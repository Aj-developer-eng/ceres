<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <!-- TITLE -->
  <title>@yield('page_title')</title>
 
  <link rel="shortcut icon" href="https://alhijaztours.net/public/favicon.ico" type="image/x-icon">
    
    <meta name="google-site-verification" content="ySvjTjmCLZHgyw7saVFtKcXCN9E9DqdCmk2kTC_xXpo" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    @yield('keywords')
    @yield('page_meta_desc')
    @yield('page_meta_title')
    
    

    <!-- GOOGLE FONT -->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:700,600,400,300' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Oswald:400' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>

    <!-- CSS LIBRARY -->
     <link rel="stylesheet" href="https://unpkg.com/flowbite@1.5.2/dist/flowbite.min.css" />
    <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/lib/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/lib/bootstrap-select.min.css') }}">
    
     <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/fonts/flaticon.css') }}">
  <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/lib/awe-booking-font.css') }}">
  
    <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/lib/magnific-popup.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/lib/jquery-ui.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/lib/owl.carousel.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/lib/owl.carousel.min.css') }}">
    <!--<link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/lib/owl.theme.default.css') }}">-->
    <!-- REVOLUTION DEMO -->
    <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/revslider-demo/css/settings.css') }}">


    <!-- MAIN STYLE -->
    <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/style.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/demo.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/build/css/intlTelInput.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/daterangepicker.css') }}">



    <!-- CSS COLOR -->
    <link id="colorreplace" rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/colors/golden.css') }}">
    

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/15.6.0/nouislider.min.css" integrity="sha512-qveKnGrvOChbSzAdtSs8p69eoLegyh+1hwOMbmpCViIwj7rn4oJjdmMvWOuyQlTOZgTlZA0N2PXA7iA8/2TUYA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    
    <link href="https://api.mapbox.com/mapbox-gl-js/v2.10.0/mapbox-gl.css" rel="stylesheet">
 


   
    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-0MLPWCSQTH"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-0MLPWCSQTH');
</script>
 
 
  <script>

$(document).ready(function(){
           
            var hostName1=window.location.href;
  
//   if(hostName1 == 'https://alhijaztours.net/hotels' ||  hostName1 == 'https://alhijaztours.net/modify_hotels_search')
//             {
              var hotel_page_select_currency = $('#exchange_currency_ajt').val();
            //var currency = $('#currency_slc').val();
                var currency= '<?php echo Session()->get('currency_slc'); ?>';
                 var currency_slc_iso= '<?php echo Session()->get('currency_slc_iso'); ?>';
                //console.log('currency hotel page='+currency);
               
              var exchange_price = [];
                var initialdisplyedhotelcount = $(".hotel_append_div").children().length;
                for(var count_i=1; count_i<=initialdisplyedhotelcount; count_i++)
                {
              price=$('.exchange_price1_1_'+count_i+'').text();
              exchange_price.push(price);
              
                
                }
//console.log(exchange_price);
    //  console.log(exchange_price);
    
    
$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            url: "{{ url('convert_currency_by_alj') }}",
            method: 'POST',
            data: {
                 "_token": "{{ csrf_token() }}",
                "currency": currency,
                "exchange_price": exchange_price,
                "currency_slc_iso": currency_slc_iso,
            },
            success: function(result){
                 console.log(result);
          result.forEach(function fn(item, index) {
 var count=index + 1;
  console.log(item);
  
  $('.exchange_rate_country_price_'+count+'').html(currency+ ' ' + item);

  

})
                 //
                
               
             
              
            },
            error:function(error){
                console.log(error);
            }
        });
        
        
        
         $('#exchange_currency_ajt').on('change', function() {
                 $('.preloader').fadeIn();
                
                var currency = $(this).find(":selected").val();
                 var currency_slc_iso = $(this).find(":selected").attr('data-iso');
               
              var exchange_price = [];
                var initialdisplyedhotelcount = $(".hotel_append_div").children().length;
                console.log('hotel_append_div'+initialdisplyedhotelcount);
                for(var count_i=1; count_i<=initialdisplyedhotelcount; count_i++)
                {
              price=$('.exchange_price1_1_'+count_i+'').text();
              exchange_price.push(price);
              
                
                }
//console.log(exchange_price);
    //  console.log(exchange_price);
    
    
$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            url: "{{ url('convert_currency_by_alj') }}",
            method: 'POST',
            data: {
                 "_token": "{{ csrf_token() }}",
                "currency": currency,
                "exchange_price": exchange_price,
                "currency_slc_iso": currency_slc_iso,
            },
            success: function(result){
                 console.log(result);
          result.forEach(function fn(item, index) {
 var count=index + 1;
  console.log(item);
  $('.exchange_rate_country_price_'+count+'').html(currency+ ' ' + item);
  $('.preloader').fadeOut();

})
                 //
                
               
             
              
            },
            error:function(error){
                console.log(error);
            }
        });
        
            
 
  
    
    
});
        
        
        
        
        
        
        
            // }  
    

});   
            
            
            
            
            

  
</script> 

 
 
<style>
button.btn.dropdown-toggle.btn-light 
{
   width: 202px !important;
        border-radius: 7px !important;
        border: 2px solid #f8f9fa !important;
        background: black !important;
        color: white !important;
        height: 41px !important;    
}
    .custom_form_select
    {
         width: 202px !important;
        border-radius: 7px !important;
        border: 2px solid #f8f9fa !important;
        background: black !important;
        color: white !important;
        height: 41px !important;   
    }
</style>

</head>

<!--[if IE 7]> <body class="ie7 lt-ie8 lt-ie9 lt-ie10"> <![endif]-->
<!--[if IE 8]> <body class="ie8 lt-ie9 lt-ie10"> <![endif]-->
<!--[if IE 9]> <body class="ie9 lt-ie10"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <body> <!--<![endif]-->


    <!-- PAGE WRAP -->
    <div id="page-wrap">
          <!-- PRELOADER -->
       
        <!-- END / PRELOADER -->
        
        
        
        <!--<div class="preloader">-->
        <!--    <div id="ModalLoadingSpinner">-->
        <!--        <div class="ModalLoadingSpinner__content" style="top:35%;">-->
        <!--            <img class="content-img" src="{{asset('public/admin_package/frontend/image_loader/white.gif')}}" />-->
           
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->
        <!-- END / PRELOADER -->
        
        
        <?php
        $all_country_currency=all_currency_func();
       if (isset($_SERVER['HTTP_CLIENT_IP']))
{
    $real_ip_adress = $_SERVER['HTTP_CLIENT_IP'];
}

if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
{
    $real_ip_adress = $_SERVER['HTTP_X_FORWARDED_FOR'];
}
else
{
    $real_ip_adress = $_SERVER['REMOTE_ADDR'];
}

$cip = $real_ip_adress;
$iptolocation = 'http://api.hostip.info/country.php?ip=' . $cip;
$creatorlocation = file_get_contents($iptolocation);
       $base_link = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
       $other_link = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
      //print_r($base_link);
        
        
        ?>
        
        
        <div class="header-wraper">
        <div class="container-fluid header-top">
            <div class="row">
                <div class="col-sm-4 col-md-4">
                <div class="contact-info">
                  <!-- LOGO -->
                  <div class="logo">
                        <a href="{{ URL::to('/') }}"><img src="{{ asset('public/admin_package/frontend/images/logo.png') }}" alt=""></a>
                    </div>
                    <!-- END / LOGO -->
                        </div>
                </div>
                <div class="col-sm-8 col-md-8">
                    <ul class="list-inline float-right">
                    <li class="list-inline-item">
                                    <i class="fa-solid fa-phone"></i>
                                    0121 777 2522
                                </li>
                    <li class="list-inline-item">
                        
                        <div class="dropdown top-drop">
                            <?php
                             $currency_slc=Session()->get('currency_slc');
                             $currency_slc_iso=Session()->get('currency_slc_iso');
                            ?>
                            <select  class="selectpicker form-control" id="exchange_currency_ajt" data-live-search="true"  data-width="100%"  data-size="5" >
                                
                                @if(isset($all_country_currency))
                                @foreach($all_country_currency as $currency)
                             <option <?php 
                             
                             if(isset($currency_slc_iso))
                             {
                                 if($currency_slc_iso == $currency->iso2)
                                 {
                                   echo 'selected';   
                                 }
                             }
                             else
                             {
                               if($creatorlocation == $currency->iso2){ echo 'selected'; }   
                             }
                              
                             
                             
                             ?> data-iso="{{$currency->iso2}}" data-flag="<img src='https://alhijaztours.net/public/admin_package/flags/<?php echo strtolower($currency->iso2); ?>.png' />" value="{{$currency->currency}}" data-content="<span style='display: flex;font-size: 14px;'><img src='https://alhijaztours.net/public/admin_package/flags/<?php echo strtolower($currency->iso2); ?>.png' />&nbsp;<span style='display:none;'>{{$currency->name}}</span> - {{$currency->currency}}</span>">{{$currency->currency}}</option>
                                
                                @endforeach
                                @endif
                            </select>
                            
                           
                            
                            
                            
                             
                            
                       
                        </div>
                    </li>
                    
                       
                        <li class="list-inline-item">
                            <?php if(session()->has('customer_login')){
                                ?>
                                <div class="show-reg-form modal-open"><a href="{{ URL::to('customer_login') }}" style="color:white;"><i class="fa fa-sign-in"></i> Log out</a></div>
                                <?php
                            }else{
                                ?>
                                <div class="show-reg-form modal-open"><a href="{{ URL::to('customer_login') }}" style="color:white;"><i class="fa fa-sign-in"></i> Sign In</a></div>
                                <?php
                            }
                            ?>

                        </li>
                    </ul>    
               
               
                </div>
            </div>

        </div>

        <!-- HEADER PAGE -->
        <header id="header-page">
            <div class="header-page__inner">
                <div class="container">
                  
                    
                    <!-- NAVIGATION -->
                    <nav class="navigation awe-navigation" data-responsive="1200">
                        <ul class="menu-list">
                            <li class=" current-menu-parent">
                                <a href="{{URL::to('/')}}">Home</a>
                               
                            </li>
                            <li class="menu-item-has-children">
                                <a href="{{URL::to('/view_all_pakages')}}">Tours</a>
                               
                            </li>
                            <li class="menu-item-has-children">
                                <a href="{{URL::to('/umrah-packages')}}">Umrah Packages </a>
                             
                            </li>
                            <li class="menu-item-has-children">
                                <a href="{{URL::to('/view_all_activities')}}">Activities </a>
                             
                            </li>
                            
                            <li class="menu-item-has-children">
                                <a href="about_us">About Us</a>
                             
                            </li>
                            <li class="menu-item-has-children">
                                <a href="{{ URL::to('contact_us') }}">Contact</a>
                               
                            </li>
                        </ul>
                    </nav>
                    <!-- END / NAVIGATION -->
                    
                    <!-- SEARCH BOX -->
                    <div class="search-box">
                         <a href="{{ route('cart') }}" style="margin-top:12px; background-color:#6c6c6c;color:white; padding-bottom:5px;" class="btn btn-info">
                            <i class="awe-icon awe-icon-cart" aria-hidden="true"></i> Cart <span class="badge badge-pill badge-danger" style="color:#ffdd00">{{ count((array) session('cart')[0]) }}</span>
                        </a>
                    </div>
                    <!-- END / SEARCH BOX -->


                    <!-- TOGGLE MENU RESPONSIVE -->
                    <a class="toggle-menu-responsive" href="#">
                        <div class="hamburger">
                            <span class="item item-1"></span>
                            <span class="item item-2"></span>
                            <span class="item item-3"></span>
                        </div>
                    </a>
                    <!-- END / TOGGLE MENU RESPONSIVE -->

                </div>
            </div>
        </header>
        </div>

        <!-- END / HEADER PAGE -->