
        <!-- FOOTER PAGE -->
        <footer id="footer-page">
            <div class="container">
                <div class="row">
                    <!-- WIDGET -->
                    <div class="col-md-3">
                        <div class="widget widget_contact_info">
                            <div class="widget_background">
                                <div class="widget_background__half">
                                    <div class="bg"></div>
                                </div>
                                <div class="widget_background__half">
                                    <div class="bg"></div>
                                </div>
                            </div>
                            <div class="logo">
                                 <img src="{{ asset('public/admin_package/frontend/images/logo-fff.png') }}" alt="">
                               
                            </div>
                            <div class="widget_content">
                               
                               
                                <a href="#">Info@Alhijaztours.net</a>
                                <p>AL HIJAZ TEAM POSSESSES DETAILED KNOWLEDGE OF ALL THE PROCEDURES OF HAJJ AND UMRAH SERVICES<p>
                            </div>
                        </div>
                    </div>
                    <!-- END / WIDGET -->

                    <!-- WIDGET -->
                    <div class="col-md-2">
                        <div class="widget widget_about_us">
                            <h3>About Us</h3>
                            <div class="widget_content">
                                <p>Al-Hijaz is the pioneer tour operation in United Kingdom to offer Hajj and Umrah services from United Kingdom. Make use of our fantastic hajj and umrah packages which are tailored to suit the needs of pilgrims visiting Saudi Arabia for their all important sacred journey.</p>
                            </div>
                        </div>
                    </div>
                    <!-- END / WIDGET -->

                    <!-- WIDGET -->
                    <div class="col-md-4">
                        <div class="widget widget_categories">
                            <h3>Helpfull Links</h3>
                            <ul>
                                 <li class="">
                                    <a href="{{URL::to('/terms_and_conditions')}}">Term & Conditions</a>
                                </li>
                               
                               
                                 <li class="">
                                    <a href="{{URL::to('/complaints_policy')}}">Complaints Policy</a>
                                </li>
                                <li class="">
                                    <a href="{{URL::to('/privacy_policy')}}">Privacy Policy</a>
                                </li>
                                 <li class="">
                                    <a href="{{URL::to('/faqs')}}">FAQs</a>
                                </li>
                                <li class="">
                                    <a href="about_us">About Us</a>
                                 
                                </li>
                                <li class="">
                                    <a href="{{ URL::to('contact_us') }}">Contact</a>
                                   
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- END / WIDGET -->

                    <!-- WIDGET -->
                 
                    <!-- END / WIDGET -->

                    <!-- WIDGET -->
                    <div class="col-md-3">
                        <div class="widget widget_follow_us">
                            <div class="widget_content">
                                <p>For Special booking request, please call</p>
                                <span class="phone">0121 777 2522</span>
                                <p>1a Nansen Road Sparkhill
Birmingham B11 4DR UK</p>


<div class="social-media-icons col-xs-12">
            <ul class="list-inline col-xs-12">
              <a href="https://twitter.com/Alhijaztours2" target="_blank" > <i class="fa-brands fa-twitter"></i></a>
                <a href="https://www.linkedin.com/company/alhijaztours/" target="_blank" ><i class="fa-brands fa-linkedin-in"></i></a>
                
                <a href="https://www.facebook.com/alhijaztoursbirmingham" target="_blank" ><i class="fa-brands fa-facebook-f"></i></a>
                <a href="#" target="_blank" ><i class="fa-brands fa-instagram"></i></a>          
            </ul>
          </div>



                               
                            </div>
                        </div>
                    </div>
                    <!-- END / WIDGET -->
                </div>
                <div class="copyright">
                    <p>©2022 Alhijaz Tours™ All rights reserved.</p>
                </div>
            </div>
        </footer>
        <!-- END / FOOTER PAGE -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

    </div>
    <!-- END / PAGE WRAP -->


    <!-- LOAD JQUERY -->
    <script type="text/javascript" src="{{ asset('public/admin_package/frontend/js/lib/jquery-1.11.2.min.js') }}"></script>
    
    
    
    
    
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script type="text/javascript" src="{{ asset('public/admin_package/frontend/js/lib/bootstrap.min.js') }}"></script>
    
 
    <script type="text/javascript" src="{{ asset('public/admin_package/frontend/js/lib/masonry.pkgd.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/admin_package/frontend/js/lib/jquery.parallax-1.1.3.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/admin_package/frontend/js/lib/jquery.owl.carousel.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/admin_package/frontend/js/lib/theia-sticky-sidebar.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/admin_package/frontend/js/lib/jquery.magnific-popup.min.js') }}"></script>
    <script type='text/javascript' src="{{ asset('public/admin_package/frontend/js/lib/jquery-ui.js') }}"></script>
          <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.1/moment.min.js"></script>

    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
        <!--<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />-->
 
    <script type="text/javascript" src="{{ asset('public/admin_package/frontend/js/scripts.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/admin_package/frontend/js/intlTelInput.js') }}"></script>
 

    <!-- REVOLUTION DEMO -->
    <script type="text/javascript" src="{{ asset('public/admin_package/frontend/revslider-demo/js/jquery.themepunch.revolution.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/admin_package/frontend/revslider-demo/js/jquery.themepunch.tools.min.js') }}"></script>
    <script src="https://unpkg.com/flowbite@1.5.2/dist/flowbite.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/15.6.0/nouislider.min.js" integrity="sha512-1mDhG//LAjM3pLXCJyaA+4c+h5qmMoTc7IuJyuNNPaakrWT9rVTxICK4tIizf7YwJsXgDC2JP74PGCc7qxLAHw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
   
   
   
    <!--<script type="text/javascript" src="{{asset('public/admin_package/frontend/js/select/jquery-2.2.0.min.js')}}"></script>-->
    <script type="text/javascript" src="{{asset('public/admin_package/frontend/js/select/popper.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('public/admin_package/frontend/js/select/bootstrap.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('public/admin_package/frontend/js/select/bootstrap-select.min.js')}}"></script>
    <!--<script type="text/javascript" src="{{asset('public/admin_package/frontend/js/select/jquery.validate.min.js')}}"></script>-->

    <script>
    
    
     $(document).ready(function(){

        var currency = $('#exchange_currency_ajt').val();
        var data_iso = $('#exchange_currency_ajt').find(":selected").attr('data-iso');
        console.log('curren is '+currency);
        $('#currency_slc').val(currency);
        $('#currency_slc_iso').val(data_iso);     
 
        //onchange action
         $('#exchange_currency_ajt').on('change', function() 
         {
             var currency = $(this).find(":selected").val();
             var currency_slc_iso = $(this).find(":selected").attr('data-iso');
             
                
              $('#currency_slc').val(currency);
                 $('#currency_slc_iso').val(currency_slc_iso);    

    
});
 
     });
     
     
     
     
     
     
    


       
</script>





    
    <script type="text/javascript">
        if($('#slider-revolution').length) {
            $('#slider-revolution').show().revolution({
                ottedOverlay:"none",
                delay:10000,
                startwidth:1600,
                startheight:800,
                hideThumbs:200,

                thumbWidth:100,
                thumbHeight:50,
                thumbAmount:5,
                
                                        
                simplifyAll:"off",

                navigationType:"none",
                navigationArrows:"solo",
                navigationStyle:"preview4",

                touchenabled:"on",
                onHoverStop:"on",
                nextSlideOnWindowFocus:"off",

                swipe_threshold: 0.7,
                swipe_min_touches: 1,
                drag_block_vertical: false,
                
                parallax:"mouse",
                parallaxBgFreeze:"on",
                parallaxLevels:[7,4,3,2,5,4,3,2,1,0],
                                        
                                        
                keyboardNavigation:"off",

                navigationHAlign:"center",
                navigationVAlign:"bottom",
                navigationHOffset:0,
                navigationVOffset:20,

                soloArrowLeftHalign:"left",
                soloArrowLeftValign:"center",
                soloArrowLeftHOffset:20,
                soloArrowLeftVOffset:0,

                soloArrowRightHalign:"right",
                soloArrowRightValign:"center",
                soloArrowRightHOffset:20,
                soloArrowRightVOffset:0,

                shadow:0,
                fullWidth:"on",
                fullScreen:"off",

                spinner:"spinner2",
                                        
                stopLoop:"off",
                stopAfterLoops:-1,
                stopAtSlide:-1,

                shuffle:"off",

                autoHeight:"off",
                forceFullWidth:"off",
                
                
                
                hideThumbsOnMobile:"off",
                hideNavDelayOnMobile:1500,
                hideBulletsOnMobile:"off",
                hideArrowsOnMobile:"off",
                hideThumbsUnderResolution:0,

                hideSliderAtLimit:0,
                hideCaptionAtLimit:0,
                hideAllCaptionAtLilmit:0,
                startWithSlide:0
            });
        }
         var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})
    </script>
    
<script src="https://api.mapbox.com/mapbox-gl-js/v2.10.0/mapbox-gl.js"></script>



    @yield('scripts')

  <!--Start of Tawk.to Script-->
<!--<script type="text/javascript">-->
<!--var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();-->
<!--(function(){-->
<!--var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];-->
<!--s1.async=true;-->
<!--s1.src='https://embed.tawk.to/6315c7ec54f06e12d892c738/1gc6h9tlr';-->
<!--s1.charset='UTF-8';-->
<!--s1.setAttribute('crossorigin','*');-->
<!--s0.parentNode.insertBefore(s1,s0);-->
<!--})();-->
<!--</script>-->
<!--End of Tawk.to Script-->
</body>
</html>