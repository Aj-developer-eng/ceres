
@extends('template/frontend/includes/master')
@section('content')
<style>
    .image-box {
    position: relative;
    margin: auto;
    overflow: hidden;
  
}
.image-box img {
    max-width: 100%;
    transition: all 0.5s;
    display: block;
    width: 100%;
    height: 200px;
    transform: scale(1);
}

.image-box:hover img {
    transform: scale(1.1);
}
.hotel-top-outer h3{
    font-size: 18px;
    color: #ceaf54;
    margin-top: 7px;
}
.fa-star{
    color: #31a900;
    font-size: 12px;
}   
.trip-item .image-cover{
        border-radius: 15px
}
.trip-item .item-body .item-title h2 a{
    color: #e19d18;
    font-size: 16px;
   } 
.sale-flights-tabs a,
.trip-item .item-body a{
     color: #666666 !important;
    text-decoration: initial;
} 
.trip-item .item-price-more a{
   background: #038501;
    color: #fff !important;
    font-size: 12px;
    padding: 5px 6px;
    margin-top: 7px !important;
}
.trip-item:hover .item-price-more .price .amount{
    color: #038501 !important;
}
.trip-item:hover{
        box-shadow: 0 0 0 2px #ffffff !important;;
}
.tabs .ui-tabs-nav li .ui-tabs-anchor {
   
    text-transform: uppercase;
    font-weight: bold;
}
.activity-section img{
   -webkit-filter: brightness(50%);
    -webkit-transition: all 1s ease;
    -moz-transition: all 1s ease;
    -o-transition: all 1s ease;
    -ms-transition: all 1s ease;
    transition: all 1s ease;
}
.activity-section{
        position: relative;
       
}

.activity-section .activity-cont{
   position: absolute;
    text-align: center;
    left: 0;
    right: 0;
    top: 30%;
    color: #fff; fin
    cursor: pointer;
}
.activity-cont h3{
    color:#fff;
}
.activity-section .image-box{
    border-radius: 15px;
}
.home-hotel-section .section-title{
    margin: 30px auto 30px;
}
.home-hotel-section .section-title h3{
    text-transform: uppercase;
}
 .trip-item,  {
    background-color: #e9e9e9;
 }
 .sale-flights-tabs .ui-state-default{
   
    margin: 0 !important;
    margin-bottom: 20px !important;
    margin-left: 10px !important;
 }
 .sale-flights-tabs .ui-state-default .ui-tabs-anchor {
    background-color: #effbfa;
    box-shadow: 0 0 0;
    border-radius: 24px;
    border: 1px solid #186d61;
   line-height: 54px !important;
    padding: 3px 27px 3px 6px !important;
 }
 .package-tb-icon{
    width: 55px;
    border-radius: 30px;
    height: 55px;
    float: left;
    margin-right: 8px;
 }
 .sale-flights-tabs .ui-tabs-nav li.ui-tabs-active .ui-tabs-anchor {
    border-bottom-color: #03a84e!important;
    border: 1px solid #03a84e;
    background-color: #d3b254;
    color: #fff!important;
 }
 .trip-item .item-price-more .price .amount{
     font-size: 16px!important;
 }
 .owl-carousel .trip-item .item-price-more {
  
    padding: 0 5px!important;
}
.display-none{
    display:none;
}
@media screen and (max-width: 480px) {
 
   .sale-flights-tabs .ui-state-default .ui-tabs-anchor{
       line-height: 25px !important;
       padding: 0px 6px 3px 6px !important;
   }
   .sale-flights-tabs .ui-state-default {
 
    margin-left: 5px !important;
    }
}
</style>
  <!-- PRELOADER -->
        <div class="preloader"></div>
        <!-- END / PRELOADER -->
@section('page_title')<?php if(isset($metaInfo) && $metaInfo != ''){echo $metaInfo->pageTitle;}?>@endsection


@section('keywords')
    <meta name="keywords" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->focus_keyword;
        }
    ?>"/>
@endsection
@section('page_meta_desc')
    <meta name="description" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->meta_description;
        }
    ?>"/>
@endsection
@section('page_meta_title')
    <meta name="title" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->metaTitle;
        }
    ?>"/>
@endsection


         <!-- HERO SECTION -->
         <section class="hero-section">
            <div id="slider-revolution">
                <ul>
                    @if(isset($silderImages))
                @foreach($silderImages as $index => $sliderImg_res)
                    <li data-slotamount="7" data-masterspeed="500" data-title="{{ $silderCaptions[$index] }}">
                        <img src="{{ config('img_url1') }}/public/images/sliderImages/{{  $sliderImg_res }}" data-bgposition="left center" data-duration="14000" data-bgpositionend="right center" alt="">
                    </li> 

                    @endforeach
                   @endif
                   

                </ul>
            </div>
        </section>
        <!-- END / HERO SECTION -->


        <!-- SEARCH TABS -->
        
        @include('template.frontend.search')
        @include('template.frontend.flash_message')
        <!-- END / SEARCH TABS -->



        <section class="sale-flights-section-demo">
            <div class="container">
                <div class="row">
                <div class="section-title">
                    <h4>Welcome to Alhijaz Tours</h4>
                    <h2>Alhijaz Tours  <span>Special </span> Packages</h2>
       
                </div>
            </div>
            
                <div class="row">
                    <div class="col-md-12">
                        <div class="sale-flights-tabs tabs">
                            <ul>
                               
                                 @if(isset($top_categories) && !empty($top_categories))
                                    @foreach($top_categories[0] as $cat_res)
                                <li><a href="#sale-flights-tabs-{{ $cat_res->id }}">
                                    
                                     <img class="package-tb-icon" src="{{ config('img_url1') }}/public/uploads/package_imgs/{{ $cat_res->image }}" alt="" >
                                    {{ $cat_res->title }}</a></li>
                                    @endforeach
                                 @endif
                               
                            </ul>
                            <div class="sale-flights-tabs__content tabs__content">
                               
                               @if(isset($top_categories) && !empty($top_categories))
                                    @foreach($top_categories[0] as $cat_res)
                                <div id="sale-flights-tabs-{{ $cat_res->id }}">
                                     <div class="owl-carousel owl-theme">
                                        @if(isset($category_tours))
                                        @foreach($category_tours as $toure_result)
                                         @if(isset($toure_result[0]->categories))
                                            @if($toure_result[0]->categories == $cat_res->id)
                                              @if(isset($toure_result))
                                                @foreach($toure_result as $toure_res)
                                                    
                                                    <div class="item">
                                                    <!-- ITEM -->
                                                        <div class="trip-item">
                                                            <div class="item-media">
                                                                <div class="image-cover">
                                                                    
                                                                    <img src="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $toure_res->tour_banner_image }}" alt="">
                                                                     <!--<img src="{{ asset('public/admin_package/frontend/images/trip.jpg') }}" alt="">-->
                                                                </div>
                                                                <!--<div class="trip-icon">-->
                                                                <!--    <img src="{{ asset('public/admin_package/frontend/images/trip.jpg') }}" alt="">-->
                                                                <!--</div>-->
                                                            </div>
                                                          
                                                            <div class="item-body">
                                                                <div class="item-title">
                                                                    <h2>
                                                                        <a href="{{ URL::to('view_detail/'.$toure_res->id.'') }}">{{ $toure_res->title }}</a>
                                                                    </h2>
                                                                </div>
                                                                <div class="item-list">
                                                                    <ul class="ul-unstyled">
                                                                        <li><i class="fa-solid fa-user"></i>   {{ $toure_res->no_of_pax_days }} Seats Available </li>
                                                                        <li><i class="fa-solid fa-moon"></i>   {{ $toure_res->time_duration - 1 }} Nights</li>
                                                                    </ul>
                                                                </div>
                                                                <!--<div class="item-footer">-->
                                                                <!--    <div class="item-rate">-->
                                                                <!--        <span>7.5 Good</span>-->
                                                                <!--    </div>-->
                                                                <!--    <div class="item-icon">-->
                                                                      
                                                                <!--        <i class="awe-icon awe-icon-car"></i>-->
                                                                <!--        <i class="awe-icon awe-icon-food"></i>-->
                                                                <!--        <i class="awe-icon awe-icon-level"></i>-->
                                                                <!--        <i class="awe-icon awe-icon-wifi"></i>-->
                                                                <!--    </div>-->
                                                                <!--</div>-->
                                                            </div>
                                                            <div class="item-price-more">
                                                                <div class="price">
                                                                Adult Price
                                                                <ins>
                                                                    <span class="amount">{{ $toure_res->currency_symbol }}
                                                                     @if($toure_res->quad_grand_total_amount != 0 OR $toure_res->quad_grand_total_amount != null)
                                                                    {{ $toure_res->quad_grand_total_amount }}
                                                                    
                                                                    @elseif($toure_res->triple_grand_total_amount != 0 OR $toure_res->triple_grand_total_amount != null) 
                                                                    {{ $toure_res->triple_grand_total_amount }}
                                                                    
                                                                    @elseif($toure_res->double_grand_total_amount != 0 OR $toure_res->double_grand_total_amount != null) 
                                                                    {{ $toure_res->double_grand_total_amount }}
                                                                    @endif
                                                                    </span>
                                                                </ins>
                                                                <!--<del>-->
                                                                <!--    <span class="amount">{{ $toure_res->currency_symbol }} -->
                                                                <!--     @if($toure_res->quad_grand_total_amount != 0 OR $toure_res->quad_grand_total_amount != null)-->
                                                                <!--    {{ $toure_res->quad_grand_total_amount }}-->
                                                                    
                                                                <!--    @elseif($toure_res->triple_grand_total_amount != 0 OR $toure_res->triple_grand_total_amount != null) -->
                                                                <!--    {{ $toure_res->triple_grand_total_amount }}-->
                                                                    
                                                                <!--    @elseif($toure_res->double_grand_total_amount != 0 OR $toure_res->double_grand_total_amount != null) -->
                                                                <!--    {{ $toure_res->double_grand_total_amount }}-->
                                                                <!--    @endif-->
                                                                <!--    </span>-->
                                                                <!--</del>-->
                                                            
                                                                </div>
                                                                <a href="{{ URL::to('view_detail/'.$toure_res->id.'') }}" class="awe-btn">Book now</a>
                                                            </div>
                                                        </div>
                                                                        <!-- END / ITEM -->
                                                    </div>
                                                    
                                                 @endforeach
                                              @endif
                                            @endif
                                            @endif
                                        @endforeach 
                                        @endif
                                    
                                    </div>
                                </div>
                                 @endforeach
                               @endif
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
     
       <section class="home-hotel-section">
           <div class="container">
               <div class="section-title">
                        <h3>Find Hotels that suit your style</h3>
                    </div>
                <div class="row g-2">
                  
                        <div class="col-sm-4">
                            <div class="row g-2">
                                <div class="col-12">
                                    <div class="hotel-top-outer activity-section">
                                        <div class="image-box">
                                               <img src="{{ asset('public/images/activites/spain.jpg') }}" alt="">
                                        </div>
                                        <div class="activity-cont">
                                            <h3>Spain</h3>
                                            <span>Total Hotels:5</span>
                                         </div>
                                      
                                    </div>
                                   
                                </div>
                                <div class="col-sm-6">
                                      <div class="hotel-top-outer activity-section">
                                        <div class="image-box">
                                              <img src="{{ asset('public/images/activites/italy.jpg') }}" alt="">
                                        </div>
                                        <div class="activity-cont">
                                            <h3>Italy</h3>
                                            <span>Total Hotels:20</span>
                                         </div>
                                      
                                    </div>
                                   
                                    
                                </div>
                                  <div class="col-sm-6">
                                      <div class="hotel-top-outer activity-section">
                                        <div class="image-box">
                                              <img src="{{ asset('public/images/activites/paris.jpg') }}" alt="">
                                        </div>
                                        <div class="activity-cont">
                                            <h3>Paris</h3>
                                            <span>Total Hotels:15</span>
                                         </div>
                                      
                                    </div>
                                    
                                    
                                </div>
                            </div>    
                        </div>    
                         <div class="col-sm-4">
                            <div class="row g-2">
                                
                                <div class="col-sm-6">
                                      <div class="hotel-top-outer activity-section">
                                        <div class="image-box">
                                              <img src="{{ asset('public/images/activites/saudia.jpg') }}" alt="">
                                        </div>
                                        <div class="activity-cont">
                                            <h3>Saudia</h3>
                                            <span>Total Hotels:15</span>
                                         </div>
                                      
                                    </div>
                                   
                                    
                                </div>
                                  <div class="col-sm-6">
                                      <div class="hotel-top-outer activity-section">
                                        <div class="image-box">
                                               <img src="{{ asset('public/images/activites/hongkong.jpg') }}" alt="">
                                        </div>
                                        <div class="activity-cont">
                                            <h3>Hong Kong</h3>
                                            <span>Total Hotels:25</span>
                                         </div>
                                      
                                    </div>
                                    
                                    
                                </div>
                                <div class="col-12">
                                    <div class="hotel-top-outer activity-section">
                                        <div class="image-box">
                                              <img src="{{ asset('public/images/activites/use.jpg') }}" alt="">
                                        </div>
                                        <div class="activity-cont">
                                            <h3>UAE</h3>
                                            <span>Total Hotels:10</span>
                                         </div>
                                      
                                    </div>
                                   
                                </div>
                            </div>    
                        </div>  
                         <div class="col-sm-4">
                            <div class="row g-2">
                                <div class="col-12">
                                    <div class="hotel-top-outer activity-section">
                                        <div class="image-box">
                                             <img src="{{ asset('public/images/activites/australia.jpg') }}" alt="">
                                        </div>
                                        <div class="activity-cont">
                                            <h3>Australia</h3>
                                            <span>Total Hotels:36</span>
                                         </div>
                                      
                                    </div>
                                   
                                </div>
                                <div class="col-sm-6">
                                      <div class="hotel-top-outer activity-section">
                                        <div class="image-box">
                                             <img src="{{ asset('public/images/activites/canada.jpg') }}" alt="">
                                        </div>
                                        <div class="activity-cont">
                                            <h3>Canada</h3>
                                            <span>Total Hotels:30</span>
                                         </div>
                                      
                                    </div>
                                   
                                    
                                </div>
                                  <div class="col-sm-6">
                                      <div class="hotel-top-outer activity-section">
                                        <div class="image-box">
                                              <img src="{{ asset('public/images/activites/america.jpg') }}" alt="">
                                        </div>
                                        <div class="activity-cont">
                                            <h3>USA</h3>
                                            <span>Total Hotels:20</span>
                                         </div>
                                      
                                    </div>
                                    
                                    
                                </div>
                            </div>    
                        </div> 
                    </div>
                        
                    
           </div>
           
       </section> 
       
        <!-- MASONRY -->
        <section class="masonry-section-demo">
            <div class="container">
                <div class="destination-grid-content">
                    <div class="section-title">
                        <h3>More than <a href="#">100 Packages</a></h3>
                    </div>
                    <div class="row1">
                        <div class="awe-masonry">
                            <!-- GALLERY ITEM -->
                            
                            @if(isset($top_categories) && !empty($top_categories))
                            @php $x=0; @endphp
                            @foreach($top_categories[0] as $cat_res)
                            <div class="awe-masonry__item">
                                <a href="{{ URL::to('/view_all_pakages/'.$cat_res->id.'') }}">
                                    <div class="image-wrap image-cover">
                                        <img src="{{ config('img_url1') }}/public/uploads/package_imgs/{{ $cat_res->image }}" alt="">
                                    </div>
                                </a>
                                <div class="item-title">
                                    <h2><a href="{{ URL::to('/view_all_pakages/'.$cat_res->id.'') }}">{{ $cat_res->title }}</a></h2>
                                    <div class="item-cat">
                                        <ul>
                                            <li><a href="{{ URL::to('/view_all_pakages/'.$cat_res->id.'') }}">{{ $cat_res->title }}</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item-available">
                                    <span class="count">{{ $top_categories[1][$x] }}</span>
                                    Available Packages1
                                </div>
                            </div>
                            
                            @php $x++ @endphp
                            @endforeach
                            @endif
                            <!-- END / GALLERY ITEM -->
                            <!-- GALLERY ITEM -->
                            <!--<div class="awe-masonry__item">-->
                            <!--    <a href="#">-->
                            <!--        <div class="image-wrap image-cover">-->
                            <!--            <img src="{{ asset('public/admin_package/frontend/images/img/2.jpg') }}" alt="">-->
                            <!--        </div>-->
                            <!--    </a>-->
                            <!--    <div class="item-title">-->
                            <!--        <h2><a href="#">The Temple Mount</a></h2>-->
                            <!--        <div class="item-cat">-->
                            <!--            <ul>-->
                            <!--                <li><a href="#">Palestine</a></li>-->
                            <!--            </ul>-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--    <div class="item-available">-->
                            <!--        <span class="count">132</span>-->
                            <!--        available hotel-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!-- END / GALLERY ITEM -->
                            <!-- GALLERY ITEM -->
                            <!--<div class="awe-masonry__item">-->
                            <!--    <a href="#">-->
                            <!--        <div class="image-wrap image-cover">-->
                            <!--            <img src="{{ asset('public/admin_package/frontend/images/img/3.jpg') }}" alt="">-->
                            <!--        </div>-->
                            <!--    </a>-->
                            <!--    <div class="item-title">-->
                            <!--        <h2><a href="#">City Tours</a></h2>-->
                            <!--        <div class="item-cat">-->
                            <!--            <ul>-->
                            <!--                <li><a href="#">Morocco</a></li>-->
                            <!--            </ul>-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--    <div class="item-available">-->
                            <!--        <span class="count">75</span>-->
                            <!--        available hotel-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!-- END / GALLERY ITEM -->
                            <!-- GALLERY ITEM -->
                            <!--<div class="awe-masonry__item">-->
                            <!--    <a href="#">-->
                            <!--        <div class="image-wrap image-cover">-->
                            <!--            <img src="{{ asset('public/admin_package/frontend/images/img/4.jpg') }}" alt="">-->
                            <!--        </div>-->
                            <!--    </a>-->
                            <!--    <div class="item-title">-->
                            <!--        <h2><a href="#">Al Rahma</a></h2>-->
                            <!--        <div class="item-cat">-->
                            <!--            <ul>-->
                            <!--                <li><a href="#">Jeddah</a></li>-->
                            <!--            </ul>-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--    <div class="item-available">-->
                            <!--        <span class="count">50</span>-->
                            <!--        available hotel-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!-- END / GALLERY ITEM -->
                            <!-- GALLERY ITEM -->
                            <!--<div class="awe-masonry__item">-->
                            <!--    <a href="#">-->
                            <!--        <div class="image-wrap image-cover">-->
                            <!--            <img src="{{ asset('public/admin_package/frontend/images/img/5.jpg') }}" alt="">-->
                            <!--        </div>-->
                            <!--    </a>-->
                            <!--    <div class="item-title">-->
                            <!--        <h2><a href="#">Top Visting Places</a></h2>-->
                            <!--        <div class="item-cat">-->
                            <!--            <ul>-->
                            <!--                <li><a href="#">Morocco</a></li>-->
                            <!--            </ul>-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--    <div class="item-available">-->
                            <!--        <span class="count">28</span>-->
                            <!--        available hotel-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!-- END / GALLERY ITEM -->
                          
                        </div>
                    </div>
                  
                    <div class="more-destination">
                        <a href="#"></a>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- END / MASONRY -->
        <section style="display:none;">
            <h4 class="text-center"><?php echo $websiteContent->page_titile ?? '' ?></h4>
            <h6>Content 1</h6>
            <p><?php echo $websiteContent->page_content1 ?? '' ?></p>

            <h6>Content 2</h6>
            <p><?php echo $websiteContent->page_content2 ?? '' ?></p>

            <h6>Content 3</h6>
            <p><?php echo $websiteContent->page_content3 ?? '' ?></p>

            <h6>Content 4</h6>
            <p><?php echo $websiteContent->page_content4 ?? '' ?></p>
        </section>
        
      


<!-- start back-to-top -->
@endsection

@section('scripts')
<!--<script src="https://maps.googleapis.com/maps/api/js?libraries=places&callback=initAutocomplete&language=nl&output=json&key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY" async defer></script>-->
<script>
var owl = $('.owl-carousel');
owl.owlCarousel({
    items:4,
    loop:true,
    margin:15,
    autoplay:true,
    autoplayTimeout:1000,
    autoplayHoverPause:true
});
$('.play').on('click',function(){
    owl.trigger('play.owl.autoplay',[1000])
})
$('.stop').on('click',function(){
    owl.trigger('stop.owl.autoplay')
})




     var siteUrl = "{{url('/')}}";
    // $(document).ready(function() {
    //     $( "#cites" ).autocomplete({
      
    //         source: function(request, response) {
    //             var city = $( "#cites" ).val();
    //             $.ajax({
    //             url: {{ URL::to('cites_suggestions') }},
    //             method:POST,
    //             data: {
    //                     cityName : city
    //              },
    //             success: function(data){
    //                 console.log('data is '+data)
    //             //   var resp = $.map(data,function(obj){
    //             //         return obj.name;
    //               }); 
      
    //               response(resp);
    //             }
    //         });
    //     },
    //     minLength: 2
    //  });
    // });
    
//     $(document).ready(function() {
//     $( "#cites" ).autocomplete({
  
//         source: function(request, response) {
//             $.ajax({
//             url: siteUrl + '/' +"cites_suggestions",
//             data: {
//                     term : request.term,
//                     type:'activity'
//              },
//             dataType: "json",
//             success: function(data){
//               var resp = $.map(data,function(obj){
//                     return obj.name;
//               }); 
  
//               response(resp);
//             }
//         });
//     },
//     minLength: 2
//  });
// });

</script>

  <script>
  
    function initAutocomplete() {
        var departure_city = document.getElementById('departure_city');
        var autocomplete = new google.maps.places.Autocomplete(departure_city);
      }
            // $("#cites").keyup(function(e){
              
            //   var city_lettar = $("#cites").val();
              
            //         $.ajax({
            //                     type: 'POST',
            //                     url: '{{URL::to('cites_suggestions')}}',
            //                     data: {_token: '{{ csrf_token() }}',
            //                         'city_lettar': city_lettar,
            //                          'table':'Activities'
            
            //                     },
            //                     success: function(msg){
            //                     var city = JSON.parse(msg);
            //                     console.log(city);
            //                     var list_data = '';
            //                     for(var i=0; i<city.length; i++){
                                    
            //                         list_data = list_data+`<li class="list-group-item" onClick="selectCity('${city[i]}')" >${city[i]}</li>`;
            //                     }
            //                     // 
                                
            //                     $('#cites_result').html(list_data)
            //                     console.log(list_data);
                                
                               
            
                                
            //                     }
                                
                        
            //             });
            // });
            
            function selectCity(val) {
                $("#cites").val(val);
                $('#cites_result').css('disp')
                // $("#suggesstion-box").hide();
            }
            
             $("#pakages_city").keyup(function(e){
              
              var city_lettar = $("#pakages_city").val();
              
                    $.ajax({
                                type: 'POST',
                                url: '{{URL::to('cites_suggestions')}}',
                                data: {_token: '{{ csrf_token() }}',
                                    'city_lettar': city_lettar,
                                     'table':'new_activites'
            
                                },
                                success: function(msg){
                                var city = JSON.parse(msg);
                                console.log(city);
                                var list_data = '';
                               
                                for(var i=0; i<city.length; i++){
                                    
                                    list_data = list_data+`<li class="list-group-item" onClick="selectCity('${city[i]}')" >${city[i]}</li>`;
                                }
                                // 
                                
                                $('#cites_result').html(list_data)
                                //  $('#cites_result').css('display','block')
                                console.log(list_data);
                                
                               
            
                                
                                }
                                
                        
                        });
            });
            
            function selectCity(val) {
                $("#cites").val(val);
                // $('#cites_result').css('display','none')
                // $("#suggesstion-box").hide();
            }
            
             
            $(function() {
            $("#dp1660648464442").datepicker({ beforeShowDay: function(date) {
            var day = date.getDay();
            return [(day != 1 && day != 3)];
            }
            });
            });
        
        
            


        </script>
        
          <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js" ></script>
    <script>

        var path = "{{ url('cites_suggestions') }}";
        
        $('#cites').typeahead({
        
            source: function(query, process){
        
                return $.get(path, {query:query}, function(data){
                    console.log(data);
                    return process(data);
        
                });
        
            }
        
        });
        
        </script>
  <div class="modal fade" id="exampleModalpayment" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Make Payment</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="{{ URL::to('submit_invoice_no') }}" method="post">
          @csrf
      <div class="modal-body">
        
          <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Enter Invoice No.</label>
            <input type="text" class="form-control" name="invoice_no" id="exampleInputEmail1" aria-describedby="emailHelp">
          </div>
          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="view_booking" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">View Booking</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="{{ URL::to('view_customer_bookings') }}" method="post">
          @csrf
      <div class="modal-body">
        
          <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Enter Email.</label>
            <input type="text" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp">
          </div>
          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="view_track_id_booking" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">View Booking</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="{{ URL::to('view_track_id_booking') }}" method="post">
          @csrf
      <div class="modal-body">
        
          <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Enter Track ID.</label>
            <input type="text" class="form-control" name="track_id" id="exampleInputEmail1" aria-describedby="emailHelp">
          </div>
          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
    </div>
  </div>
</div>
@endsection
