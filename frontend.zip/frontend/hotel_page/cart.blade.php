@extends('template/frontend/includes/master')

@section('content')

<?php

 $child_count = Session::get('child_searching');
  $hotel_beds_code=Session::get('hotel_beds_code');
 $adult_count1 = Session::get('adult');
  $adult_count=$adult_count1 + $child_count;
  $slug= Session::get('provider');
    $slug= Session::get('provider');
    $search_id=Session::get('search_id');
    
    
    $hotelbedSelectionRS=$get_data->hotelbedSelectionRS;
    $hotel_beds_select_res=json_decode($hotelbedSelectionRS);
    // print_r($hotel_beds_select_res);die();
    
    
// $cart=Session::get('cart');
// print_r($slug);die();

?>

<?php
if($slug == 'hotelbeds')
{

?>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Room Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="Tour_data">
        <table class="room-type-table tours-hotels-table">
                                                        <thead>
                                                            <tr>
                                                                
                                                              
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach($hotel_beds_select_res->hotel->rooms as $rooms)
                                                            @foreach($rooms->rates as $rates) 
                                                            <tr>
                                                                <td class="room-type">
                                                                    <div class="room-thumb">
                                                                        <img style="height: 150px;" src="https://client1.synchronousdigital.com/public/uploads/package_imgs/crown-madina-1.jpg" alt="">
                                                                    </div>
                                                                    <div class="room-title">
                                                                        <h4>{{$rooms->name}}</h4>
                                                                    </div>
                                                                    
                                                                        <ul class="list-unstyled">
                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i>Adults  : {{$rates->adults}}</li>
                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> Children : {{$rates->children}}</li>
                                                                            <li><i class="fa fa-moon-o" aria-hidden="true"></i> Bord Type : {{$rates->boardName}}</li>
                                                                            <li><i class="fa fa-moon-o" aria-hidden="true"></i> Room Price :{{$hotel_beds_select_res->hotel->currency}}  {{$rates->net}}</li>
                                                                        </ul>
                                                                    
                                                                   
                                                                   
                                                                </td>
                                                                <td class="room-people"><p>{{$rates->rateType}}</p></td>
                                                                <td class="room-condition" style="width: 100%!important;padding-right: 0px !important">
                                                                  <p style="font-weight:bold;">Note</p>{{$rates->rateComments}}
                                                                   
                                                                    
                                                                </td>
                                                               
                                                            </tr>
                                                          
                                                          @endforeach
                        @endforeach
                                                        </tbody>
                                                    </table>
      </div>
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="exampleModal_cancelation" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cancellation Policies</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="Tour_data">
        <table class="room-type-table tours-hotels-table">
                                                        <thead>
                                                            <tr>
                                                               <th width="10%">from</th>
                                                                <th width="25%">Amount</th>
                                                               
                                                 
                                                              
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach($hotel_beds_select_res->hotel->rooms as $rooms)
                                                            @foreach($rooms->rates as $rates)
                                                            @foreach($rates->cancellationPolicies as $cancellationPolicies) 
                                                            <tr>
                                                                <td class="room-type">
                                                                {{$cancellationPolicies->from}}
                                                                </td>
                                                                <td class="room-people">{{$hotel_beds_select_res->hotel->currency}}  {{$cancellationPolicies->amount}}</td>
                                                                
                                                               
                                                            </tr>
                                                          @endforeach
                                                          @endforeach
                                                         @endforeach
                                                        </tbody>
                                                    </table>
      </div>
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div>



<section class="checkout-section-demo" style="margin-top: 70px;">
            <div class="container mt-4">
                <div class="row mt-5">
                    
                    <div class="col-lg-3">
                        <div class="checkout-page__sidebar">
                            <ul>
                                <li class="current"><a href="checkout-yourcart.html">Your Cart</a></li>
                                <li><a href="checkout-customer.html">Customer information</a></li>
                                <li><a href="checkout-complete.html">Complete order</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="checkout-page__content">
                            <div class="yourcart-content">
                                <div class="content-title">
                                    <h2><i class="awe-icon awe-icon-cart"></i>Check Your Cart</h2>
                                </div>
                                <div class="cart-content">
                                    <table class="cart-table">
                                        <thead>
                                            <tr>
                                                <th width="10%"></th>
                                                <th width="40%">Hotel Name</th>
                                                
                                                <th width="25%">Rooms</th>
                                                <th width="10%">Adults/Children</th>
                                                <th class="10%" style="text-align:center">Price</th>
                                                
                                                <th class="10%" style="text-align:right">View</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           
                                            <tr data-id="">
                                                <td style="padding:5px;">
                                                    <img style="height:50px;  width:100%; overflow:hidden;" src="" alt="" class="flex-shrink-0">    
                                                </td>
                                                <td>
                                                    <span>{{$hotel_beds_select_res->hotel->name}}</span>
                                                    <br>
                                                    <a class="mt-3"  href="#" data-bs-toggle="modal" data-bs-target="#exampleModal_cancelation">
                                                       Cancellation Policy ?
                                                    </a>
                                
                                                </td>
                                                <td class="product-price">
                                                    
                                                        <span class="amount" style="font-size:.9rem;">{{$get_data->rooms ?? ''}}</span>
                                                       
                                                   
                                                    
                                                    
                                                   
                                                </td>
                                                 
                                                <td>
                                                    
                                                            <div class="form-elements form-adult">
                                                                <div class="form-item">
                                                                   {{$get_data->total_passenger}}/{{$get_data->child}}
                                                                </div>
                                                            </div>
                                                        
                                                    
                                                </td>
                                                <td class="product-subtotal">
                                                    <span class="amount">{{$hotel_beds_select_res->hotel->currency}}  {{$hotel_beds_select_res->hotel->totalNet}}</span>
                                                </td>
                                               
                                                 <td>
                                                    <button class="btn btn-sm" title="View Detail"  data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa fa-eye" aria-hidden="true"></i></button>
                                                </td>
                                            </tr>
                                            
                                           
                                                    
                                                    
                                                
                                               
                                            
                                                        
                                          
                                          
                                        </tbody>
                                    </table>
                                 
                                    <div class="cart-footer">
                                   
                                        <div class="cart-submit mt-5">
                                           
                                            <a href="{{ URL::to('hotel_checkout')}}" class="btn" style="background-color:#d2b254; color:white;">Proceed to Checkout</a>
                                           
                                                
                                           
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<?php
}
?>
<?php
if($slug == 'travellanda')
{
    
$travellandaSelectionRS=$get_data->travellandaSelectionRS;
$travellandaSelectionRS=json_decode($travellandaSelectionRS);

// print_r($travellandaSelectionRS);die();
 $travellandadetailRS=$get_data->travellandadetailRS;
$travellandadetailRS=json_decode($travellandadetailRS);   

  $travellanda_cancellation_response=$get_data->travellanda_cancellation_response;
$travellanda_cancellation_response=json_decode($travellanda_cancellation_response);   
    
    
?>


<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Room Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="Tour_data">
        <table class="room-type-table tours-hotels-table">
                                                        <thead>
                                                            <tr>
                                                                
                                                              
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach($travellandaSelectionRS as $travellandaSelectionRS)
                                                            <tr>
                                                                <td class="room-type">
                                                                    <div class="room-thumb">
                                                                        <img style="height: 150px;" src="https://client1.synchronousdigital.com/public/uploads/package_imgs/crown-madina-1.jpg" alt="">
                                                                    </div>
                                                                    <div class="room-title">
                                                                        <h4>{{$travellandaSelectionRS->Rooms->Room->RoomName}}</h4>
                                                                    </div>
                                                                    
                                                                        <ul class="list-unstyled">
                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i>Adults  : {{$travellandaSelectionRS->Rooms->Room->NumAdults}}</li>
                                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> Children : {{$travellandaSelectionRS->Rooms->Room->NumChildren}}</li>
                                                                            <li><i class="fa fa-moon-o" aria-hidden="true"></i> Bord Type : {{$travellandaSelectionRS->BoardType}}</li>
                                                                            <li><i class="fa fa-moon-o" aria-hidden="true"></i> Room Price :{{$travellanda_cancellation_response->Body->Currency ?? ''}} {{$travellandaSelectionRS->Rooms->Room->RoomPrice}}</li>
                                                                        </ul>
                                                                    
                                                                   
                                                                   
                                                                </td>
                                                                <td class="room-people"><p></p></td>
                                                                <td class="room-condition" style="width: 100%!important;padding-right: 0px !important">
                                                                  <p style="font-weight:bold;">Note</p>
                                                                   
                                                                    
                                                                </td>
                                                               
                                                            </tr>
                                                          
                                                         @endforeach
                                                        </tbody>
                                                    </table>
      </div>
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="exampleModal_cancelation" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cancellation Policies</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="Tour_data">
        <table class="room-type-table tours-hotels-table">
                                                        <thead>
                                                            <tr>
                                                               <th width="10%">From</th>
                                                               <th width="10%">Type</th>
                                                                <th width="25%">Amount</th>
                                                               
                                                 
                                                              
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @if(isset($travellanda_cancellation_response->Body->Policies->Policy))
                                                           @foreach($travellanda_cancellation_response->Body->Policies->Policy as $Policy)
                                                            <tr>
                                                                <td class="room-type">
                                                               {{$Policy->From}}
                                                                </td>
                                                                <td class="room-people">{{$Policy->Type}}</td>
                                                                <td class="room-people">{{$travellanda_cancellation_response->Body->Currency}}  {{$Policy->Value}}</td>
                                                               
                                                            </tr>
                                                          @endforeach
                                                          @endif
                                                        </tbody>
                                                    </table>
      </div>
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div>



<section class="checkout-section-demo" style="margin-top: 70px;">
            <div class="container mt-4">
                <div class="row mt-5">
                    
                    <div class="col-lg-3">
                        <div class="checkout-page__sidebar">
                            <ul>
                                <li class="current"><a href="checkout-yourcart.html">Your Cart</a></li>
                                <li><a href="checkout-customer.html">Customer information</a></li>
                                <li><a href="checkout-complete.html">Complete order</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="checkout-page__content">
                            <div class="yourcart-content">
                                <div class="content-title">
                                    <h2><i class="awe-icon awe-icon-cart"></i>Check Your Cart</h2>
                                </div>
                                <div class="cart-content">
                                    <table class="cart-table">
                                        <thead>
                                            <tr>
                                                <th width="10%"></th>
                                                <th width="40%">Hotel Name</th>
                                                
                                                <th width="25%">Rooms</th>
                                                <th width="10%">Adults/Children</th>
                                                <th class="10%" style="text-align:center">Price</th>
                                                
                                                <th class="10%" style="text-align:right">View</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           
                                            <tr data-id="">
                                                <td style="padding:5px;">
                                                    <img style="height:50px;  width:100%; overflow:hidden;" src="" alt="" class="flex-shrink-0">    
                                                </td>
                                                <td>
                                                    <span>{{$travellandadetailRS->HotelName}}</span>
                                                    <br>
                                                    <a class="mt-3"  href="#" data-bs-toggle="modal" data-bs-target="#exampleModal_cancelation">
                                                       Cancellation Policy ?
                                                    </a>
                                
                                                </td>
                                                <td class="product-price">
                                                    
                                                        <span class="amount" style="font-size:.9rem;"> {{$get_data->rooms}}</span>
                                                       
                                                   
                                                    
                                                    
                                                   
                                                </td>
                                                 
                                                <td>
                                                    
                                                            <div class="form-elements form-adult">
                                                                <div class="form-item">
                                                                   {{$get_data->total_passenger}}/{{$get_data->child}}
                                                                </div>
                                                            </div>
                                                        
                                                    
                                                </td>
                                                <td class="product-subtotal">
                                                    <span class="amount">{{$travellanda_cancellation_response->Body->Currency ?? ''}}  {{$travellandadetailRS->Options->Option[0]->TotalPrice}}</span>
                                                </td>
                                               
                                                 <td>
                                                    <button class="btn btn-sm" title="View Detail"  data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa fa-eye" aria-hidden="true"></i></button>
                                                </td>
                                            </tr>
                                            
                                           
                                              
                                                    
                                                
                                               
                                            
                                                        
                                          
                                          
                                        </tbody>
                                    </table>
                                 
                                    <div class="cart-footer">
                                   
                                        <div class="cart-submit mt-5">
                                           
                                            <a href="{{ URL::to('hotel_checkout')}}" class="btn" style="background-color:#d2b254; color:white;">Proceed to Checkout</a>
                                           
                                                
                                           
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


<?php
}
?>

@endsection

