@extends('template/frontend/includes/master')

@section('content')

<?php

 $child_count = Session::get('child_searching');
  $hotel_beds_code=Session::get('hotel_beds_code');
 $adult_count1 = Session::get('adult');
 $room_search=Session()->get('room_searching');

   $adult_count=$adult_count1;
   
   $adult_count_travelanda=$adult_count1 + $child_count;
  $slug= Session::get('provider');
    //print_r($slug);die();
    $search_id=Session::get('search_id');
     $other_passenger = Session()->get('other_adults',[]);
     $ratehawk_select_room=Session::get('ratehawk_select_room');
     $country_nationality=Session::get('country_nationality');
// $cart=Session::get('cart');
// dd($ratehawk_select_room);die();

$hotels_checkavailability=Session::get('hotels_checkavailability');
$rooms_checkavailability=Session::get('rooms_checkavailability');

 //print_r($get_data->tboSelectionRS);die();
?>
<style>
    .form-label {
    margin-bottom: 0.5rem;
    font-weight: 700;
    font-size: 15px;
    font-family: sans-serif;
}
.checkout-note{
  background-color: #277019;
  color:#fff;
 
}
.checkout-note p{
line-height: 35px;
    padding-left: 10px;
    font-size: 12px;
}
</style>

@if(session()->has('message'))
                            <div class="alert alert-success">
                                {{session('message')}}
                            </div>
                            @endif



    <section class="awe-parallax category-heading-section-demo h-300">
            <div class="awe-overlay"></div>
           
            </div>
        </section>
        <section class="checkout-section-demo">
            <div class="container">
                 
                <div class="row">
                    <div class="col-lg-8" style="border: 1px solid #d4d4d4;margin-bottom: 25px;">
         <?php
         if($slug == 'travellanda')
         {
          
          
          
         
         $travellanda_cancellation_response=$get_data->travellanda_cancellation_response;
        $travellanda_cancellation_response=json_decode($travellanda_cancellation_response);
        
                        ?>
                        <div class="checkout-page__top" style="margin-top: 15px;margin-bottom: 15px !important;color: #17c917f5;">
      <?php
      $current=date('Y-m-d');
  
    if(isset($travellanda_cancellation_response->Body->CancellationDeadline))
    {
      if($travellanda_cancellation_response->Body->CancellationDeadline < $current)
      {
      
      ?> 

         <div class="row">
          <div class="col-md-1" style="padding-left: 20px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-4" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        </div>
        </div>
      <?php
      
      }
      else
      {
      
      ?>
      
              RISK FREE! No cancellation fee before {{$travellanda_cancellation_response->Body->CancellationDeadline ?? ''}} (property local time)

      <?php
      }
    }
    
    ?>
   
    
              </div>
                    </div>
                    <div class="col-lg-4" style="border: 1px solid #d4d4d4;margin-bottom: 25px;">
                        <div class="checkout-page__top" style="margin-top: 15px;margin-bottom: 15px !important;">
                            Holding Pricing… <i style="font-size: 24px;margin-left: 3px;margin-right: 10px;" class="fa-solid fa-clock-rotate-left"></i>
                        </div>
                    </div>
        <?php
         }
         else if($slug == 'tbo')
         {
         ?>
             
             <div class="checkout-page__top" style="margin-top: 15px;margin-bottom: 15px !important;color: #17c917f5;">
            <div class="row">
          <div class="col-md-1" style="padding-left: 20px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
     
     
     <?php
      $tboSelectionRS=json_decode($get_data->tboSelectionRS);
    //print_r($tboSelectionRS);
      $current=date('Y-m-d');
      foreach($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies as $CancelPolicies)
      {
         if($CancelPolicies->ChargeType == 'Percentage')
         {
             $from=$CancelPolicies->FromDate;
         
       $from=date('Y-m-d', strtotime($from));
         
     if(isset($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies))
    {
      if($from > $current)
      {
      
      ?> 
      
            
       <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >RISK FREE! No cancellation fee before <?php echo  date('d M, Y', strtotime($from))?>  (property local time)</a></br>  
        
       
      <?php
      
      }
      else
      {
      
      ?>
      
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>      

      <?php
      }
    }
         }
      }
      ?>
     
        
        </div>
        </div>
          </div>
                    </div>
                    <div class="col-lg-4" style="border: 1px solid #d4d4d4;margin-bottom: 25px;">
                        <div class="checkout-page__top" style="margin-top: 15px;margin-bottom: 15px !important;">
                            Holding Pricing… <i style="font-size: 24px;margin-left: 3px;margin-right: 10px;" class="fa-solid fa-clock-rotate-left"></i>
                        </div>
                    </div>   
             
        <?php
             
         }
          else if($slug == 'ratehawke')
         {
         ?>
             
             <div class="checkout-page__top" style="margin-top: 15px;margin-bottom: 15px !important;color: #17c917f5;">
            <div class="row">
          <div class="col-md-1" style="padding-left: 20px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-4" style="padding-left: 0px;">
     
     
  
     <?php
     
     $ratehawk_details_rs1=$get_data->ratehawk_details_rs1;
    $ratehawk_details_rs1=json_decode($ratehawk_details_rs1);
    $array_ratehawk=array();
    foreach($ratehawk_select_room as $ratehawk_select_room)
       {
    foreach($ratehawk_details_rs1->hotels[0]->rates as $rates)
    {
      if($ratehawk_select_room->book_hash  == $rates->book_hash)
      {
         $array_ratehawk[]=$rates; 
      }
       
           
     }
    }
     
     
     
     
      $current=date('Y-m-d');
       $from=date('Y-m-d', strtotime($array_ratehawk[0]->payment_options->payment_types[0]->cancellation_penalties->policies[0]->end_at));
     if(isset($array_ratehawk[0]->payment_options->payment_types[0]->cancellation_penalties))
    {
      if($from < $current)
      {
      
      ?>
     <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
     
 <?php
 
      }
      else
      {
 ?>
      
            
    <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >RISK FREE! No cancellation fee before <?php echo  date('d M, Y', strtotime($from))?>  (property local time)</a></br>     
        
       
      <?php
      
      }
    }
      
   
      ?>
     
        
        </div>
        </div>
          </div>
                    </div>
                    <div class="col-lg-4" style="border: 1px solid #d4d4d4;margin-bottom: 25px;">
                        <div class="checkout-page__top" style="margin-top: 15px;margin-bottom: 15px !important;">
                            Holding Pricing… <i style="font-size: 24px;margin-left: 3px;margin-right: 10px;" class="fa-solid fa-clock-rotate-left"></i>
                        </div>
                    </div>   
             
        <?php
             
         }
         else if($slug == 'hotels')
         {
         ?>
             
             <div class="checkout-page__top" style="margin-top: 15px;margin-bottom: 15px !important;color: #17c917f5;">
            <?php

    if(isset($rooms_checkavailability[0]->cancellation_policy))
    {
      if($rooms_checkavailability[0]->cancellation_policy->guests_pay == 'of the full stay')
      {
      
      ?> 

         <div class="row">
          <div class="col-md-1" style="padding-left: 20px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-4" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        </div>
        </div>
      <?php
      
      }
      else
      {
      
      ?>
      
              RISK FREE! No cancellation fee before {{$rooms_checkavailability[0]->cancellation_policy->guests_pay_days ?? ''}} (property local time)

      <?php
      }
    }
    
    ?>
          </div>
                    </div>
                    <div class="col-lg-4" style="border: 1px solid #d4d4d4;margin-bottom: 25px;">
                        <div class="checkout-page__top" style="margin-top: 15px;margin-bottom: 15px !important;">
                            Holding Pricing… <i style="font-size: 24px;margin-left: 3px;margin-right: 10px;" class="fa-solid fa-clock-rotate-left"></i>
                        </div>
                    </div>   
             
        <?php
             
         }
         else
         {
  ?>

<div class="checkout-page__top" style="margin-top: 15px;margin-bottom: 15px !important;color: #17c917f5;">
    
    
          @if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
    @endif
    @if(session()->has('message1'))
    <div class="alert alert-success">
        {{ session()->get('message1') }}
    </div>
    
    
@endif

    <?php
      $current=date('Y-m-d');
      $hotelbedSelectionRS=$get_data->hotelbedSelectionRS;
        $hotelbedSelectionRS=json_decode($hotelbedSelectionRS);
        $hotelbedSelectionRS=$hotelbedSelectionRS->hotel;
        $from=date('Y-m-d', strtotime($hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies[0]->from));
      
     
     if(isset($hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies))
    {
      if($from > $current)
      {
      
      ?> 
      <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
                                                    <?php
                                                     $price=$hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies[0]->amount ?? '';
                                                    $currency=$hotelbedSelectionRS->currency ?? '';
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                    ?>
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" > GBP {{$exchange_price ?? ''}}  will be deducted upon cancellation From {{$hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies[0]->from ?? ''}}</a>
        </div>
        </div>

        
      <?php
      
      }
      else
      {
      
      ?>
      
      
      <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        </div>
        </div>
      
      
             

      <?php
      }
    }
      ?>
    
    
    
              </div>
                    </div>
                    <div class="col-lg-4" style="border: 1px solid #d4d4d4;margin-bottom: 25px;">
                        <div class="checkout-page__top" style="margin-top: 15px;margin-bottom: 15px !important;">
                           
                           <div>  Holding Pricing… <i style="font-size: 24px;margin-left: 3px;margin-right: 10px;" class="fa-solid fa-clock-rotate-left"></i><span style="color: #14b314;font-size: 19px;" id="time">05:00</span> minutes!</div>
                        </div>
                    </div>
      
      
      
      
      
<?php   
}
?>
         
                           
              
                    
<div class="col-lg-8">
<div class="checkout-page__content" style="overflow: hidden;border: 1px solid #d4d4d4;padding: 30px;">
                            
      <h6>Let us know who you are?</h6>
                             
                             
  @if($slug == "travellanda" || $slug == "hotelbeds" || $slug == "tbo" || $slug == "ratehawke" || $slug == "hotels")
  
  
  
  
                            
                    <!-- Modal -->
                    
                    <!--Add More Passenger Model Start-->
<div class="modal fade" id="exampleModal_other_passenger" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add More Passenger</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <form class="row g-3" method="post"  action="{{URL::to('add_other_passengar')}}">
           @csrf
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">Title</label>
    <select class="form-control" name="title">
        <option value="">Select Title</option>
        <option value="Mr.">Mr.</option>
        <option value="Mrs.">Mrs.</option>
    </select>
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">First Name</label>
    <input type="text" class="form-control" value="{{$other_passengar_decode[0]->other_first_name ?? ''}}"  name="other_first_name" >
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">Last Name</label>
    <input type="text" class="form-control" value="{{$other_passengar_decode[0]->other_last_name ?? ''}}"  name="other_last_name">
  </div>
  <div class="col-md-6">
    <label for="inputEmail4"  class="form-label">Nationality</label>
    <select class="form-control selectpicker" data-live-search="true" name="other_nationality">
         <option value="{{$country_nationality}}">{{$country_nationality}}</option>
        
        <!--<option value="">Select Nationality</option>-->
        <!--@foreach($countries as $countries)-->
        <!--<option value="{{$countries->name}}">{{$countries->name}}</option>-->
        <!--@endforeach-->
       
    </select>
  </div>
  
  <div class="col-12" style="text-align: right;">
    <button type="submit" name="submit"  class="btn btn-primary">Save</button>
  </div>
</form>
      </div>
      
    </div>
  </div>
</div>
<!--Add More Passenger Model End-->



 <!--Add Child Passenger Model Start-->
<div class="modal fade" id="exampleModal_booking_popup" tabindex="-1" aria-labelledby="exampleModalLabel1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel1">Booking Process</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          
          <div class="checkout-page__top" style="margin-top: 15px;margin-bottom: 15px !important;color: #17c917f5;">
    
    
    <?php
    if($slug == 'hotelbeds')
    {
      $current=date('Y-m-d');
      $hotelbedSelectionRS=$get_data->hotelbedSelectionRS;
        $hotelbedSelectionRS=json_decode($hotelbedSelectionRS);
        $hotelbedSelectionRS=$hotelbedSelectionRS->hotel;
        $from=date('Y-m-d', strtotime($hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies[0]->from));
      
     
     if(isset($hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies))
    {
      if($from > $current)
      {
      
      ?> 
 <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
     
     <div class="col-md-11" style="padding-left: 0px;">
                                                    <?php
                                                     $price=$hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies[0]->amount ?? '';
                                                    $currency=$hotelbedSelectionRS->currency ?? '';
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                    ?>
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" > GBP {{$exchange_price ?? ''}}  will be deducted upon cancellation From {{$hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies[0]->from ?? ''}}</a>

        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >Pay us before  {{$hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies[0]->from}}  and avoid to cancel your booking.</a>
        
        </div>
        </div>
        
      <?php
      
      }
      else
      {
      
      ?>
     
      
      <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        </div>
        </div>
      
      
             

      <?php
      }
    }
    }
     if($slug == 'travellanda')
    {
      $current=date('Y-m-d');
      $travellanda_cancellation_response=$get_data->travellanda_cancellation_response;
        $travellanda_cancellation_response=json_decode($travellanda_cancellation_response);
      
     
    if(isset($travellanda_cancellation_response->Body->CancellationDeadline))
    {
      if($travellanda_cancellation_response->Body->CancellationDeadline < $current)
      {
      ?> 

        <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        </div>
        </div>
      <?php
      
      }
      else
      {
      
      ?>
      <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >RISK FREE! No cancellation fee before <?php echo  date('d M, Y', strtotime($travellanda_cancellation_response->Body->CancellationDeadline))?> (property local time)</a></br>
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >Pay us before <?php echo  date('d M, Y', strtotime($travellanda_cancellation_response->Body->CancellationDeadline))?>  and avoid to cancel your booking.</a>
        </div>
        </div>
      
      
      
      
             

      <?php
      }
    }
    }
    
     if($slug == 'tbo')
    {
       $tboSelectionRS=json_decode($get_data->tboSelectionRS);
      $current=date('Y-m-d');
    //   print_r($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies);
       foreach($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies as $CancelPolicies)
      {
         if($CancelPolicies->ChargeType == 'Percentage')
         {
             $from=$CancelPolicies->FromDate;
        
       $from=date('Y-m-d', strtotime($from));
     if(isset($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies))
    {
      if($from > $current)
      {
      
      ?> 
<div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >RISK FREE! No cancellation fee before <?php echo  date('d M, Y', strtotime($from))?>  (property local time)</a></br>
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >Pay us before <?php echo  date('d M, Y', strtotime($from))?>   and avoid to cancel your booking.</a>
        </div>
        </div>
        
        
      <?php
      
      }
      else
      {
      
      ?>
      
      
      <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        </div>
        </div>
      
      
             

      <?php
      }
    }
    }
      }
      }
    
    if($slug == 'ratehawke')
    {
        $current=date('Y-m-d');
       $from=date('Y-m-d', strtotime($array_ratehawk[0]->payment_options->payment_types[0]->cancellation_penalties->policies[0]->end_at));
     if(isset($array_ratehawk[0]->payment_options->payment_types[0]->cancellation_penalties))
    {
      if($from < $current)
      {
      
      ?> 

        <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        </div>
        </div>
      <?php
      
      }
      else
      {
      
      ?>
      <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >RISK FREE! No cancellation fee before <?php echo  date('d M, Y', strtotime($from))?>  (property local time)</a></br>
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >Pay us before <?php echo  date('d M, Y', strtotime($from))?>   and avoid to cancel your booking.</a>
        </div>
        </div>
      
      
      
      
             

      <?php
      }
    }
    } 
    
      if($slug == 'hotels')
    {
        ?>
       

        <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
          <?php
      if(isset($rooms_checkavailability[0]->cancellation_policy))
    {
      if($rooms_checkavailability[0]->cancellation_policy->guests_pay == 'of the full stay')
      {

      ?>
       <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        </div>
      <?php
    }
    else
    {
    ?>
    
     <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1">Refundable</a>
        </div>
    
<?php
    }
    }
      ?>

        </div>
        
        <?php
      
    
    } 
   
      
      ?>
    
    
    
              </div>
          
          <div class="col-12" style="text-align: right;">
              <?php
              $booking_status=$get_data->booking_status;
              if($booking_status != 'Non Refundable')
              {
              ?>
              
              <form action="{{URL::to('/confrimbooking')}}/{{$search_id}}/{{$slug}}" method="GET">
                  @csrf
                  <?php
                  for($i=1; $i<=$room_search; $i++)
                  {
                      
                  
                  ?>
                  <input id="select_dynamic_price_{{$i}}" type="hidden" name="select_dynamic_price[]" value=""/>
              <input id="select_dynamic_currency_{{$i}}" type="hidden" name="select_dynamic_currency[]" value=""/>
              <?php
                  }
              ?>
                  <button class="btn" type="submit" name="submit"  style="background-color:#277019; color:white;"  >Confirm booking</button> 
              </form>
   
   <?php
   
              }
              else
              {
                  ?>
                  <a class="" href="javascript:;" style="color:#277019;"  >Keep tracking your reservation by using Track ID:{{$search_id}}</a>
                  <?php
                 
              }
   ?>
  </div>
        
      </div>
      
    </div>
  </div>
</div>
<!--Add child Passenger Model End-->


 <!--Add Child Passenger Model Start-->
<div class="modal fade" id="exampleModal_child" tabindex="-1" aria-labelledby="exampleModalLabel1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel1">Add Child Passenger</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <form class="row g-3" method="post"  action="{{URL::to('add_child_passengar')}}">
           @csrf
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">Title</label>
    <select class="form-control" name="title">
        <option value="">Select Title</option>
        <option value="Mr.">Mr.</option>
        <option value="Mrs.">Mrs.</option>
    </select>
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">First Name</label>
    <input type="text" class="form-control" value="{{$other_passengar_decode[0]->other_first_name ?? ''}}"  name="other_first_name" >
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">Last Name</label>
    <input type="text" class="form-control" value="{{$other_passengar_decode[0]->other_last_name ?? ''}}"  name="other_last_name">
  </div>
  <div class="col-md-6">
    <label for="inputEmail4"  class="form-label">Nationality</label>
    <select class="form-control selectpicker" data-live-search="true" name="other_nationality">
        <option value="">Select Nationality</option>
        
        <option value="pakistan">pakistan</option>
       
       
    </select>
  </div>
  
  <div class="col-12" style="text-align: right;">
    <button type="submit" name="submit"  class="btn btn-primary">Save</button>
  </div>
</form>
      </div>
      
    </div>
  </div>
</div>
<!--Add child Passenger Model End-->

                   
 
                            
<form method="post" class="row g-3" action="{{URL::to('add_lead_passengar')}}">
                                 @csrf
                                 

                                 
                                  <div class="col-md-4">
    <label for="inputEmail4" class="form-label">Title</label>
    <select class="form-control" name="lead_title" style="border-radius: unset !important;" required>
        <option value="">Select Title</option>
        <option value="Mr.">Mr.</option>
        <option value="Mrs.">Mrs.</option>
    </select>
  </div>
                              <div class="col-md-4">
                                <label for="inputEmail4" class="form-label">First name</label>
                                <input type="text" class="form-control" id="inputEmail4" required value="{{ $lead_passengar_decode->lead_first_name ?? '' }}"  name="lead_first_name">
                              </div>
                              <div class="col-md-4">
                                <label for="inputPassword4" class="form-label">Last name</label>
                                <input type="text" class="form-control" id="inputPassword4" required value="{{ $lead_passengar_decode->lead_last_name ?? '' }}"  name="lead_last_name">
                              </div>
                              <div class="col-6">
                                <label for="inputAddress" class="form-label">Email</label>
                                <input type="text" class="form-control" id="inputAddress" required value="{{ $lead_passengar_decode->lead_email ?? '' }}"  name="lead_email">
                              </div>
                              <div class="col-6">
                                <label for="inputAddress" class="form-label">Phone</label>
                                <input type="text" class="form-control" required id="country_code" value="{{ $lead_passengar_decode->lead_phone ?? '' }}"  name="lead_phone">
                              </div>
                              
                              
                              <!--<div class="col-md-4">-->
                              <!--  <label for="inputEmail4" class="form-label">Passport No</label>-->
                              <!--  <input type="text" class="form-control" required value="{{ $lead_passengar_decode->lead_passport_no ?? '' }}" name="lead_passport_no">-->
                              <!--</div>-->
                              
                              
<!--                              <div class="col-12">-->
<!--                                <label for="inputAddress2" class="form-label">Address</label>-->
<!--<input type="text" class="form-control" value="{{ $lead_passengar_decode->lead_address ?? '' }}"  required  name="lead_address">-->
<!--                              </div>-->
<div class="col-12">
    <div class="checkout-note">
        <p><i class="fa-regular fa-money-bill-1"></i>  Pay us with in 20 Minutes and confirm your booking, We will be holding your selection for 20 Minutes.</p>

      
    </div>
    
   
    
</div>
<div class="col-12">
    <h5>Let us know what you need</h5>
    <p>Requests are fulfilled on a first come, first served basis. We'll send yours right after you book.</p>
</div>

<p>Do you have a smoking preference?</p>
<div class="col-6">
    
    <div class="form-check">
  <input class="form-check-input" type="radio" name="non_smoking" value="Non Smoking" id="flexRadioDefault1">
  <label class="form-check-label" for="flexRadioDefault1">
     Non-smoking
  </label>
</div>
</div>
<div class="col-6">
<div class="form-check">
  <input class="form-check-input" type="radio" name="non_smoking" value="Smoking" id="flexRadioDefault2" checked>
  <label class="form-check-label" for="flexRadioDefault2">
    smoking
  </label>
</div>
</div>

<p>What bed configuration do you prefer?</p>
<div class="col-6">
  <div class="form-check">
  <input class="form-check-input" type="radio" name="large_bed" value="I'd like a large bed" id="flexRadioDefault3">
  <label class="form-check-label" for="flexRadioDefault3">
   I'd like a large bed
  </label>
</div>

</div>
<div class="col-6">
    <div class="form-check">
  <input class="form-check-input" type="radio" name="large_bed" value="I'd like twin beds" id="flexRadioDefault4" checked>
  <label class="form-check-label" for="flexRadioDefault4">
   I'd like twin beds
  </label>
</div>

</div>




<div class="collapse" id="collapseExamplenote">
           <div class="paragraph" style="border: 1px solid #d4d4d4;padding: 20px;">
             <p class="mb-1"><span class="text-muted">We'll make sure your property or host gets your request quickly.</span></p>
             <div class="row">
            <div class="col-6">
<div class="form-check">
  <input class="form-check-input" type="checkbox" name="high_floor" value="I'd like a room on a high floor." id="flexCheckIndeterminate13">
  <label class="form-check-label" for="flexCheckIndeterminate13">
    I'd like a room on a high floor
  </label>
</div>
</div>
<div class="col-6">
<div class="form-check">
  <input class="form-check-input" type="checkbox" name="baby_cot" value="I’d like to have a baby cot." id="flexCheckIndeterminate14">
  <label class="form-check-label" for="flexCheckIndeterminate14">
  I’d like to have a baby cot<br>
  (additional charges may apply)
  </label>
</div>
</div>
<div class="col-6">
<div class="form-check">
  <input class="form-check-input" type="checkbox" name="quiet_room" value="I’d like a quiet room." id="flexCheckIndeterminate15">
  <label class="form-check-label" for="flexCheckIndeterminate15">
    I’d like a quiet room
  </label>
</div>
</div>
<div class="col-6">
<div class="form-check">
  <input class="form-check-input" type="checkbox" name="airport_transfer" value="I'd like an airport transfer." id="flexCheckIndeterminate16">
  <label class="form-check-label" for="flexCheckIndeterminate16">
  I'd like an airport transfer
  </label>
</div>
</div>
<div class="col-12">
    <label for="inputAddress2" class="form-label">Additional notes:</label>
    
<textarea name="additional_notes" class="form-control"></textarea>
</div>
</div>




          </div>
        </div>
         
      
<div class="col-12">
<a style="color: #123ee5 !important;" class="btn btn-link link-info p-md-1 my-1" data-bs-toggle="collapse" href="#collapseExamplenote" role="button" aria-expanded="false" aria-controls="collapseExamplenote">Click here for more requests</a>
 </div>    



                              

                              <div class="col-12">
                               
                                                           

                                                      <?php
                                                      $adults = 0;
                                                        $children = 0;
                                                     $check_data=Session::get('other_adults');
                                                      $check_data_child=Session::get('other_child');
                                                   
                                                   
                                                
                                                      
                                                
                                                if(session('other_adults'))
                                                    {
                                                       $saveAdults = count(session('other_adults'));
                                                      
                                                        $saveAdults = $saveAdults + 1; 
                                                        // print_r($saveAdults);
                                                        
                                                    }
                                                else
                                                   {
                                                     $saveAdults = 1;  
                                                   }
                                                   
                                                   if(session('other_child'))
                                                    {
                                                       $saveChild = count(session('other_child'));
                                                      
                                                        $saveChild = $saveChild + 1; 
                                                       
                                                        
                                                    }
                                                else
                                                   {
                                                     $saveChild = 1;  
                                                   }
                                                        
                                                   
                                                if(empty($lead_passengar_decode)){
                                                     ?>
                                                    </br>
                                                    <button class="btn" style="background-color:#277019; color:white;float: right;" name="submit" type="submit">Add Lead Passengar</button>
                                                     
                                                     <?php
                                                }else
                                                {
                                                    if($saveAdults < $adult_count && $saveAdults = $adult_count)
                                                    
                                                      {
                                                        //   print_r($saveAdults);
                                                        //             print_r($adult_count);
                                                          
                                                                        
                                                      ?>
                                                      <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_other_passenger" class="btn" style="background-color:#277019; color:white;float: right;">Add other Passengar</a>
                                                                
                                                    <?php
                                                                   
                                                    
                                                      }
                                                     
                                                      else{
                                                          
                                                          
                                                        
                                                                if($saveChild <= $child_count)
                                                                
                                                                {
                                                                    // print_r($saveChild);
                                                                    // print_r($child_count);
                                                                 ?>   
                                                                    
                                                                
                                                            <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_child" class="btn" style="background-color:#277019; color:white;float: right;">Add Child Passengar</a>
                                                            <?php
                                                                }
                                                                else
                                                                {
                                                                //     print_r($saveChild); 
                                                                //   print_r($child_count);
                                                                    ?>
                                                                     <!--<a class="btn" href="{{URL::to('')}}/confrimbooking/{{$search_id}}/{{$slug}}" style="background-color:#277019; color:white;"  >Confirm booking</a> -->
                                                                  
                                                   
                                                                     <a class="btn" href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_booking_popup" style="background-color:#277019; color:white;"  >Submit booking</a> 
                                                                     <?php
                                                                   
                                                                }
                                                          
                                                      }
                                                           ?>
                                                           
                                                           
                                                           
                                                           
                                                    </br>
                                                    <?php
                                                    if($slug == 'travellanda')
                                                    {
                                                        if($saveAdults <= $adult_count_travelanda)
                                                        {
                                                    ?>
                                                    <!--<a href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn" style="background-color:#277019; color:white;float: right;">Add other Passengar</a>-->
                                                    
                                                     
                                                     <?php
                                                     
                                                        }
                                                        else
                                                        {
                                                     ?>
                                                     
                                                     
                                                   <!--<a class="btn" href="{{URL::to('')}}/confrimbooking/{{$optid."$$".$roomid}}/{{$slug}}" style="background-color:#277019; color:white;"  >Confirm booking</a>-->
                                                     
                                                     <?php
                                                     
                                                        }
                                                     ?>
                                                     
                                                     
                                                     
                                                     
                                                     <?php
                                                     
                                                    }
                                                    else
                                                    {
                                                        ?>
                                                        
                                                       <!--<a class="btn" href="{{URL::to('')}}/confrimbooking/{{$search_id}}/{{$slug}}" style="background-color:#277019; color:white;"  >Confirm booking</a> -->
                                                        
                                                    <?php
                                                    }
                                                    ?>
                                                     
                                                     <?php
                                                     
                                                     
                                                }
                                                     ?>
                                                      
                                               
                                                      
                                                      
                                                    
                                                      
                                             
                              </div>
                            </form>
                            @endif
                             
                        </div>
                        
                       
                       <?php
                         if($slug == "travellanda")
                               {
                               
                               ?>     
                       <div class="product-detail__info">
                       <div class="property-highlights">
                                <h3>Property highlights</h3>
                                
                                <?php
                                $Facilities=$res_details->get_res->Facilities ?? '';
                                $Facilities=json_decode($Facilities);
                                
                                ?>
                                
                                <div class="property-highlights__content">
                                    
                                            
                                    
                                         <?php
                                        
                                         if(isset($Facilities->Facility))
                                         {
                                     $conter_loop=1;         
                foreach($Facilities->Facility as $Facility)
                {
                if($Facility->FacilityType == 'Hotel Facilities')
                {
                    if($conter_loop < 4)
                    {
                ?>
                                         
                                    <div class="item">
                                     <i style="color: #17c917f5;" class="awe-icon fa fa-check" aria-hidden="true"></i>
                                        <!--<i class="awe-icon awe-icon-unlock"></i>-->
                                        <span style="font-weight: 700;" >{{$Facility->FacilityName}}</span>
                                    </div>
                                     
                                     <?php
                                     
                }
                $conter_loop=$conter_loop+1;
                }
                
                }
                                         }
                                     ?>
                                     
                                    
                                    
                                </div>
                                <div class="property-highlights__content" style="display:none;" id="show_more_fc">
                                    
                                            
                                    
                                         <?php
                                        
                                         if(isset($Facilities->Facility))
                                         {
                                              
                foreach($Facilities->Facility as $key => $Facility)
                {
                if($Facility->FacilityType == 'Hotel Facilities')
                {
                    if( $key > 5)
                    {
                    
                ?>
                                         
                                    <div class="item">
                                     <i style="color: #17c917f5;" class="awe-icon fa fa-check" aria-hidden="true"></i>
                                        <!--<i class="awe-icon awe-icon-unlock"></i>-->
                                        <span style="font-weight: 700;" >{{$Facility->FacilityName}}</span>
                                    </div>
                                     
                                     <?php
                    }
                                     
                
                }
                
                }
                                         }
                                     ?>
                                     
                                    
                                    
                                </div>
                                 <a id="click_more_fc" style="color: #277019;float:right;font-weight: bolder;" class="" href="javascript:;" >Read More</a>
                            </div>
                            </div>
                            <?php
                            }
                            
                            
                            else if($slug == "tbo")
                            {
                                ?>
                               <div class="col-12">
    <div class="checkout-note">
      

        <p> <i class="fa-solid fa-headset"></i> FREE CUSTOMER SERVICE AVAILABLE FOR 365/24/7</p>
    </div>
    
   
    
</div>
<div class="product-detail__info">
    <?php
        $tboSelectionRS=json_decode($get_data->tboSelectionRS);
        // print_r($tboSelectionRS);
       

       $request_data = array(
    'HotelCode' =>$tboSelectionRS->HotelResult[0]->HotelCode,
   
    );
//   $searchdata=json_encode($searchdata);
  $curl = curl_init();
     curl_setopt_array($curl, array(
     CURLOPT_URL => 'https://admin.synchronousdigital.com/api/get_tbo_hotel_details',
     CURLOPT_RETURNTRANSFER => true,
     CURLOPT_ENCODING => '',
     CURLOPT_MAXREDIRS => 10,
     CURLOPT_TIMEOUT => 0,
     CURLOPT_FOLLOWLOCATION => true,
     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
     CURLOPT_CUSTOMREQUEST => 'POST',
     CURLOPT_POSTFIELDS =>  $request_data,
     CURLOPT_HTTPHEADER => array(
        'Cookie: laravel_session=gnq21xtzzbBtgOgSa0iVWPIX9vSDzHcKrUozAnSL'
     ),
     ));
  
     $response = curl_exec($curl);
     curl_close($curl);
     $tbo_hotel_detail= $response; 
     $tbo_hotel_detail=json_decode($tbo_hotel_detail);
     $tbo_hotel_detail=$tbo_hotel_detail->data;
 
  $hotel_facilities= $tbo_hotel_detail->hotel_facilities;
     $hotel_facilities = json_decode($hotel_facilities);
     $hotel_facilities1= $tbo_hotel_detail->hotel_facilities;
     $hotel_facilities1 = json_decode($hotel_facilities1);
    //  print_r($hotel_facilities);
 
    // print_r($tbo_hotel_detail);die();
        
        ?>
                       
                             <div class="product-detail__info">
                       <div class="property-highlights">
                                <h3>Property highlights</h3>
                                
                                
                                <div class="property-highlights__content">
                                    
                                            
                                    
                                         <?php
                                        
                                         if(isset($hotel_facilities))
                                         {
                                     $conter_loop=1;         
                foreach($hotel_facilities as $hotel_facilities)
                {
                
                    if($conter_loop < 4)
                    {
                ?>
                                         
                                    <div class="item">
                                     <i style="color: #17c917f5;" class="awe-icon fa fa-check" aria-hidden="true"></i>
                                        <!--<i class="awe-icon awe-icon-unlock"></i>-->
                                        <span style="font-weight: 700;" >{{$hotel_facilities}}</span>
                                    </div>
                                     
                                     <?php
                                     
                }
                $conter_loop=$conter_loop+1;
              
                
                }
                                         }
                                     ?>
                                     
                                    
                                    
                                </div>
                                <div class="property-highlights__content" style="display:none;" id="show_more_fc">
                                    
                                            
                                    
                                         <?php
                                        
                                         if(isset($hotel_facilities1))
                                         {
                                              
                foreach($hotel_facilities1 as $key => $hotel_facilities1)
                {
                
                    if( $key > 5)
                    {
                    
                ?>
                                         
                                    <div class="item">
                                     <i style="color: #17c917f5;" class="awe-icon fa fa-check" aria-hidden="true"></i>
                                        <!--<i class="awe-icon awe-icon-unlock"></i>-->
                                        <span style="font-weight: 700;" >{{$hotel_facilities1}}</span>
                                    </div>
                                     
                                     <?php
                    }
                                     
                
               
                
                }
                                         }
                                     ?>
                                     
                                    
                                    
                                </div>
                                 <a id="click_more_fc" style="color: #277019;float:right;font-weight: bolder;" class="" href="javascript:;" >Read More</a>
                            </div>
                            </div>
                            </div>
                                
                                
                                <?php
                                
                            }
         else if($slug == "ratehawke")
                            {
                                ?>
                               <div class="col-12">
    <div class="checkout-note">
      

        <p> <i class="fa-solid fa-headset"></i> FREE CUSTOMER SERVICE AVAILABLE FOR 365/24/7</p>
    </div>
    
   
    
</div>
<div class="product-detail__info">
   
                       
                             <div class="product-detail__info">
                       <div class="property-highlights">
                                <h3>Property highlights ra</h3>
                                <?php
       
                                $ratehawk_details_rs=$get_data->ratehawk_details_rs;
                                $ratehawk_details_rs=json_decode($ratehawk_details_rs);
                                //  print_r($ratehawk_details_rs);
                                $ratehawk_amenity_groups=$ratehawk_details_rs->amenity_groups ?? '';
        
                                ?>
                                
                                                               
                                <div class="property-highlights__content">
                                    
                                            
                                    
                                         <?php
                                        
                                         if(isset($ratehawk_amenity_groups))
                                         {
                                     $conter_loop=1;         
                foreach($ratehawk_amenity_groups as  $ratehawk_amenity_groups)
                {
                
                    if($conter_loop < 4)
                    {
                ?>
                                         
                                    <div class="item">
                                     <i style="color: #17c917f5;" class="awe-icon fa fa-check" aria-hidden="true"></i>
                                        
                                         <span style="font-weight: 700;" >{{$ratehawk_amenity_groups->group_name}}</span>
                                         @foreach($ratehawk_amenity_groups->amenities as $amenities)
                                         <!--<i class="awe-icon awe-icon-unlock"></i>-->
                                        <span style="font-weight: 700;" >{{$amenities ?? ''}}</span>
                                       @endforeach
                                    </div>
                                     
                                     <?php
                                     
                }
                $conter_loop=$conter_loop+1;
              
                
                }
                                         }
                                     ?>
                                     
                                    
                                    
                                </div>
                                    <div class="property-highlights__content" style="display:none;" id="show_more_fc">
                                    
                                            
                                    
                                         <?php
                                        
                                         if(isset($ratehawk_amenity_groups))
                                         {
                                           
                foreach($ratehawk_amenity_groups as $key => $ratehawk_amenity_groups)
                {
                
                    if($key > 5)
                    {
                ?>
                                         
                                    <div class="item">
                                     <i style="color: #17c917f5;" class="awe-icon fa fa-check" aria-hidden="true"></i>
                                        
                                         <span style="font-weight: 700;" >{{$ratehawk_amenity_groups->group_name}}</span>
                                         @foreach($ratehawk_amenity_groups->amenities as $amenities)
                                         <!--<i class="awe-icon awe-icon-unlock"></i>-->
                                        <span style="font-weight: 700;" >{{$amenities ?? ''}}</span>
                                       @endforeach
                                    </div>
                                     
                                     <?php
                                     
                }
                
              
                
                }
                                         }
                                     ?>
                                     
                                    
                                    
                                </div>
                                 <a id="click_more_fc" style="color: #277019;float:right;font-weight: bolder;" class="" href="javascript:;" >Read More</a>
                            </div>
                            </div>
                            </div>
                                
                                
                                <?php
                                
                            }
                            else
                            {
                                
        
                                
                                
                            ?>
                            <div class="col-12">
    <div class="checkout-note">
      

        <p> <i class="fa-solid fa-headset"></i> FREE CUSTOMER SERVICE AVAILABLE FOR 365/24/7</p>
    </div>
    
   
    
</div>
                            <div class="product-detail__info">
                       <div class="property-highlights">
                                <h3>Important Instructions</h3>
                                
        <?php
        $hotelbedSelectionRS=$get_data->hotelbedSelectionRS;
        if(isset($hotelbedSelectionRS))
        {
        $hotelbedSelectionRS=json_decode($hotelbedSelectionRS);
        $hotelbedSelectionRS=$hotelbedSelectionRS->hotel;
        foreach($hotelbedSelectionRS->rooms as $rooms)
        {
            
        ?>
        
        <ul>
            
       
        
       
        
        
        <li class="mb-3" style="text-align: justify;"> <i class="fa-regular fa-circle-check"></i>  {{$rooms->rates[0]->rateComments}}</li>
        
        
        
         </ul>
        <?php
        }
        }
        ?>
                                
                                
                                
                                
                                
          <?php
        //  $hotelbeds_details=$hotelbeds_details->get_res;
        $hotelbeds_facilities=$hotelbeds_details->facilities ?? '';
        // $hotelbeds_facilities=json_decode($hotelbeds_facilities);
        
        $apiKey = '4b11b3c941ea25825a4de05ec398c4ab';
        $secret = 'afe693d5e4';
        $signature = hash("sha256", $apiKey.$secret.time());
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.hotelbeds.com/hotel-content-api/1.0/types/facilities?fields=all&language=ENG&from=1&to=100&useSecondaryLanguage=True',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Api-key: 4b11b3c941ea25825a4de05ec398c4ab',
    "X-Signature: $signature",
    'Accept: application/json',
    'Accept-Encoding: gzip'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
// echo $response;
$response_facilities=json_decode($response);
                                
                                ?>
                                
                  
                            </div>
                            </div>
                            
                            
                            <?php
                            }
                            ?>
                       
                       
                       
                       
                       
                       
                       
                       
                       
                    </div>
                    
                    
       <?php
       
       if($slug == "travellanda")
       {
       
       ?>             
                    
    <div class="col-md-4">
        <?php
        
        $travellandadetailRS=$get_data->travellandadetailRS;
        $travellandadetailRS=json_decode($travellandadetailRS);
        
        $travellandaSelectionRS=$get_data->travellandaSelectionRS;
        $travellandaSelectionRS=json_decode($travellandaSelectionRS);
        $travellandaSelectionRS1=$get_data->travellandaSelectionRS;
         $travellandaRoomDetails=json_decode($travellandaSelectionRS1);
        $travel_BoardType=$travellandaSelectionRS[0]->BoardType ?? '';
        // print_r($travellandaSelectionRS[0]->Rooms->Room);die();
         $travellanda_cancellation_response=$get_data->travellanda_cancellation_response;
        $travellanda_cancellation_response=json_decode($travellanda_cancellation_response);
        
        
        
        
        
        
        $Facilities=$res_details->get_res->Facilities ?? '';
         $Facilities=json_decode($Facilities);
        ?>
        <div class="modal fade" id="hoteltravellanda_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php print_r($res_details->get_res->Latitude ?? ''); ?>,<?php print_r($res_details->get_res->Longitude ?? ''); ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
        <div class="checkout-note">
    <p>  
       <i class="fa-regular fa-calendar-days"></i>    We have limited availability at this price - book now! </p>
    </div>
    <div class="card w-100 mb-4">

                                            <div class="card-body">

                                                <h5>  <svg id="Flat" height="35" viewBox="0 0 512 512" width="35" xmlns="http://www.w3.org/2000/svg"><g><path d="m90 448h-2v-24a24 24 0 0 0 -24-24h-16a24 24 0 0 0 -24 24v64h104v-8l-8-2a30 30 0 0 0 -30-30z" fill="#79d8eb"></path><path d="m422 448h2v-24a24 24 0 0 1 24-24h16a24 24 0 0 1 24 24v64h-104v-8l8-2a30 30 0 0 1 30-30z" fill="#79d8eb"></path><path d="m120 256h272v232h-272z" fill="#fac850" transform="matrix(-1 0 0 -1 512 744)"></path><g><path d="m320 456v-248h-128v248h-72v32h272v-32z" fill="#fa5d3f"></path><path d="m232 424h48v64h-48z" fill="#fac850"></path><g fill="#fff9f8"><path d="m216 320h16v16h-16z"></path><path d="m248 320h16v16h-16z"></path><path d="m280 320h16v16h-16z"></path><path d="m216 352h16v16h-16z"></path><path d="m248 352h16v16h-16z"></path><path d="m280 352h16v16h-16z"></path><path d="m216 384h16v16h-16z"></path><path d="m248 384h16v16h-16z"></path><path d="m280 384h16v16h-16z"></path><path d="m216 256h16v16h-16z"></path><path d="m248 256h16v16h-16z"></path><path d="m280 256h16v16h-16z"></path><path d="m216 288h16v16h-16z"></path><path d="m248 288h16v16h-16z"></path><path d="m280 288h16v16h-16z"></path></g></g><path d="m256.004 24 22.419 45.427 50.132 7.284-36.276 35.36 8.564 49.929-44.839-23.573-44.839 23.573 8.563-49.929-36.275-35.36 50.131-7.284z" fill="#fac850"></path><path d="m386.327 112 15.551 31.511 34.775 5.053-25.163 24.528 5.94 34.635-31.103-16.352-31.104 16.352 5.94-34.635-25.163-24.528 34.775-5.053z" fill="#fac850"></path><path d="m453.486 216 10.666 21.61 23.848 3.466-17.257 16.821 4.074 23.752-21.331-11.214-21.33 11.214 4.074-23.752-17.257-16.821 23.848-3.466z" fill="#fac850"></path><path d="m125.673 112-15.551 31.511-34.775 5.053 25.163 24.528-5.94 34.635 31.103-16.352 31.104 16.352-5.94-34.635 25.163-24.528-34.775-5.053z" fill="#fac850"></path><path d="m58.514 216-10.666 21.61-23.848 3.466 17.257 16.821-4.074 23.752 21.331-11.214 21.33 11.214-4.074-23.752 17.257-16.821-23.848-3.466z" fill="#fac850"></path><g fill="#fffdfa"><path d="m144 288h24v16h-24z"></path><path d="m144 328h24v16h-24z"></path><path d="m144 368h24v16h-24z"></path><path d="m144 408h24v16h-24z"></path><path d="m344 368h24v16h-24z"></path><path d="m344 408h24v16h-24z"></path><path d="m344 288h24v16h-24z"></path><path d="m344 328h24v16h-24z"></path></g><path d="m224 184h64v48h-64z" fill="#fac850"></path></g></svg>&nbsp;Hotel Booking Details</h5>

                                                <div class="detail-group">

                                                   

                                                    

                                                   

                                                    <ul class="list-group hotel_append_div">
                                                        <li class="d-flex justify-content-between"><b>Room Fare:</b></li>
                                                        
         <?php
        
        if($room_search == 1)
        {
        
        
         $markup_add=$CustomHotel=config('All');
            
 $total_price=$travellandaSelectionRS[0]->Rooms->Room->RoomPrice + $markup_add; 
           
       
        }
        else
        {
        
        
        $total_price=0;
        $count=1;
        foreach($travellandaRoomDetails[0]->Rooms->Room as $Room)
            {
            $markup_add=$CustomHotel=config('All');
            $total_price =$markup_add + $Room->RoomPrice + $total_price;
        }
        
        }
        ?>
       
                                                        
      <?php
        
        if($room_search == 1)
        {
        
        ?>
          <li class="d-flex justify-content-between">
              <p style="width: 200px;font-weight: 500;font-size: 13px;">{{$travellandaSelectionRS[0]->Rooms->Room->RoomName}} - <?php print_r($travel_BoardType) ?> Included</p>
              &nbsp;<b class="exchange_price1_1_1" style="display:none" >  {{$total_price}}</b>
          <b class="exchange_rate_country_price_1"><div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div></b>
          </li> 
        <?php
        $count_1=1;
        }
        else
        {
           $count_1=1;
            foreach($travellandaRoomDetails[0]->Rooms->Room as $Room)
            {
          
      
        ?>
        
         <li class="d-flex justify-content-between">
              <p style="width: 200px;font-weight: 500;font-size: 13px;">{{$Room->RoomName}} - <?php print_r($travel_BoardType) ?> Included</p>
              &nbsp;<b class="exchange_price1_1_{{$count_1}}" style="display:none" >{{$Room->RoomPrice}}</b>
          <b class="exchange_rate_country_price_{{$count_1}}"><div class="preloader1" style="display: none;"><img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div></b>
          </li>
        

        <?php
        $count_1=$count_1+1;
            }
        }
        
        ?>
        
        
              
         
<?php
                                                        
        $val=$count_1 +1;
        $val1=$count_1 +2;
       ?>
                                                               
        
<li class="d-flex justify-content-between"><b>Sub Total:</b>&nbsp;<p class="exchange_price1_1_{{$val}}" style="display:none">{{$total_price}}</p><p class="exchange_rate_country_price_{{$val}}"><div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div></p></li>
   <li class="d-flex justify-content-between"><b>Total Price:</b>&nbsp;<p class="exchange_price1_1_{{$val1}}" style="display:none">{{$total_price}}</p><p class="exchange_rate_country_price_{{$val1}}"><div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div></p></li> 
        
        
                                                        <!--<li class="d-flex justify-content-between"><b>Taxes and Fees:</b>&nbsp;<p>0</p></li>-->
                                                        <!-- <li class="d-flex justify-content-between"><b>VAT (15%) on Service Charges:</b>&nbsp;<p>0</p></li>-->
                                                       
                                                        
                                                         <li class="d-flex mt-0 justify-content-end">
                                                                    <div class="mb-2 d-flex  price-vat-tag h-15px">
                                                                        <svg class="mr-2" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="10" height="10" viewBox="0 0 503.151 503.151" style="enable-background:new 0 0 503.151 503.151;" xml:space="preserve">
                                                                            <path style="fill:#4CAF50;" d="M471.172,0H309.337c-8.483,0.022-16.616,3.387-22.635,9.365L9.369,286.699
                                                                            	c-12.492,12.496-12.492,32.752,0,45.248l161.835,161.835c12.496,12.492,32.752,12.492,45.248,0l277.333-277.333
                                                                            	c6.018-5.992,9.39-14.142,9.365-22.635V32C503.151,14.335,488.837,0.012,471.172,0z M385.839,170.667
                                                                            	c-29.455,0-53.333-23.878-53.333-53.333S356.383,64,385.839,64s53.333,23.878,53.333,53.333S415.294,170.667,385.839,170.667z"></path>
                                                                            <g>
                                                                        </g></svg>
                                                                        <small class="f-0-6-r">Inclusive of VAT &amp; Taxes</small>
                                                                    </div>
                                                                </li>


                                                    </ul>

                                                </div>

                                            </div>

                                        </div>
                                        
                                        
                                        
                                        <div class="card">
           <div class="row">
      <div class="col-md-4">
          <?php
         $Images=$res_details->Images ?? '';
        
        //  print_r($Images);
         
         ?>
         <?php
         if(isset($Images->Image))
         {
         ?>
 
   <img src="<?php print_r($Images->Image[0]) ?>" class="card-img-top" alt="...">
 
  <?php
  
  }
  ?>
         
      </div>
      <div class="col-md-8">
          <h6 style="padding-top: 5px;"><?php print_r($travellandadetailRS->HotelName); ?></h6>
          
          
          
          
          <p style="font-size: 11px;font-weight: 700;">
          <?php 
    
    $Location=$res_details->Location ?? '';
   print_r($res_details->Address);
   
 
    ?>
    
    
    
    
    
    
    
    
    
    <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#hoteltravellanda_map"><i class="fa-solid fa-location-dot"></i></a>

          
          </p>
      </div>
      
  </div>
  <?php
                           
                           $startTimeStamp = strtotime($get_data->check_in);                                   
                            $endTimeStamp = strtotime($get_data->check_out);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                        //   print_r($travellandaSelectionRS);die();
                           
                           ?>
                           
                           
                           
                           

 
 <div class="row">
              <div class="col-md-9"> <span style="font-size: 14px;line-height: 22px;font-weight: bolder;margin: 8px 0px;margin-left: 25px;"><i class="far fa-calendar-check mr-1" aria-hidden="true"></i><?php echo  date('M d, Y', strtotime($get_data->check_in))?> &nbsp;&nbsp;<i class="fas fa-sign-out-alt mr-1" aria-hidden="true"></i><?php echo  date('M d, Y', strtotime($get_data->check_out))?>  </span></div>
              <div class="col-md-3">
                  <p style="font-weight: 700;color: #14b314;font-size: 13px;line-height: 22px;"><?php echo $numberDays . 'Nights';  ?></p>
              </div>
          </div>
 
<div class="checkout-note">
    <p>  
      <i class="fa-regular fa-circle-check"></i>  Well done! You're getting this property's lowest price! </p>
    </div>
    
  <div class="card-body" style="border-top: 1px solid #d2d2d2;">
      
   <div class="detail-group">
<ul class="list-group">

<li class="d-flex justify-content-between"><b>Passenger:</b>&nbsp;<p class="text-right"><?php echo $get_data->total_passenger .' Adults, ' .$get_data->child . ' Children ';     ?>  </p></li>

 <li class="d-flex justify-content-between"><b>Rooms:</b>&nbsp;<p><?php echo $get_data->rooms . ' Rooms';     ?> </p></li>
 
 
 
        

<!--<li class="d-flex justify-content-between"><b>Room Capacity:</b>&nbsp;<p>2 Adults, 0 Children </p></li>-->
   
         <div style="border: 1px solid #d2d2d2;padding: 20px;" class="collapse" id="collapseExample1">
            <div class="collapse" id="collapseExample1">
            <h5>Cancellation Policy</h5>
             <p class="mb-1"><span class="text-muted">Cancellation Deadline: {{$travellanda_cancellation_response->Body->CancellationDeadline ?? ''}}</span></p>
              <p class="mb-1"><span class="text-muted">Total Price: {{$travellanda_cancellation_response->Body->Currency ?? ''}} {{$travellanda_cancellation_response->Body->TotalPrice ?? ''}}</span></p>
          <table class="table">
              <thead>
                  <th>From</th>
                   <th>Type</th>
                    <th>Value</th>
              </thead>
              <tbody>
           
                <?php
                foreach($travellanda_cancellation_response->Body->Policies->Policy as $Policy)
                {
                
                ?>
              <tr>
                
                <td>
                  <p class="mb-1"><span class="text-muted">{{$Policy->From}}</span></p>
                </td>
                 <td>
                  <p class="mb-1"><span class="text-muted">{{$Policy->Type}}</span></p>
                </td>
                 <td>
                  <p class="mb-1"><span class="text-muted">{{$travellanda_cancellation_response->Body->Currency ?? ''}} {{$Policy->Value}}</span></p>
                </td>
                
              </tr>
              <?php
               
                }
              
              ?>
            
          </tbody>
        </table>
        </div>
        </div>
            
       
       
        
        


                                                        <li class="d-flex justify-content-between">
                                                            
                                                             <?php
      $current=date('Y-m-d');
     if(isset($travellanda_cancellation_response->Body->CancellationDeadline))
    {
      if($travellanda_cancellation_response->Body->CancellationDeadline < $current)
      {
      
      ?> 

     <a style="color: #14b314;" class="btn btn-link link-info p-md-1 my-1">Non Refundable</a>

      <?php
      
      }
      else
      {
      
      ?>
     <a style="color: #14b314;" class="btn btn-link link-info p-md-1 my-1" data-bs-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample1">Refundable</a>


      <?php
      }
    }
      ?>
                                                            
                                                              

          
                                                            
                                                            
                                                       </li>

                                                    </ul>

                                                </div>   
    

    
    
   
  </div>
</div>
        
        
        
        
     
        
        
        
        
        
   
                </div>
                    
                    
            <?php
       }
       
       else if($slug == 'tbo')
       {
           ?>
           
           
           <div class="col-md-4">
        
        <?php
        $tboSelectionRS=json_decode($get_data->tboSelectionRS);
        // print_r($tboSelectionRS);
       

       $request_data = array(
    'HotelCode' =>$tboSelectionRS->HotelResult[0]->HotelCode,
   
    );
//   $searchdata=json_encode($searchdata);
  $curl = curl_init();
     curl_setopt_array($curl, array(
     CURLOPT_URL => 'https://admin.synchronousdigital.com/api/get_tbo_hotel_details',
     CURLOPT_RETURNTRANSFER => true,
     CURLOPT_ENCODING => '',
     CURLOPT_MAXREDIRS => 10,
     CURLOPT_TIMEOUT => 0,
     CURLOPT_FOLLOWLOCATION => true,
     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
     CURLOPT_CUSTOMREQUEST => 'POST',
     CURLOPT_POSTFIELDS =>  $request_data,
     CURLOPT_HTTPHEADER => array(
        'Cookie: laravel_session=gnq21xtzzbBtgOgSa0iVWPIX9vSDzHcKrUozAnSL'
     ),
     ));
  
     $response = curl_exec($curl);
     curl_close($curl);
     $tbo_hotel_detail= $response; 
     $tbo_hotel_detail=json_decode($tbo_hotel_detail);
     $tbo_hotel_detail=$tbo_hotel_detail->data;
 
  $hotel_facilities= $tbo_hotel_detail->hotel_facilities;
     $hotel_facilities = json_decode($hotel_facilities);
    //  print_r($hotel_facilities);
 
 
     $tbo_hotel_image= $tbo_hotel_detail->images;
     $image= json_decode($tbo_hotel_image);
     $tbo_hotel_attractions= $tbo_hotel_detail->attractions;
     $attractions = json_decode($tbo_hotel_attractions);
     $map=$tbo_hotel_detail->map;
    $map = explode('|', $map);
     
  
     
     
    // print_r($tbo_hotel_detail);die();
        
        ?>
                
<div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php print_r($map[0]); ?>,<?php print_r($map[1]); ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
<div class="checkout-note">
    <p>  
       <i class="fa-regular fa-calendar-days"></i>    We have limited availability at this price - book now! </p>
    </div>
<div class="card w-100 mb-4">

                                            <div class="card-body">

                                                <h5>  <svg id="Flat" height="35" viewBox="0 0 512 512" width="35" xmlns="http://www.w3.org/2000/svg"><g><path d="m90 448h-2v-24a24 24 0 0 0 -24-24h-16a24 24 0 0 0 -24 24v64h104v-8l-8-2a30 30 0 0 0 -30-30z" fill="#79d8eb"></path><path d="m422 448h2v-24a24 24 0 0 1 24-24h16a24 24 0 0 1 24 24v64h-104v-8l8-2a30 30 0 0 1 30-30z" fill="#79d8eb"></path><path d="m120 256h272v232h-272z" fill="#fac850" transform="matrix(-1 0 0 -1 512 744)"></path><g><path d="m320 456v-248h-128v248h-72v32h272v-32z" fill="#fa5d3f"></path><path d="m232 424h48v64h-48z" fill="#fac850"></path><g fill="#fff9f8"><path d="m216 320h16v16h-16z"></path><path d="m248 320h16v16h-16z"></path><path d="m280 320h16v16h-16z"></path><path d="m216 352h16v16h-16z"></path><path d="m248 352h16v16h-16z"></path><path d="m280 352h16v16h-16z"></path><path d="m216 384h16v16h-16z"></path><path d="m248 384h16v16h-16z"></path><path d="m280 384h16v16h-16z"></path><path d="m216 256h16v16h-16z"></path><path d="m248 256h16v16h-16z"></path><path d="m280 256h16v16h-16z"></path><path d="m216 288h16v16h-16z"></path><path d="m248 288h16v16h-16z"></path><path d="m280 288h16v16h-16z"></path></g></g><path d="m256.004 24 22.419 45.427 50.132 7.284-36.276 35.36 8.564 49.929-44.839-23.573-44.839 23.573 8.563-49.929-36.275-35.36 50.131-7.284z" fill="#fac850"></path><path d="m386.327 112 15.551 31.511 34.775 5.053-25.163 24.528 5.94 34.635-31.103-16.352-31.104 16.352 5.94-34.635-25.163-24.528 34.775-5.053z" fill="#fac850"></path><path d="m453.486 216 10.666 21.61 23.848 3.466-17.257 16.821 4.074 23.752-21.331-11.214-21.33 11.214 4.074-23.752-17.257-16.821 23.848-3.466z" fill="#fac850"></path><path d="m125.673 112-15.551 31.511-34.775 5.053 25.163 24.528-5.94 34.635 31.103-16.352 31.104 16.352-5.94-34.635 25.163-24.528-34.775-5.053z" fill="#fac850"></path><path d="m58.514 216-10.666 21.61-23.848 3.466 17.257 16.821-4.074 23.752 21.331-11.214 21.33 11.214-4.074-23.752 17.257-16.821-23.848-3.466z" fill="#fac850"></path><g fill="#fffdfa"><path d="m144 288h24v16h-24z"></path><path d="m144 328h24v16h-24z"></path><path d="m144 368h24v16h-24z"></path><path d="m144 408h24v16h-24z"></path><path d="m344 368h24v16h-24z"></path><path d="m344 408h24v16h-24z"></path><path d="m344 288h24v16h-24z"></path><path d="m344 328h24v16h-24z"></path></g><path d="m224 184h64v48h-64z" fill="#fac850"></path></g></svg>&nbsp;Hotel Booking Details</h5>

                                                <div class="detail-group">

                                                   

                                                    

                                                   

                                                    <ul class="list-group hotel_append_div" >
                                                        <li class="d-flex justify-content-between"><b>Room Fare:</b></li>
                                                        
                                                        <?php
                                                        foreach($tboSelectionRS->HotelResult[0]->Rooms as $Rooms)
                                                        {
                                                        
                                                       
                                                     $price=$Rooms->TotalFare ?? '';
                                                    $currency=$tboSelectionRS->HotelResult[0]->Currency ?? '';
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                    $markup_add=$CustomHotel=config('All');
                                                    $markup_price=$exchange_price + $markup_add;
                                                    ?>
         <li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">{{$Rooms->Name[0]}} - {{$Rooms->MealType}}</p>&nbsp;
         <b class="exchange_price1_1_1" style="display:none;"> {{$markup_price}}</b>
          <b class="exchange_rate_country_price_1"><div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div></b>
         </li> 
                                                               
        <?php
        
                                                        }
        ?>
        <?php
        $grand_TotalFare=0;
       foreach($tboSelectionRS->HotelResult[0]->Rooms as $Rooms)
       {
         $grand_TotalFare=$markup_add + $grand_TotalFare + $Rooms->TotalFare; 
       }
     ?>
      <?php
                                                     $price=$grand_TotalFare ?? '';
                                                    $currency=$tboSelectionRS->HotelResult[0]->Currency ?? '';
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                    ?>
<li class="d-flex justify-content-between"><b>Sub Total:</b>&nbsp;
<p class="exchange_price1_1_2" style="display:none;">{{$exchange_price}}</p>
<p class="exchange_rate_country_price_2"><div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div></p>
</li>
   <li class="d-flex justify-content-between"><b>Total Price:</b>&nbsp;
   <p class="exchange_price1_1_3" style="display:none;">{{$exchange_price}}</p>
   <p class="exchange_rate_country_price_1"><div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div></p>
   </li>
   
        
        
                                                        <!--<li class="d-flex justify-content-between"><b>Taxes and Fees:</b>&nbsp;<p>0</p></li>-->
                                                        <!-- <li class="d-flex justify-content-between"><b>VAT (15%) on Service Charges:</b>&nbsp;<p>0</p></li>-->
                                                       
                                                        
                                                         <li class="d-flex mt-0 justify-content-end">
                                                                    <div class="mb-2 d-flex  price-vat-tag h-15px">
                                                                        <svg class="mr-2" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="10" height="10" viewBox="0 0 503.151 503.151" style="enable-background:new 0 0 503.151 503.151;" xml:space="preserve">
                                                                            <path style="fill:#4CAF50;" d="M471.172,0H309.337c-8.483,0.022-16.616,3.387-22.635,9.365L9.369,286.699
                                                                            	c-12.492,12.496-12.492,32.752,0,45.248l161.835,161.835c12.496,12.492,32.752,12.492,45.248,0l277.333-277.333
                                                                            	c6.018-5.992,9.39-14.142,9.365-22.635V32C503.151,14.335,488.837,0.012,471.172,0z M385.839,170.667
                                                                            	c-29.455,0-53.333-23.878-53.333-53.333S356.383,64,385.839,64s53.333,23.878,53.333,53.333S415.294,170.667,385.839,170.667z"></path>
                                                                            <g>
                                                                        </g></svg>
                                                                        <small class="f-0-6-r">Inclusive of VAT &amp; Taxes</small>
                                                                    </div>
                                                                </li>


                                                    </ul>

                                                </div>

                                            </div>

                                        </div>
                                        <div class="checkout-note">
    <p>  
      <i class="fa-regular fa-circle-check"></i>  Well done! You're getting this property's lowest price! </p>
    </div>
    
    
    
    
    

     <div class="card">
           <div class="row">
      <div class="col-md-4">
          <img src="{{$image[0]}}" class="card-img-top" alt="...">
      </div>
      <div class="col-md-8">
          <h6 style="padding-top: 5px;">{{$tbo_hotel_detail->hotel_name}}</h6>
          <p style="font-size: 11px;font-weight: 700;">{{$tbo_hotel_detail->address}}<a href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map"><i class="fa-solid fa-location-dot"></i></a>

          
          </p>
      </div>
      
  </div>
 
 
 <?php
                           
                           $startTimeStamp = strtotime($get_data->check_in);                                   
                            $endTimeStamp = strtotime($get_data->check_out);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                           
                           
                           ?>

 <div class="row">
              <div class="col-md-9"> <span style="font-size: 14px;line-height: 22px;font-weight: bolder;margin: 8px 0px;margin-left: 25px;"><i class="far fa-calendar-check mr-1" aria-hidden="true"></i> <?php echo  date('d M, Y', strtotime($get_data->check_in));?>&nbsp;&nbsp;<i class="fas fa-sign-out-alt mr-1" aria-hidden="true"></i><?php echo date('d M, Y', strtotime($get_data->check_in)); ?>  </span></div>
              <div class="col-md-3">
                  <p style="font-weight: 700;color: #14b314;font-size: 13px;line-height: 22px;"><?php echo $numberDays . ' Nights';  ?></p>
              </div>
          </div>
 

    
  <div class="card-body" style="border-top: 1px solid #d2d2d2;">
      
   <div class="detail-group">
<ul class="list-group">

<li class="d-flex justify-content-between"><b>Passenger:</b>&nbsp;<p class="text-right"><?php echo $get_data->total_passenger .' Adults, ' .$get_data->child . ' Children ';     ?> </p></li>

 <li class="d-flex justify-content-between"><b>Rooms:</b>&nbsp;<p><?php echo $get_data->rooms . '  Rooms' ?></p></li>
 
 
 <!--<li class="d-flex justify-content-between"><b>Room Fare:</b></li> -->
                  
        <?php
                                                        foreach($tboSelectionRS->HotelResult[0]->Rooms as $Rooms)
                                                        {
                                                        
                                                        ?>
          
         <!--<li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">1 X {{$Rooms->Name[0]}} - {{$Rooms->MealType}}</p>&nbsp;<b> {{$tboSelectionRS->HotelResult[0]->Currency}} {{$Rooms->TotalFare}}</b></li> -->
                                                               
        <?php
        
                                                        }
        ?> 

<!--<li class="d-flex justify-content-between"><b>Room Capacity:</b>&nbsp;<p>2 Adults, 0 Children </p></li>-->
   
         <div style="border: 1px solid #d2d2d2;padding: 20px;" class="collapse" id="collapseExample1">
            <h5>Cancellation Policy</h5>
            
          <table class="table">
              <thead>
                  <tr><th>From Date</th>
                 
                    <!--<th>Charge Type</th>-->
                    <th>Cancellation Charge</th>
              </tr></thead>
              <tbody>
            <?php
                foreach($tboSelectionRS->HotelResult[0]->Rooms as $Rooms)
                    {
                      foreach($Rooms->CancelPolicies as $CancelPolicies) 
                      {
                    ?>
                 <tr>
                
                <td>
                  <p class="mb-1"><span class="text-muted">{{$CancelPolicies->FromDate}}</span></p>
                </td>
                
                <!-- <td>-->
                <!--  <p class="mb-1"><span class="text-muted">{{$CancelPolicies->ChargeType}}</span></p>-->
                <!--</td>-->
                <td>
                  <p class="mb-1"><span class="text-muted"> {{$CancelPolicies->CancellationCharge}} {{$CancelPolicies->ChargeType}}</span></p>
                </td>
                
              </tr>
               <?php
                    }
                 }
        ?> 
                          
          </tbody>
        </table>
        </div>
            
       
       
        
        


                                                        <li class="d-flex justify-content-between">
                                                            
                                                              
               <?php
      $tboSelectionRS=json_decode($get_data->tboSelectionRS);
      $current=date('Y-m-d');
    //   print_r($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies);
       foreach($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies as $CancelPolicies)
      {
         if($CancelPolicies->ChargeType == 'Percentage')
         {
             $from=$CancelPolicies->FromDate;
         
       $from=date('Y-m-d', strtotime($from));
     if(isset($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies))
    {
      if($from > $current)
      {
      ?> 
      
            
          <a style="color: #14b314;" class="btn btn-link link-info p-md-1 my-1" data-bs-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample1">Refundable</a>
      
       
      <?php
      
      }
      else
      {
      
      ?>
      
         <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>      

      <?php
      }
    }
         }
      }
      ?>

          
                                                            
                                                            
                                                       </li>

                                                    </ul>

                                                </div>   
    

    
    
   
  </div>
</div>
        
        
        
        
        
   
                </div>
           
           
           <?php
           
       }
       else if($slug == 'ratehawke')
       {
           ?>
           
           
           <div class="col-md-4">
        
        <?php
        
        
        
         
     
    
   
//     print_r($array_ratehawk);
// die();
        
        
        
        
        $ratehawk_details_rs1=$get_data->ratehawk_details_rs1;
        $ratehawk_details_rs1=json_decode($ratehawk_details_rs1);
        $ratehawk_details_rs=$get_data->ratehawk_details_rs;
        $ratehawk_details_rs=json_decode($ratehawk_details_rs);
        //  print_r($ratehawk_details_rs);
        
        ?>
                
<div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php  ?>,<?php  ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
<div class="checkout-note">
    <p>  
       <i class="fa-regular fa-calendar-days"></i>    We have limited availability at this price - book now! </p>
    </div>
<div class="card w-100 mb-4">

                                            <div class="card-body">

                                                <h5>  <svg id="Flat" height="35" viewBox="0 0 512 512" width="35" xmlns="http://www.w3.org/2000/svg"><g><path d="m90 448h-2v-24a24 24 0 0 0 -24-24h-16a24 24 0 0 0 -24 24v64h104v-8l-8-2a30 30 0 0 0 -30-30z" fill="#79d8eb"></path><path d="m422 448h2v-24a24 24 0 0 1 24-24h16a24 24 0 0 1 24 24v64h-104v-8l8-2a30 30 0 0 1 30-30z" fill="#79d8eb"></path><path d="m120 256h272v232h-272z" fill="#fac850" transform="matrix(-1 0 0 -1 512 744)"></path><g><path d="m320 456v-248h-128v248h-72v32h272v-32z" fill="#fa5d3f"></path><path d="m232 424h48v64h-48z" fill="#fac850"></path><g fill="#fff9f8"><path d="m216 320h16v16h-16z"></path><path d="m248 320h16v16h-16z"></path><path d="m280 320h16v16h-16z"></path><path d="m216 352h16v16h-16z"></path><path d="m248 352h16v16h-16z"></path><path d="m280 352h16v16h-16z"></path><path d="m216 384h16v16h-16z"></path><path d="m248 384h16v16h-16z"></path><path d="m280 384h16v16h-16z"></path><path d="m216 256h16v16h-16z"></path><path d="m248 256h16v16h-16z"></path><path d="m280 256h16v16h-16z"></path><path d="m216 288h16v16h-16z"></path><path d="m248 288h16v16h-16z"></path><path d="m280 288h16v16h-16z"></path></g></g><path d="m256.004 24 22.419 45.427 50.132 7.284-36.276 35.36 8.564 49.929-44.839-23.573-44.839 23.573 8.563-49.929-36.275-35.36 50.131-7.284z" fill="#fac850"></path><path d="m386.327 112 15.551 31.511 34.775 5.053-25.163 24.528 5.94 34.635-31.103-16.352-31.104 16.352 5.94-34.635-25.163-24.528 34.775-5.053z" fill="#fac850"></path><path d="m453.486 216 10.666 21.61 23.848 3.466-17.257 16.821 4.074 23.752-21.331-11.214-21.33 11.214 4.074-23.752-17.257-16.821 23.848-3.466z" fill="#fac850"></path><path d="m125.673 112-15.551 31.511-34.775 5.053 25.163 24.528-5.94 34.635 31.103-16.352 31.104 16.352-5.94-34.635 25.163-24.528-34.775-5.053z" fill="#fac850"></path><path d="m58.514 216-10.666 21.61-23.848 3.466 17.257 16.821-4.074 23.752 21.331-11.214 21.33 11.214-4.074-23.752 17.257-16.821-23.848-3.466z" fill="#fac850"></path><g fill="#fffdfa"><path d="m144 288h24v16h-24z"></path><path d="m144 328h24v16h-24z"></path><path d="m144 368h24v16h-24z"></path><path d="m144 408h24v16h-24z"></path><path d="m344 368h24v16h-24z"></path><path d="m344 408h24v16h-24z"></path><path d="m344 288h24v16h-24z"></path><path d="m344 328h24v16h-24z"></path></g><path d="m224 184h64v48h-64z" fill="#fac850"></path></g></svg>&nbsp;Hotel Booking Details</h5>

                                                <div class="detail-group">

                                                   

                                                    

                                                   

                                                    <ul class="list-group hotel_append_div">
                                                        
                                                        <li class="d-flex justify-content-between"><b>Room Fare:</b></li>
                                                        
                                         <?php
                                         
                                         foreach($array_ratehawk as $rates)
                                         {
                                             
                                              $markup_add=$CustomHotel=config('All');
                                             $markup_price=$rates->payment_options->payment_types[0]->amount + $markup_add;
                                            
                                         ?>              
          
         <li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">1 x {{$rates->room_name}} - {{$rates->meal}}</p>&nbsp;
         <b class="exchange_price1_1_1" style="display:none;">{{$markup_price}} </b>
         <b class="exchange_rate_country_price_1"> <div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div></b>
         </li> 
                                                               
         <?php
       }
        ?>
        
        
        <?php
        $grand_total=0;
        foreach($array_ratehawk as $rates)
        {
            $grand_total=$markup_add + $grand_total + $rates->payment_options->payment_types[0]->amount;
        }
        
        ?>
        
        
<li class="d-flex justify-content-between"><b>Sub Total:</b>&nbsp;
<p class="exchange_price1_1_2" style="display:none;"> {{$grand_total}}</p>
<p class="exchange_rate_country_price_1"><div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div></p>
</li>
   <li class="d-flex justify-content-between"><b>Total Price:</b>&nbsp;
   <p class="exchange_price1_1_3" style="display:none;"> {{$grand_total}}</p>
   <p class="exchange_rate_country_price_1"><div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div> </p>
   </li>
  
       
        
                                                        <!--<li class="d-flex justify-content-between"><b>Taxes and Fees:</b>&nbsp;<p>0</p></li>-->
                                                        <!-- <li class="d-flex justify-content-between"><b>VAT (15%) on Service Charges:</b>&nbsp;<p>0</p></li>-->
                                                       
                                                        
                                                         <li class="d-flex mt-0 justify-content-end">
                                                                    <div class="mb-2 d-flex  price-vat-tag h-15px">
                                                                        <svg class="mr-2" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="10" height="10" viewBox="0 0 503.151 503.151" style="enable-background:new 0 0 503.151 503.151;" xml:space="preserve">
                                                                            <path style="fill:#4CAF50;" d="M471.172,0H309.337c-8.483,0.022-16.616,3.387-22.635,9.365L9.369,286.699
                                                                            	c-12.492,12.496-12.492,32.752,0,45.248l161.835,161.835c12.496,12.492,32.752,12.492,45.248,0l277.333-277.333
                                                                            	c6.018-5.992,9.39-14.142,9.365-22.635V32C503.151,14.335,488.837,0.012,471.172,0z M385.839,170.667
                                                                            	c-29.455,0-53.333-23.878-53.333-53.333S356.383,64,385.839,64s53.333,23.878,53.333,53.333S415.294,170.667,385.839,170.667z"></path>
                                                                            <g>
                                                                        </g></svg>
                                                                        <small class="f-0-6-r">Inclusive of VAT &amp; Taxes</small>
                                                                    </div>
                                                                </li>


                                                    </ul>

                                                </div>

                                            </div>

                                        </div>
                                        <div class="checkout-note">
    <p>  
      <i class="fa-regular fa-circle-check"></i>  Well done! You're getting this property's lowest price! </p>
    </div>
    
    
    
    
    

     <div class="card">
           <div class="row">
      <div class="col-md-4">
          <?php
                                            
$image=$ratehawk_details_rs->images[0];
$image = explode('{size}', $image);
$img=$image[0]. '1024x768'.$image[1];
?>
          <img src="{{$img}}" class="card-img-top" alt="...">
      </div>
      <div class="col-md-8">
          <h6 style="padding-top: 5px;">{{$ratehawk_details_rs->name}}</h6>
          <p style="font-size: 11px;font-weight: 700;">{{$ratehawk_details_rs->address}}<a href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map"><i class="fa-solid fa-location-dot"></i></a>

          
          </p>
      </div>
      
  </div>
 
 
 <?php
                           
                           $startTimeStamp = strtotime($get_data->check_in);                                   
                            $endTimeStamp = strtotime($get_data->check_out);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                           
                           
                           ?>

 <div class="row">
              <div class="col-md-9"> <span style="font-size: 14px;line-height: 22px;font-weight: bolder;margin: 8px 0px;margin-left: 25px;"><i class="far fa-calendar-check mr-1" aria-hidden="true"></i> <?php echo  date('d M, Y', strtotime($get_data->check_in));?>&nbsp;&nbsp;<i class="fas fa-sign-out-alt mr-1" aria-hidden="true"></i><?php echo date('d M, Y', strtotime($get_data->check_in)); ?>  </span></div>
              <div class="col-md-3">
                  <p style="font-weight: 700;color: #14b314;font-size: 13px;line-height: 22px;"><?php echo $numberDays . ' Nights';  ?></p>
              </div>
          </div>
 

    
  <div class="card-body" style="border-top: 1px solid #d2d2d2;">
      
   <div class="detail-group">
<ul class="list-group">

<li class="d-flex justify-content-between"><b>Passenger:</b>&nbsp;<p class="text-right"><?php echo $get_data->total_passenger .' Adults, ' .$get_data->child . ' Children ';     ?> </p></li>

 <li class="d-flex justify-content-between"><b>Rooms:</b>&nbsp;<p><?php echo $get_data->rooms . '  Rooms' ?></p></li>
 
 
 <!--<li class="d-flex justify-content-between"><b>Room Fare:</b></li> -->
                  
       
          
      <?php
                                         
                                         foreach($array_ratehawk as $rates)
                                         {
                                         ?>              
          
         <!--<li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">1 x {{$rates->room_name}} - {{$rates->meal}}</p>&nbsp;<b>{{$rates->payment_options->payment_types[0]->currency_code}} {{$rates->payment_options->payment_types[0]->amount}} </b></li> -->
                                                               
         <?php
       }
        ?>
        
        
        
       

<!--<li class="d-flex justify-content-between"><b>Room Capacity:</b>&nbsp;<p>2 Adults, 0 Children </p></li>-->
   
         <div style="border: 1px solid #d2d2d2;padding: 20px;" class="collapse" id="collapseExample1">
            <h5>Cancellation Policy</h5>
            
          <table class="table">
              <thead>
                  <tr>
                      <th>Start At</th>
                 
                    <th>End At</th>
                    <th>Amount Charge</th>
              </tr>
              </thead>
              
              
              <tbody>
            <?php
                                         
            foreach($array_ratehawk as $rates)
               {
                   foreach($rates->payment_options->payment_types[0]->cancellation_penalties->policies as $policies)
                   {
             ?>    
                 <tr>
                
                <td>
                  <p class="mb-1"><span class="text-muted">{{$policies->start_at ?? ''}}</span></p>
                </td>
                
                 <td>
                  <p class="mb-1"><span class="text-muted">{{$policies->end_at ?? ''}}</span></p>
                </td>
                <td>
                  <p class="mb-1"><span class="text-muted"> {{$policies->amount_charge ?? ''}}</span></p>
                </td>
                
              </tr>
        <?php
                   }
       }
        ?>
                          
          </tbody>
        </table>
        </div>
            
       
       
        
        


<li class="d-flex justify-content-between">
                                                            
   <?php
      $current=date('Y-m-d');
       $from=date('Y-m-d', strtotime($array_ratehawk[0]->payment_options->payment_types[0]->cancellation_penalties->policies[0]->end_at));
     if(isset($array_ratehawk[0]->payment_options->payment_types[0]->cancellation_penalties))
    {
      if($from < $current)
      {
      
      ?>                                          
               
         
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        
        <?php
        
        
      }
      else
      {
       
      ?>    
       
       
       
       <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1" data-bs-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample1">Refundable</a>
       
       
      <?php    
          
      }
      
  
    }
        ?>
       
      

          
                                                            
                                                            
                                                       </li>

                                                    </ul>

                                                </div>   
    

    
    
   
  </div>
</div>
        
        
        
        
        
   
                </div>
           
           
           <?php
           
       }
       
        else if($slug == 'hotels')
       {
           ?>
           
           
           <div class="col-md-4">
        
        <?php
        
        
        
         
     
    

        
        ?>
                
<div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php  ?>,<?php  ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
<div class="checkout-note">
    <p>  
       <i class="fa-regular fa-calendar-days"></i>    We have limited availability at this price - book now! </p>
    </div>
<div class="card w-100 mb-4">

                                            <div class="card-body">

                                                <h5>  <svg id="Flat" height="35" viewBox="0 0 512 512" width="35" xmlns="http://www.w3.org/2000/svg"><g><path d="m90 448h-2v-24a24 24 0 0 0 -24-24h-16a24 24 0 0 0 -24 24v64h104v-8l-8-2a30 30 0 0 0 -30-30z" fill="#79d8eb"></path><path d="m422 448h2v-24a24 24 0 0 1 24-24h16a24 24 0 0 1 24 24v64h-104v-8l8-2a30 30 0 0 1 30-30z" fill="#79d8eb"></path><path d="m120 256h272v232h-272z" fill="#fac850" transform="matrix(-1 0 0 -1 512 744)"></path><g><path d="m320 456v-248h-128v248h-72v32h272v-32z" fill="#fa5d3f"></path><path d="m232 424h48v64h-48z" fill="#fac850"></path><g fill="#fff9f8"><path d="m216 320h16v16h-16z"></path><path d="m248 320h16v16h-16z"></path><path d="m280 320h16v16h-16z"></path><path d="m216 352h16v16h-16z"></path><path d="m248 352h16v16h-16z"></path><path d="m280 352h16v16h-16z"></path><path d="m216 384h16v16h-16z"></path><path d="m248 384h16v16h-16z"></path><path d="m280 384h16v16h-16z"></path><path d="m216 256h16v16h-16z"></path><path d="m248 256h16v16h-16z"></path><path d="m280 256h16v16h-16z"></path><path d="m216 288h16v16h-16z"></path><path d="m248 288h16v16h-16z"></path><path d="m280 288h16v16h-16z"></path></g></g><path d="m256.004 24 22.419 45.427 50.132 7.284-36.276 35.36 8.564 49.929-44.839-23.573-44.839 23.573 8.563-49.929-36.275-35.36 50.131-7.284z" fill="#fac850"></path><path d="m386.327 112 15.551 31.511 34.775 5.053-25.163 24.528 5.94 34.635-31.103-16.352-31.104 16.352 5.94-34.635-25.163-24.528 34.775-5.053z" fill="#fac850"></path><path d="m453.486 216 10.666 21.61 23.848 3.466-17.257 16.821 4.074 23.752-21.331-11.214-21.33 11.214 4.074-23.752-17.257-16.821 23.848-3.466z" fill="#fac850"></path><path d="m125.673 112-15.551 31.511-34.775 5.053 25.163 24.528-5.94 34.635 31.103-16.352 31.104 16.352-5.94-34.635 25.163-24.528-34.775-5.053z" fill="#fac850"></path><path d="m58.514 216-10.666 21.61-23.848 3.466 17.257 16.821-4.074 23.752 21.331-11.214 21.33 11.214-4.074-23.752 17.257-16.821-23.848-3.466z" fill="#fac850"></path><g fill="#fffdfa"><path d="m144 288h24v16h-24z"></path><path d="m144 328h24v16h-24z"></path><path d="m144 368h24v16h-24z"></path><path d="m144 408h24v16h-24z"></path><path d="m344 368h24v16h-24z"></path><path d="m344 408h24v16h-24z"></path><path d="m344 288h24v16h-24z"></path><path d="m344 328h24v16h-24z"></path></g><path d="m224 184h64v48h-64z" fill="#fac850"></path></g></svg>&nbsp;Hotel Booking Details</h5>

                                                <div class="detail-group">

                                                   

                                                    

                                                   

                                                    <ul class="list-group hotel_append_div">
                                                        
                                                        <li class="d-flex justify-content-between"><b>Room Fare:</b></li>
                                                        
                                         <?php
                                         if(isset($rooms_checkavailability))
                                         {
                                             $count=1;
                                             foreach($rooms_checkavailability as $rooms_check)
                                             {
                                             if($rooms_check->grand_total_price_week_weekend != 0.00)
                                             {
                                         
                                         ?>
                                         
                                          <li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">{{$rooms_check->rooms_name ?? ''}} - {{$rooms_check->rooms_meal_type ?? ''}}</p>&nbsp;
                                          <b class="exchange_price1_1_{{$count}}" style="display:none;">{{$rooms_check->grand_total_price_week_weekend ?? ''}} </b>
                                          <b class="exchange_rate_country_price_{{$count}}"><div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div> </b>
                                          </li> 
                                         
                                         <?php
                                             }
                                             else
                                             {
                                         ?>
                                         
                                         <li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">{{$rooms_check->rooms_name ?? ''}} - {{$rooms_check->rooms_meal_type ?? ''}}</p>&nbsp;
                                         <b class="exchange_price1_1_{{$count}}" style="display:none;">{{$rooms_check->grand_total_price_all_days ?? '0'}} </b>
                                          <b class="exchange_rate_country_price_{{$count}}"> <div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div></b>
                                         
                                         </li>  
                                         
                                         <?php
                                             }
                                         ?>
          
                

                                                               
         <?php
         $count=$count+1;
                                             }
                                         }
        ?>
        
        
        <?php
         $grand_total=0;
         $counts=$count+1;
          $counts1=$count+2;
          if(isset($rooms_checkavailability))
           {
        foreach($rooms_checkavailability as $rooms_check)
        {
            if($rooms_check->grand_total_price_week_weekend != NULL)
            {
                 $grand_total=$grand_total + $rooms_check->grand_total_price_week_weekend ?? 0;
            }
            if($rooms_check->grand_total_price_all_days != NULL)
            {
             $grand_total=$grand_total + $rooms_check->grand_total_price_all_days ?? 0;   
            }
           
        }
        
        }
        
        ?>
        
        
<li class="d-flex justify-content-between"><b>Sub Total:</b>&nbsp;
<b class="exchange_price1_1_{{$counts}}" style="display:none;">{{$grand_total}} </b>
                                          <b class="exchange_rate_country_price_{{$counts}}"><div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div> </b>
</li>
   <li class="d-flex justify-content-between"><b>Total Price:</b>&nbsp;
<b class="exchange_price1_1_{{$counts1}}" style="display:none;">{{$grand_total ?? ''}} </b>
                                          <b class="exchange_rate_country_price_{{$counts1}}"><div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div> </b>
   </li>
  
       
        
                                                        <!--<li class="d-flex justify-content-between"><b>Taxes and Fees:</b>&nbsp;<p>0</p></li>-->
                                                        <!-- <li class="d-flex justify-content-between"><b>VAT (15%) on Service Charges:</b>&nbsp;<p>0</p></li>-->
                                                       
                                                        
                                                         <li class="d-flex mt-0 justify-content-end">
                                                                    <div class="mb-2 d-flex  price-vat-tag h-15px">
                                                                        <svg class="mr-2" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="10" height="10" viewBox="0 0 503.151 503.151" style="enable-background:new 0 0 503.151 503.151;" xml:space="preserve">
                                                                            <path style="fill:#4CAF50;" d="M471.172,0H309.337c-8.483,0.022-16.616,3.387-22.635,9.365L9.369,286.699
                                                                            	c-12.492,12.496-12.492,32.752,0,45.248l161.835,161.835c12.496,12.492,32.752,12.492,45.248,0l277.333-277.333
                                                                            	c6.018-5.992,9.39-14.142,9.365-22.635V32C503.151,14.335,488.837,0.012,471.172,0z M385.839,170.667
                                                                            	c-29.455,0-53.333-23.878-53.333-53.333S356.383,64,385.839,64s53.333,23.878,53.333,53.333S415.294,170.667,385.839,170.667z"></path>
                                                                            <g>
                                                                        </g></svg>
                                                                        <small class="f-0-6-r">Inclusive of VAT &amp; Taxes</small>
                                                                    </div>
                                                                </li>


                                                    </ul>

                                                </div>

                                            </div>

                                        </div>
                                        <div class="checkout-note">
    <p>  
      <i class="fa-regular fa-circle-check"></i>  Well done! You're getting this property's lowest price! </p>
    </div>
    
    
    
    
    

     <div class="card">
           <div class="row">
      <div class="col-md-4">
          <?php
                                            

?>
          <img src="https://alhijaztours.net/public/uploads/package_imgs/{{$hotels_checkavailability->property_img ?? ''}}" class="card-img-top" alt="...">
      </div>
      <div class="col-md-8">
          <h6 style="padding-top: 5px;">{{$hotels_checkavailability->property_name ?? ''}}</h6>
          <p style="font-size: 11px;font-weight: 700;">{{$hotels_checkavailability->property_address ?? ''}}<a href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map"><i class="fa-solid fa-location-dot"></i></a>

          
          </p>
      </div>
      
  </div>
 
 
 <?php
                           
                           $startTimeStamp = strtotime($get_data->check_in);                                   
                            $endTimeStamp = strtotime($get_data->check_out);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                           
                           
                           ?>

 <div class="row">
              <div class="col-md-9"> <span style="font-size: 14px;line-height: 22px;font-weight: bolder;margin: 8px 0px;margin-left: 25px;"><i class="far fa-calendar-check mr-1" aria-hidden="true"></i> <?php echo  date('d M, Y', strtotime($get_data->check_in));?>&nbsp;&nbsp;<i class="fas fa-sign-out-alt mr-1" aria-hidden="true"></i><?php echo date('d M, Y', strtotime($get_data->check_out)); ?>  </span></div>
              <div class="col-md-3">
                  <p style="font-weight: 700;color: #14b314;font-size: 13px;line-height: 22px;"><?php echo $numberDays . ' Nights';  ?></p>
              </div>
          </div>
 

    
  <div class="card-body" style="border-top: 1px solid #d2d2d2;">
      
   <div class="detail-group">
<ul class="list-group">

<li class="d-flex justify-content-between"><b>Passenger:</b>&nbsp;<p class="text-right"><?php echo $get_data->total_passenger .' Adults, ' .$get_data->child . ' Children ';     ?> </p></li>

 <li class="d-flex justify-content-between"><b>Rooms:</b>&nbsp;<p><?php echo $get_data->rooms . '  Rooms' ?></p></li>
 
 
 <!--<li class="d-flex justify-content-between"><b>Room Fare:</b></li> -->
                  
 
          
     <?php
                                         if(isset($rooms_checkavailability))
                                         {
                                             foreach($rooms_checkavailability as $rooms_check)
                                             {
                                             
                                         
                                      if($rooms_check->grand_total_price_week_weekend != NULL)
                                             {          
          
                  
                                         
                                         ?>
                                          <!--<li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">{{$rooms_check->rooms_name ?? ''}} - {{$rooms_check->rooms_meal_type ?? ''}}</p>&nbsp;<b>{{$rooms_check->currency ?? ''}} {{$rooms_check->grand_total_price_week_weekend ?? ''}} </b></li> -->
                                         
                                         <?php
                                             }
                                             else
                                             {
                                         ?>
                                         <!--<li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">{{$rooms_check->rooms_name ?? ''}} - {{$rooms_check->rooms_meal_type ?? ''}}</p>&nbsp;<b>{{$rooms_check->currency ?? ''}} {{$rooms_check->grand_total_price_all_days ?? ''}} </b></li>  -->
                                         
                                         <?php
                                             }
                                         ?>

                                                               
       
<a style="color: #14b314;" class="btn btn-link link-info p-md-1 my-1" data-bs-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample1">Cancellation Policy</a>   
        
        
       

<!--<li class="d-flex justify-content-between"><b>Room Capacity:</b>&nbsp;<p>2 Adults, 0 Children </p></li>-->
   
         <div style="border: 1px solid #d2d2d2;padding: 20px;" class="collapse" id="collapseExample1">
            <h5>Cancellation Policy</h5>
            
          <table class="table">
              <thead>
                  <tr>
                      <th>cancellation_policy</th>
                 
                    <th>guests_pay_days</th>
                    <th>guests_pay</th>
                     <th>prepaymentpolicy</th>
              </tr>
              </thead>
              
              
              <tbody>
            

<?php
if(isset($rooms_check->cancellation_policy))
{
            
             ?>    
                 <tr>
                
                <td>
                  <p class="mb-1"><span class="text-muted">{{$rooms_check->cancellation_policy->concellation_policy ?? ''}}</span></p>
                </td>
                
                 <td>
                  <p class="mb-1"><span class="text-muted">{{$rooms_check->cancellation_policy->guests_pay_days ?? ''}}</span></p>
                </td>
                <td>
                  <p class="mb-1"><span class="text-muted"> {{$rooms_check->cancellation_policy->guests_pay ?? ''}}</span></p>
                </td>
                <td>
                  <p class="mb-1"><span class="text-muted"> {{$rooms_check->cancellation_policy->prepaymentpolicy ?? ''}}</span></p>
                </td>
                
              </tr>
          <?php
}
                                             }
                                         }
        ?>
                          
          </tbody>
        </table>
        </div>
            
       
       
        
        




                                                    </ul>

                                                </div>   
    

    
    
   
  </div>
</div>
        
        
        
        
        
   
                </div>
           
           
           <?php
           
       }
       
       else
       {
            ?>
            
            
            <div class="col-md-4">
        
        
        <?php
        
        $hotelbedSelectionRS=$get_data->hotelbedSelectionRS;
        if(isset($hotelbedSelectionRS))
        {
        $hotelbedSelectionRS=json_decode($hotelbedSelectionRS);
        $hotelbedSelectionRS=$hotelbedSelectionRS->hotel;
       
       
        $hotelbeds_images=$hotelbeds_details->images ?? '';
        // $hotelbeds_images=json_decode($hotelbeds_images);
        
        
        $apiKey = '4b11b3c941ea25825a4de05ec398c4ab';
        $secret = 'afe693d5e4';
    
        $signature = hash("sha256", $apiKey.$secret.time());                                            
            
     $curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.hotelbeds.com/hotel-content-api/1.0/hotels/'.$hotelbedSelectionRS->code.'/details?language=ENG&useSecondaryLanguage=False',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Api-key: 4b11b3c941ea25825a4de05ec398c4ab',
    "X-Signature: $signature",
    'Accept: application/json',
    'Accept-Encoding: gzip'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
$data1 = json_decode($response);
   
        $ho_beds_details = $data1->hotel;
        // dd($travel_content);
//          $data_code = array(
//                 'code'=>$hotelbedSelectionRS->code,
//                 );
                
               
//                  $curl = curl_init();
        
//             $endpoint_url = config('endpoint_project');
//             curl_setopt_array($curl, array(
//      CURLOPT_URL => $endpoint_url.'/api/get_hotel_details_by_hotelbeds',
//      CURLOPT_RETURNTRANSFER => true,
//      CURLOPT_ENCODING => '',
//      CURLOPT_MAXREDIRS => 10,
//      CURLOPT_TIMEOUT => 0,
//      CURLOPT_FOLLOWLOCATION => true,
//      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//      CURLOPT_CUSTOMREQUEST => 'POST',
//      CURLOPT_POSTFIELDS =>  $data_code,
//      CURLOPT_HTTPHEADER => array(
//         'Cookie: laravel_session=gnq21xtzzbBtgOgSa0iVWPIX9vSDzHcKrUozAnSL'
//      ),
//      ));
  
//      $response = curl_exec($curl);
// // echo $response;
   
//      curl_close($curl);
//      $ho_beds_details=json_decode($response);
//      $ho_beds_details=$ho_beds_details->get_res ?? '';
        
        // print_r($ho_beds_details->address);
        
        
        } 
        
        
        ?>
        
<div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php print_r($hotelbedSelectionRS->latitude ?? ''); ?>,<?php print_r($hotelbedSelectionRS->longitude ?? ''); ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
<div class="checkout-note">
    <p>  
       <i class="fa-regular fa-calendar-days"></i>    We have limited availability at this price - book now! </p>
    </div>
<div class="card w-100 mb-4">

                                            <div class="card-body">

                                                <h5>  <svg id="Flat" height="35" viewBox="0 0 512 512" width="35" xmlns="http://www.w3.org/2000/svg"><g><path d="m90 448h-2v-24a24 24 0 0 0 -24-24h-16a24 24 0 0 0 -24 24v64h104v-8l-8-2a30 30 0 0 0 -30-30z" fill="#79d8eb"></path><path d="m422 448h2v-24a24 24 0 0 1 24-24h16a24 24 0 0 1 24 24v64h-104v-8l8-2a30 30 0 0 1 30-30z" fill="#79d8eb"></path><path d="m120 256h272v232h-272z" fill="#fac850" transform="matrix(-1 0 0 -1 512 744)"></path><g><path d="m320 456v-248h-128v248h-72v32h272v-32z" fill="#fa5d3f"></path><path d="m232 424h48v64h-48z" fill="#fac850"></path><g fill="#fff9f8"><path d="m216 320h16v16h-16z"></path><path d="m248 320h16v16h-16z"></path><path d="m280 320h16v16h-16z"></path><path d="m216 352h16v16h-16z"></path><path d="m248 352h16v16h-16z"></path><path d="m280 352h16v16h-16z"></path><path d="m216 384h16v16h-16z"></path><path d="m248 384h16v16h-16z"></path><path d="m280 384h16v16h-16z"></path><path d="m216 256h16v16h-16z"></path><path d="m248 256h16v16h-16z"></path><path d="m280 256h16v16h-16z"></path><path d="m216 288h16v16h-16z"></path><path d="m248 288h16v16h-16z"></path><path d="m280 288h16v16h-16z"></path></g></g><path d="m256.004 24 22.419 45.427 50.132 7.284-36.276 35.36 8.564 49.929-44.839-23.573-44.839 23.573 8.563-49.929-36.275-35.36 50.131-7.284z" fill="#fac850"></path><path d="m386.327 112 15.551 31.511 34.775 5.053-25.163 24.528 5.94 34.635-31.103-16.352-31.104 16.352 5.94-34.635-25.163-24.528 34.775-5.053z" fill="#fac850"></path><path d="m453.486 216 10.666 21.61 23.848 3.466-17.257 16.821 4.074 23.752-21.331-11.214-21.33 11.214 4.074-23.752-17.257-16.821 23.848-3.466z" fill="#fac850"></path><path d="m125.673 112-15.551 31.511-34.775 5.053 25.163 24.528-5.94 34.635 31.103-16.352 31.104 16.352-5.94-34.635 25.163-24.528-34.775-5.053z" fill="#fac850"></path><path d="m58.514 216-10.666 21.61-23.848 3.466 17.257 16.821-4.074 23.752 21.331-11.214 21.33 11.214-4.074-23.752 17.257-16.821-23.848-3.466z" fill="#fac850"></path><g fill="#fffdfa"><path d="m144 288h24v16h-24z"></path><path d="m144 328h24v16h-24z"></path><path d="m144 368h24v16h-24z"></path><path d="m144 408h24v16h-24z"></path><path d="m344 368h24v16h-24z"></path><path d="m344 408h24v16h-24z"></path><path d="m344 288h24v16h-24z"></path><path d="m344 328h24v16h-24z"></path></g><path d="m224 184h64v48h-64z" fill="#fac850"></path></g></svg>&nbsp;Hotel Booking Details</h5>

                                                <div class="detail-group">

                                                   

                                                    

                                                   

                                                    <ul class="list-group hotel_append_div">
                                                        <li class="d-flex justify-content-between"><b>Room Fare:</b></li>
<?php
        
        foreach($hotelbedSelectionRS->rooms as $rooms)
        {
        foreach($rooms->rates as $rates)
        {
            
        ?>
          <?php
          $price=$rates->net;
           $currency=$hotelbedSelectionRS->currency ?? '';
          $exchange_price=all_currency_manage($currency,$price);
          $markup_add=$CustomHotel=config('All');
          $markup_price=$exchange_price+$markup_add;
          ?>
         <li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">{{$rates->rooms}} X {{$rooms->name}} - {{$rates->boardName}}</p>&nbsp;
                                              
         <b style="font-size: 19px;color:#d2b254; display:none;" class="exchange_price1_1_1">{{$markup_price}}</b>
          <b style="font-size: 19px;color:#d2b254;" class="exchange_rate_country_price_1"><div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div></b>
         </li> 
          <?php
                                                        
        }
        }
     ?>
<?php
        $total=0;
        foreach($hotelbedSelectionRS->rooms as $rooms)
        {
            
        foreach($rooms->rates as $rates)
        {
          $total=$total + $rates->net + $markup_add;  
        ?>
                                                     
<?php
                                                        
        }
        
        
        ?>
         <?php
          $price=$total;
           $currency=$hotelbedSelectionRS->currency ?? '';
          $exchange_price=all_currency_manage($currency,$price);
          ?>
<li class="d-flex justify-content-between"><b>Sub Total:</b>&nbsp;
<p style="font-size: 19px;color:#d2b254; display:none;" class="exchange_price1_1_2">{{$exchange_price}} </p>
<p class="exchange_rate_country_price_2"><div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div> </p>
</li>
   <li class="d-flex justify-content-between"><b>Total Price:</b>&nbsp;
   <p style="font-size: 19px;color:#d2b254; display:none;" class="exchange_price1_1_3">{{$exchange_price}} </p>
<p class="exchange_rate_country_price_3"> <div class="preloader1" style="display: none;">     <img style="width: 400px;margin-left: 35%;margin-top: 11%;"  src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""> </div></p>
   </li> 
        
        <?php
        
        
        
        
        
        }
     ?>

                                                        <!--<li class="d-flex justify-content-between"><b>Taxes and Fees:</b>&nbsp;<p>0</p></li>-->
                                                        <!-- <li class="d-flex justify-content-between"><b>VAT (15%) on Service Charges:</b>&nbsp;<p>0</p></li>-->
                                                       
                                                        
                                                         <li class="d-flex mt-0 justify-content-end">
                                                                    <div class="mb-2 d-flex  price-vat-tag h-15px">
                                                                        <svg class="mr-2" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="10" height="10" viewBox="0 0 503.151 503.151" style="enable-background:new 0 0 503.151 503.151;" xml:space="preserve">
                                                                            <path style="fill:#4CAF50;" d="M471.172,0H309.337c-8.483,0.022-16.616,3.387-22.635,9.365L9.369,286.699
                                                                            	c-12.492,12.496-12.492,32.752,0,45.248l161.835,161.835c12.496,12.492,32.752,12.492,45.248,0l277.333-277.333
                                                                            	c6.018-5.992,9.39-14.142,9.365-22.635V32C503.151,14.335,488.837,0.012,471.172,0z M385.839,170.667
                                                                            	c-29.455,0-53.333-23.878-53.333-53.333S356.383,64,385.839,64s53.333,23.878,53.333,53.333S415.294,170.667,385.839,170.667z"></path>
                                                                            <g>
                                                                        </g></svg>
                                                                        <small class="f-0-6-r">Inclusive of VAT &amp; Taxes</small>
                                                                    </div>
                                                                </li>


                                                    </ul>

                                                </div>

                                            </div>

                                        </div>
                                        <div class="checkout-note">
    <p>  
      <i class="fa-regular fa-circle-check"></i>  Well done! You're getting this property's lowest price! </p>
    </div>

     <div class="card">
         <?php
         
         if(isset($hotelbeds_images))
         {
         ?>
  <div class="row">
      <div class="col-md-4">
          <img src="https://photos.hotelbeds.com/giata/bigger/{{$hotelbeds_images[0]->path ?? ''}}" class="card-img-top" alt="...">
      </div>
      <div class="col-md-8">
          <h6 style="padding-top: 5px;"><?php print_r($hotelbedSelectionRS->name); ?></h6>
          <p style="font-size: 11px;font-weight: 700;"><?php print_r($ho_beds_details->address->content ?? '');  print_r($ho_beds_details->city->content ?? '');?><a href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map"><i class="fa-solid fa-location-dot"></i></a>

          
          </p>
      </div>
      
  </div>
 
 <?php
                           
                           $startTimeStamp = strtotime($hotelbedSelectionRS->checkIn);                                   
                            $endTimeStamp = strtotime($hotelbedSelectionRS->checkOut);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                           
                           
                           ?>

 <div class="row">
              <div class="col-md-9"> <span style="font-size: 14px;line-height: 22px;font-weight: bolder;margin: 8px 0px;margin-left: 25px;"><i class="far fa-calendar-check mr-1" aria-hidden="true"></i> <?php echo  date('d M, Y', strtotime($hotelbedSelectionRS->checkIn));?>&nbsp;&nbsp;<i class="fas fa-sign-out-alt mr-1" aria-hidden="true"></i><?php echo date('d M, Y', strtotime($hotelbedSelectionRS->checkOut)); ?>  </span></div>
              <div class="col-md-3">
                  <p style="font-weight: 700;color: #14b314;font-size: 13px;line-height: 22px;"><?php echo $numberDays . ' Nights';  ?></p>
              </div>
          </div>
 

  <?php
         }
         else
         {
  ?>
  
  <img src="" class="card-img-top" alt="...">
  
  <?php
         }
  ?>
  
  <div class="card-body" style="border-top: 1px solid #d2d2d2;">
      
   <div class="detail-group">
<ul class="list-group append_hotel_div">

<li class="d-flex justify-content-between"><b>Passenger:</b>&nbsp;<p class="text-right"><?php echo $get_data->total_passenger .' Adults, ' .$get_data->child . ' Children ';     ?> </p></li>

 <li class="d-flex justify-content-between"><b>Rooms:</b>&nbsp;<p><?php echo $get_data->rooms . '  Rooms' ?></p></li>
 
 
 <!--<li class="d-flex justify-content-between"><b>Room Fare:</b></li> -->
 
 
 
 
 
         <?php
        
        foreach($hotelbedSelectionRS->rooms as $rooms)
        {
        foreach($rooms->rates as $rates)
        {
            
        ?>
         
         <!--<li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">{{$rates->rooms}} X {{$rooms->name}} - {{$rates->boardName}}</p>&nbsp;<b> {{$hotelbedSelectionRS->currency ?? ''}} {{$rates->net}}</b></li> -->

<li class="d-flex justify-content-between"><b>Room Capacity:</b>&nbsp;<p><?php echo $rates->adults .' Adults, ' .$rates->children . ' Children ';     ?></p></li>
   
         <div style="border: 1px solid #d2d2d2;padding: 20px;" class="collapse" id="collapseExample1">
            <h5>Cancellation Policy</h5>
            
          <table class="table">
              <thead>
                  <th>From</th>
                 
                    <th>Value</th>
              </thead>
              <tbody>
           
                <?php
                foreach($rates->cancellationPolicies as $cancellationPolicies)
                {
                
                ?>
              <tr>
                
                <td>
                  <p class="mb-1"><span class="text-muted">{{$cancellationPolicies->from}}</span></p>
                </td>
                
                 <td>
                      <?php
                                                     $price=$cancellationPolicies->amount ?? '';
                                                    $currency=$hotelbedSelectionRS->currency ?? '';
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                    ?>
                  <p class="mb-1"><span class="text-muted">GBP {{$exchange_price}}</span></p>
                </td>
                
              </tr>
              <?php
               
                }
              
              ?>
            
          </tbody>
        </table>
        </div>
            
       
       
        
        <?php
        }
        }
        ?>



                                                        <li class="d-flex justify-content-between">
                                                            
                                                        <?php
      $current=date('Y-m-d');
       $from=date('Y-m-d', strtotime($hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies[0]->from));
     if(isset($hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies))
    {
      if($from > $current)
      {
      
      ?> 
      
         <a style="color: #14b314;" class="btn btn-link link-info p-md-1 my-1" data-bs-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample1">Refundable</a>   
         
        
       
      <?php
      
      }
      else
      {
      
      ?>
      
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>      

      <?php
      }
    }
      ?>    
                                                            
                                                            
                                                       </li>

                                                    </ul>

                                                </div>   
    

    
    
   
  </div>
</div>
        
        
        
        
        
   
                </div> 
            
            
            <?php
            }
            ?>
                   
                    
                    
                    
                </div>
               
            </div>
            
        </section>
        <!-- Button trigger modal -->
        <!--<script type="text/javascript" src="{{ asset('public/plugins/jquery/jquery.js') }}"></script>-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
          <script>

$(document).ready(function(){
           

              var hotel_page_select_currency = $('#exchange_currency_ajt').val();
            //var currency = $('#currency_slc').val();
                var currency= '<?php echo Session()->get('currency_slc'); ?>';
                var currency_slc_iso= '<?php echo Session()->get('currency_slc_iso'); ?>';
                //console.log('currency hotel page='+currency);
               
              var exchange_price = [];
                var initialdisplyedhotelcount = $(".hotel_append_div").children().length;
                for(var count_i=1; count_i<=initialdisplyedhotelcount; count_i++)
                {
              price=$('.exchange_price1_1_'+count_i+'').text();
              exchange_price.push(price);
              
                
                }
//console.log(exchange_price);
    //  console.log(exchange_price);
    
    
$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            url: "{{ url('convert_currency_by_alj') }}",
            method: 'POST',
            data: {
                 "_token": "{{ csrf_token() }}",
                "currency": currency,
               
                "exchange_price": exchange_price,
                "currency_slc_iso": currency_slc_iso,
            },
            success: function(result){
                 console.log(result);
          result.forEach(function fn(item, index) {
 var count=index + 1;
  console.log(item);
  
  $('.exchange_rate_country_price_'+count+'').html(currency+ ' ' + item);

   $('#select_dynamic_price_'+count+'').val(item);
    $('#select_dynamic_currency_'+count+'').val(currency);

})
                 //
                
               
             
              
            },
            error:function(error){
                console.log(error);
            }
        });
        
        
        
         $('#exchange_currency_ajt').on('change', function() {
                 $('.preloader1').fadeIn();
                
                var currency = $(this).find(":selected").val();
                 var currency_slc_iso = $(this).find(":selected").attr('data-iso');
               
              var exchange_price = [];
                var initialdisplyedhotelcount = $(".hotel_append_div").children().length;
                console.log('hotel_append_div'+initialdisplyedhotelcount);
                for(var count_i=1; count_i<=initialdisplyedhotelcount; count_i++)
                {
              price=$('.exchange_price1_1_'+count_i+'').text();
              exchange_price.push(price);
              
                
                }
//console.log(exchange_price);
    //  console.log(exchange_price);
    
    
$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            url: "{{ url('convert_currency_by_alj') }}",
            method: 'POST',
            data: {
                 "_token": "{{ csrf_token() }}",
                "currency": currency,
                "exchange_price": exchange_price,
                 "currency_slc_iso": currency_slc_iso,
            },
            success: function(result){
                 console.log(result);
          result.forEach(function fn(item, index) {
 var count=index + 1;
  console.log(item);
  $('.exchange_rate_country_price_'+count+'').html(currency+ ' ' + item);
  $('#select_dynamic_price_'+count+'').val(item);
    $('#select_dynamic_currency_'+count+'').val(currency);
  $('.preloader1').fadeOut();

})
                 //
                
               
             
              
            },
            error:function(error){
                console.log(error);
            }
        });
        
            
 
  
    
    
});
        
        
        
        
        
        
        
             
    

});   
            
            
            
            
            

  
</script>
        <script>
            $(document).ready(function(){
  $("#click_more_fc").click(function(){
    $("#show_more_fc").fadeToggle();
  });
});
        </script>
<script>




    function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    setInterval(function () {
        minutes = parseInt(timer / 60, 10)
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.text(minutes + ":" + seconds);

        if (--timer < 0) {
            timer = duration;
        }
    }, 1000);
}

jQuery(function ($)
 {
    var fiveMinutes = 60 * 5,
        display = $('#time');
    startTimer(fiveMinutes, display);
});
</script>

@endsection

