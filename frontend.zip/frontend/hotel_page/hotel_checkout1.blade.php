@extends('template/frontend/includes/master')

@section('content')

<?php

 $child_count = Session::get('child_searching');
  $hotel_beds_code=Session::get('hotel_beds_code');
 $adult_count1 = Session::get('adult');
  $adult_count=$adult_count1 + $child_count;
  $slug= Session::get('provider');
    $slug= Session::get('provider');
    $search_id=Session::get('search_id')
// $cart=Session::get('cart');
// print_r($slug);die();

?>


    <section class="awe-parallax category-heading-section-demo h-300">
            <div class="awe-overlay"></div>
           
            </div>
        </section>
        <section class="checkout-section-demo">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="checkout-page__top">
                            <div class="title">
                                <h1 class="text-uppercase">CHECKOUT</h1>
                            </div>
                            <span class="phone">Support Call: 0121 777 2522</span>
                        </div>
                    </div>
                    
                    <div class="col-lg-9">
                        <div class="checkout-page__content">
                            
      
                             
                             
  @if($slug == "travellanda" || $slug == "hotelbeds")
  
  
  
  
                            
                    <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add More Passenger</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <form class="row g-3" method="post"  action="{{URL::to('add_other_passengar')}}">
           @csrf
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">Title</label>
    <select class="form-control" name="title">
        <option value="">Select Title</option>
        <option value="Mr.">Mr.</option>
        <option value="Mrs.">Mrs.</option>
    </select>
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">First Name</label>
    <input type="text" class="form-control" value="{{$other_passengar_decode->other_first_name ?? ''}}"  name="other_first_name" >
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">Last Name</label>
    <input type="text" class="form-control" value="{{$other_passengar_decode->other_last_name ?? ''}}"  name="other_last_name">
  </div>
  <div class="col-md-6">
    <label for="inputEmail4"  class="form-label">Nationality</label>
    <select class="form-control" name="other_nationality">
        <option value="">Select Nationality</option>
        <option value="Nationality">Nationality1</option>
        <option value="Nationality">Nationality2</option>
    </select>
  </div>
  
  <div class="col-12" style="text-align: right;">
    <button type="submit" name="submit"  class="btn btn-primary">Save</button>
  </div>
</form>
      </div>
      
    </div>
  </div>
</div>


                   
 
                            
                              <form method="post" class="row g-3" action="{{URL::to('add_lead_passengar')}}">
                                 @csrf
                                 
                                 <h5><?php print_r($slug);  ?></h5>
                                 
                                  <div class="col-md-4">
    <label for="inputEmail4" class="form-label">Title</label>
    <select class="form-control" name="lead_title">
        <option value="">Select Title</option>
        <option value="Mr.">Mr.</option>
        <option value="Mrs.">Mrs.</option>
    </select>
  </div>
                              <div class="col-md-4">
                                <label for="inputEmail4" class="form-label">First name</label>
                                <input type="text" class="form-control" id="inputEmail4" required value="{{ $lead_passengar_decode->lead_first_name ?? '' }}"  name="lead_first_name">
                              </div>
                              <div class="col-md-4">
                                <label for="inputPassword4" class="form-label">Last name</label>
                                <input type="text" class="form-control" id="inputPassword4" required value="{{ $lead_passengar_decode->lead_last_name ?? '' }}"  name="lead_last_name">
                              </div>
                              <div class="col-4">
                                <label for="inputAddress" class="form-label">Email</label>
                                <input type="text" class="form-control" id="inputAddress" required value="{{ $lead_passengar_decode->lead_email ?? '' }}"  name="lead_email">
                              </div>
                              <div class="col-4">
                                <label for="inputAddress" class="form-label">Phone</label>
                                <input type="text" class="form-control" required id="country_code" value="{{ $lead_passengar_decode->lead_phone ?? '' }}"  name="lead_phone">
                              </div>
                              
                              
                              <div class="col-md-4">
                                <label for="inputEmail4" class="form-label">Passport No</label>
                                <input type="text" class="form-control" required value="{{ $lead_passengar_decode->lead_passport_no ?? '' }}" name="lead_passport_no">
                              </div>
                              
                              
                              <div class="col-6">
                                <label for="inputAddress2" class="form-label">Address</label>
<input type="text" class="form-control" value="{{ $lead_passengar_decode->lead_address ?? '' }}"  required  name="lead_address">
                              </div>
                              

                              <div class="col-12">
                               
                                                           

                                                      <?php
                                                      $adults = 0;
                                                        $children = 0;
                                                     $check_data=Session::get('other_adults');
                                                    //  print_r($check_data);
                                                      
                                                    //  foreach($check_data as $details)
                                                    //   {
                                                    //       $adults += $details->title;
                                                        
                                                    //   }
                                                   
                                                
                                                      
                                                // For Adults <Calculation>
                                                if(session('other_adults'))
                                                    {
                                                       $saveAdults = count(session('other_adults'));
                                                      
                                                        $saveAdults = $saveAdults + 1; 
                                                        print_r($saveAdults);
                                                        
                                                    }
                                                       
                                            

                                                else
                                                   {
                                                     $saveAdults = 1;  
                                                   }
                                                        
                                                   
                                                if(empty($lead_passengar_decode)){
                                                     ?>
                                                    </br>
                                                    <button class="btn" style="background-color:#d2b254; color:white;" name="submit" type="submit">Add Lead Passengar</button>
                                                     
                                                     <?php
                                                }else
                                                {
                                                    if($saveAdults < $adult_count)
                                                      {
                                                      ?>
                                                   
                                                    <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn" style="background-color:#d2b254; color:white;">Add other Passengar</a>
                                                    <?php
                                                    
                                                      }else{
                                                           ?>
                                                    </br>
                                                    <?php
                                                    if($slug == 'travellanda')
                                                    {
                                                    ?>
                                                    <a class="btn" href="{{URL::to('')}}/confrimbooking/{{$optid."$$".$roomid}}/{{$slug}}" style="background-color:#d2b254; color:white;"  >Confirm booking</a>
                                                     <?php
                                                     
                                                    }
                                                    else
                                                    {
                                                        ?>
                                                        
                                                       <a class="btn" href="{{URL::to('')}}/confrimbooking/{{$search_id}}/{{$slug}}" style="background-color:#d2b254; color:white;"  >Confirm booking</a> 
                                                        
                                                    <?php
                                                    }
                                                    ?>
                                                     
                                                     <?php
                                                     
                                                      }
                                                }
                                                     ?>
                                                      
                                               
                                                      
                                                      
                                                    
                                                      
                                             
                              </div>
                            </form>
                            @endif
                             
                        </div>
                        
                       
                       
                    </div>
                    
                    
                    
                    
                    <div class="col-lg-3">
                        <div class="checkout-page__sidebar">
                            <ul>
                               
                                <li class="current">Booking Details</li>
                               
                            </ul>
                        </div>
                    </div>
                    
                    
                    
                </div>
            </div>
        </section>
        <!-- Button trigger modal -->


@endsection

