<!DOCTYPE html>
<html class="no-js" lang="en">
    <head>
        <title>Alhijaztours  - Travel Booking System</title>
    </head>
    <body>
        <h4>Your Email Address: <b>{{ $email_Address }}</b></h4>
        <p>{{ $comment_Area }}</h1>
    </body>
</html>