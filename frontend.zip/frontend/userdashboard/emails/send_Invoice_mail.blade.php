<!DOCTYPE html>
<html class="no-js" lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="ThemeMarch">
    <!-- Site Title -->
    <title>Alhijaztours  - Travel Booking System</title>
    
    <!--<link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">-->
    
    <!--<link rel="stylesheet" href="{{asset('public/invoice/assets/css/font-awesome-6.min.css')}}">-->
    <script src="https://kit.fontawesome.com/a48bac58c4.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="https://alhijaztours.net/public/admin_package/frontend/css/lib/bootstrap.min.css">
    <link rel="stylesheet" href="{{asset('public/invoice/assets/css/style.css')}}">
    
    <style>
        .cs-border_less td{
            padding: 5px 15px;
        }
        
        .clearfix:after {
  content:"";
  display:block;
  clear:both;
 }
 
 .cs-bar_list::before{
     height: 15px;
   
    left: 4px;
    top: 26px;
 }
     
    </style>
    
</head>
    <body>
        @if(isset($cart_data))
            @foreach($cart_data as $cart_res)
                <?php  //dd($cart_data); ?>
                <div class="cs-container">
                    <div class="cs-invoice cs-style1">
                        <div class="cs-invoice_in" id="download_section">
                            <div class="cs-invoice_head cs-type1 cs-mb25 clearfix">
                              <div class="cs-invoice_left" style="width: 50%;float: left;">
                                <p class="cs-invoice_number cs-primary_color cs-mb0 cs-f16"><b class="cs-primary_color">Invoice No:</b> {{ $id }}</p>
                                <p class="cs-invoice_number cs-primary_color cs-mb0 cs-f16"><b class="cs-primary_color">Agent Name:</b> {{ $cart_res->agent_name }}</p>
                                
                              </div>
                              <div class="cs-invoice_right cs-text_right" style="width: 50%;float: right;">
                                <div class="cs-logo cs-mb5"><img src="{{asset('public/admin_package/frontend/images/logo.png')}}"alt="Logo"></div>
                                <!--<img src="https://client.synchronousdigital.com/public/admin_package/assets/images/logo1-1.png" style="max-width: 15%;">-->
                              </div>
                            </div>
                            @if(isset($iternery_array))
                                @foreach($iternery_array as $itenry_res)                    
                                    <div class="cs-invoice_head cs-mb10 clearfix">
                                      <div class="cs-invoice_left" style="width: 50%;float: left;">
                                        <p>
                                        
                                            @if($payment_Status->confirm == 1)
                                                @if($package_Type->pakage_type == 'tour')
                                                <b class="cs-primary_color cs-f22">Confirmed: {{ $itenry_res[0]->time_duration ?? '' }} Days</b> <br>
                                                @else
                                                <b class="cs-primary_color cs-f22">Confirmed: {{ $tour_data->duration }} Hours</b> <br>
                                                @endif
                                            @else
                                                @if($package_Type->pakage_type == 'tour')
                                                <b class="cs-primary_color cs-f22"> Tentative <i class="fa-solid fa-check"></i></b> <br>
                                                <b>{{ $itenry_res[0]->time_duration ?? '' }} Days </b></br>
                                                 @else
                                                <b class="cs-primary_color cs-f22">Tentative: {{ $tour_data->duration }} Hours</b> <br>
                                                @endif
                                            @endif
                                            
                                            <b class="cs-primary_color">Booked By: {{ $cart_res->agent_name }}</b> <br>
                                            
                                          <?php
                                          
                                          $dateValue = strtotime($inv_data->created_at);
                            $year = date('Y',$dateValue);
                            $monthName = date('F',$dateValue);
                            $monthNo = date('d',$dateValue);
                            printf("%s, %d, %s\n", $monthName, $monthNo, $year);
                                          ?>
                                          
                                        </p>
                                        
                                        <!--<h5>Payment Status :</h5>-->
                                            @if($package_Type->pakage_type == 'tour')
                                                @if(isset($total_package_Payments) || $total_package_Payments != null || $total_package_Payments != '' || $total_package_Payments != 0)
                                                    @if($recieved_package_Payments == 0)
                                                        <b class="cs-primary_color cs-f22">UNPAID</b> <br>
                                                    @elseif($recieved_package_Payments > 0 && $recieved_package_Payments < $total_package_Payments->total_amount - $recieved_package_Payments)
                                                        <b class="cs-primary_color cs-f22">PARTIALLY PAID</b> <br>
                                                    @else
                                                        <b class="cs-primary_color cs-f22">PAID</b> <br>
                                                    @endif
                                                @else
                                                @endif
                                            @elseif($package_Type->pakage_type == 'activity')
                                                
                                                @if($recieved_activity_Payments == 0)
                                                    <b class="cs-primary_color cs-f22">UNPAID</b> <br>
                                                @elseif($recieved_activity_Payments > 0 && $recieved_activity_Payments < $total_package_Payments->total_amount - $recieved_activity_Payments)
                                                    <b class="cs-primary_color cs-f22">PARTIALLY PAID</b> <br>
                                                @else
                                                    <b class="cs-primary_color cs-f22">PAID</b> <br>
                                                @endif
                                            @else
                                            @endif
                                      </div>
                                      <div class="cs-invoice_right cs-text_right" style="width: 50%;float: right;">
                                        <b class="cs-primary_color">{{ $cart_res->tour_name }}</b>
                                        <p>
                                          {{$contact_details->company_name ?? ''}} <br>
                                          {{$contact_details->email ?? ''}} <br>
                                          {{$contact_details->contact_number ?? ''}}<br>
                                          {{$contact_details->address ?? ''}}<br>
                                        </p>
                                      </div>
                                    </div>
                                    <div class="cs-invoice_head cs-50_col cs-mb25 clearfix" style="float: none;">
                                      <div class="cs-invoice_left" style="width: 50%;float: left;">
                                        <b class="cs-primary_color">Adults</b> <br>
                                            <?php
                                            $leadpassenger_details=$inv_data->passenger_detail;
                    
                                            if($leadpassenger_details != 'null')
                                            {
                                                $adults_details1=json_decode($leadpassenger_details);
                                                foreach($adults_details1 as $adults_details1){
                                                     $leadgender = $adults_details1->gender;
                                        
                                          }
                                        }
                                        ?>
                                            <b>Lead Passenger: </b>{{$inv_data->passenger_name}} ({{ $leadgender }})<br>
                                        
                                        <?php
                                            $adults_details=$inv_data->adults_detail;
                                            $Adult_No = 1;
                                            
                                            if($adults_details != 'null')
                                            {
                                                $adults_details1=json_decode($adults_details);
                                                foreach($adults_details1 as $adults_details1){
                                        ?>
                                                   <b> Adult {{ $Adult_No }} : </b>{{ $adults_details1->passengerName }} ( {{$adults_details1->gender}} ) <?php $Adult_No++ ?> <br>
                                        <?php
                                          }
                                        }
                                        ?>
                                        
                                        <?php
                                            $child_details=$inv_data->child_detail;
                                            if(isset($child_details) AND $child_details !== '""')
                                            { 
                                                $Child_No = 1;
                                                $child_details1=json_decode($child_details);
                                                echo '<b class="cs-primary_color">Children</b> <br>';
                                                foreach($child_details1 as $child_details1){
                                        ?>
                                                <b> Child {{ $Child_No }} : </b> {{$child_details1->passengerName}} ( {{$child_details1->gender}} )<?php $Child_No++ ?> <br>
                                        
                                        <?php
                                          }
                                        }
                                        ?>
                                        
                                         <?php
                                            $infants_details=$inv_data->infant_details;
                                            if(isset($infants_details) AND $infants_details !== '""')
                                            { 
                                                $infant_No = 1;
                                                $infants_details1=json_decode($infants_details);
                                                echo '<b class="cs-primary_color">Infants</b> <br>';
                                                foreach($infants_details1 as $child_details1){
                                        ?>
                                                <b> Infant {{ $infant_No }} : </b> {{$child_details1->passengerName}} ( {{$child_details1->gender }} )<?php $infant_No++ ?> <br>
                                        
                                        <?php
                                          }
                                        }
                                        ?>
                                        
                                      </div>
                                      <div class="cs-invoice_right" style="width: 50%;float: right;">
                                        <ul class="cs-bar_list">
                                            <?php 
                                                if($package_Type->pakage_type == 'tour'){
                                            ?>
                                          <li><b class="cs-primary_color"><img style="max-width: 17px;margin-right: 5px;" src="{{asset('public/invoice/assets/img/plane-departure-solid.svg')}}"alt="Logo"> </b>
                                          <?php
                                          
                                          $dateValue = strtotime(date("d-m-Y", strtotime($itenry_res[0]->start_date ?? '' )));
                                 
                                            $year = date('Y',$dateValue);
                                            $monthName = date('F',$dateValue);
                                            $monthNo = date('d',$dateValue);
                                            $day = date('l', $dateValue);
                                            echo $day . ',' . $monthNo . ',' . $monthName . ',' . $year;
                                            // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                                          ?>
                                          
                                          
                                          </li>
                                          <li><b class="cs-primary_color"> <img style="max-width: 17px;margin-right: 5px;" src="{{asset('public/invoice/assets/img/plane-arrival-solid.svg')}}"alt="Logo"></b>
                                          
                                           <?php
                                          
                                          $dateValue = strtotime(date("d-m-Y", strtotime($itenry_res[0]->end_date ?? '' )));
                                                 
                                            $year = date('Y',$dateValue);
                                            $monthName = date('F',$dateValue);
                                            $monthNo = date('d',$dateValue);
                                            $day = date('l', $dateValue);
                                            echo $day . ',' . $monthNo . ',' . $monthName . ',' . $year;
                                            // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                                            ?>
                                            </li>
                                            <?php
                                            }else{
                                                ?>
                                                <li>Activtiy Date  : 
                                                <?php
                                                $dateValue = strtotime(date("d-m-Y", strtotime($cart_res->activity_select_date ?? '' )));
                                                 
                                            $year = date('Y',$dateValue);
                                            $monthName = date('F',$dateValue);
                                            $monthNo = date('d',$dateValue);
                                            $day_select = date('l', $dateValue);
                                            echo $day_select . ',' . $monthNo . ',' . $monthName . ',' . $year;
                                            
                                            $start_time = '';
                                            $end_time = '';
                                            $Availibilty = json_decode($tour_data->Availibilty);
                                            foreach($Availibilty as $id => $av_res){
                                                if(isset($av_res->enable)){
                                                            $day = '';
                                                           
                                                              if($id == '1'){
                                                                    $day = "Monday";
                                                                    if($day_select == $day){
                                                                        
                                                                        $start_time = $av_res->from;
                                                                        $end_time = $av_res->to;
                                                                    }
                                                              }
                                                              
                                                               if($id == '2'){
                                                                    $day = "Tuesday";
                                                                    if($day_select == $day){
                                                                         
                                                                        $start_time = $av_res->from;
                                                                        $end_time = $av_res->to;
                                                                    }
                                                              }
                                                              
                                                               if($id == '3'){
                                                                    $day = "Wednesday";
                                                                   if($day_select == $day){
                                                                       
                                                                        $start_time = $av_res->from;
                                                                        $end_time = $av_res->to;
                                                                    }
                                                              }
                                                              
                                                               if($id == '4'){
                                                                    $day = "Thursday";
                                                                    if($day_select == $day){
                                                                        
                                                                        $start_time = $av_res->from;
                                                                        $end_time = $av_res->to;
                                                                    }
                                                              }
                                                              
                                                               if($id == '5'){
                                                                    $day = "Friday";
                                                                    
                                                                    if($day_select == $day){
                                                                        $start_time = $av_res->from;
                                                                        $end_time = $av_res->to;
                                                                    }
                                                              }
                                                              
                                                               if($id == '6'){
                                                                    $day = "Saturday";
                                                                    if($day_select == $day){
                                                                        $start_time = $av_res->from;
                                                                        $end_time = $av_res->to;
                                                                    }
                                                              }
                                                              
                                                               if($id == '7'){
                                                                    $day = "Sunday";
                                                                    if($day_select == $day){
                                                                        $start_time = $av_res->from;
                                                                        $end_time = $av_res->to;
                                                                    }
                                                              }
                                                }
                                            }
                                            ?>
                                                </li>
                                                <li>Location: {{ $tour_data->location }}</li>
                                                <li>Duration: {{ $tour_data->duration }} Hours</li>
                                                <li>Start Time: {{ $start_time }} - End Time {{ $end_time }}</li>
                                                <?php
                                            }
                                          ?>
                                                
                                            <!--<li style="font-size:16px; font-weight: bold;margin-top:25px"> Visa Included.</li>-->
                                            <!--<li style="font-size:16px; font-weight: bold;margin-top:10px">Transfer Included.</li>-->
                                            <!--<li style="font-size:16px; font-weight: bold;margin-top:10px">Flights Included.</li>-->
                                            <!--<li style="font-size:16px; font-weight: bold;margin-top:10px"> Hotels Included.</li>-->
                                         
                                        </ul>
                                        
                                       
                                      </div>
                                    </div>
                                @endforeach
                            @endif
                            <?php 
                                if($package_Type->pakage_type !== 'tour'){
                            ?>
                                    <hr>
                                    <div class="">
                                        <h4><b class="cs-primary_color">Meeting And Pickup</b></h4> <br>
                                    </div>
                                    <div>
                                        {!! $tour_data->meeting_and_pickups !!}
                                   </div>
                            <?php 
                                }
                            ?>
                            <?php
                                if(isset($tour_batchs->accomodation_details))
                                {
                            ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <ul class="cs-list cs-style2">
                                                <div class="cs-list_left">
                                                    <b class="cs-primary_color" style="margin-left: 25px; font-size: 18px;"> Accomodation Details</b> <br>
                                                </div>
                                                <?php
                                                    $accomodation_details=$tour_batchs->accomodation_details;
                                                    $accomodation_details=json_decode($accomodation_details);
                                                    foreach($accomodation_details as $accomodation_details)
                                                    {
                                                ?>            
                                                
                                                  <li>
                                                    <div class="cs-list_left" style="font-size: 15px;">
                                                       
                                                      <b class="cs-primary_color"> <i class="fa-solid fa-hotel"></i> Hotel Name :{{$accomodation_details->acc_hotel_name}} </b> <br><br>
                                                     <div class="row clearfix" style="float: none;">
                                                         <div class="col-sm-4" style="width: 50%;float: left;">
                                                              <img style="max-width: 17px;margin-right: 5px;" src="{{asset('public/invoice/assets/img/calendar-check-solid.svg')}}" alt="Logo">   Check In:{{$accomodation_details->acc_check_in}} 
                                                         </div>
                                                         <div class="col-sm-4" style="width: 50%;float: right;">
                                                              <img style="max-width: 17px;margin-right: 5px;" src="{{asset('public/invoice/assets/img/calendar-check-solid.svg')}}"alt="Logo">  Check Out: {{$accomodation_details->acc_check_out}}
                                                         </div>
                                                         
                                                     </div>
                                                     
                                                    </div>
                                                    
                                                  </li>
                                               
                                                                  
                                                   <?php
                                                          }
                                                ?>
                                            </ul> 
                                        </div>
                                    </div>
                            <?php
                                 }
                            ?>  
                            <div class="cs-invoice_head cs-50_col cs-mb25 clearfix" style="clear: right;">
                                <div class="cs-invoice_left"></div>
                                <div class="cs-invoice_right">
                                    <?php
                                        if(isset($tour_batchs->transportation_details))
                                        {
                                    ?> 
                                            <ul class="cs-list cs-style2">
                                                <div class="cs-list_left">
                                                    <b class="cs-primary_color">Transportation Details</b> <br>
                                                </div>
                                                <?php
                                                    $transportation_details=$tour_batchs->transportation_details;
                                                    $transportation_details=json_decode($transportation_details);
                                                ?>
                                    
                                                <li>
                                                <div class="cs-list_left">
                                                  <b class="cs-primary_color"> </b> <br>
                                                  <p class="cs-mb0" style="line-height: 29px;">
                                                    <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/location-dot-solid.svg')}}"alt="Logo">  Pick Up :{{$transportation_details->transportation_pick_up_location}} <br>
                                                    <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/location-dot-solid.svg')}}"alt="Logo">  Drop Off: {{$transportation_details->transportation_drop_off_location}}<br>
                                                    <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/calendar-solid.svg')}}"alt="Logo">  Pick Up Date: {{$transportation_details->transportation_pick_up_date}}<br>
                                                   
                                                    Trip Type: {{$transportation_details->transportation_trip_type}}<br>
                                                  </p>
                                                </div>
                                                
                                              </li>
                                            </ul>
                                    <?php
                                        }
                                    ?>
                                </div>    
                            </div>
                            
                            <?php
                                if(isset($tour_batchs->flights_details))
                                {
                            ?>            
                                    <ul class="cs-list cs-style2">
                                        <div class="cs-list_left">
                                            <b class="cs-primary_color">Flights Details</b> <br>
                                        </div>
                                        @if(isset($flights_details->flight_type))
                                            @if($flights_details->flight_type == 'Direct')
                                                <li>
                                                    <div class="cs-list_left">
                                                        <p class="s-mb0" style="line-height: 35px;"> 
                                                            <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/plane-departure-solid.svg')}}"alt="Logo"> : {{$flights_details->departure_airport_code ?? ''}} <br>
                                                            Departure Flight Number:{{ $flights_details->departure_flight_number ?? '' }}<br>
                                                            Departure Date: {{$flights_details->departure_date ?? ''}}<br>
                                                        </p>
                                                    </div>
                                                    <div class="cs-list_right">
                                                        <p class="cs-mb0" style="line-height: 30px;">
                                                            <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/plane-arrival-solid.svg')}}"alt="Logo">  : {{ $flights_details->arrival_airport_code ?? '' }}<br>
                                                            Arrival Flight Number:</span>{{ $flights_details->arrival_flight_number ?? ''  }}<br>
                                                            Arrival Date:</span>{{ $flights_details->arrival_date ?? '' }}<br>
                                                            Flight Type: {{$flights_details->flight_type ?? ''}}<br>
                                                        </p>
                                                    </div>
                                                </li>
                                            @elseif($flights_details->flight_type == 'Indirect')
                                                @foreach($flights_detailsI as $value)
                                                    <li>
                                                        <div class="cs-list_left">
                                                            <p class="s-mb0" style="line-height: 35px;"> 
                                                                <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/plane-departure-solid.svg')}}"alt="Logo"> : {{$value->more_departure_airport_code ?? ''}} <br>
                                                                Departure Flight Number:{{ $value->more_departure_flight_number ?? '' }}<br>
                                                                Departure Date: {{$value->more_departure_time ?? ''}}<br>
                                                            </p>
                                                        </div>
                                                        <div class="cs-list_right">
                                                            <p class="cs-mb0" style="line-height: 30px;">
                                                                <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/plane-arrival-solid.svg')}}"alt="Logo">  : {{ $value->return_more_departure_airport_code ?? '' }}<br>
                                                                Arrival Flight Number:</span>{{ $value->return_more_departure_flight_number ?? ''  }}<br>
                                                                Arrival Date:</span>{{ $value->return_more_arrival_time ?? '' }}<br>
                                                                Flight Type: {{$value->return_more_departure_Flight_Type ?? ''}}<br>
                                                            </p>
                                                        </div>
                                                    </li>
                                                @endforeach
                                            @else
                                                <h4>No Flight Details</h4>
                                            @endif
                                        @else
                                        @endif
                                   </ul>
                            <?php
                                }
                            ?>              
                            </ul>
                            <?php 
                                    $cart_total_data = json_decode($cart_res->cart_total_data);
                                    // print_r($cart_total_data);
                                 ?>
                            <div class="cs-table cs-style1">
                  <div class="cs-round_border">
                    <div class="cs-table_responsive">
                      <table class="cs-border_less">
                        <tbody>
                          <tr>
                            <td class="cs-primary_color cs-semi_bold cs-f18" colspan="3">Rooms
                            </td>
                            <td class="cs-primary_color cs-semi_bold cs-f18">
                            </td>
                            <td class="cs-primary_color cs-semi_bold cs-f18">PAX
                            </td>
                            <td class="cs-primary_color cs-semi_bold cs-f18">
                               Price
                            </td>
                          </tr>
                          
                           <?php 
                                $cart_total_data = json_decode($cart_res->cart_total_data);
                               
                          ?>
                          @if($cart_res->adults> 0)
                          <tr>
                            <td>Adults : {{ $cart_res->adults }}</td>
                            <td class="cs-primary_color">
                                <?php 
                                    if($cart_res->childs){
                                ?>
                                Children : {{ $cart_res->childs }}
                                
                                <?php 
                                    }
                                ?>
                            </td>
                            <td class="cs-bold cs-primary_color cs-text_right"></td>
                            <?php 
                            if($package_Type->pakage_type == 'tour'){
                        ?>
                            <td class="cs-bold cs-primary_color cs-text_right">Adult Price : {{ $currency_Symbol->currency_symbol }} {{ $cart_res->sigle_price }}<br>
                            <?php 
                                        if($cart_res->child_price_tour != 0 && $cart_res->child_price_tour != null && $cart_res->child_price_tour !== 'null'){
                                            if($cart_res->childs){
                                            ?>
                                             Child Price:</span>{{ $cart_res->currency }} {{ $cart_res->child_price_tour }}
                                            <?php
                                            }
                                        }
                                     ?></td>
                            <?php 
                            }else{
                                ?>
                            <td class="cs-bold cs-primary_color cs-text_right">Adult Price: {{ $currency_Symbol->currency_symbol }} {{ $cart_res->adult_price }} - Child Price :{{ $currency_Symbol->currency_symbol }} {{ $cart_res->child_price }}</td>
                                <?php
                            }
                        ?>
                          </tr>
                           @endif
                             @if($cart_res->double_adults > 0  || $cart_total_data->double_childs > 0 || $cart_total_data->double_infant > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Double Rooms X {{ $cart_res->double_room }}
                                </td>
                                 <td></td>
                               
                                <td class="cs-primary_color cs-semi_bold cs-f14" >
                                 @isset($cart_res->double_adults)
                                    {{ $cart_res->double_adults }} Adults,
                                @endisset
                                
                                @isset($cart_total_data->double_childs)
                                    {{ $cart_total_data->double_childs }} Child,
                                @endisset
                                
                                @isset($cart_total_data->double_infant)
                                    {{ $cart_total_data->double_infant }} Infants
                                @endisset
                                </td>
                                <td>
                                   {{ $cart_total_data->currency }} {{ $cart_total_data->double_adult_total + $cart_total_data->double_childs_total + $cart_total_data->double_infant_total }}
                                </td>
                           </tr>
                          @endif
                          
                              @if($cart_res->triple_adults > 0  || $cart_total_data->triple_childs > 0 || $cart_total_data->triple_infant > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Triple Rooms X  {{ $cart_res->triple_room }}
                                </td>
                                <td></td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                               @isset($cart_res->triple_adults)
                                    {{ $cart_res->triple_adults }} Adults,
                                @endisset
                                
                                @isset($cart_total_data->triple_childs)
                                    {{ $cart_total_data->triple_childs }} Child,
                                @endisset
                                
                                @isset($cart_total_data->triple_infant)
                                    {{ $cart_total_data->triple_infant }} Infants
                                @endisset
                                </td>
                                <td>
                                    {{ $cart_total_data->currency }} {{ $cart_total_data->triple_adult_total + $cart_total_data->triple_childs_total + $cart_total_data->triple_infant_total }}
                                </td>
                                
                           </tr>
                          @endif
                          
                                 @if($cart_res->quad_adults > 0  || $cart_total_data->quad_childs > 0 || $cart_total_data->quad_infant > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Quad Rooms X  {{ $cart_res->quad_room }}
                                </td>
                                 <td></td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                @isset($cart_res->quad_adults)
                                    {{ $cart_res->quad_adults }} Adults,
                                @endisset
                                
                                @isset($cart_total_data->quad_childs)
                                    {{ $cart_total_data->quad_childs }} Child,
                                @endisset
                                
                                @isset($cart_total_data->quad_infant)
                                    {{ $cart_total_data->quad_infant }} Infants
                                @endisset
                                </td>
                                 <td>
                                    {{ $cart_total_data->currency }} {{ $cart_total_data->quad_adult_total + $cart_total_data->quad_child_total + $cart_total_data->quad_infant_total }}
                                </td>
                                
                               
                           </tr>
                          @endif
                           <tr>
                               <td colspan="12"><hr></td>
                              
                              
                           </tr>
                            <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f18" colspan="3">Rooms
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f18">PAX
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f18">Price Per Person
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f18" style="text-align: right;">Total
                                </td>
                              </tr>
                         
                           @if($cart_res->double_adults > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Adults in Double Room
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_res->double_adults)
                                    {{ $cart_res->double_adults }} Adult
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->sharing2 }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->double_adult_total }}</td>
                           </tr>
                          @endif
                          
                           @if($cart_total_data->double_childs > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Childs in Double Room
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14" >
                                 @isset($cart_total_data->double_childs)
                                    {{ $cart_total_data->double_childs }} Child
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->double_child_price }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->double_childs_total }}</td>
                           </tr>
                          @endif
                          
                        @if($cart_total_data->double_infant > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i>  Infants in Double Room
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14" >
                                 @isset($cart_total_data->double_infant)
                                    {{ $cart_total_data->double_infant }} Infant
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->double_infant_price }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->double_infant_total }}</td>
                           </tr>
                          @endif
                          
                          
                          
                          
                        
                          
                           @if($cart_total_data->triple_adults > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Adults in Triple Room
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_total_data->triple_adults)
                                    {{ $cart_total_data->triple_adults }} Adult
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->sharing3 }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->triple_adult_total }}</td>
                           </tr>
                          @endif
                          
                            @if($cart_total_data->triple_childs > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Child in Triple Room
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_total_data->triple_childs)
                                    {{ $cart_total_data->triple_childs }} Child
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->triple_child_price }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->triple_childs_total }}</td>
                           </tr>
                          @endif
                          
                        @if($cart_total_data->triple_infant > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Infants in Triple Room
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_total_data->triple_infant)
                                    {{ $cart_total_data->triple_infant }} Infant
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->triple_infant_price }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->triple_infant_total }}</td>
                           </tr>
                          @endif
                          
                          
                     
                          
                               @if($cart_total_data->quad_adults > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Adults in Quad Room
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_total_data->quad_adults)
                                    {{ $cart_total_data->quad_adults }} Adult
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->sharing4 }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->quad_adult_total }}</td>
                           </tr>
                          @endif
                          
                         @if($cart_total_data->quad_childs > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Child in Quad Room
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_total_data->quad_childs)
                                    {{ $cart_total_data->quad_childs }} Child
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->quad_child_price }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ number_format((float)$cart_total_data->quad_child_total, 2, '.', '');  }}</td>
                           </tr>
                          @endif
                          
                                @if($cart_total_data->quad_infant > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i>  Infant in Quad Room
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_total_data->quad_infant)
                                    {{ $cart_total_data->quad_infant }} Infant
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->quad_infant_price }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->infant_total_total }}</td>
                           </tr>
                          @endif
                          
                          
                              @isset($cart_res->without_acc_adults)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-user"></i> Adult Without Bed
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                    {{ $cart_res->without_acc_adults }} Adult
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->without_acc_adult_price }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->without_acc_adult_total }}</td>
                           </tr>
                          @endif
                          
                           @isset($cart_total_data->children)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-child"></i> Child Without Bed
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                    {{ $cart_total_data->children }} Child
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->child_price }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ round($cart_total_data->without_acc_child_total, 2); }}</td>
                           </tr>
                          @endif
                          
                            @isset($cart_total_data->infants)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-person-breastfeeding"></i> Infants Without Bed
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                    {{ $cart_total_data->infants }} Infant
                                </td>
                                 <td>{{ $cart_total_data->currency }} {{ $cart_total_data->infant_price }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->without_acc_infant_total }}</td>
                           </tr>
                          @endif
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                             <?php
                                if($cart_res->Additional_services_names != '' && $cart_res->Additional_services_names != '[]'){
                                    $additional_services = json_decode($cart_res->Additional_services_names);
                            ?>
                                    <div class="cs-table cs-style1 cs-type1 cs-focus_bg">
                                      <h3 class="cs-primary_color cs-bold cs-f18">Additional Services</h3>
                                      <div class="cs-table_responsive">
                                        <table>
                                            <thead>
                                                 <tr>
                                                  <td class="cs-text_center cs-semi_bold" >Name</td>
                                                  <td class="cs-text_center cs-semi_bold">Price</td>
                                                  <td class="cs-text_center cs-semi_bold">Persons</td>
                                                  <td class="cs-text_center cs-semi_bold">Days</td>
                                                  <td class="cs-text_center cs-semi_bold">Dates</td>
                                                  <td class="cs-text_center cs-semi_bold">Total</td>
                                                </tr>
                                            </thead>
                                          <tbody>
                                              <?php 
                                                foreach($additional_services as $service_res){
                                               ?>
                                                <tr>
                                                  <td class="cs-text_center cs-semi_bold" >{{ $service_res->service }}</td>
                                                  <td class="cs-text_center cs-semi_bold">{{  $cart_res->currency." ".$service_res->service_price }}</td>
                                                  <td class="cs-text_center cs-semi_bold">{{ $service_res->person }}</td>
                                                  <td class="cs-text_center cs-semi_bold">{{ $service_res->Service_Days }}</td>
                                                  <td class="cs-text_center cs-semi_bold"><?php 
                                                                                if($service_res->dates != null){
                                                                                    echo $service_res->dates;
                                                                                }else{
                                                                                    echo '';
                                                                                }
                                                                          ?></td>
                                                  <td class="cs-text_center cs-semi_bold">{{ $cart_res->currency }} {{ $service_res->total_price }}</td>
                                                </tr>
                                              <?php 
                                                }
                                              ?>
                                          </tbody>
                                        </table>
                                      </div>
                                    </div>
                            <?php 
                                }
                            ?>
                            <div class="cs-table cs-style1 cs-mb20">
                              <div class="cs-table_responsive">
                                <table class="cs-border_less">
                                  <tbody>
                                    @isset($cart_total_data->price_without_disc)
                                     <tr>
                                      <td></td>
                                      <td class="cs-bold cs-primary_color cs-f18" style="float: right;;">Tour Price :</td>
                                      <td class="cs-bold cs-primary_color cs-f18 cs-text_right">{{ $currency_Symbol->currency_symbol }} {{ $cart_total_data->price_without_disc  }}</td>
                                    </tr>
                                    @endisset
                                    @isset($cart_total_data->discount_enter_am)
                                     <tr>
                                      <td></td>
                                      <td class="cs-bold cs-primary_color cs-f18" style="float: right;;">Discount Price <?php if($cart_total_data->discount_type == '%') echo " ( ".$cart_total_data->discount_enter_am." % )" ?>:</td>
                                      <td class="cs-bold cs-primary_color cs-f18 cs-text_right">{{ $currency_Symbol->currency_symbol }} {{ $cart_total_data->discount_Price  }}</td>
                                    </tr>
                                      @endisset
                                      
                                         @php 
                                                        $total = 0;
                                                
                                            @endphp
                                            @foreach($cart_data as $cart_res)
                                                @php 
                                                   $total = $total + $cart_res->price
                                                @endphp
                                            @endforeach
                                            
                                    <tr>
                                      <td></td>
                                      <td class="cs-bold cs-primary_color cs-f18" style="float: right;;">Total Amount:</td>
                                      <td class="cs-bold cs-primary_color cs-f18 cs-text_right">{{ $currency_Symbol->currency_symbol }} {{ $total }}</td>
                                    </tr>
            
                                    
                                  </tbody>
                                </table>
                              </div>
                            </div>
                            
                            <div class="cs-table cs-style1 cs-type1 cs-focus_bg">
                              <h3 class="cs-primary_color cs-bold cs-f18">Payment Details</h3>
                              <div class="cs-table_responsive">
                                <table>
                                  <tbody>
                                    @if($package_Type->pakage_type == 'tour')
                                        <tr>
                                          <td class="cs-text_center cs-semi_bold" >Package</td>
                                          <td class="cs-text_center cs-semi_bold">Paid On</td>
                                          <td class="cs-text_center cs-semi_bold">Total Amount</td>
                                          <td class="cs-text_center cs-semi_bold">Total Recieved</td>
                                          <!--<td class="cs-text_center cs-semi_bold">Remaining</td>-->
                                        </tr>
                                        
                                        @if(isset($package_Payments))
                                            @foreach($package_Payments as $value)
                                                <tr>
                                                    <td class="cs-primary_color">{{ $cart_res->tour_name }}</td>
                                                    <td class="cs-primary_color cs-text_center">
                                                        <?php
                                                        
                                                            $dateValue = strtotime($value->created_at);
                                                            $year = date('Y',$dateValue);
                                                            $monthName = date('F',$dateValue);
                                                            $monthNo = date('d',$dateValue);
                                                            $day = date('l',$dateValue);
                                                            printf("%s, %d, %s\n", $monthName, $monthNo, $year);
                                                        ?>
                                                    </td>
                                                    <td class="cs-primary_color cs-text_center">{{ $currency_Symbol->currency_symbol }} {{ $value->total_amount }}</td>
                                                    <td class="cs-primary_color cs-text_center">{{ $currency_Symbol->currency_symbol }} {{ $value->recieved_amount }}</td>
                                                    <!--<td class="cs-primary_color cs-text_center">{{ $currency_Symbol->currency_symbol }} {{ $value->remaining_amount }}</td>-->
                                                </tr>
                                            @endforeach
                                        @endif
                                    @elseif($package_Type->pakage_type == 'activity')
                                        <tr>
                                          <td class="cs-text_center cs-semi_bold" >Activity</td>
                                          <td class="cs-text_center cs-semi_bold">Paid On</td>
                                          <td class="cs-text_right cs-semi_bold">Total Amount</td>
                                          <td class="cs-text_center cs-semi_bold">Total Recieved</td>
                                          <td class="cs-text_center cs-semi_bold">Remaining</td>
                                        </tr>
                                        @if(isset($activity_Payments))
                                            @foreach($activity_Payments as $value)
                                                <tr>
                                                    <td class="cs-primary_color cs-text_center">{{ $cart_res->tour_name }}</td>
                                                    <td class="cs-primary_color cs-text_center">
                                                        <?php
                                                            $dateValue = strtotime($value->created_at);
                                                            $year = date('Y',$dateValue);
                                                            $monthName = date('F',$dateValue);
                                                            $monthNo = date('d',$dateValue);
                                                            printf("%s, %d, %s\n", $monthName, $monthNo, $year);
                                                        ?>
                                                    </td>
                                                    <td class="cs-primary_color cs-text_center">{{ $currency_Symbol->currency_symbol }} {{ $value->total_amount }}</td>
                                                    <td class="cs-primary_color cs-text_center">{{ $currency_Symbol->currency_symbol }} {{ $value->recieved_amount }}</td>
                                                    <!--<td class="cs-primary_color cs-text_center">{{ $currency_Symbol->currency_symbol }} {{ $value->remaining_amount }}</td>-->
                                                </tr>
                                            @endforeach
                                        @endif
                                    @endif
                                  </tbody>
                                </table>
                              </div>
                            </div>
                            
                            <div class="cs-table cs-style1 cs-type1">
                              <div class="cs-table_responsive">
                                <table>
                                  <tbody>
                                    <tr class="cs-table_baseline">
                                      <!--<td>-->
                                      <!--  <b class="cs-primary_color">Cost Per Person</b> <br>-->
                                      <!--  Per Person 66.66 per night included <br>fee & take.-->
                                      <!--</td>-->
                                        @if($package_Type->pakage_type == 'tour')
                                            <td>
                                                <p class="cs-mb5 cs-primary_color cs-semi_bold" style="margin-left: 80%;">Total Paid:</p>
                                                <p class="cs-m0 cs-primary_color cs-semi_bold" style="margin-left: 70%;">Total Balance Due:</p>
                                            </td>
                                            <td>
                                                <p class="cs-mb5 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ $recieved_package_Payments }}</p>
                                                @if(isset($total_package_Payments) || $total_package_Payments != null || $total_package_Payments != '' || $total_package_Payments != 0)
                                                    <p class="cs-m0 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ $total_package_Payments->total_amount - $recieved_package_Payments }}</p>
                                                @else
                                                    <p class="cs-m0 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ $recieved_package_Payments }}</p>
                                                @endif
                                            </td>
                                        @elseif($package_Type->pakage_type == 'activity')
                                            <td>
                                                <p class="cs-mb5 cs-primary_color cs-semi_bold" style="margin-left: 80%;">Total Paid:</p>
                                                <p class="cs-m0 cs-primary_color cs-semi_bold" style="margin-left: 70%;">Total Balance Due:</p>
                                            </td>
                                            <td>
                                                <p class="cs-mb5 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ $recieved_activity_Payments }}</p>
                                                @if(isset($total_package_Payments) && $total_package_Payments != null && $total_package_Payments != '' && $total_package_Payments != 0)
                                                    <p class="cs-m0 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ $total_package_Payments->total_amount - $recieved_activity_Payments }}</p>
                                                @else
                                                    <p class="cs-m0 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ $recieved_activity_Payments }}</p>
                                                @endif
                                            </td>
                                        @endif
                                    </tr> 
                                  </tbody>
                                </table>
                              </div>
                            </div>
                            
                        </div>
                        <p style="font-size: 14px;margin-top: 35px;"><b>Alhijaz Tours ltd is a acting agent on behalf of Sakeena Tours Atol Number 10941</b></p>
                    </div>
                </div>
                
            @endforeach
        @endif
        
        <?php  //dd('ok'); ?>
        
    </body>
</html>