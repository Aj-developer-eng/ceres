@include('template/frontend/userdashboard/includes/header')
	@yield('content')
@include('template/frontend/userdashboard/includes/newfooter1')