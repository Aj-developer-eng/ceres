 @include('template/frontend/userdashboard/includes/header')

	
	 @yield('content')
		
 @include('template/frontend/userdashboard/includes/footer_admin_search')