<!DOCTYPE html>
<html lang="en">

    

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        <title>Log In | Super Admin Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="" name="description" />
        <meta content="" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="{{asset('public/admin_package/assets/images/favicon.ico')}}">

        <!-- App css -->
        <link href="{{asset('public/admin_package/assets/css/icons.min.css')}}" rel="stylesheet" type="text/css" />
        <link href="{{asset('public/admin_package/assets/css/app.min.css')}}" rel="stylesheet" type="text/css" id="app-style"/>
<style>
@media screen and (max-width: 786px) {
    .auth-brand,
    .card-body,
    .align-items-center{
            display: block !important;
    }
    .card-body{
            padding: 10px;
            margin-top:0 !important;
    }
    .card-body .mt-5{
         margin-top:0 !important;
    }
   
</style>
    </head>

    <body class="authentication-bg pb-0" data-layout-config='{"darkMode":false}'>

        <div class="auth-fluid">
            <!--Auth fluid left content -->
            <div class="auth-fluid-form-box">
                <div class="align-items-center d-flex h-100">
                    
                    <!-- Logo -->
                    <div class="auth-brand text-center text-lg-start">
                        <a href="index.html" class="logo-dark">
                            <span><img src="{{asset('public/admin_package/frontend/images/logoAlhijaz.jpg')}}" style="width:95%;"></span>
                            <!--<span><img src="{{asset('public/admin_package/assets/images/logo1-1.png')}}" alt="" height="70"></span>-->
                        </a>
                        <!--<a href="index.html" class="logo-light">-->
                        <!--    <span><img src="{{asset('public/admin_package/assets/images/logo1-1.png')}}" alt="" height="70"></span>-->
                        <!--</a>-->
                    </div>
                    
                    <div class="card-body" style="margin-top:30%;">

                        <!-- title-->
                        <h4 class="mt-5">Sign In</h4>
                        <p class="text-muted mb-4">Enter your email address and password to access account.</p>

                        @if($errors->first('email'))
                        <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                                                    <strong></strong>  {{$errors->first('email')}}
                                                </div> 
                            
                        @endif
                        @if($errors->first('password'))
                        <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                                                    <strong></strong>   {{$errors->first('password')}}
                                                </div> 
                           
                        @endif
                        @if(session()->has('error'))
                        <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                                                    <strong></strong>     {{session('error')}}
                                                </div> 
                           
                        @endif
                        
                        <!-- form -->
                        <form action="{{URL::to('signin')}}" method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="mb-3">
                                <label for="emailaddress" class="form-label">Email address</label>
                                <input class="form-control" type="email" id="emailaddress" name="email" required="" placeholder="Enter your email">
                            </div>
                            <div class="mb-3">
                                <!--<a href="pages-recoverpw-2.html" class="text-muted float-end"><small>Forgot your password?</small></a>-->
                                <label for="password" class="form-label">Password</label>
                                <input class="form-control" type="password" required="" name="password" id="password" placeholder="Enter your password">
                            </div>
                            <div class="mb-3">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="checkbox-signin">
                                    <label class="form-check-label" for="checkbox-signin">Remember me</label>
                                </div>
                            </div>
                            <div class="d-grid mb-0 text-center">
                                <button class="btn btn-primary" name="submit" type="submit"><i class="mdi mdi-login"></i> Log In </button>
                            </div>
                            <!-- social-->
                            <div class="text-center mt-4">
                                <p class="text-muted font-16"></p>
                                <ul class="social-list list-inline mt-3">
                                    <li class="list-inline-item">
                                        <a href="https://www.facebook.com/alhijaztoursbirmingham" class="social-list-item border-primary text-primary"><i class="mdi mdi-facebook"></i></a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="https://alhijaztours.net/" class="social-list-item border-danger text-danger"><i class="mdi mdi-google"></i></a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="https://twitter.com/Alhijaztours2" class="social-list-item border-info text-info"><i class="mdi mdi-twitter"></i></a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="https://www.linkedin.com/company/alhijaztours/" class="social-list-item border-secondary text-secondary"><i class="mdi mdi-linkedin"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </form>
                        <!-- end form-->

                        <!-- Footer-->
                        <!--<footer class="footer footer-alt">-->
                        <!--    <p class="text-muted">Don't have an account? <a href="pages-register-2.html" class="text-muted ms-1"><b>Sign Up</b></a></p>-->
                        <!--</footer>-->

                    </div> <!-- end .card-body -->
                </div> <!-- end .align-items-center.d-flex.h-100-->
            </div>
            <!-- end auth-fluid-form-box-->

            <!-- Auth fluid right content -->
            <div class="auth-fluid-right text-center">
                <div class="auth-user-testimonial">
                    <h2 class="mb-3"></h2>
                    <p class="lead">
                    </p>
                    <p>
                       
                    </p>
                </div> <!-- end auth-user-testimonial-->
            </div>
            <!-- end Auth fluid right content -->
        </div>
        <!-- end auth-fluid-->

        <!-- bundle -->
        <script src="{{asset('public/admin_package/assets/js/vendor.min.js')}}"></script>
        <script src="{{asset('public/admin_package/assets/js/app.min.js')}}"></script>

    </body>



</html>