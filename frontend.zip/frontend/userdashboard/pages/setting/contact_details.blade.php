@extends('template/frontend/userdashboard/layout/default')
 @section('content')
 


 
<div class="card mt-5">
<div class="card-body">

<h4 class="header-title mb-3">Contact Details</h4>

<form action="{{URL::to('super_admin/submit_contact_details')}}" method="post" enctype="multipart/form-data">
@csrf
<div class="row">
<div class="col-xl-4">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">Company Name</label>
    <input type="text" id="simpleinput" name="company_name"  class="form-control" value="{{$data->company_name ?? ''}}">
</div>
</div>
<div class="col-xl-4">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">Email</label>
    <input type="email" id="simpleinput" name="email"  class="form-control" value="{{$data->email ?? ''}}">
</div>
</div>
<div class="col-xl-4">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">Contact Number</label>
    <input type="text" id="simpleinput" name="contact_number"  class="form-control" value="{{$data->contact_number ?? ''}}">
</div>
</div>

<div class="col-xl-4">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">IATA Number</label>
    <input type="text" id="simpleinput" name="iata_number" class="form-control"  value="{{$data->iata_number ?? ''}}">
</div>
</div>

<div class="col-xl-4">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">Company Registration Number</label>
    <input type="text" id="simpleinput" name="company_registration_number" class="form-control"  value="{{$data->company_registration_number ?? ''}}">
</div>
</div>

<div class="col-xl-4">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">ATOL Number</label>
    <input type="text" id="simpleinput" name="atol_number" class="form-control"  value="{{$data->atol_number ?? ''}}">
</div>
</div>



<div class="col-xl-6">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">Upload IATA Certificate</label>
    <input type="file" id="simpleinput" name="upload_iata_certificate"  class="form-control" value="{{$data->upload_iata_certificate ?? ''}}">
</div>
</div>

<div class="col-xl-6">
 <div class="mb-3 mt-4">
    <label for="simpleinput" class="form-label"></label>
  <a href="{{ config('img_url') }}/public/uploads/package_imgs/{{  $data->upload_iata_certificate ?? '' }}" target="_blank">View IATA Certificate</a>
</div>
</div>

<div class="col-xl-6">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">Upload ATOL Certificate</label>
    <input type="file" id="simpleinput" name="upload_atol_certificate"  class="form-control" value="">
</div>
</div>

<div class="col-xl-6">
 <div class="mb-3 mt-4">
    <label for="simpleinput" class="form-label"></label>
   <a href="{{ config('img_url') }}/public/uploads/package_imgs/{{  $data->upload_atol_certificate ?? '' }}" target="_blank">View ATOL Certificate</a>
</div>
</div>

<div class="col-xl-12">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">Address</label>
    <textarea name="address"  class="form-control">{{$data->address ?? ''}}</textarea>
   
</div>
</div>
</div>
 <div class="mb-3" style="margin-top: 30px;">
    <button class="btn btn-info" type="submit" name="submit">Submit</button>

</div>
</div>
</div>

@endsection