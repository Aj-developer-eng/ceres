

@extends('template/frontend/userdashboard/layout/default')
 @section('content')

 @if(session()->has('message'))
        <div class="alert alert-success alert-dismissible bg-success text-white border-0 fade show" role="alert">
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
    <strong>{{session()->get('success')}} </strong>
</div>
    @endif
    
    
    
   
    
    
    
    
    
    


        <div class="card mt-4">
<div class="card-header">
                <h4 class="card-title" id="myLargeModalLabel"></h4>
               
            </div>
            <div class="card-body ">
                <div class="mt-2 mb-4">
                    <a href="" class="text-success text-align-center">
                        <span>Edit Other Provider</span>
                    </a>
                </div>

              



      <form class="ps-3 pe-3" action="{{URL::to('super_admin/submit_edit_provider',[$data->id])}}"  method="post">
                 @csrf


                    <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Other Provider</label>
                                <select class="form-control" name="third_party_name" id="third_party_name">
                                    <option value="">Select Other Provider</option>
                                    <option value="all provider">All Provider</option>
                                    @if(isset($customer))
                                    @foreach($customer as $customer)
                                     <option attr="{{$customer->id}}" value="{{$customer->name}} {{$customer->lname}}">{{$customer->name}} {{$customer->lname}}</option>
                                     @endforeach
                                     @endif
                                </select>
                                
                               
                        
                            </div>
                            <input type="hidden" id="third_party_id" name="third_party_id" value="">
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Commission</label>
                               <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                           <input  type="text" required name="commission"  class="form-control" value="{{$data->commission}}">
                           <span class="input-group-btn input-group-append">
                               <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id=""></div></button>
                               </span>
                               </div>
                       
                            </div>
                            
                        </div>
                       
                    </div>
                    
               
                    <div class="mb-3">
                        <button name="submit" class="btn btn-primary" type="submit">Submit</button>
                    </div>

                </form>  
   






            </div>
        </div><!-- /.modal-content -->
    





<script src="https://code.jquery.com/jquery-3.5.1.js"></script>

















<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#example_1').DataTable({
           
           "order": [[ 0, 'desc' ], [ 1, 'desc' ]] 
        });
    } );
    
    
    
    $('.click_add').on('click',function(){
                
                $('#edit_role_form')[0].reset();
                $('#data_id').val($(this).attr('data-id'));
                $('#payment_gateway_title').val($(this).attr('data-title'));
                $('#email').val($(this).attr('data-email'));
                $('#primary_key').val($(this).attr('data-primary-key'));
                $('#auth_key').val($(this).attr('data-auth-key'));
                
                
            });
            
            $('#third_party_name').on('change',function(){
                
                var id = $(this).find('option:selected').attr('attr');

    $('#third_party_id').val(id);

                
                
            });
            
            
            
            
</script>

 
    @endsection