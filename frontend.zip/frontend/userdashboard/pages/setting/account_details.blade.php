@extends('template/frontend/userdashboard/layout/default')
 @section('content')
 


 
                                <div class="card mt-5">
                                    <div class="card-body">

<h4 class="header-title mb-3">Account Details</h4>

<form action="{{URL::to('super_admin/submit_edit_customer',[$data->id])}}" method="post" enctype="multipart/form-data">
@csrf
<div class="row">
<div class="col-xl-6">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">First Name</label>
    <input type="text" id="simpleinput" name="name" readonly="" class="form-control" value="{{$data->name}}">
</div>
</div>
<div class="col-xl-6">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">Last Name</label>
    <input type="text" id="simpleinput" name="lname" readonly="" class="form-control" value="{{$data->lname}}">
</div>
</div>
<div class="col-xl-6">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">Email</label>
    <input type="text" id="simpleinput" name="email" readonly="" class="form-control" value="{{$data->email}}">
</div>
</div>

<div class="col-xl-6">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">Phone No</label>
    <input type="text" id="simpleinput" name="phone" class="form-control" value="{{$data->phone}}">
</div>
</div>

<div class="col-xl-6">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">Company Name</label>
    <input type="text" id="simpleinput" name="company_name" class="form-control" readonly="" value="{{$data->company_name}}">
</div>
</div>
<div class="col-xl-6">
 <div class="mb-3">
    <label for="simpleinput" class="form-label">Webiste Address</label>
    <input type="text" id="simpleinput" name="webiste_Address" readonly="" class="form-control" value="{{$data->webiste_Address}}">
</div>
</div>

<div class="col-xl-6">
<div class="mb-3">
    <label for="simpleinput" class="form-label">Currency</label>
    
    <select name="currency_symbol" class="form-control">
        <option>Select Currency</option>
        @foreach($all_countries_currency as $all_countries_currency)
        <option value="{{$all_countries_currency->currency_symbol}}"  <?php if($data->currency_symbol == $all_countries_currency->currency_symbol) echo 'selected="selected"'; ?>    >{{$all_countries_currency->currency_symbol}} - {{$all_countries_currency->currency}}</option>
        @endforeach
    </select>
</div>
</div>

<div class="col-xl-6">
    <div class="mb-3">
        <label for="simpleinput" class="form-label">Account No.</label>
        <textarea name="account_No" value="{{ $data->account_No }}" class="form-control" >{{ $data->account_No }}</textarea>
    </div>
</div>

</div>
 <div class="mb-3" style="margin-top: 30px;">
    <button class="btn btn-info" type="submit" name="submit">Submit</button>

</div>
</div>
</div>

@endsection