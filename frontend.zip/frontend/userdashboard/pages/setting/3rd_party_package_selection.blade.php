

@extends('template/frontend/userdashboard/layout/default')
 @section('content')

 @if(session()->has('message'))
        <div class="alert alert-success alert-dismissible bg-success text-white border-0 fade show" role="alert">
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
    <strong>{{session()->get('success')}} </strong>
</div>
    @endif
    
    
    
    <div id="bs2-example-modal-lg" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel"></h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <div class="mt-2 mb-4">
                    <a href="" class="text-success">
                        <span>Edit Payment Gateway</span>
                    </a>
                </div>

              

                       <form class="ps-3 pe-3" action="{{URL::to('super_admin/edit_payment_gateways')}}" id="edit_role_form" method="post">
                 @csrf
                 
<input class="form-control"  type="hidden" id="data_id" name="id" value="">

                     <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Payment Gateway Title</label>
                                <input class="form-control"  type="text" id="payment_gateway_title" name="payment_gateway_title" value="">
                               
                        
                            </div>
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Email</label>
                               <input class="form-control"  type="email" id="email" name="email" value="">
                       
                            </div>
                            
                        </div>
                       
                    </div>
                     <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Primary Key</label>
                        <input class="form-control"  type="text" id="primary_key" name="primary_key" value=""> 
                            </div>
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Auth Key</label>
                        <input class="form-control"  type="text" id="auth_key" name="auth_key" value=""> 
                            </div>
                             
                            
                        </div>
                       
                    </div>
                   
                    
                    
                     
                    
                    
                    

                   

            
                    

                    <div class="mb-3">
                        <button name="submit" class="btn btn-primary" type="submit">submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


    <div class="row mt-5">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="header-title">Other Provider Commission</h4>
                                        <a style="float:right;" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#bs-example-modal-lg">Add Commission</a>
                                        <p class="text-muted font-14">
                                            
                                        </p>

                                        
                                        <div class="tab-content">
                                            <div class="tab-pane show active" id="buttons-table-preview">
                                                <table id="example" class="table table-striped dt-responsive nowrap w-100">
                                                    <thead>
                                                        <tr>
                                                       
                             <th>ID</th>
                         
                            <th>Other Provider Name</th>
                            <th>Commission</th>
                            <th>Status</th>
                            
                            <th>Action</th>
                            
                              
                                                        </tr>
                                                    </thead>
                                                
                                                
                              <tbody>
                                  @if(isset($data))
                            @foreach($data as $data)
                            <tr>
                                <td>{{$data->id}}</td>
                               
                                <td>
                                    @foreach($customer as $cust_res)
                                        @if($data->customer_id == $cust_res[0]->id)
                                            {{ $cust_res[0]->name." ".$cust_res[0]->lname }}
                                        @endif
                                    @endforeach
                                    
                                </td>
                                 <td>{{$data->commission}}%</td>
                                 <td>{{$data->status}}</td>
                                <td>
                                    @if($data->status == 'approve')
                                      <a href="{{ URL::to('super_admin/approve_display_pack/'.$data->id.'/pending') }}" class="btn btn-danger btn-sm">Pending</a>
                                    @else
                                      <a href="{{ URL::to('super_admin/approve_display_pack/'.$data->id.'/approve') }}" class="btn btn-success btn-sm">Approve</a>
                                    @endif
                                  
                                </td>
                               

                            </tr>
@endforeach
@endif


                                                    </tbody>
                                                </table>                                           
                                            </div> <!-- end preview-->
                                        
                                            
                                        </div> <!-- end tab-content-->
                                        
                                    </div> <!-- end card body-->
                                </div> <!-- end card -->
                            </div><!-- end col-->
                        </div> <!-- end row-->
            



<script src="https://code.jquery.com/jquery-3.5.1.js"></script>

















<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#example_1').DataTable({
           
           "order": [[ 0, 'desc' ], [ 1, 'desc' ]] 
        });
    } );
    
    
    
    $('.click_add').on('click',function(){
                
                $('#edit_role_form')[0].reset();
                $('#data_id').val($(this).attr('data-id'));
                $('#payment_gateway_title').val($(this).attr('data-title'));
                $('#email').val($(this).attr('data-email'));
                $('#primary_key').val($(this).attr('data-primary-key'));
                $('#auth_key').val($(this).attr('data-auth-key'));
                
                
            });
            
            $('#third_party_name').on('change',function(){
                
                var id = $(this).find('option:selected').attr('attr');

    $('#third_party_id').val(id);

                
                
            });
            
            
            
            
</script>

 
    @endsection