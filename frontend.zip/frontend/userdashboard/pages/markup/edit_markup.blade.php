@extends('template/frontend/userdashboard/layout/default')
@section('content')


@if(session()->has('message'))
<div class="alert alert-success alert-dismissible bg-success text-white border-0 fade show" role="alert">
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
    <strong>{{session('message')}} </strong>
</div>


        
    @endif
   <div>



<div class="tab-content__pane" id="password">
                        <div class="">
                            <!-- BEGIN: Horizontal Bar Chart -->
                            <div class="">
                                <div class="card mt-3">
                                    <div class="card-header">
                                        <h2 class="font-medium text-base mr-auto">
                                            Markup Hotels
                                        </h2>
                                    </div>
                                    <div class="card-body">
<form class="ps-3 pe-3" action="{{URL::to('super_admin/markup/update',[$markup->id])}}"  method="POST">
                 @csrf
       


                    <input type="hidden" name="provider" value="All">
 <input type="hidden" name="customer_id" value="4"> 
                    
                   
                     <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Select Markup Type</label>
                        <select class="form-control" name="markup_type">
                            <option>Select Markup Type</option>
                            <option <?php if($markup->markup_type == 'Percentage'){ echo 'selected'; } ?> value="Percentage">Percentage</option>
                            <option <?php if($markup->markup_type == 'Fixed'){ echo 'selected'; } ?> value="Fixed">Fixed</option>
                           
                        </select>
                            </div>
                            
                            
                            
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Markup</label>
                        <input class="form-control"  type="text" id="markup" name="markup_value" value="{{$markup->markup_value ?? ''}}"> 
                            </div>
                           
                        </div>
                       
                    </div>
                    
                     
                    
                    
                    

                   

            
                    

                    <div class="mb-3">
                        <button name="submit" class="btn btn-primary" type="submit">submit</button>
                    </div>

                </form>

                                   </div>
                                </div>
                            </div>
                            <!-- END: Horizontal Bar Chart -->
                        </div>

                    </div>
   
       
    </div>
    <!-- END: Content -->


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
           $('#percentage').on('change', function() {
                // alert( this.value );
                var v = ( this.value );
                // alert(v);
                $('#temp').val(v);
                });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function () {
           $('#percentage_1').on('change', function() {
                // alert( this.value );
                var v = ( this.value );
                // alert(v);
                $('#temp_1').val(v);
                });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function () {
           $('#percentage_2').on('change', function() {
                // alert( this.value );
                var v = ( this.value );
                // alert(v);
                $('#temp_2').val(v);
                });
        });
    </script>

@endsection
