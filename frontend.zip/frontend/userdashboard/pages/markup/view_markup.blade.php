<?php

 //$get_data_token=$get_data_hotel_token;
 
 
 
 

?>


@extends('template/frontend/userdashboard/layout/default')
 @section('content')
 

        <div class="row mt-5">
            @if(session()->has('message'))
<div class="alert alert-success alert-dismissible bg-success text-white border-0 fade show" role="alert" style="width: 400px;margin-left: 20px;">
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
    <strong>{{session('message')}} </strong>
</div>


        
    @endif
            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="header-title">Hotel Markup</h4>
                                        <p class="text-muted font-14" style="float:right;">
                                          <a href="{{URL::to('super_admin/markup/add')}}" class="btn btn-primary">Add Markup</a>  
                                        </p>

                                        
                                       
                                                <table id="example" class="table dt-responsive nowrap w-100">
                                                    <thead>
                                                        <tr>
                                                            <th>id</th>
                                                            <th>Provider</th>
                                                            <th>Customer</th>
                                                            <th>Markup Type</th>
                                                             <th>Markup Value</th>
                                                            <th>Eidt</th>
                                                             <th>Delete</th>
                                                            
                                                        </tr>
                                                    </thead>
                                                
                                                
                                                    <tbody>
                                                        <?php
                                                        foreach($markup->markup as $data_markup)
                                                        {
                                                        ?>
                                                        <tr>
                                                            <td>{{$data_markup->id}}</td>
                                                             <td>{{$data_markup->provider ?? ''}}</td>
                                                              <td>
                                                                  
                                                                 {{$markup->user_name ?? ''}}
                                                                  
                                                                  </td>
                                                               <td>{{$data_markup->markup_type ?? ''}}</td>
                                                                <td>{{$data_markup->markup_value ?? ''}}</td>
                                                                <td><a href="{{URL::to('super_admin/markup/edit')}}/{{$data_markup->id}}" class="btn btn-primary">Edit</a></td>
                                                                <td><a href="{{URL::to('super_admin/markup/delete')}}/{{$data_markup->id}}" class="btn btn-primary">Delete</a></td>
                                                        </tr>
                                                        <?php
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>                                           
                                            
                                        
                                    </div> <!-- end card body-->
                                </div> <!-- end card -->
                            </div><!-- end col-->
        </div>
  

                        
   
           
                  
                     
 @endsection