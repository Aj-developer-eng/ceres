@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php $currency=Session::get('currency_symbol'); ?>

<div class="dashboard-content">
   <div class="container-fluid" data-select2-id="select2-data-9-s82m">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        
                                    </div>
                                    <h4 class="page-title">Accounts</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row" data-select2-id="select2-data-8-e9ls">
                            <div class="col-12" data-select2-id="select2-data-7-wrgp">
                                <div class="card" data-select2-id="select2-data-6-xqyr">
                                    <div class="card-body" data-select2-id="select2-data-5-hczr">
                                        <div class="row mb-2">
                                            <div class="col-sm-5">
                                                <h4 class="page-title">Add Payments</h4>
                                            </div>
                                            <div class="col-sm-7">
                                                <div class="text-sm-end">
                                                    <a href="#" class="btn btn-success"><i class="mdi mdi-plus-circle me-2"></i>Payments List</a>
                                                </div>
                                            </div><!-- end col-->
                                        </div>
                
                                        <div class="row">
                                            <div class="col-md-12">
                                            <form action="{{ URL::to('super_admin/add_payment') }}" method="post">
                                                @csrf
                                                <div class="mt-3" data-select2-id="5">
                                                    <div class="row">
                                                        
                                                        <div class="col-md-2">
                                                            <label for="">Date</label>
                                                            <input type="date" id="current_date" name="current_date" value="2023-02-10" class="form-control">
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label for="">Payment Account</label>
                                                            <select name="payment_from" required="" id="payment_from" onchange="fetchCashAccountBalance()" class="form-control select2bs4">
                                                                @isset($cash_accounts)
                                                                    @foreach($cash_accounts as $cash_acc_res)
                                                                <option value="{{ $cash_acc_res->id }}">{{ $cash_acc_res->name }}</option>
                                                                    @endforeach
                                                                @endisset
                                                            </select>
                                                        </div>                              
                                                        <div class="col-md-2">
                                                            <label for="">Previous Balance</label>
                                                            <input type="number" id="account_balance" name="account_prev_bal" class="form-control" readonly="">
                                                        </div>
                                                        <div class="col-md-2">
                                                            <label for="">Updated Balance</label>
                                                            <input type="number" id="updated_balnc" name="updated_balnc" class="form-control" readonly="">
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label for="">Total Payments</label>
                                                            <input type="number" readonly="" id="total_payments" name="total_payments" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="row" data-select2-id="select2-data-4-at72">
                                                        <div class="col-md-2 mt-2">
                                                            <label for="">Payment To</label>
                                                            <select name="sel_data" id="sel_data" onchange="select_data()" class="form-control select2bs4">
                                                                <option value="-1">Select One</option>
                                                                <option value="hotel_supplier">Hotel Suppliers</option>
                                                                <option value="agents">Agents</option>
                                                                <option value="customer">Customer</option>
                                                                <!--<option value="customer">Customer</option>-->
                                                                <!--<option value="account">Different Account</option>-->
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3 mt-2">
                                                        <label for="" id="label_name">Select Account:</label>
                                                        <select name="sel_content" id="sel_content" data-toggle="select2" class="form-control select2">

                                                        </select>
                                                        </div>
                                                        
                                                        
                                                        <div class="col-md-2 mt-2">
                                                            <label for="">Balance</label>
                                                            <input type="number" name="" id="seelcted_content_bal" class="form-control" readonly="">
                                                        </div>
                                                        
                                                        <div class="col-md-2 mt-2" id="payable_balance_div" style="display:none;">
                                                            <label for="">Payable Balance</label>
                                                            <input type="number" name="" id="payable_balance" class="form-control" readonly="">
                                                        </div>
                                                        <div class="col-md-2 mt-2">
                                                            <label for="">Amount</label>
                                                            <input type="number" name="pay_amount" id="pay_amount" class="form-control">
                                                        </div>
                                                    
                                                        <div class="col-md-1">
                                                            <label for=""></label>
                                                            <button type="button" class="btn btn-success btn-md mt-2" id="enter_row_item" onclick="add_to_cart()">Add</button>
                                                        </div>
                                                    </div>
                                                    <div class="row my-5">
                                                            <table id="payments_table_id" class="table table-centered w-100 nowrap">
                                                                <thead class="table-light">
                                                                    <tr>
                                                                        <th>Received From</th>
                                                                        <th>Payments Person</th>
                                                                        <th>Amount</th>
                                                                        <th>Remarks</th>
                                                                        <th style="width: 85px;">Action</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="payments_table">
                                                                    
                                                                </tbody>
                                                            </table>

                                                     </div>
                                                    </div> 
                                                    <div class="row">
                                                        <div class="col-md-12 text-right">
                                                        <button type="submit" name="submit_payments" id="sub_pys" class="btn btn-primary">
                                                            Save
                                                        </button>
                                                        </div>
                                                    </div>  
                                                </form>
                                            </div>
                                        </div>
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col -->
                        </div>
                     
                        <!-- end row -->

                    </div>
</div>


@endsection
@section('scripts')
            <script>
                var cashAccounts = {!! json_encode($cash_accounts) !!};
                var agents = {!! json_encode($agents) !!};
                var customers = {!! json_encode($customers) !!};
                var hotelsSupplier = {!! json_encode($hotels_supplier_data) !!}
                
                // cashAccounts = JSON.parse(cashAccounts);
                // agents = JSON.parse(agents);
                
                console.log(cashAccounts);
                console.log(agents);
                console.log(hotelsSupplier);
                
                fetchCashAccountBalance = ()=>{
                    var accountId = $('#payment_from').val();
                    var total_payment = $('#total_payments').val();
                    cashAccounts.forEach((account)=>{
                        if(accountId == account['id']){
                           
                             $('#updated_balnc').val(account['balance']);
                            
                            var update_balance = +account['balance'] + +total_payment;
                            $('#account_balance').val(update_balance);
                        }
                    })
                   
                }
                
                 fetchCashAccountBalance();
                
                fetchAgentBalance = ()=>{
                    var agentId = $('#sel_content').val();
                  console.log('agen bal')
                    agents.forEach((agent)=>{
                        if(agentId == agent['id']){
                          
                             $('#seelcted_content_bal').val(agent['balance']);
                            
                        }
                    })
                   
                }
                
                fetchHotelSuppliersBalance = ()=>{
                    var supplierId = $('#sel_content').val();
                  console.log('agen bal')
                    hotelsSupplier.forEach((supplier)=>{
                        if(supplierId == supplier['id']){
                          
                             $('#seelcted_content_bal').val(supplier['balance']);
                             $('#payable_balance').val(supplier['payable']);
                            
                        }
                    })
                   
                }
                
                
                
                
                fetchCustomerBalance = ()=>{
                    var customerId = $('#sel_content').val();
                  console.log('agen bal')
                    customers.forEach((customer)=>{
                        if(customerId == customer['id']){
                          
                             $('#seelcted_content_bal').val(customer['balance']);
                            
                        }
                    })
                   
                }
                
                
                 $('#sel_content').on('change',function(){
                    var selectedContent = $('#sel_data').val();

                    if(selectedContent == 'agents'){
                        fetchAgentBalance();
                    }

                    if(selectedContent == 'customer'){
                        fetchCustomerBalance();
                    }
                    
                    if(selectedContent == 'hotel_supplier'){
                        fetchHotelSuppliersBalance();
                    }
                    
                    

                    if(selectedContent == 'account'){
                        fetchCashAccBalance();
                    }
                })
               
                
                select_data = ()=>{
                    var selectedContent = $('#sel_data').val();

                    $('#sel_content').html('');
                    if(selectedContent == 'agents'){
                        fetchAgentLists();
                    }

                    if(selectedContent == 'customer'){
                        fetchCustomerLists();
                    }
                    
                    if(selectedContent == 'hotel_supplier'){
                        fetchHotelSuppliersLists();
                        
                    }
                    
                    if(selectedContent == 'hotel_supplier'){
                        $('#payable_balance_div').css('display','block');
                    }else{
                        $('#payable_balance_div').css('display','none');
                    }
                    

                    // if(selectedContent == 'account'){
                    //     fetchAccountsLists();
                    // }
                    console.log('The content is '+selectedContent);
                }
                
                fetchAgentLists = ()=>{
                    
                    var agentsHtml = ``;
                      agents.forEach((agents)=>{
                           agentsHtml +=`<option value="${agents['id']}">${agents['agent_Name']}</option>`;
                         
                        })
                    
                    $('#sel_content').html(agentsHtml);
                                    fetchAgentBalance();
                }
                
                fetchHotelSuppliersLists = ()=>{
                    
                    var hotelSupHtml = ``;
                      hotelsSupplier.forEach((hotelSup)=>{
                           hotelSupHtml +=`<option value="${hotelSup['id']}">${hotelSup['room_supplier_name']}</option>`;
                         
                        })
                    
                    $('#sel_content').html(hotelSupHtml);
                                    fetchHotelSuppliersBalance();
                }
                
                
                 fetchCustomerLists = ()=>{
                    
                    var customerHtml = ``;
                      customers.forEach((customer)=>{
                           customerHtml +=`<option value="${customer['id']}">${customer['name']}</option>`;
                         
                        })
                    
                    $('#sel_content').html(customerHtml);
                                    fetchCustomerBalance();
                }
                
                 var trId = 1;
                add_to_cart = ()=>{
                    var selectedCrit = $('#sel_data').val();
                    if(selectedCrit != '-1'){
                        var payValue = $('#pay_amount').val();
                        if(payValue > 0){
                            var selectedContent = $('#sel_content').val();
                           
                            console.log('contn id is '+selectedContent+' catr '+selectedCrit)

                            var contentName = '';
                            var contentPerson = '';
                            if(selectedCrit == 'agents'){
                                console.log('Enter in agenst')
                                 agents.forEach((agent)=>{
                                     console.log(agent);
                                     console.log('on print ');
                                    if(selectedContent == agent['id']){
                                        
                                          contentName = agent['agent_Name'];
                                          contentPerson = 'Agent';
                                         
                                        console.log(contentName);
                                    }
                                })
                               
                            }
                            
                            
                            if(selectedCrit == 'hotel_supplier'){
                                console.log('Enter in agenst')
                                 hotelsSupplier.forEach((supplier)=>{
                                     console.log(supplier);
                                     console.log('on print ');
                                    if(selectedContent == supplier['id']){
                                        
                                          contentName = supplier['room_supplier_name'];
                                          contentPerson = 'Hotel Supplier';
                                         
                                        console.log(contentName);
                                    }
                                })
                               
                            }

                            if(selectedCrit == 'customer'){
                                 
                                
                                 customers.forEach((customer)=>{
                                     console.log(customer);
                                     console.log('on print ');
                                    if(selectedContent == customer['id']){
                                        
                                          contentName = customer['name'];
                                           contentPerson = 'Customer';
                                         
                                        console.log(contentName);
                                    }
                                })
                                
                            }

                            if(selectedCrit == 'account'){
                                 contentName = selectedContent['account_name'];
                                 contentPerson = 'Account';
                            }

                            



                            console.log(selectedContent);
                            var tableTrHtml = `<tr id="${trId}">
                                                    <td><input type="text" class="form-control" name="criteria[]" readonly="" value="${contentPerson}"></td>
                                                    <td><input type="text" class="form-control" name="content[]" readonly="" value="${contentName}"><input type="text" name="content_ids[]" hidden="" value="${selectedContent}"></td>
                                                    <td><input type="text" class="form-control enter_payment_inp" name="amount[]" required="" value="${payValue}"></td>
                                                    <td><input type="text" class="form-control" name="remarks[]"  value=""></td>
                                                    <td><button type="button" onclick="delete_row(${trId})" class="btn btn-sm btn-danger">X</button></td>
                                                </tr>`;

                            $('#payments_table').prepend(tableTrHtml).children('tr:first').append();
                            calculateTotalPayment();
                            $('#pay_amount').val('');
                        }else{
                            $('#alert_data').html('Please Enter Payment Amount');
                            $('#error-alert-modal').modal('show');
                        }
                    }else{
                        $('#alert_data').html('Please Select Any Content');
                        $('#error-alert-modal').modal('show');
                    }
                    
                     $('.enter_payment_inp').on('keyup change',function(){
                            console.log('key is up ');
                            calculateTotalPayment();
                        })
                }
                
                calculateTotalPayment = ()=>{
                // console.log('funciton is call ');
                
                var table = document.getElementById('payments_table');
        
                // console.log(table);
                    // LOOP THROUGH EACH ROW OF THE TABLE AFTER HEADER.
                    var totalPayments = 0;
                    var balnc=0;
                    
                    for (i = 0; i < table.rows.length; i++) {
                
                        // GET THE CELLS COLLECTION OF THE CURRENT ROW.
                        var objCells = table.rows.item(i).cells;
                        console.log(objCells);
                        // console.log(objCells.item(2).children[0].value);
                        var itemValue = objCells.item(2).children[0].value;
                        console.log("new coming value"+itemValue)
                        totalPayments = +totalPayments + +itemValue;
                        // console.log(total_recv_payments);
        
                        
                    }
                    console.log(totalPayments);
                    var currrt_balance= $('#account_balance').val();
                // // console.log("prevoius balnc"+currrt_balance);
                    balnc= currrt_balance - totalPayments;
        
                    
                    $('#updated_balnc').val(balnc);
                    $('#total_payments').val(totalPayments);
        
                    
                }
                
               
                
                delete_row = (id)=>{
                    console.log('button id is '+id);
                    $('#'+id+'').remove();
                    calculateTotalPayment();
                    
                }
            </script>
@stop