@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php $currency=Session::get('currency_symbol'); ?>

<div class="dashboard-content">
    
    <h3>Cash Accounts</h3>
  
        <div class="row">
            
            <div class="col-md-12 mb-4">
                @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" style="background-color:#d4edda;" role="alert">
                    {{ session('success') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif

                @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show" style="background-color:#f5cfcf;" role="alert">
                    {{ session('error') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif
            </div>
            
            <div class="offset-md-10 col-md-2">
                <button type="button" class="btn btn-success float-left" data-bs-toggle="modal" data-bs-target="#add_new_account">Add New</button>
            </div>
        </div>

   
   
    
    <div class="dashboard-content">
        <div class="row">
            <div class="col-lg-12 col-sm-12">
                <div class="dashboard-list-box dash-list margin-top-0">
                    <div class="row">
                        <div class="col-md-12">
                             <table id="scroll-horizontal-datatable"  class="display nowrap table  table-bordered" style="width:100%;">
                                <thead class="theme-bg-clr">
                                    <tr>
                                        <th>Sr</th>
                                        <!--<th>Agent Id</th>-->
                                        <!--<th>Customer Id</th>-->
                                        
                                         <th>Name</th>
                                        <th>Account No</th>
                                        <th>Opening Balance</th>
                                        <th>Balance</th>
                                        <th>Options</th>
                                    </tr>
                                </thead>
                                <tbody style="text-align: center;">
                                    @if(isset($data) && $data !== null && $data !== '')
                                        @php
                                            $x = 1;
                                        @endphp
                                        @foreach($data as $account_res)
                                                <tr>
                                                    <td>{{ $x++ }}</td>
                                                    <td>{{ $account_res->name ?? '' }}</td>
                                                    <td>{{ $account_res->account_no ?? ''}}</td>
                                                    <td>{{ $account_res->opening_balance ?? '' }}</td>
                                                    <td>{{ $account_res->balance }}</td>
                                                 
                                                    <td>
                                                       
                                                    </td>
                                                </tr>
                                        @endforeach
                                    @endif
                                </tbody>
                            </table>
                        </div>
                 
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="modal fade" id="add_new_account" tabindex="-1" aria-labelledby="exampleModalLabel" style="display: none;" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                 <div> 
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Manage Balance</h1>
                    
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <form action="{{ URL::to('super_admin/cash_accounts_add') }}" method="post" enctype="multipart/form-data">
                  @csrf
                    <div class="modal-body">
                          
                   
                      <div class="row">
                        <div class="col-12 mb-2">
                            
                            <label>Account Name</label>
                            <input type="text" name="name" class="form-control">
                        </div>
                       
                        <div class="col-md-6 mb-2">
                            <label>Account No.</label>
                            <input type="text" name="account_no" class="form-control">
                        </div>
                        
                         <div class="col-md-6 mb-2">
                            <label>Opening Balance</label>
                            <input type="text" name="opening_balance" class="form-control">
                        </div>
                       
                        
                      </div>
                   
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                  </div>
           </form>
              
            </div>
          </div>
        </div>
</div>


@endsection
@section('scripts')
@stop