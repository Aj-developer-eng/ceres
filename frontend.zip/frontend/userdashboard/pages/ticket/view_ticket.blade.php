

@extends('template/frontend/userdashboard/layout/default')
 @section('content')

 @if(session()->has('message'))
        <div x-data="{ show: true }" x-show="show"
             class="flex justify-between items-center bg-yellow-200 relative text-yellow-600 py-3 px-3 rounded-lg">
            <div>
                <span class="font-semibold text-yellow-700"> {{session()->get('message')}}</span>
            </div>
            <div>
                <button type="button" @click="show = false" class=" text-yellow-700">
                    <span class="text-2xl">&times;</span>
                </button>
            </div>
        </div>
    @endif
    
    
    

<div id="bs-example-modal-lg" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel"></h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <div class="mt-2 mb-4">
                    <a href="" class="text-success">
                        <span>Umrah Operator Detail</span>
                    </a>
                </div>

              

                       <form class="ps-3 pe-3" action="" method="post" id="myform">
                 @csrf
                  
   <input type="hidden" name="" id="txt_id">

                    <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Ticket Id</label>
                        <input class="form-control" readonly type="text" id="ticket_id" name="ticket_id" value=""> 
                            </div>
                            <input type="hidden"  value=""  id="agent_id"  name="agent_id" />
                            <div class="col-md-6">
                                 <label for="emailaddress" class="form-label">Company Name</label>
                        <input class="form-control" readonly type="text" id="company_name" name="company_name">
                            </div>
                        </div>
                       
                    </div>
                    <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Email</label>
                        <input class="form-control" readonly type="email" id="email" name="email"> 
                            </div>
                            <div class="col-md-6">
                                 <label for="emailaddress" class="form-label">Umrah Operator</label>
                        <input class="form-control" type="text" readonly id="umrah_operator" name="umrah_operator">
                            </div>
                        </div>
                       
                    </div>
                     <div class="mb-3">
                        <div class="row">
                            
                            <div class="col-md-12">
                                 <label for="emailaddress" class="form-label">phone</label>
                        <input class="form-control" readonly type="text" id="phone" name="phone">
                            </div>
                        </div>
                       
                    </div>
                     <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Ticket_Type</label>
                        <input class="form-control" readonly type="text" id="ticket_type" name="ticket_type"> 
                            </div>
                            <div class="col-md-6">
                                 <label for="emailaddress" class="form-label">Subject</label>
                        <input class="form-control" readonly type="text" id="subject" name="subject">
                            </div>
                        </div>
                       
                    </div>
                     <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Ticket Priorty</label>
                        <input class="form-control" readonly type="text" id="ticket_priorty" name="ticket_priorty"> 
                            </div>
                            <div class="col-md-6">
                                 <label for="emailaddress" class="form-label">Additinal Email</label>
                        <input class="form-control" readonly type="text" id="additinal_email" name="additinal_email">
                            </div>
                        </div>
                       
                    </div>
                     <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Description</label>
                        <input class="form-control" readonly type="text" id="description" name="description"> 
                            </div>
                            <div class="col-md-6">
                                 <label for="emailaddress" class="form-label">Status</label>
                        <select name="status" readonly id="city-list" class="form-control">
                            
                                    <option value="Pending">Pending</option>
                                    <option value="In-Process">In-Process</option>
                                    <option value="Resoloved">Resoloved</option>
                                </select>
                            </div>
                        </div>
                       
                    </div>
                    
                     <div class="mb-3">
                        <div class="row">
                            <div class="col-md-12">
                                <label for="emailaddress" class="form-label">Umrah Operator-</label>
                      <textarea cols="20" class="form-control"  value="" readonly="" id="diss_detail"  name="add_comment" ></textarea>
                            </div>
                            
                            
                        </div>
                       
                    </div>
                    <div class="mb-3">
                        <div class="row">
                           
                            
                            <div class="col-md-12">
                                <div class="">
                        <h5 class="mb-5" style="font-weight: bold;">Admin Disscussion</h5>
                       
                    </div>
                                 <label for="emailaddress" class="form-label">Add Discussion</label>
                         <textarea cols="20" class="form-control"  value=""  name="add_comment" ></textarea>
                            </div>
                        </div>
                       
                    </div>

                   

            
                    

                    <div class="mb-3">
                        <button name="submit" class="btn btn-primary" type="submit">submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


    
    


 











    <div class="row mt-5">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="header-title">Support Ticket</h4>
                                        <p class="text-muted font-14">
                                            
                                        </p>

                                        
                                        <div class="tab-content">
                                            <div class="tab-pane show active" id="buttons-table-preview">
                                                <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                                                    <thead>
                                                        <tr>
                                                        <th class="">ID</th>
                            <th class="">Ticket ID</th>
                            <th class="">Company Name</th>
                            <th class="">Umrah Operator</th>
                           
                            
                              <th class="">Ticket Type</th>
                              <th class="">Ticket Priorty</th>
                              <th class="">Detail</th>
                                                        </tr>
                                                    </thead>
                                                
                                                
                                                    <tbody>
                                                    @foreach($ticket as $ticket)
                            <tr>
                                <td class="">{{$ticket->id}}</td>
                                <td class="">{{$ticket->ticket_id}}</td>
                                <td class="">{{$ticket->company_name}} </td>
                                <td class="">{{$ticket->umrah_operator}}</td>
                                
                               
                                <td class="">{{$ticket->ticket_type}}</td>
                                <td class="">{{$ticket->ticket_priorty}}</td>
                                <td class="">
                                    <a data-bs-toggle="modal" data-bs-target="#bs-example-modal-lg" class="btn btn-info openModal"
                                    data-ticket_id="{{$ticket->ticket_id}}"
data-id="{{$ticket->id}}" data-company_name="{{
       $ticket->company_name 
   }}" data-umrah-operator="{{
       $ticket->umrah_operator 
   }}"
   data-umrah-operator="{{
       $ticket->umrah_operator 
   }}" data-email="{{
       $ticket->email 
   }}" data-phone="{{
       $ticket->phone 
   }}"
   data-ticket_type="{{
       $ticket->ticket_type 
   }}"
    data-ticket_priorty="{{
       $ticket->ticket_priorty 
   }}"
   data-subject="{{
       $ticket->subject 
   }}"
   data-description="{{
       $ticket->description 
   }}"
   data-additinal_email="{{
       $ticket->additinal_email 
   }}"
   data-ticket_id="{{
       $ticket->ticket_id 
   }}"
   data-diss_detail="{{
       $ticket->add_comment 
   }}"
   data-agent_id="{{
       $ticket->customer_id 
   }}"

   


                                    >
                                Detail
                                </a>
                            </td>
                               
                               

                            </tr>

@endforeach

                                                    </tbody>
                                                </table>                                           
                                            </div> <!-- end preview-->
                                        
                                            
                                        </div> <!-- end tab-content-->
                                        
                                    </div> <!-- end card body-->
                                </div> <!-- end card -->
                            </div><!-- end col-->
                        </div> <!-- end row-->
            



<script src="https://code.jquery.com/jquery-3.5.1.js"></script>

 <script type="text/javascript">
    $(document).ready(function(){
            $('.openModal').click(function(){
    var id = $(this).attr('data-id');
  var ticket_id = $(this).attr('data-ticket_id');
//   alert(ticket_id);
    $('#ticket_id').val(ticket_id);

    var title = $(this).attr('data-title');
    $('#title').val(title);
    var data_company_name = $(this).attr('data-company_name');
  
    $('#company_name').val(data_company_name);
    $('#company_name_1').html(data_company_name);

var data_umrah_operator = $(this).attr('data-umrah-operator');



    $('#umrah_operator').val(data_umrah_operator);

    var data_email = $(this).attr('data-email');
    $('#email').val(data_email);

    var data_email = $(this).attr('data-email');
    $('#email').val(data_email);

    var data_phone = $(this).attr('data-phone');
    $('#phone').val(data_phone);

    var data_ticket_type = $(this).attr('data-ticket_type');
    $('#ticket_type').val(data_ticket_type);

    var data_ticket_priorty = $(this).attr('data-ticket_priorty');
    $('#ticket_priorty').val(data_ticket_priorty);

    var data_subject = $(this).attr('data-subject');
    $('#subject').val(data_subject);

    var data_description = $(this).attr('data-description');
    $('#description').val(data_description);

var data_additinal_email = $(this).attr('data-additinal_email');
    $('#additinal_email').val(data_additinal_email);
     var data_ticket_id = $(this).attr('data-ticket_id');
    $('#ticket_id').val(data_ticket_id);

var data_diss_detail = $(this).attr('data-diss_detail');
    $('#diss_detail').val(data_diss_detail);
 
  
  var data_agent_id = $(this).attr('data-agent_id');
    $('#agent_id').val(data_agent_id);
    $('#txt_id').val(id);
    $("#myform").attr('action', '{{URL::to("super_admin/ticket_view/submit/")}}' + '/' + id);
    $('#bs-example-modal-lg').modal('toggle');
});

            });
        </script>















<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#example_1').DataTable({
           
           "order": [[ 0, 'desc' ], [ 1, 'desc' ]] 
        });
    } );
</script>

 
    @endsection