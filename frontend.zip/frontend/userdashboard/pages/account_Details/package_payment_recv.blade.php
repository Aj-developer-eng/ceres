@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php 
$currency=Session::get('currency_symbol');
//print_r($currency);die();
?>

<div class="content-wrapper">
    <section class="content" style="padding: 30px 50px 0px 50px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Tours</a></li>
                                <li class="breadcrumb-item active">Payments Received</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Payments Received</h4>
                    </div>
                </div>
            </div>
            
            <div class="row">
                
                <div class="col-md-12">
                    @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <strong>{{ session('error') }}</strong>
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    @endif
                    
                     @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                      <strong>{{ session('success') }}</strong>
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    @endif
                </div>
                
                <div class="col-12">
                    <!--<div class="card">-->
                        <!--<div class="card-body">-->
                            
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                </div>
                            </div>
                            
                            <!--<div class="">-->
                                <div class="row">
                                     <form action="{{ URL::to('super_admin/approve_customer_pay_multiple') }}" method="post">
                                         @csrf
                                         <button type="submit" class="btn btn-success">Approve</button>
                                    <input style="width: 200px;border-radius: 5px;border-block-color: red;height: 40px;" id="myInput" type="text" placeholder="Search..">
                                    <table class="table table-centered w-100 dt-responsive nowrap example1" id="example_1">
                                        <thead class="table-light">
                                            <tr role="row">
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Check</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">ID</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Invoice No</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Package ID</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Total Amount</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Payment Amount</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Transcation Type</th>
                                                <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Account No</th>
                                                <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Status</th>
                                                <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="myTable">
                                           
                                            @foreach($data as $data_res)
                                                <tr>
                                                    <td>
                                                        @if($data_res->status == 'pending')
                                                        <input type="checkbox" name="approve[]" value="{{ $data_res->id }}"></td>
                                                         @endif
                                                    <td>{{ $data_res->id }}</td>
                                                    <td>{{ $data_res->invoice_id }}</td>
                                                    <td>{{ $data_res->tour_id }}</td>
                                                    <td>{{$currency ?? ''}} {{ $data_res->price }}</td>
                                                    <td> {{$currency ?? ''}} {{ $data_res->payment_am }}</td>
                                                    <td><div>{{ $data_res->transcation_id }} <br> Email : <b>{{ $data_res->email }}</b></div></td>
                                                    <td>{{ $data_res->account_no }}</td>
                                                    <td>{{ $data_res->status }}</td>
                                                    <td>
                                                        @if($data_res->status == 'pending')
                                                        <a href="{{ URL::to('super_admin/approve_customer_pay/'.$data_res->id.'') }}" class="btn btn-success btn-sm">Confirmed</a>
                                                        @endif
                                                    </td>
                                                </tr>   
                                            @endforeach
                                          
                                        </tbody>
                                    </table>
                                      </form>
                                </div>
                            <!--</div>-->
                        <!--</div>-->
                    <!--</div>-->
                </div>
                
            </div>
        </div>
        
    </section>
</div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <script>
        $(document).ready(function(){
            $("#myInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#myTable tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>

@endsection
