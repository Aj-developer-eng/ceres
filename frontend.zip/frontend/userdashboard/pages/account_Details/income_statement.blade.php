@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php 
$currency=Session::get('currency_symbol');
//print_r($data);die();
?>

<div class="content-wrapper">
    <section class="content" style="padding: 30px 50px 0px 50px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Tours</a></li>
                                <li class="breadcrumb-item active">Outstandings</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Outstandings</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                </div>
                            </div>
                            <div class="col-sm-7">
                                <div class="text-sm-end">
                                </div>
                            </div>
                            <div class="table-responsive">
                                <div class="row">
                                    <table class="table table-centered w-100 dt-responsive nowrap" id="example1">
                                        <thead class="table-light">
                                            <tr role="row">
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">SR No.</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour ID</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Booking ID</th>
                                                <!--<th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Tour Name</th>-->
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Total</th>
                                                <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Recieved</th>
                                                <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="email: activate to sort column ascending" style="width: 175.073px;">Outstandings</th>
                                                <!--<th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Date: activate to sort column ascending" style="width: 138.958px;">Expense</th>-->
                                                <!--<th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Profit</th>-->
                                                <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending" style="width: 147.118px;">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i = 1; ?>
                                            @foreach($data as $value)
                                            <?php $id = $value->tourId;?>
                                                <?php $cart_total_data = json_decode($value->cart_total_data); ?>
                                                <tr role="row" class="odd">
                                                    <td>{{ $i }}</td>
                                                    <td>{{ $value->tour_id }}</td>
                                                    <td>{{ $value->invoice_no }}</td>
                                                    <td>{{ $currency }} {{ $value->total_amount ?? '0' }}</td>
                                                    <td>{{ $currency }} {{ $value->recieved_amount ?? '0' }}</td>
                                                    <td>{{ $currency }} {{ $value->remaining_amount ?? '0' }}</td>
                                                    <td>
                                                        <div class="dropdown card-widgets">
                                                            <a style="float: right;" href="#" class="dropdown-toggle arrow-none" data-bs-toggle="dropdown" aria-expanded="false">
                                                                <i class="dripicons-dots-3"></i>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end" style="">
                                                                <!--<a id="view_Payment_PopUp_{{ $id }}" onclick="view_Payment_PopUp1({{ $id }})"  data-id="{{ $id }}" class="dropdown-item"  data-bs-toggle="modal" data-bs-target="#view-Payment-PopUp">-->
                                                                <!--    <i class="mdi mdi-account"></i>-->
                                                                <!--    View Payment Details-->
                                                                <!--</a>-->
                                                                <a href="{{ URL::to('invoice')}}/{{$value->invoice_no}}" class="dropdown-item">
                                                                    <i class="mdi mdi-eye me-1"></i>View Voucher
                                                                </a>
                                                                <a href="{{ URL::to('invoice_package')}}/{{$value->invoice_no}}/{{$value->booking_id}}/{{$value->tourId}}" class="dropdown-item">
                                                                    <i class="mdi mdi-eye me-1"></i>View Invoice
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php $i++; ?>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>         
    </section>
</div>

    <!-- Modal -->
    <div class="modal fade" id="view-Payment-PopUp" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" style="margin-right: 30%;">
            <div class="modal-content" style="width: 130%;">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel" style="font-size: 30px;">Payment Detail</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <div class="modal-body" id="tour_data_detail">
                    <div class="table-responsive">
                        <div class="row">
                            <table class="table table-centered w-100 dt-responsive nowrap" id="example1">
                                <thead>
                                    <tr role="row">
                                        <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">SR No.</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            1
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function view_Payment_PopUp1(id){
            console.log('ok');
            // $('#Tour_data').empty();
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
                url: 'fetch_payment_data1',
                method: "post",
                data: {
                    _token: CSRF_TOKEN,
                    id: id,
                },
                success: function (response) {
                    var data = response;
                    var a = data['data'];
                    console.log('a : '+a);
                }
            });
        }
    </script>

@endsection
