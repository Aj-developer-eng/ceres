@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php $currency=Session::get('currency_symbol'); ?>

    <div class="modal fade" id="exampleModalCenterATA" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document" style="margin-top: 15%;">
            <div class="modal-content">
                <div class="modal-header" style="background-color: black;">
                    <h5 class="modal-title" id="exampleModalLongTitle"></h5>
                    <button type="button" class="btn-block-option" data-bs-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="col-12">
                    <h3 class="text-center">Details</h3>
                </div>
                <div id="hidden_ATA"></div>
                <div id="hidden_AHT"></div>
                
                <div class="row" style="padding: 10px">
                    <div class="col-xl-6">
                        <label for="" class="form-label"><b>Choose City</b></label>
                        <select onchange="append_PriceATA()" class="form-control" id="selected_cityIDATA" name="selected_city"></select>
                    </div>
                </div>
                <table id="tableATA" class="js-table-sections table table-hover js-table-sections-enabled" style="display:none;">
                    <thead>
                        <tr>
                            <th width="15%">Hotel Name</th>
                            <th width="15%">Hotel Type</th>
                            <th width="15%">Accomodation Cost</th>
                            <th width="15%">Flights Cost</th>
                            <th width="15%">Transportation Cost</th>
                            <th width="15%">Visa Cost</th>
                            <th width="15%">Total Cost</th>
                            <!--<th width="15%">Total Payable</th>-->
                        </tr>
                    </thead>
                    <tbody class="js-table-sections-header chintu-click">
                        <tr>
                            <td id="hotel_Name"></td>
                            <td id="hotel_Type"></td>
                            <td id="accomodation_Cost"></td>
                            <td id="flights_Cost"></td>
                            <td id="transportation_Cost"></td>
                            <td id="visa_Cost"></td>
                            <td id="total_Cost"></td>
                            <!--<td id="total_Payable"></td>-->
                        </tr>
                    </tbody>
                </table>
    
                <div class="modal-footer">
                  <button type="button" class="btn btn-alt-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Accounts</a></li>
                            <li class="breadcrumb-item active">Stats</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Stats</h4>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-xl-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title mb-4">Package Stats Chart</h4>
                        <div class="info-box">
                            <div id="piechart1"></div>
                            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
                            <script type="text/javascript">
                                google.charts.load('current', {'packages':['corechart']});
                                google.charts.setOnLoadCallback(drawChart);
                                
                                function drawChart() {
                                    var data = google.visualization.arrayToDataTable([
                                        ['Task', 'Tours'],
                                        ['Total', <?php echo $total_Amount;  ?>],
                                        ['Recieved', <?php echo $recieved_Amount;  ?>],
                                        ['Outstandings', <?php echo $total_Amount - $recieved_Amount;  ?>],
                                    ]);
                                    var options = {'width':500, 'height':500};
                                    
                                    var chart = new google.visualization.PieChart(document.getElementById('piechart1'));
                                    chart.draw(data, options);
                                }
                            </script>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title mb-4">Activity Stats Chart</h4>
                        <div class="info-box">
                            <div id="piechart2"></div>
                            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
                            <script type="text/javascript">
                                google.charts.load('current', {'packages':['corechart']});
                                google.charts.setOnLoadCallback(drawChart);
                                
                                function drawChart() {
                                    var data = google.visualization.arrayToDataTable([
                                        ['Task', 'Stats'],
                                        ['Total', <?php echo $total_Amount_Activity;  ?>],
                                        ['Recieved', <?php echo $recieved_Amount_Activity;  ?>],
                                        ['Outstandings', <?php echo $total_Amount_Activity - $recieved_Amount_Activity;  ?>],
                                    ]);
                                    var options = {'width':500, 'height':500};
                                    
                                    var chart = new google.visualization.PieChart(document.getElementById('piechart2'));
                                    chart.draw(data, options);
                                }
                            </script>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Accounts</a></li>
                            <li class="breadcrumb-item active">Paybale Stats</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Paybale Stats</h4>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <div class="info-box">
                            <div class="table-responsive">
                                <div class="row">
                                    <table class="table table-centered w-100 dt-responsive nowrap" id="example1" style="text-align:center;width: 1095px;font-size: 12px;">
                                        <thead class="table-light">
                                            <tr role="row">
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">No Of Pax</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Booked Pax</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Hotel Payable</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Flights Payable</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Transportation Payable</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Visa Payable</th>
                                                <th class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Total Payable</th>
                                                <th class="d-none d-sm-table-cell sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Phone: activate to sort column ascending">Action</th>
                                                <!--<th style="text-align: center;" class="d-none d-sm-table-cell sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 180.035px;">Total Profit</th>-->
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @if(isset($data1))
                                            
                                                @foreach($data1 as $value)
                                                    <?php 
                                                            $accomodation_details         = json_decode($value->accomodation_details);
                                                            $flight_Details               = json_decode($value->flights_details);
                                                            $transportation_details       = json_decode($value->transportation_details);
                                                            // $markup_details = json_decode($value->markup_details);
                                                    ?>
                                                    <tr role="row" class="odd" style="text-align: center;">
                                                    
                                                        <!--No Of Pax-->
                                                        <td>
                                                            {{ $value->no_of_pax_days }}
                                                        </td>
                                                        
                                                        <!--Booked Pax-->
                                                        <td>
                                                            <span class="badge bg-info" style="font-size: 15px" onclick="booked_tour_span({{ $value->id }})" 
                                                            id="booked_tour_span_{{ $value->id }}" data-id="{{ $value->id }}">
                                                                View Booked Pax
                                                            </span>
                                                        </td>
                                                        
                                                        <!--Accomodation-->
                                                        <td>
                                                            @if(isset($accomodation_details))
                                                                @foreach($accomodation_details as $accDetails)
                                                                <?php $acc_total_amount = $accDetails->acc_total_amount ?>
                                                                    <div>
                                                                        @if(isset($acc_total_amount) && $acc_total_amount !== null && $acc_total_amount !== 0 && $acc_total_amount !== '')
                                                                            {{ $accDetails->hotel_city_name }} 
                                                                            Double Cost :
                                                                            <?php echo $currency; ?>
                                                                            <b>{{ $acc_total_amount }}</b>
                                                                        @else
                                                                            {{ $accDetails->hotel_city_name }} 
                                                                            Double Cost :
                                                                            <?php echo $currency; ?>0
                                                                        @endif
                                                                    </div>
                                                                @endforeach
                                                            @endif
                                                        </td>
                                                        
                                                        <!--Flights-->
                                                        <td>
                                                            @if(isset($flight_Details))
                                                                <?php echo $currency; ?>
                                                                {{ $flight_Details->flights_per_person_price }}
                                                            @endif
                                                        </td>
                                                        
                                                        <!--Transportation-->
                                                        <td>    
                                                            @if(isset($transportation_details))
                                                                <?php echo $currency; ?>
                                                                {{ $transportation_details->transportation_price_per_person }}
                                                            @endif
                                                        </td>
                                                        
                                                        <!--Visa-->
                                                        <td>
                                                            <?php echo $currency; ?>
                                                            {{ $value->visa_fee }}
                                                        </td>
                                                        
                                                        <!--Total Payable-->
                                                        <td>
                                                            <div>DOUBLE PAYABLE :
                                                            <?php echo $currency; ?>
                                                            <b>{{ $value->double_grand_total_amount ?? '0' }}</b></div>
                                                            
                                                            <div>TRIPLE PAYABLE :
                                                            <?php echo $currency; ?>
                                                            <b>{{ $value->triple_grand_total_amount ?? '0' }}</b></div>
                                                            
                                                            <div>QUAD PAYABLE :
                                                            <?php echo $currency; ?>
                                                            <b>{{ $value->quad_grand_total_amount ?? '0' }}</b></div>
                                                        </td>
                                                        
                                                        <!--Actions-->
                                                        <td>
                                                            <div class="dropdown card-widgets">
                                                                <a style="float: right;" href="#" class="dropdown-toggle arrow-none" data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <i class="dripicons-dots-3"></i>
                                                                </a>
                                                                <div class="dropdown-menu dropdown-menu-end" style="">
                                                                    <a data-bs-toggle="modal" data-bs-target="#exampleModalCenterATA"  data-id="{{ $value->id }}" acc_hotel_Type="Double" class="dropdown-item fetchorderdetails detail-btnATA" data-uniqid="b5c7a7ced6fda207e232">
                                                                        <i class="mdi mdi-eye me-1"></i>
                                                                        Double Accomodation Cost
                                                                    </a>
                                                                    <a data-bs-toggle="modal" data-bs-target="#exampleModalCenterATA"  data-id="{{ $value->id }}" acc_hotel_Type="Triple" class="dropdown-item fetchorderdetails detail-btnATA" data-uniqid="b5c7a7ced6fda207e232">
                                                                        <i class="mdi mdi-eye me-1"></i>
                                                                        Triple Accomodation Cost
                                                                    </a>
                                                                    <a data-bs-toggle="modal" data-bs-target="#exampleModalCenterATA"  data-id="{{ $value->id }}" acc_hotel_Type="Quad" class="dropdown-item fetchorderdetails detail-btnATA" data-uniqid="b5c7a7ced6fda207e232">
                                                                        <i class="mdi mdi-eye me-1"></i>
                                                                        Quad Accomodation Cost
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                
                                            @endif
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        //More Tour Details
        function booked_tour_span(id){
            $('#booked_tour_span').empty();
            const ids = $('#booked_tour_span_'+id+'').attr('data-id');
            $.ajax({
                url: 'more_Tour_Details1/'+ids,
                type: 'GET',
                data: {
                    "id": ids
                },
                success:function(data) {
                    var a = JSON.parse(data);
                    var adults      = a['adults'];
                    var childs      = a['childs'];
                    var booked_tour = parseFloat(adults) + parseFloat(childs);
                    $('#booked_tour_span_'+id+'').html(booked_tour);
                },
            });
        }
        
        // 
        $('.detail-btnATA').click(function() {
            
            $("#hotel_Name").empty();
            $("#hotel_Type").empty();
            $("#accomodation_Cost").empty();
            $("#flights_Cost").empty();
            $("#transportation_Cost").empty();
            $("#visa_Cost").empty();
            $("#total_Cost").empty();
            $("#total_Payable").empty();
            
            $("#selected_cityIDATA").empty();
            $('#tableATA').css('display','none');
            $("#hidden_ATA").empty();
            $("#hidden_AHT").empty();
            
            const id             = $(this).attr('data-id');
            const acc_hotel_Type = $(this).attr('acc_hotel_Type');
            
            var hidden_ATA = `<input type="hidden" value="${id}" id="id_ATA">`;
            $("#hidden_ATA").append(hidden_ATA);
            
            var hidden_AHT = `<input type="hidden" value="${acc_hotel_Type}" id="h_Type">`;
            $("#hidden_AHT").append(hidden_AHT);
            
            $.ajax({
                url: 'transportation_Pay/'+id,
                type: 'GET',
                data: {
                    "id": id
                },
                success:function(data) {
                    var data1                       = data['data'];
                    var paid_accomodation           = data['paid_accomodation'];
                    var no_of_pax_days              = data1['no_of_pax_days'];
                    var accomodation_details        = JSON.parse(data1['accomodation_details']);
                    
                    var choose_city = `<option value="Choose City...">Choose City...</option>`;
                    $("#selected_cityIDATA").append(choose_city);
                    var cityNO = 1;
                    $.each(accomodation_details, function(key, value) {
                        var hotel_city_name = value.hotel_city_name;
                        var city_append  = `<option attr="${hotel_city_name}" id="hotel_city_name_${cityNO}" value="${hotel_city_name}">${hotel_city_name}</option>`;
                        $("#selected_cityIDATA").append(city_append);
                       
                        cityNO = cityNO + 1;
                    });
                    
                }
            });
        });
        
        // 
        function append_PriceATA(id){
        
            $('#tableATA').css('display','');
            $("#hotel_Name").empty();
            $("#hotel_Type").empty();
            $("#accomodation_Cost").empty();
            $("#flights_Cost").empty();
            $("#transportation_Cost").empty();
            $("#visa_Cost").empty();
            $("#total_Cost").empty();
            // $("#total_Payable").empty();
            
            var selected_city = $('#selected_cityIDATA').find('option:selected').attr('attr');
            var t_Id    = $('#id_ATA').val();
            var h_Type  = $('#h_Type').val();
            
            $.ajax({
                url:"{{URL::to('/acc_Pay')}}" + '/' + selected_city + '/' + t_Id,
                type: 'GET',
                data: {
                    "selected_city": selected_city,
                    "t_Id": t_Id
                },
                success:function(data) {
                    var data1                       = data['data'];
                    var paid_accomodation           = data['paid_accomodation'];
                    var no_of_pax_days              = data1['no_of_pax_days'];
                    var Total_Cost                  = 0;
                    var acc_hotel_name              = '';
                    // Accomodation
                    var accomodation_details        = JSON.parse(data1['accomodation_details']);
                    $.each(accomodation_details, function(key, value) {
                        var hotel_city_name = value.hotel_city_name;
                        
                        if(hotel_city_name == selected_city){
                            acc_hotel_name                  = value.acc_hotel_name;
                            var acc_type                    = value.acc_type;
                            var acc_pax                     = value.acc_pax;
                            var acc_total_amount_per_person = value.acc_total_amount;
                            
                            if(acc_type == h_Type){
                                // var acc_total_amount          = parseFloat(acc_total_amount_per_person) * parseFloat(acc_pax);
                                var acc_total_amount          = parseFloat(acc_total_amount_per_person);
                                var total_accomodation_amount = acc_total_amount.toFixed(2);
                                $("#hotel_Name").html(acc_hotel_name);
                                $("#hotel_Type").html(acc_type);
                                $("#accomodation_Cost").html(total_accomodation_amount);
                                Total_Cost = parseFloat(Total_Cost) + parseFloat(acc_total_amount); 
                            }else{
                                console.log('error');
                            }
                        }
                    });
                    
                    var more_acc_hotel_name = acc_hotel_name;
                    // More Accomodation
                    var accomodation_details_more   = JSON.parse(data1['accomodation_details_more']);
                    $.each(accomodation_details_more, function(key, value) {
                        
                        var more_hotel_city = value.more_hotel_city;
                        if(more_hotel_city == selected_city){
                            var more_acc_type                    = value.more_acc_type;
                            var more_acc_pax                     = value.more_acc_pax
                            var more_acc_total_amount_per_person = value.more_acc_total_amount;
                            if(more_acc_type == h_Type){
                                // var acc_total_amount            = parseFloat(more_acc_total_amount_per_person) * parseFloat(more_acc_pax);
                                var acc_total_amount            = parseFloat(more_acc_total_amount_per_person);
                                var total_accomodation_amount   = acc_total_amount.toFixed(2);
                                $("#hotel_Name").html(more_acc_hotel_name);
                                $("#hotel_Type").html(more_acc_type);
                                $("#accomodation_Cost").html(total_accomodation_amount);
                                Total_Cost = parseFloat(Total_Cost) + parseFloat(acc_total_amount); 
                            }else{
                                console.log('error');
                            }
                        }
                    });
                    
                    // Flights
                    var flights_details        = JSON.parse(data1['flights_details']);
                    var flights_price_per_pax  = flights_details['flights_per_person_price'];
                    $("#flights_Cost").html(flights_price_per_pax);
                    
                    // Transportation
                    var transportation_details          = JSON.parse(data1['transportation_details']);
                    var transportation_price_per_person = transportation_details['transportation_price_per_person'];
                    $("#transportation_Cost").html(transportation_price_per_person);
                    
                    // Visa
                    var visa_fee = data1['visa_fee'];
                    $("#visa_Cost").html(visa_fee);
                    
                    // Total Cost
                    var final_cost = parseFloat(Total_Cost) +parseFloat(visa_fee) + parseFloat(transportation_price_per_person) + parseFloat(flights_price_per_pax);
                    $("#total_Cost").html(final_cost);
                }
            });
        }
    </script>

@endsection
