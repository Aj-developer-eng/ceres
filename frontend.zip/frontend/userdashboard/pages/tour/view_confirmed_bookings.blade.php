@extends('template/frontend/userdashboard/layout/default')
@section('content')

    <style>
        .nav-link{
          color: #575757;
          font-size: 18px;
        }
    </style>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <section class="content">
            <div class="container-fluid">
                
                <div class="row">
                    <div class="col-12">
                      <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Tour Bookings</a></li>
                                <li class="breadcrumb-item active">Confirmed Bookings</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Confirmed Bookings</h4>
                      </div>
                    </div>
                </div>
    
                <div class="row">
                    <div class="col-12">
                        @if(session('error'))
                            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="alert_hide">
                              <strong> {{ session('error') }}</strong>
                              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        @endif
                        
                       
    
                            
                          
                                    
                                    
                                     <div class="table-responsive">
                                    <div id="example_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer"> 
                                       
                                            
                                            <input style="    background: transparent; border: 1px solid #ddd; margin-bottom:10px;" id="myInput" type="text" placeholder="Search..">
                                            
                                            <table class="table  nowrap example1" id="example_1">
                                                <thead class="table-light">
                                    
                                    
                                    
                                    
                                    
                                    <tr>
                                        <th>Tour ID</th>
                                        <th>Booking ID</th>
                                        <th style="text-align: center;">Invoice No.</th>
                                        <th>Customer Name</th>
                                        <th>Package Title</th>
                                        <th>Adults</th>
                                        <th>Childs</th>
                                        <th>Total Amount</th>
                                        <th>Payment Status</th>
                                        <th>Status</th>
                                        <th style="width: 85px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="myTable">
                                    @foreach ($data as $key => $value)
                                        @if($value->confirm == 1)
                                            <?php
                                                $date4days = date('Y-m-d',strtotime($value->created_at. ' + 2 days'));
                                                $currdate = date('Y-m-d');
                                            ?> 
                                            <tr>
                                                <td>{{ $value->tour_id }}</td>
                                                <td class="P_Id">{{ $value->booking_id }}</td>
                                                <td>{{ $value->invoice_no }}</td>
                                                <td>{{ $value->passenger_name }}</td>
                                                <td>{{ $value->tour_name }}</td>
                                                <td>
                                                    <?php 
                                                        if($value->adults > 0){ 
                                                            $adults = $value->adults;
                                                        }else{ 
                                                            $adults = 0;
                                                        }
                                                    ?>
                                                    <?php 
                                                        if($value->double_adults == null || $value->double_adults == ''){
                                                            $double_adults = 0;
                                                        }else{
                                                            $double_adults = $value->double_adults;
                                                        }
                                                    ?>
                                                    <?php 
                                                        if($value->triple_adults == null || $value->triple_adults == ''){
                                                            $triple_adults = 0;
                                                        }else{
                                                            $triple_adults = $value->triple_adults;
                                                        }
                                                    ?>
                                                    <?php 
                                                        if($value->quad_adults == null || $value->quad_adults == ''){
                                                            $quad_adults = 0;
                                                        }else{
                                                            $quad_adults   = $value->quad_adults;
                                                        }
                                                    ?>
                                                    <?php if(isset($value->without_acc_adults)){ ?>
                                                            <i class="mdi mdi-human-male-female" style="font-size: 16px;">{{ $adults + $double_adults + $triple_adults + $quad_adults + $value->without_acc_adults }}</i>
                                                    <?php }else{ ?>
                                                            <i class="mdi mdi-human-male-female" style="font-size: 16px;">{{ $adults + $double_adults + $triple_adults + $quad_adults }}</i>
                                                    <?php }?>
                                                </td>
                                                <td>
                                                    <?php 
                                                        if($value->childs > 0){ 
                                                            $childs = $value->childs;
                                                        }else{ 
                                                            $childs = 0;
                                                        }
                                                    ?>
                                                    <?php   
                                                        $cart_total_data = json_decode($value->cart_total_data);
                                                        // dd($cart_total_data->children);
                                                        if(isset($cart_total_data) && $cart_total_data != null && $cart_total_data != ''){ 
                                                    ?>
                                                            <?php 
                                                                if($cart_total_data->double_childs = null){
                                                                    $double_childs = 0;
                                                                }else{
                                                                    $double_childs = $cart_total_data->double_childs;
                                                                }
                                                            ?>
                                                            <?php 
                                                                if($cart_total_data->triple_childs = null){
                                                                    $triple_childs = 0;
                                                                }else{
                                                                    $triple_childs = $cart_total_data->triple_childs;
                                                                }
                                                            ?>
                                                            <?php 
                                                                if($cart_total_data->quad_childs = null){
                                                                    $quad_childs = 0;
                                                                }else{
                                                                    $quad_childs = $cart_total_data->quad_childs;
                                                                }
                                                            ?>
                                                            <?php 
                                                                if($cart_total_data->children == null || $cart_total_data->children == ''){
                                                                    $childrens = 0;
                                                                }else{
                                                                    $childrens = $cart_total_data->children;
                                                                }
                                                            ?>
                                                            <i class="mdi mdi-human-male-female" style="font-size: 20px;">
                                                                {{ $childrens + $childs + $double_childs + $triple_childs + $quad_childs }}
                                                            </i>
                                                    <?php }else{ ?>
                                                            <i class="mdi mdi-human-male-female" style="font-size: 20px;">
                                                                {{ $childs }}
                                                            </i>
                                                    <?php } ?>
                                                </td>
                                                <td>{{ $value->price }}</td>
                                                <td class="payment_status{{ $value->booking_id }}"></td>
                                                @if($value->confirm == 1)
                                                  <td><span class="badge bg-success" style="font-size: 15px">Confirmed</span></td>
                                                @else
                                                  <td><span class="badge btn-danger" style="font-size: 15px">Tentative</span></td>
                                                @endif
                                                <td>
                                                  <div class="dropdown card-widgets">
                                                    <a style="float: right;" href="#" class="dropdown-toggle arrow-none" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i class="dripicons-dots-3"></i>
                                                    </a> 
                                                    <div class="dropdown-menu dropdown-menu-end" style="">
                                                        <a href="{{ URL::to('super_admin/view_booking_payment')}}/{{$value->booking_id}}/{{$value->tour_id}}" class="dropdown-item"><i class="mdi mdi-eye me-1"></i>View Payment</a>
                                                        <a href="{{URL::to('invoice_package')}}/{{$value->invoice_no}}/{{$value->booking_id}}/{{$value->tour_id}}" class="dropdown-item"><i class="mdi mdi-eye me-1"></i>View Booking Details</a>
                                                        <a href="{{URL::to('invoice')}}/{{$value->invoice_no}}" class="dropdown-item"><i class="mdi mdi-eye me-1"></i>View Itinerary  Details</a>
                                                        <a href="{{ route('view_booking_customer_details',$value->booking_id) }}" class="dropdown-item"><i class="mdi mdi-account"></i>Customer Details</a>
                                                        @if($value->confirm == 1)
                                                            <!--<div class="cancel_div_dropdown{{ $value->booking_id }}">-->
                                                            <!--    <a href="#" class="dropdown-item"><i class="mdi mdi-check-circle"></i>Do yo Want to Cancel Booking?</a>-->
                                                            <!--</div>-->
                                                        @else
                                                            <div class="confirmed_div_dropdown{{ $value->booking_id }}">
                                                                <a href="{{ route('confirmed_tour_booking',$value->booking_id) }}" class="dropdown-item"><i class="mdi mdi-check-circle"></i>Confirm Booking</a>
                                                            </div>
                                                        @endif
                                                    </div>
                                                  </div>
                                                </td>
                                            </tr>
                                        @else
                                        @endif
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        
                   
                </div>
            </div> 
            </div>
            </div>
        </section>
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <script>
        $("#alert_hide").fadeOut(7000);
    </script>
    
    <script>    
        $(document).ready(function () {
            $('#example_1 .P_Id').each(function() {
                var P_Id = $(this).html();
                // console.log('p_ID : '+P_Id);
                $.ajax({
                    url: 'view_ternary_bookings_tourId/'+P_Id,
                    type: 'GET',
                    data: {
                        "P_Id": P_Id
                    },
                    success:function(data) {
                        var a           = data['a'];
                        var recieved    = parseInt(data['recieved']);
                        var price       = parseInt(data['price']);
                        // var package_id  = a['package_id'];
                        // console.log('package_id : '+package_id);
                        
                        if(price == recieved){
                            // $.each(a, function(key, value) {
                                $(".confirmed_div_dropdown"+P_Id+'').empty();
                                var url = 'confirmed_tour_booking/'+P_Id;
                                var data = `<a href="${url}" class="dropdown-item"><i class="mdi mdi-check-circle"></i>Confirm Booking</a>`
                                $(".confirmed_div_dropdown"+P_Id+'').html(data);
                            // });
                            $(".payment_status"+P_Id+'').empty();
                            $(".payment_status"+P_Id+'').html('<td style="color: Green;">PAID</td>');
                        }
                        else if(recieved > 0 && recieved < price){
                            // $.each(a, function(key, value) {
                                $(".confirmed_div_dropdown"+P_Id+'').empty();
                                var url = 'confirmed_tour_booking/'+P_Id;
                                var data = `<a href="${url}" class="dropdown-item"><i class="mdi mdi-check-circle"></i>Confirm Booking</a>`
                                $(".confirmed_div_dropdown"+P_Id+'').html(data);
                            // });
                            $(".payment_status"+P_Id+'').empty();
                            $(".payment_status"+P_Id+'').html('<td style="color: rebeccapurple;">PARTIALLY PAID</td>');
                        }
                        else{
                            $(".payment_status"+P_Id+'').empty();
                            $(".payment_status"+P_Id+'').html('<td style="color: orange;">UNPAID</td>');
                        }
                    }
                });
            });
        });
    </script>
    
    <script>
        $(document).ready(function(){
            $("#myInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#myTable tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>

@endsection
