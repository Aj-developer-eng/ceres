@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php

$customer_id=Session::get('id');


?>


<div class="card mt-5">
    <div class="card-body">
        <h4 class="header-title">Manage Currency</h4>
        @if($errors->any())
        <h4>{{$errors->first()}}</h4>
        @endif
        
        @if(session()->has('message'))
                            <div class="alert alert-success">
                                {{session('message')}}
                            </div>
                            @endif
        <!--<div class="tab-content">-->
            <form action="{{URL::to('super_admin/mange_currency_submit')}}" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
                @csrf
                
                <input type="hidden" name="customer_id" id="customer_id" value="{{$customer_id}}">
                <div class="row">

                                <div class="col-xl-3">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label">Purchase Currency</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Upload at least 10 images">
                                            </i>
                                        </div>
                                        <div>
                                            
                                	        <select name="purchase_currency" class="form-control " id="purchase_currency" required>
                                	            <option value="">Select Currency</option>
                                            @foreach($data->currency as $all_countries_currency)
                                            <option atr_currency_exchange="{{$all_countries_currency->currency}}" value="{{$all_countries_currency->currency}}" >{{$all_countries_currency->currency}} </option>
                                            @endforeach
                                            </select>
                                	       
                                        </div>
                                    </div>
                                </div>
                                 <div class="col-xl-3">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label">Sale Currency</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Upload at least 10 images">
                                            </i>
                                        </div>
                                        <div>
                                            
                                	       <select name="sale_currency" class="form-control " id="sale_currency" required>
                                	           <option value="">Select Currency</option>
                                            @foreach($data->exchange_currency as $all_countries_currency1)
                                            <option atr_currency_exchange="{{$all_countries_currency1->currency}}" value="{{$all_countries_currency1->currency}}"  >{{$all_countries_currency1->currency}} </option>
                                            @endforeach
                                            </select>
                                	       
                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="col-xl-3">-->
                                <!--    <div class="mb-3">-->
                                <!--        <div id="tooltip-container">-->
                                <!--            <label for="simpleinput" class="form-label">Exchange Base Rate</label>-->
                                <!--            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"-->
                                <!--                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Upload at least 10 images">-->
                                <!--            </i>-->
                                <!--        </div>-->
                                <!--        <div>-->
                                            
                                <!--	        <input type="text" id="exchange_rate" name="exchange_rate" class="form-control" required>-->
                                	       
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--</div>-->
                                
                                
                                
                                
                                 <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label">Conversion Type</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Upload at least 10 images">
                                            </i>
                                        </div>
                                        <div>
                                            
                                	        <select name="conversion_type" class="form-control " id="conversion_type" required>
                                	           <option value="">Select Conversion Type</option>
                                	           <option value="Divided">Divided (/)</option>
                                	           <option value="Multipal">Multipal (*)</option>
                                           
                                            
                                           
                                            </select>
                                	       
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-2 mt-3">
                                    <div class="">
                                <button style="float: right;width: 100px;margin-top: 10px;" type="submit" name="submit" class="btn btn-info deletButton">Submit</button>
                                </div>
                                </div>
                                </div>
                                
                                </form>
        <!--</div>-->
    </div>
</div>

@stop