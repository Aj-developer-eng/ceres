@extends('template/frontend/userdashboard/layout/default')
@section('content')

<div class="content-wrapper">
    <section class="content" style="padding: 30px 50px 0px 50px;">
        <div class="container-fluid">
            
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Booking Details</a></li>
                                <li class="breadcrumb-item active">Booking Allocations</li>
                            </ol>
                        </div>
                        <h4 class="page-title">View Booking Allocations</h4>
                    </div>
                </div>
            </div>
            
            <div class="row" style="margin-left: -7%;">
                <div class="col-12">
                    <div class="card" style="width: 105%;">
                        <div class="card-body" style="">
                            <div class="row mb-2">
                                <div class="col-sm-5"></div>
                                <div class="col-sm-7"><div class="text-sm-end"></div></div>
                            </div>
                            <div class="">
                                <div class="row">
                                    
                                    <div class="col-lg-12" style="margin-bottom:10px">
                                        <label class="d-none"><h4><b>Sort Data by Invoice No</b></h4></label>
                                        <select class="form-control d-none" id="booking_details_single" style="width: 220px;">
                                            <option value="0">Choose Invoice No</option>
                                            @foreach ($booking_Details as $value)
                                                <option value="{{ $value->invoice_no }}">{{ $value->invoice_no }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    
                                    <div class="col-lg-6" style="margin-bottom:10px">
                                        <label><h4><b>Sort Data by Hotel Name</b></h4></label>
                                        <select class="form-control" id="hotel_Name_Details_Single" style="width: 220px;">
                                            <option value="0">Choose Hotel Name</option>
                                            @if(isset($data->accomodation_details) && $data->accomodation_details != null && $data->accomodation_details != '')
                                                <?php $accomodation_details = json_decode($data->accomodation_details); //dd($accomodation_details); ?>
                                                @foreach ($accomodation_details as $value)
                                                    <option value="{{ $data->tour_id }}" attr-city="{{ $value->hotel_city_name }}" attr-hotel-name="{{ $value->acc_hotel_name }}">{{ $value->acc_hotel_name }} ({{ $value->hotel_city_name }})</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    
                                    <div class="col-lg-6" style="text-align: right;">
                                        <label><h4><b>Search</b></h4></label><br>
                                        <input style="width: 200px;border-radius: 5px;height: 40px;" id="myInput" type="text" placeholder="Search..">
                                    </div>
                                    
                                    <table class="table table-centered w-100 dt-responsive nowrap" id="">
                                        <thead class="table-light">
                                            <tr>
                                                <th style="text-align: center;">Booking ID</th>
                                                <th style="text-align: center;">Invoice No.</th>
                                                <th style="text-align: center;">Passenger Details</th>
                                                <th style="text-align: center;">Reservation No</th>
                                                <!--<th style="text-align: center;">Options</th>-->
                                            </tr>
                                        </thead>
                                        <tbody style="text-align:center;" id="myTable">
                                        
                                            @foreach($booking_Details as $value1)
                                                <tr>
                                                    <td>{{ $value1->booking_id }}</td>
                                                    <td>{{ $value1->invoice_no }}</td>
                                                    <td>
                                                        <table class="table table-centered w-100 dt-responsive nowrap" id="">
                                                            <thead class="table-light">
                                                                <tr style="font-size: 12px;">
                                                                    <th style="text-align: center;">Name</th>
                                                                    <th style="text-align: center;">Gender</th>
                                                                    <th style="text-align: center;">Passenger Type</th>
                                                                    <th style="text-align: center;">Package Name</th>
                                                                    <th style="text-align: center;">Booking Type</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody style="text-align:center;font-size: 12px;">
                                                                @foreach($booking_Details as $value)
                                                                    <?php
                                                                        // dd($booking_Details);
                                                                        $passenger_detail_E     = $value->passenger_detail;
                                                                        $adults_detail_E        = $value->adults_detail;
                                                                        $child_detail_E         = $value->child_detail;
                                                                        $cart_total_data_E      = $value->cart_total_data;
                                                                    ?>
                                                                    @if($value1->invoice_no == $value->invoice_no)
                                                                        @if(isset($passenger_detail_E) && $passenger_detail_E != null && $passenger_detail_E != '')
                                                                            <?php $passenger_detail = json_decode($passenger_detail_E); ?>
                                                                            @foreach($passenger_detail as $passenger_details)
                                                                                <tr>
                                                                                    <td><b>{{ $passenger_details->name }} {{ $passenger_details->lname }}</b></td>
                                                                                    <td>{{ $passenger_details->gender }}</td>
                                                                                    <td>{{ $passenger_details->passengerType }}</td>
                                                                                    @if(isset($cart_total_data_E) && $cart_total_data_E != null && $cart_total_data_E != '')
                                                                                        <?php $cart_total_data    = json_decode($cart_total_data_E); //dd($cart_total_data); ?>
                                                                                        <td>{{ $cart_total_data->name}}  <br> {{ $value->created_at }}</td>
                                                                                        @if(isset($cart_total_data->double_adults) && $cart_total_data->double_adults != null && $cart_total_data->double_adults != '' && $cart_total_data->double_adults > 0)
                                                                                            <td>Double</td>
                                                                                        @elseif(isset($cart_total_data->triple_adults) && $cart_total_data->triple_adults != null && $cart_total_data->triple_adults != '' && $cart_total_data->triple_adults > 0)
                                                                                            <td>Triple</td>
                                                                                        @elseif(isset($cart_total_data->quad_adults) && $cart_total_data->quad_adults != null && $cart_total_data->quad_adults != '' && $cart_total_data->quad_adults > 0)
                                                                                            <td>Quad</td>
                                                                                        @else
                                                                                            <td>Not Selected</td>
                                                                                        @endif
                                                                                    @else
                                                                                        <td>{{ $cart_total_data->adults }}</td>
                                                                                    @endif
                                                                                </tr>
                                                                            @endforeach
                                                                        @endif
                                                                        @if(isset($adults_detail_E) && $adults_detail_E != null && $adults_detail_E != '')
                                                                            <?php $adults_detail = json_decode($adults_detail_E); ?>
                                                                            @if(isset($adults_detail) && $adults_detail != null && $adults_detail != '')
                                                                                <?php 
                                                                                    if(is_array($adults_detail)){
                                                                                    $adults_detail_L = count($adults_detail);
                                                                                    for($a=0; $a<$adults_detail_L; $a++){
                                                                                ?>
                                                                                        <tr>
                                                                                            <td>{{ $adults_detail[$a]->passengerName }}</td>
                                                                                            <td>{{ $adults_detail[$a]->gender }}</td>
                                                                                            <td>{{ $adults_detail[$a]->passengerType }}</td>
                                                                                            @if(isset($cart_total_data_E) && $cart_total_data_E != null && $cart_total_data_E != '')
                                                                                                <?php $cart_total_data = json_decode($cart_total_data_E); //dd($cart_total_data); ?>
                                                                                                <td>{{ $cart_total_data->name}} <br> {{ $value->created_at }}</td>
                                                                                                @if(isset($cart_total_data->double_adults) && $cart_total_data->double_adults != null && $cart_total_data->double_adults != '' && $cart_total_data->double_adults > 0)
                                                                                                    <td>Double</td>
                                                                                                @elseif(isset($cart_total_data->triple_adults) && $cart_total_data->triple_adults != null && $cart_total_data->triple_adults != '' && $cart_total_data->triple_adults > 0)
                                                                                                    <td>Triple</td>
                                                                                                @elseif(isset($cart_total_data->quad_adults) && $cart_total_data->quad_adults != null && $cart_total_data->quad_adults != '' && $cart_total_data->quad_adults > 0)
                                                                                                    <td>Quad</td>
                                                                                                @else
                                                                                                    <td>Not Selected</td>
                                                                                                @endif
                                                                                            @else
                                                                                                <td>{{ $cart_total_data->adults }}</td>
                                                                                            @endif
                                                                                        </tr>
                                                                                <?php
                                                                                        }
                                                                                    }
                                                                                ?>
                                                                            @endif
                                                                        @endif
                                                                        
                                                                        @if(isset($child_detail_E) && $child_detail_E != null && $child_detail_E != '')
                                                                            <?php $child_detail = json_decode($child_detail_E); ?>
                                                                            @if(isset($child_detail) && $child_detail != null && $child_detail != '')
                                                                                @foreach($child_detail as $child_details)
                                                                                    <tr>
                                                                                        <td>{{ $child_details->passengerName }}</td>
                                                                                        <td>{{ $child_details->gender }}</td>
                                                                                        <td>{{ $child_details->passengerType }}</td>
                                                                                        @if(isset($cart_total_data_E) && $cart_total_data_E != null && $cart_total_data_E != '')
                                                                                            <?php $cart_total_data    = json_decode($cart_total_data_E); //dd($cart_total_data); ?>
                                                                                            <td>{{ $cart_total_data->name}} <br> {{ $value->created_at }}</td>
                                                                                            @if(isset($cart_total_data->double_adults) && $cart_total_data->double_adults != null && $cart_total_data->double_adults != '' && $cart_total_data->double_adults > 0)
                                                                                                <td>Double</td>
                                                                                            @elseif(isset($cart_total_data->triple_adults) && $cart_total_data->triple_adults != null && $cart_total_data->triple_adults != '' && $cart_total_data->triple_adults > 0)
                                                                                                <td>Triple</td>
                                                                                            @elseif(isset($cart_total_data->quad_adults) && $cart_total_data->quad_adults != null && $cart_total_data->quad_adults != '' && $cart_total_data->quad_adults > 0)
                                                                                                <td>Quad</td>
                                                                                            @else
                                                                                                <td>Not Selected</td>
                                                                                            @endif
                                                                                        @else
                                                                                            <td>{{ $cart_total_data->adults }}</td>
                                                                                        @endif
                                                                                    </tr>
                                                                                @endforeach
                                                                            @endif
                                                                        @endif
                                                                    @endif
                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                    <td>
                                                        @if(isset($reservation_Details) && $reservation_Details != null && $reservation_Details != '')
                                                            @foreach($reservation_Details as $reservation_Details_Single)
                                                                @if($reservation_Details_Single->invoice_No == $value1->invoice_no)
                                                                    <div>Hotel Name : <b>{{ $reservation_Details_Single->hotel_No }}</b></div>
                                                                    <div>Reservation Number : <b>{{ $reservation_Details_Single->reservation_input }}</b></div>
                                                                    <br>
                                                                @else
                                                                @endif
                                                            @endforeach
                                                        @else
                                                            <div><b>SELECT HOTEL</b></div>
                                                        @endif
                                                    </td>
                                                    <!--<td>-->
                                                    <!--    <div class="dropdown card-widgets">-->
                                                    <!--        <a href="#" class="dropdown-toggle arrow-none" data-bs-toggle="dropdown" aria-expanded="false">-->
                                                    <!--            <i class="dripicons-dots-3"></i>-->
                                                    <!--        </a>-->
                                                    <!--        <div class="dropdown-menu dropdown-menu-end" style="">-->
                                                    <!--            <a class="dropdown-item" onclick="add_more_passenger('{{$value1->invoice_no}}')" data-bs-toggle="modal" data-bs-target="#add-more-passenger-modal">View Passengers Details</a>-->
                                                    <!--        </div>-->
                                                    <!--    </div>-->
                                                    <!--</td>-->
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>           
                </div>
            </div>
                
        </div>
                
    </section>
</div>

<!--Modals-->

<div id="add-more-passenger-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" style="margin-right: 700px;">
        <div class="modal-content" style="width: 1100px;">
            <div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Passengers Detail</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="mb-3">
                            
                            <div class="row" id="leadpassenger_form" style="border: 1px solid #ebebeb;padding: 1rem;border-radius: 6px;">
                                <h3>Lead Passenger Detail</h3>
                                
                                <form method="post" class="row g-3" action="{{ url('add_more_passenger_package_booking') }}">
                                    @csrf
                                    <input type="text" name="booking_Inovice_No" class="booking_Inovice_No" hidden>
                                    
                                    <div class="col-md-4">
                                        <label for="inputEmail4" class="form-label">Title</label>
                                        <select class="form-control" id="lead_title" name="lead_title" style="border-radius: unset !important;"></select>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <label for="inputEmail4" class="form-label">First name</label>
                                        <input type="text" class="form-control" id="f_name_lead" required name="name">
                                        <input type="text" name="invoice_req_from" value="leadPassenger" hidden>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <label for="inputPassword4" class="form-label">Last name</label>
                                        <input type="text" class="form-control" id="l_name_lead" required name="lname">
                                    </div>
                                    
                                    <div class="col-4">
                                        <label for="inputAddress" class="form-label">Email</label>
                                        <input type="text" class="form-control" id="lead_email" required name="email">
                                        <input type="text" name="passengerType" hidden value="adults" class="form-control">
                                    </div>
                                    
                                    <div class="col-4">
                                        <label for="inputAddress" class="form-label">Nationality</label>
                                        <input type="text" class="form-control" name="country" id="nationality_lead">
                                    </div>
                                    
                                    <div class="col-4">
                                        <label for="inputAddress" class="form-label">Date of birth</label>
                                        <input class="form-control" type="text" id="dob_lead" name="date_of_birth">
                                    </div>
                                    
                                    <div class="col-4">
                                        <label for="inputAddress" class="form-label">Passenger Type</label>
                                        <input  type="text" id="lead_type" class="form-control " required name="passengerType"/>
                                    </div>
                                    
                                    <div class="col-4">
                                        <label for="inputAddress" class="form-label">Phone</label>
                                        <input  type="text" id="lead_mobile" class="form-control otp_code" required name="phone"/> 
                                    </div>
                                    
                                    <div class="col-4">
                                        <label for="inputAddress" class="form-label">Gender</label>
                                        <select class="form-control" id="lead_gender" name="gender"></select>
                                    </div>
    
                                    <div class="col-12">
                                        <button class="btn" style="background-color:#277019; color:white;float: right;" type="submit">Update</button>
                                    </div>
                                </form> 
                            </div>
                            
                        </div>
                    </div>
                    
                    <div class="col-lg-6">
                        <h5>Lead Passenger Name : <span id="lead_name_ID"></span></h5>
                        <p>Maximum Pax :<span id="no_of_pax_days_ID"></span></p>
                        <input type="hidden" value="Invoice" id="package_Type" name="package_Type">
                        <input type="hidden" value="" id="no_of_pax_days_Input" name="no_of_pax_days_Input">
                        <input type="hidden" value="" id="invoice_Id_Input" name="invoice_Id_Input">
                        <input type="hidden" value="" id="count_P_Input" name="count_P_Input">
                        <input type="hidden" value="" id="count_P_Input1">
                        <input type="hidden" value="" id="more_Passenger_Data_Input" name="more_Passenger_Data_Input">
                    </div>
         
                    <div class="col-lg-12">
                        <div class="mb-3 text-last" id="edit_M_P_Button">
                            <button class="btn btn-primary" id="add_more_pass_btn" onclick="add_new_passenger()" type="button">Add more Passenger</button>
                        </div>
                    </div>
                    
                    <div class="col-lg-12">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Sr</th>
                                    <th scope="col">First Name</th>
                                    <th scope="col">Last Name</th>
                                    <th scope="col">Gender</th>
                                    <th scope="col">Nationality</th>
                                    <th scope="col">Date of birth</th>
                                    <th scope="col">Passport Number</th>
                                    <th scope="col">passport Expiry	</th>
                                    <th scope="col">Passenger Type</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody id="otherPassenger"></tbody>
                        </table>
                    </div>
                    
                    <div class="row" id="" style="float:right">
                        <div class="col-lg-12 mb-3">
                            <button class="btn btn-primary" id="button_P" type="submit" style="display: none;">Submit</button>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="exampleModalAddAdultEdit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Adult</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="{{ url('add_more_passenger_package_booking') }}" method="post">
                <div class="modal-body">
                    @csrf
                    <div class="row">
                        
                        <input type="text" name="booking_Inovice_No" class="booking_Inovice_No" hidden>
                        
                        <div class="col-md-6">
                            <label for="inputEmail4" class="form-label">First name</label>
                            <input type="text" class="form-control" id="A_f_name_edit" required name="passengerName">
                            <input type="text" name="invoice_req_from" hidden value="updateAdultPassenger">
                            <!--<input type="text" name="invoice_id" hidden class="inovice_id">-->
                            <input type="text" name="index" hidden id="passIndexAdult">
                        </div>
                        
                        <div class="col-md-6">
                            <label for="inputPassword4" class="form-label">Last name</label>
                            <input type="text" class="form-control" id="A_l_name_edit" required name="lname">
                        </div>
                        
                        <div class="col-6">
                            <label for="inputAddress" class="form-label">Nationality</label>
                            <input type="text" name="country" id="A_nationality_other_edit" class="form-control">
                        </div>
                          
                        <div class="col-6">
                            <label for="inputAddress" class="form-label">Date of birth</label>
                            <input  type="text" id="A_date_of_birth_other_edit" name="date_of_birth" class="form-control " required /> 
                        </div>
                         
                        <div class="col-6">
                            <label for="inputAddress" class="form-label">Passport Number</label>
                            <input  type="text" id="A_passport_lead_other_edit" name="passport_lead" class="form-control otp_code" required /> 
                        </div>
                        
                        <div class="col-6">
                            <label for="inputAddress" class="form-label">Passport Expiry</label>
                            <input  type="text" id="A_passport_exp_lead_other_edit" name="passport_exp_lead" class="form-control" required /> 
                        </div>
                       
                        <div class="col-6">
                            <label for="inputAddress" class="form-label">Gender</label>
                            <select class="form-control" id="A_more_p_gender" name="gender"></select>
                        </div>
                        
                        <div class="col-6">
                            <label for="inputAddress" class="form-label">Passenger Type</label>
                            <input class="form-control" type="text" id="A_more_p_passengerType" name="passengerType" required/>
                        </div>
                        
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="exampleModalAddChildEdit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Child</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="{{ url('add_more_passenger_package_booking') }}" method="post">
                <div class="modal-body">
                    @csrf
                    <div class="row">
                        
                        <input type="text" name="booking_Inovice_No" class="booking_Inovice_No" hidden>
                        
                        <div class="col-md-6">
                            <label for="inputEmail4" class="form-label">First name</label>
                            <input type="text" class="form-control" id="C_f_name_edit" required name="passengerName">
                            <input type="text" name="invoice_req_from" hidden value="updateChildPassenger">
                            <!--<input type="text" name="invoice_id" hidden class="inovice_id">-->
                            <input type="text" name="index" hidden id="passIndexChild">
                        </div>
                        
                        <div class="col-md-6">
                            <label for="inputPassword4" class="form-label">Last name</label>
                            <input type="text" class="form-control" id="C_l_name_edit" required name="lname">
                        </div>
                        
                        <div class="col-6">
                            <label for="inputAddress" class="form-label">Nationality</label>
                            <input type="text" name="country" id="C_nationality_other_edit" class="form-control">
                        </div>
                          
                        <div class="col-6">
                            <label for="inputAddress" class="form-label">Date of birth</label>
                            <input  type="text" id="C_date_of_birth_other_edit" name="date_of_birth" class="form-control " required /> 
                        </div>
                         
                        <div class="col-6">
                            <label for="inputAddress" class="form-label">Passport Number</label>
                            <input  type="text" id="C_passport_lead_other_edit" name="passport_lead" class="form-control otp_code" required /> 
                        </div>
                        
                        <div class="col-6">
                            <label for="inputAddress" class="form-label">Passport Expiry</label>
                            <input  type="text" id="C_passport_exp_lead_other_edit" name="passport_exp_lead" class="form-control" required /> 
                        </div>
                       
                        <div class="col-6">
                            <label for="inputAddress" class="form-label">Gender</label>
                            <select class="form-control" id="C_more_p_gender" name="gender"></select>
                        </div>
                        
                        <div class="col-6">
                            <label for="inputAddress" class="form-label">Passenger Type</label>
                            <input class="form-control" type="text" id="C_more_p_passengerType" name="passengerType" required/>
                        </div>
                        
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

@section('scripts')

    <script>
        
        var data1                   = {!!json_encode($booking_Details)!!};
        var reservation_Details     = {!!json_encode($reservation_Details)!!};
        
        $("#booking_details_single").on('change',function(){
            var id =  $(this).val();
            console.log(id);
            if(id == 0){
                $("#myTable").empty();
                $.each(data1, function(key, value) {
                    var passenger_detail_E     = value.passenger_detail;
                    var adults_detail_E        = value.adults_detail;
                    var child_detail_E         = value.child_detail;
                    var cart_total_data_E      = value.cart_total_data;
                    var data_apppend = ``;
                    
                    if(passenger_detail_E != null && passenger_detail_E != ''){
                        var passenger_detail = JSON.parse(passenger_detail_E);
                        $.each(passenger_detail, function(key, passenger_details) {
                            data_apppend += `<tr>
                                                <td>${value.booking_id}</td>
                                                <td>${value.invoice_no}</td>
                                                <td><b>${passenger_details.name} ${passenger_details.lname}</b></td>
                                                <td>${passenger_details.gender}</td>
                                                <td>${passenger_details.passengerType}</td>`;       
                                                if(cart_total_data_E != null && cart_total_data_E != ''){
                                                    var cart_total_data    = JSON.parse(cart_total_data_E);
                                                    data_apppend += `<td>${cart_total_data.name} <br> ${value.created_at}</td>`;
                                                    if(cart_total_data.double_adults != null && cart_total_data.double_adults != '' && cart_total_data.double_adults > 0){
                                                        data_apppend += `<td>Double</td>`;
                                                    }else if(cart_total_data.triple_adults != null && cart_total_data.triple_adults != '' && cart_total_data.triple_adults > 0){
                                                        data_apppend += `<td>Triple</td>`;
                                                    }else if(cart_total_data.quad_adults != null && cart_total_data.quad_adults != '' && cart_total_data.quad_adults > 0){
                                                        data_apppend += `<td>Quad</td>`;
                                                    }else{
                                                        data_apppend += `<td>Not Selected</td>`;
                                                    }
                                                }else{
                                                    data_apppend += `<td>Not Defined</td>`;
                                                }
                                                
                            data_apppend += `</tr>`;
                        });
                    }
                                        
                    if(adults_detail_E != null && adults_detail_E != ''){
                        var adults_detail = JSON.parse(adults_detail_E);
                        if(adults_detail != null && adults_detail != ''){
                            if(Array.isArray(adults_detail)){
                                var adults_detail_L = adults_detail.length;
                                for(a=0; a<adults_detail_L; a++){
                                    data_apppend += `<tr>
                                                        <td>${value.booking_id}</td>
                                                        <td>${value.invoice_no}</td>
                                                        <td>${adults_detail[a].passengerName}</td>
                                                        <td>${adults_detail[a].gender}</td>
                                                        <td>${adults_detail[a].passengerType}</td>`;
                                                        if(cart_total_data_E != null && cart_total_data_E != ''){
                                                            var cart_total_data    = JSON.parse(cart_total_data_E);
                                                            data_apppend += `<td>${cart_total_data.name} <br> ${value.created_at}</td>`;
                                                            if(cart_total_data.double_adults != null && cart_total_data.double_adults != '' && cart_total_data.double_adults > 0){
                                                                data_apppend += `<td>Double</td>`;
                                                            }else if(cart_total_data.triple_adults != null && cart_total_data.triple_adults != '' && cart_total_data.triple_adults > 0){
                                                                data_apppend += `<td>Triple</td>`;
                                                            }else if(cart_total_data.quad_adults != null && cart_total_data.quad_adults != '' && cart_total_data.quad_adults > 0){
                                                                data_apppend += `<td>Quad</td>`;
                                                            }else{
                                                                data_apppend += `<td>Not Selected</td>`;
                                                            }
                                                        }else{
                                                            data_apppend += `<td>Not Define</td>`;
                                                        }
                                    data_apppend += `</tr>`;
                                }
                            }
                        }
                    }
                    
                    if(child_detail_E != null && child_detail_E != ''){
                        var child_detail = JSON.parse(child_detail_E);
                        if(child_detail != null && child_detail != ''){
                            $.each(child_detail, function(key, child_details) {
                                data_apppend += `<tr>
                                                    <td>${value.booking_id}</td>
                                                    <td>${value.invoice_no}</td>
                                                    <td>${child_details.name} ${child_details.lname}</td>
                                                    <td>${child_details.gender}</td>
                                                    <td>${child_details.passengerType}</td>`;       
                                                    if(cart_total_data_E != null && cart_total_data_E != ''){
                                                        var cart_total_data    = JSON.parse(cart_total_data_E);
                                                        data_apppend += `<td>${cart_total_data.name} <br> ${value.created_at}</td>`;
                                                        if(cart_total_data.double_adults != null && cart_total_data.double_adults != '' && cart_total_data.double_adults > 0){
                                                            data_apppend += `<td>Double</td>`;
                                                        }else if(cart_total_data.triple_adults != null && cart_total_data.triple_adults != '' && cart_total_data.triple_adults > 0){
                                                            data_apppend += `<td>Triple</td>`;
                                                        }else if(cart_total_data.quad_adults != null && cart_total_data.quad_adults != '' && cart_total_data.quad_adults > 0){
                                                            data_apppend += `<td>Quad</td>`;
                                                        }else{
                                                            data_apppend += `<td>Not Selected</td>`;
                                                        }
                                                    }else{
                                                        data_apppend += `<td>Not Defined</td>`;
                                                    }
                                                    
                                data_apppend += `</tr>`;
                            });
                        }
                    }
                    
                    $("#myTable").append(data_apppend); 
                    
                });
            }
            else if(id !== null){
                    $("#myTable").empty();
                    $.ajax({
                        url:"{{URL::to('booking_details_single')}}" + '/' + id,
                        method: "GET",
                        data: {
                            id : id
                        },
                        success:function(data){
                            var data1 = data['data'];
                            $.each(data1, function(key, value) {
                                var passenger_detail_E     = value.passenger_detail;
                                var adults_detail_E        = value.adults_detail;
                                var child_detail_E         = value.child_detail;
                                var cart_total_data_E      = value.cart_total_data;
                                var data_apppend = ``;
                                
                                if(passenger_detail_E != null && passenger_detail_E != ''){
                                    var passenger_detail = JSON.parse(passenger_detail_E);
                                    $.each(passenger_detail, function(key, passenger_details) {
                                        data_apppend += `<tr>
                                                            <td>${value.booking_id}</td>
                                                            <td>${value.invoice_no}</td>
                                                            <td><b>${passenger_details.name} ${passenger_details.lname}</b></td>
                                                            <td>${passenger_details.gender}</td>
                                                            <td>${passenger_details.passengerType}</td>`;       
                                                            if(cart_total_data_E != null && cart_total_data_E != ''){
                                                                var cart_total_data    = JSON.parse(cart_total_data_E);
                                                                data_apppend += `<td>${cart_total_data.name} <br> ${value.created_at}</td>`;
                                                                if(cart_total_data.double_adults != null && cart_total_data.double_adults != '' && cart_total_data.double_adults > 0){
                                                                    data_apppend += `<td>Double</td>`;
                                                                }else if(cart_total_data.triple_adults != null && cart_total_data.triple_adults != '' && cart_total_data.triple_adults > 0){
                                                                    data_apppend += `<td>Triple</td>`;
                                                                }else if(cart_total_data.quad_adults != null && cart_total_data.quad_adults != '' && cart_total_data.quad_adults > 0){
                                                                    data_apppend += `<td>Quad</td>`;
                                                                }else{
                                                                    data_apppend += `<td>Not Selected</td>`;
                                                                }
                                                            }else{
                                                                data_apppend += `<td>Not Defined</td>`;
                                                            }
                                                            
                                        data_apppend += `</tr>`;
                                    });
                                }
                                                    
                                if(adults_detail_E != null && adults_detail_E != ''){
                                    var adults_detail = JSON.parse(adults_detail_E);
                                    if(adults_detail != null && adults_detail != ''){
                                        if(Array.isArray(adults_detail)){
                                            var adults_detail_L = adults_detail.length;
                                            for(a=0; a<adults_detail_L; a++){
                                                data_apppend += `<tr>
                                                                    <td>${value.booking_id}</td>
                                                                    <td>${value.invoice_no}</td>
                                                                    <td>${adults_detail[a].passengerName}</td>
                                                                    <td>${adults_detail[a].gender}</td>
                                                                    <td>${adults_detail[a].passengerType}</td>`;
                                                                    if(cart_total_data_E != null && cart_total_data_E != ''){
                                                                        var cart_total_data    = JSON.parse(cart_total_data_E);
                                                                        data_apppend += `<td>${cart_total_data.name} <br> ${value.created_at}</td>`;
                                                                        if(cart_total_data.double_adults != null && cart_total_data.double_adults != '' && cart_total_data.double_adults > 0){
                                                                            data_apppend += `<td>Double</td>`;
                                                                        }else if(cart_total_data.triple_adults != null && cart_total_data.triple_adults != '' && cart_total_data.triple_adults > 0){
                                                                            data_apppend += `<td>Triple</td>`;
                                                                        }else if(cart_total_data.quad_adults != null && cart_total_data.quad_adults != '' && cart_total_data.quad_adults > 0){
                                                                            data_apppend += `<td>Quad</td>`;
                                                                        }else{
                                                                            data_apppend += `<td>Not Selected</td>`;
                                                                        }
                                                                    }else{
                                                                        data_apppend += `<td>Not Define</td>`;
                                                                    }
                                                data_apppend += `</tr>`;
                                            }
                                        }
                                    }
                                }
                                
                                if(child_detail_E != null && child_detail_E != ''){
                                    var child_detail = JSON.parse(child_detail_E);
                                    if(child_detail != null && child_detail != ''){
                                        $.each(child_detail, function(key, child_details) {
                                            data_apppend += `<tr>
                                                                <td>${value.booking_id}</td>
                                                                <td>${value.invoice_no}</td>
                                                                <td>${child_details.name} ${child_details.lname}</td>
                                                                <td>${child_details.gender}</td>
                                                                <td>${child_details.passengerType}</td>`;       
                                                                if(cart_total_data_E != null && cart_total_data_E != ''){
                                                                    var cart_total_data    = JSON.parse(cart_total_data_E);
                                                                    data_apppend += `<td>${cart_total_data.name} <br> ${value.created_at}</td>`;
                                                                    if(cart_total_data.double_adults != null && cart_total_data.double_adults != '' && cart_total_data.double_adults > 0){
                                                                        data_apppend += `<td>Double</td>`;
                                                                    }else if(cart_total_data.triple_adults != null && cart_total_data.triple_adults != '' && cart_total_data.triple_adults > 0){
                                                                        data_apppend += `<td>Triple</td>`;
                                                                    }else if(cart_total_data.quad_adults != null && cart_total_data.quad_adults != '' && cart_total_data.quad_adults > 0){
                                                                        data_apppend += `<td>Quad</td>`;
                                                                    }else{
                                                                        data_apppend += `<td>Not Selected</td>`;
                                                                    }
                                                                }else{
                                                                    data_apppend += `<td>Not Defined</td>`;
                                                                }
                                                                
                                            data_apppend += `</tr>`;
                                        });
                                    }
                                }
                                
                                $("#myTable").append(data_apppend); 
                                
                            });
                        }
    
                    });
            }else{
                    console.log('else');
                }
        });
        
        function edit_R_N(id){
            $('#reservationNO_ID_'+id+'').removeAttr('readonly');
            $('#reservationNO_check_'+id+'').val(1);
        }
        
        function add_R_N(id){
            var reservationNO_check = $('#reservationNO_check_'+id+'').val();
            var tour_No             = $('#tour_No_'+id+'').val();
            var hotel_No            = $('#hotel_No_'+id+'').val();
            var booking_No          = $('#booking_No_'+id+'').val();
            var invoice_No          = $('#invoice_No_'+id+'').val();
            var reservation_input   = $('#reservationNO_ID_'+id+'').val();
            
            if(reservationNO_check == 0){
                alert('Click On Edit Button First!');
            }else{
                $.ajax({
                    url:"{{URL::to('reservation_no_add')}}",
                    method: "GET",
                    data: {
                        tour_No             : tour_No,
                        hotel_No            : hotel_No,
                        booking_No          : booking_No,
                        invoice_No          : invoice_No,
                        reservation_input   : reservation_input,
                    },
                    success:function(data){
                        var data1 = data['data'];
                        console.log(data1);
                        if(data){
                            alert('Reservation Number Added Succefullly');
                        }else{
                            alert('Something Went Wrong');
                        }
                    }
                });
            }
        }
        
        function update_R_N(id){
            var reservationNO_check = $('#reservationNO_check_'+id+'').val();
            var reservation_No_id   = $('#reservation_No_id_'+id+'').val();
            var reservation_input   = $('#reservationNO_ID_'+id+'').val();
            
            if(reservationNO_check == 0){
                alert('Click On Edit Button First!');
            }else{
                $.ajax({
                    url:"{{URL::to('reservation_no_update')}}",
                    method: "GET",
                    data: {
                        reservation_No_id   : reservation_No_id,
                        reservation_input   : reservation_input,
                    },
                    success:function(data){
                        var data1 = data['data'];
                        console.log(data1);
                        if(data){
                            alert('Reservation Number Updated Succefullly');
                        }else{
                            alert('Something Went Wrong');
                        }
                    }
                });
            }
        }
        
        $("#hotel_Name_Details_Single").on('change',function(){
            var id              =  $(this).val();
            var city_Name       =  $(this).find('option:selected').attr('attr-city');
            var hotel_City_Name =  $(this).find('option:selected').attr('attr-hotel-name');
            
            if(id == 0){
                $("#myTable").empty();
                $.each(data1, function(key, value) {
                    var invoice_no              = value.invoice_no;
                    var booking_id              = value.booking_id;
                    var passenger_detail_E      = value.passenger_detail;
                    var adults_detail_E         = value.adults_detail;
                    var child_detail_E          = value.child_detail;
                    var cart_total_data_E       = value.cart_total_data;
                    var reservation_No          = value.reservation_No;
                    var data_apppend = ``;
                    data_apppend += `<tr>
                                        <td>${booking_id}</td>
                                        <td>${invoice_no}</td>
                                        <td>
                                            <table class="table table-centered w-100 dt-responsive nowrap" id="">
                                                <thead class="table-light">
                                                    <tr style="font-size: 12px;">
                                                        <th style="text-align: center;">Name</th>
                                                        <th style="text-align: center;">Gender</th>
                                                        <th style="text-align: center;">Passenger Type</th>
                                                        <th style="text-align: center;">Package Name</th>
                                                        <th style="text-align: center;">Booking Type</th>
                                                    </tr>
                                                </thead>
                                                <tbody style="text-align:center;font-size: 12px;">`;
                                                    if(passenger_detail_E != null && passenger_detail_E != ''){
                                                        var passenger_detail = JSON.parse(passenger_detail_E);
                                                        $.each(passenger_detail, function(key, passenger_details) {
                                                            data_apppend += `<tr>
                                                                                <td><b>${passenger_details.name} ${passenger_details.lname}</b></td>
                                                                                <td>${passenger_details.gender}</td>
                                                                                <td>${passenger_details.passengerType}</td>`;      
                                                                                if(cart_total_data_E != null && cart_total_data_E != ''){
                                                                                    var cart_total_data    = JSON.parse(cart_total_data_E);
                                                                                    data_apppend += `<td>${cart_total_data.name} <br> ${value.created_at} </td>`;
                                                                                    if(cart_total_data.double_adults != null && cart_total_data.double_adults != '' && cart_total_data.double_adults > 0){
                                                                                        data_apppend += `<td>Double</td>`;
                                                                                    }else if(cart_total_data.triple_adults != null && cart_total_data.triple_adults != '' && cart_total_data.triple_adults > 0){
                                                                                        data_apppend += `<td>Triple</td>`;
                                                                                    }else if(cart_total_data.quad_adults != null && cart_total_data.quad_adults != '' && cart_total_data.quad_adults > 0){
                                                                                        data_apppend += `<td>Quad</td>`;
                                                                                    }else{
                                                                                        data_apppend += `<td>Not Selected</td>`;
                                                                                    }
                                                                                }else{
                                                                                    data_apppend += `<td>Not Defined</td>`;
                                                                                }
                                                            data_apppend += `</tr>`;
                                                        });
                                                    }
                                                                
                                                    if(adults_detail_E != null && adults_detail_E != ''){
                                                        var adults_detail = JSON.parse(adults_detail_E);
                                                        if(adults_detail != null && adults_detail != ''){
                                                            if(Array.isArray(adults_detail)){
                                                                var adults_detail_L = adults_detail.length;
                                                                for(a=0; a<adults_detail_L; a++){
                                                                    data_apppend += `<tr>
                                                                                        <td>${adults_detail[a].passengerName}</td>
                                                                                        <td>${adults_detail[a].gender}</td>
                                                                                        <td>${adults_detail[a].passengerType}</td>`;
                                                                                        if(cart_total_data_E != null && cart_total_data_E != ''){
                                                                                            var cart_total_data    = JSON.parse(cart_total_data_E);
                                                                                            data_apppend += `<td>${cart_total_data.name} <br> ${value.created_at} </td>`;
                                                                                            if(cart_total_data.double_adults != null && cart_total_data.double_adults != '' && cart_total_data.double_adults > 0){
                                                                                                data_apppend += `<td>Double</td>`;
                                                                                            }else if(cart_total_data.triple_adults != null && cart_total_data.triple_adults != '' && cart_total_data.triple_adults > 0){
                                                                                                data_apppend += `<td>Triple</td>`;
                                                                                            }else if(cart_total_data.quad_adults != null && cart_total_data.quad_adults != '' && cart_total_data.quad_adults > 0){
                                                                                                data_apppend += `<td>Quad</td>`;
                                                                                            }else{
                                                                                                data_apppend += `<td>Not Selected</td>`;
                                                                                            }
                                                                                        }else{
                                                                                            data_apppend += `<td>Not Define</td>`;
                                                                                        }
                                                                    data_apppend += `</tr>`;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    
                                                    if(child_detail_E != null && child_detail_E != ''){
                                                        var child_detail = JSON.parse(child_detail_E);
                                                        if(child_detail != null && child_detail != ''){
                                                            $.each(child_detail, function(key, child_details) {
                                                                data_apppend += `<tr>
                                                                                    <td>${child_details.name} ${child_details.lname}</td>
                                                                                    <td>${child_details.gender}</td>
                                                                                    <td>${child_details.passengerType}</td>`;       
                                                                                    if(cart_total_data_E != null && cart_total_data_E != ''){
                                                                                        var cart_total_data    = JSON.parse(cart_total_data_E);
                                                                                        data_apppend += `<td>${cart_total_data.name} <br> ${value.created_at} </td>`;
                                                                                        if(cart_total_data.double_adults != null && cart_total_data.double_adults != '' && cart_total_data.double_adults > 0){
                                                                                            data_apppend += `<td>Double</td>`;
                                                                                        }else if(cart_total_data.triple_adults != null && cart_total_data.triple_adults != '' && cart_total_data.triple_adults > 0){
                                                                                            data_apppend += `<td>Triple</td>`;
                                                                                        }else if(cart_total_data.quad_adults != null && cart_total_data.quad_adults != '' && cart_total_data.quad_adults > 0){
                                                                                            data_apppend += `<td>Quad</td>`;
                                                                                        }else{
                                                                                            data_apppend += `<td>Not Selected</td>`;
                                                                                        }
                                                                                    }else{
                                                                                        data_apppend += `<td>Not Defined</td>`;
                                                                                    }
                                                                data_apppend += `</tr>`;
                                                            });
                                                        }
                                                    }
                    data_apppend +=             `</tbody>
                                            </table>
                                        </td>
                                        <td>`;
                                            if(reservation_Details != null && reservation_Details != ''){
                                                $.each(reservation_Details, function(key, reservation_Details_Single) {
                                                    if(reservation_Details_Single.invoice_No == invoice_no){
                                                        data_apppend +=`<div>Hotel Name : <b>${reservation_Details_Single.hotel_No}</b></div>
                                                                        <div>Reservation Number : <b>${reservation_Details_Single.reservation_input}</b></div>
                                                                        <br>`;
                                                    }else{
                                                        data_apppend += ``;
                                                    }
                                                });
                                            }else{
                                                data_apppend += ``;
                                            }
                    data_apppend +=     `</td>
                                    </tr>`;
                    $("#myTable").append(data_apppend); 
                    
                });
            }
            else if(id !== null){
                    $("#myTable").empty();
                    $.ajax({
                        url:"{{URL::to('hotel_Name_Details_Single')}}",
                        method: "GET",
                        data: {
                            id              : id,
                            hotel_City_Name : hotel_City_Name,
                        },
                        success:function(data){
                            var data1               = data['data'];
                            // var reservation_Details = data['reservation_Details'];
                            $.each(data1, function(key, value) {
                                var invoice_no              = value.invoice_no;
                                var booking_id              = value.booking_id;
                                var passenger_detail_E      = value.passenger_detail;
                                var adults_detail_E         = value.adults_detail;
                                var child_detail_E          = value.child_detail;
                                var cart_total_data_E       = value.cart_total_data;
                                var reservation_No          = value.reservation_No;
                                var data_apppend = ``;
                                
                                data_apppend += `<tr>
                                                    <td>${booking_id}</td>
                                                    <td>${invoice_no}</td>
                                                    <td>
                                                        <table class="table table-centered w-100 dt-responsive nowrap" id="">
                                                            <thead class="table-light">
                                                                <tr style="font-size: 12px;">
                                                                    <th style="text-align: center;">Name</th>
                                                                    <th style="text-align: center;">Gender</th>
                                                                    <th style="text-align: center;">Passenger Type</th>
                                                                    <th style="text-align: center;">Package Name</th>
                                                                    <th style="text-align: center;">Booking Type</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody style="text-align:center;font-size: 12px;">`;
                                                                if(passenger_detail_E != null && passenger_detail_E != ''){
                                                                    var passenger_detail = JSON.parse(passenger_detail_E);
                                                                    $.each(passenger_detail, function(key, passenger_details) {
                                                                        data_apppend += `<tr>
                                                                                            <td><b>${passenger_details.name} ${passenger_details.lname}</b></td>
                                                                                            <td>${passenger_details.gender}</td>
                                                                                            <td>${passenger_details.passengerType}</td>`;      
                                                                                            if(cart_total_data_E != null && cart_total_data_E != ''){
                                                                                                var cart_total_data    = JSON.parse(cart_total_data_E);
                                                                                                data_apppend += `<td>${cart_total_data.name} <br> ${value.created_at} <br> ${hotel_City_Name}</td>`;
                                                                                                if(cart_total_data.double_adults != null && cart_total_data.double_adults != '' && cart_total_data.double_adults > 0){
                                                                                                    data_apppend += `<td>Double</td>`;
                                                                                                }else if(cart_total_data.triple_adults != null && cart_total_data.triple_adults != '' && cart_total_data.triple_adults > 0){
                                                                                                    data_apppend += `<td>Triple</td>`;
                                                                                                }else if(cart_total_data.quad_adults != null && cart_total_data.quad_adults != '' && cart_total_data.quad_adults > 0){
                                                                                                    data_apppend += `<td>Quad</td>`;
                                                                                                }else{
                                                                                                    data_apppend += `<td>Not Selected</td>`;
                                                                                                }
                                                                                            }else{
                                                                                                data_apppend += `<td>Not Defined</td>`;
                                                                                            }
                                                                        data_apppend += `</tr>`;
                                                                    });
                                                                }
                                                                            
                                                                if(adults_detail_E != null && adults_detail_E != ''){
                                                                    var adults_detail = JSON.parse(adults_detail_E);
                                                                    if(adults_detail != null && adults_detail != ''){
                                                                        if(Array.isArray(adults_detail)){
                                                                            var adults_detail_L = adults_detail.length;
                                                                            for(a=0; a<adults_detail_L; a++){
                                                                                data_apppend += `<tr>
                                                                                                    <td>${adults_detail[a].passengerName}</td>
                                                                                                    <td>${adults_detail[a].gender}</td>
                                                                                                    <td>${adults_detail[a].passengerType}</td>`;
                                                                                                    if(cart_total_data_E != null && cart_total_data_E != ''){
                                                                                                        var cart_total_data    = JSON.parse(cart_total_data_E);
                                                                                                        data_apppend += `<td>${cart_total_data.name} <br> ${value.created_at} <br> ${hotel_City_Name}</td>`;
                                                                                                        if(cart_total_data.double_adults != null && cart_total_data.double_adults != '' && cart_total_data.double_adults > 0){
                                                                                                            data_apppend += `<td>Double</td>`;
                                                                                                        }else if(cart_total_data.triple_adults != null && cart_total_data.triple_adults != '' && cart_total_data.triple_adults > 0){
                                                                                                            data_apppend += `<td>Triple</td>`;
                                                                                                        }else if(cart_total_data.quad_adults != null && cart_total_data.quad_adults != '' && cart_total_data.quad_adults > 0){
                                                                                                            data_apppend += `<td>Quad</td>`;
                                                                                                        }else{
                                                                                                            data_apppend += `<td>Not Selected</td>`;
                                                                                                        }
                                                                                                    }else{
                                                                                                        data_apppend += `<td>Not Define</td>`;
                                                                                                    }
                                                                                data_apppend += `</tr>`;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                                
                                                                if(child_detail_E != null && child_detail_E != ''){
                                                                    var child_detail = JSON.parse(child_detail_E);
                                                                    if(child_detail != null && child_detail != ''){
                                                                        $.each(child_detail, function(key, child_details) {
                                                                            data_apppend += `<tr>
                                                                                                <td>${child_details.name} ${child_details.lname}</td>
                                                                                                <td>${child_details.gender}</td>
                                                                                                <td>${child_details.passengerType}</td>`;       
                                                                                                if(cart_total_data_E != null && cart_total_data_E != ''){
                                                                                                    var cart_total_data    = JSON.parse(cart_total_data_E);
                                                                                                    data_apppend += `<td>${cart_total_data.name} <br> ${value.created_at} <br> ${hotel_City_Name}</td>`;
                                                                                                    if(cart_total_data.double_adults != null && cart_total_data.double_adults != '' && cart_total_data.double_adults > 0){
                                                                                                        data_apppend += `<td>Double</td>`;
                                                                                                    }else if(cart_total_data.triple_adults != null && cart_total_data.triple_adults != '' && cart_total_data.triple_adults > 0){
                                                                                                        data_apppend += `<td>Triple</td>`;
                                                                                                    }else if(cart_total_data.quad_adults != null && cart_total_data.quad_adults != '' && cart_total_data.quad_adults > 0){
                                                                                                        data_apppend += `<td>Quad</td>`;
                                                                                                    }else{
                                                                                                        data_apppend += `<td>Not Selected</td>`;
                                                                                                    }
                                                                                                }else{
                                                                                                    data_apppend += `<td>Not Defined</td>`;
                                                                                                }
                                                                            data_apppend += `</tr>`;
                                                                        });
                                                                    }
                                                                }
                                data_apppend +=             `</tbody>
                                                        </table>
                                                    </td>
                                                    <td id="R_D_${invoice_no}"></td>
                                                </tr>`;
                                
                                $("#myTable").append(data_apppend);
                                
                                $.ajax({
                                    url:"{{URL::to('reservation_Detail_Single')}}",
                                    method: "GET",
                                    data: {
                                        invoice_no      : invoice_no,
                                        hotel_City_Name : hotel_City_Name,
                                    },
                                    success:function(data){
                                        var reservation_Details_Single = data['reservation_Details'];
                                        console.log(reservation_Details_Single);
                                        if(reservation_Details_Single != null && reservation_Details_Single != ''){
                                            if(reservation_Details_Single.invoice_No == invoice_no && reservation_Details_Single.hotel_No == hotel_City_Name){
                                                console.log(reservation_Details_Single.hotel_No);
                                                data_a=`<label>Enter Reservation Number</label><br>
                                                        <input id="reservationNO_check_${reservation_Details_Single.id}" type="hidden" value="0">
                                                        <input id="reservation_No_id_${reservation_Details_Single.id}" type="hidden" value="${reservation_Details_Single.id}">
                                                        <input id="reservationNO_ID_${reservation_Details_Single.id}" value="${reservation_Details_Single.reservation_input}" type="text" style="margin-bottom: 10px;background-color: #363e47;" readonly><br>
                                                        <button type="button" class="btn btn-primary" onclick="edit_R_N('${reservation_Details_Single.id}')" style="margin-right: 10px;">Edit</button>
                                                        <button type="button" class="btn btn-primary" onclick="update_R_N('${reservation_Details_Single.id}')">Update</button>`;
                                            }
                                        }else{
                                            data_a=`<label>Enter Reservation Number</label><br>
                                                    <input id="reservationNO_check_${invoice_no}" type="hidden" value="0">
                                                    <input id="tour_No_${invoice_no}" type="hidden" value="${id}">
                                                    <input id="hotel_No_${invoice_no}" type="hidden" value="${hotel_City_Name}">
                                                    <input id="booking_No_${invoice_no}" type="hidden" value="${booking_id}">
                                                    <input id="invoice_No_${invoice_no}" type="hidden" value="${invoice_no}">
                                                    <input id="reservationNO_ID_${invoice_no}" type="text" style="margin-bottom: 10px;background-color: #363e47;" readonly><br>
                                                    <button type="button" class="btn btn-primary" onclick="edit_R_N('${invoice_no}')" style="margin-right: 10px;">Edit</button>
                                                    <button type="button" class="btn btn-primary" onclick="add_R_N('${invoice_no}')">Add</button>`;
                                        }
                                        console.log(data_a);
                                        $('#R_D_'+invoice_no+'').append(data_a);
                                    }
                                }); 
                                
                            });
                        }
                    });
            }else{
                    console.log('else');
                }
        });
    
        $(document).ready(function(){
            $("#myInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                console.log(value);
                $("#myTable tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
        
    </script>
    
    <script>
        var all_countries = {!!json_encode($all_countries)!!};
        
        function add_more_passenger(id){
            $('#invoice_Id_Input').val(id);
            $('.booking_Inovice_No').val(id);
            $('#lead_name_ID').empty();
            $('#otherPassenger').empty();
            var aa = 1;
            $.ajax({
                url:"{{URL::to('booking_details_single')}}" + '/' + id,
                method: "GET",
                data: {
                	id:id,
                },
                success:function(data){
                    var booking_Details  = data['data'];
                    
                    if(booking_Details != null && booking_Details != ''){
                        $.each(booking_Details, function (key, value) {
                            var passenger_detail_E    = value.passenger_detail;
                            var adults_detail_E       = value.adults_detail;
                            var child_detail_E        = value.child_detail;
                            if(passenger_detail_E != null && passenger_detail_E != ''){
                                var passenger_detail = JSON.parse(passenger_detail_E);
                                $.each(passenger_detail, function (key, passenger_details) {
                                    var lead_title          = passenger_details.lead_title
                                    var f_name_lead         = passenger_details.name
                                    var l_name_lead         = passenger_details.lname
                                    var lead_email          = passenger_details.email
                                    var dob_lead            = passenger_details.date_of_birth
                                    var nationality_lead    = passenger_details.country
                                    var lead_type           = passenger_details.passengerType
                                    var lead_mobile         = passenger_details.phone
                                    var lead_gender         = passenger_details.gender
                                    $('#lead_name_ID').html(f_name_lead+' '+l_name_lead);
                                    if(lead_title == 'Mr.'){
                                        var title_data =    `<option value="">Select Title</option>
                                                            <option value="Mr." id="mr" selected>Mr.</option>
                                                            <option value="Mrs." id="mrs">Mrs.</option>`;
                                        $('#lead_title').append(title_data);
                                    }
                                    else{
                                        var title_data =    `<option value="">Select Title</option>
                                                            <option value="Mr." id="mr">Mr.</option>
                                                            <option value="Mrs." id="mrs" selected>Mrs.</option>`;
                                        $('#lead_title').append(title_data);
                                    }
                                    $('#f_name_lead').val(f_name_lead);
                                    $('#l_name_lead').val(l_name_lead);  
                                    $('#lead_email').val(lead_email);
                                    $('#dob_lead').val(dob_lead);
                                    $('#nationality_lead').val(nationality_lead);
                                    // $.each(all_countries, function (key, all_country) {
                                    //     var country_name = all_country.name;
                                    //     if(country_name == nationality_lead){
                                    //         var country_data = `<option value="${country_name}" selected>${country_name}</option>`;
                                    //         $('#nationality_lead').append(country_data);   
                                    //     }else{
                                    //         var country_data = `<option value="${country_name}">${country_name}</option>`;
                                    //         $('#nationality_lead').append(country_data);
                                    //     }
                                    // });
                                    $('#lead_type').val(lead_type);  
                                    $('#lead_mobile').val(lead_mobile);  
                                    $('#f_name_lead').val(f_name_lead); 
                                    if(lead_gender == 'male'){
                                        gender_data =  `<option value="male" selected>Male</option>
                                                        <option value="female">Female</option>`;
                                        $('#lead_gender').append(gender_data);
                                    }
                                    else{
                                        gender_data =  `<option value="male">Male</option>
                                                        <option value="female" selected>Female</option>`;
                                        $('#lead_gender').append(gender_data);
                                    }
                                });
                            }
                            
                            if(adults_detail_E != null && adults_detail_E != ''){
                                var adults_detail   = JSON.parse(adults_detail_E);
                                var adult_data      = ``;
                                var x               = 1;
                                var a               = 0;
                                $.each(adults_detail, function (key, adults_details) {
                                    var passenerObj = JSON.stringify(adults_details);
                                    adult_data +=`<tr>
                                                    <td>${x++}</td>
                                                    <td>${adults_details.passengerName}</td>
                                                    <td>${adults_details.lname}</td>
                                                    <td>${adults_details.gender}</td>
                                                    <td>${adults_details.country}</td>
                                                    <td>${adults_details.date_of_birth}</td>
                                                    <td>${adults_details.passport_lead}</td>
                                                    <td>${adults_details.passport_exp_lead}</td>
                                                    <td>${adults_details.passengerType}</td>
                                                    <td>
                                                        <input type="text" id="pass_A_${a}" hidden value='${passenerObj}'>
                                                        <button class="btn btn-success btn-sm" onclick="updateAdultPassenger(${a})">Edit</button>
                                                    </td>
                                                </tr>`;
                                    a++; 
                                });
                                $('#otherPassenger').append(adult_data);
                            }
                            
                            if(child_detail_E != null && child_detail_E != ''){
                                var child_detail = JSON.parse(child_detail_E);
                                if(child_detail != null && child_detail != ''){
                                    var child_data      = ``;
                                    var c               = 0;
                                    $.each(child_detail, function (key, child_details) {
                                        var passenerObj = JSON.stringify(child_details);
                                        child_data +=`<tr>
                                                        <td>${x++}</td>
                                                        <td>${child_details.passengerName}</td>
                                                        <td>${child_details.lname}</td>
                                                        <td>${child_details.gender}</td>
                                                        <td>${child_details.country}</td>
                                                        <td>${child_details.date_of_birth}</td>
                                                        <td>${child_details.passport_lead}</td>
                                                        <td>${child_details.passport_exp_lead}</td>
                                                        <td>${child_details.passengerType}</td>
                                                        <td>
                                                            <input type="text" id="pass_C_${c}" hidden value='${passenerObj}'>
                                                            <button class="btn btn-success btn-sm" onclick="updateChildPassenger(${c})">Edit</button>
                                                        </td>
                                                    </tr>`;
                                        c++;
                                    });
                                }
                                $('#otherPassenger').append(child_data);
                            }
                        });
                    }else{
                        alert('Booking Details Not Found');
                    }
                }
            }); 
        }
        
        function updateAdultPassenger(index){
            var passengerObject = $('#pass_A_'+index+'').val();
            var passengerObject = JSON.parse(passengerObject);
            console.log(passengerObject);
            $('#exampleModalAddAdultEdit').modal('show');
            $('#A_f_name_edit').val(passengerObject['passengerName']);
            $('#A_l_name_edit').val(passengerObject['lname']);
            $('#A_nationality_other_edit').val(passengerObject['country']);
            $('#A_date_of_birth_other_edit').val(passengerObject['date_of_birth']);
            $('#A_passport_lead_other_edit').val(passengerObject['passport_lead']);
            $('#A_passport_exp_lead_other_edit').val(passengerObject['passport_exp_lead']);
            $('#A_more_p_passengerType').val(passengerObject['passengerType']);
            $('#passIndexAdult').val(index);
            if(passengerObject['gender'] == 'male'){
                gender_data =  `<option value="male" selected>Male</option>
                                <option value="female">Female</option>`;
                $('#A_more_p_gender').append(gender_data);
            }
            else{
                gender_data =  `<option value="male">Male</option>
                                <option value="female" selected>Female</option>`;
                $('#A_more_p_gender').append(gender_data);
            } 
        }
        
        function updateChildPassenger(index){
            var passengerObject = $('#pass_C_'+index+'').val();
            var passengerObject = JSON.parse(passengerObject);
            console.log(passengerObject);
            $('#exampleModalAddChildEdit').modal('show');
            $('#C_f_name_edit').val(passengerObject['passengerName']);
            $('#C_l_name_edit').val(passengerObject['lname']);
            $('#C_nationality_other_edit').val(passengerObject['country']);
            $('#C_date_of_birth_other_edit').val(passengerObject['date_of_birth']);
            $('#C_passport_lead_other_edit').val(passengerObject['passport_lead']);
            $('#C_passport_exp_lead_other_edit').val(passengerObject['passport_exp_lead']);
            $('#C_more_p_passengerType').val(passengerObject['passengerType']);
            $('#passIndexChild').val(index);
            if(passengerObject['gender'] == 'male'){
                gender_data =  `<option value="male" selected>Male</option>
                                <option value="female">Female</option>`;
                $('#C_more_p_gender').append(gender_data);
            }
            else{
                gender_data =  `<option value="male">Male</option>
                                <option value="female" selected>Female</option>`;
                $('#C_more_p_gender').append(gender_data);
            } 
        }
    </script>

@stop

@section('slug')

@stop
