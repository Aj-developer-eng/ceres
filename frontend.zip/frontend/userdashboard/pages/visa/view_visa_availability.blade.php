@extends('template/frontend/userdashboard/layout/default')
@section('content')
<?php
// dd($visa_supplier);
?>


<div id="payable_payment_modal" class="modal fade" tabindex="-1" style="display: none;" aria-hidden="true">
   <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header modal-colored-header bg-primary">
                <h4 class="modal-title" id="compose-header-modalLabel">Payble Amount</h4>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
             <div class="modal-body visa_payment_html"> 
             </div>
           
        </div>
   </div>
</div><!-- /.modal -->

                <div class="container-fluid">
                    
                    <div class="table-responsive">
                        <div class="row">
                            @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show" style="background-color:#f5cfcf;" role="alert">
                    {{ session('error') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif
                @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" style="background-color:#d4edda;" role="alert">
                    {{ session('success') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif
                
                
            
                
                
            
                
                
                
                
                
                            <table class="table table-centered w-100 dt-responsive nowrap" id="example1">
                                <thead class="table-light">
                                    <tr>
                                        <th style="text-align: center;">Sr No.</th>
                                       
                                        <th style="text-align: center;">Suplier Name</th>
                                        <th style="text-align: center;">Suplier Visa</th>
                                        <th style="text-align: center;">Availability From</th>
                                        <th style="text-align: center;">Availability To</th>
                                        <th style="text-align: center;">Visa Qty</th>
                                        <th style="text-align: center;">Visa Price</th>
                                        <th style="text-align: center;">Visa Price</th>
                                       
                                        <th style="width: 85px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody style="text-align: center;">
                                    @foreach($visa_supplier as $visa_suppliers)
                                    <?php
                                    //  dd($visa_suppliers);
                                    $from_to_conversion = $visa_suppliers->currency_conversion;
                                    
                                    $from_to_conversion = explode(" ",$from_to_conversion);
                                   
                                    ?>
                            
                                    <tr>
                                    <td>{{$visa_suppliers->visa_id ?? ""}}</td>
                                    <td>{{$visa_suppliers->visa_supplier_name ?? "" }}</td>
                                    <td>{{$visa_suppliers->other_visa_type ?? ""}}</td>
                                    <td>{{$visa_suppliers->availability_from ?? ""}}</td>
                                    <td>{{$visa_suppliers->availability_to ?? ""}}</td>
                                    <td>{{$visa_suppliers->visa_qty ?? ""}}</td>
                                    <td>{{$from_to_conversion[0] ?? ""}} {{$visa_suppliers->visa_price ?? ""}}</td>
                                    <td>{{$from_to_conversion[2] ?? ""}} {{$visa_suppliers->visa_converted_price ?? ""}}</td>
                                 
                                    <td>
                                        
                                          <?php 
                                    $pay_form = [
                                        
                                        'amount_paidandremaining_of_visa'=>$visa_suppliers->amount_paidandremaining_of_visa,
                                        'visa_total_price'=>$visa_suppliers->total_visa_payable,
                                        'avail_id'=>$visa_suppliers->visa_id,
                                        'sup_id'=>$visa_suppliers->visa_supplier,
                                        'supplier_wallet'=>$visa_suppliers->visa_wallet ?? "",
                                        'flight_remain_amount'=>$visa_suppliers->total_visa_payable - $visa_suppliers->visa_paid_amount ?? ""
                                        
                                        ];
                                    
                                  
                                   
                                
                                    ?>
                                    
                                        <div class="dropdown card-widgets">
                                                            <a style="float: right;" href="#" class="dropdown-toggle arrow-none" data-bs-toggle="dropdown" aria-expanded="false">
                                                                <i class="dripicons-dots-3" style="color: #6e6060;"></i>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end" style="">
                                                                <a href="{{URL::to('edit_visa_supplier')}}/{{$visa_suppliers->visa_id ?? ""}}" class="dropdown-item"><i class="mdi mdi-account-edit me-1"></i>Edit
                                                                </a>
                                                                <a href="{{URL::to('delete_visa_avail')}}/{{$visa_suppliers->visa_id ?? ""}}" class="dropdown-item" onclick="return confirm('Are you sure you want to delete?');">
                                                                    <i class="mdi mdi-check-circle me-1"></i>
                                                                    Delete
                                                                </a>
                                                                <a href="javascript:void(0);" class="dropdown-item payment_btn_of_visa" detail_attr='<?php echo json_encode($pay_form) ?>' data-bs-toggle="modal" data-bs-target="#payable_payment_modal" style="font-size: 15px" > <i class="mdi mdi-account-edit me-1"></i>Payment
                                                                </a>
                                                                <a href="javascript:void(0);" class="dropdown-item payment_history_btn_of_flight" payment_detail_attr='' data-bs-toggle="modal" data-bs-target="#recieve_payment_history_modal" style="font-size: 15px" > <i class="fa-solid fa-list" style="margin-right: 3px;"></i>Payment History
                                                                </a>
                                                                
                                                        </div>
                                        <!--<a href="{{URL::to('edit_visa_supplier')}}/{{$visa_suppliers->visa_id ?? ""}}" class="mb-2"><span class="badge bg-success " style="font-size: 15px">Edit</span></a> <br>-->
                                        <!--<a href="{{URL::to('delete_visa_suppliers')}}/{{$visa_suppliers->visa_id ?? ""}}" class="mb-2"><span class="badge bg-success" style="font-size: 15px">Delete</span></a><br>-->
                                        
                                    </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div> 
                    
                </div>
                
        <!--<div class="modal fade" id="manage_balance" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">-->
        <!--  <div class="modal-dialog">-->
        <!--    <div class="modal-content">-->
        <!--      <div class="modal-header">-->
        <!--         <div> -->
        <!--            <h1 class="modal-title fs-5" id="exampleModalLabel">Manage Balance</h1>-->
                    
        <!--        </div>-->
        <!--        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>-->
        <!--      </div>-->
        <!--      <form action="https://alhijaztours.net/manage_wallent_balance" method="post" enctype="multipart/form-data">-->
        <!--         @csrf           -->
        <!--          <div class="modal-body">-->
                          
                   
        <!--              <div class="row">-->
        <!--                <div class="col-12 mb-2">-->
        <!--                    <input type="text" name="agent_id" hidden="" value="11">-->
        <!--                    <label>Select Transcation Type</label>-->
        <!--                    <select class="form-control" id="" name="transtype">-->
        <!--                        <option value="Refund">Refund</option>-->
        <!--                        <option value="Deposit">Deposit</option>-->
        <!--                    </select>-->
        <!--                </div>-->
        <!--                 <div class="col-6 mb-2">-->
        <!--                    <label>Payment Method</label>-->
        <!--                    <select class="form-control" onchange="paymentMethod()" id="payment_method" name="payment_method">-->
        <!--                        <option value="Bank Transfer">Bank Transfer</option>-->
        <!--                        <option value="Cash">Cash</option>-->
        <!--                        <option value="Card Payment">Card Payment</option>-->
        <!--                    </select>-->
        <!--                </div>-->
        <!--                 <div class="col-6 mb-2">-->
        <!--                     <label>Current Balance</label>-->
        <!--                     <input type="text" class="form-control" readonly id="current_bal" required=""  name="current_bal" placeholder="Enter Payment Amount">-->
        <!--                     <input type="text" class="form-control" readonly id="supplier_id" hidden required=""  name="supplier_id" placeholder="Enter Payment Amount">-->
        <!--                     <input type="text" name="request_person" value="flight_supplier" hidden>-->
        <!--                </div>-->
        <!--                <div class="col-6 mb-2">-->
        <!--                     <label>Payment Date</label>-->
        <!--                     <input type="date" class="form-control" required="" value="2022-12-14" name="payment_date" placeholder="Enter Payment Amount">-->
        <!--                </div>-->
                        
        <!--                <div class="col-6 mb-2">-->
        <!--                     <label>Payment Amount</label>-->
        <!--                     <input type="text" class="form-control" required="" name="payment_am" placeholder="Enter Payment Amount">-->
        <!--                </div>-->
                        
                      
                        
        <!--                <div class="col-6 mb-2" id="transcation_id" style="display: block;">-->
        <!--                    <label>Transaction ID</label>-->
        <!--                  <input type="text" class="form-control" name="transcation_id" placeholder="Enter Transaction ID">-->
        <!--                  <input type="text" class="form-control" required="" name="invoice_id" hidden="" value="AHT3383261" placeholder="Enter Transaction ID">-->
        <!--                </div>-->
                        
        <!--               <div class="col-6 mb-2" id="account_id" style="display: block;">-->
        <!--                   <label>Account No.</label>-->
        <!--                   <input type="text" class="form-control" name="account_no" placeholder="Payment to (Account No.)" value="13785580">-->
        <!--                </div>-->
                        
        <!--              </div>-->
                   
        <!--          </div>-->
        <!--          <div class="modal-footer">-->
        <!--            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>-->
        <!--            <button type="submit" class="btn btn-primary">Save changes</button>-->
        <!--          </div>-->
        <!--   </form>-->
              
        <!--    </div>-->
        <!--  </div>-->
        <!--</div>-->

@endsection

@section('scripts')

  

    <script>
    $(".payment_btn_of_visa").on('click',function () {
        var data_of_visa = $(this).attr('detail_attr');
        data_of_visa = JSON.parse(data_of_visa);
        console.log(data_of_visa);
        if(data_of_visa['amount_paidandremaining_of_flight'] ){
            var remain = JSON.parse(data_of_visa['amount_paidandremaining_of_flight']);
           
             var lastindex = remain[remain.length - 1];
             
             remain = lastindex['remaining_amount'];
           
        }else{
            var remain = data_of_visa['flight_total_price'];
        }
        
       var visa_data = ` <div class="p-1">
                <div class="modal-body px-3 pt-3 pb-0">
                    <form action="{{ URL::to('save_visa_payment_recieved_and_remaining')}}" method="post">
                        @csrf
                        
                        <input hidden readonly value="${data_of_visa['sup_id']}" name="visa_sup_id" class="form-control" type="text"  required="">
                        
                        <div class="mb-2">
                          <label for="tourId" class="form-label">Visa ID</label>
                          <input readonly name="visaId" class="form-control" value="${data_of_visa['avail_id']}" type="text" id="flightId" required="">
                        </div>
                         <?php
                                            $f_name=Session::get('name');
                                            $l_name=Session::get('lname');
                                            $email_e=Session::get('email');
                                            $id =Session::get('id');
                                            // echo $f_name . $l_name; 
                                        ?>
                        
                        <div class="mb-2">
                          <label for="tourId" class="form-label">Client Name</label>
                          <input hidden name="payingidentityemail" class="form-control" value="<?php echo $email_e; ?>" type="text"  required="">
                          <input hidden name="payingidentityid" class="form-control" value="<?php echo $id; ?>" type="text"  required="">
                          <input readonly  class="form-control" value="<?php echo $f_name . $l_name; ?>" type="text"  required="">
                        </div>


                        <div class="mb-2">
                          <label for="date" class="form-label">Date</label>
                          <input value="" name="date" class="form-control" type="date" id="date" required="">
                        </div>



                        <div class="mb-2">
                            <label for="total_amount" class="form-label">Total Amount</label>
                            <input readonly name="total_amount" value="${data_of_visa['visa_total_price']}" class="form-control" type="text" id="total_amount" required="">
                        </div>

                        <div class="mb-2">
                            <div class="row">
                                <div class="col-md-6">
                                   <label for="total_amount" class="form-label">Payment From</label>
                                    <select class="form-control" onchange="paymentMethod()" id="payment_method" name="payment_method">
                                        <option value="Bank Transfer">Bank Transfer</option>
                                        <option value="Cash">Cash</option>
                                        <option value="Card Payment">Card Payment</option>
                                        <option value="Wallet">Wallet</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label for="total_amount" class="form-label">Wallet Balance</label>
                                     <input value="${data_of_visa['supplier_wallet']}" name="" class="form-control" type="number" readonly id="supplier_wallet" required="">
                                </div>
                            </div>
                         
                        </div>
                        

                        <div class="mb-2">
                            <label for="remaining_amount" class="form-label">Remaining Amount</label>
                            <input readonly name="remaining_amount" value="${data_of_visa['flight_remain_amount']}" class="form-control" type="text" id="remaining_amount" required="">
                        </div>

                        <div class="mb-2">
                            <label for="amount_paid" class="form-label">Recieve Amount</label>
                           
                            <input name="amount_paid" onchange="myFunction()"class="form-control" type="number" id="amount_paid" placeholder="Nothing Paid yet">
                   
                        </div>

                        <div style="padding: 10px 0px 10px 0px;">
                            <button style="padding: 10px 30px 10px 30px;" type="submit" class="btn btn-primary"><i class="mdi mdi-send me-1"></i>Recieve</button>
                            <button style="margin-left: 5px;padding: 10px 30px 10px 30px;" type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                        </div>

                        <!-- <div class="mb-2 text-center">
                          <button class="btn btn-primary" type="submit">Recieve</button>
                        </div> -->
                    </form>
                </div>
            </div>`;
         $('.visa_payment_html').html(visa_data);
       
  
    });
    
        $(document).ready(function(){
          
        });
       function manage_balance(sup_id,wallet_balance){
            $('#manage_balance').modal('show');
            $('#current_bal').val(wallet_balance);
            $('#supplier_id').val(sup_id);
            
           console.log('supplier id is '+sup_id+' wallet Balance is '+wallet_balance);
       }
       
        
         function paymentMethod(){
                var payment_method = $('#payment_method').val();
                console.log('The payment is call now ');
                if(payment_method == 'Wallet'){
                    console.log('The wallet is call now ');
                    var walletAmount = $('#supplier_wallet').val();
                    $('#amount_paid').attr('max',walletAmount);
                }else{
                    $('#amount_paid').attr('max',false);
                }
            }
            function myFunction(){
            var total_amount = $('#total_amount').val();
            var paid_amount = $('#amount_paid').val();
            var remaining_amount = $('#remaining_amount').val();
           
             
            if(total_amount){
             
              var total_amount = total_amount; 
            }else{
                var total_amount = total_amount; 
            }
            if(paid_amount){
              var paid_amount = paid_amount; 
            }
            if(remaining_amount){
              var remaining_amount = remaining_amount; 
            }
           
             
             
             
            var price_addition = parseFloat(remaining_amount) - parseFloat(paid_amount);
            // console.log(price_addition)
            
            var multiple = price_addition;
            console.log(multiple);
            $('#remaining_amount').val(multiple);
        
        }
    </script>

@stop

@section('slug')

@stop
