@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php $currency_symbol = Session::get('currency_symbol'); ?>

<div class="dashboard-content">
    
    <h4 style="color:#a30000">Add New Vehicle</h4>
    <form action="{{URL::to('add_new_vehicle')}}" method="post" enctype="multipart/form-data">
        @csrf
        <div class="row">
            <div class="col-md-12 mb-4">
                @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" style="background-color:#d4edda;" role="alert">
                    {{ session('success') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif

                @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show" style="background-color:#f5cfcf;" role="alert">
                    {{ session('error') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif
            </div>
            
            <div class="col-md-12">
                
                <ul class="nav nav-tabs d-none" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation" style="width: 280px;text-align: center;">
                        <a class="nav-link active" id="home-tab" data-bs-toggle="tab" href="#general" role="tab" aria-controls="general" aria-selected="true">GENERAL</a>
                    </li>
                    <li class="nav-item d-none" role="presentation" style="width: 280px;text-align: center;">
                        <a class="nav-link" id="meta-info-tab" data-bs-toggle="tab" href="#meta-info" role="tab" aria-controls="meta-info" aria-selected="false">META INFO</a>
                    </li>
                    <li class="nav-item d-none" role="presentation" style="width: 280px;text-align: center;">
                        <a class="nav-link" id="policy-tab" data-bs-toggle="tab" href="#policy" role="tab" aria-controls="policy" aria-selected="false">POLICY</a>
                    </li>
                </ul>
                
                <!-- Main Tab Contant Start -->
                <div class="tab-content" id="myTabContent">
                    <!-- General Tab Start -->
                    <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                        <div class="row">
                            
                            <div class="col-md-3" style="padding: 15px;">
                                <label for="">Vehicle type</label>
                                <div class="input-group">
                                    <select class="form-control" name="vehicle_Type" id=vehicle_Type required>
                                        <option>Select Vehicle</option>
                                        @foreach($vehicle_category as $vehicle_categoryS)
                                            <option attr-max-bag-VC="{{ $vehicle_categoryS->max_bagage ?? '' }}" attr-id-VC="{{ $vehicle_categoryS->id ?? '' }}" attr-max-pass-VC="{{ $vehicle_categoryS->max_passeneger ?? '' }}" value="{{ $vehicle_categoryS->vehicle_category ?? '' }}">{{ $vehicle_categoryS->vehicle_category ?? '' }}</option>
                                        @endforeach
                                    </select>
                                    <span title="Add Categories" class="input-group-btn input-group-append" style="float: right;margin-bottom:10px">
                                        <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#add-Categories-modal" type="button">+</button>
                                    </span>
                                </div>
                                <input type="hidden" id="vehicle_category_id" name="vehicle_category_id">
                            </div>
                            
                            <div class="col-md-3" style="padding: 15px;">
                                <label for="">Vehicle Name</label>
                                <input id="vehicle_Name" type="text" class="form-control" name="vehicle_Name" autocomplete="vehicle_Name" autofocus required>
                            </div>
                            
                            <div class="col-md-3" style="padding: 15px;">
                                <label for="">Passenger</label>
                                <select name="vehicle_Passenger" id="vehicle_Passenger" class="form-control">
                                    <option value="">Choose...</option>
                                </select>
                            </div>
                            
                            <div class="col-md-3" style="padding: 15px;">
                                <label for="">Baggage</label>
                                <select name="vehicle_Baggage" id="vehicle_Baggage" class="form-control">
                                    <option value="">Choose...</option>
                                </select>
                            </div>
                            
                            <div class="col-md-4" style="padding: 15px;">
                                <label for="">Car Doors</label>
                                <select name="vehicle_Door" id="" class="form-control">
                                    <option value="">Choose...</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                </select>
                            </div>
                            
                            <div class="col-md-4" style="padding: 15px;">
                                <label for="">Transmission</label>
                                <select name="vehicle_Transmission" id="" class="form-control">
                                    <option value="" >Choose...</option>
                                    <option value="Auto">Auto</option>
                                    <option value="Manual">Manual</option>
                                    <option value="Others">Others</option>
                                </select>
                            </div>
                            
                            <div class="col-md-4" style="padding: 15px;">
                                <label for="">Vehicle Image</label>
                                <input id="vehicle_image" type="file" class="form-control" name="vehicle_image" value="" autocomplete="vehicle_image" autofocus>
                            </div>
                            
                            <div class="col-md-12" style="padding: 15px;">
                                <label for="">Vehicle Discription</label>
                                <textarea name="vehicle_Description" row="5" class="form-control"  autocomplete="vehicle_Description" placeholder="Enter Vehicle Description"></textarea>
                            </div>
                            
                            <div class="col-md-6 d-none" style="padding: 15px;">
                                <label for="">Currency Symbol</label>
                                <input id="currency_symbol" type="text" class="form-control" name="currency_symbol" value="{{ $currency_symbol }}" autocomplete="currency_symbol" autofocus  readonly>
                            </div>
                            
                        </div>
                        
                    </div>
                    <!-- Meta Info Tab Start -->
                    <div class="tab-pane fade d-none" id="meta-info" role="tabpanel" aria-labelledby="meta-info-tab">
                        <div class="row">
                            <div class="col-md-12" style="padding: 15px;">
                                <label for="">META TITLE</label>
                                <input id="meta_title" type="text" class="form-control" name="meta_title" autocomplete="meta_title" autofocus>
                            </div>
                                <div class="col-md-12" style="padding: 15px;">
                                    <label for="">META KEYWORDS</label>
                                    <textarea name="meta_keywords" row="5" class="form-control" autocomplete="meta_keywords" placeholder="Enter meta keyword"></textarea>
                                </div>
                                <div class="col-md-12" style="padding: 15px;">
                                    <label for="">META DESCRIPTION</label>
                                    <textarea name="meta_desc" row="5" class="form-control" autocomplete="meta_desc" placeholder="Enter meta description"></textarea>
                                </div>
                        </div>
                    </div>
                    <!-- Policy Tab Start -->
                    <div class="tab-pane fade d-none" id="policy" role="tabpanel" aria-labelledby="policy-tab">
                        <div class="row">
                            <div class="col-md-12" style="padding: 15px;">
                                <label for="">PAYMENT OPTION</label>
                                <select name="payment_option" id="" class="form-control">
                                    <option value="At Arrival">At Arrival</option>
                                </select>
                            </div>

                            <div class="col-md-12" style="padding: 15px;">
                                <label for="">POLICY AND TERMS</label>
                                <textarea name="policy_and_terms" row="5" class="form-control"  autocomplete="policy_and_terms" placeholder="Enter policy and terms"></textarea>
                            </div> 
                        </div>
                    </div>
                </div>
                <!-- Main Tab Contant End -->
            </div>
            
            <div class="col-md-4 d-none" style="margin-top:-.8rem;">
                
                <div class="card">
                    <div class="card-header">
                        Vehicle Additional Details
                    </div>
                    <div class="card-body">
                        
                        <div class="col-md-12" style="padding-bottom: 15px">
                            <label for="">Status</label>
                            <select name="vehicle_Status" id="" class="form-control">
                                <option value="Enabled">Enabled</option>
                            </select>
                        </div>
                        
                        <div class="col-md-12" style="padding-bottom: 15px">
                            <label for="">Passenger</label>
                            <select name="" id="" class="form-control">
                                <option value="">Choose...</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                            </select>
                        </div>
                        
                        <div class="col-md-12" style="padding-bottom: 15px">
                            <label for="">Car Doors</label>
                            <select name="" id="" class="form-control">
                                <option value="">Choose...</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                        </div>
                        
                        <div class="col-md-12" style="padding-bottom: 15px">
                            <label for="">Transmission</label>
                            <select name="" id="" class="form-control">
                                <option value="" >Choose...</option>
                                <option value="Auto">Auto</option>
                                <option value="Manual">Manual</option>
                                <option value="Others">Others</option>
                            </select>
                        </div>
                        
                        <div class="col-md-12" style="padding-bottom: 15px">
                            <label for="">Baggage</label>
                            <select name="" id="" class="form-control">
                                <option value="">Choose...</option>
                                <option value="x1">x1</option>
                                <option value="x2">x2</option>
                                <option value="x3">x3</option>
                                <option value="x4">x4</option>
                                <option value="x5">x5</option>
                                <option value="x6">x6</option>
                            </select>
                        </div>
                        
                        <div class="col-md-12 d-none" style="padding-bottom: 15px">
                            <label for="">Airport Picking</label>
                            <select name="vehicle_Picking" id="" class="form-control">
                                <option value="">Choose...</option>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                        
                    </div>
                </div>

            </div>
        </div>

        <div class="row">
            <div class="col-md-12 text-right mt-3">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
</div>

<div id="add-Categories-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Categories</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <div class="mb-4">
                    <label for="">Vehicle Category</label>
                    <input type="text" id="vehicle_category" name="vehicle_category" class="form-control">
                </div>
                <div class="mb-4">
                    <label for="">Max Passengers</label>
                    <input type="number" id="max_passeneger" name="max_passeneger" class="form-control">
                </div>
                
                <div class="mb-4">
                    <label for="">Max Bagages</label>
                    <input type="number" id="max_bagage" name="max_bagage" class="form-control">
                </div>
                
                <div class="mb-3 text-center">
                    <button class="btn btn-primary" id="submitForm_VC" type="button">Submit</button>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
@section('scripts')
<script>

    $('#vehicle_Type').on('change',function(){
        var attr_id_VC          = $(this).find('option:selected').attr('attr-id-VC');
        $('#vehicle_category_id').val(attr_id_VC);
        
        var attr_max_pass_VC    = $(this).find('option:selected').attr('attr-max-pass-VC');
        $('#vehicle_Passenger').empty();
        var data = `<option value="">Choose...</option>`;
        $('#vehicle_Passenger').append(data);
        for(var x=1; x<=attr_max_pass_VC; x++){
            var data = `<option value="${x}">${x}</option>`;
            $('#vehicle_Passenger').append(data);
        }
        
        var value_x             = `x`;
        var attr_max_bad_VC     = $(this).find('option:selected').attr('attr-max-bag-VC');
        $('#vehicle_Baggage').empty();
        var data = `<option value="">Choose...</option>`;
        $('#vehicle_Baggage').append(data);
        for(var x1=1; x1<=attr_max_bad_VC; x1++){
            var data = `<option value="${x1}">${value_x}${x1}</option>`;
            $('#vehicle_Baggage').append(data);
        }
    });
    
    $('#submitForm_VC').on('click',function(e){
        e.preventDefault();
        let vehicle_category    = $('#vehicle_category').val();
        let max_passeneger      = $('#max_passeneger').val();
        let max_bagage          = $('#max_bagage').val();
        $.ajax({
            url: "add_new_vehicle_category_Ajax",
            type:"POST",
            data:{
                "_token": "{{ csrf_token() }}",
                vehicle_category    : vehicle_category,
                max_passeneger      : max_passeneger,
                max_bagage          : max_bagage,
            },
            success:function(response){
                if(response){
                    var data = response['vehicle_Category'];
                    $("#vehicle_Type").empty();
                    var vehicle_Type = `<option>Select Vehicle</option>`;
                    $('#vehicle_Type').append(vehicle_Type);
                    
                    $.each(data, function(key, value) {
                        var vehicle_category_data = `<option attr-max-bag-VC="${value.max_bagage}" attr-id-VC="${value.id}" attr-max-pass-VC="${value.max_passeneger}" value="${value.vehicle_category}">${value.vehicle_category}</option>`;
                        $("#vehicle_Type").append(vehicle_category_data);
                    });
                    
                    alert('Vehicle Category Added Succesfully!');
                    $("#vehicle_Passenger").empty('');
                    $("#vehicle_category_id").val('');
                    $('#vehicle_category').val('');
                    $('#max_passeneger').val('');
                    $('#max_bagage').val('');
                }
                $('#success-message').text(response.success);
            },
        });
    });
    
    $(document).ready(function(){
        selectCities();
    })
    
    $("#checkall").click(function (){
     if ($("#checkall").is(':checked')){
        $(".form-check-input").each(function (){
           $(this).prop("checked", true);
           });
        }else{
           $(".form-check-input").each(function (){
                $(this).prop("checked", false);
           });
        }
    })

    function selectCities(){
        var country = $('#property_country').val();
        console.log(country);
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            url: "{{ url('/country_cites') }}",
            method: 'post',
            data: {
                "_token": "{{ csrf_token() }}",
                "id": country,
            },
            success: function(result){
                console.log('cites is call now');
              console.log(result);
              $('#property_city').html(result);
            },
            error:function(error){
                console.log(error);
            }
        });
    }
</script>
@stop



