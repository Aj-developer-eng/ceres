@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php $currency=Session::get('currency_symbol'); ?>

<div class="dashboard-content">
    <h4 style="color:#a30000">Update Destination</h4>
        <form action="{{URL::to('update_destination')}}/{{ $tranfer_destination->id }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="col-md-12 mb-4">
                    @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show" style="background-color:#d4edda;" role="alert">
                        {{ session('success') }}
                        <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif
    
                    @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" style="background-color:#f5cfcf;" role="alert">
                        {{ session('error') }}
                        <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif
                </div>
                
                <div class="col-md-12">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation" style="width: 280px;text-align: center;">
                            <a class="nav-link active" id="home-tab" data-bs-toggle="tab" href="#general" role="tab" aria-controls="general" aria-selected="true">Manage Destinations</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                            <div class="row">
                                
                                <input type="hidden" id="pickup_CountryCode" name="pickup_CountryCode">
                                
                                <div class="col-xl-6" style="padding: 15px;">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Currency Conversion</label>
                                        <select class="form-control CC_id_store" name="currency_conversion" id="currency_conversion1">
                                            <option value="0">Select Currency Conversion</option>
                                            @foreach($mange_currencies as $mange_currencies)
                                                <?php $currency_conversion = $mange_currencies->purchase_currency.' TO '.$mange_currencies->sale_currency; ?>
                                                <option <?php if($tranfer_destination->currency_conversion == $currency_conversion) echo 'Selected' ?> attr_id="{{$mange_currencies->id}}" attr_conversion_type="{{$mange_currencies->conversion_type}}" value="{{$mange_currencies->purchase_currency}} TO {{$mange_currencies->sale_currency}}">{{$mange_currencies->purchase_currency}} TO  {{$mange_currencies->sale_currency}}</option>
                                            @endforeach
                                        </select>
                                        <input type="hidden" id="conversion_type_Id"  name="conversion_type_Id" value="{{ $tranfer_destination->conversion_type_Id ?? '' }}">
                                        <input type="hidden" id="select_exchange_type" name="select_exchange_type" value="{{ $tranfer_destination->select_exchange_type ?? '' }}"> 
                                    </div>
                                </div>
                                
                                <div class="col-md-3 d-none" style="padding: 15px;">
                                    <label for="">Select Transfer Company</label>
                                    <select id="transfer_company" name="transfer_company" class="form-control transfer_company">
                                        <option value="">Select Company</option>
                                        @if(isset($tranfer_company) && $tranfer_company != null && $tranfer_company != '')
                                            @foreach($tranfer_company as $tranfer_companyS)
                                                <option <?php if($tranfer_destination->transfer_company == $tranfer_companyS->room_supplier_name) echo 'Selected' ?> value="{{ $tranfer_companyS->room_supplier_name }}">{{ $tranfer_companyS->room_supplier_name }}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                                
                                <div class="col-xl-6" style="padding: 15px;">
                                    <label for="">Select Trip Type</label>
                                    <select name="transfer_type" id="transfer_type" class="form-control"  data-placeholder="Choose ...">
                                        @if(isset($tranfer_destination->transfer_type) && $tranfer_destination->transfer_type != null && $tranfer_destination->transfer_type != '')
                                            <option <?php if($tranfer_destination->transfer_type == 'One-Way') echo 'selected'; ?> value="One-Way">One-Way</option>
                                            <option <?php if($tranfer_destination->transfer_type == 'Return') echo 'selected'; ?> value="Return">Return</option>
                                            <option <?php if($tranfer_destination->transfer_type == 'All_Round') echo 'selected'; ?> value="All_Round">All Round</option>
                                        @else
                                            <option value="One-Way">One-Way</option>
                                            <option value="Return">Return</option>
                                            <option value="All_Round">All Round</option>
                                        @endif
                                    </select>
                                </div>
                                
                                <div class="col-md-3" style="padding: 15px;">
                                    <label for="">Available From</label>
                                    <input value="{{ $tranfer_destination->available_from ?? '' }}" type="date" id="available_from" name="available_from" class="form-control available_from" required>
                                </div>
                                
                                <div class="col-md-3" style="padding: 15px;">
                                    <label for="">Available To</label>
                                    <input value="{{ $tranfer_destination->available_to ?? '' }}" type="date" id="available_to" name="available_to" class="form-control available_to" required>
                                </div>
                                
                                <div class="col-md-3" style="padding: 15px;">
                                    <label for="">Select Pickup City</label>
                                    <input value="{{ $tranfer_destination->pickup_City }}" type="text" id="pickup_City" name="pickup_City" class="form-control pickup_City">
                                </div>
                                
                                <div class="col-md-3" style="padding: 15px;">
                                    <label for="">Select Dropof City</label>
                                    <input value="{{ $tranfer_destination->dropof_City }}" type="text" id="dropof_City" name="dropof_City" class="form-control dropof_City">
                                </div>
                                
                                
                                <div class="row" id="returnDestinations" style="display:none">
                                    <h4>Return Destination Details</h4>
                                    <div class="col-md-5" style="padding: 15px;">
                                        <label for="">Select Return Pickup City</label>
                                        <input type="text" value="{{ $tranfer_destination->return_pickup_City ?? '' }}" id="return_pickup_City" name="return_pickup_City" class="form-control return_pickup_City">
                                    </div>
                                    
                                    <div class="col-md-5" style="padding: 15px;">
                                        <label for="">Select Return Dropof City</label>
                                        <input type="text" value="{{ $tranfer_destination->return_dropof_City ?? '' }}" id="return_dropof_City" name="return_dropof_City" class="form-control return_dropof_City">
                                    </div>
                                </div>
                                
                                <div class="col-md-12" id="subDestinations">
                                    @if(isset($tranfer_destination->more_destination_details) && $tranfer_destination->more_destination_details != null && $tranfer_destination->more_destination_details != '')
                                        <?php
                                            $subLocationCount = 1; 
                                            $more_destination_details = json_decode($tranfer_destination->more_destination_details);
                                        ?>
                                        @foreach($more_destination_details as $more_destination_detailsS)
                                            <div class="row" id="row{{ $subLocationCount }}">
                                                <h4>More Destination Details</h4>
                                                <div class="col-md-5" style="padding: 15px;">
                                                    <label for="">Select More Pickup City</label>
                                                    <input type="text" value="{{ $more_destination_detailsS->subLocationPic ?? '' }}" id="sublocPick{{ $subLocationCount }}" name="subLocationPic[]" class="form-control" required>
                                                </div>
                                                
                                                <div class="col-md-5" style="padding: 15px;">
                                                    <label for="">Select More Dropof City</label>
                                                    <input type="text" value="{{ $more_destination_detailsS->subLocationdrop ?? '' }}" id="sublocDrop{{ $subLocationCount }}" name="subLocationdrop[]" class="form-control" required>
                                                </div>
                                                
                                                <div class="col-md-2" style="padding: 15px; margin-top: 1.4rem;">
                                                    <button class="btn btn-danger" type="button" onclick="removeSublocation({{ $subLocationCount }})">Delete</button>
                                                </div>    
                                            </div>
                                            <?php $subLocationCount++ ?>
                                        @endforeach
                                        <input type="hidden" value="{{ $subLocationCount }}" id="subLocationCount_ID">
                                    @else
                                    @endif
                                    
                                </div>
                                
                                <div class="col-md-12" style="padding: 15px;">
                                    <button type="button" style="display:none;float: right;" id="subDestinations_button" onclick="addMoreSubDestination()" class="btn btn-info"> + Add More Destinations </button>
                                </div>
                                
                                <div id="append_Ziyarat">
                                    <?php $divId1 = 1; ?>
                                    @if(isset($tranfer_destination->ziyarat_City_details) && $tranfer_destination->ziyarat_City_details != null && $tranfer_destination->ziyarat_City_details != '')
                                        <?php $ziyarat_City_details = json_decode($tranfer_destination->ziyarat_City_details); ?>
                                        @foreach($ziyarat_City_details as $ziyarat_City_detailsS)
                                            <div class="row" id="ziyarat_div_{{ $divId1 }}">
                                                
                                                <div class="col-md-6" style="padding: 15px;">
                                                    <label for="">Select Ziyarat City</label>
                                                    <input type="text" value="{{ $ziyarat_City_detailsS->ziyarat_City ?? '' }}" id="ziyarat_City_{{ $divId1 }}" name="ziyarat_City[]" class="form-control">
                                                </div>
                                                
                                                <div class="col-md-6" style="padding: 15px;">
                                                    <div class="mt-2">
                                                        <a href="javascript:;" onclick="deleteZiyarat({{ $divId1 }})" class="btn btn-info" style="float: right;">Delete </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php $divId1++ ?>
                                        @endforeach
                                    @else
                                    @endif
                                    <input type="hidden" id="divId1_id" value="{{ $divId1 }}">
                                </div>
                                
                                <div class="mt-2">
                                    <a href="javascript:;" onclick="add_ziyarat()" class="btn btn-info" style="float: right;"> + Add Ziyarat </a>
                                </div>
                                
                                @if(isset($vehicle_details))
                                <?php $i = 1; ?>
                                    @foreach($vehicle_details as $vehicle_detail)
                                        <div class="row" id="vehicle_div_{{ $i }}">
                                            <div class="col-md-3" style="padding: 15px;">
                                                <label for="">Transfer Suppliers</label>
                                                <select name="transfer_supplier[]" class="form-control" id="transfer_supplier{{ $i }}" onchange="transfer_supplier_function({{ $i }})">
                                                    <option value="">Select Suppliers</option>
                                                    @foreach($tranfer_supplier as $tranfer_supplierS)
                                                        <option <?php if($vehicle_detail->transfer_supplier == $tranfer_supplierS->room_supplier_name) echo 'selected'; ?>  attr-id="{{ $tranfer_supplierS->id }}" value="{{ $tranfer_supplierS->room_supplier_name ?? '' }}">{{ $tranfer_supplierS->room_supplier_name ?? '' }}</option>
                                                    @endforeach
                                                </select>
                                                <input type="hidden" value="" id="vehicle_currency_symbol" name="currency_symbol[]">
                                                <input type="hidden" id="transfer_supplier_Id{{ $i }}" name="transfer_supplier_Id[]" value="{{ $vehicle_detail->transfer_supplier_Id ?? '' }}">
                                            </div>
                                        
                                            <div class="col-md-3" style="padding: 15px;">
                                                <label for="">Select Category Vehicle</label>
                                                <select name="vehicle_Name[]" class="form-control" id="vehicle_Data{{ $i }}" onchange="vehicle_DataF({{ $i }})">
                                                    @foreach($data as $value)
                                                        <option <?php if($vehicle_detail->vehicle_Name == $value->vehicle_Name) echo 'Selected'; ?> value="{{ json_encode($value) }}" attr="{{ $value->currency_symbol }}">{{ $value->vehicle_Name }}</option>
                                                    @endforeach
                                                </select>
                                                <input type="hidden" value="{{ $value->currency_symbol }}" id="vehicle_currency_symbol{{$i}}" name="currency_symbol[]">
                                            </div>
                                            
                                            <div class="col-md-2" style="padding: 15px;">
                                                <label for="">Fare</label>
                                                <div class="input-group">
                                                    <input value="{{ $vehicle_detail->vehicle_Fare }}" type="text" id="vehicle_Fare{{ $i }}" name="vehicle_Fare[]" class="form-control" >
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                                    </span>
                                                </div>
                                            </div>
                                        
                                            <div class="col-md-2" style="padding: 15px;">
                                                <label for="">Exchage Rate</label>
                                                <div class="input-group">
                                                    <input type="text" id="exchange_Rate{{ $i }}" value="{{ $vehicle_detail->exchange_Rate ?? '' }}" name="exchange_Rate[]" onkeyup="exchange_Rate_function({{ $i }})" class="form-control" required>
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                                    </span>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-2" style="padding: 15px;">
                                                <label for="">Total Fare</label>
                                                <div class="input-group">
                                                    <input type="text" id="vehicle_total_Fare{{ $i }}" value="{{ $vehicle_detail->vehicle_total_Fare ?? '' }}" name="vehicle_total_Fare[]" class="form-control" required>
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                    </span>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-2" style="padding: 15px;">
                                                <label for="">Markup Type</label>
                                                <select name="fare_markup_type[]" onchange="fare_markup_type_change({{ $i }})" id="fare_markup_type{{ $i }}" class="form-control">
                                                    <option <?php if($vehicle_detail->fare_markup_type == '%')  echo 'selected'; ?> value="%">Percentage</option>
                                                    <option <?php if($vehicle_detail->fare_markup_type == $currency)  echo 'selected'; ?> value="<?php echo $currency; ?>">Fixed Amount</option>
                                                </select>
                                            </div>
                                            
                                            <div class="col-md-2" style="padding: 15px;">
                                                <label for="">Markup</label>
                                                <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                    <input type="text" class="form-control" onkeyup="fare_markup_change({{ $i }})" value="{{ $vehicle_detail->fare_markup }}" id="fare_markup{{ $i }}" name="fare_markup[]">
                                                    <span class="input-group-btn input-group-append">
                                                        <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="fare_mrk{{ $i }}">{{ $vehicle_detail->fare_markup_type }}</div></button>
                                                    </span>
                                                </div>
                                            </div>
                                        
                                            <div class="col-md-2" style="padding: 15px;">
                                                <label for="">Total</label>
                                                <div class="input-group">
                                                    <input type="text" value="{{ $vehicle_detail->total_fare_markup }}" id="total_fare_markup{{ $i }}" name="total_fare_markup[]" class="form-control">
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                    </span>
                                                </div>
                                            </div>
                                            
                                            <div class="mt-2">
                                                <a href="javascript:;" onclick="deleteRowVehicle({{ $i }})" id="{{ $i }}" class="btn btn-info" style="float: right;">Delete</a>
                                            </div>
                                            
                                        </div>
                                    <?php $i++; ?>
                                    @endforeach
                                @endif
                                
                                <input type="hidden" value="{{ $i }}" id="divId">
                                    
                                <div id="append_Vehicle"></div>
                                
                                <div class="mt-2">
                                    <a href="javascript:;" onclick="add_more_vehicle()" class="btn btn-info" style="float: right;"> + Add More </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
            <div class="row">
                <div class="col-md-12 text-right mt-3">
                    <button type="submit" class="btn btn-primary">Update Destination</button>
                </div>
            </div>
        </form>
</div>

@endsection
@section('scripts')
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY&sensor=false&libraries=places"></script>

<script>
    
    let places,places1,input, address, city,subLocationCount = 1;
    function addGoogleApi(id){
            var places = new google.maps.places.Autocomplete(
                document.getElementById(id)
            );
            
            google.maps.event.addListener(places, "place_changed", function () {
                var place = places.getPlace();
                var address = place.formatted_address;
                var latitude = place.geometry.location.lat();
                var longitude = place.geometry.location.lng();
                var latlng = new google.maps.LatLng(latitude, longitude);
                var geocoder = (geocoder = new google.maps.Geocoder());
                geocoder.geocode({ latLng: latlng }, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        if (results[0]) {
                            var address = results[0].formatted_address;
                            var pin =
                            results[0].address_components[
                        results[0].address_components.length - 1
                      ].long_name;
                            var country =
                              results[0].address_components[
                                results[0].address_components.length - 2
                              ].long_name;
                            var state =
                              results[0].address_components[
                                results[0].address_components.length - 3
                              ].long_name;
                            var city =
                              results[0].address_components[
                                results[0].address_components.length - 4
                              ].long_name;
                            var country_code =
                              results[0].address_components[
                                results[0].address_components.length - 2
                              ].short_name;
                            $('#country').val(country);
                            $('#lat').val(latitude);
                            $('#long').val(longitude);
                            $('#pin').val(pin);
                            $('#city').val(city);
                            $('#country_code').val(country_code);
                            $('#pickup_CountryCode').val(country_code)
                        }
                    }
                });
            });
        }

    function vehicle_DataF(id){
        var vehicle_Data = $('#vehicle_Data'+id+'').find('option:selected').attr('attr');
        $('#vehicle_currency_symbol'+id+'').val(vehicle_Data)
    }
    
    $('#vehicle_Data').change(function(){
        var vehicle_Data = $(this).find('option:selected').attr('attr');
        $('#vehicle_currency_symbol').val(vehicle_Data)
    });
    
    $(document).ready(function(){
        addGoogleApi('pickup_City');
        addGoogleApi('dropof_City');
        addGoogleApi('return_pickup_City');
        addGoogleApi('return_dropof_City');
        
        var subLocationCount_ID = $('#subLocationCount_ID').val();
        for(i=1; i < subLocationCount_ID; i++){
            addGoogleApi('sublocPick'+i+'');
            addGoogleApi('sublocDrop'+i+'');
        }
        
        var divId1_id = $('#divId1_id').val();
        for(i=1; i < divId1_id; i++){
            addGoogleApi('ziyarat_City_'+i+'');
        }
        
        var value_c         = $("#currency_conversion1").val();
        const usingSplit    = value_c.split(' ');
        var value_1         = usingSplit['0'];
        var value_2         = usingSplit['2'];
        $(".currency_value1").html(value_1);
        $(".currency_value_exchange_1").html(value_2);
        
        var transfer_type = $('#transfer_type').find('option:selected').attr('value');
        if(transfer_type == 'Return'){
            $('#returnDestinations').css('display','');
            $('#subDestinations_button').css('display','none');
            $('#subDestinations').empty();
        }
        else if(transfer_type == 'All_Round'){
           $('#returnDestinations').css('display','none');
           $('#subDestinations_button').css('display','');
           $('#return_pickup_City').val('');
           $('#return_dropof_City').val('');
        }
        else{
            $('#returnDestinations').css('display','none');
            $('#subDestinations_button').css('display','none');
            $('#return_dropof_City').val('');
            $('#return_pickup_City').val('');
            $('#return_dropof_City').val('');
            $('#subDestinations').empty();
        }
        
    });
    
    $('#transfer_type').change(function(){
        var transfer_type = $(this).find('option:selected').attr('value');
        if(transfer_type == 'Return'){
            $('#returnDestinations').css('display','');
            $('#subDestinations_button').css('display','none');
            $('#return_pickup_City').val('');
            $('#return_dropof_City').val('');
            $('#subDestinations').empty();
        }
        else if(transfer_type == 'All_Round'){
           $('#returnDestinations').css('display','none');
           $('#subDestinations_button').css('display','');
           $('#return_pickup_City').val('');
           $('#return_dropof_City').val('');
           $('#subDestinations').empty();
        }
        else{
            $('#returnDestinations').css('display','none');
            $('#subDestinations_button').css('display','none');
            $('#return_dropof_City').val('');
            $('#return_pickup_City').val('');
            $('#return_dropof_City').val('');
            $('#subDestinations').empty();
        }
    });
    
    $('.CC_id_store').change(function(){
        var value                   = $(this).find('option:selected').attr('value');
        var attr_id                 = $(this).find('option:selected').attr('attr_id');
        var attr_conversion_type    = $(this).find('option:selected').attr('attr_conversion_type');
        
        $('#conversion_type_Id').val(attr_id);
        $('#select_exchange_type').val(attr_conversion_type);
        
        var value_c         = $("#currency_conversion1").val();
        const usingSplit    = value_c.split(' ');
        var value_1         = usingSplit['0'];
        var value_2         = usingSplit['2'];
        $(".currency_value1").html(value_1);
        $(".currency_value_exchange_1").html(value_2);
        exchange_currency_funs(value_1,value_2);
        
    });
    
    function exchange_Rate_function(id){
        var exchange_Rate   = $('#exchange_Rate'+id+'').val();
        var vehicle_Fare    = $('#vehicle_Fare'+id+'').val();
        var Total           = parseFloat(vehicle_Fare)/parseFloat(exchange_Rate);
        Total               = Total.toFixed(2);
        $('#vehicle_total_Fare'+id+'').val(Total);
    }
    
    function deleteRowVehicle(id){
        $('#vehicle_div_'+id+'').remove();
    }
    
    function add_more_vehicle(id){
        
        var divId = $('#divId').val();
        
        var data = `<div id="vehicle_div_${divId}" class="row">
                        
                        <div class="col-md-3" style="padding: 15px;">
                            <label for="">Transfer Suppliers</label>
                            <select name="transfer_supplier[]" class="form-control" id="transfer_supplier${divId}" onchange="transfer_supplier_function(${divId})">
                                <option value="">Select Suppliers</option>
                                @foreach($tranfer_supplier as $tranfer_supplierS)
                                    <option attr-id="{{ $tranfer_supplierS->id }}" value="{{ $tranfer_supplierS->room_supplier_name }}">{{ $tranfer_supplierS->room_supplier_name }}</option>
                                @endforeach
                            </select>
                            <input type="hidden" value="" id="vehicle_currency_symbol" name="currency_symbol[]">
                            <input type="hidden" id="transfer_supplier_Id${divId}" name="transfer_supplier_Id[]">
                        </div>
                        
                        <div class="col-md-3" style="padding: 15px;">
                            <label for="">Select Category Vehicle</label>
                            <select name="vehicle_Name[]" class="form-control" id="vehicle_Data${divId}" onchange="vehicle_DataF(${divId})">
                                <option value="">Select Vehicle</option>
                                @foreach($data as $value)
                                    <option value="{{ $value->vehicle_Name }}" attr="{{ $value->currency_symbol }}">{{ $value->vehicle_Name }}</option>
                                @endforeach
                            </select>
                            <input type="hidden" value="" id="vehicle_currency_symbol${divId}" name="currency_symbol[]">
                        </div>
                        
                        <div class="col-md-2" style="padding: 15px;">
                            <label for="">Fare</label>
                            <div class="input-group">
                                <span class="input-group-btn input-group-append">
                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                </span>
                                <input type="text" id="vehicle_Fare${divId}" name="vehicle_Fare[]" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="col-md-2" style="padding: 15px;">
                            <label for="">Exchage Rate</label>
                            <div class="input-group">
                                <input type="text" id="exchange_Rate${divId}" name="exchange_Rate[]" class="form-control" required onkeyup="exchange_Rate_function(${divId})">
                                <span class="input-group-btn input-group-append">
                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                </span>
                            </div>
                        </div>
                        
                        <div class="col-md-2" style="padding: 15px;">
                            <label for="">Total Fare</label>
                            <div class="input-group">
                                <input type="text" id="vehicle_total_Fare${divId}" name="vehicle_total_Fare[]" class="form-control" required>
                                <span class="input-group-btn input-group-append">
                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                </span>
                            </div>
                        </div>
                        
                        <div class="col-md-2" style="padding: 15px;">
                            <label for="">Markup Type</label>
                            <select name="fare_markup_type[]" onchange="fare_markup_type_change(${divId})" id="fare_markup_type${divId}" class="form-control">
                                <option value="">Markup Type</option>
                                <option value="%">Percentage</option>
                                <option value="<?php echo $currency; ?>">Fixed Amount</option>
                            </select>
                        </div>
                        
                        <div class="col-md-2" style="padding: 15px;">
                            <label for="">Fare Markup</label>
                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                <input type="text" class="form-control" onkeyup="fare_markup_change(${divId})" id="fare_markup${divId}" name="fare_markup[]">
                                <span class="input-group-btn input-group-append">
                                    <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="fare_mrk${divId}">%</div></button>
                                </span>
                            </div>
                        </div>
                        
                        <div class="col-md-2" style="padding: 15px;">
                            <label for="">Total</label>
                            <div class="input-group">
                                <input type="text" id="total_fare_markup${divId}" name="total_fare_markup[]" class="form-control">
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                    </span>
                            </div>
                        </div>
                        <div class="mt-2">
                            <a href="javascript:;" onclick="deleteRowVehicle(${divId})" id="${divId}" class="btn btn-info" style="float: right;">Delete </a>
                        </div>
                    </div>`;
        
        $("#append_Vehicle").append(data);
        
        var value_c         = $("#currency_conversion1").val();
        const usingSplit    = value_c.split(' ');
        var value_1         = usingSplit['0'];
        var value_2         = usingSplit['2'];
        $(".currency_value1").html(value_1);
        $(".currency_value_exchange_1").html(value_2);
        exchange_currency_funs(value_1,value_2);
        
        divId = parseFloat(divId) + 1;
        $('#divId').val(divId);
    }
    
    function transfer_supplier_function(id){
        var ids = $('#transfer_supplier'+id+'').find('option:selected').attr('attr-id');
        $('#transfer_supplier_Id'+id+'').val(ids);
    }
    
    function addMoreSubDestination(){
        var row = `<div class="row" id="row${subLocationCount}">
                        <h4>More Destination Details</h4>
                        <div class="col-md-5" style="padding: 15px;">
                            <label for="">Select More Pickup City</label>
                            <input type="text" id="sublocPick${subLocationCount}" name="subLocationPic[]" class="form-control" required>
                        </div>
                        
                        <div class="col-md-5" style="padding: 15px;">
                            <label for="">Select More Dropof City</label>
                            <input type="text" id="sublocDrop${subLocationCount}" name="subLocationdrop[]" class="form-control" required>
                        </div>
                        
                        <div class="col-md-2" style="padding: 15px; margin-top: 1.4rem;">
                            <button class="btn btn-danger" type="button" onclick="removeSublocation(${subLocationCount})">Delete</button>
                        </div>
                        
                    </div>`;
                    
        $('#subDestinations').append(row);
        addGoogleApi('sublocPick'+subLocationCount+'');
        addGoogleApi('sublocDrop'+subLocationCount+'');
        subLocationCount++;
    }
    
    function removeSublocation(id){
        $("#row"+id+"").remove();
    }
    
    function add_ziyarat(){
        
        var divId1 = $('#divId1_id').val();
        
        var data = `<div id="ziyarat_div_${divId1}" class="row">
                        
                        <div class="col-md-6" style="padding: 15px;">
                            <label>Select Ziyarat City</label>
                            <input type="text" id="ziyarat_City_${divId1}" name="ziyarat_City[]" class="form-control" required>
                        </div>
                        
                        <div class="col-md-6" style="padding: 15px;">
                            <div class="mt-2">
                                <a href="javascript:;" onclick="deleteZiyarat(${divId1})" class="btn btn-info" style="float: right;">Delete </a>
                            </div>
                        </div>
                        
                    </div>`;
        
        $("#append_Ziyarat").append(data);
        
        addGoogleApi('ziyarat_City_'+divId1+'');
        
        divId1 = parseFloat(divId) + 1;
        $('#divId1_id').val(divId1);
    }
    
    function deleteZiyarat(id){
        $('#ziyarat_div_'+id+'').remove();
    }
    
</script>

<script>

    function fare_markup_type_change(id){
        var ids = $('#fare_markup_type'+id+'').find('option:selected').attr('value');
        $('#fare_mrk'+id+'').text(ids);
    }
    
    function fare_markup_change(id){
        var ids = $('#fare_markup_type'+id+'').find('option:selected').attr('value');
        if(ids == '%')
        {
            var fare_markup     =  $('#fare_markup'+id+'').val();
            var vehicle_Fare    =  $('#vehicle_total_Fare'+id+'').val();
            var total1          = (vehicle_Fare * fare_markup/100) + parseFloat(vehicle_Fare);
            var total           = total1.toFixed(2);
            $('#total_fare_markup'+id+'').val(total);
        }
        else
        {
            var fare_markup     =  $('#fare_markup'+id+'').val();
            var vehicle_Fare    =  $('#vehicle_total_Fare'+id+'').val();
            var total1          =  parseFloat(vehicle_Fare) +  parseFloat(fare_markup);
            var total           = total1.toFixed(2);
            $('#total_fare_markup'+id+'').val(total);
        }
    }
    
</script>
@stop



