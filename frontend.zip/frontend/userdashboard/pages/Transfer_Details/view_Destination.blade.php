@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php $currency=Session::get('currency_symbol'); ?>

<div class="dashboard-content">
    
    <h3 style="color:#a30000">Manage Destination</h3>
    <form action="{{URL::to('add_new_destination')}}" method="post" enctype="multipart/form-data" style="padding-bottom: 40px">
        @csrf
        <div class="row">
            <div class="col-md-12 mb-4">
                @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" style="background-color:#d4edda;" role="alert">
                    {{ session('success') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif

                @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show" style="background-color:#f5cfcf;" role="alert">
                    {{ session('error') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif
            </div>
            
            <div class="col-md-12">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                        <div class="row">
                            
                            <input type="hidden" id="pickup_CountryCode" name="pickup_CountryCode">
                            
                            <div class="col-xl-6" style="padding-left: 15px;padding-top: 7px;">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Currency Conversion</label>
                                    <select class="form-control CC_id_store" name="currency_conversion" id="currency_conversion1">
                                        <option value="0">Select Currency Conversion</option>
                                        @foreach($mange_currencies as $mange_currencies)
                                            <option attr_id="{{$mange_currencies->id}}" attr_conversion_type="{{$mange_currencies->conversion_type}}" value="{{$mange_currencies->purchase_currency}} TO {{$mange_currencies->sale_currency}}">{{$mange_currencies->purchase_currency}} TO  {{$mange_currencies->sale_currency}}</option>
                                        @endforeach
                                    </select>
                                    <input type="hidden" id="conversion_type_Id"  name="conversion_type_Id">
                                    <input type="hidden" id="select_exchange_type" name="select_exchange_type"> 
                                </div>
                            </div>
                            
                            <div class="col-md-4 d-none" style="padding: 15px;">
                                <label for="">Select Transfer Company</label>
                                <select id="transfer_company" name="transfer_company" class="form-control transfer_company">
                                    <option value="">Select Company</option>
                                    @if(isset($tranfer_company) && $tranfer_company != null && $tranfer_company != '')
                                        @foreach($tranfer_company as $tranfer_companyS)
                                            <option value="{{ $tranfer_companyS->room_supplier_name }}">{{ $tranfer_companyS->room_supplier_name }}</option>
                                        @endforeach
                                    @endif
                                </select>
                            </div>
                            
                            <div class="col-xl-6" style="padding: 15px;">
                                <label for="">Select Trip Type</label>
                                <select name="transfer_type" id="transfer_type" class="form-control"  data-placeholder="Choose ...">
                                    <option value="One-Way">One-Way</option>
                                    <option value="Return">Return</option>
                                    <option value="All_Round">All Round</option>
                                </select>
                            </div>
                            
                            <div class="col-md-3" style="padding: 15px;">
                                <label for="">Available From</label>
                                <input type="date" id="available_from" name="available_from" class="form-control available_from" required>
                            </div>
                            
                            <div class="col-md-3" style="padding: 15px;">
                                <label for="">Available To</label>
                                <input type="date" id="available_to" name="available_to" class="form-control available_to" required>
                            </div>
                            
                            <div class="col-md-3" style="padding: 15px;">
                                <label for="">Select Pickup City</label>
                                <input type="text" id="pickup_City" name="pickup_City" class="form-control pickup_City" required>
                            </div>
                            
                            <div class="col-md-3" style="padding: 15px;">
                                <label for="">Select Dropof City</label>
                                <input type="text" id="dropof_City" name="dropof_City" class="form-control dropof_City" required>
                            </div>
                            
                            <div class="row" id="returnDestinations" style="display:none">
                                <h4>Return Destination Details</h4>
                                
                                <div class="col-md-6" style="padding: 15px;">
                                    <label for="">Select Return Pickup City</label>
                                    <input type="text" id="return_pickup_City" name="return_pickup_City" class="form-control return_pickup_City">
                                </div>
                                
                                <div class="col-md-6" style="padding: 15px;">
                                    <label for="">Select Return Dropof City</label>
                                    <input type="text" id="return_dropof_City" name="return_dropof_City" class="form-control return_dropof_City">
                                </div>
                            </div>
                            
                            <div class="col-md-12" id="subDestinations"></div>
                            
                            <div class="col-md-12" style="padding: 15px;">
                                <button type="button" style="display:none;float: right;" id="subDestinations_button" onclick="addMoreSubDestination()" class="btn btn-info"> + Add More Destinations </button>
                            </div>
                            
                            <div id="append_Ziyarat"></div>
                            
                            <div class="mt-2">
                                <a href="javascript:;" onclick="add_ziyarat()" class="btn btn-info" style="float: right;"> + Add Ziyarat </a>
                            </div>
                            
                            <div class="col-md-3" style="padding: 15px;">
                                <label for="">Transfer Suppliers</label>
                                <select name="transfer_supplier[]" class="form-control" id="transfer_supplier">
                                    <option value="">Select Suppliers</option>
                                    @foreach($tranfer_supplier as $tranfer_supplierS)
                                        <option attr-id="{{ $tranfer_supplierS->id }}" value="{{ $tranfer_supplierS->room_supplier_name }}">{{ $tranfer_supplierS->room_supplier_name }}</option>
                                    @endforeach
                                </select> 
                                <input type="hidden" value="" id="vehicle_currency_symbol" name="currency_symbol[]">
                                <input type="hidden" id="transfer_supplier_Id" name="transfer_supplier_Id[]">
                            </div>
                            
                            <div class="col-md-3" style="padding: 15px;">
                                <label for="">Select Category Vehicle</label>
                                <select name="vehicle_Name[]" class="form-control" id="vehicle_Data">
                                    <option value="">Select Vehicle</option>
                                    @foreach($data as $value)
                                        <option value='{{ json_encode($value) }}' attr="{{ $value->currency_symbol }}">{{ $value->vehicle_Name }}</option>
                                    @endforeach
                                </select>
                                <input type="hidden" value="" id="vehicle_currency_symbol" name="currency_symbol[]">
                            </div>
                            
                            <div class="col-md-2" style="padding: 15px;">
                                <label for="">Fare</label>
                                <div class="input-group">
                                    <input type="text" id="vehicle_Fare" name="vehicle_Fare[]" class="form-control" required>
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="col-md-2" style="padding: 15px;">
                                <label for="">Exchage Rate</label>
                                <div class="input-group">
                                    <input type="text" id="exchange_Rate" name="exchange_Rate[]" class="form-control" required>
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="col-md-2" style="padding: 15px;">
                                <label for="">Total Fare</label>
                                <div class="input-group">
                                    <input type="text" id="vehicle_total_Fare" name="vehicle_total_Fare[]" class="form-control" required>
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="col-md-12" style="padding: 15px;">
                                <input class="form-check-input display_on_website" counter="0" type="checkbox" name="display_on_website[]" value="true" id="display_on_website0">
                                    <label class="form-check-label" for="display_on_website0">
                                         Display on Website
                                    </label>
                                    <div class="row" id="display_markup0" style="display:none;">
                                        <div class="col-md-2" style="padding: 15px;">
                                            <label for="">Markup Type</label>
                                            <select name="fare_markup_type[]" id="fare_markup_type" class="form-control">
                                                <option value="">Markup Type</option>
                                                <option value="%">Percentage</option>
                                                <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                            </select>
                                        </div>
                                        
                                        <div class="col-md-2" style="padding: 15px;">
                                            <label for="">Markup</label>
                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                <input type="text" class="form-control" id="fare_markup" name="fare_markup[]">
                                                <span class="input-group-btn input-group-append">
                                                    <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="fare_mrk">%</div></button>
                                                </span>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-2" style="padding: 15px;">
                                            <label for="">Total</label>
                                            <div class="input-group">
                                                <input type="text" id="total_fare_markup" name="total_fare_markup[]" class="form-control">
                                                <span class="input-group-btn input-group-append">
                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            
                            <div id="append_Vehicle"></div>
                            
                            <div class="mt-2">
                                <a href="javascript:;" onclick="add_more_vehicle()" class="btn btn-info" style="float: right;"> + Add More </a>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 text-right mt-3">
                <button type="submit" class="btn btn-primary">Submit Destination</button>
            </div>
        </div>
    </form>
    
    <div class="dashboard-content">
        <h3 style="color:#a30000;font-size: 40px;text-align:center">Vehicle List</h3>
        <div class="row">
            <div class="col-lg-12 col-sm-12">
                <div class="dashboard-list-box dash-list margin-top-0">
                    <div class="row">
                        <div class="col-md-12">
                             <table id="myTable" class="display nowrap table  table-bordered" style="width:100%;">
                                <thead class="theme-bg-clr">
                                    <tr>
                                        <th style="text-align: center;">Sr</th>
                                        <th style="text-align: center;">Dates</th>
                                        <th style="text-align: center;">Destinations</th>
                                        <th style="text-align: center;">Trip Type</th>
                                        <th style="text-align: center;">Vehicle Details</th>
                                        <th style="text-align: center;">Options</th>
                                    </tr>
                                </thead>
                                <tbody style="text-align: center;">
                                    @php $x = 1; @endphp
                                    @foreach($tranfer_destination as $value)
                                        <?php 
                                            $vehicle_details = json_decode($value->vehicle_details);
                                        ?>
                                            <tr>
                                                <td>{{ $x++ }}</td>
                                                <td>
                                                    Available From  : <b>{{ $value->available_from ?? '' }}</b><br>
                                                    Available To    : <b>{{ $value->available_to ?? '' }}</b>
                                                </td>
                                                <td>
                                                    Pickup City : <b>{{ $value->pickup_City }}</b><br>
                                                    Dropof City : <b>{{ $value->dropof_City }}</b>
                                                </td>
                                                <td>{{ $value->transfer_type }}</td>
                                                <td>
                                                    @if(isset($vehicle_details))
                                                        @foreach($vehicle_details as $value2)
                                                            Type    : <b>{{ $value2->vehicle_Name ?? '' }}</b><br>
                                                            Price   : <b>{{ $currency }} {{ $value2->vehicle_Fare ?? '' }}</b><br>
                                                        @endforeach
                                                    @endif
                                                </td>
                                                <td>
                                                    <a href="{{ URL::to('edit_destination_details/'.$value->id.'') }}" class="btn btn-secondary btn-sm">Edit Details</a>
                                                </td>
                                            </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>


@endsection
@section('scripts')
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY&sensor=false&libraries=places"></script>

<script>
     $(".display_on_website").click(function (){
         var value = $(this).attr('counter');
         console.log('The Value is '+value)
     if ($("#display_on_website"+value+"").is(':checked')){
         $("#display_markup"+value+"").css('display','flex');
     }else{
           $("#display_markup"+value+"").css('display','none');
     }
       
    })
    
    function displayOnWebMore(id){
        console.log('The is call now '+id)
        if ($("#display_on_website"+id+"").is(':checked')){
            $("#display_markup"+id+"").css('display','flex');
         }else{
            $("#display_markup"+id+"").css('display','none');
         }
    }
    $('#vehicle_Data').change(function(){
        var vehicle_Data = $(this).find('option:selected').attr('attr');
        $('#vehicle_currency_symbol').val(vehicle_Data)
    });
    
    $('.CC_id_store').change(function(){
        var value                   = $(this).find('option:selected').attr('value');
        var attr_id                 = $(this).find('option:selected').attr('attr_id');
        var attr_conversion_type    = $(this).find('option:selected').attr('attr_conversion_type');
        
        $('#conversion_type_Id').val(attr_id);
        $('#select_exchange_type').val(attr_conversion_type);
        
        var value_c         = $("#currency_conversion1").val();
        const usingSplit    = value_c.split(' ');
        var value_1         = usingSplit['0'];
        var value_2         = usingSplit['2'];
        $(".currency_value1").html(value_1);
        $(".currency_value_exchange_1").html(value_2);
        exchange_currency_funs(value_1,value_2);
        
    });
    
    $('#exchange_Rate').keyup(function(){
        var exchange_Rate   = $(this).val();
        var vehicle_Fare    = $('#vehicle_Fare').val();
        var Total           = parseFloat(vehicle_Fare)/parseFloat(exchange_Rate);
        Total               = Total.toFixed(2);
        $('#vehicle_total_Fare').val(Total);
    });
    
    $('#transfer_supplier').change(function (){
        var ids = $(this).find('option:selected').attr('attr-id');
        $('#transfer_supplier_Id').val(ids);
    });
    
</script>

<script>
    let places,places1,input, address, city,subLocationCount = 1;
   
    $(document).ready(function(){
        addGoogleApi('pickup_City');
        addGoogleApi('dropof_City');
        addGoogleApi('return_pickup_City');
        addGoogleApi('return_dropof_City');
    });
    
    function addGoogleApi(id){
        var places = new google.maps.places.Autocomplete(
            document.getElementById(id)
        );
        
        google.maps.event.addListener(places, "place_changed", function () {
            var place = places.getPlace();
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                        $('#pickup_CountryCode').val(country_code)
                    }
                }
            });
        });
    }
    
    function addMoreSubDestination(){
        var row = `<div class="row" id="row${subLocationCount}">
                        <h4>More Destination Details</h4>
                        <div class="col-md-5" style="padding: 15px;">
                            <label for="">Select More Pickup City</label>
                            <input type="text" id="sublocPick${subLocationCount}" name="subLocationPic[]" class="form-control" required>
                        </div>
                        
                        <div class="col-md-5" style="padding: 15px;">
                            <label for="">Select More Dropof City</label>
                            <input type="text" id="sublocDrop${subLocationCount}" name="subLocationdrop[]" class="form-control" required>
                        </div>
                        
                        <div class="col-md-2" style="padding: 15px; margin-top: 1.4rem;">
                            <button class="btn btn-danger" type="button" onclick="removeSublocation(${subLocationCount})">Delete</button>
                        </div>
                        
                    </div>`;
                    
        $('#subDestinations').append(row);
        addGoogleApi('sublocPick'+subLocationCount+'');
        addGoogleApi('sublocDrop'+subLocationCount+'');
        subLocationCount++;
    }
    
    function removeSublocation(id){
        $("#row"+id+"").remove();
    }
    
    $('#transfer_type').change(function(){
        var transfer_type = $(this).find('option:selected').attr('value');
        if(transfer_type == 'Return'){
            $('#returnDestinations').css('display','');
            $('#subDestinations_button').css('display','none');
            $('#return_pickup_City').val('');
            $('#return_dropof_City').val('');
            $('#subDestinations').empty();
        }
        else if(transfer_type == 'All_Round'){
           $('#returnDestinations').css('display','none');
           $('#subDestinations_button').css('display','');
           $('#return_pickup_City').val('');
           $('#return_dropof_City').val('');
           $('#subDestinations').empty();
        }
        else{
            $('#returnDestinations').css('display','none');
            $('#subDestinations_button').css('display','none');
            $('#return_dropof_City').val('');
            $('#return_pickup_City').val('');
            $('#return_dropof_City').val('');
            $('#subDestinations').empty();
        }
    });
    
    $('#available_from').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var available_from  = $(this).val();
        var available_to    = $('#available_to').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var date1               = new Date(available_from);
        var date2               = new Date(available_to);
        var timediff            = date2 - date1;
        var minutes_Total       = Math.floor(timediff / minute);
        var total_hours         = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        
        var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        // $('#transportation_Time_Div').css('display','');
        $('#total_duration').val(total_hours+h+ ' : ' +minutes+m);
        
    });
    
    $('#available_to').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var available_to    = $(this).val();
        var available_from  = $('#available_from').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var date1               = new Date(available_from);
        var date2               = new Date(available_to);
        var timediff            = date2 - date1;
        var minutes_Total       = Math.floor(timediff / minute);
        var total_hours         = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        
        var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        // $('#transportation_Time_Div').css('display','');
        $('#total_duration').val(total_hours+h+ ' : ' +minutes+m);
        
    });
    
    $('#return_available_from').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var return_available_from  = $(this).val();
        var return_available_to    = $('#return_available_to').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var date1               = new Date(return_available_from);
        var date2               = new Date(return_available_to);
        var timediff            = date2 - date1;
        var minutes_Total       = Math.floor(timediff / minute);
        var total_hours         = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        
        var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        // $('#transportation_Time_Div').css('display','');
        $('#return_total_duration').val(total_hours+h+ ' : ' +minutes+m);
        
    });
    
    $('#return_available_to').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var return_available_to    = $(this).val();
        var return_available_from  = $('#return_available_from').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var date1               = new Date(return_available_from);
        var date2               = new Date(return_available_to);
        var timediff            = date2 - date1;
        var minutes_Total       = Math.floor(timediff / minute);
        var total_hours         = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        
        var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        // $('#transportation_Time_Div').css('display','');
        $('#return_total_duration').val(total_hours+h+ ' : ' +minutes+m);
        
    });
    
</script>

<script>
    $(document).ready( function () {
        $('#myTable').DataTable({
            "scrollX": true,
        });
    } );
</script>

<script>

    var divId = 1;
    function add_more_vehicle(){
    
        var data = `<div id="vehicle_div_${divId}" class="row">
                        
                        <div class="col-md-3" style="padding: 15px;">
                            <label for="">Transfer Suppliers</label>
                            <select name="transfer_supplier[]" class="form-control" id="transfer_supplier${divId}" onchange="transfer_supplier_function(${divId})">
                                <option value="">Select Suppliers</option>
                                @foreach($tranfer_supplier as $tranfer_supplierS)
                                    <option attr-id="{{ $tranfer_supplierS->id }}" value="{{ $tranfer_supplierS->room_supplier_name }}">{{ $tranfer_supplierS->room_supplier_name }}</option>
                                @endforeach
                            </select>
                            <input type="hidden" value="" id="vehicle_currency_symbol" name="currency_symbol[]">
                            <input type="hidden" id="transfer_supplier_Id${divId}" name="transfer_supplier_Id[]">
                        </div>
                        
                        <div class="col-md-3" style="padding: 15px;">
                            <label for="">Select Category Vehicle</label>
                            <select name="vehicle_Name[]" class="form-control" id="vehicle_Data${divId}" onchange="vehicle_DataF(${divId})">
                                <option value="">Select Vehicle</option>
                                @foreach($data as $value)
                                    <option value='{{ json_encode($value) }}' attr="{{ $value->currency_symbol }}">{{ $value->vehicle_Name }}</option>
                                @endforeach
                            </select>
                            <input type="hidden" value="" id="vehicle_currency_symbol${divId}" name="currency_symbol[]">
                        </div>
                        
                        <div class="col-md-2" style="padding: 15px;">
                            <label for="">Fare</label>
                            <div class="input-group">
                                <span class="input-group-btn input-group-append">
                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                </span>
                                <input type="text" id="vehicle_Fare${divId}" name="vehicle_Fare[]" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="col-md-2" style="padding: 15px;">
                            <label for="">Exchage Rate</label>
                            <div class="input-group">
                                <input type="text" id="exchange_Rate${divId}" name="exchange_Rate[]" class="form-control" required onkeyup="exchange_Rate_function(${divId})">
                                <span class="input-group-btn input-group-append">
                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                </span>
                            </div>
                        </div>
                        
                        <div class="col-md-2" style="padding: 15px;">
                            <label for="">Total Fare</label>
                            <div class="input-group">
                                <input type="text" id="vehicle_total_Fare${divId}" name="vehicle_total_Fare[]" class="form-control" required>
                                <span class="input-group-btn input-group-append">
                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                </span>
                            </div>
                        </div>
                       
                       
                       <div class="col-md-12" style="padding: 15px;">
                            <input class="form-check-input display_on_website" counter="${divId}" type="checkbox" name="display_on_website[]" value="true" id="display_on_website${divId}">
                                <label class="form-check-label" for="display_on_website${divId}">
                                     Display on Website
                                </label>
                                <div class="row" id="display_markup${divId}" style="display:none;">
                                    <div class="col-md-2" style="padding: 15px;">
                                        <label for="">Markup Type</label>
                                        <select name="fare_markup_type[]" onchange="fare_markup_type_change(${divId})" id="fare_markup_type${divId}" class="form-control">
                                            <option value="">Markup Type</option>
                                            <option value="%">Percentage</option>
                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-2" style="padding: 15px;">
                                        <label for="">Fare Markup</label>
                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                            <input type="text" class="form-control" onkeyup="fare_markup_change(${divId})" id="fare_markup${divId}" name="fare_markup[]">
                                            <span class="input-group-btn input-group-append">
                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="fare_mrk${divId}">%</div></button>
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-2" style="padding: 15px;">
                                        <label for="">Total</label>
                                        <div class="input-group">
                                            <input type="text" id="total_fare_markup${divId}" name="total_fare_markup[]" class="form-control">
                                                <span class="input-group-btn input-group-append">
                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                </span>
                                        </div>
                                    </div>
                                </div>
                        </div> 
                        </div> 
                        <div class="mt-2">
                            <a href="javascript:;" onclick="deleteRowVehicle(${divId})" id="${divId}" class="btn btn-info" style="float: right;">Delete </a>
                        </div>
                    </div>`;
        
        $("#append_Vehicle").append(data);
        
        $(".display_on_website").click(function (){
            var value = $(this).attr('counter');
            if ($("#display_on_website"+value+"").is(':checked')){
                $("#display_markup"+value+"").css('display','flex');
            }else{
               $("#display_markup"+value+"").css('display','none');
            }
           
        })
    
        var value_c         = $("#currency_conversion1").val();
        const usingSplit    = value_c.split(' ');
        var value_1         = usingSplit['0'];
        var value_2         = usingSplit['2'];
        $(".currency_value1").html(value_1);
        $(".currency_value_exchange_1").html(value_2);
        exchange_currency_funs(value_1,value_2);
        
        divId=divId + 1;
    }
    
    var divId1 = 1;
    function add_ziyarat(){
        var data = `<div id="ziyarat_div_${divId1}" class="row">
                        
                        <div class="col-md-6" style="padding: 15px;">
                            <label>Select Ziyarat City</label>
                            <input type="text" id="ziyarat_City_${divId1}" name="ziyarat_City[]" class="form-control" required>
                        </div>
                        
                        <div class="col-md-6" style="padding: 15px;">
                            <div class="mt-2">
                                <a href="javascript:;" onclick="deleteZiyarat(${divId1})" id="${divId1}" class="btn btn-info" style="float: right;">Delete </a>
                            </div>
                        </div>
                        
                    </div>`;
        
        $("#append_Ziyarat").append(data);
        
        addGoogleApi('ziyarat_City_'+divId1+'');
        
        divId1 = divId1 + 1;
    }
    
    function transfer_supplier_function(id){
        var ids = $('#transfer_supplier'+id+'').find('option:selected').attr('attr-id');
        $('#transfer_supplier_Id'+id+'').val(ids);
    }
    
    function exchange_Rate_function(id){
        var exchange_Rate   = $('#exchange_Rate'+id+'').val();
        var vehicle_Fare    = $('#vehicle_Fare'+id+'').val();
        var Total           = parseFloat(vehicle_Fare)/parseFloat(exchange_Rate);
        Total               = Total.toFixed(2);
        $('#vehicle_total_Fare'+id+'').val(Total);
    }
    
    function deleteRowVehicle(id){
        $('#vehicle_div_'+id+'').remove();
    }
    
    function deleteZiyarat(id){
        $('#ziyarat_div_'+id+'').remove();
    }
    
    function vehicle_DataF(id){
        var vehicle_Data = $('#vehicle_Data'+id+'').find('option:selected').attr('attr');
        $('#vehicle_currency_symbol'+id+'').val(vehicle_Data)
    }
    
</script>

<script>
    $("#fare_markup").keyup(function () {
        var id = $('#fare_markup_type').find('option:selected').attr('value');
        
        if(id == '%')
        {
            var fare_markup     =  $('#fare_markup').val();
            var vehicle_Fare    =  $('#vehicle_total_Fare').val();
            var total1          = (vehicle_Fare * fare_markup/100) + parseFloat(vehicle_Fare);
            var total           = total1.toFixed(2);
            $('#total_fare_markup').val(total);
        }
        else
        {
            var fare_markup     =  $('#fare_markup').val();
            var vehicle_Fare    =  $('#vehicle_total_Fare').val();
            var total1          =  parseFloat(vehicle_Fare) +  parseFloat(fare_markup);
            var total           = total1.toFixed(2);
            $('#total_fare_markup').val(total);
        }
    });
    
    function fare_markup_type_change(id){
        var ids = $('#fare_markup_type'+id+'').find('option:selected').attr('value');
    }
    
    function fare_markup_change(id){
        var ids = $('#fare_markup_type'+id+'').find('option:selected').attr('value');
        if(ids == '%')
        {
            var fare_markup     =  $('#fare_markup'+id+'').val();
            var vehicle_Fare    =  $('#vehicle_total_Fare'+id+'').val();
            var total1          = (vehicle_Fare * fare_markup/100) + parseFloat(vehicle_Fare);
            var total           = total1.toFixed(2);
            $('#total_fare_markup'+id+'').val(total);
        }
        else
        {
            var fare_markup     =  $('#fare_markup'+id+'').val();
            var vehicle_Fare    =  $('#vehicle_total_Fare'+id+'').val();
            var total1          =  parseFloat(vehicle_Fare) +  parseFloat(fare_markup);
            var total           = total1.toFixed(2);
            $('#total_fare_markup'+id+'').val(total);
        }
    }
</script>
@stop