@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php $currency=Session::get('currency_symbol'); ?>

<div class="dashboard-content">
    
    <h3 style="color:#a30000">Add Vehcile Category</h3>
    <form action="{{URL::to('add_new_vehicle_category')}}" method="post" enctype="multipart/form-data" style="padding-bottom: 40px">
        @csrf
        <div class="row">
            <div class="col-md-12 mb-4">
                @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" style="background-color:#d4edda;" role="alert">
                    {{ session('success') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif

                @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show" style="background-color:#f5cfcf;" role="alert">
                    {{ session('error') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif
            </div>
            
            <div class="col-md-12">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                        <div class="row">
                           
                            <div class="col-md-4" style="padding: 15px;">
                                <label for="">Vehicle Category</label>
                                <input type="text" id="vehicle_category" name="vehicle_category" class="form-control" required>
                            </div>
                            
                            <div class="col-md-4" style="padding: 15px;">
                                <label for="">Max Passengers</label>
                                <input type="number" id="max_passeneger" name="max_passeneger" class="form-control" required>
                            </div>
                            
                            <div class="col-md-4" style="padding: 15px;">
                                <label for="">Max Bagages</label>
                                <input type="number" id="max_bagage" name="max_bagage" class="form-control" required>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 text-right mt-3">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
    
    <div class="dashboard-content">
        <h3 style="color:#a30000;font-size: 40px;text-align:center">Vehicle Category Details</h3>
        <div class="row">
            <div class="col-lg-12 col-sm-12">
                <div class="dashboard-list-box dash-list margin-top-0">
                    <div class="row">
                        <div class="col-md-12">
                             <table id="myTable" class="display nowrap table  table-bordered" style="width:100%;">
                                <thead class="theme-bg-clr">
                                    <tr>
                                        <th style="text-align: center;">Sr</th>
                                        <th style="text-align: center;">Vehicle Category</th>
                                        <th style="text-align: center;">Max Passengers</th>
                                        <th style="text-align: center;">Max Bagages</th>
                                        <th style="text-align: center;">Edit</th>
                                        <th class="d-none" style="text-align: center;">Delete</th>
                                    </tr>
                                </thead>
                                <tbody style="text-align: center;">
                                    @php $x = 1; @endphp
                                    @foreach($vehicle_Category as $value)
                                            <tr>
                                                <td>{{ $x++ }}</td>
                                                <td>{{ $value->vehicle_category ?? '' }}</td>
                                                <td>{{ $value->max_passeneger ?? '' }}</td>
                                                <td>{{ $value->max_bagage ?? '' }}</td>
                                                <td><a href="{{ URL::to('edit_vehicle_category/'.$value->id.'') }}" class="btn btn-secondary btn-sm">Edit Details</a></td>
                                                <td class="d-none"><a href="{{ URL::to('delete_vehicle_category/'.$value->id.'') }}" class="btn btn-secondary btn-sm" onclick="return confirm('Are you sure you want to delete?');">Delete</a></td>
                                            </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>


@endsection
@section('scripts')
    
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY&sensor=false&libraries=places"></script>

@stop