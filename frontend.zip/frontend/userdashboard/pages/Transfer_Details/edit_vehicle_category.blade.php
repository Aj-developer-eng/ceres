@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php $currency=Session::get('currency_symbol'); ?>

<div class="dashboard-content">
    
    <h3 style="color:#a30000">Add Vehcile Category</h3>
    <form action="{{URL::to('update_vehicle_category')}}/{{$vehicle_Category[0]->id}}" method="post" enctype="multipart/form-data" style="padding-bottom: 40px">
        @csrf
        <div class="row">
            <div class="col-md-12 mb-4">
                @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" style="background-color:#d4edda;" role="alert">
                    {{ session('success') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif

                @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show" style="background-color:#f5cfcf;" role="alert">
                    {{ session('error') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif
            </div>
            
            <div class="col-md-12">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                        <div class="row">
                           <?php //dd($vehicle_Category); ?>
                            <div class="col-md-4" style="padding: 15px;">
                                <label for="">Vehicle Category</label>
                                <input type="text" id="vehicle_category" name="vehicle_category" class="form-control" required value="{{ $vehicle_Category[0]->vehicle_category ?? '' }}">
                            </div>
                            
                            <div class="col-md-4" style="padding: 15px;">
                                <label for="">Max Passengers</label>
                                <input type="number" id="max_passeneger" name="max_passeneger" class="form-control" required value="{{ $vehicle_Category[0]->max_passeneger ?? '' }}">
                            </div>
                            
                            <div class="col-md-4" style="padding: 15px;">
                                <label for="">Max Passengers</label>
                                <input type="number" id="max_bagage" name="max_bagage" class="form-control" required value="{{ $vehicle_Category[0]->max_bagage ?? '' }}">
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 text-right mt-3">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
    
</div>


@endsection
@section('scripts')
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY&sensor=false&libraries=places"></script>

@stop