@extends('template/frontend/userdashboard/layout/default')
 @section('content')
 
 <div class="row mt-3">
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="header-title mb-3">Create Umrah Package</h4>

                                        <form action="{{URL::to('super_admin/submit_umrah_packages')}}" method="post" enctype="multipart/form-data">
                                            @csrf
                                            <div id="progressbarwizard">

                                                <ul class="nav nav-pills nav-justified form-wizard-header mb-3">
                                                <li class="nav-item" style="font-size: 13px;">
                                                        <a href="#package_details1" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2 active">
                                                            <!-- <i class="mdi mdi-account-circle me-1"></i> -->
                                                            <span class="d-none d-sm-inline">Package Details</span>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item" style="font-size: 13px;">
                                                        <a href="#basictab1" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                                            <!-- <i class="mdi mdi-account-circle me-1"></i> -->
                                                            <span class="d-none d-sm-inline">Makkah Stay</span>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item" style="font-size: 13px;">
                                                        <a href="#profile-tab-2" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                                            <i class="mdi mdi-face-profile me-1"></i>
                                                            <span class="d-none d-sm-inline">Madina Stay</span>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item" style="font-size: 13px;">
                                                        <a href="#transfer-tab-3" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                                            <i class="mdi mdi-face-profile me-1"></i>
                                                            <span class="d-none d-sm-inline">Transfer</span>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item" style="font-size: 13px;">
                                                        <a href="#Flights-tab-4" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                                            <i class="mdi mdi-face-profile me-1"></i>
                                                            <span class="d-none d-sm-inline">Flights</span>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item" style="font-size: 13px;">
                                                        <a href="#visa-tab-5" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                                            <i class="mdi mdi-face-profile me-1"></i>
                                                            <span class="d-none d-sm-inline">Visa</span>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item" style="font-size: 13px;">
                                                        <a href="#administration-tab-6" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                                            <i class="mdi mdi-face-profile me-1"></i>
                                                            <span class="d-none d-sm-inline">Administration</span>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item" style="font-size: 13px;">
                                                        <a href="#submit-tab-7" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                                            <i class="mdi mdi-face-profile me-1"></i>
                                                            <span class="d-none d-sm-inline">Submit</span>
                                                        </a>
                                                    </li>
                                                    <!-- <li class="nav-item">
                                                        <a href="#finish-2" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                                            <i class="mdi mdi-checkbox-marked-circle-outline me-1"></i>
                                                            <span class="d-none d-sm-inline">Finish</span>
                                                        </a>
                                                    </li> -->
                                                </ul>
                                            
                                                <div class="tab-content b-0 mb-0">

                                                    <div id="bar" class="progress mb-3" style="height: 7px;">
                                                        <div class="bar progress-bar progress-bar-striped progress-bar-animated bg-success"></div>
                                                    </div>


                                                    <div class="tab-pane active" id="package_details1">

                                                    
                                                                <div class="card">
                                                                <div class="card-body">
                            
                                                            <div class="row">
                                                            <div class="col-lg-6">
                                                                <!-- Single Date Picker -->
                                                                <div class="mb-3">
                                                                <label class="form-label">Package Name</label>
                                                                <input type="text" class="form-control" required="" name="package_name" >
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="col-lg-6">
                                                                <!-- Single Date Picker -->
                                                                <div class="mb-3">
                                                                <label class="form-label">No Of Pax</label>
                                                                <input type="text" class="form-control" required="" name="no_of_pax_days" >
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="col-lg-12">
                                                                <!-- Single Date Picker -->
                                                                <div class="mb-3">
                                                                <label class="form-label">Content</label>
                                                                 <textarea name="content" id="snow-editor" cols="142" rows="10"></textarea>
                                                                </div>
                                                            </div>
        
                                                    
                                               
                                                            
        
                                                    
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <!-- Single Date Picker -->
                                                        <div class="mb-3">
                                                            <label class="form-label">Departure Date</label>
                                                            <input type="text" class="form-control date" required="" name="check_in" id="birthdatepicker" data-toggle="date-picker" data-single-date-picker="true">
                                                        </div>
                                                    </div>
                                                            <div class="col-lg-4">
                                                        <!-- Single Date Picker -->
                                                        <div class="mb-3">
                                                            <label class="form-label">Arrival Date</label>
                                                            <input type="text" class="form-control date" required=""  name="check_out" id="birthdatepicker" data-toggle="date-picker" data-single-date-picker="true">
                                                        </div>
                                                    </div>
        
                                                    
                                              
                                               
                                                            <div class="col-lg-4">
                                                        <!-- Single Date Picker -->
                                                        <div class="mb-3">
                                                            <label class="form-label">Status</label>
                                                            <select required="" class="form-select mb-3" name="status">
                                                            <option selected="">Select Status</option>
                                                            <option value="0">Enable</option>
                                                            <option value="1">Disable</option>
                                                            
                                                        </select>
                                                        </div>
                                                    </div>
        
                                                    
                                                </div>
                                                                
                                        
                                                                
                                                                
                                                            
                            </div>
                        </div>
                   
                                                    </div>


                                            
                                                    <div class="tab-pane" id="basictab1">
                                                        
<div class="mb-2" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;"><div class="row"><div class="col-xl-3"><label for="">Hotel Name</label><input type="text" id="simpleinput" name="acc_hotel_name" class="form-control">
</div><div class="col-xl-3"><label for="">Check In</label><input type="date" id="makkah_check_in" name="acc_check_in" class="form-control">
</div><div class="col-xl-3"><label for="">Check Out</label><input type="date" id="makkah_check_out" name="acc_check_out" class="form-control"></div>
<div class="col-xl-3"><label for="">No Of Nights</label><input type="text" id="makkah_no_of_nights" name="acc_no_of_nightst" class="form-control"></div>
<div class="col-xl-3">
    <label for="">Accomodation Type</label>
<select name="acc_type[]" id="" class="form-control">
    <option value="">Choose ...</option>
    <option value="Quad">Quad</option>
    <option value="Triple">Triple</option>
    <option value="Double">Double</option>
    </select>
    </div>
<div class="col-xl-3"><label for="">Quantity</label><input type="text" id="simpleinput" name="acc_qty[]" class="form-control"></div>
<div class="col-xl-3"><label for="">Pax</label><input type="text" id="simpleinput" name="acc_pax[]" class="form-control"></div><div class="col-xl-3"><label for="">Price</label>
<input type="text" id="simpleinput" name="acc_price[]" class="form-control"></div><div class="col-xl-3"><label for="">Currency</label><select name="acc_currency[]"  class="form-control"><option value="">Choose ...</option><option value="SAR">SAR</option><option value="Dollar">Dollar</option><option value="Pound">Pound</option></select></div><div class="col-xl-3"><label for="">Comission</label><input type="text" id="simpleinput" name="acc_commision[]" class="form-control"></div><div class="col-xl-3"><label for="">Sale Price</label><input type="text" id="simpleinput" name="acc_sale_Porice[]" class="form-control"></div><div class="col-xl-3"><label for="">Total Amount</label><input type="text" id="simpleinput" name="acc_total_amount[]" class="form-control"></div>
<div id="append_add_makkah"></div><div class="mt-2"><a href="javascript:;" onclick="add_more_makkah()"  id="" class="btn btn-info" style="float: right;"> + Add More </a></div></div></div>
                                                        
                                                        
                                                     

                                                       




                                        


                                                        <div class="row">
                                                            
                                                            <div class="col-lg-6">
                                                            <!-- Single Date Picker -->
                                                            <div class="mb-3">
                                                            <label class="form-label">Board Basis</label>
                                                            <select required="" class="form-select mb-3" name="makkah_board_basis">
                                                            <option selected="">Select Board Basis</option>
                                                            <option value="Full Board">Full Board</option>
                                                            <option value="Half Board">Half Board</option>
                                                            
                                                            </select>
                                                            </div>
                                                            </div>
                                                            
        
                                                    
                                                        
                                                        <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label class="form-label">Images</label>
                                                        <input name="makkah_images" class="form-control" type="file" multiple />
                                                            </div>
                                                            </div>
                                                            </div>













                                                    </div>

                                                    <div class="tab-pane" id="profile-tab-2">
                                                        
                                                        
  <div class="mb-2" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;"><div class="row"><div class="col-xl-3"><label for="">Hotel Name</label><input type="text" id="simpleinput" name="madina_hotel_name" class="form-control">
</div><div class="col-xl-3"><label for="">Check In</label><input type="date" id="madina_check_in" name="madina_check_in" class="form-control">
</div><div class="col-xl-3"><label for="">Check Out</label><input type="date" id="makkah_check_out" name="makkah_check_out" class="form-control"></div>
<div class="col-xl-3"><label for="">No Of Nights</label>
<input type="text" id="madina_no_of_nights" name="madina_no_of_nights" class="form-control"></div>
<div class="col-xl-3">
    <label for="">Accomodation Type</label>
<select name="madina_type[]" id="" class="form-control">
    <option value="">Choose ...</option>
    <option value="Quad">Quad</option>
    <option value="Triple">Triple</option>
    <option value="Double">Double</option>
    </select>
    </div>
<div class="col-xl-3"><label for="">Quantity</label><input type="text" id="simpleinput" name="madina_qty[]" class="form-control"></div>
<div class="col-xl-3"><label for="">Pax</label><input type="text" id="simpleinput" name="madina_pax[]" class="form-control"></div><div class="col-xl-3"><label for="">Price</label>
<input type="text" id="simpleinput" name="madina_price[]" class="form-control"></div><div class="col-xl-3"><label for="">Currency</label><select name="madina_currency[]"  class="form-control"><option value="">Choose ...</option><option value="SAR">SAR</option><option value="Dollar">Dollar</option><option value="Pound">Pound</option></select></div><div class="col-xl-3"><label for="">Comission</label><input type="text" id="simpleinput" name="madina_commision[]" class="form-control"></div><div class="col-xl-3"><label for="">Sale Price</label><input type="text" id="simpleinput" name="madina_sale_Porice[]" class="form-control"></div><div class="col-xl-3"><label for="">Total Amount</label><input type="text" id="simpleinput" name="madina_total_amount[]" class="form-control"></div>
<div id="append_add_madina"></div><div class="mt-2"><a href="javascript:;" onclick="add_more_madina()"  id="" class="btn btn-info" style="float: right;"> + Add More </a></div></div></div>
                                                    
                                                        

                                                        
                                                        




                                                        




                                                      




                                                       






                                                        <div class="row">
                                                            
                                                            <div class="col-lg-6">
                                                            <!-- Single Date Picker -->
                                                            <div class="mb-3">
                                                            <label class="form-label">Board Basis</label>
                                                            <select class="form-select mb-3" name="madina_board_basis">
                                                            <option selected="">Select Board Basis</option>
                                                            <option value="0">Full Board</option>
                                                            <option value="1">Half Board</option>
                                                            
                                                            </select>
                                                            </div>
                                                            </div>
                                                            
        
                                                    
                                                        
                                                        <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label class="form-label">Images</label>
                                                        <input name="madina_images" class="form-control" type="file" multiple />
                                                            </div>
                                                            </div>
                                                            </div>
                                                    </div>



                                                    
                                                    <div class="tab-pane" id="transfer-tab-3">
                                                        
<div class="row" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;" id="select_transportation">
<div class="col-xl-3"><label for="">Vehicle Type</label>
<select name="transportation_vehicle_type"  class="form-control"  data-placeholder="Choose ...">
<option value="">Choose ...</option><option value="Bus">Bus</option><option value="Coach">Coach</option><option value="Vein">Vein</option>
<option value="Coach">Coach</option><option value="Car">Car</option>
</select>
</div>
<div class="col-xl-2"><label for="">No Of Vehicle</label><input type="text" id="simpleinput" name="transportation_no_of_vehicle" class="form-control"></div>
<div class="col-xl-3"><label for="">Root Type</label><select name="transportation_root_type"  class="form-control"  data-placeholder="Choose ...">
<option value="">Choose ...</option><option value="One-Way">One-Way</option><option value="Return">Return</option><option value="All Round">All Round</option></select>
</div>
<div class="col-xl-2"><label for="">Total AvailAble Seat</label><input type="number" id="simpleinput" name="transportation_total_availAble_seat" class="form-control"></div>
<div class="col-xl-2"><label for="">Price Per Person</label><input type="text" id="simpleinput" name="transportation_price_per_person" class="form-control"></div>

<div class="col-xl-12"><label for="">Image</label><input type="file" id="simpleinput" name="transfer_images" class="form-control"></div>



                                                    <div class="row mt-3">
                                                    <div class="col-lg-6">
                                                       <div class="mb-3">
                                                
                                                      <div class="form-check form-check-inline">
                                                        <input type="checkbox" class="form-check-input" id="Makkah_Mazarat_Included" name="">
                                                       <label class="form-check-label" for="Makkah_Mazarat_Included">Makkah Mazarat Included</label>
                                                       </div>
                                                
                                                      </div>
                                                      </div>
                                                      

                                                    
                                                        
                                                            <div class="col-lg-6" id="select_Makkah_Mazarat_Included" style="display:none;" >
                                                            <!-- Single Date Picker -->
                                                            <div class="">
                                                            <label class="form-label">Makkah Mazarat Included</label>
                                                           <input type="text" class="form-control" name="Makkah_Mazarat_Included">
                                                            </div>
                                                            </div>
                                                    
                                                        </div>
                                                        
                                                        <div class="row">
                                                    <div class="col-lg-6">
                                                       <div class="mb-3">
                                                
                                                      <div class="form-check form-check-inline">
                                                        <input type="checkbox" class="form-check-input" id="Makkah_and_Madina_Mazarat_Included" name="">
                                                       <label class="form-check-label" for="Makkah_and_Madina_Mazarat_Included">Makkah and Madina Mazarat Included</label>
                                                       </div>
                                                
                                                      </div>
                                                      </div>
                                                      

                                                    
                                                        
                                                            <div class="col-lg-6" id="select_Makkah_and_Madina_Mazarat_Included" style="display:none;" >
                                                            <!-- Single Date Picker -->
                                                            <div class="">
                                                            <label class="form-label">Makkah and Madina Mazarat Included</label>
                                                           <input type="text" class="form-control" name="Makkah_and_Madina_Mazarat_Included">
                                                            </div>
                                                            </div>
                                                    
                                                        </div>
                                                        <div class="row">
                                                    <div class="col-lg-6">
                                                       <div class="mb-3">
                                                
                                                      <div class="form-check form-check-inline">
                                                        <input type="checkbox" class="form-check-input" id="Madina_Mazarat_Included" name="">
                                                       <label class="form-check-label" for="Madina_Mazarat_Included">Madina Mazarat Included</label>
                                                       </div>
                                                
                                                      </div>
                                                      </div>
                                                      

                                                    
                                                        
                                                            <div class="col-lg-6" id="select_Madina_Mazarat_Included" style="display:none;" >
                                                            <!-- Single Date Picker -->
                                                            <div class="">
                                                            <label class="form-label">Madina Mazarat Included</label>
                                                           <input type="text" class="form-control" name="Madina_Mazarat_Included">
                                                            </div>
                                                            </div>
                                                    
                                                        </div>



















<div id="append_transportation_umrah">
</div>

<div class="mt-2">
<a href="javascript:;" id="more_transportation_umrah" class="btn btn-info" style="float: right;"> + Add More </a>
</div>

</div>  

                                                    </div>


                                                    <div class="tab-pane" id="Flights-tab-4">
                                                    <div class="row">
                                                            <div class="col-lg-6">
                                                            <!-- Single Date Picker -->
                                                            <div class="mb-3">
                                                            <label class="form-label">Airline</label>
                                                            <select class="form-select mb-3" name="flights_airline">
                                                            <option selected="">Select Airline</option>
                                                            <option value="0">Airline</option>
                                                            <option value="1">Airline2</option>
                                                            
                                                            </select>
                                                            </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                            <!-- Single Date Picker -->
                                                            <div class="mb-3">
                                                            <label class="form-label">Departure Airport</label>
                                                            <select class="form-select mb-3" name="flights_departure_airport">
                                                            <option selected="">Select Departure Airport</option>
                                                            <option value="0">Departure Airport1</option>
                                                            <option value="1">LocatiDeparture Airport2on2</option>
                                                            
                                                            </select>
                                                            </div>
                                                            </div>
                                                            
        
                                                    
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                            <!-- Single Date Picker -->
                                                            <div class="mb-3">
                                                            <label class="form-label">Arrival Airport</label>
                                                            <select class="form-select mb-3" name="flights_arrival_airport">
                                                            <option selected="">Select Arrival Airport</option>
                                                            <option value="0">Arrival Airport1</option>
                                                            <option value="1">Arrival Airport2</option>
                                                            
                                                            </select>
                                                            </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                            <!-- Single Date Picker -->
                                                            <div class="mb-3">
                                                            <label class="form-label">Departure Return Airport</label>
                                                            <select class="form-select mb-3" name="flights_departure__return_airport">
                                                            <option selected="">Select Departure Return Airport</option>
                                                            <option value="0">Departure Return Airport1</option>
                                                            <option value="1">Departure Return Airport</option>
                                                            
                                                            </select>
                                                            </div>
                                                            </div>
                                                            
        
                                                    
                                                        </div>
                                                        <div class="row">
                                                        <div class="col-lg-4">
                                                            <!-- Single Date Picker -->
                                                            <div class="mb-3">
                                                            <label class="form-label">Arrival Return Airport</label>
                                                            <select class="form-select mb-3" name="flights_arrival_return_airport">
                                                            <option selected="">Select Arrival Return Airport</option>
                                                            <option value="0">Arrival Return Airport1</option>
                                                            <option value="1">Arrival Return Airport</option>
                                                            
                                                            </select>
                                                            </div>
                                                            </div>
                                                            <div class="col-lg-4">
                                                            <!-- Single Date Picker -->
                                                            <div class="mb-3">
                                                            <label class="form-label">Departure Return Date</label>
                                                            <input type="text"  class="form-control date"  name="flights_departure__return_date" id="birthdatepicker" data-toggle="date-picker" data-single-date-picker="true">
                                                            </div>
                                                            </div>
                                                            <div class="col-lg-4">
                                                            <!-- Single Date Picker -->
                                                            <div class="mb-3">
                                                            <label class="form-label">Arrival Return Date</label>
                                                            <input type="text"  class="form-control date"  name="flights_arrival_return_date" id="birthdatepicker" data-toggle="date-picker" data-single-date-picker="true">

                                                            </div>
                                                            </div>
                                                            
                                                            
        
                                                    
                                                        </div>

                                                    </div>

                                                  
                                                    <div class="tab-pane" id="visa-tab-5">
                                                        
                                                        <div class="col-xl-12">
                                                       <div class="mb-3">
                                                
                                                      <div class="form-check form-check-inline">
                                                        <input type="checkbox" class="form-check-input" id="visa_fee" name="">
                                                       <label class="form-check-label" for="visa_fee">Umrah Visa</label>
                                                       </div>
                                                
                                                      </div>
                                                      </div>
                                                      
                                                      <div class="row" id="select_visa_fee" style="display:none">
                                                        <div class="col-lg-6">
                                                            <!-- Single Date Picker -->
                                                            <div class="mb-3">
                                                            <label class="form-label">Umrah Visa fee</label>
                                                           <input type="text" class="form-control" name="visa_fee">
                                                            </div>
                                                            </div>
                                                            
                                                    
                                                        </div>
                                                        
                                                        <div class="col-xl-12">
                                                       <div class="mb-3">
                                                
                                                      <div class="form-check form-check-inline">
                                                        <input type="checkbox" class="form-check-input" id="visit_visa_fee" name="">
                                                       <label class="form-check-label" for="visit_visa_fee">Visit Visa</label>
                                                       </div>
                                                
                                                      </div>
                                                      </div>
                                                      

                                                    <div class="row" id="select_visit_visa_fee" style="display:none">
                                                        
                                                            <div class="col-lg-6">
                                                            <!-- Single Date Picker -->
                                                            <div class="mb-3">
                                                            <label class="form-label">Visit Visa fee</label>
                                                           <input type="text" class="form-control" name="visit_visa_fee">
                                                            </div>
                                                            </div>
                                                    
                                                        </div>
                                                       

                                                    </div>
                                                    <div class="tab-pane" id="administration-tab-6">
                                                    <div class="row">
                                                        <div class="col-lg-12">
                                                            <!-- Single Date Picker -->
                                                            <div class="mb-3">
                                                            <label class="form-label">Amount</label>
                                                           <input type="text" class="form-control" name="administration_charges">
                                                            </div>
                                                            </div>
                                                    
                                                        </div>
                                                       
                                                    </div>

                                                    <div class="tab-pane" id="submit-tab-7">
                                                    <div class="row">
                                                            <div class="col-12">
                                                                <div class="text-center">
                                                                    <h2 class="mt-0"></h2>
                                                                    <h3 class="mt-0"></h3>

                                                                    <p class="w-75 mb-2 mx-auto"></p>
 <button type="submit" name="submit" class="btn btn-info">Submit</button>
                                                                    
                                                                </div>
                                                            </div> <!-- end col -->
                                                        </div>
                                                    </div>

                                                   

                                                    <ul class="list-inline mb-0 wizard">
                                                        <li class="previous list-inline-item">
                                                            <a href="javascript:void(0);" class="btn btn-info">Previous</a>
                                                        </li>
                                                        <li class="next list-inline-item float-end">
                                                       
                                                            <a href="javascript:void(0);" class="btn btn-info">Next</a>
                                                        </li>
                                                    </ul>

                                                </div> <!-- tab-content -->
                                            </div> <!-- end #progressbarwizard-->
                                        </form>

                                    </div> <!-- end card-body -->
                                </div> <!-- end card-->
                            </div> <!-- end col -->

                        </div>   
                        
                        

                       
 @endsection
 
 
 @section('scripts')
 <script>
var divId = 1;
function add_more_makkah(divId)
{
   var data1 = `<div id="click_delete_${divId}" class="mb-2 mt-3" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;"><div class="row"><div class="col-xl-3"><label for="">Accomodation Type</label>
<select name="acc_type[]"  class="form-control"  data-placeholder="Choose ..."><option value="">Choose ...</option><option value="Quad">Quad</option><option value="Triple">Triple</option><option value="Double">Double</option></select></div>
<div class="col-xl-3"><label for="">Quantity</label><input type="text" id="simpleinput" name="acc_qty[]" class="form-control"></div>
<div class="col-xl-3"><label for="">Pax</label><input type="text" id="simpleinput" name="acc_pax[]" class="form-control"></div><div class="col-xl-3"><label for="">Price</label>
<input type="text" id="simpleinput" name="acc_price[]" class="form-control"></div><div class="col-xl-3"><label for="">Currency</label><select name="acc_currency[]"  class="form-control"><option value="">Choose ...</option><option value="SAR">SAR</option><option value="Dollar">Dollar</option><option value="Pound">Pound</option></select></div><div class="col-xl-3"><label for="">Comission</label><input type="text" id="simpleinput" name="acc_commision[]" class="form-control"></div><div class="col-xl-3"><label for="">Sale Price</label><input type="text" id="simpleinput" name="acc_sale_Porice[]" class="form-control"></div><div class="col-xl-3"><label for="">Total Amount</label><input type="text" id="simpleinput" name="acc_total_amount[]" class="form-control"></div>
<div class="mt-2"><a href="javascript:;"  onclick="deleteRowmakkah(${divId})"  id="${divId}" class="btn btn-info" style="float: right;">Delete </a></div></div></div>`;
  $("#append_add_makkah").append(data1);
   divId++;
}

</script>
<script>
 function deleteRowmakkah(id){
  
     $('#click_delete_'+id+'').remove();
     

 }

</script>
<script>
var divId = 1;
function add_more_madina(divId)
{
   var data1 = `<div id="click_delete_${divId}" class="mb-2 mt-3" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;"><div class="row"><div class="col-xl-3"><label for="">Accomodation Type</label>
<select name="madina_type[]"  class="form-control"  data-placeholder="Choose ..."><option value="">Choose ...</option><option value="Quad">Quad</option><option value="Triple">Triple</option><option value="Double">Double</option></select></div>
<div class="col-xl-3"><label for="">Quantity</label><input type="text" id="simpleinput" name="madina_qty[]" class="form-control"></div>
<div class="col-xl-3"><label for="">Pax</label><input type="text" id="simpleinput" name="madina_pax[]" class="form-control"></div><div class="col-xl-3"><label for="">Price</label>
<input type="text" id="simpleinput" name="madina_price[]" class="form-control"></div><div class="col-xl-3"><label for="">Currency</label><select name="madina_currency[]"  class="form-control"><option value="">Choose ...</option><option value="SAR">SAR</option><option value="Dollar">Dollar</option><option value="Pound">Pound</option></select></div><div class="col-xl-3"><label for="">Comission</label><input type="text" id="simpleinput" name="madina_commision[]" class="form-control"></div><div class="col-xl-3"><label for="">Sale Price</label><input type="text" id="simpleinput" name="madina_sale_Porice[]" class="form-control"></div><div class="col-xl-3"><label for="">Total Amount</label><input type="text" id="simpleinput" name="madina_total_amount[]" class="form-control"></div>
<div class="mt-2"><a href="javascript:;"  onclick="deleteRowmadina(${divId})"  id="${divId}" class="btn btn-info" style="float: right;">Delete </a></div></div></div>`;
  $("#append_add_madina").append(data1);
   divId++;
}

</script>
<script>
 function deleteRowmadina(id){
  
     $('#click_delete_'+id+'').remove();
     

 }

</script>

<script>
    var divId = 1
    $("#more_transportation_umrah").click(function(){
        var data = `<div class="row" id="click_delete_${divId}">
<div class="col-xl-3"><label for="">Vehicle Type</label><select name="more_transportation_vehicle_type[]"  class="form-control"  data-placeholder="Choose ...">
<option value="">Choose ...</option><option value="Bus">Bus</option><option value="Coach">Coach</option><option value="Vein">Vein</option><option value="Coach">Coach</option><option value="Car">Car</option></select>
</div>
<div class="col-xl-2"><label for="">No Of Vehicle</label><input type="text" id="simpleinput" name="more_transportation_no_of_vehicle[]" class="form-control"></div>
<div class="col-xl-3"><label for="">Root Type</label><select name="transportation_root_typemore_[]"  class="form-control"  data-placeholder="Choose ...">
<option value="">Choose ...</option><option value="One-Way">One-Way</option><option value="Return">Return</option><option value="All Round">All Round</option></select>
</div>
<div class="col-xl-2"><label for="">Total AvailAble Seat</label><input type="number" id="simpleinput" name="more_transportation_total_availAble_seat[]" class="form-control"></div>
<div class="col-xl-2"><label for="">Price Per Person</label><input type="text" id="simpleinput" name="more_transportation_price_per_person[]" class="form-control"></div>
<div class="mt-2">
<button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRowumrah(${divId})"  id="${divId}">Delete</button>
</div></div>`;
  $("#append_transportation_umrah").append(data);
  
  
  
  
  
  
  
  
  divId++;
});

</script>

<script>
 function deleteRowumrah(id){
  
     $('#click_delete_'+id+'').remove();
     

 }

</script>
<script>
 $("#visa_fee").on('click',function(){

$("#select_visa_fee").slideToggle();


});
    $("#visit_visa_fee").on('click',function(){

$("#select_visit_visa_fee").slideToggle();


});

 $("#Makkah_Mazarat_Included").on('click',function(){

$("#select_Makkah_Mazarat_Included").slideToggle();


});
 $("#Madina_Mazarat_Included").on('click',function(){

$("#select_Madina_Mazarat_Included").slideToggle();


});
 $("#Makkah_and_Madina_Mazarat_Included").on('click',function(){

$("#select_Makkah_and_Madina_Mazarat_Included").slideToggle();


});

</script>
 @stop