
<?php

//print_r($user_rooms);die();

?>


@extends('template/frontend/userdashboard/layout/default')
@section('content')


<div class="dashboard-content">
    <h4>Rooms List</h4>
 
    <div class="row">
<div class="col-lg-12 col-sm-12">
<div class="dashboard-list-box dash-list margin-top-0">
    <div class="row">
        <div class="col-md-12">
             <table id="myTable" class="display nowrap table  table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>Sr</th>
                        <th>Image</th>
                        <th>Hotel</th>
                        <th>Type</th>
                        <th>Availabile (From)</th>
                        <th>Availabile (To)</th>
                        <th>Quantity</th>
                        <th>Room weekdays Price</th>
                        <th>Room weekends Price</th>
                        <th>Room Price all days</th>
                        <th>Status</th>
                        <th>Options</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $x = 1;
                    @endphp
                    @foreach($user_rooms as $room_res)
                    <?php
                if($room_res->more_room_type_details != null)
                {
                   $more_room_type_details=$room_res->more_room_type_details;
                    $more_room_type_details=json_decode($more_room_type_details);
                   // print_r($more_room_type_details);die();
                }
                
                 
                    ?>
                    @if(isset($more_room_type_details))
                    @foreach($more_room_type_details as $more_room_res)
                    @endforeach
                    @endif
                    <tr>
                        <td>{{ $x++ }}</td>
                        <td><img src="{{ asset('public/images/rooms/roomGallery') }}/{{ $room_res->room_img }}" alt="" style="height: 50px;width: 50px;"></td>
                        <td>{{ $room_res->property_name }}</td>
                        <td>{{ $room_res->room_type }}</br>{{ $more_room_res->more_room_type ?? ''}}</br></td>
                        <td>{{ $room_res->availible_from }}</br>{{ $more_room_res->more_room_av_from ?? '' }}</br></td>
                        <td>{{ $room_res->availible_to }}</br>{{ $more_room_res->more_room_av_to ?? ''}}</br></td>
                        <td>{{ $room_res->quantity }}</br>{{ $more_room_res->more_quantity ?? ''}}</br></td>
                        
                        <td>{{ $room_res->weekdays_price ?? '' }}</br>{{ $more_room_res->more_week_days_price ?? ''}}</br></td>
                        <td>{{ $room_res->weekends_price ?? '' }}</br>{{ $more_room_res->more_week_end_price ?? ''}}</br></td>
                        <td>{{ $room_res->price_all_days ?? '' }}</br>{{ $more_room_res->more_price_all_days ?? ''}}</br></td>
                        <td>{{ $room_res->status }}</td>
                        
                        <td>
                            <a href="{{ URL::to('hotel_manger/view_room/'.$room_res->id.'') }}" target="_blank" class="btn btn-secondary btn-sm">Edit</a>
                            <!--<a href="{{ URL::to('hotel_manger/view_room/'.$room_res->id.'') }}" class="btn btn-secondary btn-sm">Edit</a>-->
                        </td>
                    </tr>
                    
                    @endforeach
                
            </table>
        </div>
 
    </div>

</div>
</div>
</div>
</div>
@endsection

@section('scripts')
<script>
    $(document).ready( function () {
        $('#myTable').DataTable({
            "scrollX": true,
        });
    } );
</script>

@stop
