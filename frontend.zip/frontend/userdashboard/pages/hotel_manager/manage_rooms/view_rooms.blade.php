<?php
if($data->hotels[0]->currency_symbol == '﷼')
                                                                        {
                                                                            $currency='SAR';
                                                                        }
                                                                        else
                                                                        {
                                                                            $currency=$data->hotels[0]->currency_symbol ?? '';
                                                                        }
// print_r($data);die();
?>


@extends('template/frontend/userdashboard/layout/default')
 @section('content')
 
 

 
 

    <div class="mt-5" id="">
        <div class="row">
            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="header-title"><?php print_r($data->hotels[0]->property_name ?? ''); ?> :Rooms Details</h4>
                                        <p class="text-muted font-14">
                                            
                                        </p>

                                        
                                       
                                                <table id="example_1" class="table dt-responsive nowrap w-100">
                                                    <thead class="theme-bg-clr">
                                                        <tr>
                                                            <th>id</th>
                                                            <th>Room Name</th>
                                                            <th>Room Available</th>
                                                            <th>Room Booked</th>
                                                            
                                                            <th>Availability</th>
                                                            
                                                            <th>Price Per Room</th>
                                                            <th>Eidt</th>
                                                            <th>Delete</th>
                                                            
                                                        </tr>
                                                    </thead>
                                                
                                                
                                                    <tbody>
                                                        <?php
                                                        if(isset($data->rooms))
                                                        {
                                                            $count=1;
                                                         foreach($data->rooms as $rooms)
                                                         {
                                                             if($rooms->quantity == $rooms->booked)
                                                             {
                                                                 
                                                            
                                                             ?>
                                                             
                                                            
                                                        <tr style="background: #ffe6e9;">
                                                            <td>{{$count ?? ''}}</td>
                                                            <td><b>{{$rooms->room_type_name ?? ''}}</b><br>
                                                             <b>{{$rooms->room_meal_type ?? ''}}</b>
                                                             
                                                             </td>
                                                             <td>{{$rooms->quantity ?? ''}}</td>
                                                             <td>{{$rooms->booked ?? ''}}</td>
                                                              
                                                               <td>{{$rooms->availible_from ?? ''}} <br>
                                                               {{$rooms->availible_to ?? ''}}
                                                               </td>
                                                               
                                                                <td>
                                                                    <?php
                                                                    if($rooms->price_week_type == 'for_all_days')
                                                                    {
                                                                        
                                                                        print_r('All Days Price=' . $currency . ' ' . $rooms->price_all_days);
                                                                    }
                                                                    else
                                                                    {
                                                                      print_r('Week Days Price='. $currency . ' ' . $rooms->weekdays_price);
                                                                      echo '</br>';
                                                                      print_r('Weekend Days Price='. $currency . ' ' . $rooms->weekends_price);
                                                                    }
                                                                    ?>
                                                                    
                                                                </td>
                                                                 <td><a href="{{URL::to('super_admin/edit_rooms')}}/{{$rooms->id}}" target="_blank" class="btn btn-info">Edit</a></td>
                                                                  <td><a href="{{URL::to('super_admin/delete_rooms')}}/{{$rooms->id}}" class="btn btn-info">Delete</a></td>
                                                            </tr>
                                                            
                                                             <?php
                                                             }
                                                             else
                                                             {
                                                                 ?>
                                                                 <tr>
                                                            <td>{{$count ?? ''}}</td>
                                                             <td><b>{{$rooms->room_type_name ?? ''}}</b><br>
                                                             <b>{{$rooms->room_meal_type ?? ''}}</b>
                                                             
                                                             </td>
                                                             <td>{{$rooms->quantity ?? ''}}</td>
                                                             <td>{{$rooms->booked ?? ''}}</td>
                                                              
                                                               <td>{{$rooms->availible_from ?? ''}} <br>
                                                               {{$rooms->availible_to ?? ''}}
                                                               </td>
                                                               
                                                                <td>
                                                                    <?php
                                                                    if($rooms->price_week_type == 'for_all_days')
                                                                    {
                                                                        
                                                                        print_r('All Days Price=' . $currency . ' ' . $rooms->price_all_days);
                                                                    }
                                                                    else
                                                                    {
                                                                      print_r('Week Days Price='. $currency . ' ' . $rooms->weekdays_price);
                                                                      echo '</br>';
                                                                      print_r('Weekend Days Price='. $currency . ' ' . $rooms->weekends_price);
                                                                    }
                                                                    ?>
                                                                    
                                                                </td>
                                                                 <td><a href="{{URL::to('super_admin/edit_rooms')}}/{{$rooms->id}}" target="_blank" class="btn btn-info">Edit</a></td>
                                                                  <td><a href="{{URL::to('super_admin/delete_rooms')}}/{{$rooms->id}}" class="btn btn-info">Delete</a></td>
                                                            </tr>
                                                                 
                                                                 <?php
                                                                 
                                                             }
                                                             $count=$count+1;
                                                         }
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>                                           
                                            
                                        
                                    </div> <!-- end card body-->
                                </div> <!-- end card -->
                            </div><!-- end col-->
        </div>
    </div>
   
   
   
     
                            

                        
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
          <script>
   $(document).ready(function () {
    
    $('#example_1').DataTable({
        scrollX: true,
        scrollY: true,
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        
    });
    
}); 
</script>  
                       
 @endsection