
<?php

//print_r($data);die();

?>

@extends('template/frontend/userdashboard/layout/default')
@section('content')

    <?php $currency=Session::get('currency_symbol'); ?>
    
    <style>
        .nav-link{
          color: #575757;
          font-size: 18px;
        }
    </style>

    <div class="content-wrapper">
        
        
        
        <section class="content" style="padding: 30px 50px 0px 50px;">
          <div class="container-fluid">
            <div class="row">
              <div class="col-lg-12 col-6">
                <nav class="breadcrumb push">
                    <a class="breadcrumb-item" href="#">Dashboard</a> 
                    <span class="breadcrumb-item active">View Agent Invoices</span>
                </nav>
              </div>
            </div>
          </div>
        </section>
        
        <section class="content" style="padding: 10px 20px 0px 20px">
          <div class="container-fluid">
     
          </div>
        </section>
    
        <section class="content" style="padding: 30px 50px 0px 50px;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-6">
                        <h4>Supplier Stats Details</h4>
                        <div class="panel-body padding-bottom-none">
                            <div class="block-content block-content-full">
                                <div id="example_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                             <table style="" class="table nowrap example1 dataTable no-footer myTable" role="grid" aria-describedby="example_info">
                                                
                                                   
                                                  <thead>
                                                        <tr role="row">
                                                            <th>Sr</th>
                                                            <th>Hotel Name</th>
                                                            <th>Hotel location</th>
                                                            <th>Room Type</th>
                                                            <th>Room Id</th>
                                                            <th>Booking From</th>
                                                            <th>Booked</th>
                                                            <th>Cost</th>
                                                            <th>Cost</th>
                                                            <th>From</th>
                                                            <th>To</th>

                                                        </tr>
                                                    </thead>
                                                <tbody>
                                                    @isset($rooms_data)
                                                        @foreach($rooms_data as $room_data_res)
                                                            @foreach($room_data_res->booking_details as $booking_res)
                                                                <tr role="row">
                                                                    <td>{{ $loop->iteration }}</td>
                                                                    <td>{{ $room_data_res->hotel_name }}</td>
                                                                    <td>{{ $room_data_res->hotel_city }}</td>
                                                                    <td>{{ $room_data_res->room_type_name }}</td>
                                                                    <td>{{ $room_data_res->room_id }}</td>
                                                                    <td>{{ $booking_res->booking_form }}</td>
                                                                    <td>{{ $booking_res->quantity }}</td>
                                                                    <td>{{ round($booking_res->cost_SAR, 2) }} {{ $booking_res->purchase_currency ?? '' }}</td>
                                                                    <td>{{ $booking_res->cost_GBP }} {{ $booking_res->sale_currency ?? '' }}</td>
                                                                    <td>{{ $booking_res->check_in }}</td>
                                                                    <td>{{ $booking_res->check_out }}</td>

                                                                </tr>
                                                            @endforeach
                                                        @endforeach
                                                    @endisset
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        
        <!-- Modal -->
   
        
        
    </div>
    
    <div class="modal fade" id="display_rooms" tabindex="-1" aria-labelledby="exampleModalLabel" style="display: none;" aria-hidden="true">
          <div class="modal-dialog modal-xl">
            <div class="modal-content">
              <div class="modal-header " style="display:flex; justify-content: space-between;">
                  <h1 class="modal-title fs-5" id="exampleModalLabel">Rooms Details</h1>
                    <div>
                         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
               
              </div>
              <div class="modal-body">
                 <div id="example_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table style="" class="table nowrap example1 dataTable no-footer myTable" role="grid" aria-describedby="example_info">
                                                
                                                <thead>
                                                    <tr role="row">
                                                        <th>Sr</th>
                                                        <th>Hotel Name</th>
                                                        <th>Hotel location</th>
                                                        <th>Room Type</th>
                                                        <th>Room Id</th>
                                                        <th>Room Generate Id</th>
                                                        <th>Quantity</th>
                                                        <th>Booked</th>
                                                        <th>Single Price</th>
                                                        <th>Total Price</th>
                                                        <th>Cost</th>
                                                        <th>Cost</th>
                                                        <th>From</th>
                                                        <th>To</th>
                                                        <th>View Bookings</th>

                                                    </tr>
                                                </thead>
                                                
                                                <tbody style="text-align: center;" id="trData">
                                                    
                                               </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
              </div>
            </div>
          </div>
        </div>
        
        <div class="modal fade" id="manage_balance" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                 <div> 
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Manage Balance</h1>
                    
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <form action="https://alhijaztours.net/manage_wallent_balance" method="post" enctype="multipart/form-data">
                 @csrf           
                  <div class="modal-body">
                          
                   
                      <div class="row">
                        <div class="col-12 mb-2">
                            <input type="text" name="agent_id" hidden="" value="11">
                            <label>Select Transcation Type</label>
                            <select class="form-control" id="" name="transtype">
                                <option value="Refund">Refund</option>
                                <option value="Deposit">Deposit</option>
                            </select>
                        </div>
                         <div class="col-6 mb-2">
                            <label>Payment Method</label>
                            <select class="form-control" onchange="paymentMethod()" id="payment_method" name="payment_method">
                                <option value="Bank Transfer">Bank Transfer</option>
                                <option value="Cash">Cash</option>
                                <option value="Card Payment">Card Payment</option>
                            </select>
                        </div>
                         <div class="col-6 mb-2">
                             <label>Current Balance</label>
                             <input type="text" class="form-control" readonly id="current_bal" required=""  name="current_bal" placeholder="Enter Payment Amount">
                             <input type="text" class="form-control" readonly id="supplier_id" hidden required=""  name="supplier_id" placeholder="Enter Payment Amount">
                             <input type="text" name="request_person" value="hotel_supplier" hidden>
                        </div>
                        <div class="col-6 mb-2">
                             <label>Payment Date</label>
                             <input type="date" class="form-control" required="" value="2022-12-14" name="payment_date" placeholder="Enter Payment Amount">
                        </div>
                        
                        <div class="col-6 mb-2">
                             <label>Payment Amount</label>
                             <input type="text" class="form-control" required="" name="payment_am" placeholder="Enter Payment Amount">
                        </div>
                        
                      
                        
                        <div class="col-6 mb-2" id="transcation_id" style="display: block;">
                            <label>Transaction ID</label>
                          <input type="text" class="form-control" name="transcation_id" placeholder="Enter Transaction ID">
                          <input type="text" class="form-control" required="" name="invoice_id" hidden="" value="AHT3383261" placeholder="Enter Transaction ID">
                        </div>
                        
                       <div class="col-6 mb-2" id="account_id" style="display: block;">
                           <label>Account No.</label>
                           <input type="text" class="form-control" name="account_no" placeholder="Payment to (Account No.)" value="13785580">
                        </div>
                        
                      </div>
                   
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                  </div>
           </form>
              
            </div>
          </div>
        </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
    <script>
    
  
    
        $(document).ready(function () {
          
            //DataTable
            $('.myTable').DataTable({
                scrollX: true,
            });
            
            //View Modal Single Quotation
          
        });
        
        
        function display_rooms(id){
            $('#display_rooms').modal('show');
            $('#trData').html('');
            
            var roomsData = $('#sup'+id+'').val();
            
            roomsData = JSON.parse(roomsData);
            console.log(roomsData);
            
            var counter = 0;
            var trData = ``;
            roomsData.forEach(function(item){
                if(item['booked'] == null){
                    var booked = 0;
                }else{
                   var booked = item['booked'];
                }
                
                if(item['room_generate_id'] == null){
                    var generateId = '';
                }else{
                    var generateId = item['room_generate_id'];
                }
                
                
                var total_cost_SAR = item['total_cost_purchase'];
                var total_cost_GBP = item['total_cost_convert'];
                trData +=`<tr>
                            <td>${counter++}</td>
                            <td>${item['hotel_name']}</td>
                            <td>${item['hotel_city']}</td>
                            <td>${item['room_type']}</td>
                            <td>${item['room_id']}</td>
                            <td>${generateId}</td>
                            <td>${item['quantity']}</td>
                            <td>${booked}</td>
                            <td>${item['single_room_price']}</td>
                            <td>${item['all_room_price']}</td>
                            <td>${total_cost_SAR.toFixed(2)} ${item['purchase_currency']}</td>
                            <td>${total_cost_GBP.toFixed(2)} ${item['sale_currency']}</td>
                            <td>${item['availible_from']}</td>
                            <td>${item['availible_to']}</td>
                            <td><a href="view_room_bookings/${item['room_id']}/${item['room_type_id']}/${item['room_generate_id']}/${id}" target="blank" class="btn btn-info btn-sm">View Bookings</td>
                        </tr>`;
            })
            
            $('#trData').html(trData)
        }
        
        function manage_balance(sup_id,wallet_balance){
            $('#manage_balance').modal('show');
            $('#current_bal').val(wallet_balance);
            $('#supplier_id').val(sup_id);
            
           console.log('supplier id is '+sup_id+' wallet Balance is '+wallet_balance);
       }

    </script>
    
    <script>
    
        
    </script>

@endsection
