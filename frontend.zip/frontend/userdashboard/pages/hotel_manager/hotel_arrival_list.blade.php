
<?php

//print_r($arrival_detail_week);die();

?>


@extends('template/frontend/userdashboard/layout/default')
@section('content')

<div class="row container mt-5">
  <div class="col-md-12">
                                <div class="card">
                                    <h5 class="card-header">Hotel Arrival List</h5>
                                    <div class="card-body">
                                        <ul class="nav nav-pills bg-nav-pills nav-justified mb-3">
                                        <li class="nav-item">
                                            <a href="#home1" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0 active">
                                                <i class="mdi mdi-home-variant d-md-none d-block"></i>
                                                <span class="d-none d-md-block">This Today Arrival</span>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#profile1" data-bs-toggle="tab" aria-expanded="true" class="nav-link rounded-0">
                                                <i class="mdi mdi-account-circle d-md-none d-block"></i>
                                                <span class="d-none d-md-block">This Week Arrival</span>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#settings1" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                                                <i class="mdi mdi-settings-outline d-md-none d-block"></i>
                                                <span class="d-none d-md-block">This Month Arrival</span>
                                            </a>
                                        </li>
                                    </ul>
                                    </div> <!-- end card-body-->
                                    <div class="tab-content">
    <div class="tab-pane  show active" id="home1">

<table id="example_111" class="table dt-responsive nowrap w-100">
                                                    <thead>
                                                        <tr>
                                                            <th>id</th>
                                                            <th>Invoice No</th>
                                                            <!--<th>Provider</th>-->
                                                            <th>Customer Name</th>
                                                             <th>Hotel Name</th>
                                                            <th>Room Type</th>
                                                            <th>Booking Date</th>
                                                            <th>Check In</th>
                                                            <th>No Of Nights</th>
                                                            <th>status</th>
                                                            
                                                        </tr>
                                                    </thead>
                                                
                                                
                                                    <tbody>
                                                       
                                                        @foreach($arrival_detail_today as $today)
                                                        
                                                        <?php
                                                        $lead_passenger_details=json_decode($today->lead_passenger_details);
                                                       
                                                        
                                                        ?>
                                                        <tr>
                                                            <td>{{$today->id}}</td>
                                                            <td>{{$today->search_id}}</td>
                                                            <!--<td>{{$today->provider}}</td>-->
                                                            <td>{{$lead_passenger_details->lead_first_name ?? ''}} {{$lead_passenger_details->lead_last_name ?? ''}}</td>
                                                            <td></td>
                                                            <td></td>
                                                            <td>{{$today->created_at}}</td>
                                                                
                                                         <td>{{$today->check_in}}</td>
                                                         <td></td>
                                                         <td>{{$today->booking_status}}</td>
        
      
      
                                                            
                                                            
                                                        </tr>
                                                      
                                                       @endforeach
                                                      
                                                    
                                                       
                                                    </tbody>
                                                </table>                                           
                                            

    </div>
    <div class="tab-pane" id="profile1">
      <table id="example_222" class="table dt-responsive nowrap w-100">
                                                    <thead>
                                                        <tr>
                                                           <th>id</th>
                                                            <th>Invoice No</th>
                                                            <th>Provider</th>
                                                            <th>Customer Name</th>
                                                             <th>Hotel Name</th>
                                                            <th>Room Type</th>
                                                            <th>Booking Date</th>
                                                            <th>Check In</th>
                                                            <th>No Of Nights</th>
                                                            <th>status</th>
                                                        </tr>
                                                    </thead>
                                                
                                                
                                                    <tbody>
                                                        
                                                        
                                                       
                                                        @foreach($arrival_detail_week as $week)
                                                        
                                                        <?php
                                                        $lead_passenger_details=json_decode($week->lead_passenger_details);
                                                        
                                                        
                                                        ?>
                                                        <tr>
                                                            <td>{{$week->id}}</td>
                                                            <td>{{$week->search_id}}</td>
                                                            <td>{{$week->provider}}</td>
                                                            <td>{{$lead_passenger_details->lead_first_name ?? ''}} {{$lead_passenger_details->lead_last_name ?? ''}}</td>
                                                            <td>
                                                                
                                                                <?php
                                                                
                                                                if($week->provider == 'hotels')
                                                                {
                                                                    
                                                                    $hotel_checkavailability=$week->hotel_checkavailability;
                                                                    $hotel_checkavailability=json_decode($hotel_checkavailability);
                                                                    print_r($hotel_checkavailability->property_name ?? '');
                                                                    
                                                                }
                                                                else if($week->provider == 'ratehawk')
                                                                {
                                                                   $ratehawk_details_rs=$week->ratehawk_details_rs;
                                                                    $ratehawk_details_rs=json_decode($ratehawk_details_rs);
                                                                    print_r($ratehawk_details_rs->name ?? '');    
                                                                }
                                                                else if($week->provider == 'hotelbeds')
                                                                {
                                                                 
                                                                      $hotelbeddetailRQ=$week->hotelbeddetailRQ;
                                                                    $hotelbeddetailRQ=json_decode($hotelbeddetailRQ);
                                                                    print_r($hotelbeddetailRQ->name ?? '');  
                                                                 
                                                                }
                                                                else if($week->provider == 'tbo')
                                                                {
                                                                  $tbo_BookingDetail_rs=$week->tbo_BookingDetail_rs;
                                                                    $tbo_BookingDetail_rs=json_decode($tbo_BookingDetail_rs);
                                                                    print_r($tbo_BookingDetail_rs->BookingDetail->HotelDetails->HotelName ?? '');   
                                                                }
                                                                 else if($week->provider == 'travellanda')
                                                                {
                                                                  $travellandadetailRS=$week->travellandadetailRS;
                                                                    $travellandadetailRS=json_decode($travellandadetailRS);
                                                                    print_r($travellandadetailRS->HotelName ?? '');   
                                                                }
                                                                
                                                                ?>
                                                                
                                                                
                                                            </td>
                                                            <td>
                                                               <?php
                                                                
                                                                if($week->provider == 'hotels')
                                                                {
                                                                    
                                                                    $hotel_checkavailability=$week->hotel_checkavailability;
                                                                    $hotel_checkavailability=json_decode($hotel_checkavailability);
                                                                    print_r($hotel_checkavailability->property_name ?? '');
                                                                    
                                                                }
                                                                else if($week->provider == 'ratehawk')
                                                                {
                                                                   $ratehawk_details_rs=$week->ratehawk_details_rs;
                                                                    $ratehawk_details_rs=json_decode($ratehawk_details_rs);
                                                                    print_r($ratehawk_details_rs->name ?? '');    
                                                                }
                                                                else if($week->provider == 'hotelbeds')
                                                                {
                                                                  $hotelbedSelectionRS=$week->hotelbedSelectionRS;
                                                                    $hotelbedSelectionRS=json_decode($hotelbedSelectionRS);
                                                                    print_r($hotelbedSelectionRS->hotel->rooms[0]->name ?? '');  
                                                                }
                                                                else if($week->provider == 'tbo')
                                                                {
                                                                  $tboSelectionRS=$week->tboSelectionRS;
                                                                    $tboSelectionRS=json_decode($tboSelectionRS);
                                                                    print_r($tboSelectionRS->HotelResult[0]->Rooms[0]->Name[0] ?? '');   
                                                                }
                                                                 else if($week->provider == 'travellanda')
                                                                {
                                                                  $travellandaSelectionRS=$week->travellandaSelectionRS;
                                                                    $travellandaSelectionRS=json_decode($travellandaSelectionRS);
                                                                    print_r($travellandaSelectionRS[0]->Rooms->Room->RoomName ?? '');   
                                                                }
                                                                
                                                                ?>
                                                                
                                                                
                                                            </td>
                                                            <td><?php echo date('y-m-d', strtotime($week->created_at)); ?></td>
                                                                
                                                         <td>{{$week->check_in}}</td>
                                                         <td>
                                                             
                                                             
                                                             <?php
                                                             
$checkinDate = date_create($week->check_in);
$checkoutDate = date_create($week->check_out);
$interval = date_diff($checkinDate,$checkoutDate);
$no_nights = $interval->format('%a');
print_r($no_nights);
                                                             
                                                             ?>
                                                             
                                                         </td>
                                                         <td>{{$week->booking_status}}</td>
        
      
      
                                                            
                                                            
                                                        </tr>
                                                      
                                                       @endforeach
                                                      
                                                       
                                                    
                                                       
                                                    </tbody>
                                                </table>  
    </div>
    <div class="tab-pane" id="settings1">
     <table id="example_333" class="table dt-responsive nowrap w-100">
                                                    <thead>
                                                       <tr>
                                                           <th>id</th>
                                                            <th>Invoice No</th>
                                                            <!--<th>Provider</th>-->
                                                            <th>Customer Name</th>
                                                             <th>Hotel Name</th>
                                                            <th>Room Type</th>
                                                            <th>Booking Date</th>
                                                            <th>Check In</th>
                                                            <th>No Of Nights</th>
                                                            <th>status</th>
                                                        </tr>
                                                    </thead>
                                                
                                                
                                                    <tbody>
                                                        
                                                        
                                                         @foreach($arrival_detail_this_month as $month)
                                                        
                                                        <?php
                                                        $lead_passenger_details=json_decode($month->lead_passenger_details);
                                                       
                                                        
                                                        ?>
                                                        <tr>
                                                            <td>{{$month->id}}</td>
                                                            <td>{{$month->search_id ?? ''}}</td>
                                                            <!--<td>{{$month->provider }}</td>-->
                                                            <td>{{$lead_passenger_details->lead_first_name ?? ''}} {{$lead_passenger_details->lead_last_name ?? ''}}</td>
                                                            <td>1</td>
                                                            <td>1</td>
                                                            <td><?php echo date('y-m-d', strtotime($month->created_at)); ?></td>
                                                                
                                                         <td>{{$month->check_in ?? ''}}</td>
                                                         <td>
                                                                                                            <?php
                                                             
$checkinDate = date_create($month->check_in);
$checkoutDate = date_create($month->check_out);
$interval = date_diff($checkinDate,$checkoutDate);
$no_nights = $interval->format('%a');
print_r($no_nights);                                                         



                                                             
                                                             ?> 
                                                             
                                                         </td>
                                                         <td>{{$month->booking_status ?? ''}}</td>
        
      
      
                                                            
                                                            
                                                        </tr>
                                                      
                                                       @endforeach
                                                       
                                                    
                                                       
                                                    </tbody>
                                                </table>  
    </div>
</div>
                                </div> <!-- end card-->
                            </div>  
</div>




 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
         <script>
   $(document).ready(function () {

     $('#example_111').DataTable({
        scrollX: true,
        scrollY: true,
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        
    });
    
    $(document).ready(function () {

     $('#example_222').DataTable({
        scrollX: true,
        scrollY: true,
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        
    });
    
}); 
$(document).ready(function () {

     $('#example_333').DataTable({
        scrollX: true,
      scrollY: true,
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        
    });
    
}); 
}); 
</script> 
@endsection
@section('scripts')

<script>

</script>
@stop



