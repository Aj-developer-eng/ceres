
<?php

//print_r($user_rooms);die();

?>


@extends('template/frontend/userdashboard/layout/default')
@section('content')


<div class="dashboard-content" style="padding:2rem;">
    <div style="display:flex; justify-content: space-between;">
        <h4>Rooms Type List</h4>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">Add New</button>
    </div>
    
    <div class="row">
<div class="col-lg-12 col-sm-12">
<div class="dashboard-list-box dash-list margin-top-0">
    <div class="row">
        <div class="col-md-12">
             <table id="myTable" class="display nowrap table  table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>Sr</th>
                        <th>ID</th>
                        <th>Type Name</th>
                        <th>Persons</th>
                        
                    </tr>
                </thead>
                <tbody>
                
                    @if(isset($roomTypes))
                        @foreach($roomTypes as $room_type_res)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $room_type_res->id }}</td>
                            <td>{{ $room_type_res->room_type }}</td>
                            <td>{{ $room_type_res->no_of_persons }}</td>
                        </tr>
                        @endforeach
                    @endif
                </tbody>
            </table>
        </div>
 
    </div>

</div>
</div>
</div>
</div>


<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" style="display: none;" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header " style="display:flex; justify-content: space-between;">
                  <h1 class="modal-title fs-5" id="exampleModalLabel">Add Room Type</h1>
                  
              </div>
              <form class="ps-3 pe-3" action="{{ URL::to('hotel_manger/add_room_type_sub') }}" method="post">
                  @csrf
              <div class="modal-body">
                 <div id="example_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                                <div class="mb-3">
                                                    <label for="username" class="form-label">Select Parent</label>
                                                    <select class="form-control" name="parent_category">
                                                        <option value="Single">Single</option>
                                                        <option value="Double">Double</option>
                                                        <option value="Triple">Triple</option>
                                                        <option value="Quad">Double</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="username" class="form-label">Type Name</label>
                                                    <input class="form-control" type="text"  name="room_type_name" required placeholder="">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="username" class="form-label">For Persons</label>
                                                    <input class="form-control" type="number"  name="max_person" required placeholder="">
                                                </div>
                                                
                                               
                                    </div>
                                </div>
                            </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button  class="btn btn-primary" type="submit">Save changes</button>
              </div>
              </form>
            </div>
          </div>
        </div>
@endsection

@section('scripts')
<script>
    $(document).ready( function () {
        $('#myTable').DataTable({
            "scrollX": true,
        });
    } );
</script>

@stop
