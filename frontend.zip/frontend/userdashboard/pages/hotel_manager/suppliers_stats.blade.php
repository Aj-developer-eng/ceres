
<?php

//print_r($data);die();

?>

@extends('template/frontend/userdashboard/layout/default')
@section('content')

    <?php $currency=Session::get('currency_symbol'); ?>
    
    <style>
        .nav-link{
          color: #575757;
          font-size: 18px;
        }
    </style>

    <div class="content-wrapper">
        
        
        
        <section class="content" style="padding: 30px 50px 0px 50px;">
          <div class="container-fluid">
            <div class="row">
              <div class="col-lg-12 col-6">
                <nav class="breadcrumb push">
                    <a class="breadcrumb-item" href="#">Dashboard</a> 
                    <span class="breadcrumb-item active">View Agent Invoices</span>
                </nav>
              </div>
            </div>
          </div>
        </section>
        
        <section class="content" style="padding: 10px 20px 0px 20px">
          <div class="container-fluid">
            <div class="row d-none">
            
              <!-- ./col -->
              <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-success" style="height: 184px;text-align: center;padding: 15px 0px 0px 0px;background-color: #313a46 !important;color: white;">
                  <div class="icon mb-2">
                    <span class="iconify" data-icon="uil-dollar-sign-alt" data-width="70"></span>
                  </div>
                  <div class="inner">
                    <h3 id="total_revenue"></h3>
    
                    <p>Total Amount</p>
                  </div>
                  
                </div>
              </div>
              <!-- ./col -->
              <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box" style="height: 184px;text-align: center;padding: 15px 0px 0px 0px;background-color: #313a46 !important;color: white;">
                  <div class="icon mb-2">
                    <span class="iconify" data-icon="uil-dollar-sign-alt" data-width="70"></span>
                  </div>
                  <div class="inner">
                    <h3 id="total_paid"></h3>
    
                    <p>Total Paid</p>
                  </div>
                  
                </div>
              </div>
              <!-- ./col -->
              <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-info" style="height: 184px;text-align: center;padding: 15px 0px 0px 0px;background-color: #313a46 !important;color: white;">
                  <div class="icon mb-2">
                    <span class="iconify" data-icon="uil-dollar-sign-alt" data-width="70"></span>
                  </div>
                  <div class="inner">
                    <h3 id="outstanding"></h3>
    
                    <p>Outstanding</p>
                  </div>
                  
                </div>
              </div>
              
                <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-primary" onclick="manageOverPaid('')" data-bs-toggle="modal" data-bs-target="#exampleModal" style="height: 184px;text-align: center;padding: 15px 0px 0px 0px;background-color: #313a46 !important;color: white;">
                  <div class="icon mb-2">
                    <!-- <i class="mdi mdi-eye me-1"></i> -->
                    <span class="iconify" data-icon="uil-dollar-sign-alt" data-width="70"></span>
                  </div>
                  <div class="inner">
                    
                    <p>Wallet Amount</p>
    
                    <h3 id="over_paid"></h3>
    
                  </div>
                  
                </div>
              </div>
              <!-- ./col -->
            </div>
          </div>
        </section>
    
        <section class="content" style="padding: 30px 50px 0px 50px;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-6">
                        <h4>Supplier Stats Details</h4>
                        <div class="panel-body padding-bottom-none">
                            <div class="block-content block-content-full">
                                <div id="example_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table style="" class="table nowrap example1 dataTable no-footer myTable" id="" role="grid" aria-describedby="example_info">
                                                
                                                   
                                                <thead>
                                                    <tr role="row">
                                                        <th>Sr</th>
                                                        <th>Wallet Balance</th>
                                                        <th>Supplier Id</th>
                                                        <th>Supplier Name</th>
                                                        <th>Total Rooms</th>
                                                        <th>Booked Rooms</th>
                                                        <th>Cost</th>
                                                        <th>Payable</th>
                                                        <th>Paid</th>
                                                        <th>Remaning Amount</th>
                                                        <th>Over Paid</th>
                                                        <th>Wallet Trans</th>
                                                  
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @isset($supplier_data)
                                                        <?php 
                                                            $total_amount = 0;
                                                            $paid_amount = 0;
                                                        ?>
                                                        @foreach($supplier_data as $sup_res)
                                                        <tr role="row">
                                                            <td>{{ $loop->iteration }}</td>
                                                            <td>{{ $sup_res->wallet_amount }}</td>
                                                            <td>{{ $sup_res->supplier_id }}</td>
                                                            <td>{{ $sup_res->supplier_name }}</td>
                                                            <td onclick="display_rooms({{ $sup_res->supplier_id }})">{{ $sup_res->total_rooms }}<br>
                                                                <input hidden type="text" value="{{ json_encode($sup_res->rooms_data) }}" id="sup{{ $sup_res->supplier_id }}">
                                                                
                                                                <?php 
                                                                    foreach($sup_res->rooms_details as $detail_res){
                                                                        ?>
                                                                          <h6><?php echo $detail_res->type_name ?> :<?php echo $detail_res->rooms_count ?>,Booked :<?php echo $detail_res->booked ?></h6>  
                                                                        <?php
                                                                    }
                                                                ?>
                                                               
                                                            </td>
                                                            <td>{{ $sup_res->total_booked }}</td>
                                                            <td>{{ $sup_res->supplier_total_cost }}</td>
                                                            <td>{{ $sup_res->supplier_total_payable }}</td>
                                                            <td>{{ $sup_res->total_paid }}</td>
                                                            <td></td>
                                                            <td>
                                                                <a onclick="manage_balance('{{ $sup_res->supplier_id }}',{{ $sup_res->wallet_amount }})" class="mb-2" data-bs-toggle="modal" data-bs-target="#exampleModal"><span class="badge bg-success" style="font-size: 15px">Manage Wallet</span></a><br>
                                                            </td>
                                                            <td>
                                                                <a href="{{ URL::to('supplier_hotel_wallet_trans/'.$sup_res->supplier_id.'') }}" title="blank" class="btn btn-info btn-sm" >Wallet Trans</a>
                                                            </td>
                                                        </tr>
                                                        
                                                       
                                                        @endforeach
                                                    @endisset
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        
        <!-- Modal -->
   
        
        
    </div>
    
    <div class="modal fade" id="display_rooms" tabindex="-1" aria-labelledby="exampleModalLabel" style="display: none;" aria-hidden="true">
          <div class="modal-dialog modal-xl">
            <div class="modal-content">
              <div class="modal-header " style="display:flex; justify-content: space-between;">
                  <h1 class="modal-title fs-5" id="exampleModalLabel">Rooms Details</h1>
                    <div>
                         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
               
              </div>
              <div class="modal-body">
                 <div id="example_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table style="" class="table nowrap example1 dataTable no-footer myTable" role="grid" aria-describedby="example_info">
                                                
                                                <thead>
                                                    <tr role="row">
                                                        <th>Sr</th>
                                                        <th>Hotel Name</th>
                                                        <th>Hotel location</th>
                                                        <th>Room Type</th>
                                                        <th>Room Id</th>
                                                        <th>Room Generate Id</th>
                                                        <th>Quantity</th>
                                                        <th>Booked</th>
                                                        <th>Room Price</th>
                                                        <th>Total Price</th>
                                                        <th>Payable</th>
                                                        <th>Payable</th>
                                                        <th>Paid Amount</th>
                                                        <th>Over Paid</th>
                                                        <th>Available From</th>
                                                        <th>Available To</th>
                                                        <th>View Bookings Details</th>

                                                    </tr>
                                                </thead>
                                                
                                                <tbody style="text-align: center;" id="trData">
                                                    
                                               </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
              </div>
            </div>
          </div>
        </div>
        
        <div class="modal fade" id="manage_balance" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                 <div> 
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Manage Balance</h1>
                    
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <form action="https://alhijaztours.net/manage_wallent_balance" method="post" enctype="multipart/form-data">
                 @csrf           
                  <div class="modal-body">
                          
                   
                      <div class="row">
                        <div class="col-12 mb-2">
                            <input type="text" name="agent_id" hidden="" value="11">
                            <label>Select Transcation Type</label>
                            <select class="form-control" id="" name="transtype">
                                <option value="Refund">Refund</option>
                                <option value="Deposit">Deposit</option>
                            </select>
                        </div>
                         <div class="col-6 mb-2">
                            <label>Payment Method</label>
                            <select class="form-control"  name="payment_method">
                                <option value="Bank Transfer">Bank Transfer</option>
                                <option value="Cash">Cash</option>
                                <option value="Card Payment">Card Payment</option>
                            </select>
                        </div>
                         <div class="col-6 mb-2">
                             <label>Current Balance</label>
                             <input type="text" class="form-control" readonly id="current_bal" required=""  name="current_bal" placeholder="Enter Payment Amount">
                             <input type="text" class="form-control" readonly id="supplier_id" hidden required=""  name="supplier_id" placeholder="Enter Payment Amount">
                             <input type="text" name="request_person" value="hotel_supplier" hidden>
                        </div>
                        <div class="col-6 mb-2">
                             <label>Payment Date</label>
                             <input type="date" class="form-control" required="" value="2022-12-14" name="payment_date" placeholder="Enter Payment Amount">
                        </div>
                        
                        <div class="col-6 mb-2">
                             <label>Payment Amount</label>
                             <input type="text" class="form-control" required="" name="payment_am" placeholder="Enter Payment Amount">
                        </div>
                        
                      
                        
                        <div class="col-6 mb-2" id="transcation_id" style="display: block;">
                            <label>Transaction ID</label>
                          <input type="text" class="form-control" name="transcation_id" placeholder="Enter Transaction ID">
                          <input type="text" class="form-control" required="" name="invoice_id" hidden="" value="AHT3383261" placeholder="Enter Transaction ID">
                        </div>
                        
                       <div class="col-6 mb-2" id="account_id" style="display: block;">
                           <label>Account No.</label>
                           <input type="text" class="form-control" name="account_no" placeholder="Payment to (Account No.)" value="13785580">
                        </div>
                        
                      </div>
                   
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                  </div>
           </form>
              
            </div>
          </div>
        </div>
        
        <div id="recieve_payment_modal" class="modal fade" tabindex="-1" style="display: none;" aria-hidden="true">
               <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header modal-colored-header bg-primary">
                            <h4 class="modal-title" id="compose-header-modalLabel">Payment Amount</h4>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                         <div class="modal-body flight_payment_html"> <div class="p-1">
                            <div class="modal-body px-3 pt-3 pb-0">
                                <form action="{{ URL::to('hotel_supplier_payments') }}" method="post">
                                    @csrf               
                                    <!--<input hidden readonly value="" name="flight_id" class="form-control" type="text" id="package_id" required="">-->
                                    
                                    <div class="mb-2">
                                        
                                          <div class="row">
                                            <div class="col-md-6">
                                                 <label for="tourId" class="form-label">Room ID</label>
                                                 <input readonly="" name="room_id" class="form-control" value="20" type="text" id="room_id" required="">
                                            </div>
                                            <div class="col-md-6">
                                                 <label for="tourId" class="form-label">Generate ID</label>
                                                 <input readonly="" name="room_id_generate" class="form-control" value="20" type="text" id="room_id_generate" >
                                            </div>
                                        </div>
                                                
                                     
                                      
                                      <input readonly="" name="supplier_id" class="form-control" hidden type="text" id="supplier_id_pay" required="">
                                    </div>
                                                             
                                    <div class="mb-2">
                                      <label for="tourId" class="form-label">Suplier Name</label>
                                      <input  name="payingidentityemail" class="form-control" readonly value="" id="supplier_name" type="text" required="">
                                      <input hidden="" name="payingidentityid" class="form-control" value="4" type="text" required="">
                                    </div>
            
            
                                    <div class="mb-2">
                                      <label for="date" class="form-label">Date</label>
                                      <input value="" name="date" class="form-control" type="date" id="date" required="">
                                    </div>
            
                                    <div class="mb-2">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for="total_amount" class="form-label">Total Amount</label>
                                                <input readonly="" name="total_amount" value="" class="form-control" type="text" id="total_amount" required="">
                                            </div>
                                            
                                            <div class="col-md-6">
                                               <label for="total_amount" class="form-label">Payable Amount</label>
                                                <input readonly="" name="total_amount_payable" value="" class="form-control" type="text" id="total_amount_payable" required="">
                                            </div>
                                            
                                            <div class="col-md-6">
                                               <label for="total_amount" class="form-label">Remaining Total</label>
                                                <input readonly="" name="" value="" class="form-control" type="text" id="rem_total" required="">
                                            </div>
                                            
                                            <div class="col-md-6">
                                               <label for="total_amount" class="form-label">Remaining Payable</label>
                                                <input readonly="" name="" value="" class="form-control" type="text" id="rem_total_pay" required="">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    
            
                                    <div class="mb-2">
                                        <div class="row">
                                            <div class="col-md-6">
                                               <label for="total_amount" class="form-label">Payment From</label>
                                                <select class="form-control" onchange="paymentMethod()" id="payment_method" name="payment_method">
                                                    <option value="Bank Transfer">Bank Transfer</option>
                                                    <option value="Cash">Cash</option>
                                                    <option value="Card Payment">Card Payment</option>
                                                    <option value="Wallet">Wallet</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="total_amount" class="form-label">Wallet Balance</label>
                                                 <input name="" class="form-control" type="number" readonly="" id="supplier_wallet" required="">
                                            </div>
                                        </div>
                                     
                                    </div>
                                    
                                    <div class="mb-2">
                                         <div class="row">
                                            <div class="col-md-6">
                                                 <label for="amount_paid" class="form-label">Payment Type</label>
                                       
                                                <select class="form-control" id="payment_type" name="payment_type">
                                                    <option value="payable_amount">Payable Amount</option>
                                                    <option value="total_amount">Total Amount</option>
                                                  
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                 <label for="amount_paid" class="form-label">Payment Amount</label>
                                       
                                                <input name="amount_paid" onchange="myFunction()" required class="form-control" type="number" id="amount_paid" placeholder="Nothing Paid yet">
                                            </div>
                                        </div>
                                     
                               
                                    </div>
            
                                    <div style="padding: 10px 0px 10px 0px;">
                                        <button style="padding: 10px 30px 10px 30px;" type="submit" class="btn btn-primary"><i class="mdi mdi-send me-1"></i>Payment</button>
                                        <button style="margin-left: 5px;padding: 10px 30px 10px 30px;" type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                                    </div>
            
                                    <!-- <div class="mb-2 text-center">
                                      <button class="btn btn-primary" type="submit">Recieve</button>
                                    </div> -->
                                </form>
                            </div>
                        </div></div>
                       
                    </div>
               </div>
            </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
    <script>
    
  
    
        $(document).ready(function () {
          
            //DataTable
            $('.myTable').DataTable({
                scrollX: true,
            });
            
            //View Modal Single Quotation
          
        });
        
          function paymentMethod(){
                var payment_method = $('#payment_method').val();
                console.log('The payment is call now ');
                if(payment_method == 'Wallet'){
                 
                    var walletAmount = $('#supplier_wallet').val();
                    $('#amount_paid').attr('max',walletAmount);
                }else{
                      
                    $('#amount_paid').attr('max',false);
                }
            }
        
        
        function display_rooms(id){
            $('#display_rooms').modal('show');
            $('#trData').html('');
            
            var roomsData = $('#sup'+id+'').val();
            
            roomsData = JSON.parse(roomsData);
            console.log(roomsData);
            
            var counter = 0;
            var trData = ``;
            roomsData.forEach(function(item){
                if(item['booked'] == null){
                    var booked = 0;
                }else{
                   var booked = item['booked'];
                }
                
                if(item['room_generate_id'] == null){
                    var generateId = '';
                }else{
                    var generateId = item['room_generate_id'];
                }
                
                
                var total_cost_SAR = item['total_cost_purchase'];
                var total_cost_GBP = item['total_cost_convert'];
                var supplier_name = item['room_supplier_name'];
                trData +=`<tr>
                            <td>${counter++}</td>
                            <td>${item['hotel_name']}</td>
                            <td>${item['hotel_city']}</td>
                            <td>${item['room_type']}</td>
                            <td>${item['room_id']}</td>
                            <td>${generateId}</td>
                            <td>${item['quantity']}</td>
                            <td>${booked}</td>
                            <td>${item['single_room_price']}</td>
                            <td>${item['all_room_price']}</td>
                            <td>${total_cost_SAR.toFixed(2)} ${item['purchase_currency']}</td>
                            <td>${total_cost_GBP.toFixed(2)} ${item['sale_currency']}</td>
                            <td>${item['paid_amount']}</td>
                            <td>${item['over_paid_amount']}</td>
                            <td>${item['availible_from']}</td>
                            <td>${item['availible_to']}</td>
                            <td><a href="view_room_bookings/${item['room_id']}/${item['room_type_id']}/${item['room_generate_id']}/${id}" target="blank" class="btn btn-info btn-sm">View Bookings</a>
                                <button class="btn btn-success btn-sm" onclick="recieve_payment_modal(${item['room_id']},'',${item['room_supplier_id']},${item['wallat_balance']},'${supplier_name}',${item['total_cost_purchase']},${item['all_room_price']},${item['paid_amount']})">Payment</button>
                            </td>
                        </tr>`;
            })
            
            $('#trData').html(trData)
        }
        
        function manage_balance(sup_id,wallet_balance){
            $('#manage_balance').modal('show');
            $('#current_bal').val(wallet_balance);
            $('#supplier_id').val(sup_id);
            
           console.log('supplier id is '+sup_id+' wallet Balance is '+wallet_balance);
       }
       
       function recieve_payment_modal(room_id,generate_id,supplier_id,wallet_bal,supplier_name,total_payable,total_amount,paid_amount){
            $('#recieve_payment_modal').modal('show');
            $('#room_id').val(room_id);
            $('#room_id_generate').val(generate_id);
            $('#supplier_id_pay').val(supplier_id);
            $('#room_id').val(room_id);
            $('#supplier_wallet').val(wallet_bal);
            $('#supplier_name').val(supplier_name);
            total_amount = total_amount.toFixed(2);
            total_payable = total_payable.toFixed(2);
            
            var rem_total  = total_amount - paid_amount;
            var rem_total_pay  = total_payable - paid_amount;
            
            $('#total_amount').val(total_amount);
            $('#rem_total_pay').val(rem_total_pay);
            $('#rem_total').val(rem_total);
            $('#total_amount_payable').val(total_payable);
            
           console.log('supplier id is '+sup_id+' wallet Balance is '+wallet_balance);
       }
       

    </script>
    
    <script>
    
        
    </script>

@endsection
