@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php $currency=Session::get('currency_symbol'); $account_No=Session::get('account_No'); ?>

<div id="flights-Airline-Name" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Flight Airline Name</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form class="ps-3 pe-3" action="#">
                    <div class="mb-3">
                        <label for="username" class="form-label">Flight Airline Name</label>
                        <input class="form-control" type="other_Airline_Name" id="other_Airline_Name" name="other_Airline_Name" placeholder="">
                    </div>

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_Airline_Name" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal --> 
 
<div id="signup-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Visa Type</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <!--<div class="text-center mt-2 mb-4">-->
                <!--    <a href="index.html" class="text-success">-->
                <!--        <span><img src="assets/images/logo-dark.png" alt="" height="18"></span>-->
                <!--    </a>-->
                <!--</div>-->

                <form class="ps-3 pe-3" action="#">

                    <div class="mb-3">
                        <label for="username" class="form-label">Visa </label>
                        <input class="form-control" type="email" id="other_visa_type" name="other_visa_type" placeholder="">
                    </div>

                   

                  

                    

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="hotel-name-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Hotel Name</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form class="ps-3 pe-3" action="#">
                    <div class="mb-3">
                        <label for="username" class="form-label">Hotel Name</label>
                        <input class="form-control" type="other_Hotel_Name" id="other_Hotel_Name" name="other_Hotel_Name" placeholder="">
                    </div>
                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_hotel_name" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="hotel-name-new-modal" aria-hidden="true" tabindex="-1" aria-labelledby="myLargeModalLabel" aria-modal="true" role="dialog" style="display: none; padding-left: 0px;">
    <div class="modal-dialog modal-lg" style="margin-right: 50%;">
        <div class="modal-content" style="width: 200%;">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">Add Hotel</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <form id="form_submit_id" action="#" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-md-12 mb-4">
                                @if (session('success'))
                                <div class="alert alert-success alert-dismissible fade show" style="background-color:#d4edda;" role="alert">
                                    {{ session('success') }}
                                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                @endif
                
                                @if (session('error'))
                                <div class="alert alert-danger alert-dismissible fade show" style="background-color:#f5cfcf;" role="alert">
                                    {{ session('error') }}
                                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                @endif
                            </div>
                            <div class="col-md-8">
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link active" id="home-tab" data-bs-toggle="tab" href="#general" role="tab" aria-controls="general" aria-selected="true">GENERAL</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="facilities-tab" data-bs-toggle="tab" href="#facilities" role="tab" aria-controls="facilities" aria-selected="false">FACILITIES</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="meta-info-tab" data-bs-toggle="tab" href="#meta-info" role="tab" aria-controls="meta-info" aria-selected="false">META INFO</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="policy-tab" data-bs-toggle="tab" href="#policy" role="tab" aria-controls="policy" aria-selected="false">POLICY</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="contact-tab" data-bs-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">CONTACT</a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="translate-tab" data-bs-toggle="tab" href="#translate" role="tab" aria-controls="translate" aria-selected="false">TRANSLATE</a>
                                    </li>
                                </ul>
                                <!-- Main Tab Contant Start -->
                                <div class="tab-content" id="myTabContent">
                                    <!-- General Tab Start -->
                                    <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                                        <div class="row">
                                            <div class="col-md-8" style="padding: 15px;">
                                                <label for="">PROPERTY TITLE</label>
                                                <input id="property_name" type="text" class="form-control @error('property_name') is-invalid @enderror" name="property_name" value="{{ old('property_name') }}" autocomplete="property_name" autofocus>
                
                                                @error('property_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="col-md-4" style="padding: 15px;">
                                                <label for="">PROPERTY IMAGE</label>
                                                <input id="property_img" type="file" class="form-control @error('property_img') is-invalid @enderror" name="property_img" value="{{ old('property_img') }}" autocomplete="property_img" autofocus>
                
                                                @error('property_img')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div> 
                                            <div class="col-md-12" style="padding: 15px;">
                                                <label for="">PROPERTY DESCRIPTION</label>
                                                <textarea name="property_desc" row="5" class="form-control @error('property_desc') is-invalid @enderror"  value="{{ old('property_desc') }}"  autocomplete="property_desc" placeholder="Enter ga message"></textarea>
                
                                                @error('property_desc')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="col-md-12" style="padding: 15px;">
                                                <label for="">GOOGLE MAP URL</label>
                                                <input id="property_google_map" type="text" class="form-control @error('property_google_map') is-invalid @enderror" name="property_google_map" value="{{ old('property_google_map') }}" autocomplete="property_google_map" autofocus>
                
                                                @error('property_google_map')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="col-md-6" style="padding: 15px;">
                                                <label for="">LATITUDE</label>
                                                <input id="latitude" type="text" class="form-control @error('latitude') is-invalid @enderror" name="latitude" value="{{ old('latitude') }}" autocomplete="latitude" autofocus>
                
                                                @error('latitude')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="col-md-6" style="padding: 15px;">
                                                <label for="">LONGITUDE</label>
                                                <input id="longitude" type="text" class="form-control @error('longitude') is-invalid @enderror" name="longitude" value="{{ old('longitude') }}" autocomplete="longitude" autofocus>
                
                                                @error('longitude')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="col-md-6" style="padding: 15px;">
                                                <label for="">PRICE TYPE</label>
                                                <select name="price_type" id="" class="form-control">
                                                    <option value="Budget">Budget</option>
                                                    <option value="Economy">Economy</option>
                                                    <option value="Moderate">Moderate</option>
                                                    <option value="Deluxe">Deluxe</option>
                                                    <option value="Premium">Premium</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6" style="padding: 15px;">
                                                <label for="">PRICE STAR</label>
                                                <select name="star_type" id="" class="form-control">
                                                    <option value="1">1 Star</option>
                                                    <option value="2">2 Star</option>
                                                    <option value="3">3 Star</option>
                                                    <option value="4">4 Star</option>
                                                    <option value="5">5 Star</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6" style="padding: 15px;">
                                                <label for="">COUNTRY</label>
                                                <select name="property_country" onchange="selectCities()" id="property_country" class="form-control">
                                                    @foreach($all_countries as $country_res)
                                                        <option value="{{ $country_res->id }}">{{ $country_res->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                
                                            <div class="col-md-6" style="padding: 15px;">
                                                <label for="">City</label>
                                                <select name="property_city" id="property_city" class="form-control">
                                                   
                                                </select>
                                            </div>  
                                        </div>
                                    </div>
                                    <!-- facilities Tab Start -->
                                    <div class="tab-pane fade" id="facilities" role="tabpanel" aria-labelledby="facilities-tab">
                                        <div class="form-check" style="margin-top: 5px;">
                                            <input class="form-check-input" type="checkbox" value="" id="checkall">
                                            <label class="form-check-label" for="checkall">
                                                Select All
                                            </label>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Airport Transport" id="Airport_Transport">
                                                    <label class="form-check-label" for="Airport_Transport">
                                                         Airport Transport
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Business Center" id="Business_Center">
                                                    <label class="form-check-label" for="Business_Center">
                                                        Business Center
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Disabled Facilities" id="Disabled_Facilities">
                                                    <label class="form-check-label" for="Disabled_Facilities">
                                                        Disabled Facilities
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Night Club" id="Night_Club">
                                                    <label class="form-check-label" for="Night_Club">
                                                        Night Club
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Laundry Service" id="Laundry Service">
                                                    <label class="form-check-label" for="Laundry Service">
                                                        Laundry Service
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Restaurant" id="Restaurant">
                                                    <label class="form-check-label" for="Restaurant">
                                                        Restaurant
                                                    </label>
                                                </div>
                                            </div>
                                          
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Wi-Fi Internet" id="Wi-Fi_Internet">
                                                    <label class="form-check-label" for="Wi-Fi_Internet">
                                                        Wi-Fi Internet
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Bar Lounge" id="Bar_Lounge">
                                                    <label class="form-check-label" for="Bar_Lounge">
                                                        Bar Lounge
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Swimming Pool" id="Swimming_Pool">
                                                    <label class="form-check-label" for="Swimming_Pool">
                                                        Swimming Pool
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Inside Parking" id="Inside_Parking">
                                                    <label class="form-check-label" for="Inside_Parking">
                                                        Inside Parking
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Shuttle Bus Service" id="Shuttle_Bus_Service">
                                                    <label class="form-check-label" for="Shuttle_Bus_Service">
                                                        Shuttle Bus Service
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Fitness Center" id="Fitness_Center">
                                                    <label class="form-check-label" for="Fitness_Center">
                                                        Fitness Center
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Children Activites" id="Children_Activites">
                                                    <label class="form-check-label" for="Children_Activites">
                                                         Children Activites
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Air Conditioner" id="Air_Conditioner">
                                                    <label class="form-check-label" for="Air_Conditioner">
                                                        Air Conditioner
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Cards Accepted" id="Cards_Accepted">
                                                    <label class="form-check-label" for="Cards_Accepted">
                                                        Cards Accepted
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Banquet Hall" id="Banquet_Hall">
                                                    <label class="form-check-label" for="Banquet_Hall">
                                                        Banquet Hall
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Elevator" id="Elevator">
                                                    <label class="form-check-label" for="Elevator">
                                                        Elevator
                                                    </label>
                                                </div>
                                            </div>
                
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="Facilites[]" value="Pets Allowed" id="Pets_Allowed">
                                                    <label class="form-check-label" for="Pets_Allowed">
                                                        Pets Allowed
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Meta Info Tab Start -->
                                    <div class="tab-pane fade" id="meta-info" role="tabpanel" aria-labelledby="meta-info-tab">
                                        <div class="row">
                                            <div class="col-md-12" style="padding: 15px;">
                                                <label for="">META TITLE</label>
                                                <input id="meta_title" type="text" class="form-control @error('meta_title') is-invalid @enderror" name="meta_title" value="{{ old('meta_title') }}" autocomplete="meta_title" autofocus>
                
                                                @error('meta_title')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                                <div class="col-md-12" style="padding: 15px;">
                                                    <label for="">META KEYWORDS</label>
                                                    <textarea name="meta_keywords" row="5" class="form-control @error('meta_keywords') is-invalid @enderror"  value="{{ old('meta_keywords') }}"  autocomplete="meta_keywords" placeholder="Enter ga message"></textarea>
                
                                                    @error('meta_keywords')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                                <div class="col-md-12" style="padding: 15px;">
                                                    <label for="">META DESCRIPTION</label>
                                                    <textarea name="meta_desc" row="5" class="form-control @error('meta_desc') is-invalid @enderror"  value="{{ old('meta_desc') }}"  autocomplete="meta_desc" placeholder="Enter ga message"></textarea>
                
                                                    @error('meta_desc')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                        </div>
                                    </div>
                                    <!-- Policy Tab Start -->
                                    <div class="tab-pane fade" id="policy" role="tabpanel" aria-labelledby="policy-tab">
                                        <div class="row">
                                            <div class="col-md-6" style="padding: 15px;">
                                                <label for="">CHECK-IN FROM</label>
                                                <select name="hotel_check_in" id="" class="form-control">
                                                    <option value="07:00">07:00</option>
                                                    <option value="07:30">07:30</option> 
                                                    <option value="08:00">08:00</option> 
                                                    <option value="08:30">08:30</option> 
                                                    <option value="09:00">09:00</option>
                                                    <option value="09:30">09:30</option> 
                                                    <option value="10:00">10:00</option>
                                                    <option value="10:30">10:30</option> 
                                                    <option value="11:00">11:00</option>
                                                    <option value="11:30">11:30</option> 
                                                    <option selected value="12:00">12:00</option>
                                                    <option value="12:30">12:30</option> 
                                                    <option value="13:00">13:00</option>
                                                    <option value="13:30">13:30</option> 
                                                    <option value="14:00">14:00</option>
                                                    <option value="14:30">14:30</option> 
                                                    <option value="15:00">15:00</option>
                                                    <option value="15:30">15:30</option> 
                                                    <option value="16:00">16:00</option>
                                                    <option value="16:30">16:30</option> 
                                                    <option value="17:00">17:00</option>
                                                    <option value="17:30">17:30</option> 
                                                    <option value="18:00">18:00</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6" style="padding: 15px;">
                                                <label for="">CHECK-OUT TO</label>
                                                <select name="hotel_check_out" id="" class="form-control">
                                                    <option value="07:00">07:00</option>
                                                    <option value="07:30">07:30</option> 
                                                    <option value="08:00">08:00</option> 
                                                    <option value="08:30">08:30</option> 
                                                    <option value="09:00">09:00</option>
                                                    <option value="09:30">09:30</option> 
                                                    <option value="10:00">10:00</option>
                                                    <option value="10:30">10:30</option> 
                                                    <option value="11:00">11:00</option>
                                                    <option value="11:30">11:30</option> 
                                                    <option selected value="12:00">12:00</option>
                                                    <option value="12:30">12:30</option> 
                                                    <option value="13:00">13:00</option>
                                                    <option value="13:30">13:30</option> 
                                                    <option value="14:00">14:00</option>
                                                    <option value="14:30">14:30</option> 
                                                    <option value="15:00">15:00</option>
                                                    <option value="15:30">15:30</option> 
                                                    <option value="16:00">16:00</option>
                                                    <option value="16:30">16:30</option> 
                                                    <option value="17:00">17:00</option>
                                                    <option value="17:30">17:30</option> 
                                                    <option value="18:00">18:00</option>
                                                </select>
                                            </div>
                
                                            <div class="col-md-12" style="padding: 15px;">
                                                <label for="">PAYMENT OPTION</label>
                                                <select name="payment_option" id="" class="form-control">
                                                    <option value="At Arrival">At Arrival</option>
                                                </select>
                                            </div>
                
                                            <div class="col-md-12" style="padding: 15px;">
                                                <label for="">POLICY AND TERMS</label>
                                                <textarea name="policy_and_terms" row="5" class="form-control @error('policy_and_terms') is-invalid @enderror"  value="{{ old('policy_and_terms') }}"  autocomplete="policy_and_terms" placeholder="Enter ga message"></textarea>
                
                                                @error('policy_and_terms')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div> 
                                        </div>
                                    </div>
                                    <!-- Contact Tab Start -->
                                    <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                                        <div class="row">
                                            <div class="col-md-12" style="padding: 15px;">
                                                <label for="">E mail</label>
                                                <input id="hotel_email" type="text" class="form-control @error('hotel_email') is-invalid @enderror" name="hotel_email" value="{{ old('hotel_email') }}" autocomplete="hotel_email" autofocus>
                
                                                @error('hotel_email')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="col-md-12" style="padding: 15px;">
                                                <label for="">Hotel's Website</label>
                                                <input id="hotel_website" type="text" class="form-control @error('hotel_website') is-invalid @enderror" name="hotel_website" value="{{ old('hotel_website') }}" autocomplete="hotel_website" autofocus>
                
                                                @error('hotel_website')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="col-md-12" style="padding: 15px;">
                                                <label for="">Phone Number</label>
                                                <input id="property_phone" type="text" class="form-control @error('property_phone') is-invalid @enderror" name="property_phone" value="{{ old('property_phone') }}" autocomplete="property_phone" autofocus>
                
                                                @error('property_phone')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="col-md-12" style="padding: 15px;">
                                                <label for="">PROPERTY ADDRESS</label>
                                                <input id="property_address" type="text" class="form-control @error('property_address') is-invalid @enderror" name="property_address" value="{{ old('property_address') }}" autocomplete="property_address" autofocus>
                
                                                @error('property_address')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Translate Tab Start --> 
                                    <div class="tab-pane fade" id="translate" role="tabpanel" aria-labelledby="translate-tab">translate</div>
                                </div>
                                <!-- Main Tab Contant End -->
                            </div>
                            <div class="col-md-4" style="margin-top:-.8rem;">
                                <div class="card">
                                    <div class="card-header">
                                        Main Settings
                                    </div>
                                    <div class="card-body">
                                        <label for="">Status</label>
                                        <select name="status" id="" class="form-control">
                                            <option value="Enabled">Enabled</option>
                                            <option value="Enabled">Enabled</option>
                                        </select>
                
                                        <label for="">PROPERTY TYPE</label>
                                        <select name="property_type" id="" class="form-control">
                                            <option value="hotel" selected="selected">Hotel</option>
                                            <option value="villa">Villa</option>
                                            <option value="apartment">Apartment</option>
                                            <option value="resort">Resort</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header">
                                        Markup
                                    </div>
                                    <div class="card-body">
                                        <label for="">B2C Markup (%)</label>
                                        <input id="b2c_markup" type="text" class="form-control @error('b2c_markup') is-invalid @enderror" name="b2c_markup" value="{{ old('b2c_markup') }}" autocomplete="b2c_markup" autofocus>
                
                                        @error('b2c_markup')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                
                                        <label for="">B2B Markup (%)</label>
                                        <input id="b2b_markup" type="text" class="form-control @error('b2b_markup') is-invalid @enderror" name="b2b_markup" value="{{ old('b2b_markup') }}" autocomplete="b2b_markup" autofocus>
                
                                        @error('b2b_markup')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                
                                        <label for="">B2E Markup (%)</label>
                                        <input id="b2e_markup" type="text" class="form-control @error('b2e_markup') is-invalid @enderror" name="b2e_markup" value="{{ old('b2e_markup') }}" autocomplete="b2e_markup" autofocus>
                
                                        @error('b2e_markup')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                
                                        <label for="">Service Fee (%)</label>
                                        <input id="service_fee" type="text" class="form-control @error('service_fee') is-invalid @enderror" name="service_fee" value="{{ old('service_fee') }}" autocomplete="service_fee" autofocus>
                
                                        @error('service_fee')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                        
                                        <div class="row">
                                            <div class="col-md-7">
                                                <label for="">Vat Tax</label>
                                                <select name="tax_type" id="" class="form-control">
                                                    <option value="Fixed">Fixed</option>
                                                    <option value="Percentage">Percentage</option>
                                                </select>
                                            </div>
                                            <div class="col-md-5">
                                                <input id="tax_value" placeholder="Value" style="margin-top:2.4rem;" type="text" class="form-control @error('tax_value') is-invalid @enderror" name="tax_value" value="{{ old('tax_value') }}" autocomplete="tax_value" autofocus>
                                            </div>
                                        </div>
                                        
                
                
                
                                    </div>
                                </div>
                
                            </div>
                        </div>
                
                        <div class="row">
                            <div class="col-md-12 text-right mt-3">
                                <button class="btn btn-primary" id="submitForm_hotel_name_New" type="submit">Submit</button>
                                <!--<button type="submit" class="btn btn-primary">Submit</button>-->
                            </div>
                        </div>
                        
                    </form>
                </div>
                
                <div id="form_submit_data" style="display:none"></div>
                
            </div>
        </div>
    </div>
</div>

<div id="hotel-name-new-modal1" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Hotel Name</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form class="ps-3 pe-3" action="#">
                    
                    <div class="row">
                        <div class="col-md-8" style="padding: 15px;">
                            <label for="">PROPERTY TITLE</label>
                            <input id="property_name" type="text" class="form-control @error('property_name') is-invalid @enderror" name="property_name" value="{{ old('property_name') }}" autocomplete="property_name" autofocus>

                            @error('property_name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-4" style="padding: 15px;">
                            <label for="">PROPERTY IMAGE</label>
                            <input id="property_img" type="file" class="form-control @error('property_img') is-invalid @enderror" name="property_img" value="{{ old('property_img') }}" autocomplete="property_img" autofocus>

                            @error('property_img')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div> 
                        <div class="col-md-12" style="padding: 15px;">
                            <label for="">PROPERTY DESCRIPTION</label>
                            <textarea name="property_desc" row="5" class="form-control @error('property_desc') is-invalid @enderror"  value="{{ old('property_desc') }}"  autocomplete="property_desc" placeholder="Enter ga message"></textarea>

                            @error('property_desc')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-12" style="padding: 15px;">
                            <label for="">GOOGLE MAP URL</label>
                            <input id="property_google_map" type="text" class="form-control @error('property_google_map') is-invalid @enderror" name="property_google_map" value="{{ old('property_google_map') }}" autocomplete="property_google_map" autofocus>

                            @error('property_google_map')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-6" style="padding: 15px;">
                            <label for="">LATITUDE</label>
                            <input id="latitude" type="text" class="form-control @error('latitude') is-invalid @enderror" name="latitude" value="{{ old('latitude') }}" autocomplete="latitude" autofocus>

                            @error('latitude')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-6" style="padding: 15px;">
                            <label for="">LONGITUDE</label>
                            <input id="longitude" type="text" class="form-control @error('longitude') is-invalid @enderror" name="longitude" value="{{ old('longitude') }}" autocomplete="longitude" autofocus>

                            @error('longitude')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-md-6" style="padding: 15px;">
                            <label for="">PRICE TYPE</label>
                            <select name="price_type" id="" class="form-control">
                                <option value="Budget">Budget</option>
                                <option value="Economy">Economy</option>
                                <option value="Moderate">Moderate</option>
                                <option value="Deluxe">Deluxe</option>
                                <option value="Premium">Premium</option>
                            </select>
                        </div>
                        <div class="col-md-6" style="padding: 15px;">
                            <label for="">PRICE STAR</label>
                            <select name="star_type" id="" class="form-control">
                                <option value="1">1 Star</option>
                                <option value="2">2 Star</option>
                                <option value="3">3 Star</option>
                                <option value="4">4 Star</option>
                                <option value="5">5 Star</option>
                            </select>
                        </div>
                        <div class="col-md-6" style="padding: 15px;">
                            <label for="">COUNTRY</label>
                            <select name="property_country" onchange="selectCities()" id="property_country" class="form-control">
                                @foreach($all_countries as $country_res)
                                    <option value="{{ $country_res->id }}">{{ $country_res->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-6" style="padding: 15px;">
                            <label for="">City</label>
                            <select name="property_city" id="property_city" class="form-control">
                               
                            </select>
                        </div>  
                    </div>
                    
                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_hotel_name1" type="submit">Submit</button>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
</div>

<div id="hotel-type-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Hotel Type</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form class="ps-3 pe-3" action="#">
                    <div class="mb-3">
                        <label for="username" class="form-label">Hotel Type</label>
                        <input class="form-control" type="other_Hotel_Type" id="other_Hotel_Type" name="other_Hotel_Type" placeholder="">
                    </div>
                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_hotel_type" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="pickup-location-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Pickup Location</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <!--<div class="text-center mt-2 mb-4">-->
                <!--    <a href="index.html" class="text-success">-->
                <!--        <span><img src="assets/images/logo-dark.png" alt="" height="18"></span>-->
                <!--    </a>-->
                <!--</div>-->

                <form class="ps-3 pe-3" action="#">

                    <div class="mb-3">
                        <label for="username" class="form-label">Pickup Location</label>
                        <input class="form-control" type="pickup_location" id="pickup_location" name="pickup_location" placeholder="">
                    </div>

                   

                  

                    

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_PUL" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="dropof-location-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Dropof Location</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <!--<div class="text-center mt-2 mb-4">-->
                <!--    <a href="index.html" class="text-success">-->
                <!--        <span><img src="assets/images/logo-dark.png" alt="" height="18"></span>-->
                <!--    </a>-->
                <!--</div>-->

                <form class="ps-3 pe-3" action="#">

                    <div class="mb-3">
                        <label for="username" class="form-label">Dropof Location</label>
                        <input class="form-control" type="dropof_location" id="dropof_location" name="dropof_location" placeholder="">
                    </div>

                   

                  

                    

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="submitForm_DOL" type="submit">Submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="add-Categories-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Categories</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form action="https://client.synchronousdigital.com/super_admin/submit_categories" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="mb-3">
                        <label for="label" class="form-label">Title</label>
                        <input class="form-control" type="text" id="title" name="title" placeholder="">
                    </div>
                    <div class="mb-3">
                        <label for="slug" class="form-label">Slug</label>
                        <input class="form-control" type="text" id="slug" name="slug" placeholder="">
                    </div>
                    <div class="mb-3">
                        <label for="image" class="form-label">Image</label>
                        <input class="form-control" type="file" id="" name="image" placeholder="">
                    </div>
                    <div class="mb-3">
                        <label for="placement" class="form-label">Placement</label>
                        <input class="form-control" type="text" id="placement" name="placement" placeholder="">
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" type="text" id="" name="description" placeholder=""></textarea>
                    </div>
                    

                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="add-facilities-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add Facilities</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form action="https://client.synchronousdigital.com/super_admin/submit_attributes" method="post" enctype="multipart/form-data">
                @csrf
                    <div class="mb-3">
                        <label for="username" class="form-label">Facilities Name</label>
                        <input class="form-control" type="title" id="title" name="title" placeholder="">
                    </div>
                    <div class="mb-3 text-center">
                        <button class="btn btn-primary" id="" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
 
<div class="card">
    <div class="card-body">
        <h4 class="header-title">Edit Invoice</h4>
        @if($errors->any())
        <h4>{{$errors->first()}}</h4>
        @endif
        <!--<div class="tab-content">-->
            <form action="{{URL::to('update_Invoices',[$get_invoice->id])}}" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
                @csrf
                <!--<div class="tab-pane show active" id="justified-tabs-preview">-->
                <div id="progressbarwizard">
                    <!--<ul class="nav nav-pills bg-nav-pills nav-justified mb-3">-->
                    <ul class="nav nav-pills nav-justified form-wizard-header mb-3" style="margin-right: 1px;margin-left: 1px;">
                        <li class="nav-item">
                            <a href="#home1" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                <i class="mdi mdi-home-variant d-md-none d-block"></i>
                                <span class="d-none d-md-block">Invoice Details</span>
                            </a>
                        </li>
                        
                        @if(isset($get_invoice->services) && $get_invoice->services != null && $get_invoice->services != '')
                            <?php $services = json_decode($get_invoice->services);?>
                            
                            @if($services[0] == '1' || $services[0] == 'accomodation_tab')
                                <li class="nav-item accomodation_tab">
                                    <a href="#profile1" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                    <i class="uil-bed d-md-none d-block"></i>
                                        <span class="d-none d-md-block">Accomodation</span>
                                    </a>
                                </li>
                            @else
                                <li class="nav-item accomodation_tab" style="display:none;">
                                    <a href="#profile1" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                    <i class="uil-bed d-md-none d-block"></i>
                                        <span class="d-none d-md-block">Accomodation</span>
                                    </a>
                                </li>
                            @endif
                            
                            @if($services[0] == '1' || $services[0] == 'flights_tab')
                                <li class="nav-item flights_tab">
                                    <a href="#settings1" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                       <i class="uil-plane-fly d-md-none d-block"></i>
                                        <span class="d-none d-md-block">Flights Details</span>
                                    </a>
                                </li>
                            @else
                                <li class="nav-item flights_tab" style="display:none;">
                                    <a href="#settings1" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                       <i class="uil-plane-fly d-md-none d-block"></i>
                                        <span class="d-none d-md-block">Flights Details</span>
                                    </a>
                                </li>
                            @endif
                            
                            @if($services[0] == '1' || $services[0] == 'visa_tab')
                                <li class="nav-item visa_tab">
                                    <a href="#visa_details" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                       <i class="mdi mdi-passport d-md-none d-block"></i>
                                        <span class="d-none d-md-block">Visa Details</span>
                                    </a>
                                </li>
                            @else
                                <li class="nav-item visa_tab" style="display:none;">
                                    <a href="#visa_details" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                       <i class="mdi mdi-passport d-md-none d-block"></i>
                                        <span class="d-none d-md-block">Visa Details</span>
                                    </a>
                                </li>
                            @endif
                            
                            @if($services[0] == '1' || $services[0] == 'transportation_tab')
                                <li class="nav-item transportation_tab">
                                    <a href="#trans_details_1" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                       <i class="uil-bus d-md-none d-block"></i>
                                        <span class="d-none d-md-block">Transportation</span>
                                    </a>
                                </li>
                            @else
                                <li class="nav-item transportation_tab" style="display:none;">
                                    <a href="#trans_details_1" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                       <i class="uil-bus d-md-none d-block"></i>
                                        <span class="d-none d-md-block">Transportation</span>
                                    </a>
                                </li>
                            @endif
                              
                            <li class="nav-item" style="display:none;">
                                <a  href="#Itinerary_details" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                   <i class="uil-globe d-md-none d-block"></i>
                                    <span class="d-none d-md-block">Itinerary</span>
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a href="#Extras_details" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                  <i class="uil-moneybag d-md-none d-block"></i>
                                    <span class="d-none d-md-block">Costing</span>
                                </a>
                            </li>
                            
                        @endif
                    </ul>
                    
                    <div class="tab-content">

                        <div class="tab-pane  show active" id="home1">
                            <div class="row"> 
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label simpleinput">Services</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Enter the package name">
                                            </i>
                                        </div>
                                        <!--<input type="text" id="simpleinput" name="title" class="form-control titleP" >-->
                                            @if(isset($get_invoice->services) && $get_invoice->services != null && $get_invoice->services != '')
                                                <?php $services = json_decode($get_invoice->services); //dd($services[0]); ?>
                                            @endif
                                            <select class="form-control  external_packages" onchange="selectServices()" data-toggle="select2" multiple="multiple" id="select_services" name="services[]">
                                                <option value="{{ $services[0] }}" selected>{{ $services[0] }}</option>
                                            </select>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label simpleinput">Select Agent</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select the Agent Name">
                                            </i>
                                        </div>
                                        <select class="form-control" id="agent_Company_Name" name="agent_Company_Name">
                                           <option value="">Choose...</option>
                                            @if(isset($Agents_detail) && $Agents_detail !== null && $Agents_detail !== '')
                                                @foreach($Agents_detail as $Agents_details)
                                                    <option <?php if($get_invoice->agent_Id == $Agents_details->id) echo "selected" ?>  attr-AN="{{ $Agents_details->agent_Name }}" attr-Id="{{ $Agents_details->id }}" value="{{ $Agents_details->company_name }}">{{ $Agents_details->company_name }}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                
                                 <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label simpleinput">Select Customer</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select the Agent Name">
                                            </i>
                                        </div>
                                        <select class="form-control" id="customer_name" name="customer_name">
                                           <option value="-1">Choose...</option>
                                            @if(isset($customers_data) && $customers_data !== null && $customers_data !== '')
                                                @foreach($customers_data as $customers_res)
                                                    <option attr-cusData='{{ json_encode($customers_res) }}' attr-Id="{{ $customers_res->id }}" <?php if($get_invoice->booking_customer_id == $customers_res->id) echo "selected" ?> value="{{ $customers_res->id }}">{{ $customers_res->name }}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                
                                <input type="hidden" id="agent_Id" name="agent_Id" class="form-control" value="{{ $get_invoice->agent_Id ?? '' }}">
                                
                                <input type="hidden" id="agent_Name" name="agent_Name" class="form-control" value="{{ $get_invoice->agent_Name ?? '' }}">
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="" class="form-label">Currency Symbol</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Currency Symbol will be auto-selected for your account">
                                            </i>
                                        </div>
                                        <select name="currency_symbol" class="form-control currency_symbol">
                                            @foreach($all_curr_symboles as $all_curr_symbolesS)
                                                <option <?php if($all_curr_symbolesS->currency_symbol == $get_invoice->currency_symbol) echo 'selected'; ?> value="{{ $all_curr_symbolesS->currency_symbol }}">{{ $all_curr_symbolesS->currency_symbol }}</option>
                                            @endforeach
                                        </select>
                                        <input readonly value="{{ $get_invoice->currency_symbol ?? '' }}" name="" class="form-control currency_symbol" hidden>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label no_of_pax_days">No Of Pax</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="No Of Pax for this package">
                                            </i>
                                        </div>
                                        <!--<input type="text" id="no_of_pax_days" name="no_of_pax_days" class="form-control no_of_pax_days">-->
                                        <input type="number" name="no_of_pax_days" value="{{ $get_invoice->no_of_pax_days ?? '1' }}" min="1" class="form-control no_of_pax_days" id="no_of_pax_days" required>
                                        <input type="number" id="no_of_pax_prev" hidden value="1">
                                        <div class="invalid-feedback">
                                            This Field is Required
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                <div class="mb-3">
                                    <div id="tooltip-container">
                                        <label for="simpleinput" class="form-label">Currency Conversion</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                            data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Currency Convirsion">
                                        </i>
                                    </div>
                                    
                                            <?php //dd($mange_currencies); ?>
                                            
                                            <select class="form-control CC_id_store" name="currency_conversion" id="currency_conversion1">
                                                <option value="0">Select Currency Conversion</option>
                                                @foreach($mange_currencies as $mange_currencies)
                                                    <option attr_id="{{$mange_currencies->id}}" <?php if($get_invoice->currency_conversion == $mange_currencies->purchase_currency .' '.'TO'.' '. $mange_currencies->sale_currency) echo 'selected' ?> attr_conversion_type="{{$mange_currencies->conversion_type}}" value="{{$mange_currencies->purchase_currency}} TO {{$mange_currencies->sale_currency}}">{{$mange_currencies->purchase_currency}} TO {{$mange_currencies->sale_currency}}</option>
                                                @endforeach
                                            </select>
                                            <input type="hidden" id="conversion_type_Id"  name="conversion_type_Id" value="{{ $get_invoice->conversion_type_Id ?? '' }}">
                                            <input type="hidden" id="select_exchange_type"  name="conversion_type" value="" > 
                                </div>
                                </div>
                                
                                <div class="col-xl-12">
                                    <div class="mb-3">
                                        <h6>Lead Passenger Detials</h6>
                                        <div class="row" style="border: 1px solid #ebebeb;padding: 1rem;border-radius: 6px;">
                                            <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label">First Name</label>
                                                    <input type="text" name="lead_fname" class="form-control" required value="{{$get_invoice->f_name}}" id="lead_fnameI">
                                                </div>
                                            </div>
                                            
                                             <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label">Last Name</label>
                                                    <input type="text" name="lead_lname" class="form-control" required value="{{$get_invoice->middle_name}}" id="lead_lnameI">
                                                </div>
                                            </div>
                                            
                                             <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label">Email</label>
                                                    <input type="text" name="email" class="form-control" required value="{{$get_invoice->email}}" id="lead_emailI">
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label">Contact Number</label>
                                                    <input type="text" name="mobile" class="form-control" required value="{{$get_invoice->mobile}}" id="lead_mobileI">
                                                </div>
                                            </div>
                                                    
                                            <div class="col-xl-4">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label">Select Nationality</label>
                                                     <select type="text" class="form-control select2 " name="nationality"  data-placeholder="Choose ...">
                                                        @foreach($all_countries as $country_res)
                                                            <option <?php if($get_invoice->country == $country_res->id) echo "selected" ?> value="{{$country_res->id}}" id="categoriesPV" required>{{$country_res->name}}</option>
                                                           
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-2" >
                                                <div class="mb-3">
                                                     <p style="margin-top: 2.2rem;">Gender</p>
                                                </div>
                                            </div>
                                            
                                               
                                            <div class="col-2">
                                              <div class="form-check" style="margin-top: 2.2rem;">
                                              <input class="form-check-input" type="radio" name="gender" <?php if($get_invoice->gender == 'male') echo "checked" ?> value="male"  id="flexRadioDefault3">
                                              <label class="form-check-label" for="flexRadioDefault3">
                                                Male
                                              </label>
                                            </div>
                                            
                                            </div>
                                            <div class="col-2" style="margin-top: 2.2rem;">
                                                <div class="form-check">
                                              <input class="form-check-input" type="radio" name="gender" <?php if($get_invoice->gender == 'female') echo "checked" ?> value="female"  id="flexRadioDefault4">
                                              <label class="form-check-label" for="flexRadioDefault4">
                                                Female
                                              </label>
                                            </div>
                                            
                                            </div>
                                            
                                           
                                            
                                        </div>
                                        
                                        
                                        <div id="other_passengers">
                                            
                                            
                                        </div>
                                        
                                    </div>
                                </div>
                                
                                <div class="col-xl-12 d-none">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label">Content</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Additional Information of Package">
                                            </i>
                                        </div>
                                        <!--<textarea name="content" id="" class="contentP summernote" cols="142" rows="10"></textarea>-->
                                        <textarea name="content" class="contentP" cols="135" rows="5"></textarea>
                                    </div>
                                </div>
                                
                                @if(isset($get_invoice->services) && $get_invoice->services != null && $get_invoice->services != '')
                                    <?php $services = json_decode($get_invoice->services); //dd($services[0]); ?>
                                    @if($services[0] == 'visa_tab')
                                        <div class="col-xl-4 d-none">
                                            <div class="mb-3">
                                                <div id="tooltip-container">
                                                    <label for="simpleinput" class="form-label start_date">Start Date</label>
                                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                        data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select start date of package">
                                                    </i>
                                                </div>
                                                
                                                <input type="" name="start_date" class="form-control date start_date" value="{{$get_invoice->start_date}}" id="start_date" required placeholder="yyyy/mm/dd" readonly>
                                                <div class="invalid-feedback">
                                                    This Field is Required
                                                </div>
                                            </div>
                                         </div>
                                        
                                        <div class="col-xl-4 d-none">
                                            <div class="mb-3">
                                                
                                                <div id="tooltip-container">
                                                    <label for="simpleinput" class="form-label end_date">End Date</label>
                                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                        data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select end date of package">
                                                    </i>
                                                </div>
                                                <input type="" name="end_date" class="form-control date end_date" value="{{$get_invoice->end_date}}" id="end_date" required placeholder="yyyy/mm/dd" readonly>
                                                <div class="invalid-feedback">
                                                    This Field is Required
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-4 d-none">
                                             <div class="mb-3">
                                                <!--<div id="tooltip-container">-->
                                                    @if(isset($get_invoice->services) && $get_invoice->services != null && $get_invoice->services != '')
                                                        <?php $services = json_decode($get_invoice->services); //dd($services[0]); ?>
                                                        @if($services[0] == '1' || $services[0] == 'accomodation_tab')
                                                            <label for="simpleinput" class="form-label no_of_Nights_Other">No Of Nights</label>
                                                        @else
                                                            <label for="simpleinput" class="form-label no_of_Nights_Other">Total Duration</label>
                                                        @endif
                                                    @endif
                                                    <!--<i class="dripicons-information" style="font-size: 17px;" id="title_Icon"-->
                                                        <!--data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="No Of Pax Info">-->
                                                    <!--</i>-->
                                                <!--</div>-->
                                              
                                              <input readonly type="text" name="time_duration" id="duration" value="{{$get_invoice->time_duration}}" class="form-control time_duration" >
                                             </div>
                                          </div>
                                    @else
                                        <div class="col-xl-4">
                                            <div class="mb-3">
                                                <div id="tooltip-container">
                                                    <label for="simpleinput" class="form-label start_date">Start Date</label>
                                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                        data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select start date of package">
                                                    </i>
                                                </div>
                                                
                                                <input type="" name="start_date" class="form-control date start_date" value="{{$get_invoice->start_date}}" id="start_date" required placeholder="yyyy/mm/dd" readonly>
                                                <div class="invalid-feedback">
                                                    This Field is Required
                                                </div>
                                            </div>
                                         </div>
                                        
                                        <div class="col-xl-4">
                                            <div class="mb-3">
                                                
                                                <div id="tooltip-container">
                                                    <label for="simpleinput" class="form-label end_date">End Date</label>
                                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                        data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select end date of package">
                                                    </i>
                                                </div>
                                                <input type="" name="end_date" class="form-control date end_date" value="{{$get_invoice->end_date}}" id="end_date" required placeholder="yyyy/mm/dd" readonly>
                                                <div class="invalid-feedback">
                                                    This Field is Required
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-4">
                                             <div class="mb-3">
                                                <!--<div id="tooltip-container">-->
                                                    @if(isset($get_invoice->services) && $get_invoice->services != null && $get_invoice->services != '')
                                                        <?php $services = json_decode($get_invoice->services); //dd($services[0]); ?>
                                                        @if($services[0] == '1' || $services[0] == 'accomodation_tab')
                                                            <label for="simpleinput" class="form-label no_of_Nights_Other">No Of Nights</label>
                                                        @else
                                                            <label for="simpleinput" class="form-label no_of_Nights_Other">Total Duration</label>
                                                        @endif
                                                    @endif
                                                    <!--<i class="dripicons-information" style="font-size: 17px;" id="title_Icon"-->
                                                        <!--data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="No Of Pax Info">-->
                                                    <!--</i>-->
                                                <!--</div>-->
                                              
                                              <input readonly type="text" name="time_duration" id="duration" value="{{$get_invoice->time_duration}}" class="form-control time_duration" >
                                             </div>
                                          </div>
                                    @endif
                                @endif
                                 
                                <div class="col-xl-4 d-none" >
                                        <div class="mb-3">
                                            <div>
                                                <div id="tooltip-container">
                                                    <label for="categoriesPV">Categories</label>
                                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                        data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select package Category">
                                                    </i>
                                                
                                                
                                                    <span title="Add Categories" class="input-group-btn input-group-append" style="float: right;margin-bottom:10px">
                                                        <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#add-Categories-modal" type="button">+</button>
                                                    </span>
                                            
                                                    <select type="text" class="form-control select2 categories" name="categories"  data-placeholder="Choose ...">
                                                        @foreach($categories as $categories)
                                                            <option value="{{$categories->id}}" id="categoriesPV" required>{{$categories->title}}</option>
                                                            <div class="invalid-feedback">
                                                                This Field is Required
                                                            </div>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                <div class="col-xl-4 d-none">
                                    <div class="mb-3">
                                        <div>
                                            <div id="tooltip-container">
                                                <label for="simpleinput" class="form-label">Tour Featured </label>
                                                <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                    data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Display your package on Home Page">
                                                </i>
                                            </div>
                                            <select name="tour_feature" id="" class="form-control tour_feature" style="margin-top: 18px">
                                                <option value="">Select Featured</option>
                                                <option value="0">Enable featured</option>
                                                <option value="1">Disable featured</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4 d-none">
                                    <div class="mb-3">
                                        <div>
                                            <!--<div id="tooltip-container">-->
                                                <label for="simpleinput" class="form-label">Default State</label>
                                                <!--<i class="dripicons-information" style="font-size: 17px;" id="title_Icon"-->
                                                    <!--data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="No Of Pax Info">-->
                                                <!--</i>-->
                                            <!--</div>-->
                                            <select name="defalut_state" id="" class="form-control defalut_state" style="margin-top: 18px">
                                                <option value="">Select Default State</option>
                                                <option value="0">Always available</option>
                                                <option value="1">Only available on specific dates</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                  
                                <div class="col-xl-6 d-none">
                                   <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label">Banner Image</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Upload your detail page image for Package (Image size should be 'Width:1600px' 'Height:300px')">
                                            </i>
                                        </div>
                                        <input type="file" id="simpleinput" name="tour_featured_image" class="form-control tour_featured_imageP">
                                    </div>
                                </div>
                                
                                <div class="col-xl-6 d-none">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label">Featured Image</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Upload your main image for Package">
                                            </i>
                                        </div>
                                        <input type="file" id="simpleinput" name="tour_banner_image" class="form-control tour_banner_imageP">
                                    </div>
                                </div>
                                
                                <div class="col-xl-3">
                                    <div class="mb-3">
                                        <!--<div id="tooltip-container">-->
                                            <label for="simpleinput" class="form-label">Author</label>
                                            <!--<i class="dripicons-information" style="font-size: 17px;" id="title_Icon"-->
                                                <!--data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="No Of Pax Info">-->
                                            <!--</i>-->
                                        <!--</div>-->
                                      
                                      <select name="tour_author" id="" class="form-control tour_author">
                                      <option value="">Select Author</option>
                                          <option <?php if($get_invoice->tour_author == 'admin') echo "selected" ?>  value="admin">admin</option>
                                          <option <?php if($get_invoice->tour_author == 'admin1') echo "selected" ?> value="admin1">admin1</option>
                                      </select>
                                  </div>
                                  </div>
                                
                                @if(isset($get_invoice->services) && $get_invoice->services != null && $get_invoice->services != '')
                                    <?php $services = json_decode($get_invoice->services); ?>
                                    @if($services[0] == '1' || $services[0] == 'accomodation_tab')  
                                        <div class="col-xl-3 more_Div_Acc_All" style="display:none">
                                            <div class="mb-3">
                                                <!--<div id="tooltip-container">-->
                                                    <label for="simpleinput" class="form-label">Option Date</label>
                                                   
                                               <input type="date" id="option_date" value="{{$get_invoice->option_date}}" name="option_date" class="form-control ">
                                              
                                          </div>
                                        </div>
                                        
                                        <div class="col-xl-3 more_Div_Acc_All" style="display:none">
                                            <div class="mb-3">
                                               
                                                    <label for="simpleinput" class="form-label">Reservation Number</label>
                                                    
                                              
                                              <input type="text" id="reservation_number" value="{{$get_invoice->reservation_number}}" name="reservation_number" class="form-control ">
                                          </div>
                                        </div>
                                        
                                        <div class="col-xl-3 more_Div_Acc_All" style="display:none">
                                            <div class="mb-3">
                                                
                                                    <label for="simpleinput" class="form-label">Hotel Reservation Number</label>
                                                   
                                              
                                              <input type="text" id="hotel_reservation_number" value="{{$get_invoice->hotel_reservation_number}}" name="hotel_reservation_number" class="form-control ">
                                          </div>
                                        </div>
                                    @endif
                                @endif
                                  
                                <div class="col-xl-8 d-none">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label">Gallery Images</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Upload at least 10 images">
                                            </i>
                                        </div>
                                        <div>
                                            <?php $img_c = 1; ?>
                                	        <input type="file" id="" name="gallery_images[]" class="form-control gallery_imagesP{{ $img_c }}" onchange="validate1({{ $img_c }})">
                                	        <span class="file_error{{ $img_c }}"></span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div id="more_img d-none"></div>
                                        
                                <div class="mt-2 d-none" style="" id="">
                                    <a href="javascript:;" id="more_images" class="btn btn-info" style="float: right;">Add Gallery Images</a>
                                </div>
                                    
                            </div>
                            <!--<a id="save_Package" type="submit" class="btn btn-primary" name="submit">Save Package Deatils</a>-->    
                        </div>

                        <div class="tab-pane" id="profile1">
                            @if(!isset($get_invoice->destination_details))
                                <div class="row">
                                    
                                    <div class="col-xl-12">
                                        <div class="row">                                                 
                                            <div class="col-xl-1">
                                               <div class="mb-3">
                                                    <input type="checkbox" id="destination" data-switch="bool"/>
                                                    <label for="destination" data-on-label="On" data-off-label="Off"></label>
                                                </div>
                                            </div>
                                            <div class="col-xl-3">
                                                Destination
                                                <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Select Country & City"></i>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row" id="select_destination">
                                        <div class="col-xl-6">
                                            <label for="">COUNTRY</label>
                                            <select name="destination_country" onchange="selectCities()" id="property_countryI" class="form-control">
                                                @foreach($all_countries as $country_res)
                                                    <option value="{{ $country_res->id }}">{{ $country_res->name}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        
                                        <div class="col-xl-6">
                                            <label for="">How Many Hotel You Want To Add?</label>
                                            <input type="number" name="city_Count" value="" id="city_No" class="form-control" placeholder="Select...">
                                        </div>
                                        
                                        <div class="col-xl-6" style="display:none">
                                            <input type="hidden" name="tour_location_city" id="tour_location_city1" value="{{ $get_invoice->tour_location  ?? '' }}"/>
                                            <input type="hidden" name="tour_location_city_else" id="tour_location_city_else" value="{{ $get_invoice->tour_location  ?? '' }}"/>
                                        </div>
                                        
                                        <div id="append_destination"></div>
                                    </div>
                                </div>
                            @else
                                <div class="row">
                                    
                                    <div class="col-xl-12 d-none">
                                        <div class="row">                                                 
                                            <div class="col-xl-1">
                                               <div class="mb-3">
                                                    <input type="checkbox" id="destination" data-switch="bool"/>
                                                    <label for="destination" data-on-label="On" data-off-label="Off"></label>
                                                </div>
                                            </div>
                                            <div class="col-xl-3">
                                                Destination
                                                <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Select Country & City"></i>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <?php
                                        $destination_details=$get_invoice->destination_details;
                                        $destination_details=json_decode($destination_details);
                                        $destination_details=$destination_details->destination_country;
                                    ?>
                                    
                                    @if(isset($get_invoice->destination_details))
                                        <div class="row"  id="select_destination">
                                            <div class="col-xl-6">
                                                <label for="">COUNTRY</label>
                                                <select name="destination_country" onchange="selectCitiesI()" id="property_countryI" class="form-control">
                                                    @foreach($all_countries as $country_res)
                                                        <option <?php if($destination_details == $country_res->id) echo "selected" ?>  value="{{ $country_res->id }}">{{ $country_res->name}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            
                                            <div class="col-xl-6">
                                                <label for="">How Many Hotel You Want To Add?</label>
                                                <input type="number" name="city_Count" value="{{$get_invoice->city_Count ?? ''}}" id="city_No" class="form-control" placeholder="Select...">
                                            </div>
                                            
                                            <div class="col-xl-6" style="display:none">
                                                <input type="hidden" name="tour_location_city" id="tour_location_city1" value="{{ $get_invoice->tour_location  ?? '' }}"/>
                                                <input type="hidden" name="tour_location_city_else" id="tour_location_city_else" value="{{ $get_invoice->tour_location  ?? '' }}"/>
                                            </div>
                                            <input type="hidden" name="packages_get_city" id="packages_get_city" value="{{ $get_invoice->tour_location  ?? '' }}" />
                                            
                                            <div id="append_destination"></div>
                                        </div>
                                    @endif
                                </div>
                            @endif
                            
                            <div class="row">
                                <div class="col-xl-12 mt-2">
                                    <div class="mb-3">
                                        <div class="row"></div>
                                    </div>
                                </div>
                            
                                <?php
                                    $accomodation_details=$get_invoice->accomodation_details;
                                    $accomodation_details=json_decode($accomodation_details);
                                    //print_r($accomodation_details);die();
                                ?>
                                @if(isset($get_invoice->accomodation_details) && $get_invoice->accomodation_details != null && $get_invoice->accomodation_details != '')
                                    <?php $i = 1; ?>
                                    <?php $img_Counter = 0; ?>
                                    <?php $divId = 1; ?>
                                    <?php $del_counter = 1; ?>
                                    <?php $del_acc_city = 1; ?>
                                    <div id="append_accomodation">
                                        <?php
                                            $count_hotel=1;
                                            foreach($accomodation_details as $details)
                                            {
                                        ?>
                                                <div class="mb-2" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;" id="del_hotelI{{ $i }}">
                                                    <h4>
                                                        City #{{$i}} ({{$details->hotel_city_name}})
                                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon_${i}"
                                                            data-bs-toggle="tooltip" data-bs-placement="right" title="Fill all the information of City {{$details->hotel_city_name}}">
                                                        </i>
                                                    </h4> 
                                                    <div class="row">
                                                        
                                                        <div class="col-xl-3">
                                                            <label for="">Check In</label>
                                                            <input type="date" value="{{$details->acc_check_in}}" id="makkah_accomodation_check_in_{{$i}}" name="acc_check_in[]" onchange="makkah_accomodation_check_inI({{$i}})" class="form-control date makkah_accomodation_check_in_class_{{$i}} check_in_hotel_{{ $i }}">
                                                        </div>
                                                            
                                                        <div class="col-xl-3">
                                                            <label for="">Check Out</label>
                                                            <input type="date" value="{{$details->acc_check_out}}" id="makkah_accomodation_check_out_date_{{$i}}" name="acc_check_out[]" onchange="makkah_accomodation_check_outI({{$i}})" class="form-control date makkah_accomodation_check_out_date_class_{{$i}} check_out_hotel_{{ $i }}">
                                                        </div>
                                                        
                                                        <div class="col-xl-3">
                                                            <label for="">City Name</label>
                                                            <input readonly value="{{ $details->hotel_city_name ?? ''}}" type="text" name="hotel_city_name[]" class="form-control property_city_newInput_I property_city_new_{{ $i }}"/>
                                                            <select type="text" id="property_city_new{{ $i }}" onchange="put_tour_locationI({{ $i }})" name="hotel_city_name[]" class="form-control property_city_new_selectI" style="display:none"/></select>
                                                        </div>
                                                        
                                                        <div class="col-xl-3">
                                                            <label for="">Hotel Name</label>
                                                            
                                                            <input type="text" id="switch_hotel_name{{ $i }}" name="switch_hotel_name[]" value="1" style="display:none">
                                                            
                                                            <div class="input-group" id="add_hotel_div{{ $i }}">
                                                                <input type="text" onkeyup="hotel_funI({{ $i }})" value="{{$details->acc_hotel_name}}" id="acc_hotel_name_{{ $i }}" name="acc_hotel_name[]" class="form-control acc_hotel_name_class_{{ $i }}">
                                                            </div>
                                                            <a style="float: right;font-size: 10px;width: 102px;" onclick="select_hotel_btn({{ $i }})" class="btn btn-primary select_hotel_btn{{ $i }}">
                                                                SELECT HOTEL
                                                            </a>
                                                            
                                                            <div class="input-group" id="select_hotel_div{{ $i }}" style="display:none">
                                                                <select onchange="get_room_types({{ $i }})" id="acc_hotel_name_{{ $i }}" name="acc_hotel_name_select[]" class="form-control acc_hotel_name_class_{{ $i }} get_room_types_{{ $i }}">
                                                                    <option></option>
                                                                </select>
                                                            </div>
                                                            <a style="display:none;float: right;font-size: 10px;width: 102px;" onclick="add_hotel_btn({{ $i }})" class="btn btn-primary add_hotel_btn{{ $i }}">
                                                                ADD HOTEL
                                                            </a>
                                                        </div>
                                                        
                                                        <div class="col-xl-3">
                                                            <label for="">No Of Nights</label>
                                                            <input readonly type="text" value="{{$details->acc_no_of_nightst}}" id="acomodation_nights_{{$i}}" name="acc_no_of_nightst[]" class="form-control acomodation_nights_class_{{$i}}">
                                                        </div>
                                                        <!--app/resources/views/template/frontend/userdashboard/pages/manageoffie/create_invoice?-->
                                                        <div class="col-xl-3">
                                                            <label>Room Type</label>
                                                            <input type="hidden" value="1" id="switch_htfI_{{ $i }}">
                                                            <div class="input-group hotel_type_add_div_{{ $i }}">
                                                                <select onclick="hotel_type_funI({{ $i }})" name="acc_type[]" id="hotel_type_{{ $i }}" class="form-control other_Hotel_Type hotel_type_class_{{ $i }}" data-placeholder="Choose ...">
                                                                    @if($details->acc_type == 'Quad')
                                                                        <option selected attr="4" value="Quad">Quad</option>
                                                                    @elseif($details->acc_type == 'Triple')
                                                                        <option selected attr="3" value="Triple">Triple</option>
                                                                    @elseif($details->acc_type == 'Double')
                                                                        <option selected attr="2" value="Double">Double</option>
                                                                    @else
                                                                        <option attr="" value=""></option>
                                                                    @endif
                                                                </select>
                                                            </div>
                                                            
                                                            <div class="input-group hotel_type_select_div_{{ $i }}" style="display:none">
                                                                <select onchange="hotel_type_funInvoice({{ $i }})" name="acc_type_select[]" id="hotel_type_{{ $i }}" class="form-control other_Hotel_Type hotel_type_class_{{ $i }} hotel_type_select_class_{{ $i }}" data-placeholder="Choose ...">
                                                                    <option value="">Choose ...</option>
                                                                </select>
                                                            </div>
                                                            
                                                        </div>
                                                        
                                                        <div class="col-xl-3">
                                                            <label for="">Quantity</label>
                                                            <input value="{{$details->acc_qty}}" type="text" id="simpleinput" name="acc_qty[]" class="form-control acc_qty_class_{{ $i }}" onkeyup="acc_qty_classI({{ $i }})">
                                                            <div class="row" style="padding: 2px;">
                                                                <div class="col-lg-6">
                                                                    <a style="display: none;font-size: 10px;" class="btn btn-success" id="room_quantity_{{ $i }}"></a>
                                                                    <input type="hidden" class="room_quantity_{{ $i }}">
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <a style="display: none;font-size: 10px;" class="btn btn-primary" id="room_available_{{ $i }}"></a>
                                                                    <input type="hidden" class="room_available_{{ $i }}">
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="row" style="padding: 2px;">
                                                                <div class="col-lg-6">
                                                                    <a style="display: none;font-size: 10px;" class="btn btn-info" id="room_booked_quantity_{{ $i }}"></a>
                                                                    <input type="hidden" class="room_booked_quantity_{{ $i }}">
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <a style="display: none;font-size: 10px;" class="btn btn-danger" id="room_over_booked_quantity_{{ $i }}"></a>
                                                                    <input type="hidden" class="room_over_booked_quantity_{{ $i }}">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-xl-3">
                                                            <label for="">Pax</label>
                                                            <input type="text" id="simpleinput" value="{{$details->acc_pax}}" name="acc_pax[]" class="form-control acc_pax_class_{{$i}}" readonly>
                                                        </div>
                                                        
                                                        <div class="col-xl-3">
                                                            <?php
                                                                $hotel_meal_type=$details->hotel_meal_type;
                                                            ?>
                                                            <label for="">Meal Type</label>
                                                            <select name="hotel_meal_type[]" id="hotel_meal_type_{{$i}}" class="form-control hotel_meal_types" data-placeholder="Choose ...">
                                                                <option <?php if($hotel_meal_type == 'Room only') echo 'selected'; ?> value="Room only">Room only</option>
                                                                <option <?php if($hotel_meal_type == 'Breakfast') echo 'selected'; ?> value="Breakfast">Breakfast</option>
                                                                <option <?php if($hotel_meal_type == 'Lunch') echo 'selected'; ?> value="Lunch">Lunch</option>
                                                                <option <?php if($hotel_meal_type == 'Dinner') echo 'selected'; ?> value="Dinner">Dinner</option>
                                                             </select>
                                                        </div>
                                                        
                                                        <div id="hotel_price_for_week_end_{{ $i }}" class="row"></div>
                                                        
                                                        <h4 class="mt-4">Purchase Price</h4>
                                                        
                                                        <input type="hidden" id="hotel_invoice_markup_{{ $i }}" name="hotel_invoice_markup[]" value="{{ $details->hotel_invoice_markup ?? '' }}">
                                                        
                                                        <input type="hidden" id="hotel_supplier_id_{{ $i }}" name="hotel_supplier_id[]" value="{{ $details->hotel_supplier_id ?? '' }}">
                                        
                                                        <input type="hidden" id="hotel_type_id_{{ $i }}" name="hotel_type_id[]" value="{{ $details->hotel_type_id ?? '' }}">
                                                        
                                                        <input type="hidden" id="hotel_type_cat_{{ $i }}" name="hotel_type_cat[]" value="{{ $details->hotel_type_cat ?? '' }}">
                                                        
                                                        <input type="hidden" id="hotelRoom_type_id_{{ $i }}" name="hotelRoom_type_id[]" value="{{ $details->hotelRoom_type_id ?? '' }}">
                                                        
                                                        <input type="hidden" id="hotelRoom_type_idM_{{ $i }}" name="hotelRoom_type_idM[]" value="{{ $details->hotelRoom_type_idM ?? '' }}">
                                                                            
                                                        <div class="col-xl-4">
                                                            <label for="">Price Per Room/Night</label>
                                                            <div class="input-group">
                                                                <span class="input-group-btn input-group-append">
                                                                    <a id="" class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                                                      
                                                                    </a>
                                                                </span>
                                                                <input type="text" id="makkah_acc_room_price_{{$i}}" onkeyup="makkah_acc_room_price_funsI({{$i}})" value="{{$details->price_per_room_purchase}}" name="price_per_room_purchase[]" class="form-control">
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-xl-4">
                                                            <label for="">Price Per Person/Night</label>
                                                            <div class="input-group">
                                                                <span class="input-group-btn input-group-append">
                                                                    <a id="" class="btn btn-primary bootstrap-touchspin-up currency_value2">
                                                                     
                                                                    </a>
                                                                </span>
                                                                <input type="text" id="makkah_acc_price_{{$i}}" onkeyup="makkah_acc_price_funs({{$i}})" value="{{$details->acc_price_purchase}}" name="acc_price_purchase[]" class="form-control makkah_acc_price_class_{{$i}}">
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-xl-4"><label for="">Total Amount/Room</label>
                                                            <div class="input-group">
                                                                <span class="input-group-btn input-group-append">
                                                                    <a id="" class="btn btn-primary bootstrap-touchspin-up currency_value3">
                                                                      
                                                                    </a>
                                                                </span>
                                                                <input readonly type="text"  id="makkah_acc_total_amount_{{$i}}" value="{{$details->acc_total_amount_purchase}}"  name="acc_total_amount_purchase[]" class="form-control makkah_acc_total_amount_class_{{$i}}">
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-xl-6">
                                                            <label for="">Exchange Rate</label>
                                                            <div class="input-group">
                                                                <span class="input-group-btn input-group-append">
                                                                    <a id="" class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                                                      
                                                                    </a>
                                                                </span>
                                                                <input type="text" id="exchange_rate_price_funs_{{$i}}" value="{{$details->exchange_rate_price}}" onkeyup="exchange_rate_price_funsI({{$i}})" value="" name="exchange_rate_price[]" class="form-control">
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-xl-6">
                                                        </div>
                                                                            
                                                        <h4 class="mt-4">Sale Price</h4>
                                                                            
                                                        <div class="col-xl-4">
                                                            <label for="">Price Per Room/Night</label>
                                                            <div class="input-group">
                                                                <span class="input-group-btn input-group-append">
                                                                    <a id="" class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                                                      
                                                                    </a>
                                                                </span>
                                                                <input type="text" id="price_per_room_exchange_rate_{{$i}}" value="{{$details->price_per_room_sale}}"  name="price_per_room_sale[]" class="form-control">
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-xl-4">
                                                        <label for="">Price Per Person/Night</label>
                                                        <div class="input-group">
                                                            <span class="input-group-btn input-group-append">
                                                                <a id="" class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2">
                                                                  
                                                                </a>
                                                            </span>
                                                            <input type="text" id="price_per_person_exchange_rate_{{$i}}" value="{{$details->acc_price}}"  name="acc_price[]" class="form-control makkah_acc_price_class_{{$i}}">
                                                        </div>
                                        
                                                        </div>
                                                        
                                                        <div class="col-xl-4"><label for="">Total Amount/Room</label>
                                                         <div class="input-group">
                                                            <span class="input-group-btn input-group-append">
                                                                <a id="" class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_3">
                                                                  
                                                                </a>
                                                            </span>
                                                            <input readonly type="text"  id="price_total_amout_exchange_rate_{{$i}}" value="{{$details->acc_total_amount}}" name="acc_total_amount[]" class="form-control">
                                                        </div>
                                                        </div>
                                                        
                                                        <input type="hidden" id="starting_acc{{ $del_acc_city }}" value="{{ $i }}">
                                                        
                                                        <div id="append_add_accomodation_{{$i}}">
                                                            
                                                            <?php
                                                                $accomodation_details_more=$get_invoice->accomodation_details_more;
                                                                $accomodation_details_more=json_decode($accomodation_details_more);
                                                                // dd($accomodation_details_more);
                                                            ?>
                                                            @if($get_invoice->accomodation_details_more != null)
                                                                <?php
                                                                    foreach($accomodation_details_more as $more_details)
                                                                    {
                                                                ?>
                                                                        @if(isset($more_details->more_hotel_city) && $more_details->more_hotel_city != null && $more_details->more_hotel_city != '')
                                                                            @if($details->hotel_city_name == $more_details->more_hotel_city)    
                                                                                <div id="click_delete_{{$divId}}" class="mb-2 mt-3" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;">
                                                                                    
                                                                                    <input readonly type="hidden" id="acc_nights1_{{$divId}}" value="{{$i}}" class="form-control">
                                                                                    <input type='hidden' name="more_hotel_city[]" value="{{$more_details->more_hotel_city}}" id="more_hotel_city{{$more_details->more_hotel_city}}" class="more_property_city_new_selectI"/>
                                                                                    
                                                                                    <div class="row" style="padding:20px;">
                                                                                        
                                                                                        <div class="col-xl-3">
                                                                                            <label for="">Check In</label>
                                                                                            <input type="date" value="{{ $more_details->more_acc_check_in }}" id="more_makkah_accomodation_check_in_{{ $divId }}" onchange="more_makkah_accomodation_check_in_class({{ $divId }})" name="more_acc_check_in[]" class="form-control more_date makkah_accomodation_check_in_class_{{ $divId }} more_check_in_hotel_{{ $divId }}">
                                                                                        </div>
                                                                                        
                                                                                        <div class="col-xl-3">
                                                                                            <label for="">Check Out</label>
                                                                                            <input type="date" value="{{ $more_details->more_acc_check_out }}" id="more_makkah_accomodation_check_out_date_{{ $divId }}"  name="more_acc_check_out[]" onchange="more_makkah_accomodation_check_out({{ $divId }})" class="form-control more_makkah_accomodation_check_out_date_class_{{ $divId }} more_check_out_hotel_${divId}">
                                                                                        </div>
                                                                                        
                                                                                        <div class="col-xl-3">
                                                                                            <label for="">Hotel Name</label>
                                                                                            
                                                                                            <input type="text" id="more_switch_hotel_name{{ $divId }}" name="more_switch_hotel_name[]" value="1" style="display:none" class="more_switch_hotel_name">
                                                                                            
                                                                                            <div class="input-group" id="more_add_hotel_div{{ $divId }}">
                                                                                                <input type="text" onkeyup="more_hotel_funI({{ $divId }})" value="{{ $more_details->more_acc_hotel_name }}" id="more_acc_hotel_name_{{ $divId }}" name="more_acc_hotel_name[]" class="form-control more_acc_hotel_name_class_{{ $divId }}">
                                                                                            </div>
                                                                                            <a style="float: right;font-size: 10px;width: 102px;" onclick="more_select_hotel_btn({{ $divId }})" class="btn btn-primary more_select_hotel_btn{{ $divId }}">
                                                                                                SELECT HOTEL
                                                                                            </a>
                                                                                            
                                                                                            <div class="input-group" id="more_select_hotel_div{{ $divId }}" style="display:none">
                                                                                                <select onchange="more_get_room_types({{ $divId }})" id="more_acc_hotel_name_select_{{ $divId }}" name="more_acc_hotel_name_select[]" class="form-control more_get_room_types_{{ $divId }}">
                                                                                                    <option attr_id="" value=""></option>
                                                                                                </select>
                                                                                            </div>
                                                                                            <a style="display:none;float: right;font-size: 10px;width: 102px;" onclick="more_add_hotel_btn({{ $divId }})" class="btn btn-primary more_add_hotel_btn{{ $divId }}">
                                                                                                ADD HOTEL
                                                                                            </a>
                                                                                        </div>
                                                                                        
                                                                                        <div class="col-xl-3"><label for="">No Of Nights</label>
                                                                                            <input readonly value="{{ $more_details->more_acc_no_of_nightst }}" type="text" id="more_acomodation_nights_{{ $divId }}" name="more_acc_no_of_nightst[]" class="form-control acomodation_nights_class_{{ $divId }}">
                                                                                        </div>
                                                                        
                                                                                        <input type='hidden' value="{{ $more_details->more_hotel_city }}" id="more_hotel_city{{ $divId }}" class="more_property_city_new_selectI"/>
                                                                                        
                                                                                        <div class="col-xl-3">
                                                                                            <label for="">Room Type</label>
                                                                                            <input type="hidden" value="1" id="more_switch_htfI_{{ $divId }}">
                                                                                            <div class="input-group more_hotel_type_add_div_{{ $divId }} more_hotel_type_add_div">
                                                                                                <select onclick="more_hotel_type_fun({{ $divId }})" name="more_acc_type[]" id="more_hotel_type_{{ $divId }}" class="form-control other_Hotel_Type more_hotel_type_class_{{ $divId }}" data-placeholder="Choose ...">
                                                                                                    @if($more_details->more_acc_type == 'Quad')
                                                                                                        <option selected attr="4" value="Quad">Quad</option>
                                                                                                    @elseif($more_details->more_acc_type == 'Triple')
                                                                                                        <option selected attr="3" value="Triple">Triple</option>
                                                                                                    @elseif($more_details->more_acc_type == 'Double')
                                                                                                        <option selected attr="2" value="Double">Double</option>
                                                                                                    @else
                                                                                                        <option attr="" value=""></option>
                                                                                                    @endif
                                                                                                </select>
                                                                                            </div>
                                                                                        
                                                                                            <div class="input-group more_hotel_type_select_div_{{ $divId }} more_hotel_type_select_div" style="display:none">
                                                                                                <select onchange="more_hotel_type_funInvoice({{ $divId }})" name="more_acc_type_select[]" id="more_hotel_type_select_{{ $divId }}" class="form-control other_Hotel_Type more_hotel_type_select_class_{{ $divId }}" data-placeholder="Choose ...">
                                                                                                    <option value="">Choose ...</option>
                                                                                                </select>
                                                                                            </div>
                                                                                        </div>
                                                                                    
                                                                                        <div class="col-xl-3">
                                                                                            <label for="">Quantity</label>
                                                                                            <input value="{{$more_details->more_acc_qty}}" onkeyup="more_acc_qty_classInvoice({{$divId}})" type="text" id="simpleinput" name="more_acc_qty[]" class="form-control more_acc_qty_class_{{$divId}}">
                                                                                            <div class="row" style="padding: 2px;">
                                                                                                <div class="col-lg-6">
                                                                                                    <a style="display: none;font-size: 10px;" class="btn btn-success" id="more_room_quantity_{{ $divId }}"></a>
                                                                                                    <input type="hidden" class="more_room_quantity_{{ $divId }}">
                                                                                                </div>
                                                                                                <div class="col-lg-6">
                                                                                                    <a style="display: none;font-size: 10px;" class="btn btn-primary" id="more_room_available_{{ $divId }}"></a>
                                                                                                    <input type="hidden" class="more_room_available_{{ $divId }}">
                                                                                                </div>
                                                                                            </div>
                                                                                            
                                                                                            <div class="row" style="padding: 2px;">
                                                                                                <div class="col-lg-6">
                                                                                                    <a style="display: none;font-size: 10px;" class="btn btn-info" id="more_room_booked_quantity_{{ $divId }}"></a>
                                                                                                    <input type="hidden" class="more_room_booked_quantity_{{ $divId }}">
                                                                                                </div>
                                                                                                <div class="col-lg-6">
                                                                                                    <a style="display: none;font-size: 10px;" class="btn btn-danger" id="more_room_over_booked_quantity_{{ $divId }}"></a>
                                                                                                    <input type="hidden" class="more_room_over_booked_quantity_{{ $divId }}">
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        
                                                                                        <div class="col-xl-3">
                                                                                            <label for="">Pax</label>
                                                                                            <input type="text" value="{{$more_details->more_acc_pax}}" id="more_acc_pax{{$divId}}" name="more_acc_pax[]" class="form-control more_acc_pax_class_{{$divId}}" readonly>
                                                                                        </div>
                                                                                        
                                                                                        <div class="col-xl-3">
                                                                                            <label for="">Meal Type</label>
                                                                                            <select name="more_hotel_meal_type[]" id="hotel_meal_type_{{$divId}}" class="form-control"  data-placeholder="Choose ...">
                                                                                                <option value="">Choose ...</option>
                                                                                                <option <?php if($more_details->more_hotel_meal_type == 'Room only') echo 'selected'; ?>  value="Room only">Room only</option>
                                                                                                <option <?php if($more_details->more_hotel_meal_type == 'Breakfast') echo 'selected'; ?> value="Breakfast">Breakfast</option>
                                                                                                <option <?php if($more_details->more_hotel_meal_type == 'Lunch') echo 'selected'; ?> value="Lunch">Lunch</option>
                                                                                                <option <?php if($more_details->more_hotel_meal_type == 'Dinner') echo 'selected'; ?> value="Dinner">Dinner</option>
                                                                                            </select>
                                                                                        </div>
                                                                                        
                                                                                        <div id="more_hotel_price_for_week_end_{{ $divId }}" class="row more_hotel_price_for_week_end"></div>
                                                                                        
                                                                                        <h4  class="mt-4">Purchase Price</h4>
                                                                                        
                                                                                        <input type="hidden" id="more_hotel_invoice_markup_{{ $divId }}" name="more_hotel_invoice_markup[]" value="{{ $more_details->more_hotel_invoice_markup ?? '' }}">
                                                                                        
                                                                                        <input type="hidden" id="more_hotel_supplier_id_{{ $divId }}" name="more_hotel_supplier_id[]" value="{{ $more_details->more_hotel_supplier_id ?? '' }}">
                            
                                                                                        <input type="hidden" id="more_hotel_type_id_{{ $divId }}" name="more_hotel_type_id[]" value="{{ $more_details->more_hotel_type_id ?? '' }}">
                                                                                                    
                                                                                        <input type="hidden" id="more_hotel_type_cat_{{ $divId }}" name="more_hotel_type_cat[]" value="{{ $more_details->more_hotel_type_cat ?? '' }}">
                                                                                        
                                                                                        <input type="hidden" id="more_hotelRoom_type_id_{{ $divId }}" name="more_hotelRoom_type_id[]" value="{{ $more_details->more_hotelRoom_type_id ?? '' }}">
                                                                                        
                                                                                        <input type="hidden" id="more_hotelRoom_type_idM_{{ $divId }}" name="more_hotelRoom_type_idM[]" value="{{ $more_details->more_hotelRoom_type_idM ?? '' }}">
                                                                                        
                                                                                        <div class="col-xl-4">
                                                                                            <label for="">Price Per Room/Night</label>
                                                                                            <div class="input-group">
                                                                                                <span class="input-group-btn input-group-append">
                                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                                                                                      
                                                                                                    </a>
                                                                                                </span>
                                                                                                <input type="text"  onkeyup="more_makkah_acc_room_price_funsI({{$divId}},{{$divId}})" value="{{$more_details->more_price_per_room_purchase}}" id="more_makkah_acc_room_price_funs_{{$divId}}" name="more_price_per_room_purchase[]" class="form-control">
                                                                                            </div>
                                                                                        </div>
                                                                                        
                                                                                        <div class="col-xl-4">
                                                                                            <label for="">Price Per Person/Night</label>
                                                                                            <div class="input-group">
                                                                                                <span class="input-group-btn input-group-append">
                                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                                                                                      
                                                                                                    </a>
                                                                                                </span>
                                                                                                <input type="text" onchange="more_acc_price({{$divId}})" id="more_acc_price_get_{{$divId}}" value="{{$more_details->more_acc_price_purchase}}" name="more_acc_price_purchase[]" class="form-control">
                                                                                            </div>
                                                                                        </div>
                                                                                        
                                                                                        <div class="col-xl-4" >
                                                                                            <label for="">Total Amount/Room</label>
                                                                                            <div class="input-group">
                                                                                                <span class="input-group-btn input-group-append">
                                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                                                                                       
                                                                                                    </a>
                                                                                                </span>
                                                                                                <input readonly type="text" id="more_acc_total_amount_{{$divId}}" value="{{$more_details->more_acc_total_amount_purchase}}" name="more_acc_total_amount_purchase[]" class="form-control">
                                                                                            </div>
                                                                                        </div>
                                                                                        
                                                                                        <div class="col-xl-6" >
                                                                                            <label for="">Exchange Rate</label>
                                                                                            <div class="input-group">
                                                                                                <span class="input-group-btn input-group-append">
                                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                                                                                       
                                                                                                    </a>
                                                                                                </span>
                                                                                                <input type="text" id="more_exchange_rate_price_funs_{{$divId}}" onkeyup="more_exchange_rate_price_funsI({{$divId}})" value="{{$more_details->more_exchange_rate_price}}" name="more_exchange_rate_price[]" class="form-control">
                                                                                            </div>
                                                                                        </div>
                                                                                        
                                                                                        <div class="col-xl-4"></div>
                                                                                        
                                                                                        <h4  class="mt-4">Sale Price</h4>
                                                                                        
                                                                                        <div class="col-xl-4" >
                                                                                            <label for="">Price Per Room/Night</label>
                                                                                            <div class="input-group">
                                                                                                <span class="input-group-btn input-group-append">
                                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                                                                </span>
                                                                                                <input type="text" id="more_price_per_room_exchange_rate_{{$divId}}" value="{{$more_details->more_price_per_room_sale}}" name="more_price_per_room_sale[]" class="form-control">
                                                                                            </div>
                                                                                        </div>
                                                                                        
                                                                                        <div class="col-xl-4">
                                                                                            <label for="">Price Per Person/Night5</label>
                                                                                            <div class="input-group">
                                                                                                <span class="input-group-btn input-group-append">
                                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                                                                </span>
                                                                                                <input type="text"  id="more_price_per_person_exchange_rate_{{$divId}}" value="{{$more_details->more_acc_price}}" name="more_acc_price[]" class="form-control">
                                                                                            </div>
                                                                                        </div>
                                                                                        
                                                                                        <div class="col-xl-4">
                                                                                            <label for="">Total Amount/Room</label>
                                                                                            <div class="input-group">
                                                                                                <span class="input-group-btn input-group-append">
                                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                                                                </span>
                                                                                                <input readonly type="text" id="more_price_total_amout_exchange_rate_{{$divId}}" value="{{$more_details->more_acc_total_amount}}" name="more_acc_total_amount[]" class="form-control">
                                                                                            </div>
                                                                                        </div>
                                                                                        
                                                                                        <div class="mt-2">
                                                                                            <a href="javascript:;" onclick="deleteRowaccI({{ $divId }})"  id="{{ $divId }}" class="btn btn-info" style="float: right;">Delete </a>
                                                                                        </div>
                                                                                    
                                                                                    </div>
                                                                                </div>
                                                                                <?php $divId++; ?>
                                                                            @endif
                                                                        @endif
                                                                <?php
                                                                    }
                                                                ?>
                                                            @endif
                                                            <input type="hidden" id="ending_acc{{ $del_acc_city }}" value="{{ $divId }}">
                                                            
                                                            <input type="hidden" id="divId_m_a_e_i" value="{{ $i }}">
                                                            
                                                        </div>
                                                        
                                                        <div class="mt-2">
                                                            <a href="javascript:;" onclick="add_more_accomodation_Invoice({{ $i }})" class="btn btn-info" style="float: right;"> + Add More </a>
                                                        </div>
                                                        
                                                        <div class="col-xl-12">
                                                            <div class="mb-3">
                                                                <label for="simpleinput" class="form-label">Room Amenities</label>
                                                                <textarea name="hotel_whats_included[]" class="form-control" value="{{ $details->hotel_whats_included }}" id="" cols="10" rows="0">{{ $details->hotel_whats_included }}</textarea>
                                                            </div>
                                                        </div>
                                                        
                                                        <?php
                                                            $accomodation_image = $details->accomodation_image;
                                                            $accomodation_image_encode = json_encode($details->accomodation_image);
                                                            
                                                            if(!is_array($accomodation_image)){
                                                                $accomodation_image = array($accomodation_image);
                                                            }else{
                                                                $accomodation_image = $details->accomodation_image;
                                                            }
                                                        ?>
                                                        
                                                        <div class="col-xl-12">
                                                            <label for="">Image</label>
                                                            <input multiple type="file" name="accomodation_image{{ $img_Counter }}[]" class="form-control">
                                                            <div class="row" style="padding:5px">
                                                                @if(isset($accomodation_image) || $accomodation_image !== null || $accomodation_image !== "")
                                                                    @foreach($accomodation_image as $value1)
                                                                        <div class="col-md-3" id="accImg<?php echo $del_counter; ?>" style="text-align: center;margin-bottom: 10px;">
                                                                            <img src="{{ asset('/public/uploads/package_imgs/'.$value1) }}" style="width:233px;height:150px;margin-bottom: 10px;" />
                                                                            <div>
                                                                                <input type="text" name="accomodation_image_else{{ $img_Counter }}[]" class="form-control" value="{{ $value1 }}" readonly hidden>
                                                                                <button class="btn btn-danger" type="button" onclick="remove_acc_img(<?php echo $del_counter; ?>)">Delete</button>
                                                                            </div>
                                                                        </div>
                                                                        <?php $del_counter++; ?>
                                                                    @endforeach
                                                                @else
                                                                    <img src="{{ asset('/public/uploads/package_imgs/'.$value->accomodation_image) }}" style="width:233px;height:150px;margin-bottom: 10px;"  />
                                                                    <input type="text" name="accomodation_image_else[]" class="form-control" value="{{ $accomodation_image_encode }}" readonly hidden>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="mt-2">
                                                            <a href="javascript:;" onclick="remove_hotelsI({{ $i }})" id="{{ $i }}" class="btn btn-danger" style="float: right;"> 
                                                                Delete Hotel
                                                            </a>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                            <?php
                                                $count_hotel++;
                                                $img_Counter++;
                                                $i++;
                                            }
                                        ?>
                                    </div>
                                    <input type="text" id="hotel_map" class="form-control" value="{{ $i }}" readonly hidden>
                                    <input type="text" id="del_counter1" class="form-control" value="{{ $del_counter }}" readonly hidden>
                                    <input type="text" id="img_Counter1" class="form-control" value="{{ $img_Counter }}" readonly hidden>
                                    <input type="text" value="{{ $divId }}" id="newdivId" hidden/>
                                    <input type="hidden" id="city_No1" value="{{ $del_acc_city }}">
                                    
                                    <input type="hidden" id="count_hotel" value="{{ $count_hotel }}">
                                    
                                    <input type="hidden" id="more_acc_new_id" value="{{ $divId }}">
                                    
                                    <div class="col-xl-3">
                                        <div class="mt-2">
                                            <a href="javascript:;" id="add_hotel_accomodation_editI" class="btn btn-info"> 
                                                + Add Hotels 
                                            </a>
                                        </div>
                                    </div>
                                @else
                                    <div class="row">
                                        <div class="col-xl-12 mt-2">
                                            <div class="mb-3">
                                                <div class="row">
                                                    <div class="col-xl-3">
                                                        <div class="mt-2">
                                                            <a href="javascript:;" id="add_hotel_accomodation" class="btn btn-info"> 
                                                                + Add Hotels 
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="append_accomodation"> </div>
                                        <div id="append_accomodation1"></div>
                                    </div>
                                @endif
                            </div>                                                      
                            <!--<a id="save_Accomodation" class="btn btn-primary" name="submit">Save Accomodation</a>-->   
                        </div>

                        <div class="tab-pane" id="settings1">
                      
                            <div class="col-xl-12">
                                <div class="mb-3">
                                    <div class="row">
                                        <div class="col-xl-1">
                                            <input type="checkbox" id="flights_inc" data-switch="bool"/>
                                            <label for="flights_inc" data-on-label="On" data-off-label="Off"></label>
                                        </div>
                                        <div class="col-xl-3">
                                            Flights Included ?
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Add your flights details"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- flights -->
                            <div class="row" style="display:none;" id="select_flights_inc">
                                
                                <div class="col-xl-6" style="padding-left: 24px;">
                                    <label for="">Flight Type</label>
                                    <select name="flight_type" id="flights_type" class="form-control">
                                        <option attr="select" selected>Select Flight Type</option>
                                         <option attr="Direct" value="Direct">Direct</option>
                                          <option attr="Indirect" value="Indirect">Indirect</option>
                                    </select>
                                </div>
    
                                <div class="col-xl-3" id="flights_type_connected"></div>
    
                                <div class="col-xl-3"></div>
                                
                                <div class="container Flight_section">
                                    <h3 style="padding: 12px">Departure Details : </h3>
                                    <div class="row" style="padding: 12px">
                                        <div class="col-xl-4">
                                            <label for="">Departure Airport</label>
                                            <input name="departure_airport_code" id="departure_airport_code" class="form-control" autocomplete="off" placeholder="Enter Departure Location">
                                        </div>
                                        <div class="col-xl-1" style="margin-top: 25px;text-align: center;">
                                            <label for=""></label>
                                            <span id="Change_Location" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                        </div>
                                        <div class="col-xl-4">
                                            <label for="">Arrival Airport</label>
                                            <input name="arrival_airport_code" id="arrival_airport_code" class="form-control" autocomplete="off" placeholder="Enter Arrival Location">
                                            
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Airline Name</label>
                                            <input type="text" id="other_Airline_Name2" name="other_Airline_Name2" class="form-control other_airline_Name1">
                                            <!--<div class="input-group">-->
                                            <!--    <select type="text" id="other_Airline_Name2" name="other_Airline_Name2" class="form-control other_airline_Name1">-->
                                                
                                            <!--    </select>-->
                                            <!--    <span title="Add Pickup Location" class="input-group-btn input-group-append">-->
                                            <!--        <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#flights-Airline-Name" type="button">+</button>-->
                                            <!--    </span>-->
                                            <!--</div>-->
                                        </div>
                                        <div class="col-xl-3" style="margin-top: 15px;">
                                            <label for="">Class Type</label>
                                            <select  name="departure_Flight_Type" id="departure_Flight_Type" class="form-control">
                                                <option value="">Select Flight Type</option>
                                                <option value="Bussiness">Bussiness</option>
                                                <option value="Economy">Economy</option>
                                                <option value="Standard">Standard</option>
                                            </select>
                                        </div>
                                        <div class="col-xl-3" style="margin-top: 15px;">
                                            <label for="">Flight Number</label>
                                            <input type="text" id="simpleinput" name="departure_flight_number" class="form-control" placeholder="Enter Flight Number">
                                        </div>
                                        <div class="col-xl-3" style="margin-top: 15px;">
                                            <label for="">Departure Date and Time</label>
                                            <input type="datetime-local" id="simpleinput" name="departure_time" class="form-control departure_time1" value="" >
                                        </div>
                                        <div class="col-xl-3" style="margin-top: 15px;">
                                            <label for="">Arrival Date and Time</label>
                                            <input type="datetime-local" id="simpleinput" name="arrival_time" class="form-control arrival_time1" value="" >
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="container" style="display:none" id="total_Time_Div">
                                    <div class="row" style="margin-left: 320px">
                                        <div class="col-sm-3">
                                            <h3 style="width: 125px;margin-top: 25px;float:right" id="stop_No">Direct :</h3>
                                        </div>
                                        <div class="col-sm-3">
                                             <label for="">Transit Time</label>
                                            <input type="text" id="total_Time" name="total_Time" class="form-control total_Time1" readonly style="width: 170px;" value="">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="container Flight_section_append"></div>
                                
                                <div class="container return_Flight_section">
                                    <h3 style="padding: 12px">Return Details : </h3>
                                    <div class="row" style="padding: 12px">
                                        <div class="col-xl-4">
                                            <label for="">Departure Airport</label>
                                            <input name="return_departure_airport_code" id="return_departure_airport_code" class="form-control" autocomplete="off" placeholder="Enter Return Location">
                                        </div>
                                        <div class="col-xl-1" style="margin-top: 25px;text-align: center;">
                                            <label for=""></label>
                                            <span id="return_Change_Location" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                        </div>
                                        <div class="col-xl-4">
                                            <label for="">Arrival Airport</label>
                                            <input name="return_arrival_airport_code" id="return_arrival_airport_code" class="form-control" autocomplete="off" placeholder="Enter Return Location">
                                            
                                        </div>
                                        <div class="col-xl-3">
                                            <label for="">Airline Name</label>
                                            <input type="text" id="return_other_Airline_Name2" name="return_other_Airline_Name2" class="form-control other_airline_Name1">
                                            <!--<div class="input-group">-->
                                            <!--    <select type="text" id="return_other_Airline_Name2" name="return_other_Airline_Name2" class="form-control other_airline_Name1">-->
                                                
                                            <!--    </select>-->
                                            <!--    <span title="Add Pickup Location" class="input-group-btn input-group-append">-->
                                            <!--        <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#flights-Airline-Name" type="button">+</button>-->
                                            <!--    </span>-->
                                            <!--</div>-->
                                        </div>
                                        <div class="col-xl-3" style="margin-top: 15px;">
                                            <label for="">Class Type</label>
                                            <select  name="return_departure_Flight_Type" id="return_departure_Flight_Type" class="form-control">
                                                <option value="">Select Flight Type</option>
                                                <option value="Bussiness">Bussiness</option>
                                                <option value="Economy">Economy</option>
                                                <option value="Standard">Standard</option>
                                            </select>
                                        </div>
                                        <div class="col-xl-3" style="margin-top: 15px;">
                                            <label for="">Flight Number</label>
                                            <input type="text" id="simpleinput" name="return_departure_flight_number" class="form-control" placeholder="Enter Flight Number">
                                        </div>
                                        <div class="col-xl-3" style="margin-top: 15px;">
                                            <label for="">Departure Date and Time</label>
                                            <input type="datetime-local" id="simpleinput" name="return_departure_time" class="form-control return_departure_time1" value="" >
                                        </div>
                                        <div class="col-xl-3" style="margin-top: 15px;">
                                            <label for="">Arrival Date and Time</label>
                                            <input type="datetime-local" id="simpleinput" name="return_arrival_time" class="form-control return_arrival_time1" value="" >
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="container" style="display:none" id="return_total_Time_Div">
                                    <div class="row" style="margin-left: 320px">
                                        <div class="col-sm-3">
                                            <h3 style="width: 162px;margin-top: 25px;float:right" id="return_stop_No">Return Direct :</h3>
                                        </div>
                                        <div class="col-sm-3">
                                             <label for="">Transit Time</label>
                                            <input type="text" id="return_total_Time" name="return_total_Time" class="form-control return_total_Time1" readonly style="width: 170px;" value="">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="container return_Flight_section_append"></div>
                                
                                <div class="col-xl-6" style="padding-left: 24px;">
                                    <label for="">Price Per Person</label>
                                    <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2">
                                        
                                            </a>
                                        </span>
                                        <input type="text" id="flights_per_person_price" name="flights_per_person_price" class="form-control">
                                    </div>
                                </div>
                                
                                <div class="col-xl-12 mt-3" style="display:none" id="text_editer">
                                    <label for="">Indirect Flight Duration and Details</label>
                                    <textarea name="connected_flights_duration_details" class="form-control" cols="10" rows="10"></textarea>
                                </div>
                                
                                <div class="col-xl-12 mt-2" style="padding-left: 24px;">
                                    <label for="">Additional Flight Details</label>
                                    <textarea name="terms_and_conditions" class="form-control" cols="5" rows="5"></textarea>
                                </div>
                                
                                <div class="col-xl-12 mt-2 d-none" style="padding-left: 24px;">
                                    <label for="">image</label>
                                    <input type="file" id="" name="flights_image" class="form-control">
                                </div>
                                
                                <div id="append_flights"></div>
                                
                            </div>
                            <!-- END Flifhts -->    
                            <!--<a id="save_Flights" class="btn btn-primary" name="submit">Save Flights</a>-->
                           
                        </div>
                                                
                        <div class="tab-pane" id="visa_details">
                                                    
                            <div class="row">                                                  
                                <div class="col-xl-12 mt-2">
                                    <div class="mb-3">
                                        <div class="row">
                                            <div class="col-xl-1">
                                                <input type="checkbox" id="visa_inc" data-switch="bool"/>
                                                <label for="visa_inc" data-on-label="On" data-off-label="Off"></label>
                                            </div>
                                            <div class="col-xl-3">
                                                Visa Included ?
                                                <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Add visa price & requirement"></i>
                                            </div>
                                         </div>
                                    </div>
                                </div>
                                
                                <div class="row mt-1 mb-3" style="" id="select_visa_inc">
                                    
                                    <div class="col-xl-4" style="padding: 10px;">
                                        <label for="">Visa Type</label>
                                        <div class="input-group" id="timepicker-input-group1">
                                            @if(isset($get_invoice->visa_type) && $get_invoice->visa_type != null && $get_invoice->visa_type != '')
                                                <select name="visa_type" id="visa_type" class="form-control other_type">
                                                    @foreach($visa_type as $value)
                                                        <option <?php if($get_invoice->visa_type == $value->other_visa_type) echo "selected" ?> attr="{{ $value->other_visa_type }}" value="{{ $value->other_visa_type }}">{{ $value->other_visa_type }}</option>
                                                    @endforeach
                                                </select>
                                            @else
                                                <select name="visa_type" id="visa_type" class="form-control other_type"></select>
                                            @endif
                                            <span title="Add Visa Type" class="input-group-btn input-group-append"><button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#signup-modal" type="button">+</button></span>
                                        </div>
                                     </div>
                                    
                                    <div class="col-xl-4" style="padding: 10px;">
                                        <label for="">Visa Fee</label>
                                        <div class="input-group">
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up visa_C_S">
                                                    <?php echo $currency; ?>
                                                </a>
                                            </span>
                                            @if(isset($get_invoice->visa_fee) && $get_invoice->visa_fee != null && $get_invoice->visa_fee != '')
                                                <input type="text" id="visa_fee" name="visa_fee" class="form-control" value="{{ $get_invoice->visa_fee }}">
                                            @else
                                                <input type="text" id="visa_fee" name="visa_fee" class="form-control">
                                            @endif
                                        </div>
                                    </div>
                                    
                                    
                                    @if(isset($get_invoice->total_visa_markup_value) && $get_invoice->total_visa_markup_value != null && $get_invoice->total_visa_markup_value != '')
                                        <input type="hidden" id="total_visa_markup_value" name="total_visa_markup_value" class="form-control" value="{{ $get_invoice->total_visa_markup_value }}">
                                    @else
                                        <input type="hidden" id="total_visa_markup_value" name="total_visa_markup_value" class="form-control">
                                    @endif
                                    
                                    <div class="col-xl-4" style="padding: 10px;">
                                        <label for="">Visa Pax</label>
                                        @if(isset($get_invoice->visa_Pax) && $get_invoice->visa_Pax != null && $get_invoice->visa_Pax != '')
                                            <input type="text" id="visa_Pax" name="visa_Pax" class="form-control" value="{{ $get_invoice->visa_Pax }}">
                                        @else
                                            <input type="text" id="visa_Pax" name="visa_Pax" class="form-control">
                                        @endif
                                    </div>
                                    <?php //dd($get_invoice->currency_conversion); ?>
                                    @if(isset($get_invoice->currency_conversion) && $get_invoice->currency_conversion != null && $get_invoice->currency_conversion != '')
                                        <div class="col-xl-6" style="padding: 10px;">
                                            <label for="">Exchange Rate</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append">
                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                                        
                                                    </a>
                                                </span>
                                                <input type="text" id="exchange_rate_visaI" onkeyup="exchange_rate_visaI_function()" name="exchange_rate_visaI" class="form-control" value="{{ $get_invoice->exchange_rate_visaI ?? '' }}">
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-6" style="padding: 10px;">
                                            <label for="">Exchange Visa Fee</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a></span>
                                                <input type="text" id="exchange_rate_visa_total_amountI" name="exchange_rate_visa_fee" class="form-control" value="{{ $get_invoice->exchange_rate_visa_fee ?? '' }}">
                                            </div>
                                        </div>
                                    @endif
                                    
                                    @if(isset($get_invoice->more_visa_details) && $get_invoice->more_visa_details != null && $get_invoice->more_visa_details != '')
                                        <div id="add_more_visa_Pax_Div">
                                            <?php $more_visa_details = json_decode($get_invoice->more_visa_details); $m_VD_count = 1; //dd($more_visa_details);?>
                                            @foreach($more_visa_details as $value)
                                                <div id="more_visa_pax_div_{{$m_VD_count}}" class="row">
                                                    <div class="col-xl-4" style="padding: 10px;">
                                                        <label for="">Visa Type</label>
                                                        @if(isset($get_invoice->visa_type) && $get_invoice->visa_type != null && $get_invoice->visa_type != '')
                                                            <select name="more_visa_type[]" id="more_visa_type_{{$m_VD_count}}" class="form-control more_visa_type_class" onchange="more_visa_type_select({{$m_VD_count}})">
                                                                @foreach($visa_type as $value1)
                                                                    <option <?php if($value->more_visa_type == $value1->other_visa_type) echo "selected" ?> attr="{{ $value1->other_visa_type }}" value="{{ $value1->other_visa_type }}">{{ $value1->other_visa_type }}</option>
                                                                @endforeach
                                                            </select>
                                                        @else
                                                            <select name="more_visa_type[]" id="more_visa_type_{{$m_VD_count}}" class="form-control more_visa_type_class" onchange="more_visa_type_select({{$m_VD_count}})"></select>
                                                        @endif
                                                     </div>
                                                
                                                    <div class="col-xl-4" style="padding: 10px;">
                                                        <label for="">Visa Fee</label>
                                                        <div class="input-group">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up more_visa_C_S">
                                                                    <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                            <input type="text" id="more_visa_fee_{{$m_VD_count}}" name="more_visa_fee[]" value="{{ $value->more_visa_fee }}" class="form-control" onchange="more_visa_fee_calculation({{$m_VD_count}})">
                                                        </div>
                                                    </div>
                                                    <input type="hidden" id="more_total_visa_markup_value_{{$m_VD_count}}" name="more_total_visa_markup_value[]" value="{{ $value->more_total_visa_markup_value }}" class="form-control">
                                                    <div class="col-xl-3" style="padding: 10px;">
                                                        <label for="">Visa Pax</label>
                                                        <input type="text" id="more_visa_Pax_{{$m_VD_count}}" name="more_visa_Pax[]" value="{{ $value->more_visa_Pax }}" class="form-control">
                                                    </div>
                                                    <div class="col-xl-1" style="margin-top: 30px;">
                                                        <button type="button" onclick="remove_more_visa_pax({{$m_VD_count}})" class="btn btn-primary">Remove</button>
                                                    </div>
                                                     @if(isset($get_invoice->currency_conversion) && $get_invoice->currency_conversion != null && $get_invoice->currency_conversion != '')
                                                        <div class="col-xl-6" style="padding: 10px;">
                                                            <label for="">Exchange Rate</label>
                                                            <div class="input-group">
                                                                <span class="input-group-btn input-group-append">
                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                                                        
                                                                    </a>
                                                                </span>
                                                                <input type="text" id="more_exchange_rate_visaI_{{$m_VD_count}}" onkeyup="more_exchange_rate_visaI_function({{$m_VD_count}})" name="more_exchange_rate_visaI" class="form-control" value="{{ $value->more_exchange_rate_visa ?? '' }}">
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-xl-6" style="padding: 10px;">
                                                            <label for="">Exchange Visa Fee</label>
                                                            <div class="input-group">
                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a></span>
                                                                <input type="text" id="more_exchange_rate_visa_total_amountI_{{$m_VD_count}}" name="more_exchange_rate_visa_fee[]" class="form-control" value="{{ $value->more_exchange_rate_visa_fee ?? '' }}">
                                                            </div>
                                                        </div>
                                                    @endif
                                                </div>
                                                <?php $m_VD_count++ ?>
                                            @endforeach
                                            <input type="hidden" value="{{ $m_VD_count }}" id="m_VD_count">
                                        </div>
                                    @else
                                        <input type="hidden" value="1" id="m_VD_count">
                                        <div id="add_more_visa_Pax_Div"></div>
                                    @endif
                                    
                                    <div class="col-xl-12" style="padding: 10px;text-align: right;">
                                        <button type="button" id="add_more_visa_Pax" class="btn btn-primary">Add more</button>
                                    </div>
                                    
                                    <div class="col-xl-12" style="padding: 10px;">
                                        <label for="">Visa Requirements:</label>
                                        @if(isset($get_invoice->visa_rules_regulations) && $get_invoice->visa_rules_regulations != null && $get_invoice->visa_rules_regulations != '')
                                            <textarea name="visa_rules_regulations" class="form-control" cols="5" rows="5" value="{{ $get_invoice->visa_rules_regulations }}">{{ $get_invoice->visa_rules_regulations }}</textarea>
                                        @else
                                            <textarea name="visa_rules_regulations" class="form-control" cols="5" rows="5"></textarea>
                                        @endif
                                     </div>
                                     
                                    <div class="col-xl-12" style="padding: 10px;">
                                        <label for="">Image:</label>
                                        @if(isset($get_invoice->visa_image) && $get_invoice->visa_image != null && $get_invoice->visa_image != '')
                                            <img src="{{ asset('/public/uploads/package_imgs/'.$get_invoice->visa_image) }}" style="width:300px;" /> 
                                        @else
                                            <input type="file" id="" name="visa_image" class="form-control">
                                        @endif
                                     </div>
                                </div>
                                
                            </div>
                            <!--<a id="save_Visa" class="btn btn-primary" name="submit">Save Visa</a>-->
                            
                        </div> 
                                                    
                        <div class="tab-pane" id="trans_details_1">
                            <div class="row">                                       
                                <div class="tab-pane" id="trans_details_1">
                                    
                                    <div class="col-xl-12 mt-2 d-none">
                                        <div class="mb-3">
                                            <div class="row">
                                                <div class="col-xl-1">
                                                    <input type="checkbox" id="transportation" data-switch="bool"/>
                                                    <label for="transportation" data-on-label="On" data-off-label="Off"></label>
                                                </div>
                                                <div class="col-xl-3">
                                                    Transportation
                                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Add your transportation details"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-xl-3 mt-2" style="padding: 10px;">
                                        <label for="">Transfer Suppliers List</label>
                                        <select name="transfer_supplier" class="form-control" id="transfer_supplier">
                                            <option value="">Select Suppliers</option>
                                            @foreach($tranfer_supplier as $tranfer_supplierS)
                                                <option <?php if($get_invoice->transfer_supplier_id == $tranfer_supplierS->id) echo 'selected' ?> attr-id="{{ $tranfer_supplierS->id }}" value="{{ $tranfer_supplierS->room_supplier_name }}">{{ $tranfer_supplierS->room_supplier_name }}</option>
                                            @endforeach
                                        </select>
                                        
                                        <input type="hidden" name="transfer_supplier_id" id="transfer_supplier_selected_id" value="{{ $get_invoice->transfer_supplier_id ?? '' }}">
                                        
                                    </div>
                                    
                                    <div class="row" id="transfer_supplier_list_div" style="display:none">
                                        <div class="dashboard-content">
                                            <h3 style="color:#a30000;font-size: 40px;text-align:center">Vehicle List</h3>
                                            <div class="row">
                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="dashboard-list-box dash-list margin-top-0">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <table id="myTable" class="display nowrap table table-bordered" style="width:100%;">
                                                                    <thead class="theme-bg-clr">
                                                                        <tr>
                                                                            <th>Id</th>
                                                                            <th>Company Name</th>
                                                                            <th>Pickup City</th>
                                                                            <th>Dropoff City</th>
                                                                            <th>Available From</th>
                                                                            <th>Available To</th>
                                                                            <th>Trip Type</th>
                                                                            <th>Total Fare</th>
                                                                            <th>Occupy</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody style="text-align: center;" id="transfer_supplier_list_body"></tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    @if(isset($get_invoice->services) && $get_invoice->services != null && $get_invoice->services != '')
                                        <?php $services = json_decode($get_invoice->services);?>
                                        @if($services[0] == '1' || $services[0] == 'transportation_tab')
                                        
                                            @if(isset($get_invoice->transportation_details) && $get_invoice->transportation_details != null && $get_invoice->transportation_details != '')
                                                <?php   
                                                    $transportation_details_D       = json_decode($get_invoice->transportation_details);
                                                    $transportation_details_more_D  = json_decode($get_invoice->transportation_details_more);
                                                    $MTD_id                         = 1;
                                                    $TD_id1                         = 1;
                                                ?>
                                                <div class="row" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;" id="select_transportation">
                                                    @if(isset($transportation_details_D) && $transportation_details_D != null && $transportation_details_D != '')
                                                        @foreach($transportation_details_D as $transportation_details_DS)
                                                            @if($transportation_details_DS->transportation_trip_type != null && $transportation_details_DS->transportation_trip_type != '' && $transportation_details_DS->transportation_trip_type != 'All_Round')
                                                            
                                                                <input type="hidden" name="destination_id[]" id="destination_id" value="{{ $transportation_details_DS->destination_id }}">
                                                                
                                                                <input type="hidden" name="vehicle_select_exchange_type[]" id="vehicle_select_exchange_type_ID_{{ $TD_id1 }}" value="{{ $transportation_details_DS->vehicle_select_exchange_type ?? '' }}">
                                        
                                                                <input type="hidden" name="vehicle_exchange_Rate[]" id="vehicle_exchange_Rate_ID_{{ $TD_id1 }}" value="{{ $transportation_details_DS->vehicle_exchange_Rate ?? '' }}">
                                                                
                                                                <input type="hidden" name="currency_SAR[]" id="currency_SAR" value="{{ $transportation_details_DS->currency_SAR ?? '' }}">
                                                            
                                                                <input type="hidden" name="currency_GBP[]" id="currency_GBP" value="{{ $transportation_details_DS->currency_GBP ?? '' }}">
                                                                
                                                                <input type="hidden" id="currency_GBP_for_costing" value="{{ $transportation_details_DS->currency_GBP ?? '' }}">
                                                                
                                                                <h3>Transportation Details :</h3>
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Pick-up Location</label>
                                                                    <input type="text" value="{{ $transportation_details_DS->transportation_pick_up_location ?? '' }}" id="transportation_pick_up_location_{{ $TD_id1 }}" name="transportation_pick_up_location[]" class="form-control pickup_location" value="" onkeyup="TPUL_function({{ $TD_id1 }})">
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Drop-off Location</label>
                                                                    <input type="text" value="{{ $transportation_details_DS->transportation_drop_off_location ?? '' }}" id="transportation_drop_off_location_{{ $TD_id1 }}" name="transportation_drop_off_location[]" class="form-control dropof_location" onkeyup="TDOL_function({{ $TD_id1 }})">
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Pick-up Date & Time</label>
                                                                    <input type="datetime-local" value="{{ $transportation_details_DS->transportation_pick_up_date ?? '' }}" id="transportation_pick_up_date_{{ $TD_id1 }}" name="transportation_pick_up_date[]" class="form-control" onchange="TPUD_function({{ $TD_id1 }})">
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Drop-of Date & Time</label>
                                                                    <input type="datetime-local" value="{{ $transportation_details_DS->transportation_drop_of_date ?? '' }}" id="transportation_drop_of_date_{{ $TD_id1 }}" name="transportation_drop_of_date[]" class="form-control" onchange="TDOP_function({{ $TD_id1 }})">
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;" id="transportation_Time_Div">
                                                                    <label for="">Estimate Time</label>
                                                                    <input type="text" value="{{ $transportation_details_DS->transportation_total_Time ?? '' }}" id="transportation_total_Time_{{ $TD_id1 }}" name="transportation_total_Time[]" class="form-control transportation_total_Time1" readonly style="padding: 10px;" value="">
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Select Trip Type</label>
                                                                    <select name="transportation_trip_type[]" id="slect_trip_{{ $TD_id1 }}" class="form-control"  data-placeholder="Choose ..." readonly>
                                                                        <option value="{{ $transportation_details_DS->transportation_trip_type ?? '' }}">{{ $transportation_details_DS->transportation_trip_type ?? '' }}</option>
                                                                    </select>
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Vehicle Type</label>
                                                                    <select name="transportation_vehicle_type[]" id="transportation_vehicle_typeI_{{ $TD_id1 }}" class="form-control"  data-placeholder="Choose ...">
                                                                        <option selected value="{{ $transportation_details_DS->transportation_vehicle_type ?? '' }}">{{ $transportation_details_DS->transportation_vehicle_type ?? '' }}</option>
                                                                    </select>
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">No Of Vehicle</label>
                                                                    <input type="text" value="{{ $transportation_details_DS->transportation_no_of_vehicle ?? '' }}" id="transportation_no_of_vehicle_{{ $TD_id1 }}" name="transportation_no_of_vehicle[]" class="form-control" onkeyup="TNOV_function({{ $TD_id1 }})">
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Price Per Vehicle</label>
                                                                    <div class="input-group">
                                                                        <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T">{{ $transportation_details_DS->currency_SAR ?? '' }}</a></span>
                                                                        <input type="text" value="{{ $transportation_details_DS->transportation_price_per_vehicle ?? '' }}" id="transportation_price_per_vehicle_{{ $TD_id1 }}" name="transportation_price_per_vehicle[]" class="form-control" readonly>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Total Vehicle Price</label>
                                                                    <div class="input-group">
                                                                        <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T">{{ $transportation_details_DS->currency_SAR ?? '' }}</a></span>
                                                                        <input type="text" value="{{ $transportation_details_DS->transportation_vehicle_total_price ?? '' }}" id="transportation_vehicle_total_price_{{ $TD_id1 }}" name="transportation_vehicle_total_price[]" class="form-control" readonly>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Price Per Person</label>
                                                                    <div class="input-group">
                                                                        <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T">{{ $transportation_details_DS->currency_SAR ?? '' }}</a></span>
                                                                        <input type="text" value="{{ $transportation_details_DS->transportation_price_per_person ?? '' }}" id="transportation_price_per_person_{{ $TD_id1 }}" name="transportation_price_per_person[]" class="form-control" readonly>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Exchange Rate</label>
                                                                    <div class="input-group">
                                                                        <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T">{{ $transportation_details_DS->currency_SAR ?? '' }}</a></span>
                                                                        <input type="text" value="{{ $transportation_details_DS->transfer_exchange_rate_destination ?? '' }}" name="transfer_exchange_rate_destination[]" id="transfer_exchange_rate_destination_{{ $TD_id1 }}" class="form-control" readonly>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Price Per Vehicle</label>
                                                                    <div class="input-group">
                                                                        <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T">{{ $transportation_details_DS->currency_GBP ?? '' }}</a></span>
                                                                        <input type="text" value="{{ $transportation_details_DS->without_markup_price_converted_destination ?? '' }}" name="without_markup_price_converted_destination[]" id="without_markup_price_converted_destination_{{ $TD_id1 }}" class="form-control" readonly>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Total Vehicle Price</label>
                                                                    <div class="input-group">
                                                                        <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T">{{ $transportation_details_DS->currency_GBP ?? '' }}</a></span>
                                                                        <input type="text" value="{{ $transportation_details_DS->transportation_vehicle_total_price_converted ?? '' }}" name="transportation_vehicle_total_price_converted[]" id="transportation_vehicle_total_price_converted_{{ $TD_id1 }}" class="form-control" readonly>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Price Per Person</label>
                                                                    <div class="input-group">
                                                                        <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T">{{ $transportation_details_DS->currency_GBP ?? '' }}</a></span>
                                                                        <input type="text" value="{{ $transportation_details_DS->transportation_price_per_person_converted ?? '' }}" name="transportation_price_per_person_converted[]" id="transportation_price_per_person_converted_{{ $TD_id1 }}" class="form-control" readonly>
                                                                    </div>
                                                                </div>
                                                                
                                                                <!--Costing-->
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Vehicle Markup Type</label>
                                                                    <select name="vehicle_markup_type[]" id="vehicle_markup_type_{{ $TD_id1 }}" class="form-control" onchange="vehicle_markup_OWandR1({{ $TD_id1 }})">
                                                                        <option <?php if($transportation_details_DS->vehicle_markup_type ?? ''  == '') echo 'selected' ?> value="">Markup Type</option>
                                                                        <option <?php if($transportation_details_DS->vehicle_markup_type ?? ''  == '%') echo 'selected' ?> value="%">Percentage</option>
                                                                        <option <?php if($transportation_details_DS->vehicle_markup_type ?? ''  == $currency) echo 'selected' ?> value="<?php echo $currency; ?>">Fixed Amount</option>
                                                                    </select>
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Markup Value per Vehicle</label>
                                                                    <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                        <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T">{{ $transportation_details_DS->currency_GBP ?? '' }}</a></span>
                                                                        <input value="{{ $transportation_details_DS->vehicle_per_markup_value ?? '' }}" type="text" class="form-control" id="vehicle_per_markup_value_{{ $TD_id1 }}" name="vehicle_per_markup_value[]" onkeyup="vehicle_per_markup_OWandR1({{ $TD_id1 }})">
                                                                    </div>
                                                                </div>
                                                                
                                                                <input value="{{ $transportation_details_DS->markup_price_per_vehicle_converted ?? '' }}" type="text" class="form-control d-none" id="markup_price_per_vehicle_converted_{{ $TD_id1 }}" name="markup_price_per_vehicle_converted[]" readonly>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Vehicle Markup Value</label>
                                                                    <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                        <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T">{{ $transportation_details_DS->currency_SAR ?? '' }}</a></span>
                                                                        <input value="{{ $transportation_details_DS->vehicle_markup_value ?? '' }}" type="text" class="form-control" id="vehicle_markup_value_{{ $TD_id1 }}" name="vehicle_markup_value[]" onkeyup="vehicle_markup_OWandR1({{ $TD_id1 }})" readonly>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Vehicle Total Price</label>
                                                                    <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                        <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T">{{ $transportation_details_DS->currency_SAR ?? '' }}</a></span>
                                                                        <input value="{{ $transportation_details_DS->vehicle_total_price_with_markup ?? '' }}" type="text" class="form-control" id="vehicle_total_price_with_markup_{{ $TD_id1 }}" name="vehicle_total_price_with_markup[]" readonly>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Vehicle Markup Value</label>
                                                                    <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                        <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T">{{ $transportation_details_DS->currency_GBP ?? '' }}</a></span>
                                                                        <input value="{{ $transportation_details_DS->vehicle_markup_value_converted ?? '' }}" type="text" class="form-control" id="vehicle_markup_value_converted_{{ $TD_id1 }}" name="vehicle_markup_value_converted[]" readonly>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                    <label for="">Vehicle Markup Price</label>
                                                                    <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                        <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T">{{ $transportation_details_DS->currency_GBP ?? '' }}</a></span>
                                                                        <input value="{{ $transportation_details_DS->vehicle_total_price_with_markup_converted ?? '' }}" type="text" class="form-control" id="vehicle_total_price_with_markup_converted_{{ $TD_id1 }}" name="vehicle_total_price_with_markup_converted[]" readonly>
                                                                    </div>
                                                                </div>
                                                                <!--End Costing-->
                                                                
                                                                <input type="hidden" class="transfer_markup_type_invoice" value="{{ $transportation_details_DS->transfer_markup_type_invoice ?? '' }}" name="transfer_markup_type_invoice[]">
                                                                <input type="hidden" class="transfer_markup_invoice" value="{{ $transportation_details_DS->transfer_markup_invoice ?? '' }}" name="transfer_markup_invoice[]">
                                                                <input type="hidden" class="transfer_markup_price_invoice" value="{{ $transportation_details_DS->transfer_markup_price_invoice ?? '' }}" name="transfer_markup_price_invoice[]">
                                                        
                                                                <!--Return Transportation-->
                                                                @if($transportation_details_DS->transportation_trip_type != 'Return')
                                                                    <div class="row" id="select_return" style="display:none;padding: 10px;">
                                                                        <h3>Return Details :</h3>
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Pick-up Location</label>
                                                                            <input type="text" id="return_transportation_pick_up_location" name="return_transportation_pick_up_location" class="form-control pickup_location">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Drop-off Location</label>
                                                                            <input type="text" id="return_transportation_drop_off_location" name="return_transportation_drop_off_location" class="form-control dropof_location">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Pick-up Date & Time</label>
                                                                            <input type="datetime-local" id="return_transportation_pick_up_date" name="return_transportation_pick_up_date" class="form-control">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Drop-of Date & Time</label>
                                                                            <input type="datetime-local" id="return_transportation_drop_of_date" name="return_transportation_drop_of_date" class="form-control">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;" id="return_transportation_Time_Div">
                                                                            <label for="" style="width: 205px;">Estimate Time Return</label>
                                                                            <input type="text" id="return_transportation_total_Time" name="return_transportation_total_Time" class="form-control return_transportation_total_Time1" readonly style="padding: 10px;" value="">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="display:none;padding: 10px;">
                                                                            <label for="">Vehicle Type</label>
                                                                            <select name="return_transportation_vehicle_type" id="" class="form-control"  data-placeholder="Choose ...">
                                                                                <option value="">Choose ...</option>
                                                                                <option value="Bus">Bus</option>
                                                                                <option value="Coach">Coach</option>
                                                                                <option value="Vain">Vain</option>
                                                                                <option value="Car">Car</option>
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="display:none;padding: 10px;">
                                                                            <label for="">No Of Vehicle</label>
                                                                            <input type="text" id="return_transportation_no_of_vehicle" name="return_transportation_no_of_vehicle" class="form-control">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="display:none;padding: 10px;">
                                                                            <label for="">Price Per Vehicle</label>
                                                                            <div class="input-group">
                                                                                        <span class="input-group-btn input-group-append">
                                                                                            <a class="btn btn-primary bootstrap-touchspin-up">
                                                                                               <?php echo $currency; ?>
                                                                                            </a>
                                                                                        </span>
                                                                                <input type="text" id="return_transportation_price_per_vehicle" name="return_transportation_price_per_vehicle" class="form-control">
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="display:none;padding: 10px;">
                                                                            <label for="">Total Vehicle Price</label>
                                                                            <div class="input-group">
                                                                                        <span class="input-group-btn input-group-append">
                                                                                            <a class="btn btn-primary bootstrap-touchspin-up">
                                                                                               <?php echo $currency; ?>
                                                                                            </a>
                                                                                        </span>
                                                                                <input type="text" id="return_transportation_vehicle_total_price" name="return_transportation_vehicle_total_price" class="form-control">
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="display:none;padding: 10px;">
                                                                            <label for="">Price Per Person</label>
                                                                                <div class="input-group">
                                                                                            <span class="input-group-btn input-group-append">
                                                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                                                   <?php echo $currency; ?>
                                                                                                </a>
                                                                                            </span>
                                                                                    <input type="text" id="return_transportation_price_per_person" name="return_transportation_price_per_person" class="form-control">
                                                                                </div>
                                                                            </div>
                                                                    </div>
                                                                @else
                                                                    <div class="row" id="select_return" style="padding: 10px;">
                                                                        <h3>Return Details :</h3>
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Pick-up Location</label>
                                                                            <input type="text" value="{{ $transportation_details_DS->return_transportation_pick_up_location ?? '' }}" id="return_transportation_pick_up_location" name="return_transportation_pick_up_location" class="form-control pickup_location" onchange="TRPUL_function({{ $TD_id1 }})">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Drop-off Location</label>
                                                                            <input type="text" value="{{ $transportation_details_DS->return_transportation_drop_off_location ?? '' }}" id="return_transportation_drop_off_location" name="return_transportation_drop_off_location" class="form-control dropof_location" onchange="TRDOL_function({{ $TD_id1 }})">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Pick-up Date & Time</label>
                                                                            <input type="datetime-local" value="{{ $transportation_details_DS->return_transportation_pick_up_date ?? '' }}" id="return_transportation_pick_up_date_{{ $TD_id1 }}" name="return_transportation_pick_up_date" class="form-control" onchange="TRPUD_function({{ $TD_id1 }})">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Drop-of Date & Time</label>
                                                                            <input type="datetime-local" value="{{ $transportation_details_DS->return_transportation_drop_of_date ?? '' }}" id="return_transportation_drop_of_date_{{ $TD_id1 }}" name="return_transportation_drop_of_date" class="form-control" onchange="TRDOP_function({{ $TD_id1 }})">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;" id="return_transportation_Time_Div_{{ $TD_id1 }}">
                                                                            <label for="" style="width: 205px;">Estimate Time Return</label>
                                                                            <input type="text" value="{{ $transportation_details_DS->return_transportation_total_Time ?? '' }}" id="return_transportation_total_Time_{{ $TD_id1 }}" name="return_transportation_total_Time" class="form-control return_transportation_total_Time1" readonly style="padding: 10px;">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="display:none;padding: 10px;">
                                                                            <label for="">Vehicle Type</label>
                                                                            <select name="return_transportation_vehicle_type" id="" class="form-control"  data-placeholder="Choose ...">
                                                                                <option value="">Choose ...</option>
                                                                                <option value="Bus">Bus</option>
                                                                                <option value="Coach">Coach</option>
                                                                                <option value="Vain">Vain</option>
                                                                                <option value="Car">Car</option>
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="display:none;padding: 10px;">
                                                                            <label for="">No Of Vehicle</label>
                                                                            <input type="text" id="return_transportation_no_of_vehicle" name="return_transportation_no_of_vehicle" class="form-control">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="display:none;padding: 10px;">
                                                                            <label for="">Price Per Vehicle</label>
                                                                            <div class="input-group">
                                                                                        <span class="input-group-btn input-group-append">
                                                                                            <a class="btn btn-primary bootstrap-touchspin-up">
                                                                                               <?php echo $currency; ?>
                                                                                            </a>
                                                                                        </span>
                                                                                <input type="text" id="return_transportation_price_per_vehicle" name="return_transportation_price_per_vehicle" class="form-control">
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="display:none;padding: 10px;">
                                                                            <label for="">Total Vehicle Price</label>
                                                                            <div class="input-group">
                                                                                        <span class="input-group-btn input-group-append">
                                                                                            <a class="btn btn-primary bootstrap-touchspin-up">
                                                                                               <?php echo $currency; ?>
                                                                                            </a>
                                                                                        </span>
                                                                                <input type="text" id="return_transportation_vehicle_total_price" name="return_transportation_vehicle_total_price" class="form-control">
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="display:none;padding: 10px;">
                                                                            <label for="">Price Per Person</label>
                                                                                <div class="input-group">
                                                                                            <span class="input-group-btn input-group-append">
                                                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                                                   <?php echo $currency; ?>
                                                                                                </a>
                                                                                            </span>
                                                                                    <input type="text" id="return_transportation_price_per_person" name="return_transportation_price_per_person" class="form-control">
                                                                                </div>
                                                                            </div>
                                                                    </div>
                                                                @endif
                                                                
                                                                <div id="append_transportation"></div>
                                                            
                                                                <div class="mt-2" style="display:none;" id="add_more_destination">
                                                                    <a href="javascript:;" id="more_transportationI" class="btn btn-info" style="float: right;">Add More Destinations </a>
                                                                </div>
                                                                
                                                            @else
                                                                @if($transportation_details_DS->transportation_trip_type != null && $transportation_details_DS->transportation_trip_type != '')
                                                                        
                                                                    <div class="row" id="allRound_Div_{{ $TD_id1 }}">
                                                                        
                                                                        <input type="hidden" name="all_round_Type[]" value="{{ $transportation_details_DS->all_round_Type ?? '' }}">
                                                                        
                                                                        <input type="hidden" name="destination_id[]" id="destination_id" value="{{ $transportation_details_DS->destination_id }}">
                                                                        
                                                                        <input type="hidden" name="vehicle_select_exchange_type[]" id="vehicle_select_exchange_type_ID_{{ $TD_id1 }}" value="{{ $transportation_details_DS->vehicle_select_exchange_type ?? '' }}">
                                        
                                                                        <input type="hidden" name="vehicle_exchange_Rate[]" id="vehicle_exchange_Rate_ID_{{ $TD_id1 }}" value="{{ $transportation_details_DS->vehicle_exchange_Rate ?? '' }}">
                                                                        
                                                                        <input type="hidden" name="currency_SAR[]" id="currency_SAR_{{ $TD_id1 }}" value="{{ $transportation_details_DS->currency_SAR ?? '' }}">
                                                                    
                                                                        <input type="hidden" name="currency_GBP[]" id="currency_GBP_{{ $TD_id1 }}" value="{{ $transportation_details_DS->currency_GBP ?? '' }}">
                                                                        
                                                                        <input type="hidden" id="currency_GBP_for_costing" value="{{ $transportation_details_DS->currency_GBP ?? '' }}">
                                                                        
                                                                        <h3>Transportation Details :</h3>
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Pick-up Location</label>
                                                                            <input type="text" value="{{ $transportation_details_DS->transportation_pick_up_location ?? '' }}" id="transportation_pick_up_location_{{ $TD_id1 }}" name="transportation_pick_up_location[]" class="form-control pickup_location" onkeyup="TPUL_function({{ $TD_id1 }})">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Drop-off Location</label>
                                                                            <input type="text" value="{{ $transportation_details_DS->transportation_drop_off_location ?? '' }}" id="transportation_drop_off_location_{{ $TD_id1 }}" name="transportation_drop_off_location[]" class="form-control dropof_location" onkeyup="TDOL_function({{ $TD_id1 }})">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Pick-up Date & Time</label>
                                                                            <input type="datetime-local" value="{{ $transportation_details_DS->transportation_pick_up_date ?? '' }}" id="transportation_pick_up_date_{{ $TD_id1 }}" name="transportation_pick_up_date[]" class="form-control" onchange="TPUD_function({{ $TD_id1 }})">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Drop-of Date & Time</label>
                                                                            <input type="datetime-local" value="{{ $transportation_details_DS->transportation_drop_of_date ?? '' }}" id="transportation_drop_of_date_{{ $TD_id1 }}" name="transportation_drop_of_date[]" class="form-control" onchange="TDOP_function({{ $TD_id1 }})">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;" id="transportation_Time_Div_{{ $TD_id1 }}">
                                                                            <label for="">Estimate Time</label>
                                                                            <input type="text" value="{{ $transportation_details_DS->transportation_total_Time ?? '' }}" id="transportation_total_Time_{{ $TD_id1 }}" name="transportation_total_Time[]" class="form-control transportation_total_Time1" readonly style="padding: 10px;" value="">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Select Trip Type</label>
                                                                            <select name="transportation_trip_type[]" id="slect_trip_{{ $TD_id1 }}" class="form-control"  data-placeholder="Choose ..." readonly>
                                                                                <option value="{{ $transportation_details_DS->transportation_trip_type ?? '' }}">{{ $transportation_details_DS->transportation_trip_type ?? '' }}</option>
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Vehicle Type</label>
                                                                            <select name="transportation_vehicle_type[]" id="transportation_vehicle_typeI_{{ $TD_id1 }}" class="form-control"  data-placeholder="Choose ...">
                                                                                <option selected value="{{ $transportation_details_DS->transportation_vehicle_type ?? '' }}">{{ $transportation_details_DS->transportation_vehicle_type ?? '' }}</option>
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">No Of Vehicle</label>
                                                                            <input type="text" value="{{ $transportation_details_DS->transportation_no_of_vehicle ?? '' }}" id="transportation_no_of_vehicle_{{ $TD_id1 }}" name="transportation_no_of_vehicle[]" class="form-control" onkeyup="TNOV_function({{ $TD_id1 }})">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Price Per Vehicle</label>
                                                                            <div class="input-group">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T_{{ $TD_id1 }}">{{ $transportation_details_DS->currency_SAR ?? '' }}</a></span>
                                                                                <input type="text" value="{{ $transportation_details_DS->transportation_price_per_vehicle ?? '' }}" id="transportation_price_per_vehicle_{{ $TD_id1 }}" name="transportation_price_per_vehicle[]" class="form-control" readonly>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Total Vehicle Price</label>
                                                                            <div class="input-group">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T_{{ $TD_id1 }}">{{ $transportation_details_DS->currency_SAR ?? '' }}</a></span>
                                                                                <input type="text" value="{{ $transportation_details_DS->transportation_vehicle_total_price ?? '' }}" id="transportation_vehicle_total_price_{{ $TD_id1 }}" name="transportation_vehicle_total_price[]" class="form-control" readonly>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Price Per Person</label>
                                                                            <div class="input-group">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T_{{ $TD_id1 }}">{{ $transportation_details_DS->currency_SAR ?? '' }}</a></span>
                                                                                <input type="text" value="{{ $transportation_details_DS->transportation_price_per_person ?? '' }}" id="transportation_price_per_person_{{ $TD_id1 }}" name="transportation_price_per_person[]" class="form-control" readonly>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Exchange Rate</label>
                                                                            <div class="input-group">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T_{{ $TD_id1 }}">{{ $transportation_details_DS->currency_SAR ?? '' }}</a></span>
                                                                                <input type="text" value="{{ $transportation_details_DS->transfer_exchange_rate_destination ?? '' }}" name="transfer_exchange_rate_destination[]" id="transfer_exchange_rate_destination_{{ $TD_id1 }}" class="form-control" readonly>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Price Per Vehicle</label>
                                                                            <div class="input-group">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T_{{ $TD_id1 }}">{{ $transportation_details_DS->currency_GBP ?? '' }}</a></span>
                                                                                <input type="text" value="{{ $transportation_details_DS->without_markup_price_converted_destination ?? '' }}" name="without_markup_price_converted_destination[]" id="without_markup_price_converted_destination_{{ $TD_id1 }}" class="form-control" readonly>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Total Vehicle Price</label>
                                                                            <div class="input-group">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T_{{ $TD_id1 }}">{{ $transportation_details_DS->currency_GBP ?? '' }}</a></span>
                                                                                <input type="text" value="{{ $transportation_details_DS->transportation_vehicle_total_price_converted ?? '' }}" name="transportation_vehicle_total_price_converted[]" id="transportation_vehicle_total_price_converted_{{ $TD_id1 }}" class="form-control" readonly>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Price Per Person</label>
                                                                            <div class="input-group">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T_{{ $TD_id1 }}">{{ $transportation_details_DS->currency_GBP ?? '' }}</a></span>
                                                                                <input type="text" value="{{ $transportation_details_DS->transportation_price_per_person_converted ?? '' }}" name="transportation_price_per_person_converted[]" id="transportation_price_per_person_converted_{{ $TD_id1 }}" class="form-control" readonly>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <!--Costing-->
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Vehicle Markup Type</label>
                                                                            <select name="vehicle_markup_type[]" id="vehicle_markup_type_{{ $TD_id1 }}" class="form-control" onchange="vehicle_markup_AllR({{ $TD_id1 }})">
                                                                                <option <?php if($transportation_details_DS->vehicle_markup_type ?? '' == '') echo 'selected' ?> value="">Markup Type</option>
                                                                                <option <?php if($transportation_details_DS->vehicle_markup_type ?? '' == '%') echo 'selected' ?> value="%">Percentage</option>
                                                                                <option <?php if($transportation_details_DS->vehicle_markup_type ?? '' == $currency) echo 'selected' ?> value="<?php echo $currency; ?>">Fixed Amount</option>
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Markup Value per Vehicle</label>
                                                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T">{{ $transportation_details_DS->currency_GBP ?? '' }}</a></span>
                                                                                <input value="{{ $transportation_details_DS->vehicle_per_markup_value ?? '' }}" type="text" class="form-control" id="vehicle_per_markup_value_{{ $TD_id1 }}" name="vehicle_per_markup_value[]" onkeyup="vehicle_per_markup_OWandR1({{ $TD_id1 }})">
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <input value="{{ $transportation_details_DS->markup_price_per_vehicle_converted ?? '' }}" type="text" class="form-control d-none" id="markup_price_per_vehicle_converted_{{ $TD_id1 }}" name="markup_price_per_vehicle_converted[]" readonly>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Vehicle Markup Value</label>
                                                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T_{{ $TD_id1 }}">{{ $transportation_details_DS->currency_SAR ?? '' }}</a></span>
                                                                                <input value="{{ $transportation_details_DS->vehicle_markup_value ?? '' }}" ype="text" class="form-control" id="vehicle_markup_value_{{ $TD_id1 }}" name="vehicle_markup_value[]" onkeyup="vehicle_markup_AllR({{ $TD_id1 }})" readonly>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Vehicle Total Price</label>
                                                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T_{{ $TD_id1 }}">{{ $transportation_details_DS->currency_SAR ?? '' }}</a></span>
                                                                                <input value="{{ $transportation_details_DS->vehicle_total_price_with_markup ?? '' }}" type="text" class="form-control" id="vehicle_total_price_with_markup_{{ $TD_id1 }}" name="vehicle_total_price_with_markup[]" readonly>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Vehicle Markup Value</label>
                                                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T_{{ $TD_id1 }}">{{ $transportation_details_DS->currency_GBP ?? '' }}</a></span>
                                                                                <input value="{{ $transportation_details_DS->vehicle_markup_value_converted ?? '' }}" type="text" class="form-control" id="vehicle_markup_value_converted_{{ $TD_id1 }}" name="vehicle_markup_value_converted[]" readonly>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3" style="padding: 10px;">
                                                                            <label for="">Vehicle Markup Price</label>
                                                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T_{{ $TD_id1 }}">{{ $transportation_details_DS->currency_GBP ?? '' }}</a></span>
                                                                                <input value="{{ $transportation_details_DS->vehicle_total_price_with_markup_converted ?? '' }}" type="text" class="form-control" id="vehicle_total_price_with_markup_converted_{{ $TD_id1 }}" name="vehicle_total_price_with_markup_converted[]" readonly>
                                                                            </div>
                                                                        </div>
                                                                        <!--End Costing-->
                                                                        
                                                                        <input type="hidden" class="transfer_markup_type_invoice" value="{{ $transportation_details_DS->transfer_markup_type_invoice ?? '' }}" name="transfer_markup_type_invoice[]">
                                                                        <input type="hidden" class="transfer_markup_invoice" value="{{ $transportation_details_DS->transfer_markup_invoice ?? '' }}" name="transfer_markup_invoice[]">
                                                                        <input type="hidden" class="transfer_markup_price_invoice" value="{{ $transportation_details_DS->transfer_markup_price_invoice ?? '' }}" name="transfer_markup_price_invoice[]">
                                                                    
                                                                        <div id="append_transportation">
                                                                            @if(isset($transportation_details_more_D) && $transportation_details_more_D !=null && $transportation_details_more_D != '')
                                                                                @foreach($transportation_details_more_D as $transportation_details_more_DS)
                                                                                    @if(isset($transportation_details_more_DS->more_all_round_Type) && $transportation_details_more_DS->more_all_round_Type != null && $transportation_details_more_DS->more_all_round_Type != '')
                                                                                    
                                                                                        @if($transportation_details_more_DS->more_all_round_Type == $transportation_details_DS->all_round_Type)
                                                                                            <input type="hidden" name="more_all_round_Type[]" value="{{ $transportation_details_more_DS->more_all_round_Type ?? '' }}">
                                                                                            
                                                                                            <div class="row" id="click_delete_{{ $MTD_id }}">
                                                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                                                    <label for="">Pick-up Location</label>
                                                                                                    <input type="text" value="{{ $transportation_details_more_DS->more_transportation_pick_up_location }}" id="more_transportation_pick_up_location_{{ $MTD_id }}" name="more_transportation_pick_up_location[]" class="form-control">
                                                                                                </div>
                                                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                                                    <label for="">Drop-off Location</label>
                                                                                                    <input type="text" value="{{ $transportation_details_more_DS->more_transportation_drop_off_location }}" id="more_transportation_drop_off_location_{{ $MTD_id }}" name="more_transportation_drop_off_location[]" class="form-control">
                                                                                                </div>
                                                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                                                    <label for="">Pick-up Date & Time</label>
                                                                                                    <input type="datetime-local" value="{{ $transportation_details_more_DS->more_transportation_pick_up_date }}" id="more_transportation_pick_up_date_{{ $MTD_id }}" onchange="MTPD_function({{ $MTD_id }})" name="more_transportation_pick_up_date[]" class="form-control">
                                                                                                </div>
                                                                                                
                                                                                                <div class="col-xl-3" style="padding: 10px;">
                                                                                                    <label for="">Drop-of Date & Time</label>
                                                                                                    <input type="datetime-local" value="{{ $transportation_details_more_DS->more_transportation_drop_of_date }}" id="more_transportation_drop_of_date_{{ $MTD_id }}" onchange="MTDD_function({{ $MTD_id }})" name="more_transportation_drop_of_date[]" class="form-control">
                                                                                                </div>
                                                                                                
                                                                                                <div class="col-xl-3" style="padding: 10px;" id="more_transportation_Time_Div_{{ $MTD_id }}">
                                                                                                    <label for="">Estimate Time</label>
                                                                                                    <input type="text" value="{{ $transportation_details_more_DS->more_transportation_total_Time }}" id="more_transportation_total_Time_{{ $MTD_id }}" name="more_transportation_total_Time[]" class="form-control" readonly style="padding: 10px;">
                                                                                                </div>
                                                                                                
                                                                                                <div class="col-xl-9" style="padding: 20px;">
                                                                                                    <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRowTransI({{ $MTD_id }})"  id="${MTD_id}">Delete</button>
                                                                                                </div>
                                                                                            </div>
                                                                                        @endif
                                                                                    @endif
                                                                                <?php $MTD_id = $MTD_id + 1; ?>
                                                                                @endforeach
                                                                            @endif
                                                                        </div>
                                                                    
                                                                        <input type="hidden" value="{{ $MTD_id }}" id="MTD_id_input">
                                                                        
                                                                        <div class="mt-2" style="display:none;" id="add_more_destination">
                                                                            <a href="javascript:;" id="more_transportationI" class="btn btn-info" style="float: right;">Add More Destinations </a>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-6 R_AllRound_class_{{ $TD_id1 }}" style="padding: 10px;"></div>
                                                                        <div class="col-xl-6 R_AllRound_class_{{ $TD_id1 }}" style="padding: 10px;">
                                                                            <a type="button" class="btn btn-primary" id="R_AllRound_Id_{{ $TD_id1 }}" onclick="R_AllRound_function({{ $TD_id1 }},{{ $TD_id1 }})" style="float: right;">Remove</a>
                                                                        </div>
                                                                    
                                                                    </div>
                                                                
                                                                @endif
                                                            @endif
                                                            <?php $TD_id1 = $TD_id1 + 1; ?>
                                                        @endforeach
                                                    @endif
                                                </div>
                                                
                                                <input type="hidden" id="transportation_price_switchAR" value="{{ $TD_id1 }}">
                                                
                                            @endif
                                            
                                        @endif
                                        
                                    @endif
                                    
                                    <div class="row" style="display:none;border:1px solid #ced4da;padding: 20px 20px 20px 20px;" id="select_transportation_Original">
                                        
                                        <input type="hidden" id="transportation_price_switch">
                                        
                                        <input type="hidden" name="all_round_Type[]">
                                        
                                        <input type="hidden" name="destination_id[]" id="destination_id">
                                        
                                        <input type="hidden" name="vehicle_select_exchange_type[]" id="vehicle_select_exchange_type_ID">
                                
                                        <input type="hidden" name="vehicle_exchange_Rate[]" id="vehicle_exchange_Rate_ID">
                                        
                                        <input type="hidden" name="currency_SAR[]" id="currency_SAR">
                                    
                                        <input type="hidden" name="currency_GBP[]" id="currency_GBP">
                                        
                                        <h3>Transportation Details :</h3>
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Pick-up Location</label>
                                            <input type="text" id="transportation_pick_up_location" name="transportation_pick_up_location[]" class="form-control pickup_location" value="">
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Drop-off Location</label>
                                            <input type="text" id="transportation_drop_off_location" name="transportation_drop_off_location[]" class="form-control dropof_location">
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Pick-up Date & Time</label>
                                            <input type="datetime-local" id="transportation_pick_up_date" name="transportation_pick_up_date[]" class="form-control">
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Drop-of Date & Time</label>
                                            <input type="datetime-local" id="transportation_drop_of_date" name="transportation_drop_of_date[]" class="form-control">
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;display:none" id="transportation_Time_Div">
                                            <label for="">Estimate Time</label>
                                            <input type="text" id="transportation_total_Time" name="transportation_total_Time[]" class="form-control transportation_total_Time1" readonly style="padding: 10px;" value="">
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Select Trip Type</label>
                                            <select name="transportation_trip_type[]" id="slect_trip" class="form-control"  data-placeholder="Choose ...">
                                                <option value="">Select</option>
                                                <option value="One-Way">One-Way</option>
                                                <option value="Return">Return</option>
                                                <option value="All_Round">All Round</option>
                                            </select>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Vehicle Type</label>
                                            <select name="transportation_vehicle_type[]" id="transportation_vehicle_typeI" class="form-control"  data-placeholder="Choose ...">
                                                <option value="">Choose ...</option>
                                                <option value="Bus">Bus</option>
                                                <option value="Coach">Coach</option>
                                                <option value="Vain">Vain</option>
                                                <option value="Car">Car</option>
                                            </select>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">No Of Vehicle</label>
                                            <input type="text" id="transportation_no_of_vehicle" name="transportation_no_of_vehicle[]" class="form-control">
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Price Per Vehicle</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" id="transportation_price_per_vehicle" name="transportation_price_per_vehicle[]" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Total Vehicle Price</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" id="transportation_vehicle_total_price" name="transportation_vehicle_total_price[]" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Price Per Person</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" id="transportation_price_per_person" name="transportation_price_per_person[]" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Exchange Rate</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" name="transfer_exchange_rate_destination[]" id="transfer_exchange_rate_destination" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Price Per Vehicle</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T"></a></span>
                                                <input type="text" name="without_markup_price_converted_destination[]" id="without_markup_price_converted_destination" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Total Vehicle Price</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T"></a></span>
                                                <input type="text" name="transportation_vehicle_total_price_converted[]" id="transportation_vehicle_total_price_converted" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Price Per Person</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T"></a></span>
                                                <input type="text" name="transportation_price_per_person_converted[]" id="transportation_price_per_person_converted" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <!--Costing-->
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Vehicle Markup Type</label>
                                            <select name="vehicle_markup_type[]" id="vehicle_markup_type" class="form-control" onchange="vehicle_markup_OWandR()">
                                                <option value="">Markup Type</option>
                                                <option value="%">Percentage</option>
                                                <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                            </select>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Markup Value per Vehicle</label>
                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" class="form-control" id="vehicle_per_markup_value" name="vehicle_per_markup_value[]" onkeyup="vehicle_per_markup_OWandR()">
                                            </div>
                                        </div>
                                        
                                        <input type="text" class="form-control d-none" id="markup_price_per_vehicle_converted" name="markup_price_per_vehicle_converted[]" readonly>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Vehicle Markup Value</label>
                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" class="form-control" id="vehicle_markup_value" name="vehicle_markup_value[]" onkeyup="vehicle_markup_OWandR()" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Vehicle Total Price</label>
                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" class="form-control" id="vehicle_total_price_with_markup" name="vehicle_total_price_with_markup[]" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Vehicle Markup Value</label>
                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T"></a></span>
                                                <input type="text" class="form-control" id="vehicle_markup_value_converted" name="vehicle_markup_value_converted[]" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Vehicle Markup Price</label>
                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T"></a></span>
                                                <input type="text" class="form-control" id="vehicle_total_price_with_markup_converted" name="vehicle_total_price_with_markup_converted[]" readonly>
                                            </div>
                                        </div>
                                        <!--End Costing-->
                                        
                                        <input type="hidden" class="transfer_markup_type_invoice" name="transfer_markup_type_invoice[]">
                                        <input type="hidden" class="transfer_markup_invoice" name="transfer_markup_invoice[]">
                                        <input type="hidden" class="transfer_markup_price_invoice" name="transfer_markup_price_invoice[]">
                                
                                        <!--Return Transportation-->
                                        <div class="row" id="select_return" style="display:none;padding: 10px;">
                                            <h3>Return Details :</h3>
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Pick-up Location</label>
                                                <input type="text" id="return_transportation_pick_up_location" name="return_transportation_pick_up_location" class="form-control pickup_location">
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Drop-off Location</label>
                                                <input type="text" id="return_transportation_drop_off_location" name="return_transportation_drop_off_location" class="form-control dropof_location">
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Pick-up Date & Time</label>
                                                <input type="datetime-local" id="return_transportation_pick_up_date" name="return_transportation_pick_up_date" class="form-control">
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Drop-of Date & Time</label>
                                                <input type="datetime-local" id="return_transportation_drop_of_date" name="return_transportation_drop_of_date" class="form-control">
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;display:none" id="return_transportation_Time_Div">
                                                <label for="" style="width: 205px;">Estimate Time Return</label>
                                                <input type="text" id="return_transportation_total_Time" name="return_transportation_total_Time" class="form-control return_transportation_total_Time1" readonly style="padding: 10px;" value="">
                                            </div>
                                            
                                            <div class="col-xl-3" style="display:none;padding: 10px;">
                                                <label for="">Vehicle Type</label>
                                                <select name="return_transportation_vehicle_type" id="" class="form-control"  data-placeholder="Choose ...">
                                                    <option value="">Choose ...</option>
                                                    <option value="Bus">Bus</option>
                                                    <option value="Coach">Coach</option>
                                                    <option value="Vain">Vain</option>
                                                    <option value="Car">Car</option>
                                                </select>
                                            </div>
                                            
                                            <div class="col-xl-3" style="display:none;padding: 10px;">
                                                <label for="">No Of Vehicle</label>
                                                <input type="text" id="return_transportation_no_of_vehicle" name="return_transportation_no_of_vehicle" class="form-control">
                                            </div>
                                            
                                            <div class="col-xl-3" style="display:none;padding: 10px;">
                                                <label for="">Price Per Vehicle</label>
                                                <div class="input-group">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up"><?php echo $currency; ?></a></span>
                                                    <input type="text" id="return_transportation_price_per_vehicle" name="return_transportation_price_per_vehicle" class="form-control">
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-3" style="display:none;padding: 10px;">
                                                <label for="">Total Vehicle Price</label>
                                                <div class="input-group">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up"><?php echo $currency; ?></a></span>
                                                    <input type="text" id="return_transportation_vehicle_total_price" name="return_transportation_vehicle_total_price" class="form-control">
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-3" style="display:none;padding: 10px;">
                                                <label for="">Price Per Person</label>
                                                <div class="input-group">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up"><?php echo $currency; ?></a></span>
                                                    <input type="text" id="return_transportation_price_per_person" name="return_transportation_price_per_person" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div id="append_transportation"></div>
                                    
                                        <div class="mt-2" style="display:none;" id="add_more_destination">
                                            <a href="javascript:;" id="more_transportationI" class="btn btn-info" style="float: right;">Add More Destinations </a>
                                        </div>
                                    </div>
                                    
                                    @if($services[0] == '1' || $services[0] == 'transportation_tab')
                                        <div class="row" style="display:none;border:1px solid #ced4da;padding: 20px 20px 20px 20px;" id="transportation_main_divI"></div>
                                        
                                        <div class="col-xl-12" style="padding: 10px;">
                                            <label for="">Image</label>
                                            <input type="file" name="transportation_image" class="form-control">
                                            <img src="{{ asset('/public/uploads/package_imgs/'.$transportation_details_DS->transportation_image) }}" style="width:30%;" /> 
                                            <input type="text" name="transportation_image_else" class="form-control" value="{{ $transportation_details_DS->transportation_image ?? ''}}" readonly hidden>
                                        </div>
                                    @else
                                        <div class="row" style="display:none;border:1px solid #ced4da;padding: 20px 20px 20px 20px;" id="transportation_main_divI"></div>
                                    
                                        <div class="col-xl-12" style="padding: 10px;">
                                            <label for="">Image</label>
                                            <input type="file" name="transportation_image" class="form-control">
                                        </div>
                                    @endif
                                    
                                </div>
                            </div> 
                            <!--<a id="save_Transportation" class="btn btn-primary" name="submit">Save Transportation Details</a>-->
                        </div> 
                                                
                        <div class="tab-pane" id="Itinerary_details">
                            <div class="row">
                                
                                <div class="col-xl-12">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">What's Included In Package?</label>
                                        <textarea name="whats_included" class="form-control summernote" id="" cols="10" rows="0"></textarea>
                                        <!--<textarea name="whats_included" class="form-control" cols="10" rows="5"></textarea>-->
                                    </div>
                                </div>
                              
                                <div class="col-xl-12">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">What's Excluded In Package?</label>
                                        <textarea name="whats_excluded" class="form-control summernote" id="" cols="10" rows="0"></textarea>
                                        <!--<textarea name="whats_excluded" class="form-control" cols="10" rows="5"></textarea>-->
                                    </div>
                                </div>
                              
                                <div class="col-xl-12">
                                    <label for="">Cancellation Policy</label>
                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Cancellation Policy"></i>
                                    <textarea name="cancellation_policy" class="form-control" cols="5" rows="5"></textarea>
                                </div>
                                
                                <div class="col-xl-12" style="margin-top:15px">
                                    <div class="mb-3">
                                        <div class="row">
                                            <div class="col-xl-1">
                                                <input type="checkbox" id="Itinerary" data-switch="bool"/>
                                                <label for="Itinerary" data-on-label="On" data-off-label="Off"></label>
                                            </div>
                                            <div class="col-xl-3">
                                                Itinerary
                                                <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Add day to day Itinerary for this package"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                              
                                <div class="row" id="Itinerary_select" style="display:none">
                                    
                                    <div class="col-xl-6">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label">Title</label>
                                            <input type="text" id="simpleinput" name="Itinerary_title" class="form-control">
                                        </div>
                                    </div>
                                  
                                    <div class="col-xl-6">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label">Short Description</label>
                                            <input type="text" id="simpleinput" name="Itinerary_city" class="form-control">
                                        </div>
                                    </div>
                                  
                                    <div class="col-xl-12">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label">Content</label>
                                            <textarea name="Itinerary_content" class="form-control" id="" cols="10" rows="10"></textarea>
                                        </div>
                                    </div>
                                  
                                    <div class="" id="append_data"></div>
                                
                                    <div class="mb-3">
                                        <div class="btn btn-info" id="click_more_Itinerary">Add More</div>
                                    </div>
                                </div>

                                <div class="col-xl-12">
                                    <div class="mb-3">
                                        <div class="row">
                                            <div class="col-xl-1">
                                                <input type="checkbox" id="extra_price" data-switch="bool"/>
                                                <label for="extra_price" data-on-label="On" data-off-label="Off"></label>
                                            </div>
                                            <div class="col-xl-3 additional_Services">Additional Services
                                                <i class="dripicons-information" style="font-size: 17px;" id="additional_Services" data-bs-toggle="tooltip" data-bs-placement="right" title="Additional Services"></i>
                                            </div> 
                                        </div>
                                    </div>
                                </div>

                                <!-- extra price started -->
                                <div class="row" id="extraprice_select" style="display:none">
                                    
                                    <div class="col-xl-6">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label">Name</label>
                                            <input type="text" id="simpleinput" name="extra_price_name" class="form-control">
                                        </div>
                                    </div>
                                  
                                    <div class="col-xl-6">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label">Price</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append">
                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2">
                                                
                                                    </a>
                                                </span>
                                                <input type="text" id="simpleinput" name="extra_price_price" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                  
                                    <div class="col-xl-6">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label">Type</label>
                                            <select name="extra_price_type" id="" class="form-control">
                                                <option value="">Select Type</option>
                                                <option value="0">One-Time</option>
                                                <option value="1">Per-Hour</option>
                                                <option value="2">Per-Day</option>
                                            </select>
                                        </div>
                                    </div>
                                  
                                    <div class="col-xl-6">
                                        <div class="mb-3 mt-4">
                                            <div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="Price_per_person" name="extra_price_person">
                                                <label class="form-check-label" for="Price_per_person">Price per person</label>
                                            </div>
                                        </div>
                                    </div>
                            
                                    <div class="" id="append_data_extra_price"></div>
                            
                                    <div class="mb-3">
                                        <div class="btn btn-info" id="click_more_extra_price">Add More</div>
                                    </div>
                                    
                                </div>
                                <!-- extra price ended -->

                                <div class="col-xl-12">
                                    <div class="mb-3">
                                        <div class="row">
                                            <div class="col-xl-1">
                                                <input type="checkbox" id="faq" data-switch="bool"/>
                                                <label for="faq" data-on-label="On" data-off-label="Off"></label>
                                            </div>
                                            <div class="col-xl-3">
                                                FAQ
                                                <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Add common questions & answers for customers"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- faq started -->
                                <div class="row" id="faq_select" style="display:none">
                                    
                                    <div class="col-xl-6">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label">Title</label>
                                            <input type="text" id="simpleinput" name="faq_title" class="form-control">
                                        </div>
                                    </div>
                                    
                                    <div class="col-xl-6">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label">content</label>
                                            <textarea name="faq_content" class="form-control" id="" cols="10" rows="10"></textarea>
                                        </div>
                                    </div>
                                    
                                    <div class="" id="append_data_faq"></div>
                                    
                                    <div class="mb-3">
                                        <div class="btn btn-info" id="click_more_faq">Add More</div>   
                                    </div>
                                    
                                </div>
                                <!-- faq ended -->
                                
                            </div> 
                            <!--<a id="save_Itinerary" class="btn btn-primary" name="submit">Save Itinerar Details</a>-->
                        </div> 
                                                    
                        <div class="tab-pane" id="Extras_details" >
                        
                            <div class="row">
                                
                                <div class="col-xl-4" style="text-align:right;">
                                    <span>Markup on total price</span>
                                </div>
                                
                                <input type="hidden" id="markupSwitch" name="markupSwitch" value="single_markup_switch">
                                
                                <div class="col-xl-1">
                                    <input type="checkbox" id="switch2" data-switch="bool"/>
                                    <label for="switch2" data-on-label="On" data-off-label="Off"></label>
                                </div>
                                 
                                <div class="col-xl-7">
                                    <span>Markup on break down prices</span>
                                </div>
  
                                <div class="col-xl-12" id="markup_services">
                                    <div class="card">
                                        
                                        <div class="card-header">
                                            <h4 class="modal-title" id="standard-modalLabel">Markup on break down prices</h4>
                                        </div>
                                            
                                        <div id="" class="card-body">
                                            <div class="row">
                                                
                                                <div class="row" id="flights_cost" style="display:none;padding-bottom: 25px">
                                                    
                                                    <div class="col-xl-3">
                                                         <h4 class="" id="">Flights Cost</h4>
                                                    </div>
                                                    
                                                    <input type="hidden" name="acc_hotel_CityName[]">
                                                    <input type="hidden" name="acc_hotel_HotelName[]">
                                                    <input type="hidden" name="acc_hotel_CheckIn[]">
                                                    <input type="hidden" name="acc_hotel_CheckOut[]" >
                                                    <input type="hidden" name="acc_hotel_NoOfNights[]">
                                                    <input type="hidden" name="acc_hotel_Quantity[]">
                                                    
                                                    <div class="col-xl-9">
                                                        <input type="hidden" id="flight_Type_Costing" name="markup_Type_Costing[]" value="flight_Type_Costing" class="form-control">
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <input value="" type="text" id="flights_departure_code" readonly="" name="hotel_name_markup[]" class="form-control">
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <input value="" type="text" id="flights_arrival_code" readonly="" name="room_type[]" class="form-control">
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="flights_price_per_night" readonly="" name="without_markup_price_single[]" class="form-control">    
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group">
                                                            <input type="text" id="flights_prices" readonly="" name="without_markup_price[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2">
                                                            
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <select name="markup_type[]" id="markup_type" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                            <input type="text"  class="form-control" id="markup_value" name="markup[]">
                                                            <span class="input-group-btn input-group-append">
                                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="markup_value_markup_mrk">%</div></button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-1" style="display:none">
                                                        <input type="text" id="flights_exchage_rate_per_night" readonly="" name="exchage_rate_single[]" class="form-control">    
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="flights_exchage_rate_markup_total_per_night" readonly="" name="markup_total_per_night[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                            </span>
                                                        </div> 
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group">
                                                            <input type="text" id="total_markup" name="markup_price[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2">
                                                            
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                
                                                </div>
                                                
                                                <div id="append_accomodation_data_cost">
                                                    
                                                    @if($get_invoice->markup_details != null)
                                                        <?php
                                                            $count = 1;
                                                            $markup_details = $get_invoice->markup_details;
                                                            $markup_details = json_decode($markup_details);
                                                            foreach($markup_details as $details)
                                                            {
                                                                if($details->markup_Type_Costing == 'hotel_Type_Costing')
                                                                {
                                                        ?>
                                                                    <div class="row" id="costing_accI{{$count}}" style="margin-bottom:20px;">
                                                                        <input type="hidden" id="hotel_Type_Costing" name="markup_Type_Costing[]" value="hotel_Type_Costing" class="form-control">
                                                                    
                                                                        <input type="text" name="hotel_name_markup[]" hidden>
                                                                    
                                                                        @if(isset($get_invoice->accomodation_details) && $get_invoice->accomodation_details != null && $get_invoice->accomodation_details != '')
                                                                            <?php
                                                                                $accomodation_details=$get_invoice->accomodation_details;
                                                                                $accomodation_details=json_decode($accomodation_details);
                                                                            ?>
                                                                            @foreach($accomodation_details as $accomodation_detailsS)
                                                                                <div class="col-xl-12 d-none">
                                                                                    @if(isset($details->markup_price) && $details->markup_price != null && $details->markup_price != '')
                                                                                        @if($details->markup_price == $accomodation_detailsS->hotel_invoice_markup)
                                                                                            <h4> 
                                                                                                Accomodation Details {{ $accomodation_detailsS->hotel_city_name ?? '' }} - {{ $accomodation_detailsS->acc_hotel_name ?? '' }}
                                                                                                <a class="btn">
                                                                                                    (Quantity : <b style="color: #cdc0c0;">{{ $accomodation_detailsS->acc_qty ?? '' }}</b>)
                                                                                                    (Check in : <b style="color: #cdc0c0;">{{ $accomodation_detailsS->acc_check_in ?? '' }}</b>)
                                                                                                    (Check Out : <b style="color: #cdc0c0;">{{ $accomodation_detailsS->acc_check_out ?? '' }}</b>)
                                                                                                    (Nights : <b style="color: #cdc0c0;">{{ $accomodation_detailsS->acc_no_of_nightst ?? '' }}</b>)
                                                                                                </a>
                                                                                            </h4>
                                                                                        @endif
                                                                                    @endif
                                                                                </div>
                                                                            @endforeach
                                                                        @else
                                                                            <div class="col-xl-12 d-none"></div>
                                                                        @endif
                                                                        
                                                                        <div class="col-xl-12">
                                                                            <input type="hidden" name="acc_hotel_CityName[]" id="acc_hotel_CityName{{ $count }}" value="{{ $details->acc_hotel_CityName ?? '' }}">
                                                                            <input type="hidden" name="acc_hotel_HotelName[]" id="acc_hotel_HotelName{{ $count }}" value="{{ $details->acc_hotel_HotelName ?? '' }}">
                                                                            <input type="hidden" name="acc_hotel_CheckIn[]" id="acc_hotel_CheckIn{{ $count }}" value="{{ $details->acc_hotel_CheckIn ?? '' }}">
                                                                            <input type="hidden" name="acc_hotel_CheckOut[]" id="acc_hotel_CheckOut{{ $count }}" value="{{ $details->acc_hotel_CheckOut ?? '' }}">
                                                                            <input type="hidden" name="acc_hotel_NoOfNights[]" id="acc_hotel_NoOfNights{{ $count }}" value="{{ $details->acc_hotel_NoOfNights ?? '' }}">
                                                                            <input type="hidden" name="acc_hotel_Quantity[]" id="acc_hotel_Quantity{{ $count }}" value="{{ $details->acc_hotel_Quantity ?? '' }}">
                                                                            @if(isset($details->acc_hotel_CityName) && $details->acc_hotel_CityName != null && $details->acc_hotel_CityName != '')
                                                                                <h4> 
                                                                                    Accomodation Details {{ $details->acc_hotel_CityName ?? '' }} - {{ $accomodation_detailsS->acc_hotel_name ?? '' }}
                                                                                    <a class="btn">
                                                                                        (Quantity : <b style="color: #cdc0c0;">{{ $details->acc_hotel_Quantity ?? '' }}</b>)
                                                                                        (Check in : <b style="color: #cdc0c0;">{{ $details->acc_hotel_CheckIn ?? '' }}</b>)
                                                                                        (Check Out : <b style="color: #cdc0c0;">{{ $details->acc_hotel_CheckOut ?? '' }}</b>)
                                                                                        (Nights : <b style="color: #cdc0c0;">{{ $details->acc_hotel_NoOfNights ?? '' }}</b>)
                                                                                    </a>
                                                                                </h4>
                                                                            @else
                                                                                <h4 id="acc_cost_html_{{ $count }}">Accomodation Cost</h4>
                                                                            @endif
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3">
                                                                            <label>Room Type</label>
                                                                            <input type="text" id="hotel_acc_type_{{$count}}" readonly="" value="{{$details->room_type}}" name="room_type[]" class="form-control id_cot">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3">
                                                                            <label>Price Per Room/Night</label>
                                                                            <div class="input-group">
                                                                                <input type="text" id="hotel_acc_price_per_night_{{ $count }}" readonly="" name="without_markup_price_single[]" class="form-control" value="{{ $details->without_markup_price_single ?? '' }}">
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3">
                                                                            <label>Cost Price/Room</label>
                                                                            <div class="input-group">
                                                                                <input type="text" id="hotel_acc_price_{{$count}}" readonly="" value="{{$details->without_markup_price}}"  name="without_markup_price[]" class="form-control">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2"></a></span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3">
                                                                            <label>Markup Type</label>
                                                                            <select name="markup_type[]" onchange="hotel_markup_typeI({{$count}})" id="hotel_markup_types_{{$count}}" class="form-control">
                                                                                <option value="">Markup Type</option>
                                                                                <option <?php if($details->markup_type == '%') echo "selected";?> value="%">Percentage</option>
                                                                                <option <?php if($details->markup_type == $currency ) echo "selected";?> value="<?php echo $currency; ?>">Fixed Amount</option>
                                                                                <option <?php if($details->markup_type == 'per_Night' ) echo "selected";?> value="per_Night">Per Night</option>
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3 markup_value_Div_{{ $count }}" style="display:none;margin-top:10px">
                                                                            <label>Markup Value</label>
                                                                            <input type="hidden" id="" name="" class="form-control">
                                                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                                <input type="text" value="{{$details->markup}}"  class="form-control" id="hotel_markup_{{$count}}" name="markup[]" onkeyup="hotel_markup_funI({{ $count }})">
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="hotel_markup_mrk_{{$count}}" class="currency_value1">%</div></button>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3 exchnage_rate_Div_{{ $count }}" style="display:none;margin-top:10px">
                                                                            <label>Exchange Rate</label>
                                                                            <div class="input-group">
                                                                                <input type="text" id="hotel_exchage_rate_per_night_{{ $count }}" readonly="" name="exchage_rate_single[]" class="form-control" value="{{ $details->exchage_rate_single }}">
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3 markup_price_Div_{{ $count }}" style="display:none;margin-top:10px">
                                                                            <label>Markup Price</label>
                                                                            <div class="input-group">
                                                                                <input type="text" id="hotel_exchage_rate_markup_total_per_night_{{ $count }}" readonly="" name="markup_total_per_night[]" class="form-control" value="{{ $details->markup_total_per_night }}">
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                                                </span>
                                                                            </div> 
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3 markup_total_price_Div_{{ $count }}" style="display:none;margin-top:10px">
                                                                            <label>Markup Total Price</label>
                                                                            <div class="input-group">
                                                                                <input type="text" id="hotel_markup_total_{{$count}}" value="{{$details->markup_price}}" name="markup_price[]" class="form-control id_cot">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2"></a></span>
                                                                            </div> 
                                                                        </div>
                                                                    </div>
                                                        <?php
                                                                $count=$count+1;
                                                                }
                                                            }
                                                        ?>
                                                    @endif
                                                </div>
                                                
                                                <hr style="width: 98%;margin-left: 13px;margin-top: 10px;margin-bottom: 10px;color: black;"></hr>
                                                
                                                <div id="append_accomodation_data_cost1">
                                                    
                                                    @if($get_invoice->more_markup_details != null)
                                                        <?php
                                                            $count=1;
                                                            $more_markup_details=$get_invoice->more_markup_details;
                                                            $more_markup_details=json_decode($more_markup_details);
                                                            // dd($more_markup_details);
                                                            foreach($more_markup_details as $details)
                                                            {
                                                                if($details->more_markup_Type_Costing == 'more_hotel_Type_Costing')
                                                                {
                                                        ?>
                                                                    <div style="padding-bottom: 5px;" class="row click_deleteI_{{$count}}" id="click_deleteI_{{$count}}">
                                                                        
                                                                        @if(isset($get_invoice->accomodation_details_more) && $get_invoice->accomodation_details_more != null && $get_invoice->accomodation_details_more != '')
                                                                            <?php
                                                                                $accomodation_details_more=$get_invoice->accomodation_details_more;
                                                                                $accomodation_details_more=json_decode($accomodation_details_more);
                                                                                // dd($accomodation_details_more);
                                                                            ?>
                                                                            @foreach($accomodation_details_more as $accomodation_details_moreS)
                                                                                <div class="col-xl-12 d-none">
                                                                                    @if(isset($details->more_markup_price) && $details->more_markup_price != null && $details->more_markup_price != '')
                                                                                        @if($details->more_markup_price == $accomodation_details_moreS->more_hotel_invoice_markup)
                                                                                            <h4 class="" id="">
                                                                                                More Accomodation Cost {{ $accomodation_details_moreS->more_hotel_city ?? '' }} - <a id="new_MAHN_{{ $count }}">{{ $accomodation_details_moreS->more_acc_hotel_name ?? '' }}</a>
                                                                                                <a class="btn">
                                                                                                    (Quantity : <b style="color: #cdc0c0;">{{ $accomodation_details_moreS->more_acc_qty ?? '' }}</b>)
                                                                                                    (Check in : <b style="color: #cdc0c0;">{{ $accomodation_details_moreS->more_acc_check_in ?? '' }}</b>)
                                                                                                    (Check Out : <b style="color: #cdc0c0;">{{ $accomodation_details_moreS->more_acc_check_out ?? '' }}</b>)
                                                                                                    (Nights : <b style="color: #cdc0c0;">{{ $accomodation_details_moreS->more_acc_no_of_nightst ?? '' }}</b>)
                                                                                                </a>
                                                                                            </h4>
                                                                                        @endif
                                                                                    @endif
                                                                                </div>
                                                                            @endforeach
                                                                        @else
                                                                            <div class="col-xl-12 d-none"></div>
                                                                        @endif
                                                                        
                                                                        <input type="hidden" name="more_acc_hotel_CityName[]" id="more_acc_hotel_CityName{{ $count }}" value="{{ $details->more_acc_hotel_CityName ?? '' }}">
                                                                        <input type="hidden" name="more_acc_hotel_HotelName[]" id="more_acc_hotel_HotelName{{ $count }}" value="{{ $details->more_acc_hotel_HotelName ?? '' }}">
                                                                        <input type="hidden" name="more_acc_hotel_CheckIn[]" id="more_acc_hotel_CheckIn{{ $count }}" value="{{ $details->more_acc_hotel_CheckIn ?? '' }}">
                                                                        <input type="hidden" name="more_acc_hotel_CheckOut[]" id="more_acc_hotel_CheckOut{{ $count }}" value="{{ $details->more_acc_hotel_CheckOut ?? '' }}">
                                                                        <input type="hidden" name="more_acc_hotel_NoOfNights[]" id="more_acc_hotel_NoOfNights{{ $count }}" value="{{ $details->more_acc_hotel_NoOfNights ?? '' }}">
                                                                        <input type="hidden" name="more_acc_hotel_Quantity[]" id="more_acc_hotel_Quantity{{ $count }}" value="{{ $details->more_acc_hotel_Quantity ?? '' }}">
                                                                        
                                                                        <div class="col-xl-12">
                                                                            <input type="text" name="more_hotel_name_markup[]" hidden id="more_hotel_name_markup{{$count}}">
                                                                            @if(isset($details->more_acc_hotel_CityName) && $details->more_acc_hotel_CityName != null && $details->more_acc_hotel_CityName != '')
                                                                                <h4> 
                                                                                    More Accomodation Details {{ $details->more_acc_hotel_CityName ?? '' }} - <a id="new_MAHN_{{ $count }}">{{ $accomodation_details_moreS->more_acc_hotel_name ?? '' }}</a>
                                                                                    <a class="btn">
                                                                                        (Quantity : <b style="color: #cdc0c0;">{{ $details->more_acc_hotel_Quantity ?? '' }}</b>)
                                                                                        (Check in : <b style="color: #cdc0c0;">{{ $details->more_acc_hotel_CheckIn ?? '' }}</b>)
                                                                                        (Check Out : <b style="color: #cdc0c0;">{{ $details->more_acc_hotel_CheckOut ?? '' }}</b>)
                                                                                        (Nights : <b style="color: #cdc0c0;">{{ $details->more_acc_hotel_NoOfNights ?? '' }}</b>)
                                                                                    </a>
                                                                                </h4>
                                                                            @else
                                                                                <h4>
                                                                                    More Accomodation Cost {{ $details->more_acc_hotel_CityName ?? '' }} - <a id="new_MAHN_{{ $count }}"></a>
                                                                                    <a class="btn" id="more_acc_cost_html_{{ $count }}"></a>
                                                                                </h4>
                                                                            @endif
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3">
                                                                            <input type="hidden" id="more_hotel_Type_Costing" name="more_markup_Type_Costing[]" value="more_hotel_Type_Costing" class="form-control">
                                                                            <label>Room Type</label>
                                                                            <input type="text" id="more_hotel_acc_type_{{$count}}" readonly="" value="{{$details->more_room_type}}" name="more_room_type[]" class="form-control">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3">
                                                                            <label>Price Per Room/Night</label>
                                                                            <div class="input-group">
                                                                                <input type="text" id="more_hotel_acc_price_per_night_{{ $count }}" readonly="" name="more_without_markup_price_single[]" class="form-control" value="{{ $details->more_without_markup_price_single }}">
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                                                </span>        
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3">
                                                                            <label>Cost Price/Room</label>
                                                                            <div class="input-group">
                                                                                <input type="text" id="more_hotel_acc_price_{{$count}}" readonly="" value="{{$details->more_without_markup_price}}" name="more_without_markup_price[]" class="form-control">
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                                                </span>
                                                                                
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3">
                                                                            <label>Markup Type</label>
                                                                            <select name="more_markup_type[]" onchange="more_hotel_markup_type_accI({{$count}})" id="more_hotel_markup_types_{{$count}}" class="form-control">
                                                                                <option value="">Markup Type</option>
                                                                                <option <?php if($details->more_markup_type == '%' ) echo "selected";?> value="%">Percentage</option>
                                                                                <option <?php if($details->more_markup_type == $currency ) echo "selected";?> value="<?php echo $currency; ?>">Fixed Amount</option>
                                                                                <option <?php if($details->more_markup_type == 'per_Night' ) echo "selected";?> value="per_Night">Per Night</option>
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3 more_markup_value_Div_{{ $count }}" style="display:none;margin-top:10px">
                                                                            <label>Markup Value</label>
                                                                            <input type="hidden" id="" name="" class="form-control">
                                                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                                <input type="text"  class="form-control" id="more_hotel_markup_{{$count}}" value="{{$details->more_markup}}" name="more_markup[]" onkeyup="get_markup_invoice_price({{ $count }})">
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="more_hotel_markup_mrk_{{$count}}" class="currency_value1">%</div></button>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3 more_exchnage_rate_Div_{{ $count }}" style="display:none;margin-top:10px">
                                                                            <label>Exchange Rate</label>
                                                                            <div class="input-group">
                                                                                <input type="text" id="more_hotel_exchage_rate_per_night_{{ $count }}" readonly="" name="more_exchage_rate_single[]" class="form-control" value="{{ $details->more_exchage_rate_single }}">    
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                                                                </span>        
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3 more_markup_price_Div_{{ $count }}" style="display:none;margin-top:10px">
                                                                            <label>Markup Price</label>
                                                                            <div class="input-group">
                                                                                <input type="text" id="more_hotel_exchage_rate_markup_total_per_night_{{ $count }}" readonly="" name="more_markup_total_per_night[]" class="form-control" value="{{ $details->more_markup_total_per_night }}"> 
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3 more_markup_total_price_Div_{{ $count }}" style="display:none;margin-top:10px">
                                                                            <label>Markup Total Price</label>
                                                                            <div class="input-group">
                                                                                <input type="text" id="more_hotel_markup_total_{{$count}}"  name="more_markup_price[]" value="{{$details->more_markup_price}}" class="form-control">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a></span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                        <?php
                                                            $count=$count+1;
                                                                }
                                                            }
                                                        ?>
                                                    @endif
                                                </div>
                                                
                                                @if(isset($get_invoice->services) && $get_invoice->services != null && $get_invoice->services != '')
                                                    <?php $services = json_decode($get_invoice->services); ?>
                                                    @if($services[0] == 'transportation_tab' || $services[0] == '1')
                                                        <div class="row" id="transportation_cost">
                                                        
                                                            @if($get_invoice->markup_details != null)
                                                                <?php
                                                                    $markup_details = $get_invoice->markup_details;
                                                                    $markup_details = json_decode($markup_details);
                                                                ?>
                                                                @foreach($markup_details as $details)
                                                                    @if($details->markup_Type_Costing == 'transportation_Type_Costing')
                                                                    
                                                                    
                                                                        <div class="col-xl-3">
                                                                            <h4>Transportation Cost</h4>
                                                                        </div>
                                                                        
                                                                        <input type="hidden" name="acc_hotel_CityName[]">
                                                                        <input type="hidden" name="acc_hotel_HotelName[]">
                                                                        <input type="hidden" name="acc_hotel_CheckIn[]">
                                                                        <input type="hidden" name="acc_hotel_CheckOut[]" >
                                                                        <input type="hidden" name="acc_hotel_NoOfNights[]">
                                                                        <input type="hidden" name="acc_hotel_Quantity[]">
                                                                        
                                                                        <input type="hidden" name="tranf_no_of_vehicle[]" id="tranf_no_of_vehicle" value="{{ $details->tranf_no_of_vehicle ?? '' }}">
                                                                        <input type="hidden" name="tranf_price_per_vehicle[]" id="tranf_price_per_vehicle" value="{{ $details->tranf_price_per_vehicle ?? '' }}">
                                                                        <input type="hidden" name="tranf_price_all_vehicle[]" id="tranf_price_all_vehicle" value="{{ $details->tranf_price_all_vehicle ?? '' }}">
                                                                        
                                                                        <div class="col-xl-9">
                                                                            <input type="hidden" value="{{ $details->markup_Type_Costing ?? '' }}" id="transportation_Type_Costing" name="markup_Type_Costing[]" value="transportation_Type_Costing" class="form-control">  
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-2">
                                                                            <input type="text" value="{{ $details->hotel_name_markup ?? '' }}" id="transportation_pick_up_location_select" readonly="" name="hotel_name_markup[]" class="form-control">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-2">
                                                                            <input type="text" value="{{ $details->room_type ?? '' }}" id="transportation_drop_off_location_select" readonly="" name="room_type[]" class="form-control">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-2">
                                                                            <div class="input-group">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2T"></a></span>
                                                                                <input type="text" value="{{ $details->without_markup_price ?? '' }}" id="transportation_price_per_person_select" readonly="" name="without_markup_price[]" class="form-control">
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-2">
                                                                            <select name="markup_type[]" id="transportation_markup_type" class="form-control">
                                                                                <option value="">Markup Type</option>
                                                                                <option <?php if($details->markup_type == '%') echo 'selected'; ?> value="%">Percentage</option>
                                                                                <option <?php if($details->markup_type == $currency) echo 'selected'; ?> value="<?php echo $currency; ?>">Fixed Amount</option>
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-2">
                                                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2T"></a></span>
                                                                                <input type="text" value="{{ $details->markup ?? '' }}" class="form-control" id="transportation_markup" name="markup[]" readonly>
                                                                                <span class="input-group-btn input-group-append d-none">
                                                                                    <button class="btn btn-primary bootstrap-touchspin-up" type="button">
                                                                                        <div id="transportation_markup_mrk currency_value_exchange_2T">
                                                                                            <?php 
                                                                                                if($details->markup_type == '%'){
                                                                                                    echo '%';
                                                                                                }else if($details->markup_type == $currency){
                                                                                                    echo $currency;
                                                                                                }else{
                                                                                                    echo '';
                                                                                                }
                                                                                            ?>
                                                                                        </div>
                                                                                    </button>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-2">
                                                                            <div class="input-group">
                                                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2T"></a></span>
                                                                                <input type="text" value="{{ $details->markup_price ?? '' }}" id="transportation_markup_total" name="markup_price[]" class="form-control" readonly>
                                                                            </div>
                                                                        </div>
                                                                    
                                                                    @endif
                                                                @endforeach
                                                            @endif
                                                            
                                                        </div>
                                                    @endif
                                                @endif
                                                
                                                @if(isset($get_invoice->visa_type) && $get_invoice->visa_type != null && $get_invoice->visa_type != '')
                                                    <div class="row" id="visa_cost">
                                                        <div class="col-xl-3">
                                                            <h4 class="" id="">Visa Cost</h4>
                                                        </div>
                                                        <input type="hidden" name="acc_hotel_CityName[]">
                                                        <input type="hidden" name="acc_hotel_HotelName[]">
                                                        <input type="hidden" name="acc_hotel_CheckIn[]">
                                                        <input type="hidden" name="acc_hotel_CheckOut[]" >
                                                        <input type="hidden" name="acc_hotel_NoOfNights[]">
                                                        <input type="hidden" name="acc_hotel_Quantity[]">
                                                        <?php $markup_detailsE = $get_invoice->markup_details; ?>
                                                        @if(isset($markup_detailsE) && $markup_detailsE != null && $markup_detailsE != '')
                                                            <?php $markup_details     = json_decode($markup_detailsE); ?>
                                                            @foreach($markup_details as $value)
                                                                <?php $markup_Type_Costing = $value->markup_Type_Costing; ?>
                                                                @if(isset($markup_Type_Costing) && $markup_Type_Costing != null && $markup_Type_Costing != '')
                                                                    @if($markup_Type_Costing == 'visa_Type_Costing')
                                                                        <div class="col-xl-9">
                                                                            <input type="hidden" id="visa_Type_Costing" name="markup_Type_Costing[]" value="{{ $markup_Type_Costing }}" class="form-control">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3">
                                                                            <input readonly type="text" id="visa_type_select" name="hotel_name_markup[]" class="form-control" value="{{ $value->hotel_name_markup }}">
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-2" style="display:none">
                                                                            <div class="input-group">
                                                                                <input type="text" id="visa_price_per_night" readonly="" name="without_markup_price_single[]" class="form-control">    
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-3">
                                                                            <div class="input-group">
                                                                                <input readonly type="text" id="visa_price_select" name="without_markup_price[]" class="form-control" value="{{ $value->without_markup_price }}">
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <a class="btn btn-primary bootstrap-touchspin-up">
                                                                                       <?php echo $currency; ?>
                                                                                    </a>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-2">
                                                                            <select name="markup_type[]" id="visa_markup_type" class="form-control">
                                                                                <option <?php if($value->markup_type == '') echo "selected" ?> value="">Markup Type</option>
                                                                                <option <?php if($value->markup_type == '%') echo "selected" ?> value="%">Percentage</option>
                                                                                <option <?php if($value->markup_type == $currency) echo "selected" ?> value="<?php echo $currency; ?>">Fixed Amount</option>
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-2">
                                                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                                <input type="text" class="form-control" id="visa_markup" name="markup[]" value="{{ $value->markup }}">
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <button class="btn btn-primary bootstrap-touchspin-up" type="button">
                                                                                        <div id="visa_mrk">
                                                                                            <?php 
                                                                                                if($value->markup_type == '%'){
                                                                                                    echo '%';
                                                                                                }else if($value->markup_type == $currency){
                                                                                                    echo $currency;
                                                                                                }else{
                                                                                                    echo '';
                                                                                                }
                                                                                            ?>
                                                                                        </div>
                                                                                    </button>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-1" style="display:none">
                                                                            <input type="text" id="visa_exchage_rate_per_night" readonly="" name="exchage_rate_single[]" class="form-control">    
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-2" style="display:none">
                                                                            <div class="input-group">
                                                                                <input type="text" id="visa_exchage_rate_markup_total_per_night" readonly="" name="markup_total_per_night[]" class="form-control">
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                                                </span>
                                                                            </div> 
                                                                        </div>
                                                                        
                                                                        <div class="col-xl-2">
                                                                            <div class="input-group">
                                                                                <input type="text" id="total_visa_markup" name="markup_price[]" class="form-control" value="{{ $value->markup_price }}">
                                                                                <span class="input-group-btn input-group-append">
                                                                                    <a class="btn btn-primary bootstrap-touchspin-up">
                                                                                       <?php echo $currency; ?>
                                                                                    </a>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    @endif
                                                                @endif
                                                            @endforeach
                                                        @endif
                                                        
                                                    </div>
                                                    
                                                    <div id="more_visa_cost_div" class="row">
                                                        <input type="hidden" name="acc_hotel_CityName[]">
                                                        <input type="hidden" name="acc_hotel_HotelName[]">
                                                        <input type="hidden" name="acc_hotel_CheckIn[]">
                                                        <input type="hidden" name="acc_hotel_CheckOut[]" >
                                                        <input type="hidden" name="acc_hotel_NoOfNights[]">
                                                        <input type="hidden" name="acc_hotel_Quantity[]">
                                                        <?php $markup_detailsE = $get_invoice->markup_details; ?>
                                                        @if(isset($markup_detailsE) && $markup_detailsE != null && $markup_detailsE != '')
                                                            <?php $markup_details = json_decode($markup_detailsE); $m_VC_count = 1; ?>
                                                            @foreach($markup_details as $value)
                                                                <?php $markup_Type_Costing = $value->markup_Type_Costing; ?>
                                                                @if(isset($markup_Type_Costing) && $markup_Type_Costing != null && $markup_Type_Costing != '')
                                                                    @if($markup_Type_Costing == 'more_visa_Type_Costing')
                                                                        <div id="more_visa_cost_{{ $m_VC_count }}" class="row">
                                                                            <div class="col-xl-3">
                                                                                <h4 class="" id="">More Visa Cost</h4>
                                                                            </div>
                                                                            
                                                                            <div class="col-xl-9">
                                                                                <input type="hidden" id="more_visa_Type_Costing_{{ $m_VC_count }}" name="markup_Type_Costing[]" value="{{ $markup_Type_Costing }}" class="form-control">
                                                                            </div>
                                                                            
                                                                            <div class="col-xl-3">
                                                                                <input readonly type="text" id="more_visa_type_select_{{ $m_VC_count }}" name="hotel_name_markup[]" class="form-control" value="{{ $value->hotel_name_markup }}">
                                                                            </div>
                                                                            
                                                                            <div class="col-xl-3">
                                                                                <div class="input-group">
                                                                                    <input readonly type="text" id="more_visa_price_select_{{ $m_VC_count }}" name="without_markup_price[]" class="form-control" value="{{ $value->without_markup_price }}">
                                                                                    <span class="input-group-btn input-group-append">
                                                                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                                                                           <?php echo $currency; ?>
                                                                                        </a>
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            <div class="col-xl-2">
                                                                                <select name="markup_type[]" id="more_visa_markup_type_{{ $m_VC_count }}" class="form-control">
                                                                                    <option <?php if($value->markup_type == '') echo "selected" ?> value="">Markup Type</option>
                                                                                    <option <?php if($value->markup_type == '%') echo "selected" ?> value="%">Percentage</option>
                                                                                    <option <?php if($value->markup_type == $currency) echo "selected" ?> value="<?php echo $currency; ?>">Fixed Amount</option>
                                                                                </select>
                                                                            </div>
                                                                            
                                                                            <div class="col-xl-2">
                                                                                <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                                    <input type="text" class="form-control" id="more_visa_markup_{{ $m_VC_count }}" name="markup[]" value="{{ $value->markup }}">
                                                                                    <span class="input-group-btn input-group-append">
                                                                                        <button class="btn btn-primary bootstrap-touchspin-up" type="button">
                                                                                            <div id="visa_mrk">
                                                                                                <?php 
                                                                                                    if($value->markup_type == '%'){
                                                                                                        echo '%';
                                                                                                    }else if($value->markup_type == $currency){
                                                                                                        echo $currency;
                                                                                                    }else{
                                                                                                        echo '';
                                                                                                    }
                                                                                                ?>
                                                                                            </div>
                                                                                        </button>
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            <div class="col-xl-2">
                                                                                <div class="input-group">
                                                                                    <input type="text" id="more_total_visa_markup_{{ $m_VC_count }}" name="markup_price[]" class="form-control" value="{{ $value->markup_price }}">
                                                                                    <span class="input-group-btn input-group-append">
                                                                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                                                                           <?php echo $currency; ?>
                                                                                        </a>
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <?php $m_VC_count++; ?>
                                                                    @endif
                                                                @endif
                                                            @endforeach
                                                        @endif
                                                    </div>
                                                @else
                                                    <div class="row" id="visa_cost" style="display:none;">
                                                        <div class="col-xl-3">
                                                            <h4 class="" id="">Visa Cost</h4>
                                                        </div>
                                                        <input type="hidden" name="acc_hotel_CityName[]">
                                                        <input type="hidden" name="acc_hotel_HotelName[]">
                                                        <input type="hidden" name="acc_hotel_CheckIn[]">
                                                        <input type="hidden" name="acc_hotel_CheckOut[]" >
                                                        <input type="hidden" name="acc_hotel_NoOfNights[]">
                                                        <input type="hidden" name="acc_hotel_Quantity[]">
                                                    
                                                        <div class="col-xl-9">
                                                            <input type="hidden" id="visa_Type_Costing" name="markup_Type_Costing[]" value="visa_Type_Costing" class="form-control">
                                                        </div>
                                                        
                                                        <div class="col-xl-3">
                                                            <input readonly type="text" id="visa_type_select" name="hotel_name_markup[]" class="form-control">
                                                        </div>
                                                        
                                                        <div class="col-xl-2" style="display:none">
                                                            <div class="input-group">
                                                                <input type="text" id="visa_price_per_night" readonly="" name="without_markup_price_single[]" class="form-control">    
                                                                <span class="input-group-btn input-group-append">
                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-xl-3">
                                                            <div class="input-group">
                                                                <input readonly type="text" id="visa_price_select" name="without_markup_price[]" class="form-control">
                                                                <span class="input-group-btn input-group-append">
                                                                    <a class="btn btn-primary bootstrap-touchspin-up">
                                                                       <?php echo $currency; ?>
                                                                    </a>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-xl-2">
                                                            <select name="markup_type[]" id="visa_markup_type" class="form-control">
                                                                <option value="">Markup Type</option>
                                                                <option value="%">Percentage</option>
                                                                <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                            </select>
                                                        </div>
                                                        
                                                        <div class="col-xl-2">
                                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                <input type="text" class="form-control" id="visa_markup" name="markup[]">
                                                                <span class="input-group-btn input-group-append">
                                                                    <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="visa_mrk">%</div></button>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-xl-1" style="display:none">
                                                            <input type="text" id="visa_exchage_rate_per_night" readonly="" name="exchage_rate_single[]" class="form-control">    
                                                        </div>
                                                        
                                                        <div class="col-xl-2" style="display:none">
                                                            <div class="input-group">
                                                                <input type="text" id="visa_exchage_rate_markup_total_per_night" readonly="" name="markup_total_per_night[]" class="form-control">
                                                                <span class="input-group-btn input-group-append">
                                                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                                </span>
                                                            </div> 
                                                        </div>
                                                        
                                                        <div class="col-xl-2">
                                                            <div class="input-group">
                                                                <input type="text" id="total_visa_markup" name="markup_price[]" class="form-control">
                                                                <span class="input-group-btn input-group-append">
                                                                    <a class="btn btn-primary bootstrap-touchspin-up">
                                                                       <?php echo $currency; ?>
                                                                    </a>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    
                                                    </div>
                                                    
                                                    <div id="more_visa_cost_div"></div>
                                                @endif
                                                    
                                            </div>    
                                        </div>
                                            
                                    </div>
                                </div>
                            </div>

                            <div class="row" >
                                <div class="col-xl-12" style="display:none;" id="all_services_markup">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="modal-title" id="standard-modalLabel">Markup on total price</h4>
                                            <div class="card-body">
                                               <div class="row">
                                                   
                                                    <div class="col-xl-6">
                                                        <div class="mb-3">
                                                            <label for="all_markup_type" class="form-label">Markup Type</label>
                                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Markup type"></i>
                                                             <select class="form-control" id="all_markup_type" name="all_markup_type" >
                                                                <option>Select Markup Type</option>
                                                                <option value="%">Percentage</option>
                                                                <option value="<?php echo $currency; ?>">Number</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                
                                                    <div class="col-xl-6">
                                                        <div class="mb-3">
                                                            <label for="all_markup_add" class="form-label">All Markup</label>
                                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="All Markup"></i>
                                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                <input type="text"  class="form-control" id="all_markup_add" name="all_markup_add">
                                                                <span class="input-group-btn input-group-append">
                                                                    <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="select_mrk">%</div></button>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                
                                               </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            
                            <div id="accomodation_price_hide" class="row mt-2" style="display:none">
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Quad Cost Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;"  id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Quad Cost Price"></i>
                                        <div class="input-group">
                                            <input class="form-control" id="quad_cost_price" value="{{$get_invoice->quad_cost_price ?? ''}}" name="quad_cost_price" />
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2">
                                                   
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Triple Cost Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Triple Cost Price"></i>
                                        <div class="input-group">
                                            <input class="form-control" id="triple_cost_price" value="{{$get_invoice->triple_cost_price ?? ''}}" name="triple_cost_price" />
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2">
                                                   
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Double Cost Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Double Cost Price"></i>
                                        <div class="input-group">
                                            <input class="form-control" id="double_cost_price" value="{{$get_invoice->double_cost_price ?? ''}}" name="double_cost_price" />
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2">
                                                   
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            
                            </div>
                        
                            <div class="row" id="sale_pr" style="display:none">
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label quad_grand_total_amount">Quad Sale Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Quad Sale Price"></i>
                                        
                                        <div class="input-group">
                                            <!--<input class="form-control" id="quad_grand_total_amount" name="quad_grand_total_amount" />-->
                                            <input type="text" name="quad_grand_total_amount_single" value="{{$get_invoice->quad_grand_total_amount ?? ''}}" class="form-control" id="quad_grand_total_amount">
                                            
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2">
                                                          
                                                        </a>
                                                    </span>
                                            <div class="invalid-feedback">
                                                This Field is Required
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="simpleinput triple_grand_total_amount" class="form-label">Triple Sale Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Triple Sale Price"></i>
                                        <div class="input-group">
                                            <!--<input class="form-control" id="triple_grand_total_amount" name="triple_grand_total_amount" />-->
                                            <input type="text" name="triple_grand_total_amount_single" value="{{$get_invoice->triple_grand_total_amount ?? ''}}" class="form-control" id="triple_grand_total_amount">
                                            
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2">
                                                          
                                                        </a>
                                                    </span>
                                            <div class="invalid-feedback">
                                                This Field is Required
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="simpleinput double_grand_total_amount" class="form-label">Double Sale Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Double Sale Price"></i>
                                        <div class="input-group">
                                            <!--<input class="form-control" id="double_grand_total_amount" name="double_grand_total_amount" />-->
                                            <input type="text" name="double_grand_total_amount_single" value="{{$get_invoice->double_grand_total_amount ?? ''}}" class="form-control" id="double_grand_total_amount">
                                            
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_2">
                                                          
                                                        </a>
                                                    </span>
                                            <div class="invalid-feedback">
                                                This Field is Required
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                            
                            <div class="row" style="display:none;" id="markup_seprate_services">
                                    <div class="col-xl-4">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label quad_markup">Quad Sale Price</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Quad Sale Price"></i>
                                            <input class="form-control" id="quad_markup" name="quad_grand_total_amount" />
                                            <!--<input type="text" name="quad_grand_total_amount" class="form-control" id="quad_markup" required>-->
                                            <!--<div class="invalid-feedback">-->
                                            <!--    This Field is Required-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                    <div class="col-xl-4">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label triple_markup">Triple Sale Price</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Triple Sale Price"></i>
                                            <input class="form-control" id="triple_markup" name="triple_grand_total_amount" />
                                            <!--<input type="text" name="triple_grand_total_amount" class="form-control" id="triple_markup" required>-->
                                            <!--<div class="invalid-feedback">-->
                                            <!--    This Field is Required-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                    <div class="col-xl-4">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label double_markup">Double Sale Price</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Double Sale Price"></i>
                                            <input class="form-control" id="double_markup" name="double_grand_total_amount" />
                                            <!--<input type="text" name="double_grand_total_amount" class="form-control" id="double_markup" required>-->
                                            <!--<div class="invalid-feedback">-->
                                            <!--    This Field is Required-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                </div>
                                
                            <div class="row">
    
                                <div class="col-xl-6">
                                    <div class="mb-3">
                                         <label for="simpleinput" class="form-label">Payment Methods</label>
                                         <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payment GateWay"></i>
                                         <select class="form-control" id="payment_gateways" name="payment_gateways">
                                             <option value="">Select Payment Gateway</option>
                                             @if(isset($payment_gateways))
                                             @foreach($payment_gateways as $payment_gateways)
                                              <option <?php if($get_invoice->payment_gateways = $payment_gateways->payment_gateway_title) echo 'selected'; ?> value="{{$payment_gateways->payment_gateway_title}}">{{$payment_gateways->payment_gateway_title}}</option>
                                              @endforeach
                                              @endif
                                         </select>
                                    
                                    </div>
                                </div>
                                
                                <div class="col-xl-6">
                                    <div class="mb-3">
                                        
                                        
                                    <?php //dd($get_invoice->payment_modes); ?>
                                    
                                         <label for="simpleinput" class="form-label">Payment Mode</label>
                                         <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payment Mode"></i>
                                         <select class="select2 form-control select2-multiple external_packages" data-toggle="select2" multiple="multiple" id="payment_modes" name="payment_modes[]">
                                                <option value="">Select Payment Mode</option>
                                                @if(isset($get_invoice->payment_modes) && $get_invoice->payment_modes != null && $get_invoice->payment_modes != '' && $get_invoice->payment_modes != 'null')
                                                    <?php $payment_modesDB = json_decode($get_invoice->payment_modes); //dd($payment_modesDB); ?>
                                                    @foreach($payment_modesDB as $payment_modesDB1)
                                                        @if(isset($payment_modes))
                                                            @foreach($payment_modes as $payment_modes1)
                                                                <option <?php if($payment_modesDB1 == $payment_modes1->payment_mode) echo 'selected'; ?> value="{{$payment_modes1->payment_mode}}">{{$payment_modes1->payment_mode}}</option>
                                                            @endforeach
                                                        @endif
                                                    @endforeach
                                                @else
                                                    @if(isset($payment_modes))
                                                        @foreach($payment_modes as $payment_modes1)
                                                            <option value="{{$payment_modes1->payment_mode}}">{{$payment_modes1->payment_mode}}</option>
                                                        @endforeach
                                                    @endif
                                                @endif
                                         </select>
                                    
                                     
                                      
                                    
                                     
                                     
                                    </div>
                                </div>
                            
                                <div class="col-xl-12">
                                    <label for="">Payment Instructions</label>
                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payment Instructions"></i>
                                    <textarea name="checkout_message" class="form-control" cols="5" rows="5" value="{{ $account_No }}">{{ $account_No }}</textarea>
                                </div>
                            
                            </div>
      
                            <!--<a id="save_Costing" class="btn btn-primary" name="submit">Save Costing Details</a>-->
                            <button style="float: right;width: 100px;margin-top: 10px;" type="submit" name="submit" class="btn btn-info deletButton">Submit</button>
                        </div>
                        
                        <ul class="list-inline mb-0 wizard" style="margin-top:60px;">
                            <li class="previous list-inline-item">
                                <a href="javascript:void(0);" style="width: 100px;" class="btn btn-info">Previous</a>
                            </li>
                            <li class="next list-inline-item float-end">
                                <a href="javascript:void(0);" style="width: 100px;" class="btn btn-info">Next</a>
                            </li>
                        </ul>
                                                
                    </div>
                    
                </div> 
            </form>
        <!--</div>-->
    </div>
</div>

@endsection

@section('scripts')

<script src="https://maps.googleapis.com/maps/api/js?libraries=places&callback=initAutocomplete&language=nl&output=json&key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY" async defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.20/summernote-bs5.min.js" integrity="sha512-6F1RVfnxCprKJmfulcxxym1Dar5FsT/V2jiEUvABiaEiFWoQ8yHvqRM/Slf0qJKiwin6IDQucjXuolCfCKnaJQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script type="text/javascript">

    $(document).ready(function() {
        var value_c = $("#currency_conversion1").val();
        const usingSplit = value_c.split(' ');
        var value_1 = usingSplit['0'];
        var value_2 = usingSplit['2'];
        exchange_currency_funs(value_1,value_2);
        var attr_conversion_type = $("#currency_conversion1").find('option:selected').attr('attr_conversion_type');
        if(attr_conversion_type != 0){
            $("#select_exchange_type").val(attr_conversion_type);
        }
        
        $('.visa_C_S').empty();
        $('.visa_C_S').html(value_1);
        
        $('.more_visa_C_S').empty();
        $('.more_visa_C_S').html(value_1);
    });

    $(document).ready(function() {
        $('.summernote').summernote({});
    });
    
    $("#destination").on('click',function(){
        $("#destination").slideToggle();
        $("#select_destination").css('display','');
    });
    
</script>

<script>
$(document).ready(function() {
    var ifchecked=$('#NotIncluded').prop('checked', true);
 
if(ifchecked)
{
  $('#NotIncluded_with_price').fadeIn();   
}
});
$(document).on('click','#NotIncluded' ,function(){

 
 $('#NotIncluded_with_price').fadeIn(); 
});
$(document).on('click','#Included' ,function(){
 
 $('#NotIncluded_with_price').fadeOut(); 
});

$('#NotIncluded_with_price_meal').keyup(function() {
    var NotIncluded_with_price =  $('#NotIncluded_with_price_meal').val();
    console.log('NotIncluded_with_price' + NotIncluded_with_price);
    var hotel_meal_types=$('.hotel_meal_types').val();
    $('#meal_type').val(hotel_meal_types);
    $('#meal_type_with_out_markup_price').val(NotIncluded_with_price);
});
$(document).on('change','#meal_type_with_markup' ,function(){
  var vale = $('#meal_type_with_markup option:selected').val();
  console.log('vale'+vale);
  $('#meal_markup_mrk').text(vale);
  
});

    $('#meal_type_with_markup_amout').keyup(function() {
            var with_out_markup_price = $('#meal_type_with_out_markup_price').val();
            var meal_type_with_markup  = $('#meal_type_with_markup').val();
            var markup_price = $('#meal_type_with_markup_amout').val();
            if(meal_type_with_markup == '%')
            {
               
               
                    var total1 = (with_out_markup_price * markup_price/100) + parseFloat(with_out_markup_price);
                    var total = total1.toFixed(2);
                    $('#meal_type_with_markup_sale_amout').val(total);
                   
                
            }
            else
            {
                
                    var total1 = parseFloat(with_out_markup_price) + parseFloat(markup_price);
                    var total = total1.toFixed(2);
                    $('#meal_type_with_markup_sale_amout').val(total);
                    
                
            }
        });

 //alert(val);
    $(document).on('change','#select_services' ,function(){
  var val = $('#select_services option:selected').val();
 //alert(val);
 if(val == 'flights_tab')
 {
     $("#accomodation_price_hide").css('display','none');
     $("#sale_pr").css('display','none');
 }
 if(val == 'visa_tab')
 {
     $("#accomodation_price_hide").css('display','none');
     $("#sale_pr").css('display','none');
 }
 if(val == 'transportation_tab')
 {
      $("#accomodation_price_hide").css('display','none');
     $("#sale_pr").css('display','none');
 }
  

})


    function validate1(id) {
    	$('.file_error'+id+'').html("");
    	$('.gallery_imagesP'+id+'').css("border-color","#F0F0F0");
    	var file_size = $('.gallery_imagesP'+id+'')[0].files[0].size;
    	if(file_size > 100000) {
    		$('.file_error'+id+'').html("File size is greater than 100kb");
    		$('.gallery_imagesP'+id+'').css("border-color","#FF0000");
    		return false;
    	} 
    	return true;
    }
    
    function selectServices(){
        var selectedServices = $('#select_services').val();
        
        $.each(selectedServices, function(key, value) {
            if(value != null && value != ''){
                if((value == '1') || (value == 'accomodation_tab')){
                    $('.more_Div_Acc_All').css('display','');
                    $('.no_of_Nights_Other').html('No Of Nights');
                    $('.visa_type_select').css('display','');
                }else if(value == 'visa_tab'){
                    $('.visa_type_select').css('display','none');
                    $('.more_Div_Acc_All').css('display','none');
                }else{
                    $('.more_Div_Acc_All').css('display','none');
                    $('.no_of_Nights_Other').html('Total Duration');
                    $('.visa_type_select').css('display','');
                }
            }
        });
        
        const allServicesSelect = selectedServices.find(element => element == 1);
        
        if(allServicesSelect){
            $(".accomodation_tab").css('display','block');
            $(".flights_tab").css('display','block');
            $(".visa_tab").css('display','block');
            $(".transportation_tab").css('display','block');
        }else{
            $(".accomodation_tab").css('display','none');
            $(".flights_tab").css('display','none');
            $(".visa_tab").css('display','none');
            $(".transportation_tab").css('display','none');
            for(var i=0; i < selectedServices.length; i++){
                $("."+selectedServices[i]+"").css('display','flex');
            }
        }
    }
    
    var passengerCounter = 1;
    $('#no_of_pax_days').on('change',function(){
        var no_of_pax_days = $('#no_of_pax_days').val();
        var prev_value = $('#no_of_pax_prev').val();
        
        var difference = no_of_pax_days - prev_value;
        
        passengerCounter = +passengerCounter + +difference
         
         
         for(var i = prev_value; i<=no_of_pax_days; i++){
             id = +i + +1;
             console.log('id is now '+id);
         }
         
         $('#no_of_pax_prev').val(no_of_pax_days);
         var passengerHtml = `<div class="row other_passengers" style="border: 1px solid #ebebeb;padding: 1rem;border-radius: 6px;">
                                            <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label no_of_pax_days">First Name</label>
                                                    <input type="text" name="lead_fname" class="form-control" required>
                                                </div>
                                            </div>
                                            
                                             <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label no_of_pax_days">Last Name</label>
                                                    <input type="text" name="lead_fname" class="form-control" required>
                                                </div>
                                            </div>
                                            
                                                    
                                            <div class="col-xl-4">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label no_of_pax_days">Select Nationality</label>
                                                     <select type="text" class="form-control select2 " name="Country"  data-placeholder="Choose ...">
                                                        @foreach($all_countries as $country_res)
                                                            <option value="{{$country_res->id}}" id="categoriesPV" required>{{$country_res->name}}</option>
                                                           
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-2" >
                                                <div class="mb-3">
                                                     <p style="margin-top: 2.2rem;">Gender</p>
                                                </div>
                                            </div>
                                            
                                               
                                            <div class="col-2">
                                              <div class="form-check" style="margin-top: 2.2rem;">
                                              <input class="form-check-input" type="radio" name="gender" value="male"  id="flexRadioDefault3">
                                              <label class="form-check-label" for="flexRadioDefault3">
                                                Male
                                              </label>
                                            </div>
                                            
                                            </div>
                                            <div class="col-2" style="margin-top: 2.2rem;">
                                                <div class="form-check">
                                              <input class="form-check-input" type="radio" name="gender" value="female"  id="flexRadioDefault4">
                                              <label class="form-check-label" for="flexRadioDefault4">
                                                Female
                                              </label>
                                            </div>
                                            </div>
                                        </div>`
    })
    
</script>

<!--Package Save-->
<script>
        
    $('#save_Package').on('click',function(e){
        e.preventDefault();
        
        // var data = $('#formP').serialize();
        // console.log(data);
        var title = $(".titleP").val();
        var no_of_pax_days = $(".no_of_pax_days").val();
        var starts_rating = $(".starts_rating").val();
        var currency_symbol = $(".currency_symbol").val();
        var content = $("#snow-editor").val();
        var start_date = $(".start_date").val();
        var end_date = $(".end_date").val();
        var time_duration = $(".time_duration").val();
        var categories = $(".categories").val();
        var tour_feature = $(".tour_feature").val();
        var defalut_state = $(".defalut_state").val();
        var tour_featured_image = $(".tour_featured_imageP").val();
        // console.log(tour_featured_image);
        var tour_banner_image = $(".tour_banner_imageP").val();
        // console.log(tour_banner_image);
        var tour_publish = $(".tour_publish").val();
        var tour_author = $(".tour_author").val();
        var external_packages = $(".external_packages").val();
        // console.log(external_packages);
        var gallery_images = $('.gallery_imagesP').val();
        // console.log(gallery_images);
        $.ajax({    
            type: "POST",
            url: "save_Package",
            data:{
                "_token"                : "{{ csrf_token() }}",
                // 'data'                  : data,
                'title'                 : title,
                'no_of_pax_days'        : no_of_pax_days,
                'starts_rating'         : starts_rating,
                'currency_symbol'       : currency_symbol,
                'content'               : content,
                'start_date'            : start_date,
                'end_date'              : end_date,
                'time_duration'         : time_duration,
                'categories'            : categories,
                'tour_feature'          : tour_feature,
                'defalut_state'         : defalut_state,
                'tour_featured_image'   : tour_featured_image,
                'tour_banner_image'     : tour_banner_image,
                'tour_publish'          : tour_publish,
                'tour_author'           : tour_author,
                'external_packages'     : external_packages,
                'gallery_images'        : gallery_images,
            },
            success: function(data){
                // alert('Package Details Saved SuccessFUl!');
                id = JSON.parse(data['id']);
                $('#save_Accomodation').val(id);
                $('#save_Flights').val(id);
                $('#save_Visa').val(id);
                $('#save_Transportation').val(id);
                $('#save_Itinerary').val(id);
                $('#save_Costing').val(id);
            }
        });
            
    });
    
    $('#save_Flights').on('click',function(e){
        e.preventDefault();
        var id  = $(this).val();
        console.log('id :' +id);
    });
    
    $('#save_Visa').on('click',function(e){
        e.preventDefault();
        var id  = $(this).val();
        console.log('id :' +id);
    });
    
    $('#save_Transportation').on('click',function(e){
        e.preventDefault();
        var id  = $(this).val();
        console.log('id :' +id);
    });
    
    $('#save_Itinerary').on('click',function(e){
        e.preventDefault();
        var id  = $(this).val();
        console.log('id :' +id);
    });
    
    $('#save_Costing').on('click',function(e){
        e.preventDefault();
        var id  = $(this).val();
        console.log('id :' +id);
    });
</script>
<!-- End Package Save-->

<!--Flights-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY&sensor=false&libraries=places"></script>
<script>
    
    let places,places1,return_places,return_places1,places_T,places1_T,return_places_T,return_places1_T ,input, address, city;
    google.maps.event.addDomListener(window, "load", function () {
        var places = new google.maps.places.Autocomplete(
            document.getElementById("departure_airport_code")
        );
        
        var places1 = new google.maps.places.Autocomplete(
            document.getElementById("arrival_airport_code")
        );
        
        google.maps.event.addListener(places, "place_changed", function () {
            var place = places.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            $('#flights_arrival_code').val(address);
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        google.maps.event.addListener(places1, "place_changed", function () {
            var place1 = places1.getPlace();
            // console.log(place1);
            var address = place1.formatted_address;
            var latitude = place1.geometry.location.lat();
            var longitude = place1.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // Return_Details
        var return_places = new google.maps.places.Autocomplete(
            document.getElementById("return_departure_airport_code")
        );
        
        var return_places1 = new google.maps.places.Autocomplete(
            document.getElementById("return_arrival_airport_code")
        );
        
        google.maps.event.addListener(return_places, "place_changed", function () {
            var return_place = return_places.getPlace();
            // console.log(return_place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        google.maps.event.addListener(return_places1, "place_changed", function () {
            var return_place1 = return_places1.getPlace();
            // console.log(return_place1);
            var address = place1.formatted_address;
            var latitude = place1.geometry.location.lat();
            var longitude = place1.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        // Transporation_Details
        var places_T = new google.maps.places.Autocomplete(
            document.getElementById("transportation_pick_up_location")
        );
        
        var places1_T = new google.maps.places.Autocomplete(
            document.getElementById("transportation_drop_off_location")
        );
        
        google.maps.event.addListener(places_T, "place_changed", function () {
            var place = places_T.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
        
        google.maps.event.addListener(places1_T, "place_changed", function () {
            var place1 = places1_T.getPlace();
            // console.log(place1);
            var address = place1.formatted_address;
            var latitude = place1.geometry.location.lat();
            var longitude = place1.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                        $("#transportation_drop_off_location").on('change',function () {
                            var b = $('#transportation_drop_off_location_select').val(city);
                            console.log(b);
                        });
                    }
                }
            });
        });
        
        // Return_Transportation_Details
        var return_places_T = new google.maps.places.Autocomplete(
            document.getElementById("return_transportation_pick_up_location")
        );
        
        var return_places1_T = new google.maps.places.Autocomplete(
            document.getElementById("return_transportation_drop_off_location")
        );
        
        google.maps.event.addListener(return_places_T, "place_changed", function () {
            var place = return_places_T.getPlace();
            // console.log(place);
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code); 
                    }
                }
            });
        });
        
        google.maps.event.addListener(return_places1_T, "place_changed", function () {
            var place1 = return_places1_T.getPlace();
            // console.log(place1);
            var address = place1.formatted_address;
            var latitude = place1.geometry.location.lat();
            var longitude = place1.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                    }
                }
            });
        });
    });
    
</script>
<!--End Flights-->

<script type="text/javascript">
 
    $("#switch2").click(function () {
        $('#markup_services').slideToggle();
        $('#all_services_markup').slideToggle();
        $('#markup_seprate_services').slideToggle();
        $('#sale_pr').slideToggle();
        
        var switchValue = $('#markupSwitch').val();
        if(switchValue == 'single_markup_switch'){
            $('#markupSwitch').val('all_markup_switch');
        }else{
             $('#markupSwitch').val('single_markup_switch');
        }
    });
 
    $("#all_markup_type").change(function () {
    var id = $(this).find('option:selected').attr('value');
    
        $('#select_mrk').text(id);
    if(id == '%')
    {
        $('#all_markup_add').keyup(function() {
            
   var markup_val =  $('#all_markup_add').val();
   
       var quad_cost_price   =  $('#quad_cost_price').val();
       var triple_cost_price =  $('#triple_cost_price').val();
       var double_cost_price =  $('#double_cost_price').val();
       
        if(quad_cost_price != 0){
            var total_quad_cost_price1 = (quad_cost_price * markup_val/100) + parseFloat(quad_cost_price);
            var total_quad_cost_price = total_quad_cost_price1.toFixed(2); 
            $('#quad_markup').val(total_quad_cost_price);   
        }else{
           $('#quad_markup').val(0);
        }
   
      
        if(triple_cost_price != 0){
            var total_triple_cost_price1 = (triple_cost_price * markup_val/100) + parseFloat(triple_cost_price);
            var total_triple_cost_price = total_triple_cost_price1.toFixed(2);
            $('#triple_markup').val(total_triple_cost_price);    
        }else{
            $('#triple_markup').val(0);
        }
        
        if(double_cost_price != 0){
            var total_double_cost_price1 = (double_cost_price * markup_val/100) + parseFloat(double_cost_price);
            var total_double_cost_price = total_double_cost_price1.toFixed(2);
            $('#double_markup').val(total_double_cost_price);
        }else{
            $('#double_markup').val(0);
        }
        
        
        
 
});
       
       
    }
    else
    {
       $('#all_markup_add').keyup(function() {
            
   var markup_val =  $('#all_markup_add').val();
   
        var quad_cost_price =  $('#quad_cost_price').val();
        var triple_cost_price =  $('#triple_cost_price').val();
        var double_cost_price =  $('#double_cost_price').val();
        
        if(quad_cost_price != 0){
            var total_quad_cost_price1 =  parseFloat(quad_cost_price) +  parseFloat(markup_val);
            var total_quad_cost_price = total_quad_cost_price1.toFixed(2); 
            $('#quad_markup').val(total_quad_cost_price);  
        }else{
           $('#quad_markup').val(0);
        }
   
      
        if(triple_cost_price != 0){
            var total_triple_cost_price1 =  parseFloat(triple_cost_price) +  parseFloat(markup_val);
            var total_triple_cost_price = total_triple_cost_price1.toFixed(2);
            $('#triple_markup').val(total_triple_cost_price);    
        }else{
            $('#triple_markup').val(0);
        }
        
        if(double_cost_price != 0){
            var total_double_cost_price1 = parseFloat(double_cost_price) +  parseFloat(markup_val);
            var total_double_cost_price = total_double_cost_price1.toFixed(2);
            $('#double_markup').val(total_double_cost_price);
        }else{
            $('#double_markup').val(0);
        }
   
        // var total_quad_cost_price1 =  parseFloat(quad_cost_price) +  parseFloat(markup_val);
        // var total_quad_cost_price = total_quad_cost_price1.toFixed(2); 
        // $('#quad_markup').val(total_quad_cost_price);
        
        // var total_triple_cost_price1 =  parseFloat(triple_cost_price) +  parseFloat(markup_val);
        // var total_triple_cost_price = total_triple_cost_price1.toFixed(2);
        // $('#triple_markup').val(total_triple_cost_price);
        
        // var total_double_cost_price1 = parseFloat(double_cost_price) +  parseFloat(markup_val);
        // var total_double_cost_price = total_double_cost_price1.toFixed(2);
        // $('#double_markup').val(total_double_cost_price);
        
        
 
});
     
    }
      
  

  });

    $(document).on('click','#visa_inc',function(){
        $.ajax({    
           
            url: "super_admin/get_other_visa_type_detail", 
            type: "GET",
            dataType: "html",                  
            success: function(data){  
            
                var data1 = JSON.parse(data);
                var data2= JSON.parse(data1['visa_type']);
                //   console.log(data2['visa_type']);
                // jQuery.each(data2, function(key, value){  
                //     $(".other_type").append('<option value=' +value.id+ '>' + value.other_visa_type+ '</option>');
                //   });
            	$("#visa_type").empty();
           
                $.each(data2['visa_type'], function(key, value) {
                    var visa_type_Data = `<option attr="${value.other_visa_type}" value="${value.other_visa_type}"> ${value.other_visa_type}</option>`;
                    $("#visa_type").append(visa_type_Data);
                });  
            }
        });
    });

    $('#submitForm_PUL').on('click',function(e){
        e.preventDefault();
        let pickup_location = $('#pickup_location').val();
        $.ajax({
            url: "submit_pickup_location",
            type:"POST",
            data:{
                "_token": "{{ csrf_token() }}",
                pickup_location:pickup_location,
            },
            success:function(response){
                if(response){
                    var data1 = JSON.parse(response)
                    var data = data1['pickup_location_get'];
                    $(".pickup_location").empty();
                    $.each(data, function(key, value) {
                        var pickup_location_Data = `<option attr="${value.pickup_location}" value="${value.pickup_location}"> ${value.pickup_location}</option>`;
                        $(".pickup_location").append(pickup_location_Data);
                    });
                    alert('Pickup Location Added SuccessFUl!');
                }
                $('#success-message').text(response.success);
            },
        });
    });
    
    $('#submitForm_DOL').on('click',function(e){
        e.preventDefault();
        let dropof_location = $('#dropof_location').val();
        $.ajax({
            url: "submit_dropof_location",
            type:"POST",
            data:{
                "_token": "{{ csrf_token() }}",
                dropof_location:dropof_location,
            },
            success:function(response){
                if(response){
                    var data1 = JSON.parse(response)
                    var data = data1['dropof_location_get'];
                    $(".dropof_location").empty();
                    $.each(data, function(key, value) {
                        var dropof_location_Data = `<option attr="${value.dropof_location}" value="${value.dropof_location}"> ${value.dropof_location}</option>`;
                        $(".dropof_location").append(dropof_location_Data);
                    });
                    alert('DropOf Location Added SuccessFUl!');
                }
                $('#success-message').text(response.success);
            },
        });
    });
    
    $('#submitForm').on('click',function(e){
        e.preventDefault();
        let other_visa_type = $('#other_visa_type').val();
        $.ajax({
            url: "submit_other_visa_type",
            type:"POST",
            data:{
                "_token": "{{ csrf_token() }}",
                other_visa_type:other_visa_type,
            },
            success:function(response){
                if(response){
                    var data1 = JSON.parse(response)
                    var data = data1['visa_type_get'];
                    console.log(data);
                    $("#visa_type").empty();
                    $.each(data, function(key, value) {
                        var visa_type_Data = `<option attr="${value.other_visa_type}" value="${value.other_visa_type}"> ${value.other_visa_type}</option>`;
                        $("#visa_type").append(visa_type_Data);
                    });
                    alert('Visa Other Type Added SuccessFUl!');
                }
                $('#success-message').text(response.success);
            },
        });
    });
    
    $('#submitForm_Airline_Name').on('click',function(e){
        e.preventDefault();
        let other_Airline_Name = $('#other_Airline_Name').val();
        $.ajax({
            url: "submitForm_Airline_Name",
            type:"POST",
            data:{
                "_token": "{{ csrf_token() }}",
                other_Airline_Name:other_Airline_Name,
            },
            success:function(response){
                // console.log(response);
                if(response){
                    var data1 = response;
                    var data = data1['other_Airline_Name_get'];
                    // console.log(data);
                    $("#other_Airline_Name2").empty();
                    $("#return_other_Airline_Name2").empty();
                    $.each(data, function(key, value) {
                        // console.log(value.other_Airline_Name);
                        $("#other_Airline_Name2").append('<option attr=' +value.other_Airline_Name+ ' value=' +value.other_Airline_Name+ '>' +value.other_Airline_Name+'</option>');
                        $("#return_other_Airline_Name2").append('<option attr=' +value.other_Airline_Name+ ' value=' +value.other_Airline_Name+ '>' +value.other_Airline_Name+'</option>');
                    });
                    alert('Other Airline Name Added SuccessFUl!');
                }
                $('#success-message').text(response.success);
            },
        });
    });
    
</script>

<script type="text/javascript">

    $("#Itinerary").on('click',function(){
        $("#Itinerary_select").slideToggle();
    });
    
    $("#extra_price").on('click',function(){
        $("#extraprice_select").slideToggle();
    });
    
    $("#faq").on('click',function(){
        $("#faq_select").slideToggle();
    });
    
    $("#destination1").on('click',function(){
        $("#select_destination1").slideToggle();
    });
    
    $("#flights_inc").on('click',function(){
        $("#select_flights_inc").slideToggle();
        // $('#flights_cost').toggle();
    });

    $("#transportation").on('click',function(){
        $("#select_transportation").slideToggle();
        $('#transportation_cost').toggle();
    });
    
    var divId = 1
    $("#click_more_Itinerary").click(function(){
        var data = `<div class="row" style="border: 2px solid #eef2f7;padding: 10px 10px 10px 10px;" id="click_delete_${divId}">
                        <div class="col-xl-6">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Title</label>
                                    <input type="text" id="simpleinput" name="more_Itinerary_title[]" class="form-control">
                                </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="mb-3">
                                <label for="simpleinput" class="form-label">Short Description</label>
                                <input type="text" id="simpleinput" name="more_Itinerary_city[]" class="form-control">
                            </div>
                        </div>
                        <div class="col-xl-12">
                            <div class="mb-3">
                                <label for="simpleinput" class="form-label">Content</label>
                                <textarea name="more_Itinerary_content[]" class="form-control" id="" cols="10" rows="10"></textarea>
                            </div>
                        </div>
                        <div class="col-xl-12">
                            <!--<div class="mb-3">
                                <label for="simpleinput" class="form-label">image</label>
                                <input type="file" id="simpleinput" name="more_Itinerary_image[]" class="form-control">
                            </div>!-->
                            <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRow(${divId})"  id="${divId}">Delete</button>
                        </div>
                    </div>`
                    ;
        $("#append_data").append(data);
        divId++;
    });
    
    function deleteRow(id){
        $('#click_delete_'+id+'').remove();
    }
    
    function deleteRow_extra(id){
        $('#click_delete_'+id+'').remove();
    }
    
    function deleteRow_faq(id){
        $('#click_delete_'+id+'').remove();
    }
    
    function remove_hotels(id){
            
            $('#del_hotel'+id+'').remove();
            $('#costing_acc'+id+'').remove();
            
            var city_No1 = $('#city_No').val();
            var city_No = parseFloat(city_No1) - 1;
            $('#city_No').val(city_No);
            
            put_tour_location();
            put_tour_location_else();
            add_numberElse();
        }
    
</script>

<script>
    var divId = 1
    $("#more_destination").click(function(){
        var data = `<div class="row" id="click_delete_${divId}"><div class="col-xl-6"><label for="">COUNTRY</label><select name="more_destination_country" onclick="selectCities_on(${divId})"  id="destination_${divId}" class="form-control">@foreach($all_countries as $country_res)<option value="{{ $country_res->id }}">{{ $country_res->name}}</option>@endforeach</select></div><div class="col-xl-6"><label for="">City</label><select name="more_destination_city[]" id="destination_city_${divId}" class="select2 form-control select2-multiple select_ct" data-toggle="select2" multiple="multiple" data-placeholder="Choose ..."></select></div><div class="col-xl-12 mt-2"><button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRowDes(${divId})"  id="${divId}">Delete</button></div></div>`
                    ;
  $("#append_destination").append(data);
  
  
  
  
  
  
  
  
  divId++;
});

</script>

<script>

function selectCities_on(id){
      var country = $('#destination_'+id+'').val();
      console.log(country);
      $.ajaxSetup({
         headers: {
             'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
         }
      });
      $.ajax({
         url: "{{ url('/country_cites') }}",
         method: 'post',
         data: {
             "_token": "{{ csrf_token() }}",
             "id": country,
         },
         success: function(result){
             console.log('cites is call now');
           console.log(result);
           $('#destination_city_'+id+'').html(result);
         },
         error:function(error){
             console.log(error);
         }
      });
   }


 function deleteRowDes(id){
  
     $('#click_delete_'+id+'').remove();
     

 }
 
 

</script>

<script>
    function selectCountry(id,val,shortcode) {
      var suggesstion=  $("#"+id).attr("data-suggestion");
      var shrtcode   =  $("#"+id).parent(".flight").children(".shrtcode");
      $("#"+id).val(val);
      $("#"+suggesstion).hide();
      $(shrtcode).val(shortcode);
    }
  </script>

<script>
    $(".get_flight_name").keyup(function(){

      console.log('This is call ');
      var searchinput = $(this);
      var suggesstion=  $(searchinput).attr("data-suggestion");
      var id = $(this).attr("id");
      var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
      var keyword = $(this).val();
      // console.log('This is call id is '+id+' data suggesstion '+suggesstion);
      $.ajax({
        type: "POST",
        url: '{{URL::to('get_flight_name')}}',
        data: {
          _token    : CSRF_TOKEN,
          'keyword' : keyword,
          "id"      : id,
        },
        success: function(data){
          $("#"+suggesstion).show();
          $("#"+suggesstion).html(data['thml']);
          $(searchinput).css("background","#FFF");
        }
      });
    });

  </script>
  
@stop

@section('slug')

@extends('template/frontend/userdashboard/pages/manage_Office/Invoices/editInvoiceScript')

@stop