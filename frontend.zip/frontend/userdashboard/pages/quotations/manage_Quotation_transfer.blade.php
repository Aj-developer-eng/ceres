@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php $currency=Session::get('currency_symbol'); $account_No=Session::get('account_No'); //dd($account_No); ?>

<div class="card">
    <div class="card-body">
        <h4 class="header-title">Create Transfer Quotation</h4>
        @if($errors->any())
        <h4>{{$errors->first()}}</h4>
        @endif
        <!--<div class="tab-content">-->
            <form action="{{URL::to('add_Invoices')}}" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
                @csrf
                <!--<div class="tab-pane show active" id="justified-tabs-preview">-->
                <div id="progressbarwizard">
                    <!--<ul class="nav nav-pills bg-nav-pills nav-justified mb-3">-->
                    <ul class="nav nav-pills nav-justified form-wizard-header mb-3" style="margin-right: 1px;margin-left: 1px;">
                        
                        <li class="nav-item">
                            <a href="#home1" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                              <i class="mdi mdi-home-variant d-md-none d-block"></i>
                                <span class="d-none d-md-block">Invoice Details</span>
                            </a>
                        </li>
                        
                        <li class="nav-item transportation_tab">
                            <!--<a href="#trans_details_1" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">-->
                            <a href="#trans_details_1" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                              <i class="uil-bus d-md-none d-block"></i>
                                <span class="d-none d-md-block">Transportation</span>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <!--<a href="#Extras_details" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">-->
                            <a href="#Extras_details" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                              <i class="uil-moneybag d-md-none d-block"></i>
                                <span class="d-none d-md-block">Costing</span>
                            </a>
                        </li>
                    </ul>
                    
                    <div class="tab-content">

                        <div class="tab-pane  show active" id="home1">
                            <div class="row">
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label simpleinput">Services</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Enter the package name">
                                            </i>
                                        </div>
                                        <!--<input type="text" id="simpleinput" name="title" class="form-control titleP" >-->
                                       <select class="form-control external_packages" data-toggle="select2" multiple="multiple" id="select_services" name="services[]">
                                            <option value="transportation_tab">Transportation</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <input type="checkbox" class="custom-control-input" id="selectAgent" name="customer_select" value="booking_by_customer">
                                    <label  class="custom-control-label" for="selectAgent">Book for Agent</span></label>
                                    
                                    <div class="mb-3" id="agent_div" style="display:none;padding-top: 10px;">
                                        <select class="form-control" id="agent_Company_Name" name="agent_Company_Name">
                                           <option value="">Choose...</option>
                                            @if(isset($Agents_detail) && $Agents_detail !== null && $Agents_detail !== '')
                                                @foreach($Agents_detail as $Agents_details)
                                                    <option attr-Id="{{ $Agents_details->id }}" attr-AN="{{ $Agents_details->agent_Name }}" value="{{ $Agents_details->company_name }}">{{ $Agents_details->company_name }}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    
                                        <input type="hidden" name="agent_Id" id="agent_Id" readonly>
                                        
                                        <input type="hidden" name="agent_Name" id="agent_Name" readonly>
                                        
                                    </div>
                                </div>
                                
                                <div class="col-xl-3 d-none">
                                    <div id="tooltip-container">
                                        <label for="simpleinput" class="form-label simpleinput">Select Agent</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                            data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select the Agent Name">
                                        </i>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <input type="checkbox" class="custom-control-input" id="selectcustomer" name="customer_select" value="booking_by_customer">
                                    <label  class="custom-control-label" for="selectcustomer">Book for Customer</span></label>
                                    
                                    <div class="mb-3" id="customer_div" style="display:none;padding-top: 10px;">
                                        <select class="form-control" id="customer_name" name="customer_name">
                                           <option value="-1">Choose...</option>
                                            @if(isset($customers_data) && $customers_data !== null && $customers_data !== '')
                                                @foreach($customers_data as $customers_res)
                                                    <option attr-cusData='{{ json_encode($customers_res) }}' attr-Id="{{ $customers_res->id }}" value="{{ $customers_res->id }}">{{ $customers_res->name }}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-xl-3 d-none">
                                    <div id="tooltip-container">
                                        <label for="simpleinput" class="form-label simpleinput">Select Customer</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                            data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select the Agent Name">
                                        </i>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="" class="form-label">Currency Symbol</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Currency Symbol will be auto-selected for your account">
                                            </i>
                                        </div>
                                        <select name="currency_symbol" class="form-control currency_symbol">
                                            @foreach($all_curr_symboles as $all_curr_symbolesS)
                                                <option <?php if($all_curr_symbolesS->currency_symbol == $currency) echo 'selected'; ?> value="{{ $all_curr_symbolesS->currency_symbol }}">{{ $all_curr_symbolesS->currency_symbol }}</option>
                                            @endforeach
                                        </select>
                                        <input readonly value="<?php echo $currency; ?>" name="" class="form-control currency_symbol" hidden>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="" class="form-label no_of_pax_days">No Of Pax</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="No Of Pax for this package">
                                            </i>
                                        </div>
                                        <!--<input type="text" id="no_of_pax_days" name="no_of_pax_days" class="form-control no_of_pax_days">-->
                                        <input type="number" name="no_of_pax_days" value="1" min="1" class="form-control no_of_pax_days" id="no_of_pax_days" required>
                                        <input type="number" id="no_of_pax_prev" hidden value="1">
                                        <div class="invalid-feedback">
                                            This Field is Required
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="" class="form-label">Currency Conversion</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Currency Conversion">
                                            </i>
                                        </div>
                                        <select class="form-control CC_id_store" name="currency_conversion" id="currency_conversion1">
                                            <option value="0">Select Currency Conversion</option>
                                            @foreach($mange_currencies as $mange_currencies)
                                                <option attr_id="{{$mange_currencies->id}}" attr_conversion_type="{{$mange_currencies->conversion_type}}" value="{{$mange_currencies->purchase_currency}} TO {{$mange_currencies->sale_currency}}">{{$mange_currencies->purchase_currency}} TO  {{$mange_currencies->sale_currency}}</option>
                                            @endforeach
                                        </select>
                                        <input type="hidden" id="conversion_type_Id"  name="conversion_type_Id" >
                                        <input type="hidden" id="select_exchange_type" value=""> 
                                    </div>
                                </div>
                                
                                <div class="col-xl-12">
                                    <div class="mb-3">
                                        <h6>Lead Passenger Details</h6>
                                        <div class="row" style="border: 1px solid #ebebeb;padding: 1rem;border-radius: 6px;">
                                            <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="" class="form-label no_of_pax_days">First Name</label>
                                                    <input type="text" name="lead_fname" class="form-control" required id="lead_fnameI">
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="" class="form-label no_of_pax_days">Last Name</label>
                                                    <input type="text" name="lead_lname" class="form-control" required id="lead_lnameI">
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="" class="form-label no_of_pax_days">Email</label>
                                                    <input type="text" name="email" class="form-control" required id="lead_emailI">
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="" class="form-label no_of_pax_days">Contact Number</label>
                                                    <input type="text" name="mobile" class="form-control" required id="lead_mobileI">
                                                </div>
                                            </div>
                                            <!-- <div class="col-xl-4">-->
                                            <!--    <div class="mb-3">-->
                                            <!--        <label for="simpleinput" class="form-label no_of_pax_days">Date Of Birth</label>-->
                                            <!--        <input type="date" name="data_of_birth" class="form-control" required>-->
                                            <!--    </div>-->
                                            <!--</div>-->
                                            <!-- <div class="col-xl-4">-->
                                            <!--    <div class="mb-3">-->
                                            <!--        <label for="simpleinput" class="form-label no_of_pax_days">Passport No</label>-->
                                            <!--        <input type="text" name="passport_no" class="form-control" required>-->
                                            <!--    </div>-->
                                            <!--</div>-->
                                            <!-- <div class="col-xl-4">-->
                                            <!--    <div class="mb-3">-->
                                            <!--        <label for="simpleinput" class="form-label no_of_pax_days">Passport Expiry Date</label>-->
                                            <!--        <input type="date" name="passport_expiry_date" class="form-control" required>-->
                                            <!--    </div>-->
                                            <!--</div>-->
                                            
                                                    
                                            <div class="col-xl-4">
                                                <div class="mb-3">
                                                    <label for="" class="form-label no_of_pax_days">Select Nationality</label>
                                                     <select type="text" class="form-control select2 " name="nationality"  data-placeholder="Choose ...">
                                                        @foreach($all_countries as $country_res)
                                                            <option value="{{$country_res->id}}" id="categoriesPV">{{$country_res->name}}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-2" >
                                                <div class="mb-3">
                                                     <p style="margin-top: 2.2rem;">Gender</p>
                                                </div>
                                            </div>
                                            
                                               
                                            <div class="col-2">
                                              <div class="form-check" style="margin-top: 2.2rem;">
                                              <input class="form-check-input" type="radio" name="gender" value="male"  id="flexRadioDefault3">
                                              <label class="form-check-label" for="flexRadioDefault3">
                                                Male
                                              </label>
                                            </div>
                                            
                                            </div>
                                            <div class="col-2" style="margin-top: 2.2rem;">
                                                <div class="form-check">
                                              <input class="form-check-input" type="radio" name="gender" value="female"  id="flexRadioDefault4">
                                              <label class="form-check-label" for="flexRadioDefault4">
                                                Female
                                              </label>
                                            </div>
                                            
                                            </div>
                                            
                                           
                                            
                                        </div>
                                        
                                        
                                        <div id="other_passengers">
                                            
                                            
                                        </div>
                                        
                                    </div>
                                </div>
                                
                                <div class="col-xl-12 d-none">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="" class="form-label">Content</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Additional Information of Package">
                                            </i>
                                        </div>
                                        <!--<textarea name="content" id="" class="contentP summernote" cols="142" rows="10"></textarea>-->
                                        <textarea name="content" class="contentP" cols="135" rows="5"></textarea>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4 visa_type_select">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="" class="form-label start_date">Start Date</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select start date of package">
                                            </i>
                                        </div>
                                        
                                        <input type="date" name="start_date" class="form-control start_date" id="start_date" required placeholder="yyyy/mm/dd">
                                        <div class="invalid-feedback">
                                            This Field is Required
                                        </div>
                                    </div>
                                 </div>
                                
                                <div class="col-xl-4 visa_type_select">
                                    <div class="mb-3">
                                        
                                        <div id="tooltip-container">
                                            <label for="" class="form-label end_date">End Date</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select end date of package">
                                            </i>
                                        </div>
                                        <input type="date" name="end_date" class="form-control end_date" id="end_date" required placeholder="yyyy/mm/dd">
                                        <div class="invalid-feedback">
                                            This Field is Required
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4 visa_type_select">
                                     <div class="mb-3">
                                        <!--<div id="tooltip-container">-->
                                            <label for="" class="form-label no_of_Nights_Other">Total Duration</label>
                                            <!--<i class="dripicons-information" style="font-size: 17px;" id="title_Icon"-->
                                                <!--data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="No Of Pax Info">-->
                                            <!--</i>-->
                                        <!--</div>-->
                                      
                                      <input readonly type="text" name="time_duration" id="duration" class="form-control time_duration" >
                                     </div>
                                  </div>
                                 
                                <div class="col-xl-4 d-none" >
                                        <div class="mb-3">
                                            <div>
                                                <div id="tooltip-container">
                                                    <label for="categoriesPV">Categories</label>
                                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                        data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select package Category">
                                                    </i>
                                                
                                                
                                                    <span title="Add Categories" class="input-group-btn input-group-append" style="float: right;margin-bottom:10px">
                                                        <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#add-Categories-modal" type="button">+</button>
                                                    </span>
                                            
                                                    <select type="text" class="form-control select2 categories" name="categories"  data-placeholder="Choose ...">
                                                        @foreach($categories as $categories)
                                                            <option value="{{$categories->id}}" id="categoriesPV" required>{{$categories->title}}</option>
                                                            <div class="invalid-feedback">
                                                                This Field is Required
                                                            </div>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                <div class="col-xl-4 d-none">
                                    <div class="mb-3">
                                        <div>
                                            <div id="tooltip-container">
                                                <label for="simpleinput" class="form-label">Tour Featured </label>
                                                <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                    data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Display your package on Home Page">
                                                </i>
                                            </div>
                                            <select name="tour_feature" id="" class="form-control tour_feature" style="margin-top: 18px">
                                                <option value="">Select Featured</option>
                                                <option value="0">Enable featured</option>
                                                <option value="1">Disable featured</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4 d-none">
                                    <div class="mb-3">
                                        <div>
                                            <!--<div id="tooltip-container">-->
                                                <label for="simpleinput" class="form-label">Default State</label>
                                                <!--<i class="dripicons-information" style="font-size: 17px;" id="title_Icon"-->
                                                    <!--data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="No Of Pax Info">-->
                                                <!--</i>-->
                                            <!--</div>-->
                                            <select name="defalut_state" id="" class="form-control defalut_state" style="margin-top: 18px">
                                                <option value="">Select Default State</option>
                                                <option value="0">Always available</option>
                                                <option value="1">Only available on specific dates</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                  
                                <div class="col-xl-6 d-none">
                                   <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label">Banner Image</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Upload your detail page image for Package (Image size should be 'Width:1600px' 'Height:300px')">
                                            </i>
                                        </div>
                                        <input type="file" id="simpleinput" name="tour_featured_image" class="form-control tour_featured_imageP">
                                    </div>
                                </div>
                                
                                <div class="col-xl-6 d-none">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label">Featured Image</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Upload your main image for Package">
                                            </i>
                                        </div>
                                        <input type="file" id="simpleinput" name="tour_banner_image" class="form-control tour_banner_imageP">
                                    </div>
                                </div>
                                
                                <div class="col-xl-3">
                                    <div class="mb-3">
                                        <!--<div id="tooltip-container">-->
                                            <label for="simpleinput" class="form-label">Author</label>
                                            <!--<i class="dripicons-information" style="font-size: 17px;" id="title_Icon"-->
                                                <!--data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="No Of Pax Info">-->
                                            <!--</i>-->
                                        <!--</div>-->
                                      
                                      <select name="tour_author" id="" class="form-control tour_author">
                                      <option value="">Select Author</option>
                                          <option value="admin">admin</option>
                                          <option value="admin1">admin1</option>
                                      </select>
                                  </div>
                                  </div>
                                  
                                <div class="col-xl-3 more_Div_Acc_All" style="display:none">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Option Date</label>
                                        <input type="date" id="option_date" value="" name="option_date" class="form-control ">
                                    </div>
                                </div>
                                  
                                <div class="col-xl-3 more_Div_Acc_All" style="display:none">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Reservation Number</label>
                                        <input type="text" id="reservation_number" value="" name="reservation_number" class="form-control ">
                                    </div>
                                </div>
                                  
                                <div class="col-xl-3 more_Div_Acc_All" style="display:none">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Hotel Reservation Number</label>
                                        <input type="text" id="hotel_reservation_number" value="" name="hotel_reservation_number" class="form-control ">
                                    </div>
                                </div>
                                  
                                <div class="col-xl-8 d-none">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label">Gallery Images</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Upload at least 10 images">
                                            </i>
                                        </div>
                                        <div>
                                            <?php $img_c = 1; ?>
                                	        <input type="file" id="" name="gallery_images[]" class="form-control gallery_imagesP{{ $img_c }}" onchange="validate1({{ $img_c }})">
                                	        <span class="file_error{{ $img_c }}"></span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div id="more_img d-none"></div>
                                        
                                <div class="mt-2 d-none" style="" id="">
                                    <a href="javascript:;" id="more_images" class="btn btn-info" style="float: right;">Add Gallery Images</a>
                                </div>
                                    
                            </div>
                            <!--<a id="save_Package" type="submit" class="btn btn-primary" name="submit">Save Package Deatils</a>-->    
                        </div>
                        
                        <div class="tab-pane" id="trans_details_1">
                            <div class="row">                                       
                                <div class="tab-pane" id="trans_details_1">
                                    
                                    <div class="col-xl-12 mt-2 d-none">
                                        <div class="mb-3">
                                            <div class="row">
                                                <div class="col-xl-1">
                                                    <input type="checkbox" id="transportation" data-switch="bool"/>
                                                    <label for="transportation" data-on-label="On" data-off-label="Off"></label>
                                                </div>
                                                <div class="col-xl-3">
                                                    Transportation
                                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Add your transportation details"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-xl-3 mt-2" style="padding: 10px;">
                                        <label for="">Transfer Suppliers List</label>
                                        <select name="transfer_supplier" class="form-control" id="transfer_supplier">
                                            <option value="">Select Suppliers</option>
                                            @foreach($tranfer_supplier as $tranfer_supplierS)
                                                <option attr-id="{{ $tranfer_supplierS->id }}" value="{{ $tranfer_supplierS->room_supplier_name }}">{{ $tranfer_supplierS->room_supplier_name }}</option>
                                            @endforeach
                                        </select>
                                        
                                        <input type="hidden" name="transfer_supplier_id" id="transfer_supplier_selected_id">
                                        
                                    </div>
                                    
                                    <div class="row" id="transfer_supplier_list_div" style="display:none">
                                        <div class="dashboard-content">
                                            <h3 style="font-size: 40px;text-align:center">Vehicle List</h3>
                                            <div class="row">
                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="dashboard-list-box dash-list margin-top-0">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <table id="myTable" class="display nowrap table table-bordered" style="width:100%;">
                                                                    <thead style="background: linear-gradient(176deg, rgb(28 63 170) 0%, rgb(0 14 58) 100%);color:white;">
                                                                        <tr>
                                                                            <th>Id</th>
                                                                            <th>Company Name</th>
                                                                            <th>Pickup City</th>
                                                                            <th>Dropoff City</th>
                                                                            <th>Available From</th>
                                                                            <th>Available To</th>
                                                                            <th>Trip Type</th>
                                                                            <th>Total Fare</th>
                                                                            <th>Occupy</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody style="text-align: center;" id="transfer_supplier_list_body"></tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                     
                                    <div class="row" style="display:none;border:1px solid #ced4da;padding: 20px 20px 20px 20px;" id="select_transportation">
                                        
                                        <input type="hidden" id="transportation_price_switch">
                                        
                                        <input type="hidden" name="all_round_Type[]">
                                        
                                        <input type="hidden" name="destination_id[]" id="destination_id">
                                        
                                        <input type="hidden" name="vehicle_select_exchange_type[]" id="vehicle_select_exchange_type_ID">
                                        
                                        <input type="hidden" name="vehicle_exchange_Rate[]" id="vehicle_exchange_Rate_ID">
                                        
                                        <input type="hidden" name="currency_SAR[]" id="currency_SAR">
                                            
                                        <input type="hidden" name="currency_GBP[]" id="currency_GBP">
                                        
                                        <h3>Transportation Details :</h3>
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Pick-up Location</label>
                                            <input type="text" id="transportation_pick_up_location" name="transportation_pick_up_location[]" class="form-control pickup_location" value="">
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Drop-off Location</label>
                                            <input type="text" id="transportation_drop_off_location" name="transportation_drop_off_location[]" class="form-control dropof_location">
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Pick-up Date & Time</label>
                                            <input type="datetime-local" id="transportation_pick_up_date" name="transportation_pick_up_date[]" class="form-control">
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Drop-of Date & Time</label>
                                            <input type="datetime-local" id="transportation_drop_of_date" name="transportation_drop_of_date[]" class="form-control">
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;" id="transportation_Time_Div">
                                            <label for="">Estimate Time</label>
                                            <input type="text" id="transportation_total_Time" name="transportation_total_Time[]" class="form-control transportation_total_Time1" readonly style="padding: 10px;" value="">
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Select Trip Type</label>
                                            <select name="transportation_trip_type[]" id="slect_trip" class="form-control"  data-placeholder="Choose ...">
                                                <option value="">Select</option>
                                                <option value="One-Way">One-Way</option>
                                                <option value="Return">Return</option>
                                                <option value="All_Round">All Round</option>
                                            </select>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Vehicle Type</label>
                                            <select name="transportation_vehicle_type[]" id="transportation_vehicle_typeI" class="form-control"  data-placeholder="Choose ...">
                                                <option value="">Choose ...</option>
                                                <option value="Bus">Bus</option>
                                                <option value="Coach">Coach</option>
                                                <option value="Vain">Vain</option>
                                                <option value="Car">Car</option>
                                            </select>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">No Of Vehicle</label>
                                            <input type="text" id="transportation_no_of_vehicle" name="transportation_no_of_vehicle[]" class="form-control">
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Price Per Vehicle</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" id="transportation_price_per_vehicle" name="transportation_price_per_vehicle[]" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Total Vehicle Price</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" id="transportation_vehicle_total_price" name="transportation_vehicle_total_price[]" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Price Per Person</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" id="transportation_price_per_person" name="transportation_price_per_person[]" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Exchange Rate</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" name="transfer_exchange_rate_destination[]" id="transfer_exchange_rate_destination" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Price Per Vehicle</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T"></a></span>
                                                <input type="text" name="without_markup_price_converted_destination[]" id="without_markup_price_converted_destination" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Total Vehicle Price</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T"></a></span>
                                                <input type="text" name="transportation_vehicle_total_price_converted[]" id="transportation_vehicle_total_price_converted" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Price Per Person</label>
                                            <div class="input-group">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T"></a></span>
                                                <input type="text" name="transportation_price_per_person_converted[]" id="transportation_price_per_person_converted" class="form-control" readonly>
                                            </div>
                                        </div>
                                        
                                        <!--Costing-->
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Vehicle Markup Type</label>
                                            <select name="vehicle_markup_type[]" id="vehicle_markup_type" class="form-control" onchange="vehicle_markup_OWandR()">
                                                <option value="">Markup Type</option>
                                                <option value="%">Percentage</option>
                                                <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                            </select>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Markup Value per Vehicle</label>
                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" class="form-control" id="vehicle_per_markup_value" name="vehicle_per_markup_value[]" onkeyup="vehicle_per_markup_OWandR()">
                                            </div>
                                        </div>
                                        
                                        <input type="text" class="form-control d-none" id="markup_price_per_vehicle_converted" name="markup_price_per_vehicle_converted[]" readonly>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Vehicle Total Price</label>
                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" class="form-control" id="vehicle_total_price_with_markup" name="vehicle_total_price_with_markup[]" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Vehicle Markup Value</label>
                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T"></a></span>
                                                <input type="text" class="form-control" id="vehicle_markup_value" name="vehicle_markup_value[]" onkeyup="vehicle_markup_OWandR()" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Vehicle Markup Value</label>
                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T"></a></span>
                                                <input type="text" class="form-control" id="vehicle_markup_value_converted" name="vehicle_markup_value_converted[]" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3" style="padding: 10px;">
                                            <label for="">Vehicle Markup Price</label>
                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T"></a></span>
                                                <input type="text" class="form-control" id="vehicle_total_price_with_markup_converted" name="vehicle_total_price_with_markup_converted[]" readonly>
                                            </div>
                                        </div>
                                        <!--End Costing-->
                                        
                                        <input type="hidden" class="transfer_markup_type_invoice" name="transfer_markup_type_invoice[]">
                                        <input type="hidden" class="transfer_markup_invoice" name="transfer_markup_invoice[]">
                                        <input type="hidden" class="transfer_markup_price_invoice" name="transfer_markup_price_invoice[]">
                                
                                        <!--Return Transportation-->
                                        <div class="row" id="select_return" style="display:none;padding: 10px;">
                                            <h3>Return Details :</h3>
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Pick-up Location</label>
                                                <input type="text" id="return_transportation_pick_up_location" name="return_transportation_pick_up_location" class="form-control pickup_location">
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Drop-off Location</label>
                                                <input type="text" id="return_transportation_drop_off_location" name="return_transportation_drop_off_location" class="form-control dropof_location">
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Pick-up Date & Time</label>
                                                <input type="datetime-local" id="return_transportation_pick_up_date" name="return_transportation_pick_up_date" class="form-control">
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Drop-of Date & Time</label>
                                                <input type="datetime-local" id="return_transportation_drop_of_date" name="return_transportation_drop_of_date" class="form-control">
                                            </div>
                                            
                                            <div class="col-xl-3" style="display:none" id="return_transportation_Time_Div">
                                                <label for="" style="width: 205px;">Estimate Time Return</label>
                                                <input type="text" id="return_transportation_total_Time" name="return_transportation_total_Time" class="form-control return_transportation_total_Time1" readonly style="padding: 10px;" value="">
                                            </div>
                                            
                                            <div class="col-xl-3" style="display:none;padding: 10px;">
                                                <label for="">Vehicle Type</label>
                                                <select name="return_transportation_vehicle_type" id="" class="form-control"  data-placeholder="Choose ...">
                                                    <option value="">Choose ...</option>
                                                    <option value="Bus">Bus</option>
                                                    <option value="Coach">Coach</option>
                                                    <option value="Vain">Vain</option>
                                                    <option value="Car">Car</option>
                                                </select>
                                            </div>
                                            
                                            <div class="col-xl-3" style="display:none;padding: 10px;">
                                                <label for="">No Of Vehicle</label>
                                                <input type="text" id="return_transportation_no_of_vehicle" name="return_transportation_no_of_vehicle" class="form-control">
                                            </div>
                                            
                                            <div class="col-xl-3" style="display:none;padding: 10px;">
                                                <label for="">Price Per Vehicle</label>
                                                <div class="input-group">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                    <input type="text" id="return_transportation_price_per_vehicle" name="return_transportation_price_per_vehicle" class="form-control">
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-3" style="display:none;padding: 10px;">
                                                <label for="">Total Vehicle Price</label>
                                                <div class="input-group">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                    <input type="text" id="return_transportation_vehicle_total_price" name="return_transportation_vehicle_total_price" class="form-control">
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-3" style="display:none;padding: 10px;">
                                                <label for="">Price Per Person</label>
                                                    <div class="input-group">
                                                                <span class="input-group-btn input-group-append">
                                                                    <a class="btn btn-primary bootstrap-touchspin-up">
                                                                       <?php echo $currency; ?>
                                                                    </a>
                                                                </span>
                                                        <input type="text" id="return_transportation_price_per_person" name="return_transportation_price_per_person" class="form-control">
                                                    </div>
                                                </div>
                                        </div>
                                        
                                        <div id="append_transportation"></div>
                                    
                                        <div class="mt-2" style="display:none;" id="add_more_destination">
                                            <a href="javascript:;" id="more_transportationI" class="btn btn-info" style="float: right;">Add More Destinations </a>
                                        </div>
                                    </div>
                                    
                                    <div class="row" style="display:none;border:1px solid #ced4da;padding: 20px 20px 20px 20px;" id="transportation_main_divI"></div>
                                    
                                    <div class="col-xl-12" style="padding: 10px;">
                                        <label for="">Image</label>
                                        <input type="file" id="" name="transportation_image" class="form-control">
                                    </div>
                                    
                                </div>
                            </div> 
                            <!--<a id="save_Transportation" class="btn btn-primary" name="submit">Save Transportation Details</a>-->
                        </div>
                        
                        <div class="tab-pane" id="Extras_details">  
                        
                            <div class="row">
                                
                                <div class="col-xl-4" style="text-align:right;">
                                    <span>Markup on total price</span>
                                </div>
                                
                                <input type="hidden" id="markupSwitch" name="markupSwitch" value="single_markup_switch">
                                
                                <div class="col-xl-1">
                                    <input type="checkbox" id="switch2" data-switch="bool"/>
                                    <label for="switch2" data-on-label="On" data-off-label="Off"></label>
                                </div>
                                 
                                <div class="col-xl-7">
                                    <span>Markup on break down prices</span>
                                </div>
  
                                <div class="col-xl-12" id="markup_services">
                                    <div class="card">
                                        
                                        <div class="card-header">
                                            <h4 class="modal-title" id="standard-modalLabel">Markup on break down prices</h4>
                                        </div>
                                        
                                        <div id="" class="card-body">
                                            <div class="row">
                                                <h4 >Flights Cost <b id="flights_departure_code_html"></b></h4> 
                                                <div class="row" id="flights_cost" style="display:none;padding-bottom: 25px">
                                                    
                                                    <input type="hidden" name="acc_hotel_CityName[]">
                                                    <input type="hidden" name="acc_hotel_HotelName[]">
                                                    <input type="hidden" name="acc_hotel_CheckIn[]">
                                                    <input type="hidden" name="acc_hotel_CheckOut[]">
                                                    <input type="hidden" name="acc_hotel_NoOfNights[]">
                                                    <input type="hidden" name="acc_hotel_Quantity[]">
                                                    
                                                    <div class="col-xl-9">
                                                        <input type="hidden" id="flight_Type_Costing" name="markup_Type_Costing[]" value="flight_Type_Costing" class="form-control">
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <input value="" type="text" id="flights_departure_code" readonly="" name="hotel_name_markup[]" class="form-control flights_type_code">
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <input value="" type="text" id="flights_arrival_code" readonly="" name="room_type[]" class="form-control">
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="flights_price_per_night" readonly="" name="without_markup_price_single[]" class="form-control">    
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group">
                                                            <input type="text" id="flights_prices" readonly="" name="without_markup_price[]" class="form-control flights_per_person_price12345">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <select name="markup_type[]" id="markup_type" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                            <input type="text"  class="form-control" id="markup_value" name="markup[]">
                                                            <span class="input-group-btn input-group-append">
                                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="markup_value_markup_mrk">%</div></button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-1" style="display:none">
                                                        <input type="text" id="flights_exchage_rate_per_night" readonly="" name="exchage_rate_single[]" class="form-control">    
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="flights_exchage_rate_markup_total_per_night" readonly="" name="markup_total_per_night[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                            </span>
                                                        </div> 
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group">
                                                            <input type="text" id="total_markup" name="markup_price[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                                
                                                <div class="row d-none" style="padding-bottom: 20px">
                                                    
                                                    <div class="col-xl-2">
                                                        <label for="">Total Adult</label>
                                                        <input  type="text" id="adult_final_qty"  readonly="" name="adultfinalqty" class="form-control">
                                                    </div>
                                                    
                                                     
                                                    <div class="col-xl-2">
                                                        <label for="">Per Adult Price</label>
                                                        <div class="input-group">
                                                            <input type="text" id="per_adult_price" readonly="" name="adultPerprice" class="form-control flights_per_person_price12345">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <label for=""></label>
                                                        <select name="" id="markup_type_for_adult" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <label for=""></label>
                                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                            <input type="text"  class="form-control" id="markup_value_for_adult" name="">
                                                            <span class="input-group-btn input-group-append">
                                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="markup_value_markup_mrk_for_adult">%</div></button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                     <input type="hidden"  class="form-control adult_total_with_markup"  name="adult_total_with_markup">
                                                    
                                                    
                                                    
                                                    <div class="col-xl-2">
                                                        <label for=""></label>
                                                        <div class="input-group">
                                                            <input type="text" id="total_markup_for_adult" name="adult_markup_price1" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <label for=""></label>
                                                        <div class="input-group">
                                                            <input type="text" id="total_adult_markup" name="adult_markup_price" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                                <div class="row d-none" style="padding-bottom: 20px">
                                                    
                                                    <div class="col-xl-2">
                                                            
                                                  <label for="">Total Child</label>
                                                        <input  type="text" id="child_final_qty" readonly="" name="childfinalqty" class="form-control">
                                                    </div>
                                                    
                                                  
                                                   
                                                    <div class="col-xl-2">
                                                         <label for="">Per Child Price</label>
                                                        <div class="input-group">
                                                            <input type="text" id="per_child_price" readonly="" name="childPerprice" class="form-control flights_per_person_price12345">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                           <label for=""></label>
                                                        <select name="" id="markup_type_for_child" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                           <label for=""></label>
                                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                            <input type="text"  class="form-control" id="markup_value_for_child" name="">
                                                            <span class="input-group-btn input-group-append">
                                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="markup_value_markup_mrk">%</div></button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <input type="hidden"  class="form-control child_total_with_markup"  name="child_total_with_markup">
                                                    <div class="col-xl-1" style="display:none">
                                                        <input type="text" id="flights_exchage_rate_per_night" readonly="" name="" class="form-control">    
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="flights_exchage_rate_markup_total_per_night" readonly="" name="" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                            </span>
                                                        </div> 
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <label for=""></label>
                                                        <div class="input-group">
                                                            <input type="text" id="total_markup_for_child" name="total_markup_for_child" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-2">
                                                        <label for=""></label>
                                                        <div class="input-group">
                                                            <input type="text" id="total_child_markup" name="" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                                <div class="row d-none" style="padding-bottom: 20px">
                                                    
                                                    <div class="col-xl-2">
                                                         <label for="">Total Infant</label>
                                                        <input  type="text" id="infant_final_qty" readonly="" name="infantfinalqty" class="form-control">
                                                    </div>
                                                    
                                                  
                                                    <div class="col-xl-2">
                                                          <label for="">Per Infant Price</label>
                                                        <div class="input-group">
                                                            <input type="text" id="per_infant_price" readonly="" name="infantPerprice" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                          <label for=""></label>
                                                        <select name="" id="markup_type_for_infant" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                         <label for=""></label>
                                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                            <input type="text"  class="form-control" id="markup_value_for_infant" name="">
                                                            <span class="input-group-btn input-group-append">
                                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="markup_value_markup_mrk">%</div></button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                     <input type="hidden"  class="form-control infant_total_with_markup"  name="infant_total_with_markup">
                                                    <div class="col-xl-1" style="display:none">
                                                        <input type="text" id="flights_exchage_rate_per_night" readonly="" name="" class="form-control">    
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="flights_exchage_rate_markup_total_per_night" readonly="" name="" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                            </span>
                                                        </div> 
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                         <label for=""></label>
                                                        <div class="input-group">
                                                            <input type="text" id="total_markup_for_infant" name="total_markup_for_infant" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div> 
                                                    <div class="col-xl-2">
                                                         <label for=""></label>
                                                        <div class="input-group">
                                                            <input type="text" id="total_infant_markup" name="" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                                <div id="append_accomodation_data_cost"></div>
                                                
                                                <hr style="width: 98%;margin-left: 13px;margin-top: 10px;margin-bottom: 10px;color: black;"></hr>
                                                
                                                <div id="append_accomodation_data_cost1"></div>
                                                
                                                <div class="row" id="transportation_cost" style="display:none;">
                                                    
                                                    <div class="col-xl-3">
                                                         <h4 class="" id="">Transportation Cost</h4>
                                                    </div>
                                                    
                                                    <input type="hidden" name="acc_hotel_CityName[]">
                                                    <input type="hidden" name="acc_hotel_HotelName[]">
                                                    <input type="hidden" name="acc_hotel_CheckIn[]">
                                                    <input type="hidden" name="acc_hotel_CheckOut[]">
                                                    <input type="hidden" name="acc_hotel_NoOfNights[]">
                                                    <input type="hidden" name="acc_hotel_Quantity[]">
                                                    
                                                    <div class="col-xl-9">
                                                        <input type="hidden" id="transportation_Type_Costing" name="markup_Type_Costing[]" value="transportation_Type_Costing" class="form-control">  
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <input type="text" id="transportation_pick_up_location_select" readonly="" name="hotel_name_markup[]" class="form-control">
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <input type="text" id="transportation_drop_off_location_select" readonly="" name="room_type[]" class="form-control">
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="transportation_price_per_night" readonly="" name="without_markup_price_single[]" class="form-control">    
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group">
                                                            <input type="text" id="transportation_price_per_person_select" readonly="" name="without_markup_price[]" class="form-control" readonly>
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <select name="markup_type[]" id="transportation_markup_type" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                            <input type="text"  class="form-control" id="transportation_markup" name="markup[]" readonly>
                                                            <span class="input-group-btn input-group-append">
                                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="transportation_markup_mrk">%</div></button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-1" style="display:none">
                                                        <input type="text" id="transportation_exchage_rate_per_night" readonly="" name="exchage_rate_single[]" class="form-control">    
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="transportation_exchage_rate_markup_total_per_night" readonly="" name="markup_total_per_night[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                            </span>
                                                        </div> 
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group">
                                                            <input type="text" id="transportation_markup_total" name="markup_price[]" class="form-control" readonly>
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                                <div class="row" id="visa_cost" style="display:none;">
                                                    
                                                    <div class="col-xl-3">
                                                        <h4 class="" id="">Visa Cost</h4>
                                                    </div>
                                                    
                                                    <input type="hidden" name="acc_hotel_CityName[]">
                                                    <input type="hidden" name="acc_hotel_HotelName[]">
                                                    <input type="hidden" name="acc_hotel_CheckIn[]">
                                                    <input type="hidden" name="acc_hotel_CheckOut[]">
                                                    <input type="hidden" name="acc_hotel_NoOfNights[]">
                                                    <input type="hidden" name="acc_hotel_Quantity[]">
                                                    
                                                    <div class="col-xl-9">
                                                        <input type="hidden" id="visa_Type_Costing" name="markup_Type_Costing[]" value="visa_Type_Costing" class="form-control">
                                                    </div>
                                                    
                                                    <div class="col-xl-3">
                                                        <input readonly type="text" id="visa_type_select" name="hotel_name_markup[]" class="form-control">
                                                    </div> 
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="visa_price_per_night" readonly="" name="without_markup_price_single[]" class="form-control">    
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-3">
                                                        <div class="input-group">
                                                            <input readonly type="text" id="visa_price_select" name="without_markup_price[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <select name="markup_type[]" id="visa_markup_type" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                            <input type="text" class="form-control" id="visa_markup" name="markup[]">
                                                            <span class="input-group-btn input-group-append">
                                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="visa_mrk">%</div></button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-1" style="display:none">
                                                        <input type="text" id="visa_exchage_rate_per_night" readonly="" name="exchage_rate_single[]" class="form-control">    
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="visa_exchage_rate_markup_total_per_night" readonly="" name="markup_total_per_night[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                            </span>
                                                        </div> 
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group">
                                                            <input type="text" id="total_visa_markup" name="markup_price[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                                <div id="more_visa_cost_div"></div>
                                                    
                                            </div>    
                                        </div>
                                            
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-xl-12" style="display:none;" id="all_services_markup">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="modal-title" id="standard-modalLabel">Markup on total price</h4>
                                            <div class="card-body">
                                               <div class="row">
                                                   
                                                    <div class="col-xl-6">
                                                        <div class="mb-3">
                                                            <label for="all_markup_type" class="form-label">Markup Type</label>
                                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Markup type"></i>
                                                             <select class="form-control" id="all_markup_type" name="all_markup_type" >
                                                                <option>Select Markup Type</option>
                                                                <option value="%">Percentage</option>
                                                                <option value="<?php echo $currency; ?>">Number</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                
                                                    <div class="col-xl-6">
                                                        <div class="mb-3">
                                                            <label for="all_markup_add" class="form-label">All Markup</label>
                                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="All Markup"></i>
                                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                <input type="text"  class="form-control" id="all_markup_add" name="all_markup_add">
                                                                <span class="input-group-btn input-group-append">
                                                                    <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="select_mrk">%</div></button>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                
                                               </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            
                            <div id="accomodation_price_hide" class="row mt-2 d-none">
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Quad Cost Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Quad Cost Price"></i>
                                        <div class="input-group">
                                            <input class="form-control" id="quad_cost_price" name="quad_cost_price" />
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                   <?php echo $currency; ?>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Triple Cost Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Triple Cost Price"></i>
                                        <div class="input-group">
                                            <input class="form-control" id="triple_cost_price" name="triple_cost_price" />
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                    <?php echo $currency; ?>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Double Cost Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Double Cost Price"></i>
                                        <div class="input-group">
                                            <input class="form-control" id="double_cost_price" name="double_cost_price" />
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                    <?php echo $currency; ?>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            
                            </div>
                        
                            <div class="row d-none" id="sale_pr">
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="" class="form-label quad_grand_total_amount">Quad Sale Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Quad Sale Price"></i>
                                        
                                        <div class="input-group">
                                            <!--<input class="form-control" id="quad_grand_total_amount" name="quad_grand_total_amount" />-->
                                            <input type="text" name="quad_grand_total_amount_single" class="form-control" id="quad_grand_total_amount">
                                            
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                                           <?php echo $currency; ?>
                                                        </a>
                                                    </span>
                                            <div class="invalid-feedback">
                                                This Field is Required
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="triple_grand_total_amount" class="form-label">Triple Sale Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Triple Sale Price"></i>
                                        <div class="input-group">
                                            <!--<input class="form-control" id="triple_grand_total_amount" name="triple_grand_total_amount" />-->
                                            <input type="text" name="triple_grand_total_amount_single" class="form-control" id="triple_grand_total_amount">
                                            
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                                           <?php echo $currency; ?>
                                                        </a>
                                                    </span>
                                            <div class="invalid-feedback">
                                                This Field is Required
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="double_grand_total_amount" class="form-label">Double Sale Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Double Sale Price"></i>
                                        <div class="input-group">
                                            <!--<input class="form-control" id="double_grand_total_amount" name="double_grand_total_amount" />-->
                                            <input type="text" name="double_grand_total_amount_single" class="form-control" id="double_grand_total_amount">
                                            
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                                           <?php echo $currency; ?>
                                                        </a>
                                                    </span>
                                            <div class="invalid-feedback">
                                                This Field is Required
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                            
                            <div class="row" id="markup_seprate_services" style="display:none;">
                                    <div class="col-xl-4">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label quad_markup">Quad Sale Price</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Quad Sale Price"></i>
                                            <input class="form-control" id="quad_markup" name="quad_grand_total_amount" />
                                            <!--<input type="text" name="quad_grand_total_amount" class="form-control" id="quad_markup" required>-->
                                            <!--<div class="invalid-feedback">-->
                                            <!--    This Field is Required-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                    <div class="col-xl-4">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label triple_markup">Triple Sale Price</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Triple Sale Price"></i>
                                            <input class="form-control" id="triple_markup" name="triple_grand_total_amount" />
                                            <!--<input type="text" name="triple_grand_total_amount" class="form-control" id="triple_markup" required>-->
                                            <!--<div class="invalid-feedback">-->
                                            <!--    This Field is Required-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                    <div class="col-xl-4">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label double_markup">Double Sale Price</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Double Sale Price"></i>
                                            <input class="form-control" id="double_markup" name="double_grand_total_amount" />
                                            <!--<input type="text" name="double_grand_total_amount" class="form-control" id="double_markup" required>-->
                                            <!--<div class="invalid-feedback">-->
                                            <!--    This Field is Required-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                </div>
                                
                            <div class="row">
                                <div class="col-xl-6">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Payment Methods</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payment GateWay"></i>
                                        <select class="form-control" id="payment_gateways" name="payment_gateways">
                                            <option value="">Select Payment Gateway</option>
                                            @if(isset($payment_gateways))
                                                @foreach($payment_gateways as $payment_gateways)
                                                    <option value="{{$payment_gateways->payment_gateway_title}}">{{$payment_gateways->payment_gateway_title}}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            
                                <div class="col-xl-6">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Payment Mode</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payment Mode"></i>
                                        <select class="select2 form-control select2-multiple external_packages" data-toggle="select2" multiple="multiple" id="payment_modes" name="payment_modes[]">
                                            <option value="">Select Payment Mode</option>
                                            @if(isset($payment_modes))
                                                @foreach($payment_modes as $payment_modes)
                                                    <option value="{{$payment_modes->payment_mode}}">{{$payment_modes->payment_mode}}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
    
                                <div class="col-xl-12">
                                    <label for="">Payment Instructions</label>
                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payment Instructions"></i>
                                    <textarea name="checkout_message" class="form-control" cols="5" rows="5" value="{{ $account_No }}">{{ $account_No }}</textarea>
                                </div>
                            </div>
      
                            <!--<a id="save_Costing" class="btn btn-primary" name="submit">Save Costing Details</a>-->
                            <button style="float: right;width: 100px;margin-top: 10px;" type="submit" name="submit" class="btn btn-info deletButton">Submit</button>
                        </div>
                        
                        <ul class="list-inline mb-0 wizard" style="margin-top:60px;">
                            <li class="previous list-inline-item">
                                <a href="javascript:void(0);" style="width: 100px;" class="btn btn-info">Previous</a>
                            </li>
                            <li class="next list-inline-item float-end">
                                <a href="javascript:void(0);" style="width: 100px;" id="" class="btn btn-info">Next</a>
                            </li>
                        </ul>
                                                
                    </div>
                    
                </div> 
            </form>
        <!--</div>-->
    </div>
</div>

@endsection

@section('scripts')

<script src="https://maps.googleapis.com/maps/api/js?libraries=places&callback=initAutocomplete&language=nl&output=json&key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY" async defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.20/summernote-bs5.min.js" integrity="sha512-6F1RVfnxCprKJmfulcxxym1Dar5FsT/V2jiEUvABiaEiFWoQ8yHvqRM/Slf0qJKiwin6IDQucjXuolCfCKnaJQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>

    $(document).on('change','#select_services' ,function(){
        var val = $('#select_services option:selected').val();
        //alert(val);
        if(val == 'flights_tab')
        {
            $("#accomodation_price_hide").css('display','none');
            $("#sale_pr").css('display','none');
        }
        if(val == 'visa_tab')
        {
            $("#accomodation_price_hide").css('display','none');
            $("#sale_pr").css('display','none');
        }
        if(val == 'transportation_tab')
        {
            $("#accomodation_price_hide").css('display','none');
            $("#sale_pr").css('display','none');
        }
    });

    function validate1(id) {
    	$('.file_error'+id+'').html("");
    	$('.gallery_imagesP'+id+'').css("border-color","#F0F0F0");
    	var file_size = $('.gallery_imagesP'+id+'')[0].files[0].size;
    	if(file_size > 100000) {
    		$('.file_error'+id+'').html("File size is greater than 100kb");
    		$('.gallery_imagesP'+id+'').css("border-color","#FF0000");
    		return false;
    	} 
    	return true;
    }
    
    function selectServices(){
        var selectedServices = $('#select_services').val();
        
        $.each(selectedServices, function(key, value) {
            if(value != null && value != ''){
                if((value == '1') || (value == 'accomodation_tab')){
                    $('.more_Div_Acc_All').css('display','');
                    $('.no_of_Nights_Other').html('No Of Nights');
                    $('.visa_type_select').css('display','');
                }else if(value == 'visa_tab'){
                    $('.visa_type_select').css('display','none');
                    $('.more_Div_Acc_All').css('display','none');
                }else{
                    $('.more_Div_Acc_All').css('display','none');
                    $('.no_of_Nights_Other').html('Total Duration');
                    $('.visa_type_select').css('display','');
                }
            }
        });
        
        const allServicesSelect = selectedServices.find(element => element == 1);
        
        if(allServicesSelect){
            $(".accomodation_tab").css('display','block');
            $(".flights_tab").css('display','block');
            $(".visa_tab").css('display','block');
            $(".transportation_tab").css('display','block');
        }else{
            $(".accomodation_tab").css('display','none');
            $(".flights_tab").css('display','none');
            $(".visa_tab").css('display','none');
            $(".transportation_tab").css('display','none');
            for(var i=0; i < selectedServices.length; i++){
                $("."+selectedServices[i]+"").css('display','flex');
            }
        }
    }
    
    var passengerCounter = 1;
     $('#no_of_pax_days').on('change',function(){
        var no_of_pax_days = $('#no_of_pax_days').val();
         $('#adult_number').val(no_of_pax_days);
         $('#reserved_pax').val(no_of_pax_days);
        var prev_value = $('#no_of_pax_prev').val();
        
        var difference = no_of_pax_days - prev_value;
        
        passengerCounter = +passengerCounter + +difference
         
         
         for(var i = prev_value; i<=no_of_pax_days; i++){
             id = +i + +1;
            //  console.log('id is now '+id);
         }
         
         $('#no_of_pax_prev').val(no_of_pax_days);
         var passengerHtml = `<div class="row other_passengers" style="border: 1px solid #ebebeb;padding: 1rem;border-radius: 6px;">
                                            <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label no_of_pax_days">First Name</label>
                                                    <input type="text" name="lead_fname" class="form-control" required>
                                                </div>
                                            </div>
                                            
                                             <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label no_of_pax_days">Last Name</label>
                                                    <input type="text" name="lead_fname" class="form-control" required>
                                                </div>
                                            </div>
                                            
                                                    
                                            <div class="col-xl-4">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label no_of_pax_days">Select Nationality</label>
                                                     <select type="text" class="form-control select2 " name="Country"  data-placeholder="Choose ...">
                                                        @foreach($all_countries as $country_res)
                                                            <option value="{{$country_res->id}}" id="categoriesPV" required>{{$country_res->name}}</option>
                                                           
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-2" >
                                                <div class="mb-3">
                                                     <p style="margin-top: 2.2rem;">Gender</p>
                                                </div>
                                            </div>
                                            
                                               
                                            <div class="col-2">
                                              <div class="form-check" style="margin-top: 2.2rem;">
                                              <input class="form-check-input" type="radio" name="gender" value="male"  id="flexRadioDefault3">
                                              <label class="form-check-label" for="flexRadioDefault3">
                                                Male
                                              </label>
                                            </div>
                                            
                                            </div>
                                            <div class="col-2" style="margin-top: 2.2rem;">
                                                <div class="form-check">
                                              <input class="form-check-input" type="radio" name="gender" value="female"  id="flexRadioDefault4">
                                              <label class="form-check-label" for="flexRadioDefault4">
                                                Female
                                              </label>
                                            </div>
                                            </div>
                                        </div>`
                                        // console.log("no_of_pax_days"+no_of_pax_days);
                                        
    })
    
</script>

<!--Package Save-->
<script>

    $("#selectAgent").click(function() {
        $('#lead_fnameI').val('');
        $('#lead_lnameI').val('');
        $('#lead_emailI').val('');
        $('#lead_mobileI').val('');
        
        if($("#selectAgent").is(':checked')){
            $("#selectcustomer").prop('checked', false);
            $('#customer_div').css('display','none')
            $('#agent_div').css('display','block')
            $('#customer_name').val('-1').change();
        }else {
            $('#agent_div').css('display','none')
        }
    });
        
    $("#selectcustomer").click(function() {
        $('#lead_fnameI').val('');
        $('#lead_lnameI').val('');
        $('#lead_emailI').val('');
        $('#lead_mobileI').val('');
        
        if($("#selectcustomer").is(':checked')){
            $("#selectAgent").prop('checked', false);
            $('#agent_div').css('display','none')
            $('#customer_div').css('display','block')
            $('#agent_Company_Name').val('').change();
            
        }else{
            $('#customer_div').css('display','none')
        }
    });
</script>
<!-- End Package Save-->

<!--Flights-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY&sensor=false&libraries=places"></script>
<!--End Flights-->

<script>

    $("#extra_price").on('click',function(){
        $("#extraprice_select").slideToggle();
    });
        
    $("#all_markup_type").change(function () {
    var id = $(this).find('option:selected').attr('value');
    
        $('#select_mrk').text(id);
    if(id == '%')
    {
        $('#all_markup_add').keyup(function() {
            
   var markup_val =  $('#all_markup_add').val();
   
       var quad_cost_price   =  $('#quad_cost_price').val();
       var triple_cost_price =  $('#triple_cost_price').val();
       var double_cost_price =  $('#double_cost_price').val();
       
        if(quad_cost_price != 0){
            var total_quad_cost_price1 = (quad_cost_price * markup_val/100) + parseFloat(quad_cost_price);
            var total_quad_cost_price = total_quad_cost_price1.toFixed(2); 
            $('#quad_markup').val(total_quad_cost_price);   
        }else{
           $('#quad_markup').val(0);
        }
   
      
        if(triple_cost_price != 0){
            var total_triple_cost_price1 = (triple_cost_price * markup_val/100) + parseFloat(triple_cost_price);
            var total_triple_cost_price = total_triple_cost_price1.toFixed(2);
            $('#triple_markup').val(total_triple_cost_price);    
        }else{
            $('#triple_markup').val(0);
        }
        
        if(double_cost_price != 0){
            var total_double_cost_price1 = (double_cost_price * markup_val/100) + parseFloat(double_cost_price);
            var total_double_cost_price = total_double_cost_price1.toFixed(2);
            $('#double_markup').val(total_double_cost_price);
        }else{
            $('#double_markup').val(0);
        }
        
        
        
 
});
       
       
    }
    else
    {
       $('#all_markup_add').keyup(function() {
            
   var markup_val =  $('#all_markup_add').val();
   
        var quad_cost_price =  $('#quad_cost_price').val();
        var triple_cost_price =  $('#triple_cost_price').val();
        var double_cost_price =  $('#double_cost_price').val();
        
        if(quad_cost_price != 0){
            var total_quad_cost_price1 =  parseFloat(quad_cost_price) +  parseFloat(markup_val);
            var total_quad_cost_price = total_quad_cost_price1.toFixed(2); 
            $('#quad_markup').val(total_quad_cost_price);  
        }else{
           $('#quad_markup').val(0);
        }
   
      
        if(triple_cost_price != 0){
            var total_triple_cost_price1 =  parseFloat(triple_cost_price) +  parseFloat(markup_val);
            var total_triple_cost_price = total_triple_cost_price1.toFixed(2);
            $('#triple_markup').val(total_triple_cost_price);    
        }else{
            $('#triple_markup').val(0);
        }
        
        if(double_cost_price != 0){
            var total_double_cost_price1 = parseFloat(double_cost_price) +  parseFloat(markup_val);
            var total_double_cost_price = total_double_cost_price1.toFixed(2);
            $('#double_markup').val(total_double_cost_price);
        }else{
            $('#double_markup').val(0);
        }
   
        // var total_quad_cost_price1 =  parseFloat(quad_cost_price) +  parseFloat(markup_val);
        // var total_quad_cost_price = total_quad_cost_price1.toFixed(2); 
        // $('#quad_markup').val(total_quad_cost_price);
        
        // var total_triple_cost_price1 =  parseFloat(triple_cost_price) +  parseFloat(markup_val);
        // var total_triple_cost_price = total_triple_cost_price1.toFixed(2);
        // $('#triple_markup').val(total_triple_cost_price);
        
        // var total_double_cost_price1 = parseFloat(double_cost_price) +  parseFloat(markup_val);
        // var total_double_cost_price = total_double_cost_price1.toFixed(2);
        // $('#double_markup').val(total_double_cost_price);
        
        
 
});
     
    }
      
  

  });

    $(document).on('click','#visa_inc',function(){
        $("#select_visa_inc").slideToggle();
        $('#visa_cost').toggle();
        
        $.ajax({    
           
            url: "super_admin/get_other_visa_type_detail", 
             type: "GET",
            dataType: "html",                  
            success: function(data){  
            
                var data1 = JSON.parse(data);
                var data2= JSON.parse(data1['visa_type']);
                //   console.log(data2['visa_type']);
                // jQuery.each(data2, function(key, value){  
                //     $(".other_type").append('<option value=' +value.id+ '>' + value.other_visa_type+ '</option>');
                //   });
            	$("#visa_type").empty();
           
                $.each(data2['visa_type'], function(key, value) {
                    var visa_type_Data = `<option attr="${value.other_visa_type}" value="${value.other_visa_type}"> ${value.other_visa_type}</option>`;
                    $("#visa_type").append(visa_type_Data);
                });  
            }
        });
    });
    
</script>
  
@stop

@section('slug')

<script>
    var Agents_detail = {!!json_encode($Agents_detail)!!};
    var all_countries = {!!json_encode($all_countries)!!};

    $('#agent_Company_Name').change(function () {
        var agent_Id = $(this).find('option:selected').attr('attr-Id');
        $('#agent_Id').val(agent_Id);
        
        var agent_Name = $(this).find('option:selected').attr('attr-AN');
        console.log('agent_Name : '+agent_Name);
        
        $('#agent_Name').val(agent_Name);
        
        $.each(Agents_detail, function(key, value) {
            var AD_id = value.id;
            if(AD_id == agent_Id){
                var lead_fname      = value.agent_Name;
                var lead_lname      = value.agent_Name;
                var lead_email      = value.agent_Email;
                var lead_mobile     = value.agent_contact_number;
                var company_name    = value.company_name;
                
                $('#lead_fnameI').val(company_name);
                $('#lead_lnameI').val(company_name);
                $('#lead_emailI').val(lead_email);
                $('#lead_mobileI').val(lead_mobile);
            }
        });
        
    });
    
    $('#customer_name').change(function () {
        var customer_data   = $(this).find('option:selected').attr('attr-cusData');
        var customer_data2  = JSON.parse(customer_data);
        var lead_fname      = customer_data2['name'];
        var lead_lname      = customer_data2['name'];
        var lead_email      = customer_data2['email'];
        var lead_mobile     = customer_data2['phone'];
        $('#lead_fnameI').val(lead_fname);
        $('#lead_lnameI').val(lead_lname);
        $('#lead_emailI').val(lead_email);
        $('#lead_mobileI').val(lead_mobile);
    });

    $('#transportation_price_per_vehicle').keyup(function() {
        
        $('#transportation_markup').val('');
        $('#transportation_markup_total').val('');
        
        $('#vehicle_markup_value').val('');
        $('#vehicle_total_price_with_markup').val('');
        $('#vehicle_markup_value_converted').val('');
        $('#vehicle_total_price_with_markup_converted').val('');
        
        $('#vehicle_per_markup_value').val('');
        $('#markup_price_per_vehicle_converted').val('');
        
        var transportation_price_per_vehicle    =  $('#transportation_price_per_vehicle').val();
        var transportation_no_of_vehicle        =  $('#transportation_no_of_vehicle').val();
        var no_of_pax_days                      =  $('#no_of_pax_days').val();
        var t_trans1                            =  transportation_price_per_vehicle * transportation_no_of_vehicle;
        var t_trans                             =  t_trans1.toFixed(2);
        $('#transportation_vehicle_total_price').val(t_trans);
        var total_trans1    = t_trans/no_of_pax_days;
        var total_trans     = total_trans1.toFixed(2);
        $('#transportation_price_per_person').val(total_trans);
        // $('#transportation_price_per_person_select').val(t_trans);
        
        $('#tranf_no_of_vehicle').val(transportation_no_of_vehicle);
        $('#tranf_price_per_vehicle').val(t_trans);
        $('#tranf_price_all_vehicle').val(total_trans);
        
        var select_exchange_type    = $('#vehicle_select_exchange_type_ID').val();
        var exchange_Rate           = $('#vehicle_exchange_Rate_ID').val();
        if(select_exchange_type == 'Divided'){
            var without_markup_price_converted_destination    = parseFloat(transportation_price_per_vehicle)/parseFloat(exchange_Rate);
            var transportation_vehicle_total_price_converted  = parseFloat(t_trans)/parseFloat(exchange_Rate);
            var transportation_price_per_person_converted     = parseFloat(total_trans)/parseFloat(exchange_Rate);
        }else{
            var without_markup_price_converted_destination    = parseFloat(transportation_price_per_vehicle) * parseFloat(exchange_Rate);
            var transportation_vehicle_total_price_converted  = parseFloat(t_trans) * parseFloat(exchange_Rate);
            var transportation_price_per_person_converted     = parseFloat(total_trans) * parseFloat(exchange_Rate);
        }
        
        without_markup_price_converted_destination   = without_markup_price_converted_destination.toFixed(2);
        transportation_vehicle_total_price_converted = transportation_vehicle_total_price_converted.toFixed(2);
        transportation_price_per_person_converted    = transportation_price_per_person_converted.toFixed(2);
        
        $('#without_markup_price_converted_destination').val(without_markup_price_converted_destination);
        $('#transportation_vehicle_total_price_converted').val(transportation_vehicle_total_price_converted);
        $('#transportation_price_per_person_converted').val(transportation_price_per_person_converted);
        
        $('#transportation_price_per_person_select').val(transportation_vehicle_total_price_converted);
        
        add_numberElseI();
        
    });

    $('#return_transportation_price_per_vehicle').keyup(function() {    
        var return_transportation_price_per_vehicle =  $('#return_transportation_price_per_vehicle').val();
        var return_transportation_no_of_vehicle     =  $('#return_transportation_no_of_vehicle').val();
        var no_of_pax_days                          =  $('#no_of_pax_days').val();
        var return_t_trans1                         = return_transportation_price_per_vehicle * return_transportation_no_of_vehicle;
        var return_t_trans                          = return_t_trans1.toFixed(2);
        console.log('return_t_trans'+return_t_trans);
        $('#return_transportation_vehicle_total_price').val(return_t_trans)
        var return_total_trans1 = return_t_trans/no_of_pax_days;
        var return_total_trans  = return_total_trans1.toFixed(2);
        console.log('return_total_trans'+return_total_trans);
        $('#return_transportation_price_per_person').val(return_total_trans)
        
        add_numberElseI();
    });

    $("#markup_type").change(function () {
        var id = $(this).find('option:selected').attr('value');
        
        $('#markup_value_markup_mrk').text(id);
        var markup_val =  $('#markup_value').val();
        
        var flights_prices =  $('#flights_prices').val();
        if(id == '%')
        {
            $('#markup_value').keyup(function() {
                var markup_val =  $('#markup_value').val();
                var total1 = (flights_prices * markup_val/100) + parseFloat(flights_prices) ;
                var total = total1.toFixed(2);
                $('#total_markup').val(total);
                add_numberElse_1I();
            });
        }
        else
        {
            $('#markup_value').keyup(function() {
                var markup_val =  $('#markup_value').val();
                console.log(markup_val);
                var total1 = parseFloat(flights_prices) + parseFloat(markup_val);
                var total = total1.toFixed(2);
                $('#total_markup').val(total);
                add_numberElse_1I();
            });
        }
    });
      
    $('#property_city').change(function(){
        var arr=[];
        $('#property_city option:selected').each(function(){
        var $value =$(this).attr('type');
        // console.log($value);
        arr.push($value);
    });
// console.log(arr);
var json_data=JSON.stringify(arr);
$('#tour_location_city').val(json_data); 
$('#packages_get_city').val(json_data);
 
}); 

    $("#transportation_pick_up_location").on('keyup',function () {
        setTimeout(function() { 
            var id = $('#transportation_pick_up_location').val();
            console.log('transportation_pick_up_location :'+id+'');
            $('#transportation_pick_up_location_select').val(id);
        }, 10000);
    });
    
    $("#transportation_drop_off_location").change(function () {
        setTimeout(function() { 
            var id = $('#transportation_drop_off_location').val();
            console.log('transportation_drop_off_location :'+id+'');
            $('#transportation_drop_off_location_select').val(id);
        }, 10000);
    });
        
    $("#return_transportation_pick_up_location").change(function () {
        var id = this.value;
        
        $('#return_transportation_pick_up_location_select').val(id);
        
        
        });
        
    $("#return_transportation_drop_off_location").change(function () {
        var id = this.value;
        
        $('#return_transportation_drop_off_location_select').val(id);
        
        
        });
        
    $("#transportation_price_per_person").change(function () {
        var id = this.value;
        
        $('#transportation_price_per_person_select').val(id);
        
        
        
        
        });
        
    $("#transportation_markup_type").change(function () {
            var id = $(this).find('option:selected').attr('value');
            $('#transportation_markup_mrk').text(id);
            if(id == '%')
            {
                $('#transportation_markup').keyup(function() {
                var markup_val =  $('#transportation_markup').val();
                var transportation_price =  $('#transportation_price_per_person_select').val();
                var total1 = (transportation_price * markup_val/100) + parseFloat(transportation_price);
                var total = total1.toFixed(2);
                $('#transportation_markup_total').val(total);
                
                // $('#transfer_markup_price_invoice').val(total);
                // $('#transfer_markup_type_invoice').val(id);
                // $('#transfer_markup_invoice').val(markup_val);
                
                $('.transfer_markup_price_invoice').val(total);
                $('.transfer_markup_type_invoice').val(id);
                $('.transfer_markup_invoice').val(markup_val);
                
                add_numberElse_1I();
                });
            }
            else
            {
                $('#transportation_markup').keyup(function() {
                var markup_val =  $('#transportation_markup').val();
                console.log(markup_val);
                var transportation_price =  $('#transportation_price_per_person_select').val();
                var total1 = parseFloat(transportation_price) + parseFloat(markup_val);
                var total = total1.toFixed(2);
                $('#transportation_markup_total').val(total);
                
                $('.transfer_markup_price_invoice').val(total);
                $('.transfer_markup_type_invoice').val(id);
                $('.transfer_markup_invoice').val(markup_val);
                
                add_numberElse_1I();
                });
            }
        });
  
    $("#slect_trip").change(function () {
        var id = $(this).find('option:selected').attr('value');
        // alert(id);
        if(id == 'Return')
        {
            $('#add_more_destination').fadeOut();
        	$('#select_return').fadeIn();
        }
        else if(id == 'All_Round')
        {
        	$('#select_return').fadeOut();
        	$('#add_more_destination').fadeIn();
        }
        else
        {
          	$('#select_return').fadeOut();
          	$('#add_more_destination').fadeOut();
        }
    });

</script>

<script>
    
    function add_numberElseI(){
        var flights_prices=parseFloat($("#flights_prices").val());  
        if(isNaN(flights_prices)) 
        {
            flights_prices=0;
        }
        else
        {
            var flights_prices=parseFloat($("#flights_prices").val()); 
        }
        var visa_price_select=parseFloat($("#visa_fee").val());  
        if(isNaN(visa_price_select)) 
        {
            visa_price_select=0;
        }
        else
        {
            var visa_price_select=parseFloat($("#visa_fee").val());
        }
  
        var transportation_price_per_person_select=parseFloat($("#transportation_price_per_person").val());
        if(isNaN(transportation_price_per_person_select)) 
        {
            transportation_price_per_person_select=0;
        }
        else
        {
            var transportation_price_per_person_select=parseFloat($("#transportation_price_per_person").val());
        }
        
        var count =$("#city_No").val();
        
        // var city_slc =$(".city_slc").val();
        // var count = city_slc.length;
        var quad_hotel=0;
        var triple_hotel=0;
        var double_hotel=0;
        var more_quad_hotel=0;
        var more_triple_hotel=0;
        var more_double_hotel=0;
   
        for(var i=1; i<=5; i++){
            var hotel_acc_type = $('#hotel_acc_type_'+i+'').val();
            var hotel_markup = parseFloat($("#hotel_acc_price_"+i+'').val());
            
            if(isNaN(hotel_markup)) 
            {
                hotel_markup=0;
            }
            else
            {
                var hotel_markup=parseFloat($("#hotel_acc_price_"+i+'').val());
            }
            
            if(hotel_acc_type == 'Quad')
            {
                quad_hotel = quad_hotel + hotel_markup;
                var quad_hotel1 = quad_hotel.toFixed(2);
                $('#quad_cost_price').val(quad_hotel1);
            }
            if(hotel_acc_type == 'Triple')
            {
                triple_hotel = triple_hotel + hotel_markup;
                var triple_hotel1 = triple_hotel.toFixed(2);
                $('#triple_cost_price').val(triple_hotel1);
            }
            if(hotel_acc_type == 'Double')
            {
                double_hotel = double_hotel + hotel_markup;
                var double_hotel1 = double_hotel.toFixed(2);
                $('#double_cost_price').val(double_hotel1);
            }
                   
        }
        
        var sumData = flights_prices + visa_price_select + transportation_price_per_person_select;
        if(quad_hotel != 0){
            var quadCost = quad_hotel + sumData;
        }else{
            var quadCost = 0;
        }
        if(triple_hotel != 0){
            var tripleCost = triple_hotel + sumData;
        }else{
            var tripleCost = 0;
        }
        if(double_hotel != 0){
            var doubleCost = double_hotel + sumData;
        }else{
            var doubleCost = 0;
        }
        quadCost = quadCost.toFixed(2);
        $('#quad_cost_price').val(quadCost);
        tripleCost = tripleCost.toFixed(2);
        $('#triple_cost_price').val(tripleCost);
        doubleCost = doubleCost.toFixed(2);
        $('#double_cost_price').val(doubleCost);
        
        for(var k=1; k<=50; k++){
            
            var more_hotel_acc_type=$('#more_hotel_acc_type_'+k+'').val(); 
            var more_hotel_markup=$('#more_hotel_acc_price_'+k+'').val();  
            
            if(isNaN(more_hotel_markup)) 
            {
                more_hotel_markup=0;
            }
            else
            {
                var more_hotel_markup=parseFloat($("#more_hotel_acc_price_"+k+'').val());
            }
            if(more_hotel_acc_type == 'Quad')
            {
               more_quad_hotel = more_quad_hotel + more_hotel_markup;
               var more_quad_hotel1 = more_quad_hotel.toFixed(2);
                 $('#quad_cost_price').val(more_quad_hotel1);
            }
            if(more_hotel_acc_type == 'Triple')
            {
                more_triple_hotel = more_triple_hotel + more_hotel_markup;
                var more_triple_hotel1 = more_triple_hotel.toFixed(2);
                $('#triple_cost_price').val(more_triple_hotel1);
            }
            if(more_hotel_acc_type == 'Double')
            {
               more_double_hotel = more_double_hotel + more_hotel_markup;
               var more_double_hotel1 = more_double_hotel.toFixed(2);
                $('#double_cost_price').val(more_double_hotel1);
            }
        }
        
        var morequadCost = sumData + more_quad_hotel;
        morequadCost = morequadCost.toFixed(2);
        
        if(more_quad_hotel == 0){
            if(quadCost != 0){
                $('#quad_cost_price').val(quadCost);   
            }else{
                $('#quad_cost_price').val(0);   
            }
        }else{
            $('#quad_cost_price').val(morequadCost);   
        }
        
        var moretripleCost = sumData + more_triple_hotel;
        moretripleCost = moretripleCost.toFixed(2);
        
        if(more_triple_hotel == 0){
            if(tripleCost != 0){
                $('#triple_cost_price').val(tripleCost);   
            }else{
                $('#triple_cost_price').val(0);   
            }  
        }else{
            $('#triple_cost_price').val(moretripleCost);   
        }
        
        
        var moredoubleCost = sumData + more_double_hotel;
        moredoubleCost = moredoubleCost.toFixed(2);
        
        if(more_double_hotel == 0){
            if(doubleCost != 0){
                //$('#double_cost_price').val(doubleCost);   
            }else{
                $('#double_cost_price').val(0);   
            }   
        }else{
            //$('#double_cost_price').val(moredoubleCost);
        }
    }
    
    function add_numberElse_1I(){
        var count =$("#city_No").val();
        // var city_slc =$(".city_slc").val();
        // var count = city_slc.length;
        var quad_hotel=0;
        var triple_hotel=0;
        var double_hotel=0;
        var more_quad_hotel=0;
        var more_triple_hotel=0;
        var more_double_hotel=0;
        
        var total_markup = parseFloat($("#total_markup").val());  
        if(isNaN(total_markup)) 
        {
            total_markup=0;
        }
        else
        {
            var total_markup=parseFloat($("#total_markup").val()); 
        }
        
        var total_visa_markup = parseFloat($("#total_visa_markup").val());  
        if(isNaN(total_visa_markup)) 
        {
            total_visa_markup=0;
        }
        else
        {
            var total_visa_markup = parseFloat($("#total_visa_markup").val());
        }
        
        var transportation_markup_total=parseFloat($("#transportation_markup_total").val());
        if(isNaN(transportation_markup_total)) 
        {
            transportation_markup_total=0;
        }
        else
        {
            var transportation_markup_total=parseFloat($("#transportation_markup_total").val());
        }
       
        for(var i=1; i<=10; i++){
            
            var hotel_acc_type=$('#hotel_acc_type_'+i+'').val();
            var hotel_markup=parseFloat($("#hotel_markup_total_"+i+'').val());
            
            if(isNaN(hotel_markup)) 
            { 
                hotel_markup=0;
            }
            else
            {
                // console.log("hotel_markup : " + hotel_markup);
                var hotel_markup = parseFloat($("#hotel_markup_total_"+i+'').val());
            }
            
            if(hotel_acc_type == 'Quad')
            {
                quad_hotel      = quad_hotel + hotel_markup + more_quad_hotel;
                var quad_hotel1 = quad_hotel.toFixed(2);
                $('#quad_grand_total_amount').val(quad_hotel1);
            }
            if(hotel_acc_type == 'Triple')
            {
                triple_hotel        = triple_hotel  +hotel_markup + more_triple_hotel;
                var triple_hotel1   = triple_hotel.toFixed(2);
                $('#triple_grand_total_amount').val(triple_hotel1);
            }
            if(hotel_acc_type == 'Double')
            {
                double_hotel        = double_hotel + hotel_markup  + more_double_hotel;
                var double_hotel1   = double_hotel.toFixed(2);
                $('#double_grand_total_amount').val(double_hotel1);
            }
        }
        
        var sumData = total_markup + total_visa_markup + transportation_markup_total;
        $('#without_acc_sale_price').val(sumData);
        
        
        if(quad_hotel != 0){
           var quadCost = quad_hotel + sumData;
        }else{
            var quadCost = 0;
        }
        
        if(triple_hotel != 0){
            var tripleCost = triple_hotel + sumData;
        }else{
            var tripleCost = 0;
        }
        
        if(double_hotel != 0){
            var doubleCost = double_hotel + sumData;
        }else{
            var doubleCost = 0;
        }
        
        quadCost = quadCost.toFixed(2);
        $('#quad_grand_total_amount').val(quadCost);
        tripleCost = tripleCost.toFixed(2);
        $('#triple_grand_total_amount').val(tripleCost);
        doubleCost = doubleCost.toFixed(2);
        $('#double_grand_total_amount').val(doubleCost);
        
        for(var k=1; k<=20; k++){
            var more_hotel_acc_type = $('#more_hotel_acc_type_'+k+'').val(); 
            var more_hotel_markup   = $('#more_hotel_markup_total_'+k+'').val();
            if(isNaN(more_hotel_markup)) 
            {
                more_hotel_markup=0;
            }
            else
            {
                var more_hotel_markup=parseFloat($("#more_hotel_markup_total_"+k+'').val());
                // $('#more_hotel_invoice_markup_'+k+'').val(more_hotel_markup);
            }
            if(more_hotel_acc_type == 'Quad')
            {
                more_quad_hotel         = more_quad_hotel + more_hotel_markup;
                var more_quad_hotel1    = 0;
                more_quad_hotel1        = more_quad_hotel.toFixed(2);
                $('#quad_grand_total_amount').val(more_quad_hotel1);
            }
            if(more_hotel_acc_type == 'Triple')
            {
                more_triple_hotel       = more_triple_hotel + more_hotel_markup;
                var more_triple_hotel1  = 0;
                more_triple_hotel1      = more_triple_hotel.toFixed(2);
                $('#triple_grand_total_amount').val(more_triple_hotel1);
            }
            if(more_hotel_acc_type == 'Double')
            {
                more_double_hotel       = more_double_hotel +more_hotel_markup;
                var more_double_hotel1  = 0;
                more_double_hotel1      = more_double_hotel.toFixed(2);
                $('#double_grand_total_amount').val(more_double_hotel1);
            }
        }
    
        var morequadCost = sumData + more_quad_hotel;
        morequadCost = morequadCost.toFixed(2);
        
        if(more_quad_hotel == 0){
            if(quadCost != 0){
                $('#quad_grand_total_amount').val(quadCost);   
            }else{
                $('#quad_grand_total_amount').val(0);   
            }   
        }else{
            $('#quad_grand_total_amount').val(morequadCost);   
        }
        
        var moretripleCost = sumData + more_triple_hotel;
        moretripleCost = moretripleCost.toFixed(2);
        
        if(more_triple_hotel == 0){
            if(tripleCost != 0){
                $('#triple_grand_total_amount').val(tripleCost);   
            }else{
                $('#triple_grand_total_amount').val(0);   
            }   
        }else{
            $('#triple_grand_total_amount').val(moretripleCost);   
        }
        
        var moredoubleCost = sumData + more_double_hotel;
        moredoubleCost = moredoubleCost.toFixed(2);
        
        if(more_double_hotel == 0){
            if(doubleCost != 0){
                $('#double_grand_total_amount').val(doubleCost);   
            }else{
                $('#double_grand_total_amount').val(0);   
            }   
        }else{
            $('#double_grand_total_amount').val(moredoubleCost);
        }
    }
        
</script>

<script>

    $(".CC_id_store").change(function (){
        var CC_id_store =  $(this).find('option:selected').attr('attr_id');
        $("#conversion_type_Id").val(CC_id_store);
    });
    
    var user_hotels = {!!json_encode($user_hotels)!!};
    
    // Transportation
    $('#transportation_drop_of_date').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var transportation_drop_of_date = $(this).val();
        var transportation_pick_up_date = $('#transportation_pick_up_date').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var date1 = new Date(transportation_pick_up_date);
        var date2 = new Date(transportation_drop_of_date);
        var timediff = date2 - date1;
        
        var minutes_Total = Math.floor(timediff / minute);
        
        var total_hours   = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        
        var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        $('#transportation_Time_Div').css('display','');
        $('#transportation_total_Time').val(total_hours+h+ ' : ' +minutes+m);
        
    });
    
    $('#return_transportation_drop_of_date').change(function () {
        
        var h = "hours";
        var m = "minutes";
        
        var return_transportation_drop_of_date = $(this).val();
        var return_transportation_pick_up_date = $('#return_transportation_pick_up_date').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        
        var return_date1 = new Date(return_transportation_pick_up_date);
        var return_date2 = new Date(return_transportation_drop_of_date);
        var return_timediff = return_date2 - return_date1;
        
        var return_minutes_Total = Math.floor(return_timediff / minute);
        
        var return_total_hours   = Math.floor(return_timediff / hour)
        var return_total_hours_minutes = parseFloat(return_total_hours) * 60;
        
        var return_minutes = parseFloat(return_minutes_Total) - parseFloat(return_total_hours_minutes);
        
        $('#return_transportation_Time_Div').css('display','');
        $('#return_transportation_total_Time').val(return_total_hours+h+ ' : ' +return_minutes+m);
    
    });
    
    function addGoogleApi(id){
        var places = new google.maps.places.Autocomplete(
            document.getElementById(id)
        );
        
        google.maps.event.addListener(places, "place_changed", function () {
            var place = places.getPlace();
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var latlng = new google.maps.LatLng(latitude, longitude);
            var geocoder = (geocoder = new google.maps.Geocoder());
            geocoder.geocode({ latLng: latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var address = results[0].formatted_address;
                        var pin =
                        results[0].address_components[
                    results[0].address_components.length - 1
                  ].long_name;
                        var country =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].long_name;
                        var state =
                          results[0].address_components[
                            results[0].address_components.length - 3
                          ].long_name;
                        var city =
                          results[0].address_components[
                            results[0].address_components.length - 4
                          ].long_name;
                        var country_code =
                          results[0].address_components[
                            results[0].address_components.length - 2
                          ].short_name;
                        $('#country').val(country);
                        $('#lat').val(latitude);
                        $('#long').val(longitude);
                        $('#pin').val(pin);
                        $('#city').val(city);
                        $('#country_code').val(country_code);
                        $('#pickup_CountryCode').val(country_code)
                    }
                }
            });
        });
    }
    
    var MTD_id = 1;
    $("#more_transportationI").click(function(){
        var data = `<div class="row" id="click_delete_${MTD_id}">
                        <div class="col-xl-3" style="padding: 10px;">
                            <label for="">Pick-up Location</label>
                            <input type="text" id="more_transportation_pick_up_location_${MTD_id}" name="more_transportation_pick_up_location[]" class="form-control">
                        </div>
                        <div class="col-xl-3" style="padding: 10px;">
                            <label for="">Drop-off Location</label>
                            <input type="text" id="more_transportation_drop_off_location_${MTD_id}" name="more_transportation_drop_off_location[]" class="form-control">
                        </div>
                        <div class="col-xl-3" style="padding: 10px;">
                            <label for="">Pick-up Date & Time</label>
                            <input type="datetime-local" id="more_transportation_pick_up_date_${MTD_id}" name="more_transportation_pick_up_date[]" class="form-control">
                        </div>
                        
                        <div class="col-xl-3" style="padding: 10px;">
                            <label for="">Drop-of Date & Time</label>
                            <input type="datetime-local" id="more_transportation_drop_of_date_${MTD_id}" name="more_transportation_drop_of_date[]" class="form-control">
                        </div>
                        
                        <div class="col-xl-3" style="display:none;padding: 10px;" id="more_transportation_Time_Div_${MTD_id}">
                            <label for="">Estimate Time</label>
                            <input type="text" id="more_transportation_total_Time_${MTD_id}" name="more_transportation_total_Time[]" class="form-control" readonly style="padding: 10px;">
                        </div>
                        
                        <div class="mt-2">
                            <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRowTransI(${MTD_id})"  id="${MTD_id}">Delete</button>
                        </div>
                    </div>`;
        $("#append_transportation").append(data);
        
        addGoogleApi('more_transportation_pick_up_location_'+MTD_id+'');
        addGoogleApi('more_transportation_drop_off_location_'+MTD_id+'');
        
        $('#more_transportation_drop_of_date_'+MTD_id+'').change(function () {
        
            var h = "hours";
            var m = "minutes";
            
            var transportation_drop_of_date = $('#more_transportation_drop_of_date_'+MTD_id+'').val();
            var transportation_pick_up_date = $('#more_transportation_pick_up_date_'+MTD_id+'').val();
            
            var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
            
            var date1 = new Date(transportation_pick_up_date);
            var date2 = new Date(transportation_drop_of_date);
            var timediff = date2 - date1;
            
            var minutes_Total = Math.floor(timediff / minute);
            
            var total_hours   = Math.floor(timediff / hour)
            var total_hours_minutes = parseFloat(total_hours) * 60;
            
            var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
            
            $('#more_transportation_Time_Div_'+MTD_id+'').css('display','');
            $('#more_transportation_total_Time_'+MTD_id+'').val(total_hours+h+ ' : ' +minutes+m);
            
        });
    
        MTD_id++;
    });
    
    function deleteRowTransI(id){
        $('#click_delete_'+id+'').remove();
    }
    
    var destination_details = {!!json_encode($destination_details)!!};
    
    $('#transfer_supplier').change(function (){
        var ids = $(this).find('option:selected').attr('attr-id');
        
        $('#transfer_supplier_selected_id').val(ids);
        
        $('#transfer_supplier_list_body').empty();
        // $('#transportation_main_divI').empty();
        var i = 1;
        $.each(destination_details, function(key, value) {
            var vehicle_detailsE    = value.vehicle_details;
            var transfer_type       = value.transfer_type;
            
            if(vehicle_detailsE != null && vehicle_detailsE != ''){
                var vehicle_details = JSON.parse(vehicle_detailsE);
                $.each(vehicle_details, function(key, value1) {
                    var vehicle_id = value1.vehicle_id;
                    // console.log('vehicle_id : '+vehicle_id);
                    var transfer_supplier_Id = value1.transfer_supplier_Id;
                    if(ids == transfer_supplier_Id){
                        $('#transfer_supplier_list_div').css('display','');
                        var TS_data =  `<tr>
                                            <td>${value.id}<input type="hidden" value="${value.id}" id="transfer_id_td_${i}"><input type="hidden" value="${value1.vehicle_id}" id="transfer_vehicle_id_td_${i}"></td>
                                            <td>${value.transfer_company}<input type="hidden" value="${value.transfer_company}" id="transfer_company_td_${i}"></td>
                                            <td>${value.pickup_City}<input type="hidden" value="${value.pickup_City}" id="pickup_City_td_${i}"></td>
                                            <td>${value.dropof_City}<input type="hidden" id="dropof_City_td_${i}" value="${value.dropof_City}"></td>
                                            <td>${value.available_from}<input type="hidden"id="available_from_td_${i}" value="${value.available_from}"></td>
                                            <td>${value.available_to}<input type="hidden" id="available_to_td_${i}" value="${value.available_to}"></td>
                                            <td>${value.transfer_type}<input type="hidden" id="transfer_Type_td_${i}" value="${value.transfer_type}"></td>
                                            <td>${value1.vehicle_Fare}<input type="hidden" id="total_fare_markup_td_${i}" value="${value.vehicle_Fare}"></td>
                                            <td>
                                                <input type="hidden" id="ocupancy_btn_switch_${i}" value="0" class="ocupancy_btn_switch_class_all">
                                                <a type="button" class="btn btn-primary ocupancy_btn_class_all" id="occupy_btn_${i}" onclick="occupy_function(${i})">Occupy</a>
                                            </td>
                                        </tr>`;
                        $('#transfer_supplier_list_body').append(TS_data);
                        i = i + 1;
                    }
                    
                });
            }
        });
    });
    
    var TD_id1  = 1;
    var MTD_id1 = 1;
    
    function occupy_function(id){
        var transfer_supplier_id    = $('#transfer_supplier').find('option:selected').attr('attr-id');
        var transfer_id_td          = $('#transfer_id_td_'+id+'').val();
        var transfer_Type_td        = $('#transfer_Type_td_'+id+'').val();
        var transfer_vehicle_id_td  = $('#transfer_vehicle_id_td_'+id+'').val();
        var ocupancy_btn_switch     = $('#ocupancy_btn_switch_'+id+'').val();
        
        $.each(destination_details, function(key, value) {
            
            var id_DD                   = value.id
            var transfer_type           = value.transfer_type;
            var select_exchange_type    = value.select_exchange_type;
            $('#vehicle_select_exchange_type_ID').val(select_exchange_type);
            
            if(id_DD == transfer_id_td){
                
                if(transfer_Type_td == "One-Way"){
                    
                    $('#vehicle_markup_type').val('');
                    $('#vehicle_markup_value').val('');
                    $('#vehicle_total_price_with_markup').val('');
                    $('#vehicle_markup_value_converted').val('');
                    $('#vehicle_total_price_with_markup_converted').val('');
                    $('#vehicle_per_markup_value').val('');
                    $('#markup_price_per_vehicle_converted').val('');
                    
                    $('#currency_SAR').val('');
                    $('#currency_GBP').val('');
                    
                    $('#without_markup_price_converted_destination').val('');
                    $('#transportation_vehicle_total_price_converted').val('');
                    $('#transportation_price_per_person_converted').val('');
                    
                    $('#transportation_markup').val('');
                    $('#transportation_markup_total').val('');
                    
                    $('#transportation_price_per_person_select').val(0);
                    
                    $('#transportation_cost').css('display','');
                    
                    $('.ocupancy_btn_class_all').css('background-color','rebeccapurple');
                    $('.ocupancy_btn_switch_class_all').val(0);
                    
                    $('#transportation_pick_up_date').val('');
                    $('#transportation_drop_of_date').val('');
                    $('#transportation_total_Time').val('');
                    $('#transportation_Time_Div').css('display','');
                    
                    $('#select_transportation').css('display','');
                    $('#select_return').css('display','none');
                    
                    $("#append_transportation").empty();
                    $('#add_more_destination').css('display','none');
                    
                    $("#transportation_main_divI").empty();
                    $('#transportation_main_divI').css('display','none');
                    
                    $('#return_transportation_pick_up_location').val('');
                    $('#return_transportation_drop_off_location').val('');
                    $('#return_transportation_Time_Div').css('display','none');
                    $('#return_transportation_pick_up_date').val('');
                    $('#return_transportation_drop_of_date').val('');
                    $('#return_transportation_total_Time').val('');
                    
                    $('#transportation_no_of_vehicle').val('');
                    $('#transportation_vehicle_total_price').val('');
                    $('#transportation_price_per_person').val('');
                    
                    var pickup_City = value.pickup_City;
                    var dropof_City = value.dropof_City;
                    
                    var destination_id = value.id;
                    $('#destination_id').val(destination_id);
                    
                    $('#transportation_pick_up_location').val(pickup_City);
                    $('#transportation_drop_off_location').val(dropof_City);
                    
                    $('#transportation_pick_up_location_select').val(pickup_City);
                    $('#transportation_drop_off_location_select').val(dropof_City);
                    
                    $('#slect_trip').empty();
                    slect_trip_data =  `<option value="One-Way" Selected>One-Way</option>`;
                    $('#slect_trip').append(slect_trip_data);
                    
                    var vehicle_detailsE = value.vehicle_details;
                    if(vehicle_detailsE != null && vehicle_detailsE != ''){
                        var vehicle_details = JSON.parse(vehicle_detailsE);
                        $.each(vehicle_details, function(key, value1) {
                            var transfer_supplier_Id    = value1.transfer_supplier_Id;
                            var total_fare_markup       = value1.total_fare_markup;
                            var vehicle_Name            = value1.vehicle_Name;
                            var vehicle_Fare            = value1.vehicle_Fare;
                            var vehicle_total_Fare      = value1.vehicle_total_Fare;
                            var exchange_Rate           = value1.exchange_Rate;
                            var vehicle_id              = value1.vehicle_id;
                            
                            if(transfer_supplier_id == transfer_supplier_Id){
                                if(transfer_vehicle_id_td == vehicle_id){
                                
                                    $('#transportation_vehicle_typeI').empty();
                                    var transportation_vehicle_type_Data = `<option value="${vehicle_Name}" Selected>${vehicle_Name}</option>`;
                                    $('#transportation_vehicle_typeI').append(transportation_vehicle_type_Data);
                                    
                                    $('#transportation_price_per_vehicle').val(vehicle_Fare);
                                    $('#without_markup_price_converted_destination').val(vehicle_total_Fare);
                                    $('#transfer_exchange_rate_destination').val(exchange_Rate);
                                    
                                    $('#vehicle_exchange_Rate_ID').val(exchange_Rate);
                                    
                                    // $('#transportation_price_per_vehicle').val(total_fare_markup);
                                    // $('#transportation_price_per_person_select').val(total_fare_markup);
                                }
                            }
                            
                        });
                    }
                    
                    var currency_conversion = value.currency_conversion;
                    console.log(currency_conversion);
                                    
                    var value_c         = value.currency_conversion;
                    const usingSplit    = value_c.split(' ');
                    var value_1         = usingSplit['0'];
                    var value_2         = usingSplit['2'];
                    $(".currency_value1_T").html(value_1);
                    $(".currency_value_exchange_1_T").html(value_2);
                    
                    $("#currency_SAR").val(value_1);
                    $("#currency_GBP").val(value_2);
                    
                    exchange_currency_funs(value_1,value_2);
                }
                else if(transfer_Type_td == "Return"){
                    
                    $('#vehicle_markup_type').val('');
                    $('#vehicle_markup_value').val('');
                    $('#vehicle_total_price_with_markup').val('');
                    $('#vehicle_markup_value_converted').val('');
                    $('#vehicle_total_price_with_markup_converted').val('');
                    $('#vehicle_per_markup_value').val('');
                    $('#markup_price_per_vehicle_converted').val('');
                    
                    $('#currency_SAR').val('');
                    $('#currency_GBP').val('');
                    
                    $('#without_markup_price_converted_destination').val('');
                    $('#transportation_vehicle_total_price_converted').val('');
                    $('#transportation_price_per_person_converted').val('');
                    
                    $('#transportation_markup').val('');
                    $('#transportation_markup_total').val('');
                    
                    $('#transportation_price_per_person_select').val(0);
                    
                    $('#transportation_cost').css('display','');
                    
                    $('#return_transportation_Time_Div').css('display','');
                    $('#return_transportation_pick_up_date').val('');
                    $('#return_transportation_drop_of_date').val('');
                    $('#return_transportation_total_Time').val('');
                    
                    $('#transportation_no_of_vehicle').val('');
                    $('#transportation_vehicle_total_price').val('');
                    $('#transportation_price_per_person').val('');
                    
                    $('#transportation_pick_up_date').val('');
                    $('#transportation_drop_of_date').val('');
                    $('#transportation_total_Time').val('');
                    $('#transportation_Time_Div').css('display','none');
                    
                    $('#select_transportation').css('display','');
                    $('#select_return').css('display','');
                    
                    $("#append_transportation").empty();
                    $('#add_more_destination').css('display','none');
                    
                    $("#transportation_main_divI").empty();
                    $('#transportation_main_divI').css('display','none');
                    
                    $('.ocupancy_btn_class_all').css('background-color','rebeccapurple');
                    $('.ocupancy_btn_switch_class_all').val(0)
                    
                    var pickup_City     = value.pickup_City;
                    var dropof_City     = value.dropof_City;
                    
                    var destination_id  = value.id;
                    $('#destination_id').val(destination_id);
                    
                    $('#transportation_pick_up_location').val(pickup_City);
                    $('#transportation_drop_off_location').val(dropof_City);
                    
                    $('#transportation_pick_up_location_select').val(pickup_City);
                    $('#transportation_drop_off_location_select').val(dropof_City);
                    
                    $('#slect_trip').empty();
                    slect_trip_data =  `<option value="Return" Selected>Return</option>`;
                    $('#slect_trip').append(slect_trip_data);
                    
                    var vehicle_detailsE = value.vehicle_details;
                    if(vehicle_detailsE != null && vehicle_detailsE != ''){
                        var vehicle_details = JSON.parse(vehicle_detailsE);
                        $.each(vehicle_details, function(key, value1) {
                            var transfer_supplier_Id    = value1.transfer_supplier_Id;
                            var total_fare_markup       = value1.total_fare_markup;
                            var vehicle_Name            = value1.vehicle_Name;
                            var vehicle_Fare            = value1.vehicle_Fare;
                            var vehicle_total_Fare      = value1.vehicle_total_Fare;
                            var exchange_Rate           = value1.exchange_Rate;
                            var vehicle_id              = value1.vehicle_id;
                            
                            if(transfer_supplier_id == transfer_supplier_Id){
                                if(transfer_vehicle_id_td == vehicle_id){
                                    $('#transportation_vehicle_typeI').empty();
                                    var transportation_vehicle_type_Data = `<option value="${vehicle_Name}" Selected>${vehicle_Name}</option>`;
                                    $('#transportation_vehicle_typeI').append(transportation_vehicle_type_Data);
                                    
                                    $('#transportation_price_per_vehicle').val(vehicle_Fare);
                                    $('#without_markup_price_converted_destination').val(vehicle_total_Fare);
                                    $('#transfer_exchange_rate_destination').val(exchange_Rate);
                                    
                                    $('#vehicle_exchange_Rate_ID').val(exchange_Rate);
                                    
                                    // $('#transportation_price_per_vehicle').val(total_fare_markup);
                                    // $('#transportation_price_per_person_select').val(total_fare_markup);
                                }
                            }
                            
                        });
                    }
                    
                    var return_pickup_City  = value.return_pickup_City;
                    var return_dropof_City  = value.return_dropof_City;
                    
                    $('#return_transportation_pick_up_location').val(return_pickup_City);
                    $('#return_transportation_drop_off_location').val(return_dropof_City);
                    
                    var currency_conversion = value.currency_conversion;
                    console.log(currency_conversion);
                    var value_c         = value.currency_conversion;
                    const usingSplit    = value_c.split(' ');
                    var value_1         = usingSplit['0'];
                    var value_2         = usingSplit['2'];
                    $(".currency_value1_T").html(value_1);
                    $(".currency_value_exchange_1_T").html(value_2);
                    
                    $("#currency_SAR").val(value_1);
                    $("#currency_GBP").val(value_2);
                    
                    exchange_currency_funs(value_1,value_2);
                }
                else{
                    
                    if(ocupancy_btn_switch == 0){
                        
                        $('#vehicle_select_exchange_type').val('');
                        
                        $('#vehicle_markup_type').val('');
                        $('#vehicle_markup_value').val('');
                        $('#vehicle_total_price_with_markup').val('');
                        $('#vehicle_markup_value_converted').val('');
                        $('#vehicle_total_price_with_markup_converted').val('');
                        $('#vehicle_per_markup_value').val('');
                        $('#markup_price_per_vehicle_converted').val('');
                        
                        $('#currency_SAR').val('');
                        $('#currency_GBP').val('');
                        
                        $('#vehicle_select_exchange_type_ID').val('');
                        $('#vehicle_exchange_Rate_ID').val('');
                        
                        $('#without_markup_price_converted_destination').val('');
                        $('#transportation_vehicle_total_price_converted').val('');
                        $('#transportation_price_per_person_converted').val('');
                        
                        $('#transfer_markup_type_invoice').val('');
                        $('#transfer_markup_invoice').val('');
                        $('#transfer_markup_price_invoice').val('');
                        $('#transfer_exchange_rate_destination').val('');
                        
                        $('#destination_id').val('');
                        
                        $('#transportation_markup').val('');
                        $('#transportation_markup_total').val('');
                        
                        $('#transportation_price_per_person_select').val(0);
                        
                        $('#transportation_cost').css('display','');
                    
                        $('#occupy_btn_'+id+'').css('background-color','red');
                        
                        $('#transportation_main_divI').css('display','');
                        
                        $('#select_transportation').css('display','none');
                        $('#select_return').css('display','none');
                        
                        $("#append_transportation").empty();
                        
                        $('#return_transportation_pick_up_location').val('');
                        $('#return_transportation_drop_off_location').val('');
                        $('#return_transportation_Time_Div').css('display','none');
                        $('#return_transportation_pick_up_date').val('');
                        $('#return_transportation_drop_of_date').val('');
                        $('#return_transportation_total_Time').val('');
                        
                        $('#transportation_pick_up_location').val('');
                        $('#transportation_drop_off_location').val('');
                        $('#transportation_Time_Div').css('display','none');
                        $('#transportation_pick_up_date').val('');
                        $('#transportation_drop_of_date').val('');
                        $('#transportation_total_Time').val('');
                        
                        $('#slect_trip').empty();
                        slect_trip_data =  `<option></option>
                                            <option value="One-Way">One-Way</option>
                                            <option value="Return">Return</option>
                                            <option value="All_Round">All Round</option>`;
                        $('#slect_trip').append(slect_trip_data);
                        $('#transportation_price_per_vehicle').val('');
                        $('#transportation_no_of_vehicle').val('');
                        $('#transportation_vehicle_total_price').val('');
                        $('#transportation_price_per_person').val('');
                        $('#transportation_vehicle_typeI').empty();
                        TVTI_data = `<option value=""></option>
                                    <option value="Bus">Bus</option>
                                    <option value="Coach">Coach</option>
                                    <option value="Vain">Vain</option>
                                    <option value="Car">Car</option>`;
                        $('#transportation_vehicle_typeI').append(TVTI_data);
                        
                        var pickup_City = value.pickup_City;
                        var dropof_City = value.dropof_City;
                        
                        $('#transportation_pick_up_location_select').val(pickup_City);
                        $('#transportation_drop_off_location_select').val(dropof_City);
                    
                        var allR_data = `<div class="row" id="allRound_Div_${TD_id1}">
                                            <h3>Transportation Details :</h3>
                                            
                                            <input type="hidden" value="All_Round${TD_id1}" name="all_round_Type[]" id="all_round_Type_${TD_id1}">
                                            
                                            <input type="hidden" name="destination_id[]" id="destination_id_${TD_id1}">
                                            
                                            <input type="hidden" name="vehicle_select_exchange_type[]" id="vehicle_select_exchange_type_ID_${TD_id1}" value="${select_exchange_type}">
                                        
                                            <input type="hidden" name="vehicle_exchange_Rate[]" id="vehicle_exchange_Rate_ID_${TD_id1}">
                                            
                                            <input type="hidden" name="currency_SAR[]" id="currency_SAR_${TD_id1}">
                                            
                                            <input type="hidden" name="currency_GBP[]" id="currency_GBP_${TD_id1}">
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Pick-up Location</label>
                                                <input type="text" value="${pickup_City}" id="transportation_pick_up_location_${TD_id1}" name="transportation_pick_up_location[]" class="form-control pickup_location">
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Drop-off Location</label>
                                                <input type="text" value="${dropof_City}" id="transportation_drop_off_location_${TD_id1}" name="transportation_drop_off_location[]" class="form-control dropof_location">
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Pick-up Date & Time</label>
                                                <input type="datetime-local" id="transportation_pick_up_date_${TD_id1}" name="transportation_pick_up_date[]" class="form-control" onchange="TPUD_function(${TD_id1})">
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Drop-of Date & Time</label>
                                                <input type="datetime-local" id="transportation_drop_of_date_${TD_id1}" name="transportation_drop_of_date[]" class="form-control" onchange="TDOP_function(${TD_id1})">
                                            </div>
                                            
                                            <div class="col-xl-3" style="display:none" id="transportation_Time_Div_${TD_id1}">
                                                <label for="">Estimate Time</label>
                                                <input type="text" id="transportation_total_Time_${TD_id1}" name="transportation_total_Time[]" class="form-control transportation_total_Time1" readonly style="padding: 10px;">
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Select Trip Type</label>
                                                <select name="transportation_trip_type[]" id="slect_trip_${TD_id1}" class="form-control" data-placeholder="Choose ...">
                                                    <option value="All_Round" Selected>All Round</option>
                                                </select>
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Vehicle Type</label>
                                                <select name="transportation_vehicle_type[]" id="transportation_vehicle_typeI_${TD_id1}" class="form-control"  data-placeholder="Choose ...">
                                                    <option value="">Choose ...</option>
                                                    <option value="Bus">Bus</option>
                                                    <option value="Coach">Coach</option>
                                                    <option value="Vain">Vain</option>
                                                    <option value="Car">Car</option>
                                                </select>
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">No Of Vehicle</label>
                                                <input type="text" id="transportation_no_of_vehicle_${TD_id1}" name="transportation_no_of_vehicle[]" class="form-control" onchange="TNOV_function(${TD_id1})">
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Price Per Vehicle</label>
                                                <div class="input-group">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T_${TD_id1}"></a></span>
                                                    <input type="text" id="transportation_price_per_vehicle_${TD_id1}" name="transportation_price_per_vehicle[]" class="form-control" onchange="TPPV_function(${TD_id1})" readonly>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Total Vehicle Price</label>
                                                <div class="input-group">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T_${TD_id1}"></a></span>
                                                    <input type="text" id="transportation_vehicle_total_price_${TD_id1}" name="transportation_vehicle_total_price[]" class="form-control" readonly>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Price Per Person</label>
                                                <div class="input-group">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T_${TD_id1}"></a></span>
                                                    <input type="text" id="transportation_price_per_person_${TD_id1}" name="transportation_price_per_person[]" class="form-control" readonly>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Exchange Rate</label>
                                                <div class="input-group">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T_${TD_id1}"></a></span>
                                                    <input type="text" name="transfer_exchange_rate_destination[]" id="transfer_exchange_rate_destination_${TD_id1}" class="form-control" readonly>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Price Per Vehicle</label>
                                                <div class="input-group">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T_${TD_id1}"></a></span>
                                                    <input type="text" name="without_markup_price_converted_destination[]" id="without_markup_price_converted_destination_${TD_id1}" class="form-control" readonly>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Total Vehicle Price</label>
                                                <div class="input-group">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T_${TD_id1}"></a></span>
                                                    <input type="text" name="transportation_vehicle_total_price_converted[]" id="transportation_vehicle_total_price_converted_${TD_id1}" class="form-control" readonly>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Price Per Person</label>
                                                <div class="input-group">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T_${TD_id1}"></a></span>
                                                    <input type="text" name="transportation_price_per_person_converted[]" id="transportation_price_per_person_converted_${TD_id1}" class="form-control" readonly>
                                                </div>
                                            </div>
                                            
                                            <!--Costing--!>
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Vehicle Markup Type</label>
                                                <select name="vehicle_markup_type[]" id="vehicle_markup_type_${TD_id1}" class="form-control" onchange="vehicle_markup_AllR(${TD_id1})">
                                                    <option value="">Markup Type</option>
                                                    <option value="%">Percentage</option>
                                                    <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                </select>
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Markup Value per Vehicle</label>
                                                <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T_${TD_id1}"></a></span>
                                                    <input type="text" class="form-control" id="vehicle_per_markup_value_${TD_id1}" name="vehicle_per_markup_value[]" onkeyup="vehicle_per_markup_AllR(${TD_id1})">
                                                </div>
                                            </div>
                                            
                                            <input type="text" class="form-control d-none" id="markup_price_per_vehicle_converted_${TD_id1}" name="markup_price_per_vehicle_converted[]" readonly>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Vehicle Total Price</label>
                                                <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T_${TD_id1}"></a></span>
                                                    <input type="text" class="form-control" id="vehicle_total_price_with_markup_${TD_id1}" name="vehicle_total_price_with_markup[]" readonly>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Vehicle Markup Value</label>
                                                <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value1_T_${TD_id1}"></a></span>
                                                    <input type="text" class="form-control" id="vehicle_markup_value_${TD_id1}" name="vehicle_markup_value[]" onkeyup="vehicle_markup_AllR(${TD_id1})" readonly>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Vehicle Markup Value</label>
                                                <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T_${TD_id1}"></a></span>
                                                    <input type="text" class="form-control" id="vehicle_markup_value_converted_${TD_id1}" name="vehicle_markup_value_converted[]" readonly>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-3" style="padding: 10px;">
                                                <label for="">Vehicle Markup Price</label>
                                                <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                    <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1_T_${TD_id1}"></a></span>
                                                    <input type="text" class="form-control" id="vehicle_total_price_with_markup_converted_${TD_id1}" name="vehicle_total_price_with_markup_converted[]" readonly>
                                                </div>
                                            </div>
                                            <!--End Costing--!>
                                            
                                            <input type="hidden" class="transfer_markup_type_invoice" name="transfer_markup_type_invoice[]">
                                            <input type="hidden" class="transfer_markup_invoice" name="transfer_markup_invoice[]">
                                            <input type="hidden" class="transfer_markup_price_invoice" name="transfer_markup_price_invoice[]">
                                            
                                            <div id="append_transportation_${TD_id1}"></div>
                                        </div>
                                        <div class="col-xl-6 R_AllRound_class_${TD_id1}" style="padding: 10px;"></div>
                                        <div class="col-xl-6 R_AllRound_class_${TD_id1}" style="padding: 10px;">
                                            <a type="button" class="btn btn-primary" id="R_AllRound_Id_${TD_id1}" onclick="R_AllRound_function(${TD_id1},${id})" style="float: right;">Remove</a>
                                        </div>`;
                        
                        $('#transportation_main_divI').append(allR_data);
                        
                        var destination_id = value.id;
                        $('#destination_id_'+TD_id1+'').val(destination_id);
                        
                        var all_round_Type = $('#all_round_Type_'+TD_id1+'').val();
                        
                        addGoogleApi('transportation_pick_up_location_'+TD_id1+'');
                        addGoogleApi('transportation_drop_off_location_'+TD_id1+'');
                        
                        var vehicle_detailsE = value.vehicle_details;
                        if(vehicle_detailsE != null && vehicle_detailsE != ''){
                            var vehicle_details = JSON.parse(vehicle_detailsE);
                            $.each(vehicle_details, function(key, value1) {
                                var transfer_supplier_Id    = value1.transfer_supplier_Id;
                                var total_fare_markup       = value1.total_fare_markup;
                                var vehicle_Name            = value1.vehicle_Name;
                                var vehicle_Fare            = value1.vehicle_Fare;
                                var vehicle_total_Fare      = value1.vehicle_total_Fare;
                                var exchange_Rate           = value1.exchange_Rate;
                                var vehicle_id              = value1.vehicle_id;
                                
                                if(transfer_supplier_id == transfer_supplier_Id){
                                    if(transfer_vehicle_id_td == vehicle_id){
                                        $('#transportation_vehicle_typeI_'+TD_id1+'').empty();
                                        var transportation_vehicle_type_Data = `<option value="${vehicle_Name}" Selected>${vehicle_Name}</option>`;
                                        $('#transportation_vehicle_typeI_'+TD_id1+'').append(transportation_vehicle_type_Data);
                                        
                                        $('#transportation_price_per_vehicle_'+TD_id1+'').val(vehicle_Fare);
                                        $('#without_markup_price_converted_destination_'+TD_id1+'').val(vehicle_total_Fare);
                                        $('#transfer_exchange_rate_destination_'+TD_id1+'').val(exchange_Rate);
                                        
                                        $('#vehicle_exchange_Rate_ID_'+TD_id1+'').val(exchange_Rate);
                                        
                                        // $('#transportation_price_per_vehicle_'+TD_id1+'').val(total_fare_markup);
                                        // $('#transportation_price_per_person_select').val(total_fare_markup);
                                    }
                                }
                                
                            });
                        }
                        
                        var more_destination_details_E  = value.more_destination_details;
                        if(more_destination_details_E != null && more_destination_details_E != ''){
                            var more_destination_details_D  = JSON.parse(more_destination_details_E);
                            $.each(more_destination_details_D, function(key, value2) {
                                var subLocationPic   = value2.subLocationPic;
                                var subLocationdrop  = value2.subLocationdrop;
                                
                                var data = `<div class="row" id="click_delete_${MTD_id1}">
                                                
                                                <input type="hidden" name="more_all_round_Type[]" id="more_all_round_Type_${MTD_id1}">
                                                
                                                <div class="col-xl-3" style="padding: 10px;">
                                                    <label for="">Pick-up Location</label>
                                                    <input type="text" value="${subLocationPic}" id="more_transportation_pick_up_location_${MTD_id1}" name="more_transportation_pick_up_location[]" class="form-control">
                                                </div>
                                                
                                                <div class="col-xl-3" style="padding: 10px;">
                                                    <label for="">Drop-off Location</label>
                                                    <input type="text" value="${subLocationdrop}" id="more_transportation_drop_off_location_${MTD_id1}" name="more_transportation_drop_off_location[]" class="form-control">
                                                </div>
                                                
                                                <div class="col-xl-3" style="padding: 10px;">
                                                    <label for="">Pick-up Date & Time</label>
                                                    <input type="datetime-local" id="more_transportation_pick_up_date_${MTD_id1}" name="more_transportation_pick_up_date[]" class="form-control" onchange="MTPD_function(${MTD_id1})">
                                                </div>
                                                
                                                <div class="col-xl-3" style="padding: 10px;">
                                                    <label for="">Drop-of Date & Time</label>
                                                    <input type="datetime-local" id="more_transportation_drop_of_date_${MTD_id1}" name="more_transportation_drop_of_date[]" class="form-control" onchange="MTDD_function(${MTD_id1})">
                                                </div>
                                                
                                                <div class="col-xl-3" style="display:none" id="more_transportation_Time_Div_${MTD_id1}">
                                                    <label for="">Estimate Time</label>
                                                    <input type="text" id="more_transportation_total_Time_${MTD_id1}" name="more_transportation_total_Time[]" class="form-control" readonly style="padding: 10px;">
                                                </div>
                                            
                                                <div class="mt-2 d-none">
                                                    <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRowTransI(${MTD_id1})" id="${MTD_id1}">Delete</button>
                                                </div>
                                            </div>`;
                                $('#append_transportation_'+TD_id1+'').append(data);
                                
                                $('#more_all_round_Type_'+MTD_id1+'').val(all_round_Type);
                                
                                addGoogleApi('more_transportation_pick_up_location_'+MTD_id1+'');
                                addGoogleApi('more_transportation_drop_off_location_'+MTD_id1+'');
                                
                                MTD_id1++;
                            });
                        }
                        
                        var currency_conversion = value.currency_conversion;        
                        var value_c         = value.currency_conversion;
                        const usingSplit    = value_c.split(' ');
                        var value_1         = usingSplit['0'];
                        var value_2         = usingSplit['2'];
                        $('.currency_value1_T_'+TD_id1+'').html(value_1);
                        $('.currency_value_exchange_1_T_'+TD_id1+'').html(value_2);
                        
                        $('#currency_SAR_'+TD_id1+'').val(value_1);
                        $('#currency_GBP_'+TD_id1+'').val(value_2);
                        
                        exchange_currency_funs(value_1,value_2);
                        
                        TD_id1++;
                        
                        $('#transportation_price_switch').val(TD_id1);
                        
                        $('#ocupancy_btn_switch_'+id+'').val(1);
                        
                    }else{
                        alert('Already Occupied')
                    }
                }
            }
        });
    }
    
    function R_AllRound_function(TD_id1,id){
        $('#allRound_Div_'+TD_id1+'').remove();
        $('.R_AllRound_class_'+TD_id1+'').remove();
        $('#ocupancy_btn_switch_'+id+'').val(0);
        $('#occupy_btn_'+id+'').css('background-color','rebeccapurple');
        
        $('#transportation_markup').val('');
        $('#transportation_markup_total').val('');
        
        var transportation_price_switch = $('#transportation_price_switch').val();
        var Tran_no_of_Vehicle          = 0;
        var Tran_price_per_vehicle      = 0;
        var Tran_price_all_vehicle      = 0;
        var Tran_Orignal_price          = 0;
        var Tran_price_all_vehicleC     = 0;
        var transportation_markup       = 0;
        var transportation_markup_total = 0;
        for(x=1; x<transportation_price_switch; x++){
            var transportation_price_per_person     = $('#transportation_price_per_person_'+x+'').val();
            var transportation_no_of_vehicle        = $('#transportation_no_of_vehicle_'+x+'').val();
            var transportation_price_per_vehicle    = $('#transportation_price_per_vehicle_'+x+'').val();
            var transportation_vehicle_total_price  = $('#transportation_vehicle_total_price_'+x+'').val();
            var transportation_vehicle_total_price_converted = $('#transportation_vehicle_total_price_converted_'+x+'').val();
            var vehicle_markup_value_converted                  = $('#vehicle_markup_value_converted_'+x+'').val();
            var vehicle_total_price_with_markup_converted       = $('#vehicle_total_price_with_markup_converted_'+x+'').val();
            
            if(transportation_price_per_person != null && transportation_price_per_person != ''){
                Tran_Orignal_price = parseFloat(Tran_Orignal_price) + parseFloat(transportation_price_per_person);
                Tran_Orignal_price = Tran_Orignal_price.toFixed(2);
                $('#transportation_price_per_person_select').val(Tran_Orignal_price);
            }
            
            if(transportation_no_of_vehicle != null && transportation_no_of_vehicle != ''){
                Tran_no_of_Vehicle = parseFloat(Tran_no_of_Vehicle) + parseFloat(transportation_no_of_vehicle);
                Tran_no_of_Vehicle = Tran_no_of_Vehicle.toFixed(2);
                $('#tranf_no_of_vehicle').val(Tran_no_of_Vehicle);
            }
            
            if(transportation_price_per_vehicle != null && transportation_price_per_vehicle != ''){
                Tran_price_per_vehicle = parseFloat(Tran_price_per_vehicle) + parseFloat(transportation_price_per_vehicle);
                Tran_price_per_vehicle = Tran_price_per_vehicle.toFixed(2);
                $('#tranf_price_per_vehicle').val(Tran_price_per_vehicle);
            }
            
            if(transportation_vehicle_total_price != null && transportation_vehicle_total_price != ''){
                Tran_price_all_vehicle = parseFloat(Tran_price_all_vehicle) + parseFloat(transportation_vehicle_total_price);
                Tran_price_all_vehicle = Tran_price_all_vehicle.toFixed(2);
                $('#tranf_price_all_vehicle').val(Tran_price_all_vehicle);
                $('#transportation_price_per_person_select').val(Tran_price_all_vehicle);
            }
            
            if(transportation_vehicle_total_price_converted != null && transportation_vehicle_total_price_converted != ''){
                Tran_price_all_vehicleC = parseFloat(Tran_price_all_vehicleC) + parseFloat(transportation_vehicle_total_price_converted);
                Tran_price_all_vehicleC = Tran_price_all_vehicleC.toFixed(2);
                $('#tranf_price_all_vehicle').val(Tran_price_all_vehicleC);
                $('#transportation_price_per_person_select').val(Tran_price_all_vehicleC);
            }
            
            if(vehicle_markup_value_converted != null && vehicle_markup_value_converted != ''){
                transportation_markup = parseFloat(transportation_markup) + parseFloat(vehicle_markup_value_converted);
                transportation_markup = transportation_markup.toFixed(2);
                $('#transportation_markup').val(transportation_markup);
            }
            
            if(vehicle_total_price_with_markup_converted != null && vehicle_total_price_with_markup_converted != ''){
                transportation_markup_total = parseFloat(transportation_markup_total) + parseFloat(vehicle_total_price_with_markup_converted);
                transportation_markup_total = transportation_markup_total.toFixed(2);
                $('#transportation_markup_total').val(transportation_markup_total);
            }
            
        }
        add_numberElseI();
    }
    
    function TPUD_function(id){
        var h = "hours";
        var m = "minutes";
        var transportation_drop_of_date = $('#transportation_drop_of_date_'+id+'').val();
        var transportation_pick_up_date = $('#transportation_pick_up_date_'+id+'').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        var date1               = new Date(transportation_pick_up_date);
        var date2               = new Date(transportation_drop_of_date);
        var timediff            = date2 - date1;
        var minutes_Total       = Math.floor(timediff / minute);
        var total_hours         = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        var minutes             = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        $('#transportation_Time_Div_'+id+'').css('display','');
        $('#transportation_total_Time_'+id+'').val(total_hours+h+ ' : ' +minutes+m);
    }
    
    function TDOP_function(id){
        var h = "hours";
        var m = "minutes";
        var transportation_drop_of_date = $('#transportation_drop_of_date_'+id+'').val();
        var transportation_pick_up_date = $('#transportation_pick_up_date_'+id+'').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        var date1               = new Date(transportation_pick_up_date);
        var date2               = new Date(transportation_drop_of_date);
        var timediff            = date2 - date1;
        var minutes_Total       = Math.floor(timediff / minute);
        var total_hours         = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        var minutes             = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        $('#transportation_Time_Div_'+id+'').css('display','');
        $('#transportation_total_Time_'+id+'').val(total_hours+h+ ' : ' +minutes+m);
        
    }
    
    function TNOV_function(id){
        $('#transportation_markup').val('');
        $('#transportation_markup_total').val('');
        
        $('#vehicle_markup_value').val('');
        $('#vehicle_total_price_with_markup').val('');
        $('#vehicle_markup_value_converted').val('');
        $('#vehicle_total_price_with_markup_converted').val('');
        $('#vehicle_per_markup_value').val('');
        $('#markup_price_per_vehicle_converted').val('');
        
        $('#transportation_markup').val('');
        $('#transportation_markup_total').val('');
        var transportation_price_per_vehicle    =  $('#transportation_price_per_vehicle_'+id+'').val();
        var transportation_no_of_vehicle        =  $('#transportation_no_of_vehicle_'+id+'').val();
        var no_of_pax_days                      =  $('#no_of_pax_days').val();
        var t_trans1                            =  transportation_price_per_vehicle * transportation_no_of_vehicle;
        var t_trans                             =  t_trans1.toFixed(2);
        $('#transportation_vehicle_total_price_'+id+'').val(t_trans);
        var total_trans1                        = t_trans/no_of_pax_days;
        var total_trans                         = total_trans1.toFixed(2);
        $('#transportation_price_per_person_'+id+'').val(total_trans);
        $('#transportation_price_per_person_select_'+id+'').val(t_trans);
        
        var select_exchange_type    = $('#vehicle_select_exchange_type_ID_'+id+'').val();
        var exchange_Rate           = $('#vehicle_exchange_Rate_ID_'+id+'').val();
        
        if(select_exchange_type == 'Divided'){
            var without_markup_price_converted_destination    = parseFloat(transportation_price_per_vehicle)/parseFloat(exchange_Rate);
            var transportation_vehicle_total_price_converted  = parseFloat(t_trans)/parseFloat(exchange_Rate);
            var transportation_price_per_person_converted     = parseFloat(total_trans)/parseFloat(exchange_Rate);
        }else{
            var without_markup_price_converted_destination    = parseFloat(transportation_price_per_vehicle) * parseFloat(exchange_Rate);
            var transportation_vehicle_total_price_converted  = parseFloat(t_trans) * parseFloat(exchange_Rate);
            var transportation_price_per_person_converted     = parseFloat(total_trans) * parseFloat(exchange_Rate);
        }
        
        without_markup_price_converted_destination   = without_markup_price_converted_destination.toFixed(2);
        transportation_vehicle_total_price_converted = transportation_vehicle_total_price_converted.toFixed(2);
        transportation_price_per_person_converted    = transportation_price_per_person_converted.toFixed(2);
        
        $('#without_markup_price_converted_destination_'+id+'').val(without_markup_price_converted_destination);
        $('#transportation_vehicle_total_price_converted_'+id+'').val(transportation_vehicle_total_price_converted);
        $('#transportation_price_per_person_converted_'+id+'').val(transportation_price_per_person_converted);
        
        var transportation_price_switch = $('#transportation_price_switch').val();
        var Tran_no_of_Vehicle = 0;
        var Tran_price_per_vehicle = 0;
        var Tran_price_all_vehicle = 0;
        var Tran_Orignal_price = 0;
        var Tran_price_all_vehicleC = 0;
        for(x=1; x<transportation_price_switch; x++){
            var transportation_price_per_person     = $('#transportation_price_per_person_'+x+'').val();
            var transportation_no_of_vehicle        = $('#transportation_no_of_vehicle_'+x+'').val();
            var transportation_price_per_vehicle    = $('#transportation_price_per_vehicle_'+x+'').val();
            var transportation_vehicle_total_price  = $('#transportation_vehicle_total_price_'+x+'').val();
            var transportation_vehicle_total_price_converted  = $('#transportation_vehicle_total_price_converted_'+x+'').val();
            
            if(transportation_price_per_person != null && transportation_price_per_person != ''){
                Tran_Orignal_price = parseFloat(Tran_Orignal_price) + parseFloat(transportation_price_per_person);
                Tran_Orignal_price = Tran_Orignal_price.toFixed(2);
                $('#transportation_price_per_person_select').val(Tran_Orignal_price);
            }
            
            if(transportation_no_of_vehicle != null && transportation_no_of_vehicle != ''){
                Tran_no_of_Vehicle = parseFloat(Tran_no_of_Vehicle) + parseFloat(transportation_no_of_vehicle);
                Tran_no_of_Vehicle = Tran_no_of_Vehicle.toFixed(2);
                $('#tranf_no_of_vehicle').val(Tran_no_of_Vehicle);
            }
            
            if(transportation_price_per_vehicle != null && transportation_price_per_vehicle != ''){
                Tran_price_per_vehicle = parseFloat(Tran_price_per_vehicle) + parseFloat(transportation_price_per_vehicle);
                Tran_price_per_vehicle = Tran_price_per_vehicle.toFixed(2);
                $('#tranf_price_per_vehicle').val(Tran_price_per_vehicle);
            }
            
            if(transportation_vehicle_total_price != null && transportation_vehicle_total_price != ''){
                Tran_price_all_vehicle = parseFloat(Tran_price_all_vehicle) + parseFloat(transportation_vehicle_total_price);
                Tran_price_all_vehicle = Tran_price_all_vehicle.toFixed(2);
                $('#tranf_price_all_vehicle').val(Tran_price_all_vehicle);
                // $('#transportation_price_per_person_select').val(Tran_price_all_vehicle);
            }
            
            if(transportation_vehicle_total_price_converted != null && transportation_vehicle_total_price_converted != ''){
                Tran_price_all_vehicleC = parseFloat(Tran_price_all_vehicleC) + parseFloat(transportation_vehicle_total_price_converted);
                Tran_price_all_vehicleC = Tran_price_all_vehicleC.toFixed(2);
                $('#tranf_price_all_vehicle').val(Tran_price_all_vehicleC);
                $('#transportation_price_per_person_select').val(Tran_price_all_vehicleC);
            }
        }
        add_numberElseI();
    }
    
    function TPPV_function(id){
        // var Tran_Orignal_price = $('#transportation_price_per_person_select').val();
        
        $('#transportation_markup').val('');
        $('#transportation_markup_total').val('');
        
        $('#vehicle_markup_value').val('');
        $('#vehicle_total_price_with_markup').val('');
        $('#vehicle_markup_value_converted').val('');
        $('#vehicle_total_price_with_markup_converted').val('');
        $('#vehicle_per_markup_value').val('');
        $('#markup_price_per_vehicle_converted').val('');
        
        // var transportation_price_per_vehicle    =  $('#transportation_price_per_vehicle_'+id+'').val();
        var transportation_price_per_vehicle    =  $('#transportation_price_per_vehicle_'+id+'').val();
        var transportation_no_of_vehicle        =  $('#transportation_no_of_vehicle_'+id+'').val();
        var no_of_pax_days                      =  $('#no_of_pax_days').val();
        var t_trans1                            =  transportation_price_per_vehicle * transportation_no_of_vehicle;
        var t_trans                             =  t_trans1.toFixed(2);
        $('#transportation_vehicle_total_price_'+id+'').val(t_trans);
        var total_trans1                        = t_trans/no_of_pax_days;
        var total_trans                         = total_trans1.toFixed(2);
        $('#transportation_price_per_person_'+id+'').val(total_trans);
        $('#transportation_price_per_person_select_'+id+'').val(t_trans);
        
        var select_exchange_type    = $('#vehicle_select_exchange_type_ID_'+id+'').val();
        var exchange_Rate           = $('#vehicle_exchange_Rate_ID_'+id+'').val();
        if(select_exchange_type == 'Divided'){
            var without_markup_price_converted_destination    = parseFloat(transportation_price_per_vehicle)/parseFloat(exchange_Rate);
            var transportation_vehicle_total_price_converted  = parseFloat(t_trans)/parseFloat(exchange_Rate);
            var transportation_price_per_person_converted     = parseFloat(total_trans)/parseFloat(exchange_Rate);
        }else{
            var without_markup_price_converted_destination    = parseFloat(transportation_price_per_vehicle) * parseFloat(exchange_Rate);
            var transportation_vehicle_total_price_converted  = parseFloat(t_trans) * parseFloat(exchange_Rate);
            var transportation_price_per_person_converted     = parseFloat(total_trans) * parseFloat(exchange_Rate);
        }
        
        without_markup_price_converted_destination   = without_markup_price_converted_destination.toFixed(2);
        transportation_vehicle_total_price_converted = transportation_vehicle_total_price_converted.toFixed(2);
        transportation_price_per_person_converted    = transportation_price_per_person_converted.toFixed(2);
        
        $('#without_markup_price_converted_destination_'+id+'').val(without_markup_price_converted_destination);
        $('#transportation_vehicle_total_price_converted_'+id+'').val(transportation_vehicle_total_price_converted);
        $('#transportation_price_per_person_converted_'+id+'').val(transportation_price_per_person_converted);
        
        var transportation_price_switch = $('#transportation_price_switch').val();
        var Tran_no_of_Vehicle = 0;
        var Tran_price_per_vehicle = 0;
        var Tran_price_all_vehicle = 0;
        var Tran_Orignal_price = 0;
        var Tran_price_all_vehicleC = 0;
        for(x=1; x<transportation_price_switch; x++){
            var transportation_price_per_person     = $('#transportation_price_per_person_'+x+'').val();
            var transportation_no_of_vehicle        = $('#transportation_no_of_vehicle_'+x+'').val();
            var transportation_price_per_vehicle    = $('#transportation_price_per_vehicle_'+x+'').val();
            var transportation_vehicle_total_price  = $('#transportation_vehicle_total_price_'+x+'').val();
            var transportation_vehicle_total_price_converted  = $('#transportation_vehicle_total_price_converted_'+x+'').val();
            
            if(transportation_price_per_person != null && transportation_price_per_person != ''){
                Tran_Orignal_price = parseFloat(Tran_Orignal_price) + parseFloat(transportation_price_per_person);
                Tran_Orignal_price = Tran_Orignal_price.toFixed(2);
                $('#transportation_price_per_person_select').val(Tran_Orignal_price);
            }
            
            if(transportation_no_of_vehicle != null && transportation_no_of_vehicle != ''){
                Tran_no_of_Vehicle = parseFloat(Tran_no_of_Vehicle) + parseFloat(transportation_no_of_vehicle);
                Tran_no_of_Vehicle = Tran_no_of_Vehicle.toFixed(2);
                $('#tranf_no_of_vehicle').val(Tran_no_of_Vehicle);
            }
            
            if(transportation_price_per_vehicle != null && transportation_price_per_vehicle != ''){
                Tran_price_per_vehicle = parseFloat(Tran_price_per_vehicle) + parseFloat(transportation_price_per_vehicle);
                Tran_price_per_vehicle = Tran_price_per_vehicle.toFixed(2);
                $('#tranf_price_per_vehicle').val(Tran_price_per_vehicle);
            }
            
            if(transportation_vehicle_total_price != null && transportation_vehicle_total_price != ''){
                Tran_price_all_vehicle = parseFloat(Tran_price_all_vehicle) + parseFloat(transportation_vehicle_total_price);
                Tran_price_all_vehicle = Tran_price_all_vehicle.toFixed(2);
                $('#tranf_price_all_vehicle').val(Tran_price_all_vehicle);
                // $('#transportation_price_per_person_select').val(Tran_price_all_vehicle);
            }
            
            if(transportation_vehicle_total_price_converted != null && transportation_vehicle_total_price_converted != ''){
                Tran_price_all_vehicleC = parseFloat(Tran_price_all_vehicleC) + parseFloat(transportation_vehicle_total_price_converted);
                Tran_price_all_vehicleC = Tran_price_all_vehicleC.toFixed(2);
                $('#tranf_price_all_vehicle').val(Tran_price_all_vehicleC);
                $('#transportation_price_per_person_select').val(Tran_price_all_vehicleC);
            }
            
        }
        add_numberElseI();
    }
    
    function MTPD_function(id){
        var h = "hours";
        var m = "minutes";
        var transportation_drop_of_date = $('#more_transportation_drop_of_date_'+id+'').val();
        var transportation_pick_up_date = $('#more_transportation_pick_up_date_'+id+'').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        var date1               = new Date(transportation_pick_up_date);
        var date2               = new Date(transportation_drop_of_date);
        var timediff            = date2 - date1;
        var minutes_Total       = Math.floor(timediff / minute);
        var total_hours         = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        
        var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        $('#more_transportation_Time_Div_'+id+'').css('display','');
        $('#more_transportation_total_Time_'+id+'').val(total_hours+h+ ' : ' +minutes+m);
    }
    
    function MTDD_function(id){
        var h = "hours";
        var m = "minutes";
        var transportation_drop_of_date = $('#more_transportation_drop_of_date_'+id+'').val();
        var transportation_pick_up_date = $('#more_transportation_pick_up_date_'+id+'').val();
        
        var second=1000, minute=second*60, hour=minute*60, day=hour*24, week=day*7;
        var date1               = new Date(transportation_pick_up_date);
        var date2               = new Date(transportation_drop_of_date);
        var timediff            = date2 - date1;
        var minutes_Total       = Math.floor(timediff / minute);
        var total_hours         = Math.floor(timediff / hour)
        var total_hours_minutes = parseFloat(total_hours) * 60;
        
        var minutes = parseFloat(minutes_Total) - parseFloat(total_hours_minutes);
        
        $('#more_transportation_Time_Div_'+id+'').css('display','');
        $('#more_transportation_total_Time_'+id+'').val(total_hours+h+ ' : ' +minutes+m);
    }
    
    function vehicle_per_markup_OWandR(){
        var vehicle_per_markup_value        = $('#vehicle_per_markup_value').val();
        var transportation_no_of_vehicle    = $('#transportation_no_of_vehicle').val();
        var total_price_all_vehicle_vehicle = parseFloat(transportation_no_of_vehicle) * parseFloat(vehicle_per_markup_value);
        total_price_all_vehicle_vehicle     = total_price_all_vehicle_vehicle.toFixed(2);
        $('#vehicle_markup_value').val(total_price_all_vehicle_vehicle);
        var without_markup_price_converted_destination      = $('#without_markup_price_converted_destination').val();
        
        var vehicle_markup_type                             = $('#vehicle_markup_type').val();
        var vehicle_markup_value                            = $('#vehicle_markup_value').val();
        var transportation_vehicle_total_price              = $('#transportation_vehicle_total_price').val();
        var transportation_vehicle_total_price_converted    = $('#transportation_vehicle_total_price_converted').val();
        var vehicle_exchange_Rate_ID                        = $('#vehicle_exchange_Rate_ID').val();;
        var vehicle_select_exchange_type_ID                 = $('#vehicle_select_exchange_type_ID').val();;
        
        if(vehicle_select_exchange_type_ID == 'Divided'){
            var vehicle_markup_value_converted      = parseFloat(vehicle_markup_value)/parseFloat(vehicle_exchange_Rate_ID);
            var price_per_vehicle_with_converted    = parseFloat(vehicle_per_markup_value)/parseFloat(vehicle_exchange_Rate_ID);
        }
        else{
            var vehicle_markup_value_converted      = parseFloat(vehicle_markup_value) * parseFloat(vehicle_exchange_Rate_ID);
            var price_per_vehicle_with_converted    = parseFloat(vehicle_per_markup_value) * parseFloat(vehicle_exchange_Rate_ID);
        }
        
        vehicle_markup_value_converted = vehicle_markup_value_converted.toFixed(2);
        $('#vehicle_markup_value_converted').val(vehicle_markup_value_converted);
        $('#transportation_markup').val(vehicle_markup_value_converted);
        
        if(vehicle_markup_type == ''){
            alert('Select Markup Type');
        }
        else if(vehicle_markup_type == '%'){
            var total1 = (transportation_vehicle_total_price * vehicle_markup_value/100) + parseFloat(transportation_vehicle_total_price);
            var total  = total1.toFixed(2);
            $('#vehicle_total_price_with_markup').val(total);
            add_numberElse_1I();
            
            var total1_C = (transportation_vehicle_total_price_converted * vehicle_markup_value_converted/100) + parseFloat(transportation_vehicle_total_price_converted);
            var total_C  = total1_C.toFixed(2);
            $('#vehicle_total_price_with_markup_converted').val(total_C);
            $('#transportation_markup_total').val(total_C);
            
            add_numberElse_1I();
            
            $('#transportation_markup_type').empty();
            var transportation_markup_type = `<option value="%" selected>Percentage</option>`;
            $('#transportation_markup_type').append(transportation_markup_type);
            
            var S_total1_C = (without_markup_price_converted_destination * price_per_vehicle_with_converted/100) + parseFloat(without_markup_price_converted_destination);
            var S_total_C  = S_total1_C.toFixed(2);
            $('#markup_price_per_vehicle_converted').val(S_total_C);
        }
        else{
            var total1 = parseFloat(transportation_vehicle_total_price) + parseFloat(vehicle_markup_value);
            var total  = total1.toFixed(2);
            $('#vehicle_total_price_with_markup').val(total);
            add_numberElse_1I();
            
            var total1_C = parseFloat(transportation_vehicle_total_price_converted) + parseFloat(vehicle_markup_value_converted);
            var total_C  = total1_C.toFixed(2);
            $('#vehicle_total_price_with_markup_converted').val(total_C);
            $('#transportation_markup_total').val(total_C);
            
            add_numberElse_1I();
            
            $('#transportation_markup_type').empty();
            var transportation_markup_type = `<option value="<?php echo $currency; ?>" selected>Fixed Amount</option>`;
            $('#transportation_markup_type').append(transportation_markup_type);
            
            var S_total1_C = parseFloat(without_markup_price_converted_destination) + parseFloat(price_per_vehicle_with_converted);
            var S_total_C  = S_total1_C.toFixed(2);
            $('#markup_price_per_vehicle_converted').val(S_total_C);
        }
    }
    
    function vehicle_per_markup_AllR(id){
        var vehicle_per_markup_value        = $('#vehicle_per_markup_value_'+id+'').val();
        var transportation_no_of_vehicle    = $('#transportation_no_of_vehicle_'+id+'').val();
        var total_price_all_vehicle_vehicle = parseFloat(transportation_no_of_vehicle) * parseFloat(vehicle_per_markup_value);
        total_price_all_vehicle_vehicle     = total_price_all_vehicle_vehicle.toFixed(2);
        $('#vehicle_markup_value_'+id+'').val(total_price_all_vehicle_vehicle);
        var without_markup_price_converted_destination      = $('#without_markup_price_converted_destination_'+id+'').val();
        
        $('#transportation_markup').val('');
        $('#transportation_markup_total').val('');
        
        $('#vehicle_markup_value').val('');
        $('#vehicle_total_price_with_markup').val('');
        $('#vehicle_markup_value_converted').val('');
        $('#vehicle_total_price_with_markup_converted').val('');
        
        var vehicle_markup_type                             = $('#vehicle_markup_type_'+id+'').val();
        var vehicle_markup_value                            = $('#vehicle_markup_value_'+id+'').val();
        var transportation_vehicle_total_price              = $('#transportation_vehicle_total_price_'+id+'').val();
        var transportation_vehicle_total_price_converted    = $('#transportation_vehicle_total_price_converted_'+id+'').val();
        var vehicle_exchange_Rate_ID                        = $('#vehicle_exchange_Rate_ID_'+id+'').val();
        var vehicle_select_exchange_type_ID                 = $('#vehicle_select_exchange_type_ID_'+id+'').val();
        
        if(vehicle_select_exchange_type_ID == 'Divided'){
            var vehicle_markup_value_converted      = parseFloat(vehicle_markup_value)/parseFloat(vehicle_exchange_Rate_ID);
            var price_per_vehicle_with_converted    = parseFloat(vehicle_per_markup_value)/parseFloat(vehicle_exchange_Rate_ID);
        }
        else{
            var vehicle_markup_value_converted      = parseFloat(vehicle_markup_value) * parseFloat(vehicle_exchange_Rate_ID);
            var price_per_vehicle_with_converted    = parseFloat(vehicle_per_markup_value) * parseFloat(vehicle_exchange_Rate_ID);
        }
        
        vehicle_markup_value_converted = vehicle_markup_value_converted.toFixed(2);
        $('#vehicle_markup_value_converted_'+id+'').val(vehicle_markup_value_converted);
        // $('#transportation_markup').val(vehicle_markup_value_converted);
        
        if(vehicle_markup_type == ''){
            alert('Select Markup Type');
        }
        else if(vehicle_markup_type == '%'){
            var total1 = (transportation_vehicle_total_price * vehicle_markup_value/100) + parseFloat(transportation_vehicle_total_price);
            var total  = total1.toFixed(2);
            $('#vehicle_total_price_with_markup_'+id+'').val(total);
            add_numberElse_1I();
            
            var total1_C = (transportation_vehicle_total_price_converted * vehicle_markup_value_converted/100) + parseFloat(transportation_vehicle_total_price_converted);
            var total_C  = total1_C.toFixed(2);
            $('#vehicle_total_price_with_markup_converted_'+id+'').val(total_C);
            // $('#transportation_markup_total').val(total_C);
            
            add_numberElse_1I();
            
            $('#transportation_markup_type').empty();
            var transportation_markup_type = `<option value="%" selected>Percentage</option>`;
            $('#transportation_markup_type').append(transportation_markup_type);
            
            var S_total1_C = (without_markup_price_converted_destination * price_per_vehicle_with_converted/100) + parseFloat(without_markup_price_converted_destination);
            var S_total_C  = S_total1_C.toFixed(2);
            $('#markup_price_per_vehicle_converted_'+id+'').val(S_total_C);
        }
        else{
            var total1 = parseFloat(transportation_vehicle_total_price) + parseFloat(vehicle_markup_value);
            var total  = total1.toFixed(2);
            $('#vehicle_total_price_with_markup_'+id+'').val(total);
            add_numberElse_1I();
            
            var total1_C = parseFloat(transportation_vehicle_total_price_converted) + parseFloat(vehicle_markup_value_converted);
            var total_C  = total1_C.toFixed(2);
            $('#vehicle_total_price_with_markup_converted_'+id+'').val(total_C);
            // $('#transportation_markup_total').val(total_C);
            add_numberElse_1I();
            
            $('#transportation_markup_type').empty();
            var transportation_markup_type = `<option value="<?php echo $currency; ?>" selected>Fixed Amount</option>`;
            $('#transportation_markup_type').append(transportation_markup_type);
            
            var S_total1_C = parseFloat(without_markup_price_converted_destination) + parseFloat(price_per_vehicle_with_converted);
            var S_total_C  = S_total1_C.toFixed(2);
            $('#markup_price_per_vehicle_converted_'+id+'').val(S_total_C);
        }
        
        var transportation_price_switch     = $('#transportation_price_switch').val();
        var transportation_markup           = 0;
        var transportation_markup_total     = 0;
        for(x=1; x<transportation_price_switch; x++){
            var vehicle_markup_value_converted              = $('#vehicle_markup_value_converted_'+x+'').val();
            var vehicle_total_price_with_markup_converted   = $('#vehicle_total_price_with_markup_converted_'+x+'').val();
            
            if(vehicle_markup_value_converted != null && vehicle_markup_value_converted != ''){
                transportation_markup = parseFloat(transportation_markup) + parseFloat(vehicle_markup_value_converted);
                transportation_markup = transportation_markup.toFixed(2);
                $('#transportation_markup').val(transportation_markup);
            }
            
            if(vehicle_total_price_with_markup_converted != null && vehicle_total_price_with_markup_converted != ''){
                transportation_markup_total = parseFloat(transportation_markup_total) + parseFloat(vehicle_total_price_with_markup_converted);
                transportation_markup_total = transportation_markup_total.toFixed(2);
                $('#transportation_markup_total').val(transportation_markup_total);
            }
            
        }
        add_numberElseI();
        
    }
    
    function vehicle_markup_OWandR(){
        var vehicle_markup_type                             = $('#vehicle_markup_type').val();
        var vehicle_markup_value                            = $('#vehicle_markup_value').val();
        var transportation_vehicle_total_price              = $('#transportation_vehicle_total_price').val();
        var transportation_vehicle_total_price_converted    = $('#transportation_vehicle_total_price_converted').val();
        var vehicle_exchange_Rate_ID                        = $('#vehicle_exchange_Rate_ID').val();;
        var vehicle_select_exchange_type_ID                 = $('#vehicle_select_exchange_type_ID').val();;
        
        if(vehicle_select_exchange_type_ID == 'Divided'){
            var vehicle_markup_value_converted = parseFloat(vehicle_markup_value)/parseFloat(vehicle_exchange_Rate_ID);
        }
        else{
            var vehicle_markup_value_converted = parseFloat(vehicle_markup_value) * parseFloat(vehicle_exchange_Rate_ID);
        }
        
        vehicle_markup_value_converted = vehicle_markup_value_converted.toFixed(2);
        $('#vehicle_markup_value_converted').val(vehicle_markup_value_converted);
        $('#transportation_markup').val(vehicle_markup_value_converted);
        
        if(vehicle_markup_type == ''){
            alert('Select Markup Type');
        }
        else if(vehicle_markup_type == '%'){
            var total1 = (transportation_vehicle_total_price * vehicle_markup_value/100) + parseFloat(transportation_vehicle_total_price);
            var total  = total1.toFixed(2);
            $('#vehicle_total_price_with_markup').val(total);
            add_numberElse_1I();
            
            var total1_C = (transportation_vehicle_total_price_converted * vehicle_markup_value_converted/100) + parseFloat(transportation_vehicle_total_price_converted);
            var total_C  = total1_C.toFixed(2);
            $('#vehicle_total_price_with_markup_converted').val(total_C);
            $('#transportation_markup_total').val(total_C);
            
            add_numberElse_1I();
            
            $('#transportation_markup_type').empty();
            var transportation_markup_type = `<option value="%" selected>Percentage</option>`;
            $('#transportation_markup_type').append(transportation_markup_type);
        }
        else{
            var total1 = parseFloat(transportation_vehicle_total_price) + parseFloat(vehicle_markup_value);
            var total  = total1.toFixed(2);
            $('#vehicle_total_price_with_markup').val(total);
            add_numberElse_1I();
            
            var total1_C = parseFloat(transportation_vehicle_total_price_converted) + parseFloat(vehicle_markup_value_converted);
            var total_C  = total1_C.toFixed(2);
            $('#vehicle_total_price_with_markup_converted').val(total_C);
            $('#transportation_markup_total').val(total_C);
            add_numberElse_1I();
            
            $('#transportation_markup_type').empty();
            var transportation_markup_type = `<option value="<?php echo $currency; ?>" selected>Fixed Amount</option>`;
            $('#transportation_markup_type').append(transportation_markup_type);
        }
    }
    
    function vehicle_markup_AllR(id){
        $('#transportation_markup').val('');
        $('#transportation_markup_total').val('');
        
        $('#vehicle_markup_value').val('');
        $('#vehicle_total_price_with_markup').val('');
        $('#vehicle_markup_value_converted').val('');
        $('#vehicle_total_price_with_markup_converted').val('');
        
        var vehicle_markup_type                             = $('#vehicle_markup_type_'+id+'').val();
        var vehicle_markup_value                            = $('#vehicle_markup_value_'+id+'').val();
        var transportation_vehicle_total_price              = $('#transportation_vehicle_total_price_'+id+'').val();
        var transportation_vehicle_total_price_converted    = $('#transportation_vehicle_total_price_converted_'+id+'').val();
        var vehicle_exchange_Rate_ID                        = $('#vehicle_exchange_Rate_ID_'+id+'').val();
        var vehicle_select_exchange_type_ID                 = $('#vehicle_select_exchange_type_ID_'+id+'').val();
        
        if(vehicle_select_exchange_type_ID == 'Divided'){
            var vehicle_markup_value_converted = parseFloat(vehicle_markup_value)/parseFloat(vehicle_exchange_Rate_ID);
        }
        else{
            var vehicle_markup_value_converted = parseFloat(vehicle_markup_value) * parseFloat(vehicle_exchange_Rate_ID);
        }
        
        vehicle_markup_value_converted = vehicle_markup_value_converted.toFixed(2);
        $('#vehicle_markup_value_converted_'+id+'').val(vehicle_markup_value_converted);
        // $('#transportation_markup').val(vehicle_markup_value_converted);
        
        if(vehicle_markup_type == ''){
            alert('Select Markup Type');
        }
        else if(vehicle_markup_type == '%'){
            var total1 = (transportation_vehicle_total_price * vehicle_markup_value/100) + parseFloat(transportation_vehicle_total_price);
            var total  = total1.toFixed(2);
            $('#vehicle_total_price_with_markup_'+id+'').val(total);
            add_numberElse_1I();
            
            var total1_C = (transportation_vehicle_total_price_converted * vehicle_markup_value_converted/100) + parseFloat(transportation_vehicle_total_price_converted);
            var total_C  = total1_C.toFixed(2);
            $('#vehicle_total_price_with_markup_converted_'+id+'').val(total_C);
            // $('#transportation_markup_total').val(total_C);
            
            add_numberElse_1I();
            
            $('#transportation_markup_type').empty();
            var transportation_markup_type = `<option value="%" selected>Percentage</option>`;
            $('#transportation_markup_type').append(transportation_markup_type);
        }
        else{
            var total1 = parseFloat(transportation_vehicle_total_price) + parseFloat(vehicle_markup_value);
            var total  = total1.toFixed(2);
            $('#vehicle_total_price_with_markup_'+id+'').val(total);
            add_numberElse_1I();
            
            var total1_C = parseFloat(transportation_vehicle_total_price_converted) + parseFloat(vehicle_markup_value_converted);
            var total_C  = total1_C.toFixed(2);
            $('#vehicle_total_price_with_markup_converted_'+id+'').val(total_C);
            // $('#transportation_markup_total').val(total_C);
            add_numberElse_1I();
            
            $('#transportation_markup_type').empty();
            var transportation_markup_type = `<option value="<?php echo $currency; ?>" selected>Fixed Amount</option>`;
            $('#transportation_markup_type').append(transportation_markup_type);
        }
        
        var transportation_price_switch     = $('#transportation_price_switch').val();
        var transportation_markup           = 0;
        var transportation_markup_total     = 0;
        for(x=1; x<transportation_price_switch; x++){
            var vehicle_markup_value_converted              = $('#vehicle_markup_value_converted_'+x+'').val();
            var vehicle_total_price_with_markup_converted   = $('#vehicle_total_price_with_markup_converted_'+x+'').val();
            
            if(vehicle_markup_value_converted != null && vehicle_markup_value_converted != ''){
                transportation_markup = parseFloat(transportation_markup) + parseFloat(vehicle_markup_value_converted);
                transportation_markup = transportation_markup.toFixed(2);
                $('#transportation_markup').val(transportation_markup);
            }
            
            if(vehicle_total_price_with_markup_converted != null && vehicle_total_price_with_markup_converted != ''){
                transportation_markup_total = parseFloat(transportation_markup_total) + parseFloat(vehicle_total_price_with_markup_converted);
                transportation_markup_total = transportation_markup_total.toFixed(2);
                $('#transportation_markup_total').val(transportation_markup_total);
            }
            
        }
        add_numberElseI();
        
    }
    // End Transportation
    
</script>

@stop