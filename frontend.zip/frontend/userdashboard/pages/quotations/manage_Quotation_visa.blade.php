@extends('template/frontend/userdashboard/layout/default')
@section('content')

<?php $currency=Session::get('currency_symbol'); $account_No=Session::get('account_No'); //dd($account_No); ?>
 
<div class="card">
    <div class="card-body">
        <h4 class="header-title">Create Visa Quotation</h4>
        @if($errors->any())
        <h4>{{$errors->first()}}</h4>
        @endif
        <!--<div class="tab-content">-->
            <form action="{{URL::to('add_Invoices')}}" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
                @csrf
                <!--<div class="tab-pane show active" id="justified-tabs-preview">-->
                <div id="progressbarwizard">
                    <!--<ul class="nav nav-pills bg-nav-pills nav-justified mb-3">-->
                    <ul class="nav nav-pills nav-justified form-wizard-header mb-3" style="margin-right: 1px;margin-left: 1px;">
                        
                        <li class="nav-item">
                            <a href="#home1" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                              <i class="mdi mdi-home-variant d-md-none d-block"></i>
                                <span class="d-none d-md-block">Invoice Details</span>
                            </a>
                        </li>
                        
                        <li class="nav-item visa_tab">
                            <!--<a href="#visa_details" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">-->
                            <a href="#visa_details" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                              <i class="mdi mdi-passport d-md-none d-block"></i>
                                <span class="d-none d-md-block">Visa Details</span>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <!--<a href="#Extras_details" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">-->
                            <a href="#Extras_details" data-bs-toggle="tab" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                              <i class="uil-moneybag d-md-none d-block"></i>
                                <span class="d-none d-md-block">Costing</span>
                            </a>
                        </li>
                    </ul>
                    
                    <div class="tab-content">

                        <div class="tab-pane  show active" id="home1">
                            <div class="row">
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label simpleinput">Services</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Enter the package name">
                                            </i>
                                        </div>
                                        <!--<input type="text" id="simpleinput" name="title" class="form-control titleP" >-->
                                       <select class="form-control  external_packages" data-toggle="select2" multiple="multiple" id="select_services" name="services[]">
                                            <option value="visa_tab">Visa Details</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <input type="checkbox" class="custom-control-input" id="selectAgent" name="customer_select" value="booking_by_customer">
                                    <label  class="custom-control-label" for="selectAgent">Book for Agent</span></label>
                                    
                                    <div class="mb-3" id="agent_div" style="display:none;padding-top: 10px;">
                                        <select class="form-control" id="agent_Company_Name" name="agent_Company_Name">
                                           <option value="">Choose...</option>
                                            @if(isset($Agents_detail) && $Agents_detail !== null && $Agents_detail !== '')
                                                @foreach($Agents_detail as $Agents_details)
                                                    <option attr-Id="{{ $Agents_details->id }}" attr-AN="{{ $Agents_details->agent_Name }}" value="{{ $Agents_details->company_name }}">{{ $Agents_details->company_name }}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    
                                        <input type="hidden" name="agent_Id" id="agent_Id" readonly>
                                        
                                        <input type="hidden" name="agent_Name" id="agent_Name" readonly>
                                        
                                    </div>
                                </div>
                                
                                <div class="col-xl-3 d-none">
                                    <div id="tooltip-container">
                                        <label for="simpleinput" class="form-label simpleinput">Select Agent</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                            data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select the Agent Name">
                                        </i>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <input type="checkbox" class="custom-control-input" id="selectcustomer" name="customer_select" value="booking_by_customer">
                                    <label  class="custom-control-label" for="selectcustomer">Book for Customer</span></label>
                                    
                                    <div class="mb-3" id="customer_div" style="display:none;padding-top: 10px;">
                                        <select class="form-control" id="customer_name" name="customer_name">
                                           <option value="-1">Choose...</option>
                                            @if(isset($customers_data) && $customers_data !== null && $customers_data !== '')
                                                @foreach($customers_data as $customers_res)
                                                    <option attr-cusData='{{ json_encode($customers_res) }}' attr-Id="{{ $customers_res->id }}" value="{{ $customers_res->id }}">{{ $customers_res->name }}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-xl-3 d-none">
                                    <div id="tooltip-container">
                                        <label for="simpleinput" class="form-label simpleinput">Select Customer</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                            data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select the Agent Name">
                                        </i>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="" class="form-label">Currency Symbol</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Currency Symbol will be auto-selected for your account">
                                            </i>
                                        </div>
                                        <select name="currency_symbol" class="form-control currency_symbol">
                                            @foreach($all_curr_symboles as $all_curr_symbolesS)
                                                <option <?php if($all_curr_symbolesS->currency_symbol == $currency) echo 'selected'; ?> value="{{ $all_curr_symbolesS->currency_symbol }}">{{ $all_curr_symbolesS->currency_symbol }}</option>
                                            @endforeach
                                        </select>
                                        <input readonly value="<?php echo $currency; ?>" name="" class="form-control currency_symbol" hidden>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="" class="form-label no_of_pax_days">No Of Pax</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="No Of Pax for this package">
                                            </i>
                                        </div>
                                        <!--<input type="text" id="no_of_pax_days" name="no_of_pax_days" class="form-control no_of_pax_days">-->
                                        <input type="number" name="no_of_pax_days" value="1" min="1" class="form-control no_of_pax_days" id="no_of_pax_days" required>
                                        <input type="number" id="no_of_pax_prev" hidden value="1">
                                        <div class="invalid-feedback">
                                            This Field is Required
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="" class="form-label">Currency Conversion</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Currency Conversion">
                                            </i>
                                        </div>
                                        <select class="form-control CC_id_store" name="currency_conversion" id="currency_conversion1">
                                            <option value="0">Select Currency Conversion</option>
                                            @foreach($mange_currencies as $mange_currencies)
                                                <option attr_id="{{$mange_currencies->id}}" attr_conversion_type="{{$mange_currencies->conversion_type}}" value="{{$mange_currencies->purchase_currency}} TO {{$mange_currencies->sale_currency}}">{{$mange_currencies->purchase_currency}} TO  {{$mange_currencies->sale_currency}}</option>
                                            @endforeach
                                        </select>
                                        <input type="hidden" id="conversion_type_Id"  name="conversion_type_Id" >
                                        <input type="hidden" id="select_exchange_type" value=""> 
                                    </div>
                                </div>
                                
                                <div class="col-xl-12">
                                    <div class="mb-3">
                                        <h6>Lead Passenger Details</h6>
                                        <div class="row" style="border: 1px solid #ebebeb;padding: 1rem;border-radius: 6px;">
                                            <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="" class="form-label no_of_pax_days">First Name</label>
                                                    <input type="text" name="lead_fname" class="form-control" required id="lead_fnameI">
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="" class="form-label no_of_pax_days">Last Name</label>
                                                    <input type="text" name="lead_lname" class="form-control" required id="lead_lnameI">
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="" class="form-label no_of_pax_days">Email</label>
                                                    <input type="text" name="email" class="form-control" required id="lead_emailI">
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="" class="form-label no_of_pax_days">Contact Number</label>
                                                    <input type="text" name="mobile" class="form-control" required id="lead_mobileI">
                                                </div>
                                            </div>
                                            <!-- <div class="col-xl-4">-->
                                            <!--    <div class="mb-3">-->
                                            <!--        <label for="simpleinput" class="form-label no_of_pax_days">Date Of Birth</label>-->
                                            <!--        <input type="date" name="data_of_birth" class="form-control" required>-->
                                            <!--    </div>-->
                                            <!--</div>-->
                                            <!-- <div class="col-xl-4">-->
                                            <!--    <div class="mb-3">-->
                                            <!--        <label for="simpleinput" class="form-label no_of_pax_days">Passport No</label>-->
                                            <!--        <input type="text" name="passport_no" class="form-control" required>-->
                                            <!--    </div>-->
                                            <!--</div>-->
                                            <!-- <div class="col-xl-4">-->
                                            <!--    <div class="mb-3">-->
                                            <!--        <label for="simpleinput" class="form-label no_of_pax_days">Passport Expiry Date</label>-->
                                            <!--        <input type="date" name="passport_expiry_date" class="form-control" required>-->
                                            <!--    </div>-->
                                            <!--</div>-->
                                            
                                                    
                                            <div class="col-xl-4">
                                                <div class="mb-3">
                                                    <label for="" class="form-label no_of_pax_days">Select Nationality</label>
                                                     <select type="text" class="form-control select2 " name="nationality"  data-placeholder="Choose ...">
                                                        @foreach($all_countries as $country_res)
                                                            <option value="{{$country_res->id}}" id="categoriesPV">{{$country_res->name}}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-2" >
                                                <div class="mb-3">
                                                     <p style="margin-top: 2.2rem;">Gender</p>
                                                </div>
                                            </div>
                                            
                                               
                                            <div class="col-2">
                                              <div class="form-check" style="margin-top: 2.2rem;">
                                              <input class="form-check-input" type="radio" name="gender" value="male"  id="flexRadioDefault3">
                                              <label class="form-check-label" for="flexRadioDefault3">
                                                Male
                                              </label>
                                            </div>
                                            
                                            </div>
                                            <div class="col-2" style="margin-top: 2.2rem;">
                                                <div class="form-check">
                                              <input class="form-check-input" type="radio" name="gender" value="female"  id="flexRadioDefault4">
                                              <label class="form-check-label" for="flexRadioDefault4">
                                                Female
                                              </label>
                                            </div>
                                            
                                            </div>
                                            
                                           
                                            
                                        </div>
                                        
                                        
                                        <div id="other_passengers">
                                            
                                            
                                        </div>
                                        
                                    </div>
                                </div>
                                
                                <div class="col-xl-12 d-none">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="" class="form-label">Content</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Additional Information of Package">
                                            </i>
                                        </div>
                                        <!--<textarea name="content" id="" class="contentP summernote" cols="142" rows="10"></textarea>-->
                                        <textarea name="content" class="contentP" cols="135" rows="5"></textarea>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4 d-none visa_type_select">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="" class="form-label start_date">Start Date</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select start date of package">
                                            </i>
                                        </div>
                                        
                                        <input type="date" name="start_date" class="form-control start_date" id="start_date" required placeholder="yyyy/mm/dd">
                                        <div class="invalid-feedback">
                                            This Field is Required
                                        </div>
                                    </div>
                                 </div>
                                
                                <div class="col-xl-4 d-none visa_type_select">
                                    <div class="mb-3">
                                        
                                        <div id="tooltip-container">
                                            <label for="" class="form-label end_date">End Date</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select end date of package">
                                            </i>
                                        </div>
                                        <input type="date" name="end_date" class="form-control end_date" id="end_date" required placeholder="yyyy/mm/dd">
                                        <div class="invalid-feedback">
                                            This Field is Required
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4 d-none visa_type_select">
                                     <div class="mb-3">
                                        <!--<div id="tooltip-container">-->
                                            <label for="" class="form-label no_of_Nights_Other">No Of Nights</label>
                                            <!--<i class="dripicons-information" style="font-size: 17px;" id="title_Icon"-->
                                                <!--data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="No Of Pax Info">-->
                                            <!--</i>-->
                                        <!--</div>-->
                                      
                                      <input readonly type="text" name="time_duration" id="duration" class="form-control time_duration" >
                                     </div>
                                  </div>
                                 
                                <div class="col-xl-4 d-none" >
                                        <div class="mb-3">
                                            <div>
                                                <div id="tooltip-container">
                                                    <label for="categoriesPV">Categories</label>
                                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                        data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Select package Category">
                                                    </i>
                                                
                                                
                                                    <span title="Add Categories" class="input-group-btn input-group-append" style="float: right;margin-bottom:10px">
                                                        <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#add-Categories-modal" type="button">+</button>
                                                    </span>
                                            
                                                    <select type="text" class="form-control select2 categories" name="categories"  data-placeholder="Choose ...">
                                                        @foreach($categories as $categories)
                                                            <option value="{{$categories->id}}" id="categoriesPV" required>{{$categories->title}}</option>
                                                            <div class="invalid-feedback">
                                                                This Field is Required
                                                            </div>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                <div class="col-xl-4 d-none">
                                    <div class="mb-3">
                                        <div>
                                            <div id="tooltip-container">
                                                <label for="simpleinput" class="form-label">Tour Featured </label>
                                                <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                    data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Display your package on Home Page">
                                                </i>
                                            </div>
                                            <select name="tour_feature" id="" class="form-control tour_feature" style="margin-top: 18px">
                                                <option value="">Select Featured</option>
                                                <option value="0">Enable featured</option>
                                                <option value="1">Disable featured</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4 d-none">
                                    <div class="mb-3">
                                        <div>
                                            <!--<div id="tooltip-container">-->
                                                <label for="simpleinput" class="form-label">Default State</label>
                                                <!--<i class="dripicons-information" style="font-size: 17px;" id="title_Icon"-->
                                                    <!--data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="No Of Pax Info">-->
                                                <!--</i>-->
                                            <!--</div>-->
                                            <select name="defalut_state" id="" class="form-control defalut_state" style="margin-top: 18px">
                                                <option value="">Select Default State</option>
                                                <option value="0">Always available</option>
                                                <option value="1">Only available on specific dates</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                  
                                <div class="col-xl-6 d-none">
                                   <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label">Banner Image</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Upload your detail page image for Package (Image size should be 'Width:1600px' 'Height:300px')">
                                            </i>
                                        </div>
                                        <input type="file" id="simpleinput" name="tour_featured_image" class="form-control tour_featured_imageP">
                                    </div>
                                </div>
                                
                                <div class="col-xl-6 d-none">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label">Featured Image</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Upload your main image for Package">
                                            </i>
                                        </div>
                                        <input type="file" id="simpleinput" name="tour_banner_image" class="form-control tour_banner_imageP">
                                    </div>
                                </div>
                                
                                <div class="col-xl-3">
                                    <div class="mb-3">
                                        <!--<div id="tooltip-container">-->
                                            <label for="simpleinput" class="form-label">Author</label>
                                            <!--<i class="dripicons-information" style="font-size: 17px;" id="title_Icon"-->
                                                <!--data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="No Of Pax Info">-->
                                            <!--</i>-->
                                        <!--</div>-->
                                      
                                      <select name="tour_author" id="" class="form-control tour_author">
                                      <option value="">Select Author</option>
                                          <option value="admin">admin</option>
                                          <option value="admin1">admin1</option>
                                      </select>
                                  </div>
                                  </div>
                                  
                                <div class="col-xl-3 more_Div_Acc_All" style="display:none">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Option Date</label>
                                        <input type="date" id="option_date" value="" name="option_date" class="form-control ">
                                    </div>
                                </div>
                                  
                                <div class="col-xl-3 more_Div_Acc_All" style="display:none">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Reservation Number</label>
                                        <input type="text" id="reservation_number" value="" name="reservation_number" class="form-control ">
                                    </div>
                                </div>
                                  
                                <div class="col-xl-3 more_Div_Acc_All" style="display:none">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Hotel Reservation Number</label>
                                        <input type="text" id="hotel_reservation_number" value="" name="hotel_reservation_number" class="form-control ">
                                    </div>
                                </div>
                                  
                                <div class="col-xl-8 d-none">
                                    <div class="mb-3">
                                        <div id="tooltip-container">
                                            <label for="simpleinput" class="form-label">Gallery Images</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon"
                                                data-bs-container="#tooltip-container" data-bs-toggle="tooltip" data-bs-placement="right" title="Upload at least 10 images">
                                            </i>
                                        </div>
                                        <div>
                                            <?php $img_c = 1; ?>
                                	        <input type="file" id="" name="gallery_images[]" class="form-control gallery_imagesP{{ $img_c }}" onchange="validate1({{ $img_c }})">
                                	        <span class="file_error{{ $img_c }}"></span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div id="more_img d-none"></div>
                                        
                                <div class="mt-2 d-none" style="" id="">
                                    <a href="javascript:;" id="more_images" class="btn btn-info" style="float: right;">Add Gallery Images</a>
                                </div>
                                    
                            </div>
                            <!--<a id="save_Package" type="submit" class="btn btn-primary" name="submit">Save Package Deatils</a>-->    
                        </div>

                        <div class="tab-pane" id="visa_details">
                            <div class="row">                                                  
                                <div class="col-xl-12 mt-2">
                                    <div class="mb-3">
                                        <div class="row">
                                            <div class="col-xl-1">
                                                <input type="checkbox" id="visa_inc" data-switch="bool"/>
                                                <label for="visa_inc" data-on-label="On" data-off-label="Off"></label>
                                            </div>
                                            <div class="col-xl-3">
                                                Visa Included ?
                                                <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Add visa price & requirement"></i>
                                            </div>
                                         </div>
                                    </div>
                                </div>
  
                                <div class="row mt-1 mb-3" style="display:none" id="select_visa_inc">
                                  
                                    <div class="col-xl-4" style="padding: 10px;">
                                        <label for="">Visa Type</label>
                                        <div class="input-group" id="timepicker-input-group1">
                                            <select name="visa_type" id="visa_type" class="form-control other_type"></select>
                                            <span title="Add Visa Type" class="input-group-btn input-group-append"><button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#signup-modal" type="button">+</button></span>
                                        </div>
                                     </div>
                                    
                                    <div class="col-xl-4" style="padding: 10px;" id="visa_fee_OLD">
                                        <label for="">Visa Fee</label>
                                        <div class="input-group">
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up" id="visa_C_S">
                                                    <?php echo $currency; ?>
                                                </a>
                                            </span>
                                            <input type="text" id="visa_fee" name="visa_fee" class="form-control">
                                        </div>
                                    </div>
                                    <input type="hidden" id="total_visa_markup_value" name="total_visa_markup_value" class="form-control">
                                    <div class="col-xl-4" style="padding: 10px;">
                                        <label for="">Visa Pax</label>
                                        <input type="text" id="visa_Pax" name="visa_Pax" class="form-control">
                                    </div>
                                    
                                    <div id="invoice_exchage_rate_visa_Div" class="row"></div>
                                    
                                    <div id="add_more_visa_Pax_Div"></div>
                                    
                                    <div class="col-xl-12" style="padding: 10px;text-align: right;">
                                        <button type="button" id="add_more_visa_Pax" class="btn btn-primary">Add more</button>
                                    </div>
                                    
                                    <div class="col-xl-12" style="padding: 10px;">
                                        <label for="">Visa Requirements:</label>
                                        <textarea name="visa_rules_regulations" class="form-control" cols="5" rows="5"></textarea>
                                     </div>
                                     
                                    <div class="col-xl-12" style="padding: 10px;">
                                        <label for="">Image:</label>
                                        <input type="file" id="" name="visa_image" class="form-control">
                                     </div>
                                </div>
                            </div>
                            <!--<a id="save_Visa" class="btn btn-primary" name="submit">Save Visa</a>-->
                        </div> 
                    
                        <div class="tab-pane" id="Extras_details">  
                        
                            <div class="row">
                                
                                <div class="col-xl-4" style="text-align:right;">
                                    <span>Markup on total price</span>
                                </div>
                                
                                <input type="hidden" id="markupSwitch" name="markupSwitch" value="single_markup_switch">
                                
                                <div class="col-xl-1">
                                    <input type="checkbox" id="switch2" data-switch="bool"/>
                                    <label for="switch2" data-on-label="On" data-off-label="Off"></label>
                                </div>
                                 
                                <div class="col-xl-7">
                                    <span>Markup on break down prices</span>
                                </div>
  
                                <div class="col-xl-12" id="markup_services">
                                    <div class="card">
                                        
                                        <div class="card-header">
                                            <h4 class="modal-title" id="standard-modalLabel">Markup on break down prices</h4>
                                        </div>
                                        
                                        <div id="" class="card-body">
                                            <div class="row">
                                                <h4 >Flights Cost <b id="flights_departure_code_html"></b></h4> 
                                                <div class="row" id="flights_cost" style="display:none;padding-bottom: 25px">
                                                    
                                                    <input type="hidden" name="acc_hotel_CityName[]">
                                                    <input type="hidden" name="acc_hotel_HotelName[]">
                                                    <input type="hidden" name="acc_hotel_CheckIn[]">
                                                    <input type="hidden" name="acc_hotel_CheckOut[]">
                                                    <input type="hidden" name="acc_hotel_NoOfNights[]">
                                                    <input type="hidden" name="acc_hotel_Quantity[]">
                                                    
                                                    <div class="col-xl-9">
                                                        <input type="hidden" id="flight_Type_Costing" name="markup_Type_Costing[]" value="flight_Type_Costing" class="form-control">
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <input value="" type="text" id="flights_departure_code" readonly="" name="hotel_name_markup[]" class="form-control flights_type_code">
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <input value="" type="text" id="flights_arrival_code" readonly="" name="room_type[]" class="form-control">
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="flights_price_per_night" readonly="" name="without_markup_price_single[]" class="form-control">    
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group">
                                                            <input type="text" id="flights_prices" readonly="" name="without_markup_price[]" class="form-control flights_per_person_price12345">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <select name="markup_type[]" id="markup_type" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                            <input type="text"  class="form-control" id="markup_value" name="markup[]">
                                                            <span class="input-group-btn input-group-append">
                                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="markup_value_markup_mrk">%</div></button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-1" style="display:none">
                                                        <input type="text" id="flights_exchage_rate_per_night" readonly="" name="exchage_rate_single[]" class="form-control">    
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="flights_exchage_rate_markup_total_per_night" readonly="" name="markup_total_per_night[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                            </span>
                                                        </div> 
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group">
                                                            <input type="text" id="total_markup" name="markup_price[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                                
                                                <div class="row d-none" style="padding-bottom: 20px">
                                                    
                                                    <div class="col-xl-2">
                                                        <label for="">Total Adult</label>
                                                        <input  type="text" id="adult_final_qty"  readonly="" name="adultfinalqty" class="form-control">
                                                    </div>
                                                    
                                                     
                                                    <div class="col-xl-2">
                                                        <label for="">Per Adult Price</label>
                                                        <div class="input-group">
                                                            <input type="text" id="per_adult_price" readonly="" name="adultPerprice" class="form-control flights_per_person_price12345">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <label for=""></label>
                                                        <select name="" id="markup_type_for_adult" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <label for=""></label>
                                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                            <input type="text"  class="form-control" id="markup_value_for_adult" name="">
                                                            <span class="input-group-btn input-group-append">
                                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="markup_value_markup_mrk_for_adult">%</div></button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                     <input type="hidden"  class="form-control adult_total_with_markup"  name="adult_total_with_markup">
                                                    
                                                    
                                                    
                                                    <div class="col-xl-2">
                                                        <label for=""></label>
                                                        <div class="input-group">
                                                            <input type="text" id="total_markup_for_adult" name="adult_markup_price1" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <label for=""></label>
                                                        <div class="input-group">
                                                            <input type="text" id="total_adult_markup" name="adult_markup_price" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                                <div class="row d-none" style="padding-bottom: 20px">
                                                    
                                                    <div class="col-xl-2">
                                                            
                                                  <label for="">Total Child</label>
                                                        <input  type="text" id="child_final_qty" readonly="" name="childfinalqty" class="form-control">
                                                    </div>
                                                    
                                                  
                                                   
                                                    <div class="col-xl-2">
                                                         <label for="">Per Child Price</label>
                                                        <div class="input-group">
                                                            <input type="text" id="per_child_price" readonly="" name="childPerprice" class="form-control flights_per_person_price12345">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                           <label for=""></label>
                                                        <select name="" id="markup_type_for_child" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                           <label for=""></label>
                                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                            <input type="text"  class="form-control" id="markup_value_for_child" name="">
                                                            <span class="input-group-btn input-group-append">
                                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="markup_value_markup_mrk">%</div></button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <input type="hidden"  class="form-control child_total_with_markup"  name="child_total_with_markup">
                                                    <div class="col-xl-1" style="display:none">
                                                        <input type="text" id="flights_exchage_rate_per_night" readonly="" name="" class="form-control">    
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="flights_exchage_rate_markup_total_per_night" readonly="" name="" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                            </span>
                                                        </div> 
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <label for=""></label>
                                                        <div class="input-group">
                                                            <input type="text" id="total_markup_for_child" name="total_markup_for_child" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-2">
                                                        <label for=""></label>
                                                        <div class="input-group">
                                                            <input type="text" id="total_child_markup" name="" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                                <div class="row d-none" style="padding-bottom: 20px">
                                                    
                                                    <div class="col-xl-2">
                                                         <label for="">Total Infant</label>
                                                        <input  type="text" id="infant_final_qty" readonly="" name="infantfinalqty" class="form-control">
                                                    </div>
                                                    
                                                  
                                                    <div class="col-xl-2">
                                                          <label for="">Per Infant Price</label>
                                                        <div class="input-group">
                                                            <input type="text" id="per_infant_price" readonly="" name="infantPerprice" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                          <label for=""></label>
                                                        <select name="" id="markup_type_for_infant" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                         <label for=""></label>
                                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                            <input type="text"  class="form-control" id="markup_value_for_infant" name="">
                                                            <span class="input-group-btn input-group-append">
                                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="markup_value_markup_mrk">%</div></button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                     <input type="hidden"  class="form-control infant_total_with_markup"  name="infant_total_with_markup">
                                                    <div class="col-xl-1" style="display:none">
                                                        <input type="text" id="flights_exchage_rate_per_night" readonly="" name="" class="form-control">    
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="flights_exchage_rate_markup_total_per_night" readonly="" name="" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                            </span>
                                                        </div> 
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                         <label for=""></label>
                                                        <div class="input-group">
                                                            <input type="text" id="total_markup_for_infant" name="total_markup_for_infant" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div> 
                                                    <div class="col-xl-2">
                                                         <label for=""></label>
                                                        <div class="input-group">
                                                            <input type="text" id="total_infant_markup" name="" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                                <div id="append_accomodation_data_cost"></div>
                                                
                                                <hr style="width: 98%;margin-left: 13px;margin-top: 10px;margin-bottom: 10px;color: black;"></hr>
                                                
                                                <div id="append_accomodation_data_cost1"></div>
                                                
                                                <div class="row" id="transportation_cost" style="display:none;">
                                                    
                                                    <div class="col-xl-3">
                                                         <h4 class="" id="">Transportation Cost</h4>
                                                    </div>
                                                    
                                                    <input type="hidden" name="acc_hotel_CityName[]">
                                                    <input type="hidden" name="acc_hotel_HotelName[]">
                                                    <input type="hidden" name="acc_hotel_CheckIn[]">
                                                    <input type="hidden" name="acc_hotel_CheckOut[]">
                                                    <input type="hidden" name="acc_hotel_NoOfNights[]">
                                                    <input type="hidden" name="acc_hotel_Quantity[]">
                                                    
                                                    <div class="col-xl-9">
                                                        <input type="hidden" id="transportation_Type_Costing" name="markup_Type_Costing[]" value="transportation_Type_Costing" class="form-control">  
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <input type="text" id="transportation_pick_up_location_select" readonly="" name="hotel_name_markup[]" class="form-control">
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <input type="text" id="transportation_drop_off_location_select" readonly="" name="room_type[]" class="form-control">
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="transportation_price_per_night" readonly="" name="without_markup_price_single[]" class="form-control">    
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group">
                                                            <input type="text" id="transportation_price_per_person_select" readonly="" name="without_markup_price[]" class="form-control" readonly>
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <select name="markup_type[]" id="transportation_markup_type" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                            <input type="text"  class="form-control" id="transportation_markup" name="markup[]" readonly>
                                                            <span class="input-group-btn input-group-append">
                                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="transportation_markup_mrk">%</div></button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-1" style="display:none">
                                                        <input type="text" id="transportation_exchage_rate_per_night" readonly="" name="exchage_rate_single[]" class="form-control">    
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="transportation_exchage_rate_markup_total_per_night" readonly="" name="markup_total_per_night[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                            </span>
                                                        </div> 
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group">
                                                            <input type="text" id="transportation_markup_total" name="markup_price[]" class="form-control" readonly>
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                                <div class="row" id="visa_cost" style="display:none;">
                                                    
                                                    <div class="col-xl-3">
                                                        <h4 class="" id="">Visa Cost</h4>
                                                    </div>
                                                    
                                                    <input type="hidden" name="acc_hotel_CityName[]">
                                                    <input type="hidden" name="acc_hotel_HotelName[]">
                                                    <input type="hidden" name="acc_hotel_CheckIn[]">
                                                    <input type="hidden" name="acc_hotel_CheckOut[]">
                                                    <input type="hidden" name="acc_hotel_NoOfNights[]">
                                                    <input type="hidden" name="acc_hotel_Quantity[]">
                                                    
                                                    <div class="col-xl-9">
                                                        <input type="hidden" id="visa_Type_Costing" name="markup_Type_Costing[]" value="visa_Type_Costing" class="form-control">
                                                    </div>
                                                    
                                                    <div class="col-xl-3">
                                                        <input readonly type="text" id="visa_type_select" name="hotel_name_markup[]" class="form-control">
                                                    </div> 
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="visa_price_per_night" readonly="" name="without_markup_price_single[]" class="form-control">    
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-3">
                                                        <div class="input-group">
                                                            <input readonly type="text" id="visa_price_select" name="without_markup_price[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <select name="markup_type[]" id="visa_markup_type" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                            <input type="text" class="form-control" id="visa_markup" name="markup[]">
                                                            <span class="input-group-btn input-group-append">
                                                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="visa_mrk">%</div></button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-xl-1" style="display:none">
                                                        <input type="text" id="visa_exchage_rate_per_night" readonly="" name="exchage_rate_single[]" class="form-control">    
                                                    </div>
                                                    
                                                    <div class="col-xl-2" style="display:none">
                                                        <div class="input-group">
                                                            <input type="text" id="visa_exchage_rate_markup_total_per_night" readonly="" name="markup_total_per_night[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                                            </span>
                                                        </div> 
                                                    </div>
                                                    
                                                    <div class="col-xl-2">
                                                        <div class="input-group">
                                                            <input type="text" id="total_visa_markup" name="markup_price[]" class="form-control">
                                                            <span class="input-group-btn input-group-append">
                                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                                   <?php echo $currency; ?>
                                                                </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                                <div id="more_visa_cost_div"></div>
                                                    
                                            </div>    
                                        </div>
                                            
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-xl-12" style="display:none;" id="all_services_markup">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="modal-title" id="standard-modalLabel">Markup on total price</h4>
                                            <div class="card-body">
                                               <div class="row">
                                                   
                                                    <div class="col-xl-6">
                                                        <div class="mb-3">
                                                            <label for="all_markup_type" class="form-label">Markup Type</label>
                                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Markup type"></i>
                                                             <select class="form-control" id="all_markup_type" name="all_markup_type" >
                                                                <option>Select Markup Type</option>
                                                                <option value="%">Percentage</option>
                                                                <option value="<?php echo $currency; ?>">Number</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                
                                                    <div class="col-xl-6">
                                                        <div class="mb-3">
                                                            <label for="all_markup_add" class="form-label">All Markup</label>
                                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="All Markup"></i>
                                                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                                <input type="text"  class="form-control" id="all_markup_add" name="all_markup_add">
                                                                <span class="input-group-btn input-group-append">
                                                                    <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="select_mrk">%</div></button>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                
                                               </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            
                            <div id="accomodation_price_hide" class="row mt-2 d-none">
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Quad Cost Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Quad Cost Price"></i>
                                        <div class="input-group">
                                            <input class="form-control" id="quad_cost_price" name="quad_cost_price" />
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                   <?php echo $currency; ?>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Triple Cost Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Triple Cost Price"></i>
                                        <div class="input-group">
                                            <input class="form-control" id="triple_cost_price" name="triple_cost_price" />
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                    <?php echo $currency; ?>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Double Cost Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Double Cost Price"></i>
                                        <div class="input-group">
                                            <input class="form-control" id="double_cost_price" name="double_cost_price" />
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                    <?php echo $currency; ?>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            
                            </div>
                        
                            <div class="row d-none" id="sale_pr">
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="" class="form-label quad_grand_total_amount">Quad Sale Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Quad Sale Price"></i>
                                        
                                        <div class="input-group">
                                            <!--<input class="form-control" id="quad_grand_total_amount" name="quad_grand_total_amount" />-->
                                            <input type="text" name="quad_grand_total_amount_single" class="form-control" id="quad_grand_total_amount">
                                            
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                                           <?php echo $currency; ?>
                                                        </a>
                                                    </span>
                                            <div class="invalid-feedback">
                                                This Field is Required
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="triple_grand_total_amount" class="form-label">Triple Sale Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Triple Sale Price"></i>
                                        <div class="input-group">
                                            <!--<input class="form-control" id="triple_grand_total_amount" name="triple_grand_total_amount" />-->
                                            <input type="text" name="triple_grand_total_amount_single" class="form-control" id="triple_grand_total_amount">
                                            
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                                           <?php echo $currency; ?>
                                                        </a>
                                                    </span>
                                            <div class="invalid-feedback">
                                                This Field is Required
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-xl-4">
                                    <div class="mb-3">
                                        <label for="double_grand_total_amount" class="form-label">Double Sale Price</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Double Sale Price"></i>
                                        <div class="input-group">
                                            <!--<input class="form-control" id="double_grand_total_amount" name="double_grand_total_amount" />-->
                                            <input type="text" name="double_grand_total_amount_single" class="form-control" id="double_grand_total_amount">
                                            
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                                           <?php echo $currency; ?>
                                                        </a>
                                                    </span>
                                            <div class="invalid-feedback">
                                                This Field is Required
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                            
                            <div class="row" id="markup_seprate_services" style="display:none;">
                                    <div class="col-xl-4">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label quad_markup">Quad Sale Price</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Quad Sale Price"></i>
                                            <input class="form-control" id="quad_markup" name="quad_grand_total_amount" />
                                            <!--<input type="text" name="quad_grand_total_amount" class="form-control" id="quad_markup" required>-->
                                            <!--<div class="invalid-feedback">-->
                                            <!--    This Field is Required-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                    <div class="col-xl-4">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label triple_markup">Triple Sale Price</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Triple Sale Price"></i>
                                            <input class="form-control" id="triple_markup" name="triple_grand_total_amount" />
                                            <!--<input type="text" name="triple_grand_total_amount" class="form-control" id="triple_markup" required>-->
                                            <!--<div class="invalid-feedback">-->
                                            <!--    This Field is Required-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                    <div class="col-xl-4">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label double_markup">Double Sale Price</label>
                                            <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Double Sale Price"></i>
                                            <input class="form-control" id="double_markup" name="double_grand_total_amount" />
                                            <!--<input type="text" name="double_grand_total_amount" class="form-control" id="double_markup" required>-->
                                            <!--<div class="invalid-feedback">-->
                                            <!--    This Field is Required-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                </div>
                                
                            <div class="row">
                                <div class="col-xl-6">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Payment Methods</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payment GateWay"></i>
                                        <select class="form-control" id="payment_gateways" name="payment_gateways">
                                            <option value="">Select Payment Gateway</option>
                                            @if(isset($payment_gateways))
                                                @foreach($payment_gateways as $payment_gateways)
                                                    <option value="{{$payment_gateways->payment_gateway_title}}">{{$payment_gateways->payment_gateway_title}}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            
                                <div class="col-xl-6">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Payment Mode</label>
                                        <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payment Mode"></i>
                                        <select class="select2 form-control select2-multiple external_packages" data-toggle="select2" multiple="multiple" id="payment_modes" name="payment_modes[]">
                                            <option value="">Select Payment Mode</option>
                                            @if(isset($payment_modes))
                                                @foreach($payment_modes as $payment_modes)
                                                    <option value="{{$payment_modes->payment_mode}}">{{$payment_modes->payment_mode}}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
    
                                <div class="col-xl-12">
                                    <label for="">Payment Instructions</label>
                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payment Instructions"></i>
                                    <textarea name="checkout_message" class="form-control" cols="5" rows="5" value="{{ $account_No }}">{{ $account_No }}</textarea>
                                </div>
                            </div>
      
                            <!--<a id="save_Costing" class="btn btn-primary" name="submit">Save Costing Details</a>-->
                            <button style="float: right;width: 100px;margin-top: 10px;" type="submit" name="submit" class="btn btn-info deletButton">Submit</button>
                        </div>
                        
                        <ul class="list-inline mb-0 wizard" style="margin-top:60px;">
                            <li class="previous list-inline-item">
                                <a href="javascript:void(0);" style="width: 100px;" class="btn btn-info">Previous</a>
                            </li>
                            <li class="next list-inline-item float-end">
                                <a href="javascript:void(0);" style="width: 100px;" id="" class="btn btn-info">Next</a>
                            </li>
                        </ul>
                                                
                    </div>
                    
                </div> 
            </form>
        <!--</div>-->
    </div>
</div>

@endsection

@section('scripts')

<script src="https://maps.googleapis.com/maps/api/js?libraries=places&callback=initAutocomplete&language=nl&output=json&key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY" async defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.20/summernote-bs5.min.js" integrity="sha512-6F1RVfnxCprKJmfulcxxym1Dar5FsT/V2jiEUvABiaEiFWoQ8yHvqRM/Slf0qJKiwin6IDQucjXuolCfCKnaJQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>

    $(document).on('change','#select_services' ,function(){
        var val = $('#select_services option:selected').val();
        //alert(val);
        if(val == 'flights_tab')
        {
            $("#accomodation_price_hide").css('display','none');
            $("#sale_pr").css('display','none');
        }
        if(val == 'visa_tab')
        {
            $("#accomodation_price_hide").css('display','none');
            $("#sale_pr").css('display','none');
        }
        if(val == 'transportation_tab')
        {
            $("#accomodation_price_hide").css('display','none');
            $("#sale_pr").css('display','none');
        }
    });

    function validate1(id) {
    	$('.file_error'+id+'').html("");
    	$('.gallery_imagesP'+id+'').css("border-color","#F0F0F0");
    	var file_size = $('.gallery_imagesP'+id+'')[0].files[0].size;
    	if(file_size > 100000) {
    		$('.file_error'+id+'').html("File size is greater than 100kb");
    		$('.gallery_imagesP'+id+'').css("border-color","#FF0000");
    		return false;
    	} 
    	return true;
    }
    
    function selectServices(){
        var selectedServices = $('#select_services').val();
        
        $.each(selectedServices, function(key, value) {
            if(value != null && value != ''){
                if((value == '1') || (value == 'accomodation_tab')){
                    $('.more_Div_Acc_All').css('display','');
                    $('.no_of_Nights_Other').html('No Of Nights');
                    $('.visa_type_select').css('display','');
                }else if(value == 'visa_tab'){
                    $('.visa_type_select').css('display','none');
                    $('.more_Div_Acc_All').css('display','none');
                }else{
                    $('.more_Div_Acc_All').css('display','none');
                    $('.no_of_Nights_Other').html('Total Duration');
                    $('.visa_type_select').css('display','');
                }
            }
        });
        
        const allServicesSelect = selectedServices.find(element => element == 1);
        
        if(allServicesSelect){
            $(".accomodation_tab").css('display','block');
            $(".flights_tab").css('display','block');
            $(".visa_tab").css('display','block');
            $(".transportation_tab").css('display','block');
        }else{
            $(".accomodation_tab").css('display','none');
            $(".flights_tab").css('display','none');
            $(".visa_tab").css('display','none');
            $(".transportation_tab").css('display','none');
            for(var i=0; i < selectedServices.length; i++){
                $("."+selectedServices[i]+"").css('display','flex');
            }
        }
    }
    
    var passengerCounter = 1;
     $('#no_of_pax_days').on('change',function(){
        var no_of_pax_days = $('#no_of_pax_days').val();
         $('#adult_number').val(no_of_pax_days);
         $('#reserved_pax').val(no_of_pax_days);
        var prev_value = $('#no_of_pax_prev').val();
        
        var difference = no_of_pax_days - prev_value;
        
        passengerCounter = +passengerCounter + +difference
         
         
         for(var i = prev_value; i<=no_of_pax_days; i++){
             id = +i + +1;
            //  console.log('id is now '+id);
         }
         
         $('#no_of_pax_prev').val(no_of_pax_days);
         var passengerHtml = `<div class="row other_passengers" style="border: 1px solid #ebebeb;padding: 1rem;border-radius: 6px;">
                                            <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label no_of_pax_days">First Name</label>
                                                    <input type="text" name="lead_fname" class="form-control" required>
                                                </div>
                                            </div>
                                            
                                             <div class="col-xl-6">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label no_of_pax_days">Last Name</label>
                                                    <input type="text" name="lead_fname" class="form-control" required>
                                                </div>
                                            </div>
                                            
                                                    
                                            <div class="col-xl-4">
                                                <div class="mb-3">
                                                    <label for="simpleinput" class="form-label no_of_pax_days">Select Nationality</label>
                                                     <select type="text" class="form-control select2 " name="Country"  data-placeholder="Choose ...">
                                                        @foreach($all_countries as $country_res)
                                                            <option value="{{$country_res->id}}" id="categoriesPV" required>{{$country_res->name}}</option>
                                                           
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xl-2" >
                                                <div class="mb-3">
                                                     <p style="margin-top: 2.2rem;">Gender</p>
                                                </div>
                                            </div>
                                            
                                               
                                            <div class="col-2">
                                              <div class="form-check" style="margin-top: 2.2rem;">
                                              <input class="form-check-input" type="radio" name="gender" value="male"  id="flexRadioDefault3">
                                              <label class="form-check-label" for="flexRadioDefault3">
                                                Male
                                              </label>
                                            </div>
                                            
                                            </div>
                                            <div class="col-2" style="margin-top: 2.2rem;">
                                                <div class="form-check">
                                              <input class="form-check-input" type="radio" name="gender" value="female"  id="flexRadioDefault4">
                                              <label class="form-check-label" for="flexRadioDefault4">
                                                Female
                                              </label>
                                            </div>
                                            </div>
                                        </div>`
                                        // console.log("no_of_pax_days"+no_of_pax_days);
                                        
    })
    
</script>

<!--Package Save-->
<script>

    $("#selectAgent").click(function() {
        $('#lead_fnameI').val('');
        $('#lead_lnameI').val('');
        $('#lead_emailI').val('');
        $('#lead_mobileI').val('');
        
        if($("#selectAgent").is(':checked')){
            $("#selectcustomer").prop('checked', false);
            $('#customer_div').css('display','none')
            $('#agent_div').css('display','block')
            $('#customer_name').val('-1').change();
        }else {
            $('#agent_div').css('display','none')
        }
    });
        
    $("#selectcustomer").click(function() {
        $('#lead_fnameI').val('');
        $('#lead_lnameI').val('');
        $('#lead_emailI').val('');
        $('#lead_mobileI').val('');
        
        if($("#selectcustomer").is(':checked')){
            $("#selectAgent").prop('checked', false);
            $('#agent_div').css('display','none')
            $('#customer_div').css('display','block')
            $('#agent_Company_Name').val('').change();
            
        }else{
            $('#customer_div').css('display','none')
        }
    });
</script>
<!-- End Package Save-->

<!--Flights-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY&sensor=false&libraries=places"></script>
<!--End Flights-->

<script>

    $("#extra_price").on('click',function(){
        $("#extraprice_select").slideToggle();
    });
    
    $("#all_markup_type").change(function () {
    var id = $(this).find('option:selected').attr('value');
    
        $('#select_mrk').text(id);
    if(id == '%')
    {
        $('#all_markup_add').keyup(function() {
            
   var markup_val =  $('#all_markup_add').val();
   
       var quad_cost_price   =  $('#quad_cost_price').val();
       var triple_cost_price =  $('#triple_cost_price').val();
       var double_cost_price =  $('#double_cost_price').val();
       
        if(quad_cost_price != 0){
            var total_quad_cost_price1 = (quad_cost_price * markup_val/100) + parseFloat(quad_cost_price);
            var total_quad_cost_price = total_quad_cost_price1.toFixed(2); 
            $('#quad_markup').val(total_quad_cost_price);   
        }else{
           $('#quad_markup').val(0);
        }
   
      
        if(triple_cost_price != 0){
            var total_triple_cost_price1 = (triple_cost_price * markup_val/100) + parseFloat(triple_cost_price);
            var total_triple_cost_price = total_triple_cost_price1.toFixed(2);
            $('#triple_markup').val(total_triple_cost_price);    
        }else{
            $('#triple_markup').val(0);
        }
        
        if(double_cost_price != 0){
            var total_double_cost_price1 = (double_cost_price * markup_val/100) + parseFloat(double_cost_price);
            var total_double_cost_price = total_double_cost_price1.toFixed(2);
            $('#double_markup').val(total_double_cost_price);
        }else{
            $('#double_markup').val(0);
        }
        
        
        
 
});
       
       
    }
    else
    {
       $('#all_markup_add').keyup(function() {
            
   var markup_val =  $('#all_markup_add').val();
   
        var quad_cost_price =  $('#quad_cost_price').val();
        var triple_cost_price =  $('#triple_cost_price').val();
        var double_cost_price =  $('#double_cost_price').val();
        
        if(quad_cost_price != 0){
            var total_quad_cost_price1 =  parseFloat(quad_cost_price) +  parseFloat(markup_val);
            var total_quad_cost_price = total_quad_cost_price1.toFixed(2); 
            $('#quad_markup').val(total_quad_cost_price);  
        }else{
           $('#quad_markup').val(0);
        }
   
      
        if(triple_cost_price != 0){
            var total_triple_cost_price1 =  parseFloat(triple_cost_price) +  parseFloat(markup_val);
            var total_triple_cost_price = total_triple_cost_price1.toFixed(2);
            $('#triple_markup').val(total_triple_cost_price);    
        }else{
            $('#triple_markup').val(0);
        }
        
        if(double_cost_price != 0){
            var total_double_cost_price1 = parseFloat(double_cost_price) +  parseFloat(markup_val);
            var total_double_cost_price = total_double_cost_price1.toFixed(2);
            $('#double_markup').val(total_double_cost_price);
        }else{
            $('#double_markup').val(0);
        }
   
        // var total_quad_cost_price1 =  parseFloat(quad_cost_price) +  parseFloat(markup_val);
        // var total_quad_cost_price = total_quad_cost_price1.toFixed(2); 
        // $('#quad_markup').val(total_quad_cost_price);
        
        // var total_triple_cost_price1 =  parseFloat(triple_cost_price) +  parseFloat(markup_val);
        // var total_triple_cost_price = total_triple_cost_price1.toFixed(2);
        // $('#triple_markup').val(total_triple_cost_price);
        
        // var total_double_cost_price1 = parseFloat(double_cost_price) +  parseFloat(markup_val);
        // var total_double_cost_price = total_double_cost_price1.toFixed(2);
        // $('#double_markup').val(total_double_cost_price);
        
        
 
});
     
    }
      
  

  });

    $(document).on('click','#visa_inc',function(){
        $("#select_visa_inc").slideToggle();
        $('#visa_cost').toggle();
        
        $.ajax({    
           
            url: "super_admin/get_other_visa_type_detail", 
             type: "GET",
            dataType: "html",                  
            success: function(data){  
            
                var data1 = JSON.parse(data);
                var data2= JSON.parse(data1['visa_type']);
                //   console.log(data2['visa_type']);
                // jQuery.each(data2, function(key, value){  
                //     $(".other_type").append('<option value=' +value.id+ '>' + value.other_visa_type+ '</option>');
                //   });
            	$("#visa_type").empty();
           
                $.each(data2['visa_type'], function(key, value) {
                    var visa_type_Data = `<option attr="${value.other_visa_type}" value="${value.other_visa_type}"> ${value.other_visa_type}</option>`;
                    $("#visa_type").append(visa_type_Data);
                });  
            }
        });
    });
    
</script>
  
@stop

@section('slug')

<script>
    var Agents_detail = {!!json_encode($Agents_detail)!!};
    var all_countries = {!!json_encode($all_countries)!!};

    $('#agent_Company_Name').change(function () {
        var agent_Id = $(this).find('option:selected').attr('attr-Id');
        $('#agent_Id').val(agent_Id);
        
        var agent_Name = $(this).find('option:selected').attr('attr-AN');
        console.log('agent_Name : '+agent_Name);
        
        $('#agent_Name').val(agent_Name);
        
        $.each(Agents_detail, function(key, value) {
            var AD_id = value.id;
            if(AD_id == agent_Id){
                var lead_fname      = value.agent_Name;
                var lead_lname      = value.agent_Name;
                var lead_email      = value.agent_Email;
                var lead_mobile     = value.agent_contact_number;
                var company_name    = value.company_name;
                
                $('#lead_fnameI').val(company_name);
                $('#lead_lnameI').val(company_name);
                $('#lead_emailI').val(lead_email);
                $('#lead_mobileI').val(lead_mobile);
            }
        });
        
    });
    
    $('#customer_name').change(function () {
        var customer_data   = $(this).find('option:selected').attr('attr-cusData');
        var customer_data2  = JSON.parse(customer_data);
        var lead_fname      = customer_data2['name'];
        var lead_lname      = customer_data2['name'];
        var lead_email      = customer_data2['email'];
        var lead_mobile     = customer_data2['phone'];
        $('#lead_fnameI').val(lead_fname);
        $('#lead_lnameI').val(lead_lname);
        $('#lead_emailI').val(lead_email);
        $('#lead_mobileI').val(lead_mobile);
    });
  
    $("#markup_type").change(function () {
        var id = $(this).find('option:selected').attr('value');
        
        $('#markup_value_markup_mrk').text(id);
        var markup_val =  $('#markup_value').val();
        
        var flights_prices =  $('#flights_prices').val();
        if(id == '%')
        {
            $('#markup_value').keyup(function() {
                var markup_val =  $('#markup_value').val();
                var total1 = (flights_prices * markup_val/100) + parseFloat(flights_prices) ;
                var total = total1.toFixed(2);
                $('#total_markup').val(total);
                add_numberElse_1I();
            });
        }
        else
        {
            $('#markup_value').keyup(function() {
                var markup_val =  $('#markup_value').val();
                console.log(markup_val);
                var total1 = parseFloat(flights_prices) + parseFloat(markup_val);
                var total = total1.toFixed(2);
                $('#total_markup').val(total);
                add_numberElse_1I();
            });
        }
    });
      
    $('#property_city').change(function(){
        var arr=[];
        $('#property_city option:selected').each(function(){
        var $value =$(this).attr('type');
        // console.log($value);
        arr.push($value);
    });
// console.log(arr);
var json_data=JSON.stringify(arr);
$('#tour_location_city').val(json_data); 
$('#packages_get_city').val(json_data);
 
}); 

    $("#visa_type").change(function () {
        var id = $(this).find('option:selected').attr('attr');
        
        $('#visa_type_select').val(id);
        
        
        });
    
    $("#visa_markup_type").change(function () {
        var id = $(this).find('option:selected').attr('value');
        $('#visa_mrk').text(id);
        // var markup_val =  $('#visa_markup').val();
        // var visa_price_select =  $('#visa_price_select').val();
        if(id == '%')
        {
            $('#visa_markup').keyup(function() {
                var markup_val =  $('#visa_markup').val();
                var visa_price_select =  $('#visa_price_select').val();
                var total1 = (visa_price_select * markup_val/100) + parseFloat(visa_price_select);
                var total = total1.toFixed(2);
                $('#total_visa_markup').val(total);
                $('#total_visa_markup_value').val(total);
                
                add_numberElse_1I();
            });
        }
        else
        {
            $('#visa_markup').keyup(function() {
                var markup_val =  $('#visa_markup').val();
                var visa_price_select =  $('#visa_price_select').val();
                var total1 =  parseFloat(visa_price_select) +  parseFloat(markup_val);
                var total = total1.toFixed(2);
                $('#total_visa_markup').val(total);
                $('#total_visa_markup_value').val(total);
                add_numberElse_1I();
            });
        }
    });
        
    $('#visa_fee').keyup(function() {
        var visa_fee = $(this).val();
        $('#visa_price_select').val(visa_fee);
        $('#exchange_rate_visaI').val('');
        $('#exchange_rate_visa_total_amountI').val('');
        add_numberElseI();
    });
    
    $("#visa_type").change(function () {
        var id = $(this).find('option:selected').attr('value');
        if(id == 'Others'){
        	$('#SubmitForm_sec').fadeOut();
        	$('#SubmitForm_sec').fadeIn();
        }
        else{
        	$('#SubmitForm_sec').fadeOut();
        }
    });
    
</script>

<script>
    
    function add_numberElseI(){
        var flights_prices=parseFloat($("#flights_prices").val());  
        if(isNaN(flights_prices)) 
        {
            flights_prices=0;
        }
        else
        {
            var flights_prices=parseFloat($("#flights_prices").val()); 
        }
        var visa_price_select=parseFloat($("#visa_fee").val());  
        if(isNaN(visa_price_select)) 
        {
            visa_price_select=0;
        }
        else
        {
            var visa_price_select=parseFloat($("#visa_fee").val());
        }
  
        var transportation_price_per_person_select=parseFloat($("#transportation_price_per_person").val());
        if(isNaN(transportation_price_per_person_select)) 
        {
            transportation_price_per_person_select=0;
        }
        else
        {
            var transportation_price_per_person_select=parseFloat($("#transportation_price_per_person").val());
        }
        
        var count =$("#city_No").val();
        
        // var city_slc =$(".city_slc").val();
        // var count = city_slc.length;
        var quad_hotel=0;
        var triple_hotel=0;
        var double_hotel=0;
        var more_quad_hotel=0;
        var more_triple_hotel=0;
        var more_double_hotel=0;
   
        for(var i=1; i<=5; i++){
            var hotel_acc_type = $('#hotel_acc_type_'+i+'').val();
            var hotel_markup = parseFloat($("#hotel_acc_price_"+i+'').val());
            
            if(isNaN(hotel_markup)) 
            {
                hotel_markup=0;
            }
            else
            {
                var hotel_markup=parseFloat($("#hotel_acc_price_"+i+'').val());
            }
            
            if(hotel_acc_type == 'Quad')
            {
                quad_hotel = quad_hotel + hotel_markup;
                var quad_hotel1 = quad_hotel.toFixed(2);
                $('#quad_cost_price').val(quad_hotel1);
            }
            if(hotel_acc_type == 'Triple')
            {
                triple_hotel = triple_hotel + hotel_markup;
                var triple_hotel1 = triple_hotel.toFixed(2);
                $('#triple_cost_price').val(triple_hotel1);
            }
            if(hotel_acc_type == 'Double')
            {
                double_hotel = double_hotel + hotel_markup;
                var double_hotel1 = double_hotel.toFixed(2);
                $('#double_cost_price').val(double_hotel1);
            }
                   
        }
        
        var sumData = flights_prices + visa_price_select + transportation_price_per_person_select;
        if(quad_hotel != 0){
            var quadCost = quad_hotel + sumData;
        }else{
            var quadCost = 0;
        }
        if(triple_hotel != 0){
            var tripleCost = triple_hotel + sumData;
        }else{
            var tripleCost = 0;
        }
        if(double_hotel != 0){
            var doubleCost = double_hotel + sumData;
        }else{
            var doubleCost = 0;
        }
        quadCost = quadCost.toFixed(2);
        $('#quad_cost_price').val(quadCost);
        tripleCost = tripleCost.toFixed(2);
        $('#triple_cost_price').val(tripleCost);
        doubleCost = doubleCost.toFixed(2);
        $('#double_cost_price').val(doubleCost);
        
        for(var k=1; k<=50; k++){
            
            var more_hotel_acc_type=$('#more_hotel_acc_type_'+k+'').val(); 
            var more_hotel_markup=$('#more_hotel_acc_price_'+k+'').val();  
            
            if(isNaN(more_hotel_markup)) 
            {
                more_hotel_markup=0;
            }
            else
            {
                var more_hotel_markup=parseFloat($("#more_hotel_acc_price_"+k+'').val());
            }
            if(more_hotel_acc_type == 'Quad')
            {
               more_quad_hotel = more_quad_hotel + more_hotel_markup;
               var more_quad_hotel1 = more_quad_hotel.toFixed(2);
                 $('#quad_cost_price').val(more_quad_hotel1);
            }
            if(more_hotel_acc_type == 'Triple')
            {
                more_triple_hotel = more_triple_hotel + more_hotel_markup;
                var more_triple_hotel1 = more_triple_hotel.toFixed(2);
                $('#triple_cost_price').val(more_triple_hotel1);
            }
            if(more_hotel_acc_type == 'Double')
            {
               more_double_hotel = more_double_hotel + more_hotel_markup;
               var more_double_hotel1 = more_double_hotel.toFixed(2);
                $('#double_cost_price').val(more_double_hotel1);
            }
        }
        
        var morequadCost = sumData + more_quad_hotel;
        morequadCost = morequadCost.toFixed(2);
        
        if(more_quad_hotel == 0){
            if(quadCost != 0){
                $('#quad_cost_price').val(quadCost);   
            }else{
                $('#quad_cost_price').val(0);   
            }
        }else{
            $('#quad_cost_price').val(morequadCost);   
        }
        
        var moretripleCost = sumData + more_triple_hotel;
        moretripleCost = moretripleCost.toFixed(2);
        
        if(more_triple_hotel == 0){
            if(tripleCost != 0){
                $('#triple_cost_price').val(tripleCost);   
            }else{
                $('#triple_cost_price').val(0);   
            }  
        }else{
            $('#triple_cost_price').val(moretripleCost);   
        }
        
        
        var moredoubleCost = sumData + more_double_hotel;
        moredoubleCost = moredoubleCost.toFixed(2);
        
        if(more_double_hotel == 0){
            if(doubleCost != 0){
                //$('#double_cost_price').val(doubleCost);   
            }else{
                $('#double_cost_price').val(0);   
            }   
        }else{
            //$('#double_cost_price').val(moredoubleCost);
        }
    }
    
    function add_numberElse_1I(){
        var count =$("#city_No").val();
        // var city_slc =$(".city_slc").val();
        // var count = city_slc.length;
        var quad_hotel=0;
        var triple_hotel=0;
        var double_hotel=0;
        var more_quad_hotel=0;
        var more_triple_hotel=0;
        var more_double_hotel=0;
        
        var total_markup = parseFloat($("#total_markup").val());  
        if(isNaN(total_markup)) 
        {
            total_markup=0;
        }
        else
        {
            var total_markup=parseFloat($("#total_markup").val()); 
        }
        
        var total_visa_markup = parseFloat($("#total_visa_markup").val());  
        if(isNaN(total_visa_markup)) 
        {
            total_visa_markup=0;
        }
        else
        {
            var total_visa_markup = parseFloat($("#total_visa_markup").val());
        }
        
        var transportation_markup_total=parseFloat($("#transportation_markup_total").val());
        if(isNaN(transportation_markup_total)) 
        {
            transportation_markup_total=0;
        }
        else
        {
            var transportation_markup_total=parseFloat($("#transportation_markup_total").val());
        }
       
        for(var i=1; i<=10; i++){
            
            var hotel_acc_type=$('#hotel_acc_type_'+i+'').val();
            var hotel_markup=parseFloat($("#hotel_markup_total_"+i+'').val());
            
            if(isNaN(hotel_markup)) 
            { 
                hotel_markup=0;
            }
            else
            {
                // console.log("hotel_markup : " + hotel_markup);
                var hotel_markup = parseFloat($("#hotel_markup_total_"+i+'').val());
            }
            
            if(hotel_acc_type == 'Quad')
            {
                quad_hotel      = quad_hotel + hotel_markup + more_quad_hotel;
                var quad_hotel1 = quad_hotel.toFixed(2);
                $('#quad_grand_total_amount').val(quad_hotel1);
            }
            if(hotel_acc_type == 'Triple')
            {
                triple_hotel        = triple_hotel  +hotel_markup + more_triple_hotel;
                var triple_hotel1   = triple_hotel.toFixed(2);
                $('#triple_grand_total_amount').val(triple_hotel1);
            }
            if(hotel_acc_type == 'Double')
            {
                double_hotel        = double_hotel + hotel_markup  + more_double_hotel;
                var double_hotel1   = double_hotel.toFixed(2);
                $('#double_grand_total_amount').val(double_hotel1);
            }
        }
        
        var sumData = total_markup + total_visa_markup + transportation_markup_total;
        $('#without_acc_sale_price').val(sumData);
        
        
        if(quad_hotel != 0){
           var quadCost = quad_hotel + sumData;
        }else{
            var quadCost = 0;
        }
        
        if(triple_hotel != 0){
            var tripleCost = triple_hotel + sumData;
        }else{
            var tripleCost = 0;
        }
        
        if(double_hotel != 0){
            var doubleCost = double_hotel + sumData;
        }else{
            var doubleCost = 0;
        }
        
        quadCost = quadCost.toFixed(2);
        $('#quad_grand_total_amount').val(quadCost);
        tripleCost = tripleCost.toFixed(2);
        $('#triple_grand_total_amount').val(tripleCost);
        doubleCost = doubleCost.toFixed(2);
        $('#double_grand_total_amount').val(doubleCost);
        
        for(var k=1; k<=20; k++){
            var more_hotel_acc_type = $('#more_hotel_acc_type_'+k+'').val(); 
            var more_hotel_markup   = $('#more_hotel_markup_total_'+k+'').val();
            if(isNaN(more_hotel_markup)) 
            {
                more_hotel_markup=0;
            }
            else
            {
                var more_hotel_markup=parseFloat($("#more_hotel_markup_total_"+k+'').val());
                // $('#more_hotel_invoice_markup_'+k+'').val(more_hotel_markup);
            }
            if(more_hotel_acc_type == 'Quad')
            {
                more_quad_hotel         = more_quad_hotel + more_hotel_markup;
                var more_quad_hotel1    = 0;
                more_quad_hotel1        = more_quad_hotel.toFixed(2);
                $('#quad_grand_total_amount').val(more_quad_hotel1);
            }
            if(more_hotel_acc_type == 'Triple')
            {
                more_triple_hotel       = more_triple_hotel + more_hotel_markup;
                var more_triple_hotel1  = 0;
                more_triple_hotel1      = more_triple_hotel.toFixed(2);
                $('#triple_grand_total_amount').val(more_triple_hotel1);
            }
            if(more_hotel_acc_type == 'Double')
            {
                more_double_hotel       = more_double_hotel +more_hotel_markup;
                var more_double_hotel1  = 0;
                more_double_hotel1      = more_double_hotel.toFixed(2);
                $('#double_grand_total_amount').val(more_double_hotel1);
            }
        }
    
        var morequadCost = sumData + more_quad_hotel;
        morequadCost = morequadCost.toFixed(2);
        
        if(more_quad_hotel == 0){
            if(quadCost != 0){
                $('#quad_grand_total_amount').val(quadCost);   
            }else{
                $('#quad_grand_total_amount').val(0);   
            }   
        }else{
            $('#quad_grand_total_amount').val(morequadCost);   
        }
        
        var moretripleCost = sumData + more_triple_hotel;
        moretripleCost = moretripleCost.toFixed(2);
        
        if(more_triple_hotel == 0){
            if(tripleCost != 0){
                $('#triple_grand_total_amount').val(tripleCost);   
            }else{
                $('#triple_grand_total_amount').val(0);   
            }   
        }else{
            $('#triple_grand_total_amount').val(moretripleCost);   
        }
        
        var moredoubleCost = sumData + more_double_hotel;
        moredoubleCost = moredoubleCost.toFixed(2);
        
        if(more_double_hotel == 0){
            if(doubleCost != 0){
                $('#double_grand_total_amount').val(doubleCost);   
            }else{
                $('#double_grand_total_amount').val(0);   
            }   
        }else{
            $('#double_grand_total_amount').val(moredoubleCost);
        }
    }
        
</script>

<script>
    $(".CC_id_store").change(function (){
        var CC_id_store =  $(this).find('option:selected').attr('attr_id');
        $("#conversion_type_Id").val(CC_id_store);
    });
    
    var user_hotels = {!!json_encode($user_hotels)!!};
    
    // Visa
    $("#currency_conversion1").on('change', function(){
        var value_c = $('option:selected', this).val();
        var attr_conversion_type = $('option:selected', this).attr('attr_conversion_type');
        $("#select_exchange_type").val(attr_conversion_type);
        const usingSplit = value_c.split(' ');
        var value_1 = usingSplit['0'];
        var value_2 = usingSplit['2'];
        
        $('#visa_C_S').empty();
        $('#visa_C_S').html(value_1);
        
        if(value_c != 0){
            $('#invoice_exchage_rate_visa_Div').empty();
            
            var data = `<div class="col-xl-6" style="padding: 10px;">
                            <label for="">Exchange Rate</label>
                            <div class="input-group">
                                <span class="input-group-btn input-group-append">
                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                        
                                    </a>
                                </span>
                                <input type="text" id="exchange_rate_visaI" onkeyup="exchange_rate_visaI_function()" name="exchange_rate_visaI" class="form-control">
                            </div>
                        </div>
                        
                        <div class="col-xl-6" style="padding: 10px;">
                            <label for="">Exchange Visa Fee</label>
                            <div class="input-group">
                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a></span>
                                <input type="text" id="exchange_rate_visa_total_amountI" name="exchange_rate_visa_fee" class="form-control">
                            </div>
                        </div>`;
            $('#invoice_exchage_rate_visa_Div').append(data);
        }else{
            $('#invoice_exchage_rate_visa_Div').empty();
        }
        exchange_currency_funs(value_1,value_2);
        
    });
    
    function exchange_rate_visaI_function(){
        var visa_fee            = $('#visa_fee').val();
        var exchange_rate_visa  = $('#exchange_rate_visaI').val();
        var currency_conversion = $("#select_exchange_type").val();
        if(currency_conversion == 'Divided'){
            var total_visa = parseFloat(visa_fee) / parseFloat(exchange_rate_visa);
        }
        else{
            var total_visa = parseFloat(visa_fee) * parseFloat(exchange_rate_visa);
        }
        var total_visa = total_visa.toFixed(2);
        $('#exchange_rate_visa_total_amountI').val(total_visa);
        $('#visa_price_select').val(total_visa);
    }
    
    var v_ID = 1;
    $('#add_more_visa_Pax').click(function (){
        var data = `<div id="more_visa_pax_div_${v_ID}" class="row">
                        <div class="col-xl-4" style="padding: 10px;">
                            <label for="">Visa Type</label>
                            <select name="more_visa_type[]" id="more_visa_type_${v_ID}" class="form-control more_visa_type_class" onchange="more_visa_type_select(${v_ID})"></select>
                         </div>
                    
                        <div class="col-xl-4" style="padding: 10px;">
                            <label for="">Visa Fee</label>
                            <div class="input-group">
                                <span class="input-group-btn input-group-append">
                                    <a class="btn btn-primary bootstrap-touchspin-up more_visa_C_S">
                                        <?php echo $currency; ?>
                                    </a>
                                </span>
                                <input type="text" id="more_visa_fee_${v_ID}" name="more_visa_fee[]" class="form-control" onchange="more_visa_fee_calculation(${v_ID})">
                            </div>
                        </div>
                        <input type="hidden" id="more_total_visa_markup_value_${v_ID}" name="more_total_visa_markup_value[]" class="form-control">
                        <div class="col-xl-3" style="padding: 10px;">
                            <label for="">Visa Pax</label>
                            <input type="text" id="more_visa_Pax_${v_ID}" name="more_visa_Pax[]" class="form-control">
                        </div>
                        
                        <div class="col-xl-1" style="margin-top: 30px;">
                            <button type="button" onclick="remove_more_visa_pax(${v_ID})" class="btn btn-primary">Remove</button>
                        </div>
                        
                        <div id="more_invoice_exchage_rate_visa_Div_${v_ID}" class="row"></div>
                    </div>`;
        $('#add_more_visa_Pax_Div').append(data);
        
        var data_1 = `<div class="row" id="more_visa_cost_${v_ID}">                        
                            <div class="col-xl-3">
                                <h4>Visa Cost</h4>
                            </div>
                            
                            <input type="hidden" name="acc_hotel_CityName[]">
                            <input type="hidden" name="acc_hotel_HotelName[]">
                            <input type="hidden" name="acc_hotel_CheckIn[]">
                            <input type="hidden" name="acc_hotel_CheckOut[]">
                            <input type="hidden" name="acc_hotel_NoOfNights[]">
                            <input type="hidden" name="acc_hotel_Quantity[]">
                            
                            <div class="col-xl-9">
                                <input type="hidden" id="more_visa_Type_Costing_${v_ID}" name="markup_Type_Costing[]" value="more_visa_Type_Costing" class="form-control">
                            </div>
                            
                            <div class="col-xl-3">
                                <input readonly type="text" id="more_visa_type_select_${v_ID}" name="hotel_name_markup[]" class="form-control">
                            </div>
                            
                            <div class="col-xl-2" style="display:none">
                                <div class="input-group">
                                    <input type="text" id="more_visa_price_per_night_${v_ID}" readonly="" name="more_without_markup_price_single[]" class="form-control">
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value1"></a>
                                    </span>        
                                </div>
                            </div>
                            
                            <div class="col-xl-3">
                                <div class="input-group">
                                    <input readonly type="text" id="more_visa_price_select_${v_ID}" name="without_markup_price[]" class="form-control">
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                           <?php echo $currency; ?>
                                        </a>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="col-xl-2">
                                <select name="markup_type[]" id="more_visa_markup_type_${v_ID}" class="form-control" onchange="more_visa_markup_type_function(${v_ID})">
                                    <option value="">Markup Type</option>
                                    <option value="%">Percentage</option>
                                    <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                </select>
                            </div>
                            
                            <div class="col-xl-2">
                                <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                    <input type="text" class="form-control" id="more_visa_markup_${v_ID}" name="markup[]" onkeyup="more_visa_markup_function(${v_ID})">
                                    <span class="input-group-btn input-group-append">
                                        <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="more_visa_mrk_${v_ID}">%</div></button>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="col-xl-1" style="display:none">
                                <input type="text" id="more_visa_exchage_rate_per_night_${v_ID}" readonly="" name="more_exchage_rate_single[]" class="form-control">    
                            </div>
                            
                            <div class="col-xl-2" style="display:none">
                                <div class="input-group">
                                    <input type="text" id="more_visa_exchage_rate_markup_total_per_night_${v_ID}" readonly="" name="more_markup_total_per_night[]" class="form-control"> 
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="col-xl-2">
                                <div class="input-group">
                                    <input type="text" id="more_total_visa_markup_${v_ID}" name="markup_price[]" class="form-control">
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                           <?php echo $currency; ?>
                                        </a>
                                    </span>
                                </div>
                            </div>
                            
                        </div>`;
        $('#more_visa_cost_div').append(data_1);
        
        $.ajax({
            url: "super_admin/get_other_visa_type_detail", 
            type: "GET",
            dataType: "html",
            success: function(data){
                var data1   = JSON.parse(data);
                var data2   = JSON.parse(data1['visa_type']);
            	$('.more_visa_type_class').empty();
                $.each(data2['visa_type'], function(key, value) {
                    var visa_type_Data = `<option attr="${value.other_visa_type}" value="${value.other_visa_type}"> ${value.other_visa_type}</option>`;
                    $('.more_visa_type_class').append(visa_type_Data);
                });  
            }
        });
        
        var value_c                 = $("#currency_conversion1").val();
        var attr_conversion_type    = $("#currency_conversion1").find('option:selected').attr('attr_conversion_type');
        const usingSplit            = value_c.split(' ');
        var value_1                 = usingSplit['0'];
        var value_2                 = usingSplit['2'];
        $("#select_exchange_type").val(attr_conversion_type);
        
        $('.more_visa_C_S').empty();
        $('.more_visa_C_S').html(value_1);
        
        if(value_c != 0){
            $('#more_invoice_exchage_rate_visa_Div_'+v_ID+'').empty();
            
            var data = `<div class="col-xl-6" style="padding: 10px;">
                            <label for="">Exchange Rate</label>
                            <div class="input-group">
                                <span class="input-group-btn input-group-append">
                                    <a class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                        
                                    </a>
                                </span>
                                <input type="text"  id="more_exchange_rate_visaI_${v_ID}" onkeyup="more_exchange_rate_visaI_function(${v_ID})" name="more_exchange_rate_visa[]" class="form-control">
                            </div>
                        </div>
                        
                        <div class="col-xl-6" style="padding: 10px;">
                            <label for="">Exchange Visa Fee</label>
                            <div class="input-group">
                                <span class="input-group-btn input-group-append"><a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1"></a></span>
                                <input type="text" id="more_exchange_rate_visa_total_amountI_${v_ID}" name="more_exchange_rate_visa_fee[]" class="form-control">
                            </div>
                        </div>`;
            $('#more_invoice_exchage_rate_visa_Div_'+v_ID+'').append(data);
        }else{
            $('#more_invoice_exchage_rate_visa_Div_'+v_ID+'').empty();
        }
        exchange_currency_funs(value_1,value_2);
        
        v_ID = v_ID + 1;
    });
    
    function more_exchange_rate_visaI_function(id){
        var more_visa_fee               =  $('#more_visa_fee_'+id+'').val();
        var more_exchange_rate_visa     =  $('#more_exchange_rate_visaI_'+id+'').val();
        var currency_conversion         = $("#select_exchange_type").val();
        if(currency_conversion == 'Divided'){
            var total_visa = parseFloat(more_visa_fee) / parseFloat(more_exchange_rate_visa);
        }
        else{
            var total_visa = parseFloat(more_visa_fee) * parseFloat(more_exchange_rate_visa);
        }
        var total_visa = total_visa.toFixed(2);
        $('#more_exchange_rate_visa_total_amountI_'+id+'').val(total_visa);
        $('#more_visa_price_select_'+id+'').val(total_visa);    
    }
    
    function remove_more_visa_pax(id){
        $('#more_visa_pax_div_'+id+'').remove();
        $('#more_visa_cost_'+id+'').remove();
    }
    
    function more_visa_type_select(id){
        var more_visa_type = $('#more_visa_type_'+id+'').val();
        $('#more_visa_type_select_'+id+'').val(more_visa_type);
    }
    
    function more_visa_fee_calculation(id){
        var more_visa_fee = $('#more_visa_fee_'+id+'').val();
        $('#more_visa_price_select_'+id+'').val(more_visa_fee);
        $('#more_exchange_rate_visaI_'+id+'').val('');
        $('#more_exchange_rate_visa_total_amountI_'+id+'').val('');
    }
    
    function more_visa_markup_type_function(id){
        var id1 = $('#more_visa_markup_type_'+id+'').find('option:selected').attr('value');
        $('#more_visa_mrk_'+id+'').text(id1);
    }
    
    function more_visa_markup_function(id){
        var id1 = $('#more_visa_markup_type_'+id+'').find('option:selected').attr('value');
        if(id1 == '%')
        {
            var more_visa_markup        =  $('#more_visa_markup_'+id+'').val();
            var more_visa_price_select  =  $('#more_visa_price_select_'+id+'').val();
            var total1                  = (more_visa_price_select * more_visa_markup/100) + parseFloat(more_visa_price_select);
            var total                   = total1.toFixed(2);
            $('#more_total_visa_markup_'+id+'').val(total);
            $('#more_total_visa_markup_value_'+id+'').val(total);
        }
        else
        {
            var more_visa_markup        =  $('#more_visa_markup_'+id+'').val();
            var more_visa_price_select  =  $('#more_visa_price_select_'+id+'').val();
            var total1                  =  parseFloat(more_visa_price_select) +  parseFloat(more_visa_markup);
            var total                   = total1.toFixed(2);
            $('#more_total_visa_markup_'+id+'').val(total);
            $('#more_total_visa_markup_value_'+id+'').val(total);
        }
    }
</script>

@stop