@extends('template/frontend/userdashboard/layout/default')
@section('content')
    


<div class="content-wrapper">
    <section class="content" style="padding: 30px 50px 0px 50px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <!--<div class="page-title-right">-->
                        <!--    <ol class="breadcrumb m-0">-->
                        <!--        <li class="breadcrumb-item"><a href="javascript: void(0);">View Packages</a></li>-->
                        <!--        <li class="breadcrumb-item active">View Packages</li>-->
                        <!--    </ol>-->
                        <!--</div>-->
                        <h4 class="page-title">View Activities</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                </div>
                            <div class="col-sm-7">
                                <div class="text-sm-end">
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <div class="row">
                                <table class="table table-centered w-100 dt-responsive nowrap" id="example1">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>No of Pax</th>
                                            <th>Booking Date</th>
                                            <!--<th>Location</th>-->
                                            <!--<th>Author</th>-->
                                            <th>Booking Status</th>
                                            <th>View Voucher</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($packages as $packages)
                                        
                                        @if($packages->pakage_type == 'activity')
                                            
                                            <tr>
                                                <td>{{$packages->id}}</td>
                                                <td>{{$packages->tour_name}}</td>
                                                <td>
                                                   {{$packages->adults}} 
                                                </td>
                                                <td>{{$packages->created_at}}
                                                    </td>
                                                <!--<td></td>-->
                                                <!--<td></td>                                                -->
                                                
                                               <td><?php
                                               if($packages->status == 1)
                                               {
                                                   echo 'confirm';
                                               }
                                               else
                                               {
                                                   echo 'failed';
                                               }
                                               
                                               ?></td>
                                                <td><a class="btn btn-primary" target="_blank" href="{{URL::to('invoice')}}/{{$packages->invoice_no}}">Voucher</a></td>
                                                
                                            </tr>
                                            @endif
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>           
            </div>
        </div> 
    </section>
</div>





<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    
    $(document).ready(function () {

        //More Tour Details
        $('#booked_tour_span').click(function() {
            const id = $(this).attr('data-id');
            $.ajax({
                url: 'more_Tour_Details/'+id,
                type: 'GET',
                data: {
                    "id": id
                },
                success:function(data) {
                    var a = data;
                    var booked_tour    = a['booked_tour'];
                    $('#booked_tour_span').empty();
                    $('#booked_tour_span').html(booked_tour);
                },
            });
        });

    });

</script>
@endsection