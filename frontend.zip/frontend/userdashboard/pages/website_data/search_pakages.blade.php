@extends('template/frontend/userdashboard/layout/default')
 @section('content')
<div class="container-fluid">

<!-- start page title -->
    <div class="row mt-5">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="header-title">Search Packages</h4>
                    <p class="text-muted font-14">
                        
                    </p>
                    <div class="row justify-content-center search-pack">
                        <div class="col-md-10">
                        <ul class="nav nav-pills bg-nav-pills nav-justified mb-3">
                           
                            <li class="nav-item">
                                <a href="#profile1" data-bs-toggle="tab" aria-expanded="true" class="nav-link rounded-0 active">
                                   
                                   Search Packages
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#settings1" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                                   Search Activites
                                </a>
                            </li>
                        </ul>
                                        
                        <div class="tab-content">
                            
                            <div class="tab-pane show active" id="profile1">
                               <form action="{{ URL::to('search_tour') }}" target="blank" method="post">
                                @csrf
                           
  
                                <div class="row">
                                    <div class="col-md-3">
                                         <label>Destinations</label>
                                        <div class="form-item" style="postion:relative">
                                              <input name="" id="departure_airport_code" class="form-control" autocomplete="off" placeholder="Enter Destination">
                                              <div class="col-xl-1" style="margin-top: 25px;text-align: center; display:none">
                                                 <label for=""></label>
                                                 <span id="Change_Location" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                              </div>
                                              <input type="hidden" name="country" placeholder="Search City" id="country">
                                              <input type="hidden" name="lat" placeholder="Search City" id="lat">
                                              <input type="hidden" name="long" placeholder="Search City" id="long">
                                              <input type="hidden" name="pin" placeholder="Search City" id="pin">
                                              <input type="hidden" name="cityd" placeholder="Search City" id="city">
                                              <input type="hidden" name="country_code" placeholder="Search City" id="country_code">
                                            
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                         <label>Departure From</label>
                                            <div class="form-item">
                                                <i class="awe-icon awe-icon-marker-1"></i>
                                                <input type="text" name="city" class="form-control" id="departure_city" value="Country, city, airport...">
                                                <input type="text" name="booking_person" hidden readonly value="admin">

                                            </div>
                                    </div>
                                    <div class="col-md-3">
                                        <label>Departure Date</label>
                                        <div class="form-item">
                                            <i class="awe-icon awe-icon-calendar"></i>
                                            <input type="date" name="start" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <button class="btn btn-primary" style="margin-top: 1.5rem;" type="submit" name="submit">Search</button>
                                    </div>
                                    
                                </div>

                            </form>
                            </div>
                            <div class="tab-pane" id="settings1">
                               <form action="{{ URL::to('search_activities') }}" target="blank" method="post">
                                @csrf
                           
  
                                <div class="row">
                                    
                                    <div class="col-md-3">
                                         <label>Where To Go?</label>
                                            <div class="form-item">
                                                <input type="text" name="city" class="form-control"  id="pakages_city" placeholder="Country, city, airport..."  >
                                            <div style="postion:absolute">
                                                <ul class="list-group" id="cites_result"></ul>
                                            </div>
                                                <input type="text" name="booking_person" hidden readonly value="admin">

                                            </div>
                                    </div>
                                    <div class="col-md-3">
                                        <label>Departure Date</label>
                                        <div class="form-item">
                                            <i class="awe-icon awe-icon-calendar"></i>
                                            <input type="date" name="start" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <button class="btn btn-primary" style="margin-top: 1.5rem;" type="submit" name="submit">Search</button>
                                    </div>
                                    
                                </div>

                            </form>
                            </div>
                        </div>
                        
                        </div>
                    </div> 
                    <!-- end tab-content-->
                    
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div> <!-- end row-->
                           
<!-- end row -->

</div>
@endsection
@section('scripts')
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY&sensor=false&libraries=places"></script>

<script>
   
  function initAutocomplete() {
        var departure_city = document.getElementById('departure_city');
        var autocomplete = new google.maps.places.Autocomplete(departure_city);
      }
      
       $("#pakages_city").keyup(function(e){
              
              var city_lettar = $("#pakages_city").val();
              
                    $.ajax({
                                type: 'POST',
                                url: '{{URL::to('cites_suggestions')}}',
                                data: {_token: '{{ csrf_token() }}',
                                    'city_lettar': city_lettar,
                                     'table':'Activities'
            
                                },
                                success: function(msg){
                                var city = JSON.parse(msg);
                                console.log(city);
                                var list_data = '';
                               
                                for(var i=0; i<city.length; i++){
                                    
                                    list_data = list_data+`<li class="list-group-item" onClick="selectCity('${city[i]}')" >${city[i]}</li>`;
                                }
                                // 
                                
                                $('#cites_result').html(list_data)
                                //  $('#cites_result').css('display','block')
                                console.log(list_data);
                                
                               
            
                                
                                }
                                
                        
                        });
            });
            
                  
    function selectCity(val) {
        $("#pakages_city").val(val);
        // $('#cites_result').css('display','none')
        // $("#suggesstion-box").hide();
    }
</script>

<script>
   let departure_city_tour,places,places1,return_places,return_places1,places_T,places1_T,return_places_T,return_places1_T ,input, address, city;
   google.maps.event.addDomListener(window, "load", function () {
       var places = new google.maps.places.Autocomplete(
           document.getElementById("departure_airport_code")
       );
       
       var departure_city_tour = new google.maps.places.Autocomplete(
           document.getElementById("departure_city_tour")
       );
       
   google.maps.event.addListener(places, "place_changed", function () {
           var place = places.getPlace();
          console.log(place);
           var address = place.formatted_address;
           var latitude = place.geometry.location.lat();
           var longitude = place.geometry.location.lng();
           var latlng = new google.maps.LatLng(latitude, longitude);
           var geocoder = (geocoder = new google.maps.Geocoder());
           geocoder.geocode({ latLng: latlng }, function (results, status) {
               if (status == google.maps.GeocoderStatus.OK) {
                   if (results[0]) {
                       var address = results[0].formatted_address;
                       var pin =
                       results[0].address_components[
                   results[0].address_components.length - 1
                 ].short_name;
                  console.log('pin'+pin);
                       var country =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].long_name;
                       var state =
                         results[0].address_components[
                           results[0].address_components.length - 3
                         ].long_name;
                         console.log('state'+state);
                       var city =
                         results[0].address_components[
                           results[0].address_components.length - 4
                         ].long_name;
                       var country_code =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].short_name;
                       $('#country').val(country);
                       $('#lat').val(latitude);
                       $('#long').val(longitude);
                       $('#pin').val(pin);
                       $('#city').val(city);
                       $('#country_code').val(country_code);
                   }
               }
           });
       });
       
        google.maps.event.addListener(departure_city_tour, "place_changed", function () {
           var place = places.getPlace();
           // console.log(place);
           var address = place.formatted_address;
           var latitude = place.geometry.location.lat();
           var longitude = place.geometry.location.lng();
           var latlng = new google.maps.LatLng(latitude, longitude);
           var geocoder = (geocoder = new google.maps.Geocoder());
           geocoder.geocode({ latLng: latlng }, function (results, status) {
               if (status == google.maps.GeocoderStatus.OK) {
                   if (results[0]) {
                       var address = results[0].formatted_address;
                       var pin =
                       results[0].address_components[
                   results[0].address_components.length - 1
                 ].long_name;
                       var country =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].long_name;
                       var state =
                         results[0].address_components[
                           results[0].address_components.length - 3
                         ].long_name;
                       var city =
                         results[0].address_components[
                           results[0].address_components.length - 4
                         ].long_name;
                       var country_code =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].short_name;
                       $('#country').val(country);
                       $('#lat').val(latitude);
                       $('#long').val(longitude);
                       $('#pin').val(pin);
                       $('#city').val(city);
                       $('#country_code').val(country_code);
                   }
               }
           });
       });
   });
   
    google.maps.event.addDomListener(window, "load", function () {
       var places = new google.maps.places.Autocomplete(
           document.getElementById("get_nationality")
       );
   google.maps.event.addListener(places, "place_changed", function () {
           var place = places.getPlace();
           // console.log(place);
           var address = place.formatted_address;
           var latitude = place.geometry.location.lat();
           var longitude = place.geometry.location.lng();
           var latlng = new google.maps.LatLng(latitude, longitude);
           var geocoder = (geocoder = new google.maps.Geocoder());
           geocoder.geocode({ latLng: latlng }, function (results, status) {
               if (status == google.maps.GeocoderStatus.OK) {
                   if (results[0]) {
                       var address = results[0].formatted_address;
                       var pin =
                       results[0].address_components[
                   results[0].address_components.length - 1
                 ].long_name;
                       var country =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].long_name;
                       var state =
                         results[0].address_components[
                           results[0].address_components.length - 3
                         ].long_name;
                       var city =
                         results[0].address_components[
                           results[0].address_components.length - 4
                         ].long_name;
                       var country_code =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].short_name;
                       $('#country_n').val(country);
                       $('#lat_n').val(latitude);
                       $('#long_n').val(longitude);
                       $('#pin_n').val(pin);
                       $('#city_n').val(city);
                       $('#country_code_n').val(country_code);
                   }
               }
           });
       });
   });
   
</script>
@stop
