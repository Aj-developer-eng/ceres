@extends('template/frontend/userdashboard/layout/default')
 @section('content')
<div class="container-fluid">

@php 
    $sliderData = json_decode($response_data->data->slider_images);
    $imagesArr = $sliderData[1];
    $captionArr = $sliderData[0];


@endphp
<!-- start page title -->
    <div class="row mt-5">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="header-title">Add Update Content</h4>
                    <p class="text-muted font-14">
                        
                    </p>
                <form action="{{ url('images_submit') }}" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
                   @csrf
                    <div class="row justify-content-center">
                        <div class="col-md-10">
                            <div class="row">
                                @php 
                                    $x = 0;
                                @endphp
                                <div class="col-md-6"><img src="{{ asset('public/images/sliderImages')}}/{{ $imagesArr[$id] }}" style="height:150px;" alt=""></div>
                                <div class="col-md-6">
                                <input type="text" name="sliderCapt" class="form-control" id="validationCustom02" placeholder="Last name" value="{{ $captionArr[$id] }}">
                                <input type="text" name="indexNo" hidden class="form-control" id="validationCustom02" placeholder="Last name" value="{{ $id }}">
                                    <label class="form-label"  for="validationCustom02">Slider Image</label>
                                    <input type="file" name="sliderImage" class="form-control" id="validationCustom02">
                                </div>

                                @php $x++ 
                            
                                @endphp
                            
                            </div>
                      
                        </div>
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div> 
                </form>
                    <!-- end tab-content-->
                    
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div> <!-- end row-->
                           
<!-- end row -->

</div>
@endsection
@section('scripts')
<script>
   
</script>
@stop
