
application/x-httpd-php view_activities_new.blade.php ( ASCII HTML document text )
@extends('template/frontend/userdashboard/layout/default')
@section('content')
    


<div class="content-wrapper">
    <section class="content" style="padding: 30px 50px 0px 50px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Activity</a></li>
                                <li class="breadcrumb-item active">View Activity</li>
                            </ol>
                        </div>
                        <h4 class="page-title">View Pages</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                </div>
                            <div class="col-sm-7">
                                <div class="text-sm-end">
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <div class="row">
                                <table class="table table-centered w-100 dt-responsive nowrap" id="example1">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ID</th>
                                            <th>Page Name</th>
                                            <th>Page Title</th>
                                            <th>Page Link</th>
                                            <th style="width: 85px;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $x = 1;
                                            foreach($pages as $page_res){
                                                ?>
                                        <tr>
                                            <td>{{ $x++ }}</td>
                                            <td>{{ $page_res->pagename }}</td>
                                            <td>{{ $page_res->pageTitle }}</td>
                                            <td>{{ $page_res->page_url }}</td>
                                            <td style="width: 85px;">
                                                <a href="{{ URL::to('update_pages/'.$page_res->id.'') }}" class="btn btn-info"><i class="mdi mdi-account-edit me-1"></i></a>
                                            </td>
                                        </tr>
                                                <?php
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>           
            </div>
        </div> 
    </section>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    


</script>
@endsection