@extends('template/frontend/userdashboard/layout/default')
 @section('content')
<div class="container-fluid">

<!-- start page title -->
    <div class="row mt-5">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="header-title">Add Update Content</h4>
                    @if (session('success'))
                    <div class="alert alert-success alert-dismissible bg-success text-white border-0 fade show" role="alert">
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                        <strong>Success - </strong> {{ session('success') }}
                    </div>
                    @endif

                    @if (session('error'))
                    <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                        <strong></strong> {{ session('error') }}
                    </div>
                    @endif
                    <p class="text-muted font-14">
                        
                    </p>
                    <div class="row justify-content-center">
                        <div class="col-md-10">
                        <ul class="nav nav-pills bg-nav-pills nav-justified mb-3">
                           
                           
                            <li class="nav-item">
                                <a href="#settings1" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0 active">
                                    <i class="mdi mdi-settings-outline d-md-none d-block"></i>
                                    <span class="d-none d-md-block">Home page Content</span>
                                </a>
                            </li>
                        </ul>
                        <form action="{{ url('/webcontent_update') }}" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
                                            @csrf
                        <div class="tab-content">
                            
                            
                            <div class="tab-pane show active" id="settings1">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label class="form-label"  for="validationCustom02">Page Title</label>
                                            <!-- <input type="text" class="form-control"  name="page_title">
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div> -->
                                            <input id="pageTitle" type="text" class="form-control @error('pageTitle') is-invalid @enderror" name="pageTitle" value="{{  $response_data->data->page_titile }}" required autocomplete="pageTitle" autofocus>
                                                @error('pageTitle')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label class="form-label"  for="validationCustom02">Home Page Content1</label>
                                            <textarea name="content1" id="" class="form-control" cols="30" rows="4">{{  $response_data->data->page_content1 }}</textarea>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label class="form-label"  for="validationCustom02">Home Page Content2</label>
                                            <textarea name="content2" id="" class="form-control" cols="30" rows="4">{{  $response_data->data->page_content2 }}</textarea>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label class="form-label"  for="validationCustom02">Home Page Content3</label>
                                            <textarea name="content3" id="" class="form-control" cols="30" rows="4">{{  $response_data->data->page_content3 }}</textarea>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label class="form-label"  for="validationCustom02">Home Page Content4</label>
                                            <textarea name="content4" id="" class="form-control" cols="30" rows="4">{{  $response_data->data->page_content4 }}</textarea>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2 offset-md-10">
                            <button class="btn btn-primary" type="submit">Submit form</button>

                        </div>
                        </form>
                        </div>
                    </div> 
                    <!-- end tab-content-->
                    
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div> <!-- end row-->
                           
<!-- end row -->

</div>
@endsection
@section('scripts')
<script>
   
    var imgDiv = 1;
    function addMoreSliderImage(){
    var data = `<div class="row" id="slider_row${imgDiv}">
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label"  for="validationCustom02">Slider Image</label>
                            <input type="file" name="sliderImage[]" class="form-control" id="validationCustom02" placeholder="Last name" value="" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="mb-3">
                            <label class="form-label"  for="validationCustom02">Caption</label>
                            <input type="text" name="sliderCapt[]" class="form-control" id="validationCustom02" placeholder="Last name" value="" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                    </div>
                    <div class="col-md-1">
                        <div class="mt-3">
                            <button type="button" onclick="removeSliderImage(${imgDiv})"  class="btn btn-danger">X</button>
                        </div>
                    </div>
                </div>`;
                $('#sliderDiv').append(data);
                imgDiv++
        console.log('Slider Call now');
    }

    function removeSliderImage(id){
        $('#slider_row'+id+'').remove();
        console.log('id is '+id);
    }
</script>
@stop
