@extends('template/frontend/userdashboard/layout/default')
 @section('content')
<div class="container-fluid">

<!-- start page title -->
    <div class="row mt-5">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="header-title">Add Page Content</h4>
                    <p class="text-muted font-14">
                        
                    </p>
                    <div class="row justify-content-center">
                        <div class="col-md-10">
                            <form action="{{ URL::to('add_pages_submit') }}" method="post">
                                @csrf
                                <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label"  for="validationCustom02">Page Url</label>
                                        <!-- <input type="text" class="form-control"  name="page_title">
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div> -->
                                        <input id="pageTitle" type="text" class="form-control @error('pageTitle') is-invalid @enderror" name="page_url" value="{{ old('pageTitle') }}" required autocomplete="pageTitle" autofocus>
                                           
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label"  for="validationCustom02">Focus keyword</label>
                                        
                                        <input id="pageTitle" type="text" class="form-control @error('pageTitle') is-invalid @enderror" name="focus_keyword" value="{{ old('pageTitle') }}" required autocomplete="pageTitle" autofocus>
                                           
                                    </div>
                                   
                                    <div class="mb-3">
                                        <label class="form-label"  for="validationCustom02">Page Name</label>
                                        <!-- <input type="text" class="form-control"  name="page_title">
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div> -->
                                        <input id="pageTitle" type="text" class="form-control @error('pageTitle') is-invalid @enderror" name="pagename" value="{{ old('pageTitle') }}" required autocomplete="pageTitle" autofocus>
                                           
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label"  for="validationCustom02">Page Title</label>
                                        <!-- <input type="text" class="form-control"  name="page_title">
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div> -->
                                        <input id="pageTitle" type="text" class="form-control @error('pageTitle') is-invalid @enderror" name="pageTitle" value="{{ old('pageTitle') }}" required autocomplete="pageTitle" autofocus>
                                           
                                    </div>
                                       <div class="mb-3">
                                        <label class="form-label"  for="validationCustom02">Meta Title</label>
                                        <!-- <input type="text" class="form-control"  name="page_title">
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div> -->
                                        <input id="pageTitle" type="text" class="form-control @error('pageTitle') is-invalid @enderror" name="metaTitle" value="{{ old('pageTitle') }}" required autocomplete="pageTitle" autofocus>
                                           
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label"  for="validationCustom02">Meta Description</label>
                                        <textarea name="meta_description" id="" class="form-control" cols="30" rows="4"></textarea>
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-10">
                                    <div class="mb-3">
                                        <label class="form-label"  for="validationCustom02">Meta Tags</label>
                                      <select class="select2 form-control select2-multiple" id="meta_tags" name="meta_tags[]" data-toggle="select2" multiple="multiple" data-placeholder="Choose ...">
                                            <option value="Chose One">Chose One</option>
                                        
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="mb-3">
                                        <button class="btn btn-info" type="button" data-bs-toggle="modal" data-bs-target="#add_meta_tags-modal" style="margin-top:30px;">Add New</button>
                                    </div>
                                </div>
                                  <div class="col-md-12">
                                    <div class="mb-3">
                                        <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                                    </div>
                                </div>
                            </div>
                            </form>
                                    

                        </div>
                    </div> 
                    <!-- end tab-content-->
                    
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div> <!-- end row-->
    
    <div id="add_meta_tags-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="standard-modalLabel">Add New Meta Tag</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form action="https://client.synchronousdigital.com/super_admin/submit_attributes_activities" id="facilities_form" method="post" enctype="multipart/form-data">
                @csrf
                    <div class="mb-3">
                        <label for="username" class="form-label">Meta Tag</label>
                        <input class="form-control" type="title" id="add_meta_tags_title" name="title" placeholder="">
                    </div>
                    <div class="mb-3 text-right">
                        <button class="btn btn-primary" id="add_meta_tags" onclick="add_meta_tags_fun()" type="button">Submit</button>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
                           
<!-- end row -->

</div>
@endsection
@section('scripts')
<script>

    
    function add_meta_tags_fun(){
        var meta_title = $('#add_meta_tags_title').val();
         $.ajax({
          type:'POST',
          url: `/super_admin/submit_meta_tags`,
           data: {
                _token: '{{ csrf_token() }}', 
                 add_meta_tags_title: meta_title, 
           },
           success: (response) => {
               console.log(response)
             if (response) {
                 
              $('#add_meta_tags-modal').modal('hide');
              alert('Tag has been added successfully');
               
             }
           },
           error: function(response){
              console.log(response);
                $('#image-input-error').text(response.responseJSON.errors.file);
           }
       });
    }
    
     function fetch_meta_tags(){
      $.ajax({
          type:'GET',
          url: `/super_admin/get_meta_tags`,
          data:{
          },
          contentType: false,
          processData: false,
          success: (response) => {
            //   console.log(response);
             $('#meta_tags').html(response)
          }
      });
  }
  
  fetch_meta_tags();
</script>
@stop
