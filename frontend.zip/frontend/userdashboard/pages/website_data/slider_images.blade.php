@extends('template/frontend/userdashboard/layout/default')
 @section('content')
@php 
    $sliderData = json_decode($response_data->data->slider_images);
    $imagesArr = $sliderData[1];
    $captionArr = $sliderData[0];


@endphp

<div class="container-fluid">

<!-- start page title -->
    <div class="row mt-5">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                @if (session('success'))
                <div class="alert alert-success alert-dismissible bg-success text-white border-0 fade show" role="alert">
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                    <strong>Success - </strong> {{ session('success') }}
                </div>
                @endif
                    <div class="row mb-4">
                        <div class="col-md-10">
                            <h4 class="header-title">Slider Images</h4>
                        </div>
                        <div class="col-md-2">
                        <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#bs-example-modal-lg">Add More</button>
                        </div>
                    </div>

                   
                   
                    <table id="scroll-horizontal-datatable" class="table w-100 nowrap">
                        <thead>
                            <tr>
                                <th>Sr</th>
                                <th>Image</th>
                                <th>Caption</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        @php 
                                        $x = 0;
                                    @endphp
                                   @foreach($imagesArr as $img_res)
                            <tr>
                                <td>{{ $x + 1 }}</td>
                                <td><img src="{{ asset('public/images/sliderImages')}}/{{ $img_res }}" style="height:100px; width:auto" alt=""></td>
                                <td>{{ $captionArr[$x] }}</td>
                                <td>
                                    <a href="{{ url('update_img/'.$x.'') }}" class="btn btn-primary btn-sm">Edit</a>
                                    <button onclick="delete_slider({{ $x }})" class="btn btn-danger btn-sm">Delete</button>
                                </td>
                               
                            </tr>

                            @php $x++ 
                                
                                @endphp
                            
                                @endforeach
                            
                        </tbody>
                    </table>
                   
                    <!-- end tab-content-->
                    
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div> <!-- end row-->
                           
<!-- end row -->

</div>

 <!-- Large modal -->
 <div class="modal fade" id="bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">Add More Images</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
            <form action="{{ url('/add_more_sliders') }}" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
                                            @csrf
                <div id="sliderDiv">
                    <div class="row" id="slider_img_row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label"  for="validationCustom02">Slider Image</label>
                                <input type="file" name="sliderImage[]" class="form-control" id="validationCustom02" placeholder="Last name" value="" required>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>

                        <div class="col-md-8">
                            <div class="mb-3">
                                <label class="form-label"  for="validationCustom02">Caption</label>
                                <input type="text" name="sliderCapt[]" class="form-control" id="validationCustom02" placeholder="Last name" value="" required>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
                <div class="row">
                    <div class="col-md-12">
                        <button type="button" class="btn btn-success" onclick="addMoreSliderImage()">Add More</button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2 offset-md-10 text-right">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
@endsection
@section('scripts')
<script src="{{ asset('public/adminPanel/assets/js/vendor/jquery.dataTables.min.js') }}"></script>
        <script src="{{ asset('public/adminPanel/assets/js/vendor/dataTables.bootstrap5.js') }}"></script>
<script>
 function delete_slider(index){
        console.log('Function is call now '+index);
        if(window.confirm("Are You Sure to Delete This")){
            window.location = "delete_img/"+index+"";
        }
        
    }
    

    var imgDiv = 1;
    function addMoreSliderImage(){
    var data = `<div class="row" id="slider_row${imgDiv}">
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label"  for="validationCustom02">Slider Image</label>
                            <input type="file" name="sliderImage[]" class="form-control" id="validationCustom02" placeholder="Last name" value="" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="mb-3">
                            <label class="form-label"  for="validationCustom02">Caption</label>
                            <input type="text" name="sliderCapt[]" class="form-control" id="validationCustom02" placeholder="Last name" value="" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                    </div>
                    <div class="col-md-1">
                        <div class="mt-3">
                            <button type="button" onclick="removeSliderImage(${imgDiv})"  class="btn btn-danger">X</button>
                        </div>
                    </div>
                </div>`;
                $('#sliderDiv').append(data);
                imgDiv++
        console.log('Slider Call now');
    }

    function removeSliderImage(id){
        $('#slider_row'+id+'').remove();
        console.log('id is '+id);
    }
</script>
@stop
