<?php

 //$get_data_token=$get_data_hotel_token;
 
 
 
 

?>


@extends('template/frontend/userdashboard/layout/default')
 @section('content')
 
 
<div class="modal fade" id="bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">View Payment Details</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
           <div style="width: 400px;margin-top: 20px; display:none;" id='msg' class="alert alert-primary alert-dismissible bg-primary text-white border-0 fade show" role="alert">
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
    <strong></strong>
</div>
           
            <div class="modal-body">
               <form class="row form-group" id="form">
                  
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Invoice No</label>
                        <input type="text" id="invoice_no" class="form-control" readonly value="">
                    </div>
                 </div>
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Check In</label>
                        <input type="text" id="checkin" class="form-control" readonly value="">
                    </div>
                 </div>  
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Check Out</label>
                        <input type="text" id="checkout" class="form-control" readonly value="">
                    </div>
                 </div>  
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Rooms</label>
                        <input type="text" id="rooms" class="form-control" readonly value="">
                    </div>
                 </div>  
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Adults</label>
                        <input type="text" id="adults" class="form-control" readonly value="">
                    </div>
                 </div>  
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Children</label>
                        <input type="text" id="children" class="form-control" readonly value="">
                    </div>
                 </div>
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Customer Name</label>
                        <input type="text" id="customer_name" class="form-control" readonly value="">
                    </div>
                 </div>
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Customer Email</label>
                        <input type="email" id="customer_email" class="form-control" readonly value="">
                    </div>
                 </div>
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Hotel Name</label>
                        <input type="text" id="hotel_name" class="form-control" readonly value="">
                    </div>
                 </div>
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Room Name</label>
                        <input type="text" id="room_name" class="form-control" readonly value="">
                    </div>
                 </div>
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Room Price</label>
                        <input type="text" id="room_price" class="form-control" readonly value="">
                    </div>
                 </div>
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Total Price</label>
                        <input type="text" id="total_amount" class="form-control" readonly value="">
                    </div>
                 </div>
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Recieved Amount</label>
                        <input type="text" id="recieved_amount" class="form-control"  value="">
                    </div>
                 </div>
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Remaining Amount</label>
                        <input type="text" id="remaining_amount" class="form-control" readonly value="">
                    </div>
                 </div>
                 <div class="col-md-4">
                     <div class="mb-3">
                        <label for="simpleinput" class="form-label">Amount Paid</label>
                        <input type="text" id="amount_paid" class="form-control" readonly value="">
                    </div>
                 </div>

                    <div class="mb-3">
                        <button  style="float: right;" id="submitpaymentform" class="btn btn-primary">submit</button>
                    </div>
                   
               </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
 
 

     
   


    
    <div class="mt-5" id="Ratehawk">
        <div class="row">
            
            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="header-title">RateHawk Recevied Booking</h4>
                                        <p class="text-muted font-14">
                                            
                                        </p>

                                        
                                       
                                                <table id="example_4" class="table dt-responsive nowrap w-100">
                                                    <thead>
                                                        <tr>
                                                            <th>id</th>
                                                            <th>Invoice No</th>
                                                            <th>Provider</th>
                                                            <th>Hotel Name</th>
                                                             <th>Room Details</th>
                                                            
                                                            <th>Customer Name</th>
                                                            <th>Client Name</th>
                                                            <th>Total Amount</th>
                                                            <th>Payment Status</th>
                                                             <th>Payment Details</th>
                                                            <th>Booking Status</th>
                                                            <th>Booking Cancell</th>
                                                        </tr>
                                                    </thead>
                                                
                                                
                                                    <tbody>
                                                        @foreach($ratehawk_hotel_booking as $ratehawk_hotel_booking)
                                                        
                                                        <?php
                                                        
                                                        $customer_subcriptions=$get_data_customer_subcriptions;
                                                        $name=$customer_subcriptions->name;
                                                        $lname=$customer_subcriptions->lname;
                                                        $client_name=$name . $lname;
                                                       
                                                        $curl = curl_init();
                                                        $data = array('search_id' => $ratehawk_hotel_booking->search_id);
                                                        curl_setopt_array($curl, array(
                                                            CURLOPT_URL => 'https://admin.synchronousdigital.com/api/get_hotel_payment_details_by_id',
                                                            CURLOPT_RETURNTRANSFER => true,
                                                            CURLOPT_ENCODING => '',
                                                            CURLOPT_MAXREDIRS => 10,
                                                            CURLOPT_TIMEOUT => 0,
                                                            CURLOPT_FOLLOWLOCATION => true,
                                                            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                                            CURLOPT_CUSTOMREQUEST => 'POST',
                                                            CURLOPT_POSTFIELDS =>  $data,
                                                            CURLOPT_HTTPHEADER => array(
                                                             'Cookie: laravel_session=gnq21xtzzbBtgOgSa0iVWPIX9vSDzHcKrUozAnSL'
                                                            ),
                                                        ));
                                                
                                                        $response_pament = curl_exec($curl);
                                                   //echo $response;
                                                        curl_close($curl);
                                                        $hotel_payment_details_total=json_decode($response_pament);
                                                        $hotel_payment_details_total=$hotel_payment_details_total->hotel_payment_details ?? '';
                                                        //print_r($hotel_payment_details_total);
                                                        ?>
                                                        
                                                        <?php
                                                        if($ratehawk_hotel_booking->provider == 'ratehawk')
                                                        {
                                                           
                                                        
                                                        
                                                        ?>
                                                        
                                                        <tr>
                                                            <td>{{$ratehawk_hotel_booking->id}}</td>
                                                            <td><?php print_r($ratehawk_hotel_booking->search_id); ?></td>
                                                            <td>{{$ratehawk_hotel_booking->provider}}</td>
                                                            
                                                            <?php
                                                            
                                                            $ratehawk_details_rs1=$ratehawk_hotel_booking->ratehawk_details_rs1;
                                                            $ratehawk_details_rs1=json_decode($ratehawk_details_rs1);
                                                            
                                                            $ratehawk_details_rs=$ratehawk_hotel_booking->ratehawk_details_rs;
                                                            $ratehawk_details_rs=json_decode($ratehawk_details_rs);
                                                            
                                                            $ratehawk_selection_rq_arr=$ratehawk_hotel_booking->ratehawk_selection_rq_arr;
                                                            $ratehawk_selection_rq_arr=json_decode($ratehawk_selection_rq_arr);
                                                            //print_r($ratehawk_selection_rq_arr);die();
                                                            
                                                            
                                                            ?>
                                                            
                                                            <td>
                                                                <?php
                                                                
                                                                if(isset($ratehawk_details_rs))
                                                                {
                                                                   echo $ratehawk_details_rs->name ?? ''; 
                                                                }
                                                                
                                                                
                                                                ?>
                                                                
                                                                
                                                                
                                                            </td>
                                                            <td>
                                                                
                                                               <?php
                                                                
                                                                  $grand_total=0;
                                                                   if(isset($ratehawk_details_rs1))
                                                                   {
                                                                        foreach($ratehawk_selection_rq_arr as $ratehawk_selection_rq_arr)
                                                                    {
                                                                foreach($ratehawk_details_rs1->hotels[0]->rates as $rates)
                                                                {
                                                                   
                                                                        if($ratehawk_selection_rq_arr->book_hash == $rates->book_hash)
                                                                        {
                                                                    echo 'RoomName:  ' . ($rates->room_name ?? '');
                                                                    
                                                                    $RoomName=$rates->room_name ?? '';
                                                               
                                                                    echo '</br>';
                                                                    echo 'boardName: ' . ($rates->meal ?? '');
                                                                     echo '</br>';
                                                                    
                                                                    echo 'RoomPrice: '. ($rates->payment_options->payment_types[0]->currency_code . $rates->payment_options->payment_types[0]->amount ?? '');  
                                                                $grand_total=$grand_total + $rates->payment_options->payment_types[0]->amount;
                                                                    }
                                                                }
                                                                    
                                                                }
                                                                   } 
                                                                   
                                                               
                                                                ?> 
                                                                
                                                            </td>
                                                           
                                                            <td><?php 
                                                             $lead_passenger_details=$ratehawk_hotel_booking->lead_passenger_details;
                                                            $lead_passenger_details=json_decode($lead_passenger_details);
                                                            if(isset($lead_passenger_details))
                                                            {
                                                              echo $lead_passenger_details->lead_first_name. ' ' . $lead_passenger_details->lead_last_name;  
                                                            }
                                                            ?></td>
                                                            <td><?php print_r($client_name); ?></td>
                                                            <td>

                                                            </td>
                                                           <td>
                                                                
        <?php
        
        if($hotel_payment_details_total == 0)
       {
        ?>
        <a class="btn btn-info" href="javascript:;">UnPaid</a>
         <?php
                                                                    
         }
        ?>
        <?php
        
        if($hotel_payment_details_total < $grand_total && $hotel_payment_details_total > 0)
       {
        ?>
        <a class="btn btn-secondary" href="javascript:;">Partial Paid</a>
          <?php
          }
           ?>
        <?php
         if($hotel_payment_details_total == $grand_total)
         {
          ?>
         <a class="btn btn-success" href="javascript:;">Paid</a>
          <?php
         }
       
        
         ?>
  
                                                            </td>
                                                             <td>
                                                                <?php
                                                                
                                                                   
                                                                  if(isset($ratehawk_hotel_booking->lead_passenger_details))
                                                                {
                                                                $lead_passenger_details=$ratehawk_hotel_booking->lead_passenger_details ?? '';
                                                                $lead_passenger_details=json_decode($lead_passenger_details);
                                                                $CustomerName=$lead_passenger_details->lead_first_name. ' ' . $lead_passenger_details->lead_last_name;
                                                                $Customeremail=$lead_passenger_details->lead_email;
                                                                }
                                                                  
                                                                  if(isset($ratehawk_details_rs))
                                                                {
                                                                   $hotelName=$ratehawk_details_rs->name ?? ''; 
                                                                } 
                                                           
                                                                  
                                                                   
                                                                   
                                                              
                                                                    
                                                                    
                                                                       
                                                                   
                                                                ?>
                                                                <?php
                                                               
                                                                 if($hotel_payment_details_total == $grand_total)
                                                                    {
                                                                    ?>
                                                                     <a class="btn btn-success" href="javascript:;">Payment Paid</a>   
                                                                        
                                                                    <?php
                                                                    }
                                                                
                                                                    else
                                                                    {
                                                                ?>
                                                                
                                                                 <a class="btn btn-success" href="javascript:;" onClick="paymentFunction({{$ratehawk_hotel_booking->search_id}})" 
                                                                 atr_id="{{$ratehawk_hotel_booking->search_id  ?? ''}}"
                                                                 atr_provider="{{$ratehawk_hotel_booking->provider  ?? ''}}"
                                                                 atr_check_in="{{$ratehawk_hotel_booking->check_in  ?? ''}}"
                                                                 atr_check_out="{{$ratehawk_hotel_booking->check_out  ?? ''}}"
                                                                 atr_rooms="{{$ratehawk_hotel_booking->rooms  ?? ''}}"
                                                                 atr_total_passenger="{{$ratehawk_hotel_booking->total_passenger  ?? ''}}"
                                                                  atr_child="{{$ratehawk_hotel_booking->child  ?? ''}}"
                                                                  atr_CustomerName="{{$CustomerName  ?? ''}}"
                                                                  atr_Customeremail="{{$Customeremail  ?? ''}}"
                                                                  atr_hotel_name="{{$hotelName ?? ''}}"
                                                                   atr_RoomName="{{$RoomName ?? ''}}"
                                                                   atr_RoomPrice="{{$grand_total ?? ''}}"
                                                                   atr_TotalPrice="{{$grand_total ?? ''}}"
                                                                   
                                                                    atr_remaining_amount="{{$ratehawk_hotel_booking->remaining_amount ?? ''}}"
                                                                     atr_paid_amount="{{$hotel_payment_details_total ?? ''}}"
                                                                 id="click_payment_popup_{{$ratehawk_hotel_booking->search_id}}"
                                                                 data-bs-toggle="modal" data-bs-target="#bs-example-modal-lg">Payment Details</a> 
                                                                 <?php
                                                                    }
                                                                
                                                                 ?>
                                                            </td>
                                                             
                                                            <td>
                                                                <?php
                                                                
                                                                if($ratehawk_hotel_booking->booking_status == 'Confirmed')
                                                                {
                                                                ?>
                                                                <a class="btn btn-success" href="javascript:;">Confirmed</a>
                                                                <?php
                                                                }
                                                                else if($ratehawk_hotel_booking->booking_status == 'Cancelled')
                                                                {
                                                                ?>
                                                                <a class="btn btn-success" href="javascript:;">Cancelled</a>
                                                                <?php
                                                                }
                                                                else
                                                                {
                                                                ?>
                                                                <a class="btn btn-info" href="{{URL::to('super_admin/booking/')}}/{{$ratehawk_hotel_booking->search_id}}" target="_blanck">Book Now</a>
                                                                <?php
                                                                }
                                                                ?>
                                                               
                                                            </td>
                                                        
                                                        <td ><a class="btn btn-info" href="https://alhijaztours.net/voucher/{{$ratehawk_hotel_booking->search_id}}/{{$ratehawk_hotel_booking->provider}}" target="_blank">Booking Cancell</a></td>
                                                        
                                                        </tr>
                                                        <?php
                                                        }
                                                        ?>
                                                       
                                                    
                                                        @endforeach
                                                    </tbody>
                                                </table>                                           
                                            
                                        
                                    </div> <!-- end card body-->
                                </div> <!-- end card -->
                            </div><!-- end col-->
        </div>
    </div>

     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     

                        
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
            <script>
   $(document).ready(function () {
    $('#example').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        // scrollX: true,
    });
    $('#example1').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        // scrollX: true,
    });
    $('#example_1').DataTable({
        scrollX: true,
        scrollY: true,
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        
    });
     $('#example_2').DataTable({
        scrollX: true,
        scrollY: true,
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        
    });
     $('#example_3').DataTable({
        scrollX: true,
        // scrollY: true,
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        
    });
     $('#example_4').DataTable({
        scrollX: true,
        scrollY: true,
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        
    });
    $('#example2').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        // scrollX: true,
    });
    $('#example3').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        // scrollX: true,
    });
    $('#example4').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        // scrollX: true,
    });
}); 
</script>
      <script>
     
      function paymentFunction(searchedid)
      {
          const searched_id = $('#click_payment_popup_'+searchedid+'').attr('atr_id');
          $('#invoice_no').val(searched_id);
          const provider = $('#click_payment_popup_'+searchedid+'').attr('atr_provider');
          
           const check_in = $('#click_payment_popup_'+searchedid+'').attr('atr_check_in');
           $('#checkin').val(check_in);
            const check_out = $('#click_payment_popup_'+searchedid+'').attr('atr_check_out');
            $('#checkout').val(check_out);
             const rooms = $('#click_payment_popup_'+searchedid+'').attr('atr_rooms');
             $('#rooms').val(rooms);
              const total_passenger = $('#click_payment_popup_'+searchedid+'').attr('atr_total_passenger');
              $('#adults').val(total_passenger);
               const child = $('#click_payment_popup_'+searchedid+'').attr('atr_child');
               $('#children').val(child);
                const CustomerName = $('#click_payment_popup_'+searchedid+'').attr('atr_CustomerName');
                $('#customer_name').val(CustomerName);
                 const Customeremail = $('#click_payment_popup_'+searchedid+'').attr('atr_Customeremail');
                 $('#customer_email').val(Customeremail);
                 const hotel_name = $('#click_payment_popup_'+searchedid+'').attr('atr_hotel_name');
                 $('#hotel_name').val(hotel_name);
                 
                 const room_name = $('#click_payment_popup_'+searchedid+'').attr('atr_RoomName');
                 $('#room_name').val(room_name);
                 
                 const room_price = $('#click_payment_popup_'+searchedid+'').attr('atr_RoomPrice');
                 $('#room_price').val(room_price);
                 
                 const total_price = $('#click_payment_popup_'+searchedid+'').attr('atr_TotalPrice');
                 $('#total_amount').val(total_price);
                 
                
                 
                 const amount_paid = $('#click_payment_popup_'+searchedid+'').attr('atr_paid_amount');
                 console.log(amount_paid);
                 $('#amount_paid').val(amount_paid);
                 
                  const remaining_amount = parseFloat(total_price) - parseFloat(amount_paid);
                  
                  //  const remaining_amount = $('#click_payment_popup_'+searchedid+'').attr('atr_remaining_amount');
                 $('#remaining_amount').val(remaining_amount);
          console.log(total_price);
          console.log(amount_paid);
            console.log(remaining_amount);
          
       
      }
      
      
     
    $(document).ready(function () {

       

        $('#recieved_amount').on('change',function(){
            recieved_amount  = $(this).val();
            remaining_amount = $('#remaining_amount').val();
            remaining_amount_final = parseFloat(remaining_amount) - parseFloat(recieved_amount);
            $('#remaining_amount').val(remaining_amount_final);
            $('#amount_paid').val(recieved_amount);
        });

    });
   
    
   


</script>                  
      <script>
      $(function () {
          
        
        

        $('#form').on('submit', function (e) {
var invoice_no = $('#invoice_no').val();
       
        var amount_paid = $('#amount_paid').val();
        var remaining_amount = $('#remaining_amount').val();
        var recieved_amount = $('#recieved_amount').val();
        var total_amount =$('#total_amount').val();
          e.preventDefault();

          $.ajax({
            type: 'post',
            url: 'payment_detact/'+invoice_no,
            
            data: {
                'invoice_no':invoice_no,
                 'amount_paid':amount_paid,
                  'remaining_amount':remaining_amount,
                  'recieved_amount':recieved_amount,
                  'total_amount':total_amount,
                
            },
            headers: {
                            'X-CSRF-TOKEN': "{{ csrf_token() }}"
                            },
            success: function (data) {
              console.log(data);
             $('#msg').html(data).fadeIn('slow');
            $('#msg').html("payment successfully").fadeIn('slow') //also show a success message 
             $('#msg').delay(2000).fadeOut('slow');
            //  location.reload();
            setTimeout("window.location = ''",2000);
            }
          });

        });

      });
    </script>                     
 @endsection