<?php

//print_r($employees);
//die();
?>


@extends('template/frontend/userdashboard/layout/default')
@section('content')


    @if(session()->has('success'))
        <div x-data="{ show: true }" x-show="show"
             class="flex justify-between items-center bg-yellow-200 relative text-yellow-600 py-3 px-3 rounded-lg">
            <div>
                <span class="font-semibold text-yellow-700">   {{session('success')}}</span>
            </div>
            <div>
                <button type="button" @click="show = false" class=" text-yellow-700">
                    <span class="text-2xl">&times;</span>
                </button>
            </div>
        </div>
    @endif
    
   
        <div class="modal-content">
<div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel"></h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <div class="mt-2 mb-4">
                    <a href="" class="text-success">
                        <span>Edit Task</span>
                    </a>
                </div>

              

                       <form class="ps-3 pe-3" action="{{URL::to('super_admin/submit_edit_task',[$task->id])}}" id="edit_role_form" method="post">
                 @csrf
                  


                    <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Task Title</label>
                        <input class="form-control"  type="text" id="task_title" name="task_title" value="{{$task->task_title}}"> 
                            </div>
                            <div class="col-md-6">
                                <label for="emailaddress" class="form-label">Employee id</label>
                      
                        <select class="form-control" name="employee_id">
                            <option>Select Employee </option>
                            @foreach($admin_employee as $admin_employee)
                            <option value="{{$admin_employee->id}}">{{$admin_employee->first_name}}  {{$admin_employee->last_name}}</option>
                            @endforeach
                        </select>
                            </div>
                            
                        </div>
                       
                    </div>
                     <div class="mb-3">
                        <div class="row">
                            <div class="col-md-12">
                                <label for="emailaddress" class="form-label">Task Discription</label>
                                <textarea class="form-control" name="task_discription" rows="5" cols="5">{{$task->task_discription}}</textarea>
                            </div>
                            
                             
                            
                        </div>
                       
                    </div>
                    <div class="mb-3">
                        <div class="row">
                            <div class="col-md-12">
                                <label for="emailaddress" class="form-label">Task Comments</label>
                                <textarea class="form-control" name="task_comments" rows="5" cols="5">{{$task->task_comments}}</textarea>
                            </div>
                            
                             
                            
                        </div>
                       
                    </div>
                   
                    <div class="mb-3">
                        <div class="row">
                            <div class="col-md-4">
                                <label for="emailaddress" class="form-label">Task Assigned Date</label>
                        <input class="form-control"  type="date" id="task_assigned_date" name="task_assigned_date" value="{{$task->task_assigned_date}}"> 
                            </div>
                            <div class="col-md-4">
                                <label for="emailaddress" class="form-label">Expected Completion Date</label>
                        <input class="form-control"  type="date" id="expected_completion_date" name="expected_completion_date" value="{{$task->expected_completion_date}}"> 
                            </div>
                            <div class="col-md-4">
                                <label for="emailaddress" class="form-label">Completion Date</label>
                        <input class="form-control"  type="date" id="completion_date" name="completion_date" value="{{$task->completion_date}}"> 
                            </div>
                            
                        </div>
                       
                    </div>
                    
                     
                    
                    
                    

                   

            
                    

                    <div class="mb-3">
                        <button name="submit" class="btn btn-primary" type="submit">submit</button>
                    </div>

                </form>

            </div>
        </div><!-- /.modal-content -->
   






 


    
@endsection



