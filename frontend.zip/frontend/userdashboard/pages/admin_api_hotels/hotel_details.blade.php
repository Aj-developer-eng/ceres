<?php
//print_r($hotel_res);die();
 $hotel_beds_code=Session::get('hotel_beds_code');
 $hotel_beds_name=Session::get('hotel_beds_name');
 $room_search=Session()->get('room_searching');
 $count_p=Session()->get('room_searching');
  $travellanda_currency=Session::get('travellanda_currency');
//  $room_search=$room_search[0]->Room;
//  print_r($hotel_beds_name);die();
$hotel_beds_latitude=Session::get('hotel_beds_latitude');
$hotel_beds_longitude=Session::get('hotel_beds_longitude');
 $adult_count = Session::get('adult');
  $child_searching = Session::get('child_searching');
  $in = Session::get('newstart');
  $out = Session::get('newend');
  $webbeds_hotel_name = Session::get('webbed_hotel_name');
  $webbed_hotel_currency = Session::get('$webbed_hotel_currency');
  $hotel_res=Session::get('hotels_checkavailability');

?>
@extends('template/frontend/userdashboard/layout/default')
 @section('content')
<style>
.display
{
  display: none;
}
.form-check label.btn-success
{
   background:#198754;
   border:1px solid #198754;
}
.form-check label.btn-success svg {
  display: block;
    position: absolute;
    top: 7px;
    left: 15px;
}
.form-check label.btn-primary svg {
  display: none;
}
.owl-item
{
    width: 120px !important;
}
.owl-carousel
{
  width: 616px !important;   
}
</style>
<!-- Start Content-->


@if(isset($hotel_res) && isset($hotels_rooms))
      <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/lib/owl.carousel.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('public/admin_package/frontend/css/lib/owl.carousel.min.css') }}">
<input type="hidden" value="0" id="total_rooms_selected" />
<div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    
                                    <h4 class="page-title">Hotel Details</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title --> 

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-5">
                                                <!-- Product image -->
                                                
                                                <a href="javascript: void(0);" class="text-center d-block mb-4">
                                                    <?php
                                                    if(isset($rooms_img_gallary))
                                                    {
                                                        $img=json_decode($rooms_img_gallary[0]->img_name);
                                                    ?>
                                                    <img src="{{$img[0]}}" class="img-fluid" style="max-width: 280px;" alt="Product-img" />
                                                    <?php
                                                    }
                                                    ?>
                                                </a>

                                                <div class="d-lg-flex d-none justify-content-center">
                                                    <?php
                                                    if(isset($rooms_img_gallary))
                                                    {
                                                    $img=json_decode($rooms_img_gallary[0]->img_name);
                                                    $count=1;
                                                    if(isset($img))
                                                    {
                                                    foreach($img as $key => $imgs)
                                                    {
                                                        if($key > 0)
                                                        {
                                                        if($count <= 3)
                                                        {
                                                    ?>
                                                    <a href="javascript: void(0);">
                                                        <img src="https://alhijaztours.net/public/uploads/more_room_images/{{$imgs}}" class="img-fluid img-thumbnail p-2" style="max-width: 75px;" alt="Product-img" />
                                                    </a>
                                                    <?php
                                                    $count=$count+1;
                                                        }
                                                        }
                                                    }
                                                    }
                                                    }
                                                    ?>
                                                </div>
                                            </div> <!-- end col -->
                                            <div class="col-lg-7">
                                                <form class="ps-lg-4">
                                                    <!-- Product title -->
                                                    <h3 class="mt-0">{{$hotel_res->property_name ?? ""}}<a href="javascript: void(0);" class="text-muted"><i class="mdi mdi-square-edit-outline ms-2"></i></a> </h3>
                                                    <p class="mb-1">{{$hotel_res->property_city ?? ''}}, {{$hotel_res->property_country ?? ''}}</p>
                                                    <p class="font-16">
                                                        
                                                        <?php
                                                        if($hotel_res->star_type == 1)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($hotel_res->star_type == 2)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($hotel_res->star_type == 3)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($hotel_res->star_type == 4)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($hotel_res->star_type == 5)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        
                                                    </p>

                                                    <!-- Product stock -->
                                                    <div class="mt-3">
                                                        <h4><span class="badge badge-success-lighten">Instock</span></h4>
                                                    </div>

                                                    <!-- Product description -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Hotel Price:</h6>
                                                        <h3> $139.58</h3>
                                                    </div>

                                                    <!-- Quantity -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Quantity</h6>
                                                        <!--<div class="d-flex">-->
                                                        <!--    <input type="number" min="1" value="1" class="form-control" placeholder="Qty" style="width: 90px;">-->
                                                            <!--<button type="button" class="btn btn-danger ms-2"><i class="mdi mdi-cart me-1"></i> Add to cart</button>-->
                                                        <!--</div>-->
                                                    </div>
                                        
                                                    <!-- Product description -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Description:</h6>
                                                        <p>{{$hotel_res->property_desc ?? ''}}</p>
                                                    </div>

                                                    <!-- Product information -->
                                                    <div class="mt-4">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Phone No:</h6>
                                                                <p class="text-sm lh-150">{{$hotel_res->property_phone ?? ''}}</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Latitude:</h6>
                                                                <p class="text-sm lh-150">{{$hotel_res->latitude ?? ''}}</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Longitude:</h6>
                                                                <p class="text-sm lh-150">{{$hotel_res->longitude ?? ''}}</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </form>
                                            </div> <!-- end col -->
                                        </div> <!-- end row-->
<form id="roomsform" action="{{URL::to('booking/locked/hotels')}}" method="post">
    @csrf
                                        <div class="table-responsive mt-4">
                                            <table class="table table-bordered table-centered mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Room Name</th>
                                                        <th>Room Price</th>
                                                        <th>Capacity</th>
                                                        <th>Select</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    
                                                    <?php
                                                    
                                                         $room_counter=1;
                                                         $count_price=1;
                                                     foreach($hotels_rooms as $Rooms)
                                                        {
                                                         
                                                    ?>
                                                    
                                                    <tr>
                                                        <td>{{$Rooms->room_type_id ?? ''}}

                                                        </td>
                                                        <td>
                                                            <?php
                                                            if($Rooms->price_all_days_wi_markup != null)
                                                            {
                                                                $price=$Rooms->price_all_days_wi_markup;
                                                                 if($hotel_res->currency_symbol == '﷼')
                                                                    {
                                                                    $currency='SAR';
                                                                    }
                                                                    else
                                                                    {
                                                                    $currency=$hotels->currency_symbol;
                                                                    }
                                                                $exchange_price=all_currency_manage($currency,$price);
                                                    
                                                                $room_price=$exchange_price;
                                                                
                                                                echo 'GBP' . $room_price;
                                                            
                                                            }
                                                            else
                                                            {
                                                                
                                                                 $price=$Rooms->weekdays_price_wi_markup;
                                                                if($hotel_res->currency_symbol == '﷼')
                                                                    {
                                                                    $currency='SAR';
                                                                    }
                                                                    else
                                                                    {
                                                                    $currency=$hotels->currency_symbol;
                                                                    }
                                                                $exchange_price=all_currency_manage($currency,$price);
                                                                $room_price=$exchange_price;
                                                                echo 'GBP' . $room_price;
                                                            }
                                                            ?>
                                                           
                                                            </td>
                                                        <td>
                                                            <div class="progress-w-percent mb-0">
                                                                
                                                                <span class="">Adults: {{$adult_count}} </span><br>
                                                                <span class="">Children:{{$child_searching}} </span>
                                                                
                                                            </div>
                                                        </td>
                                                        <td>
                                                           
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <table class="table table-centered mb-0" style="border-color:none !important;">
                                                            
    <tbody>
        <tr>
            <td>
                <div class="owl-carousel" style="text-align:center">
 <!--<div class="row" style="text-align:center;">-->
<?php
$exchange_price_weekdays='';
$exchange_price_weekends='';
$exchange_price_for_all_days='';
$st_date = $in;
$st_date = date('Y-m-d', strtotime('+1 day', strtotime($st_date)));
$ed_date = $out;

// $dateMonthYearArr = array();
$st_dateTS = strtotime($st_date);
$ed_dateTS = strtotime($ed_date);
$grand_total_weekdays=0;
$grand_total_weekends=0;
$grand_total_price_all_days=0;

  $count_price1=$count_price;
for ($currentDateTS = $st_dateTS; $currentDateTS <= $ed_dateTS; $currentDateTS += (60 * 60 * 24)) {
// use date() and $currentDateTS to format the dates in between
$currentDateStr = date("Y-m-d",$currentDateTS);
$currentDateStr1 = date("l",$currentDateTS);


$date_formates=date("D,M d",$currentDateTS);

$dateMonthYearArr[] = $currentDateStr;
?>
 
<div class="item hotel_append_div_carosal" style="border: 1px solid #d2b254;border-radius: 45px;margin-right: 0px;padding: 0px;font-size: 12px;height: 40px;font-weight: bold;">

<?php
print $date_formates;
echo '<br>';
// print $currentDateStr;
// echo '<br>';
// print $currentDateStr1;
// echo '<br>';

if(isset($Rooms->weekdays))
{
    $weekdays=json_decode($Rooms->weekdays);
    if(isset($weekdays))
    {
    foreach($weekdays as $weekday)
    {
        if($weekday == $currentDateStr1)
        {
            if($currentDateStr1 == 'Monday' || $currentDateStr1 == 'Tuesday' || $currentDateStr1 == 'Wednesday'|| $currentDateStr1 == 'Thursday'|| $currentDateStr1 == 'Friday'|| $currentDateStr1 == 'Saturday'|| $currentDateStr1 == 'Sunday')
            {
                 $price=$Rooms->weekdays_price_wi_markup;
                                                    if($hotel_res->currency_symbol == '﷼')
                                                                    {
                                                                    $currency='SAR';
                                                                    }
                                                                    else
                                                                    {
                                                                    $currency=$hotels->currency_symbol;
                                                                    }
                 $exchange_price=all_currency_manage($currency,$price);
                 $exchange_price_weekdays=number_format($exchange_price,2);
                  $curr='GBP';
                 ?>
                  <p style="font-size: 12px;"><?php print_r($curr .' '.$exchange_price); ?></p>
                 
                 <?php
                 
               
            
             $grand_total_weekdays=number_format($grand_total_weekdays + $exchange_price,2);
            }
        }
    }

}
}


if(isset($Rooms->weekends))
{
    $weekends=json_decode($Rooms->weekends);
     if(isset($weekends))
    {
    foreach($weekends as $weekend)
    {
        if($weekend == $currentDateStr1)
        {
             if($currentDateStr1 == 'Monday' || $currentDateStr1 == 'Tuesday' || $currentDateStr1 == 'Wednesday'|| $currentDateStr1 == 'Thursday'|| $currentDateStr1 == 'Friday'|| $currentDateStr1 == 'Saturday'|| $currentDateStr1 == 'Sunday')
            {
             $price=$Rooms->weekends_price_wi_markup;
             
             if($hotel_res->currency_symbol == '﷼')
                                                                    {
                                                                    $currency='SAR';
                                                                    }
                                                                    else
                                                                    {
                                                                    $currency=$hotels->currency_symbol;
                                                                    }
                 
                 $exchange_price=all_currency_manage($currency,$price);
                 $exchange_price_weekends=number_format($exchange_price,2);
                $curr='GBP';
                ?>
                  <p><?php print_r($curr .' '.$exchange_price); ?></p>
                <?php
            
              $grand_total_weekends=number_format($grand_total_weekends + $exchange_price,2);
        }
        }
    }
    }
}

if(isset($Rooms->price_week_type))
{
    if($Rooms->price_week_type == 'for_all_days')
    {
    $price_all_days=$Rooms->price_all_days_wi_markup;
    $all_days=array(
        '0'=>'Monday',
        '1'=>'Tuesday',
        '2'=>'Wednesday',
        '3'=>'Thursday',
        '4'=>'Friday',
        '5'=>'Saturday',
        '6'=>'Sunday',
        );
     if(isset($price_all_days))
    {
       
    foreach($all_days as $all_day)
    {
        if($all_day == $currentDateStr1)
        {
             if($currentDateStr1 == 'Monday' || $currentDateStr1 == 'Tuesday' || $currentDateStr1 == 'Wednesday'|| $currentDateStr1 == 'Thursday'|| $currentDateStr1 == 'Friday'|| $currentDateStr1 == 'Saturday'|| $currentDateStr1 == 'Sunday')
            {
           $price=$Rooms->price_all_days_wi_markup;
           
                 if($hotel_res->currency_symbol == '﷼')
                                                                    {
                                                                    $currency='SAR';
                                                                    }
                                                                    else
                                                                    {
                                                                    $currency=$hotels->currency_symbol;
                                                                    }
                 $exchange_price=all_currency_manage($currency,$price);
                 $exchange_price_for_all_days=number_format($exchange_price,2);
                $curr='GBP';
                ?>
                 <p class="" ><?php print_r($curr . $exchange_price_for_all_days); ?></p>
                 
                <?php
             
              $grand_total_price_all_days=$grand_total_price_all_days + $exchange_price;
        }
        }
        
    }
    }
    }
}


?>
</div>
<?php
$big_grand_all_days_week=number_format($grand_total_price_all_days,2);
$big_grand=number_format($grand_total_weekends + $grand_total_weekdays,2);
$count_price1=$count_price1+1;

}

?>



                                                   
 </div>
            </td>
            <td>
                 <?php
                                            
                                               
                                             $room_data=array(
                                                         
                                                         'rooms_id'=>$Rooms->id,
                                                         'rooms_name'=>$Rooms->room_type_id,
                                                         'room_price'=>$room_price,
                                                         'rooms_type'=>'outer',
                                                         'rooms_type_id'=>$Rooms->room_type_cat,
                                                         'rooms_type_name'=>$Rooms->room_type_name,
                                                         'rooms_supplier'=>$Rooms->room_supplier_name,
                                                         'rooms_name'=>$Rooms->room_type_id,
                                                         'rooms_on_request'=>$Rooms->rooms_on_rq ?? '',
                                                         'room_view'=>$Rooms->room_view,
                                                         'rooms_meal_type'=>$Rooms->room_meal_type,
                                                         'currency'=>'GBP',
                                                         'price_week_type'=>$Rooms->price_week_type ?? '',
                                                         'grand_total_price_week_weekend'=>$big_grand ?? '',
                                                         'grand_total_price_all_days'=>$big_grand_all_days_week ?? '',
                                                          'weekdays'=>$Rooms->weekdays ?? '',
                                                         'exchange_price_weekdays'=>$exchange_price_weekdays,
                                                         'weekends'=>$Rooms->weekends ?? '',
                                                         'exchange_price_weekends'=>$exchange_price_weekends,
                                                         'exchange_price_for_all_days'=>$exchange_price_for_all_days,
                                                         'rooms_quantity'=>$room_search,
                                                         'rooms_adults'=>$Rooms->max_adults,
                                                         'rooms_children'=>$Rooms->max_child,
                                                         'cancellation_policy'=>array(
                                                             'concellation_policy'=>$cancellation_details->concellation_policy ?? '',
                                                             'guests_pay_days'=>$cancellation_details->guests_pay_days ?? '',
                                                             'guests_pay'=>$cancellation_details->guests_pay ?? '',
                                                             'prepaymentpolicy'=>$cancellation_details->prepaymentpolicy ?? '',
                                                             
                                                             ),
                                                             'additional_meal'=>array(
                                                             
                                                             'additional_meal_type'=>$Rooms->additional_meal_type ?? '',
                                                             'additional_meal_type_charges'=>$Rooms->additional_meal_type_charges ?? '',
                                                            
                                                             
                                                             ),
                                                         
                                                         );
                                                     
                                                     ?>
                                               
                                                      <div class="form-check" style="width: 101px;float:right;">
                                                            
                                                        <input  value='<?php print_r(json_encode($room_data));?>' data-room="{{$Rooms->room_meal_type}}" room-id="{{$Rooms->id}}" room-quantity="1" data-for="{{$Rooms->room_meal_type}}{{$room_counter}}"  data-room-type="{{$Rooms->room_type_id}}"   type="checkbox" class="form-check-input selectrooms btn-check" id="{{$Rooms->room_meal_type}}{{$room_counter}}"  autocomplete="off" name="hotels_select_room[]">
                                                        <label style="padding: 5px;position: relative;" class="btn btn-primary font-size-12px w-100 font-bold" for="{{$Rooms->room_meal_type}}{{$room_counter}}">
                                                        <p class="mb-0 text-white" style="font-size: 11px;">Select </p><p class="mb-0 text-white" style="font-size: 11px;">{{$Rooms->room_meal_type}} - 
                                                        <?php
                                                       
                                                         if($Rooms->price_week_type == 'for_week_end')
                                                         {
                                                         ?>
                                                         <?php echo 'GBP' . '  ' . $big_grand; ?>
                                                         
                                                         <?php
                                                         }
                                                         ?>
                                                         
                                                         <?php
                                                         if($Rooms->price_week_type == 'for_all_days')
                                                         {
                                                         ?>
                                                         <p style="font-size: 11px;" class="" >GBP {{$big_grand_all_days_week ?? '0'}}</p>
                                                        
                                                        
                                                         <?php
                                                         }
                                                         ?>
                                                        
                                                        </p>
                                                        
                                                                          
                                                                               
                                                                        
                                                                          
                                                                          </label>
                                                                       
                                                                     </div>
                                                
                                                            
            </td>
        </tr>
    </tbody>
</table>
                                                    </tr>
                                                   <?php
                                                   $room_counter=$room_counter+1;
                                                             }
                                                         
                                                         
                                                         
                                                   ?>
                                                  
                                                </tbody>
                                            </table>
                                             
                                        </div> <!-- end table-responsive-->
                                        
                                        <div class="d-flex" style="margin: 22px;float: right;">
                                                           
                                                    <button type="submit" name="submit" class="btn btn-danger ms-2">Book Now</button>
                                                    </div>
                                        </form>
                                        
                                        
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
                        </div>
                        <!-- end row-->
                        
                    </div> <!-- container -->
                    
@endif







@if(isset($travellanda_roomh))
<input type="hidden" value="0" id="total_rooms_selected" />
<div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    
                                    <h4 class="page-title">Hotel Details</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title --> 

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-5">
                                                <!-- Product image -->
                                                
                                                <a href="javascript: void(0);" class="text-center d-block mb-4">
                                                    <img src="{{$details_travellanda->Images->Image[0] ?? ''}}" class="img-fluid" style="max-width: 280px;" alt="Product-img" />
                                                </a>

                                                <div class="d-lg-flex d-none justify-content-center">
                                                    <?php
                                                    $count=1;
                                                    foreach($details_travellanda->Images->Image as $key => $img)
                                                    {
                                                        if($key > 0)
                                                        {
                                                        if($count <= 3)
                                                        {
                                                    ?>
                                                    <a href="javascript: void(0);">
                                                        <img src="{{$img}}" class="img-fluid img-thumbnail p-2" style="max-width: 75px;" alt="Product-img" />
                                                    </a>
                                                    <?php
                                                    $count=$count+1;
                                                        }
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div> <!-- end col -->
                                            <div class="col-lg-7">
                                                <form class="ps-lg-4">
                                                    <!-- Product title -->
                                                    <h3 class="mt-0">{{$details_travellanda->HotelName ?? ""}}<a href="javascript: void(0);" class="text-muted"><i class="mdi mdi-square-edit-outline ms-2"></i></a> </h3>
                                                    <p class="mb-1">{{$details_travellanda->Address ?? ''}},{{$details_travellanda->Location ?? ''}}</p>
                                                    <p class="font-16">
                                                        
                                                        <?php
                                                        if($details_travellanda->StarRating == 1)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($details_travellanda->StarRating == 2)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($details_travellanda->StarRating == 3)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($details_travellanda->StarRating == 4)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($details_travellanda->StarRating == 5)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        
                                                    </p>

                                                    <!-- Product stock -->
                                                    <div class="mt-3">
                                                        <h4><span class="badge badge-success-lighten">Instock</span></h4>
                                                    </div>

                                                    <!-- Product description -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Hotel Price:</h6>
                                                        <h3> $139.58</h3>
                                                    </div>

                                                    <!-- Quantity -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Quantity</h6>
                                                        <!--<div class="d-flex">-->
                                                        <!--    <input type="number" min="1" value="1" class="form-control" placeholder="Qty" style="width: 90px;">-->
                                                            <!--<button type="button" class="btn btn-danger ms-2"><i class="mdi mdi-cart me-1"></i> Add to cart</button>-->
                                                        <!--</div>-->
                                                    </div>
                                        
                                                    <!-- Product description -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Description:</h6>
                                                        <p>{{$details_travellanda->Description ?? ''}}</p>
                                                    </div>

                                                    <!-- Product information -->
                                                    <div class="mt-4">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Phone No:</h6>
                                                                <p class="text-sm lh-150">{{$details_travellanda->PhoneNumber ?? ''}}</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Latitude:</h6>
                                                                <p class="text-sm lh-150">{{$details_travellanda->Latitude ?? ''}}</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Longitude:</h6>
                                                                <p class="text-sm lh-150">{{$details_travellanda->Longitude ?? ''}}</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </form>
                                            </div> <!-- end col -->
                                        </div> <!-- end row-->
<form id="roomsform" action="{{URL::to('booking/locked/travellanda')}}" method="post">
    @csrf
                                        <div class="table-responsive mt-4">
                                            <table class="table table-bordered table-centered mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Room Name</th>
                                                        <th>Room Price</th>
                                                        <th>Capacity</th>
                                                        <th>Select</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    
                                                    <?php
                                                    
                                                         
                                                    if(isset($travellanda_roomh->Options->Option))
                                                         {
                                                    if(is_array($travellanda_roomh->Options->Option))
                                                         {
                                                             $room_counter=1;
                                                             foreach($travellanda_roomh->Options->Option as $optionz)
                                                             {
                                                         
                                                    ?>
                                                    
                                                    <tr>
                                                        <td>{{$optionz->Rooms->Room->RoomName ?? ''}}
                                                       
                                                        </td>
                                                        <td>GBP {{$optionz->Rooms->Room->RoomPrice ?? ''}}</td>
                                                        <td>
                                                            <div class="progress-w-percent mb-0">
                                                                <span class="">Adults: {{$optionz->Rooms->Room->NumAdults}} </span><br>
                                                                <span class="">Children:{{$optionz->Rooms->Room->NumChildren}} </span>
                                                                
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <?php
                                            
                                               
                                              $obj=array(
                                                   
                                                  'OptionId'=>$optionz->OptionId,
                                                    'OnRequest'=>$optionz->OnRequest,
                                                     'BoardType'=>$optionz->BoardType,
                                                      'TotalPrice'=>$optionz->TotalPrice,
                                                      'Rooms'=> array(
                                                          'Room'=>array(
                                                         "RoomId"=>$optionz->Rooms->Room->RoomId ?? '',
                                                            "RoomName"=>$optionz->Rooms->Room->RoomName,
                                                            "NumAdults"=>$optionz->Rooms->Room->NumAdults,
                                                            "NumChildren"=>$optionz->Rooms->Room->NumChildren,
                                                            "RoomPrice"=>$optionz->Rooms->Room->RoomPrice,
                                                          ),
                                                          
                                                          ),
                                                  );
                                                  
                                                  
                                               
                                               
                                               
                                              
                                               
                                               ?>
                                               
                                                           <div class="form-check">
                                                          
                                                               
                                                                         <input  value='<?php print_r(json_encode($obj));  ?>' data-room="{{$optionz->BoardType}}" room-id="{{$optionz->Rooms->Room->RoomId}}" room-quantity="{{$room_search}}" data-for="{{$optionz->BoardType}}{{$room_counter}}"  data-room-type="{{$optionz->Rooms->Room->RoomName}}" room-id="{{$room_counter}}"  type="checkbox" class="form-check-input selectrooms btn-check" id="{{$optionz->BoardType}}{{$room_counter}}"  autocomplete="off" name="selectrooms[]">
                                                                          <label style="padding: 5px;position: relative;" class="btn btn-primary font-size-12px w-100 font-bold" for="{{$optionz->BoardType}}{{$room_counter}}"><p class="mb-0 text-white" style="font-size: 11px;">Select </p><p class="mb-0 text-white" style="font-size: 11px;">{{$optionz->BoardType}}</p>
                                                                          <i class="fa-solid fa-check"></i>
                                                                          
                                                                               
                                                                        
                                                                          
                                                                          </label>
                                                                       
                                                                     </div> 
                                                
                                                            
                                                        </td>
                                                    </tr>
                                                   <?php
                                                   $room_counter=$room_counter+1;
                                                             }
                                                         }
                                                         }
                                                         
                                                         
                                                   ?>
                                                  
                                                </tbody>
                                            </table>
                                             
                                        </div> <!-- end table-responsive-->
                                        
                                        <div class="d-flex" style="margin: 22px;float: right;">
                                                           
                                                    <button type="submit" name="submit" class="btn btn-danger ms-2">Book Now</button>
                                                    </div>
                                        </form>
                                        
                                        
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
                        </div>
                        <!-- end row-->
                        
                    </div> <!-- container -->
                    
@endif


@if(isset($hotel_beds_de_result))

 <?php
        
        $hotel_bed=$hotel_beds_de_result;
        
        if($hotel_beds_code == $hotel_bed->code && $hotel_beds_name == $hotel_bed->name)
        {
        
        ?>
       
        
<?php




                   $apiKey = '833583586f0fd4fccd3757cd8a57c0a8';
        $secret = 'ae2dc887d0';
    
        $signature = hash("sha256", $apiKey.$secret.time());                                            
            
     $curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.test.hotelbeds.com/hotel-content-api/1.0/hotels/'.$hotel_bed->code.'/details?language=ENG&useSecondaryLanguage=False',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Api-key: 833583586f0fd4fccd3757cd8a57c0a8',
    "X-Signature: $signature",
    'Accept: application/json',
    'Accept-Encoding: gzip'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
$data1 = json_decode($response);
   
        $travel_content = $data1->hotel;
        // dd($travel_content);
        // print_r($travel_content);
        ?>


<input type="hidden" value="0" id="total_rooms_selected" />





<div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    
                                    <h4 class="page-title">Hotel Details</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title --> 

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-5">
                                                <!-- Product image -->
                                                
                                                <a href="javascript: void(0);" class="text-center d-block mb-4">
                                                    <img src="https://photos.hotelbeds.com/giata/bigger/{{$travel_content->images[0]->path}}" class="img-fluid" style="max-width: 280px;" alt="Product-img" />
                                                </a>

                                                <div class="d-lg-flex d-none justify-content-center">
                                                    <?php
                                                    $count=1;
                                                    foreach($travel_content->images as $key => $img)
                                                    {
                                                        if($key > 0)
                                                        {
                                                        if($count <= 3)
                                                        {
                                                    ?>
                                                    <a href="javascript: void(0);">
                                                        <img src="https://photos.hotelbeds.com/giata/bigger/{{$img->path}}" class="img-fluid img-thumbnail p-2" style="max-width: 75px;" alt="Product-img" />
                                                    </a>
                                                    <?php
                                                    $count=$count+1;
                                                        }
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div> <!-- end col -->
                                            <div class="col-lg-7">
                                                <form class="ps-lg-4">
                                                    <!-- Product title -->
                                                    <h3 class="mt-0">{{$hotel_bed->name ?? ""}}<a href="javascript: void(0);" class="text-muted"><i class="mdi mdi-square-edit-outline ms-2"></i></a> </h3>
                                                    <p class="mb-1">{{$hotel_bed->destinationName ?? ""}}</p>
                                                    <p class="font-16">
                                                        
                                                        <?php
                                                        $StarRating=5;
                                                        if($StarRating == 1)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($StarRating == 2)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($StarRating == 3)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($StarRating == 4)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($StarRating == 5)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        
                                                    </p>

                                                    <!-- Product stock -->
                                                    <div class="mt-3">
                                                        <h4><span class="badge badge-success-lighten">Instock</span></h4>
                                                    </div>

                                                    <!-- Product description -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Hotel Price:</h6>
                                                        <h3> $139.58</h3>
                                                    </div>

                                                    <!-- Quantity -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Quantity</h6>
                                                        <!--<div class="d-flex">-->
                                                        <!--    <input type="number" min="1" value="1" class="form-control" placeholder="Qty" style="width: 90px;">-->
                                                            <!--<button type="button" class="btn btn-danger ms-2"><i class="mdi mdi-cart me-1"></i> Add to cart</button>-->
                                                        <!--</div>-->
                                                    </div>
                                        
                                                    <!-- Product description -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Description:</h6>
                                                        <p>{{$travel_content->description->content ?? ""}}</p>
                                                    </div>

                                                    <!-- Product information -->
                                                    <div class="mt-4">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Phone No:</h6>
                                                                <p class="text-sm lh-150">43623623632</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Latitude:</h6>
                                                                <p class="text-sm lh-150">23336366</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Longitude:</h6>
                                                                <p class="text-sm lh-150">263463464646</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </form>
                                            </div> <!-- end col -->
                                        </div> <!-- end row-->
<form id="roomsform" action="{{URL::to('booking/locked/hotelbeds')}}" method="post">
    @csrf
                                        <div class="table-responsive mt-4">
                                            <table class="table table-bordered table-centered mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Room Name</th>
                                                        <th>Room Price</th>
                                                        <th>Capacity</th>
                                                        <th>Select</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    
                                                    <?php
                                                
                                                             $room_counter=1;
                                                    foreach($rooms_data as  $rooms_data)
                                                         {
                                                             
                                                            foreach($hotel_bed->rooms as $room)
                                                             {
                                                                   if($room->code == $rooms_data->roomCode)
                                            
                                                                        {
                                                         
                                                   
                                                            
                                                            $select=$room_counter;
                                                          
                                                           
                                                        
                                                         foreach($room->rates as $rate)
                                                            {
                                                     
                                                     $price=$rate->net;
                                                    $currency=$hotel_bed->currency ?? '';
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                    
                                                     
                                                     ?>
                                                    <tr>
                                                        <td>{{$room->name ?? ""}}
                                                       
                                                        </td>
                                                        <td>GBP {{$exchange_price ?? ''}}</td>
                                                        <td>
                                                            <div class="progress-w-percent mb-0">
                                                                <span class="">Rooms: {{$rate->rooms}} </span><br>
                                                                <span class="">Adults: {{$rate->adults}} </span><br>
                                                                <span class="">Children:{{$rate->children}} </span>
                                                                
                                                            </div>
                                                        </td>
                                                        <td>
                                                            
                                               <?php
                                               $obj_hotel_beds=array(
                                                        
                                                       'rate_rateKey'=>$rate->rateKey
                                                        
                                                        );
                                               ?>
                                                           <div class="form-check">
                                                          
                                                               
                                                                         <input  value='<?php print_r(json_encode($obj_hotel_beds));  ?>' data-room="{{$rate->boardName}}" room-id="{{$select}}" room-quantity="{{$rate->rooms}}" data-for="{{$rate->boardName}}{{$select}}"  data-room-type="{{$room->name}}" room-id="{{$select}}"  type="checkbox" class="form-check-input selectrooms btn-check" id="{{$rate->boardName}}{{$select}}"  autocomplete="off" name="hotelbeds_select_room[]">
                                                                          <label style="padding: 5px;position: relative;" class="btn btn-primary font-size-12px w-100 font-bold" for="{{$rate->boardName}}{{$select}}"><p class="mb-0 text-white" style="font-size: 11px;">Select </p><p class="mb-0 text-white" style="font-size: 11px;">{{$rate->boardName}}</p>
                                                                          <i class="fa-solid fa-check"></i>
                                                                          
                                                                               
                                                                        
                                                                          
                                                                          </label>
                                                                       
                                                                     </div>
                                                
                                                            
                                                        </td>
                                                    </tr>
                                                   <?php
                                                   $select=$select+1;
                                                             }
                                                   $room_counter=$select;
                                                         }
                                                         }
                                                         }
                                                   ?>
                                                  
                                                </tbody>
                                            </table>
                                             
                                        </div> <!-- end table-responsive-->
                                        
                                        <div class="d-flex" style="margin: 22px;float: right;">
                                                           
                                                    <button type="submit" name="submit" class="btn btn-danger ms-2">Book Now</button>
                                                    </div>
                                        </form>
                                        
                                        
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
                        </div>
                        <!-- end row-->
                        
                    </div> <!-- container -->
                    
                    <?php
        }
                    ?>
                    
@endif


@if(isset($hotel_tbo_detail_result))

<?php

       $request_data = array(
    'HotelCode' =>$hotel_tbo_detail_result->HotelCode,
   
    );
//   $searchdata=json_encode($searchdata);
  $curl = curl_init();
     curl_setopt_array($curl, array(
     CURLOPT_URL => 'https://admin.synchronousdigital.com/api/get_tbo_hotel_details',
     CURLOPT_RETURNTRANSFER => true,
     CURLOPT_ENCODING => '',
     CURLOPT_MAXREDIRS => 10,
     CURLOPT_TIMEOUT => 0,
     CURLOPT_FOLLOWLOCATION => true,
     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
     CURLOPT_CUSTOMREQUEST => 'POST',
     CURLOPT_POSTFIELDS =>  $request_data,
     CURLOPT_HTTPHEADER => array(
        'Cookie: laravel_session=gnq21xtzzbBtgOgSa0iVWPIX9vSDzHcKrUozAnSL'
     ),
     ));
  
     $response = curl_exec($curl);
     curl_close($curl);
     $tbo_hotel_detail= $response; 
    //  print_r($tbo_hotel_detail);
     $tbo_hotel_detail=json_decode($tbo_hotel_detail);
     $tbo_hotel_detail=$tbo_hotel_detail->data;

  $hotel_facilities= $tbo_hotel_detail->hotel_facilities;
     $hotel_facilities = json_decode($hotel_facilities);
    
 
 
     $tbo_hotel_image= $tbo_hotel_detail->images;
     $image= json_decode($tbo_hotel_image);
     $tbo_hotel_attractions= $tbo_hotel_detail->attractions;
     $attractions = json_decode($tbo_hotel_attractions);
     
     $map=$tbo_hotel_detail->map;
    $map = explode('|', $map);
     
  
     
     
    // print_r($tbo_hotel_detail);die();
        ?>


<input type="hidden" value="0" id="total_rooms_selected" />





<div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    
                                    <h4 class="page-title">Hotel Details</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title --> 

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-5">
                                                <!-- Product image -->
                                                
                                                <a href="javascript: void(0);" class="text-center d-block mb-4">
                                                    <img src="{{$image[0]}}" class="img-fluid" style="max-width: 280px;" alt="Product-img" />
                                                </a>

                                                <div class="d-lg-flex d-none justify-content-center">
                                                    <?php
                                                    $count=1;
                                                    foreach($image as $key => $img)
                                                    {
                                                        if($key > 0)
                                                        {
                                                        if($count <= 3)
                                                        {
                                                    ?>
                                                    <a href="javascript: void(0);">
                                                        <img src="{{$img}}" class="img-fluid img-thumbnail p-2" style="max-width: 75px;" alt="Product-img" />
                                                    </a>
                                                    <?php
                                                    $count=$count+1;
                                                        }
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div> <!-- end col -->
                                            <div class="col-lg-7">
                                                <form class="ps-lg-4">
                                                    <!-- Product title -->
                                                    <h3 class="mt-0">{{$tbo_hotel_detail->hotel_name ?? ""}}<a href="javascript: void(0);" class="text-muted"><i class="mdi mdi-square-edit-outline ms-2"></i></a> </h3>
                                                    <p class="mb-1">{{$tbo_hotel_detail->city_name}}, {{$tbo_hotel_detail->country_name}}</p>
                                                    <p class="font-16">
                                                        
                                                        <?php
                                                        $StarRating=5;
                                                        if($StarRating == 1)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($StarRating == 2)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($StarRating == 3)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($StarRating == 4)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($StarRating == 5)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        
                                                    </p>

                                                    <!-- Product stock -->
                                                    <div class="mt-3">
                                                        <h4><span class="badge badge-success-lighten">Instock</span></h4>
                                                    </div>

                                                    <!-- Product description -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Hotel Price:</h6>
                                                        <h3> $139.58</h3>
                                                    </div>

                                                    <!-- Quantity -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Quantity</h6>
                                                        <!--<div class="d-flex">-->
                                                        <!--    <input type="number" min="1" value="1" class="form-control" placeholder="Qty" style="width: 90px;">-->
                                                            <!--<button type="button" class="btn btn-danger ms-2"><i class="mdi mdi-cart me-1"></i> Add to cart</button>-->
                                                        <!--</div>-->
                                                    </div>
                                        
                                                    <!-- Product description -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Description:</h6>
                                                        <p>{{$tbo_hotel_detail->hotel_description}}</p>
                                                    </div>

                                                    <!-- Product information -->
                                                    <div class="mt-4">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Phone No:</h6>
                                                                <p class="text-sm lh-150">43623623632</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Latitude:</h6>
                                                                <p class="text-sm lh-150">23336366</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Longitude:</h6>
                                                                <p class="text-sm lh-150">263463464646</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </form>
                                            </div> <!-- end col -->
                                        </div> <!-- end row-->
<form id="roomsform" action="{{URL::to('booking/locked/tbo')}}" method="post">
    @csrf
                                        <div class="table-responsive mt-4">
                                            <table class="table table-bordered table-centered mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Room Name</th>
                                                        <th>Room Price</th>
                                                        <th>Capacity</th>
                                                        <th>Select</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    
                                                    <?php
                                                
                                                          $room_counter=1;
                                 
                                 foreach($hotel_tbo_detail_result->Rooms as $Rooms)
                                        {
                                                     
                                                    $price=$Rooms->TotalFare;
                                                    $currency='USD';
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                    
                                                     
                                                     ?>
                                                    <tr>
                                                        <td>{{$Rooms->Name[0] ?? ""}}
                                                       
                                                        </td>
                                                        <td>GBP {{$exchange_price ?? ''}}</td>
                                                        <td>
                                                            <div class="progress-w-percent mb-0">
                                                                <span class="">Rooms: {{$room_search}} </span><br>
                                                                <span class="">Adults: {{$adult_count}} </span><br>
                                                                <span class="">Children:{{$child_searching}} </span>
                                                                
                                                            </div>
                                                        </td>
                                                        <td>
                                                            
                                              <?php
                                                         $data_tbo_obj=array(
                                                             
                                                             'BookingCode'=>$Rooms->BookingCode,
                                                             );
                                               ?>
                                                           <div class="form-check">
                                                          
                                                               
                                                                         <input  value='<?php print_r(json_encode($data_tbo_obj));  ?>' data-room="{{$Rooms->MealType}}" room-id="{{$room_counter}}" room-quantity="1" data-for="{{$Rooms->MealType}}{{$room_counter}}"  data-room-type="{{$Rooms->Name[0]}}" room-id="{{$room_counter}}"  type="checkbox" class="form-check-input selectrooms btn-check" id="{{$Rooms->MealType}}{{$room_counter}}"  autocomplete="off" name="tbo_select_room[]">
                                                                          <label style="padding: 5px;position: relative;" class="btn btn-primary font-size-12px w-100 font-bold" for="{{$Rooms->MealType}}{{$room_counter}}"><p class="mb-0 text-white" style="font-size: 11px;">Select </p><p class="mb-0 text-white" style="font-size: 11px;">{{$Rooms->MealType}}</p>
                                                                          <i class="fa-solid fa-check"></i>
                                                                          
                                                                               
                                                                        
                                                                          
                                                                          </label>
                                                                       
                                                                     </div>
                                                
                                                            
                                                        </td>
                                                    </tr>
                                                   <?php
                                                    $room_counter=$room_counter+1;
                                        }
                                                   ?>
                                                  
                                                </tbody>
                                            </table>
                                             
                                        </div> <!-- end table-responsive-->
                                        
                                        <div class="d-flex" style="margin: 22px;float: right;">
                                                           
                                                    <button type="submit" name="submit" class="btn btn-danger ms-2">Book Now</button>
                                                    </div>
                                        </form>
                                        
                                        
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
                        </div>
                        <!-- end row-->
                        
                    </div> <!-- container -->
                    
                    
                    
@endif

@if(isset($rate_hawke_hotel_details))

<input type="hidden" value="0" id="total_rooms_selected" />





<div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    
                                    <h4 class="page-title">Hotel Details</h4>
                                </div>
                            </div>
                        </div>
                         @if(session()->has('message'))
                                        
                                        <div class="alert alert-primary alert-dismissible bg-primary text-white border-0 fade show" role="alert">
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                                        <strong>{{session('message')}} </strong> 
                                    </div>
                                        
                            
                            @endif
                        <!-- end page title --> 

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-5">
                                                <!-- Product image -->
<?php
                                            
$image=$rate_hawke_hotel_details->images[0];
$image = explode('{size}', $image);
$img=$image[0]. '1024x768'.$image[1];
?> 
                                                <a href="javascript: void(0);" class="text-center d-block mb-4">
                                                    <img src="{{$img}}" class="img-fluid" style="max-width: 280px;" alt="Product-img" />
                                                </a>

                                                <div class="d-lg-flex d-none justify-content-center">
                                                    <?php
                                                    $count=1;
                                                    foreach($rate_hawke_hotel_details->images as $key => $img)
                                                    {
                                                        if($key > 0)
                                                        {
                                                        if($count <= 3)
                                                        {

                                            
$image=$img;
$image = explode('{size}', $image);
$img=$image[0]. '1024x768'.$image[1];

                                                    ?>
                                                    <a href="javascript: void(0);">
                                                        <img src="{{$img}}" class="img-fluid img-thumbnail p-2" style="max-width: 75px;" alt="Product-img" />
                                                    </a>
                                                    <?php
                                                    $count=$count+1;
                                                        }
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div> <!-- end col -->
                                            <div class="col-lg-7">
                                                <form class="ps-lg-4">
                                                    <!-- Product title -->
                                                    <h3 class="mt-0">{{$rate_hawke_hotel_details->name ?? ""}}<a href="javascript: void(0);" class="text-muted"><i class="mdi mdi-square-edit-outline ms-2"></i></a> </h3>
                                                    <p class="mb-1">{{$rate_hawke_hotel_details->address ?? ""}}</p>
                                                    <p class="font-16">
                                                        
                                                        <?php
                                                        $StarRating=5;
                                                        if($StarRating == 1)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($StarRating == 2)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($StarRating == 3)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($StarRating == 4)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        <?php
                                                        if($StarRating == 5)
                                                        {
                                                         ?>
                                                         <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                          <span class="text-warning mdi mdi-star"></span>
                                                         <?php
                                                        }
                                                        ?>
                                                        
                                                    </p>

                                                    <!-- Product stock -->
                                                    <div class="mt-3">
                                                        <h4><span class="badge badge-success-lighten">Instock</span></h4>
                                                    </div>

                                                    <!-- Product description -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Hotel Price:</h6>
                                                        <h3> $139.58</h3>
                                                    </div>

                                                    <!-- Quantity -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Quantity</h6>
                                                        <!--<div class="d-flex">-->
                                                        <!--    <input type="number" min="1" value="1" class="form-control" placeholder="Qty" style="width: 90px;">-->
                                                            <!--<button type="button" class="btn btn-danger ms-2"><i class="mdi mdi-cart me-1"></i> Add to cart</button>-->
                                                        <!--</div>-->
                                                    </div>
                                        
                                                    <!-- Product description -->
                                                    <div class="mt-4">
                                                        <h6 class="font-14">Description:</h6>
                                                         @foreach($rate_hawke_hotel_details->description_struct as $description_struct)
                                                        <p>{{$description_struct->title}}</p>
                                                        @endforeach
                                                    </div>

                                                    <!-- Product information -->
                                                    <div class="mt-4">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Phone No:</h6>
                                                                <p class="text-sm lh-150">43623623632</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Latitude:</h6>
                                                                <p class="text-sm lh-150">23336366</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <h6 class="font-14">Longitude:</h6>
                                                                <p class="text-sm lh-150">263463464646</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </form>
                                            </div> <!-- end col -->
                                        </div> <!-- end row-->
<form id="roomsform" action="{{URL::to('booking/locked/ratehawke')}}" method="post">
    @csrf
                                        <div class="table-responsive mt-4">
                                            <table class="table table-bordered table-centered mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Room Name</th>
                                                        <th>Room Price</th>
                                                        <th>Capacity</th>
                                                        <th>Select</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    
                                                    <?php
                                                
                                                          $room_counter=1;
                                 
                                  
                                 if(isset($hotel_ratehawke_detail_result))
                                 {
                                 foreach($hotel_ratehawke_detail_result->hotels[0]->rates as $Rooms)
                                        {
                                          
                                         
                                                     ?>
                                                    <tr>
                                                        <td>{{$Rooms->room_name ?? ""}}
                                                       
                                                        </td>
                                                         @foreach($Rooms->payment_options->payment_types as $payment_types)
                                                        <td>GBP {{$payment_types->amount}}</td>
                                                         @endforeach
                                                        <td>
                                                            <div class="progress-w-percent mb-0">
                                                                <span class="">Rooms: {{$Rooms->rg_ext->quality}} </span><br>
                                                                <span class="">Adults: {{$Rooms->rg_ext->capacity}} </span><br>
                                                                <!--<span class="">Children:{{$child_searching}} </span>-->
                                                                
                                                            </div>
                                                        </td>
                                                        <td>
                                             <?php
                                                    
                                                    $obj=array(
                                                        
                                                        "book_hash"=>$Rooms->book_hash,
                                                        
                                                        
                                                        
                                                        );
                                                    
                                                    
                                                    
                                                    ?>
                                                          <div class="form-check">
                                                          
                                                               
                                                                         <input  value='<?php print_r(json_encode($obj)); ?>' data-room="{{$Rooms->meal}}" room-id="1" room-quantity="1" data-for="{{$Rooms->meal}}{{$room_counter}}"  data-room-type="{{$Rooms->room_name}}"   type="checkbox" class="form-check-input selectrooms btn-check" id="{{$Rooms->meal}}{{$room_counter}}"  autocomplete="off" name="ratehawk_select_room[]">
                                                                          <label style="padding: 5px;position: relative;" class="btn btn-primary font-size-12px w-100 font-bold" for="{{$Rooms->meal}}{{$room_counter}}"><p class="mb-0 text-white" style="font-size: 11px;">Select </p><p class="mb-0 text-white" style="font-size: 11px;">{{$Rooms->meal}}</p>
                                                                          <i class="fa-solid fa-check"></i>
                                                                          
                                                                               
                                                                        
                                                                          
                                                                          </label>
                                                                       
                                                                     </div>
                                                
                                                            
                                                        </td>
                                                    </tr>
                                                   <?php
                                                    $room_counter=$room_counter+1;
                                        }
                                 }
                                                   ?>
                                                  
                                                </tbody>
                                            </table>
                                             
                                        </div> <!-- end table-responsive-->
                                        
                                        <div class="d-flex" style="margin: 22px;float: right;">
                                                           
                                                    <button type="submit" name="submit" class="btn btn-danger ms-2">Book Now</button>
                                                    </div>
                                        </form>
                                        
                                        
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
                        </div>
                        <!-- end row-->
                        
                    </div> <!-- container -->
                    
                    
                    
@endif




















@endsection
@section('scripts')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
 <script type="text/javascript" src="{{ asset('public/admin_package/frontend/js/lib/jquery.owl.carousel.js') }}"></script>
<script>
    $(document).ready(function(){
            

 
  $(".owl-carousel").owlCarousel({
 
      autoPlay: 3000,
      items : 4,
      itemsDesktop : [1199,3],
      itemsDesktopSmall : [979,3],
      center: true,
      nav:true,
      loop:true,
      responsive: {
        600: {
          items: 4
        }
      }
  });
});
$('.selectrooms').change(function(){
    var room = $(this).attr('data-room');
    var amount = $(this).attr('data-amount');
    var room_type = $(this).attr('data-room-type');
    var room_id = $(this).attr('room-id');
    var room_quantity = $(this).attr('room-quantity');
    
    console.log('room_quantity'+room_quantity);
    var room_for = $(this).attr('data-for');
    if ($(this).is(':checked')) {
        var total_rooms_selected = <?php echo $count_p; ?>;
        
        var total_rooms = $('#total_rooms_selected').val();
        total_rooms = parseInt(total_rooms);
        
        
        total_rooms_selected = parseInt(total_rooms_selected);
   
        var total_rooms = parseInt(total_rooms) + parseInt(room_quantity);
       
        if(total_rooms <= total_rooms_selected){
        
           
            $('#total_rooms_selected').val(total_rooms);
            var price = $('#total_room_price').html();
            price = parseFloat(amount) + parseFloat(price);
               price = price.toFixed(2);
            $('#total_room_price').html(price);
            var close = '<a rel="nofollow" class="close-button cursor-pointer" data-room-id="'+room_id+'" data-amount="'+amount+'" data-quantity="'+room_quantity+'" data-label="'+room_for+'" id="delete_room' + room_id + '">x</a>';
            $('#rooms_title').append('<p id="room_id_calculate' + room_id + '">'+ room_quantity + ' x ' + room_type + ' - ' + room + '- SAR' + amount + '</p>' + close);
        }else{
            this.checked = false;
            alert('Select the room according to the search criteria','danger');
            return 0;
        }
    }else{
        var price = $('#total_room_price').html();
        var total_rooms = $('#total_rooms_selected').val();
         total_rooms = parseInt(total_rooms) - parseInt(room_quantity);
         $('#total_rooms_selected').val(total_rooms);
        price = parseFloat(price) - parseFloat(amount);
         price = price.toFixed(2);
        $('#total_room_price').html(price);
        $('#rooms_title').find('#room_id_calculate' + room_id).remove();
         $('#rooms_title').find('#delete_room' + room_id).remove();
    }
    
})

$('.book_now').click(function(){
   
   var total_rooms_selected = <?php echo $count_p; ?>;
   var total_rooms = $('#total_rooms_selected').val();
   total_rooms = parseInt(total_rooms);
        
        
  total_rooms_selected = parseInt(total_rooms_selected);
 
  if(total_rooms == total_rooms_selected){
      $('#roomsform').submit();
      
    
  }else{
       alert('Select the room according to the search criteria','danger');
  }
 
   
  });
  $('.btn-check').change(function(){
    var id = $(this).attr('id');
   
    var check = $("label[for='"+$(this).attr("id")+"']");
    
      if ($(this).is(':checked')) {
         
          check.removeClass('btn-primary');
          check.addClass('btn-success');
      }else{
           check.removeClass('btn-success');
          check.addClass('btn-primary');
      }
});
                 
</script>
@stop