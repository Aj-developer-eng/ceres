
<?php
   
//  $travellandacnfrmRS=$data->travellandacnfrmRS;
//                      $travellandacnfrmRS=json_decode($travellandacnfrmRS);
         
//  //$tbo_BookingDetail_rs=json_decode($data->tbo_BookingDetail_rs);
 //print_r($hotelbeds);die();
?>

<!DOCTYPE html>
<html lang="en">
   <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      
      <meta name="author" content="TechyDevs">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Alhijaztours  - Travel Booking System</title>
      <!-- Favicon -->
      <link rel="icon" href="">
      <!-- Google Fonts -->
      <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&amp;display=swap" rel="stylesheet">
      <!-- Template CSS Files -->
      <link rel="stylesheet" href="https://umrahtech.com/public/assets/frontend/css/bootstrap.min.css">
      <link rel="stylesheet" href="https://umrahtech.com/public/assets/frontend/css/line-awesome.css">
      
    
     
      <link rel="stylesheet" href="https://umrahtech.com/public/assets/frontend/css/style.css">
     
   </head>
   <style>
          body{
      font-family: "Roboto", sans-serif !important;
      }
     
      .title-vochure-top .la-check-circle{
      font-size: 100px;
      color: #2e97c0;
      }
      .title-vochure{
      padding-left: 15px;
      padding-top: 15px;
      }
      .title-vochure h1{
      margin: 0;
      padding: 0;
      color: #ae8c32;
      }
      .title-vochure p{
      margin: 0;
      color: #fff;
      font-size: 24px;
      }
      .title-vochure-top .w-32{
      width:120px;
      }
      .vochure-header-border{
      border-bottom: 3px solid #ae8c32
      padding: 15px 
      }
      .vochure-header-border .logo img{
        width: 100%;
    margin-top: 30px;
      }
      .vochure-detail-section{
      border: 1px solid #ddd;
      }
      .v-heading-top{
      background-color: #ae8c32;
      padding: 5px 0;
      color: #fff;
      text-transform: capitalize;
      }
      .v-heading-icon-title{
      padding-top: 3px;
      }
      .v-heading-icon img{
      max-width: 75px;
      padding: 0 15px;
      }
      .v-heading-icon-title h3{
      border-bottom: 2px solid #ae8c32;
      color: #ae8c32;
      }
      .v-section-info {
      padding: 5px 75px;
      }
      .vochure-content .list-items-2{
      border: 1px solid;
      padding: 10px;
      }
      .vochure-content .list-items-5{
      border: 1px solid;
      padding: 10px;
      }
      .vochure-content button{
      background-color: #ae8c32;
      color: white;
      font-weight: 500;
      border-radius: 25px;
      }
      .vochure-content .list-items-5 p{
      display: inline;
      }
      .vochure-content  .col-sm-4 > ul.list-items.list-notice.clearfix {
      background-color: #efefef;
      border:none;
      }
      .vochure-content .notice{
      padding: 20px;
      font-weight: 500;
      line-height: 1.7;
      }
      .vochure-content .thank-you-section h3{
      margin-top: 2.3em;
      color:#ae8c32;
      font-weight: 300;
      } 
      .vochure-content .thank-you-section button{
      background-color: #ae8c32;
      color: white;
      font-weight: 600;
      border-radius: 25px;
      padding: 8px;
      width: 225px;
      font-size: 16px;
      margin-bottom: 25px;
      } 
      .vochure-content .vochure-detail-section .v-heading > h2{
      padding: 10px;
      padding-left: 5%;
      padding: 10px;
      padding-left: 5%;
      }
      .vochure-content .list-items-2 li {
      display: -webkit-flex;
      display: -ms-flex;
      display: flex;
      -ms-flex-align: center;
      align-items: center;
      -ms-flex-pack: justify;
      justify-content: space-between;
      }
      .vochure-content .grand-total{
      padding: 38px;
      padding-left: 30%;
      font-size: 30px;
      }
      .vochure-content .notice{
      border: none;
      font-size: 14px;
      }
      .vochure-sidebar-title h3{
      background-color: #ae8c32;
      color: #fff;
      padding: 9px 15px;
      text-transform: capitalize;
      }
      .f-20{
      font-size:20px;
      }
      .list-items li {
      margin-bottom: 0;
      }
      .list-items-3 li span{
      width: 40%;
      /* width: 250px; */
      }
      .list-items-3 li{
      justify-content: start;
      word-break: break-word;
      }
      .la-headset{
      line-height: 2;
      }
      .icon-layout-3 .info-icon{
      background-color: #ff0000;
      }
      .table td, .table th {
      padding: 5px;
      }
      @media(max-width: 991px) {
      .title-vochure p {
      font-size: 14px;
      }
      .title-vochure h1 {
      font-size: 20px; 
      }
      .vochure-header-border .logo img {
      width: 85px;
      }
      .title-vochure-top .la-check-circle {
      font-size: 60px;
      }
      .title-vochure {
      padding-top: 5px;
      }
      }
      @media (max-width: 575.98px){
      .vochure-header-border .logo,
      .vochure-header-border .logo a
      {
      width: 100%;
      text-align: center;
      padding-bottom: 10px;
      }
      .list-items-3 li span{
      width: 100%;
      }
      .list-items-3 li{
      display: block;
      }
      .v-section-info {
      padding: 5px 20px;
      }
      .v-heading-icon-title h3 {
      font-size: 20px;
      }
      .v-heading-icon-title h2 {
      font-size: 22px;
      }
      .v-heading-icon-title{
      padding-top: 10px;
      }
      }
      .la-check-circle {
      /*color: #ffffff;*/
      background: none;
      }
      body{
      font-size: 14px;
      }
      .additionalServices_box {
      border: solid 1px cornflowerblue;
      padding: 10px;
      }
      .voucher-modal .modal-content{
      border-radius: 0px;
      }
      .voucher-modal .modal-footer{
      border-top: 0px;
      }
      .table{
      font-size: 12px;
      margin-bottom: 0;
      }
      .otp-top .btn{
      background: #113669;
      color: #fff;
      font-size: 12px;
      padding: 4px 10px;  
      }
      .otp-top .btn2{
      background: #068a62;
      }
      .itenery-ul{
        padding-left: 15px;
        padding-top: 15px;
        list-style-type: none;
      }
      .itenery-ul h4{
        font-size:20px;
      }
      .vochure-header {
        background-image:url("{{asset('public/admin_package/frontend/images/bg-vochure.jpg')}}");
      }
   </style>
   <body>
      <!-- start cssload-loader -->
      <div class="preloader" id="preloader">
         <div class="loader">
            <svg class="spinner" viewBox="0 0 50 50">
               <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle>
            </svg>
         </div>
      </div>
      
      
      
      
      
      
      
      <!-- end cssload-loader -->
      <!-- ================================
         START MODAL AREA
         
         
         ================================= -->
    
          <?php
                                
      if($data->provider == 'travellanda')
      {
          ?>
         
         
          <div class="container">
         <div class="row">
            <div class="col-12 col-md-12">
               <section class="modal_umrah_tech">
                  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                     <div class="modal-dialog modal-md">
                        <div class="modal-content">
                           <div class="modal-header justify-content-center">
                           </div>
                           <div class="modal-body">
                              <div class="container">
                                 <div class="row">
                                    <div class="col-12 col-md-12 text-center">
                                       <h1>Are You Sure!</h1>
                                       <h4>Your Reservation will be Cancelled By doing this Action</h4>
                                    </div>
                                
                                 </div>
                                 
                                 
                                 <?php
                                
      
    
                  $travellandaSelectionRS=$data->checkavailability_again_rs;
                     $travellandaSelectionRS=json_decode($travellandaSelectionRS);
                     
                    
                     if(isset($travellandaSelectionRS[0]->Rooms->Room->RoomPrice))
                     {
                       $grand_total=$travellandaSelectionRS[0]->Rooms->Room->RoomPrice;  
                     }
                     else
                     {
                  $grand_total=0;
                  
                  foreach($travellandaSelectionRS[0]->Rooms->Room as $travellandaSelectionRS)
                  {
                      $grand_total= $grand_total + $travellandaSelectionRS->RoomPrice;
                  }
                     }
                  
                  
                  $travellandacnfrmRS=$data->booking_rs;
                     $travellandacnfrmRS=json_decode($travellandacnfrmRS);
                     
                    if(isset($travellandacnfrmRS->Body->Bookings))
                    {
                       $booking_rf=$travellandacnfrmRS->Body->Bookings->HotelBooking->BookingReference; 
                    }
                    else
                    {
                      $booking_rf=$travellandacnfrmRS->Body->HotelBooking->BookingReference;  
                    }
                  
                  ?>
                                 
                                 
                                 
                                 
<form class="g-3" method="post"  action="{{URL::to('admin/booking_cancle')}}/{{$booking_rf}}/{{$data->provider}}">
           @csrf
  <div class="row">
  <div class="col-md-12">
    <label for="inputPassword4" class="form-label">Total Amount</label>
    <input type="text" class="form-control" value="{{$grand_total}}"  name="total_amount" >
  </div>
      </div>                            
            <div class="modal-footer text-center">
                              <button  type="submit" name="submit" class="btn btn-secondary">Submit</button>
                           </div>                        
      </form> 
                              </div>
                           </div>
                           
                        </div>
                     </div>
                  </div>
               </section>
            </div>
         </div>
      </div>
         
         <?php
         
      }
         ?>
         
         
         <?php
                                
      if($data->provider == 'hotelbeds')
      {
          ?>
         
         
          <div class="container">
         <div class="row">
            <div class="col-12 col-md-12">
               <section class="modal_umrah_tech">
                  <div class="modal fade" id="exampleModal_hotel_beds" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                     <div class="modal-dialog modal-md">
                        <div class="modal-content">
                           <div class="modal-header justify-content-center">
                           </div>
                           <div class="modal-body">
                              <div class="container">
                                 <div class="row">
                                    <div class="col-12 col-md-12 text-center">
                                       <h1>Are You Sure!</h1>
                                       <h4>Your Reservation will be Cancelled By doing this Action</h4>
                                    </div>
                                
                                 </div>
                                 
                                 
                                 <?php
                                
      
    
                  
                     
                    
                  
                  ?>
                                 
                                 
                                 
                                 

  <div class="row">
  <div class="col-md-12">
    <label for="inputPassword4" class="form-label">Total Amount</label>
    <input type="text" class="form-control" value="{{$hotelbeds->booking->hotel->currency ?? ''}}  {{$hotelbeds->booking->hotel->totalNet ?? ''}}"  name="total_amount" >
  </div>
      </div>                            
            <div class="modal-footer text-center">
                              <!--<button  type="submit" name="submit" class="btn btn-secondary">Submit</button>-->
                              <a class="btn btn-secondary" href="{{URL::to('hotel_bed_cancelliation')}}/{{$hotelbeds->booking->reference ?? ""}}">Confirm Cancel</a>
                           </div>                        
    
                              </div>
                           </div>
                           
                        </div>
                     </div>
                  </div>
               </section>
            </div>
         </div>
      </div>
         
         <?php
         
      }
         ?>
         
         
    
      <!-- ================================
         END MODAL AREA
         ================================= -->
      <script>
         localStorage.setItem('total_amount', 10933.17);
      </script>
      <!--End PHP-->
      <div class="vochure-header">
         <div class="container">
            <div class="vochure-header-border">
               <div class="row">
                  <div class="col-sm-4">
                     <div class="logo">
                        <a href="#"><img src="{{ asset('public/admin_package/frontend/images/logo.png') }}"  alt="logo"></a>
                     </div>
                  </div>
                  <div class="col-sm-8">
                     <div class="title-vochure-top float-right">
                        <div class="float-left text-right">
                           <img class="w-32" src="{{asset('public/admin_package/frontend/images/confirm.png') }}" alt="Booking Confirm">
                        </div>
                        <div class="title-vochure float-left">
                           <h1>Booking Confirmation</h1>
                           <p>Thanks for Booking with Alhijaz Tours</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      
      
      <?php
      if($data->provider == 'travellanda')
      {
      ?>
      
      
      <div class="vochure-content">
         <div class="container">
            <div class="button-group-voucher" style="display: flex; justify-content: flex-end;">
               <div class="text-right mt-3 mr-2">
                  <button type="submit" class="btn btn-secondary" onclick="window.print()">Print  Voucher </button>
               </div>
               <!--<div class="text-right mt-3 mr-2">-->
               <!--   <a href=""><button type="button" class="btn btn-secondary">Invoice</button></a>-->
               <!--</div>-->
               <!--<div class="text-right mt-3">-->
               <!--   <input type="hidden" name="" value="165389811372985682">-->
               <!--   <input type="hidden" id="invoice_number" value="165389811372985682" />-->
               <!--   <a href=""><button type="button" class="btn btn-secondary">Arabic</button></a>-->
               <!--</div>-->
            </div>
            <div class="row">
               <div class="col-md-8 col-sm-12">
                     
                  <section class="vochure-detail-section mt-3">
                     <div class="v-heading-icon v-heading-top clearfix">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/icon-tour.png') }}">
                        </div>
                        <div class="v-heading-icon-title float-left">
                           <h2></h2>
                        </div>
                     </div>
                     <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Hotel Information</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                     
                     <?php
                     
                     $travellandadetailRS=$data->checkavailability_rs;
                     $travellandadetailRS=json_decode($travellandadetailRS);
                     
                     
                     $travellandaSelectionRS=$data->checkavailability_again_rs;
                     $travellandaSelectionRS=json_decode($travellandaSelectionRS);
                     
                     
                      $travellandacnfrmRS=$data->booking_rs;
                     $travellandacnfrmRS=json_decode($travellandacnfrmRS);
                     
                     if(isset($travellandacnfrmRS->Body->Bookings))
                    {
                       Session::put('currency',$travellandacnfrmRS->Body->Bookings->HotelBooking->Currency);
                    }
                    else
                    {
                      Session::put('currency',$travellandacnfrmRS->Body->HotelBooking->Currency);  
                    }
                    
                   
                     
                     ?>
                     
                     
                     <div class="clearfix v-section-info">
                        <ul class="list-items list-items-3 list-items-4  clearfix" >
                           <li>
                              <span class="text-black font-weight-bold">Hotel Name:</span>
                              
                              <?php
                              
                              if(isset($travellandacnfrmRS->Body->Bookings))
                    {
                      $HotelName=$travellandacnfrmRS->Body->Bookings->HotelBooking->HotelName;
                    }
                    else
                    {
                      $HotelName=$travellandacnfrmRS->Body->HotelBooking->HotelName;  
                    }
                              
                              ?>
                              {{$HotelName}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                           
                           <li>
                              <span class="text-black font-weight-bold">Booking Status:</span>
                             {{$data->booking_status ?? ''}}
                              
                              
                              
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                           
                           
                           <li>
                              <span class="text-black font-weight-bold">Booking Reference No:</span>
                              <?php
                              
                              if(isset($travellandacnfrmRS->Body->Bookings))
                    {
                      $BookingReference=$travellandacnfrmRS->Body->Bookings->HotelBooking->BookingReference;
                    }
                    else
                    {
                      $BookingReference=$travellandacnfrmRS->Body->HotelBooking->BookingReference; 
                    }
                              
                              ?>
                              {{$BookingReference}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           <!-- <li>-->
                              
                           <!--   <span class="text-black font-weight-bold">Rating:</span>{{$travellandadetailRS->StarRating}}-->
                              
                           <!--</li>-->
                          
                           <li><span class="text-black font-weight-bold">Passenger:</span>{{$data->adults}} Adult , {{$data->childs}} Children</li>
                           
                           <li><span class="text-black font-weight-bold">Hotel Price:</span>
                           
                           <?php
                              
                               $travellandaSelectionRS=$data->checkavailability_again_rs;
                               $travellanda_rooms=$data->rooms;
                     $travellandaSelectionRS=json_decode($travellandaSelectionRS);
                     
                  if(isset($travellandaSelectionRS[0]->Rooms->Room->RoomPrice))
                     {
                       $grand_total=$travellandaSelectionRS[0]->Rooms->Room->RoomPrice;  
                     }
                     else
                     {
                  $grand_total=0;
                  
                  foreach($travellandaSelectionRS[0]->Rooms->Room as $travellandaSelectionRS)
                  {
                      $grand_total= $grand_total + $travellandaSelectionRS->RoomPrice;
                  }
                     }
                              
                              ?>
                              <?php
                              $currency=Session::get('currency');
                              ?>
                             {{$currency ?? ''}} {{$grand_total}}</li>
                           
                           
                                                           
                           <li><span class="text-black font-weight-bold">Check-In:</span>{{$data->check_in}}</li>
                           <li><span class="text-black font-weight-bold">Check-Out:</span>{{$data->check_out}}</li>
                           
                           
                           
                           <?php
                           
                           $startTimeStamp = strtotime($data->check_in);                                   
                            $endTimeStamp = strtotime($data->check_out);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                           
                           
                           ?>
                           
                           
                           
                           <li><span class="text-black font-weight-bold">Duration:</span><?php echo $numberDays; ?> Nights</li>
                           
                                  
                         
                        </ul>
                     </div>
                     
                     
                     
                     
                     
                     
                     
                     <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Room Information</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                     
                     <?php
                     
                     $count=1;
                     ?>
                     
                     <?php
                     if($travellanda_rooms == 1)
                     {
                         $travel_bordtype=$travellandaSelectionRS[0]->BoardType ?? '';
                     ?>
                     <div class="clearfix v-section-info">
                        <ul class="list-items list-items-3 list-items-4  clearfix" >
                            <li>
                              <span class="text-black font-weight-bold">Room <?php echo $count; ?></span>
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           <li>
                              <span class="text-black font-weight-bold">Room Name:</span>{{$travellandaSelectionRS[0]->Rooms->Room->RoomName}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                            <li>
                             
                              <span class="text-black font-weight-bold">Room id:</span>{{$travellandaSelectionRS[0]->Rooms->Room->RoomId}}
                             
                              
                           </li>
                           <li>
                             
                              <span class="text-black font-weight-bold">Board Type:</span>{{$travel_bordtype}}
                             
                              
                           </li>
                            <li>
                              
                              <span class="text-black font-weight-bold">Passenger:</span>{{$travellandaSelectionRS[0]->Rooms->Room->NumAdults}} Adult , {{$travellandaSelectionRS[0]->Rooms->Room->NumChildren}} Children
                              
                           </li>
                          
                           
                           
                           <li>
                              
                              <span class="text-black font-weight-bold">Room Price:</span> 
                              <?php
                              $currency=Session::get('currency');
                              echo $currency; 
                              
                              ?>   {{$travellandaSelectionRS[0]->Rooms->Room->RoomPrice}}
                              
                           </li>
                           
                                                           
                           
                           
                                  
                         
                        </ul>
                     </div>
                     
                     <?php
                     }
                     else
                     {
                         $travellandaSelectionRS=$data->checkavailability_again_rs;
                     $travellandaSelectionRS=json_decode($travellandaSelectionRS);
                      $travel_bordtype=$travellandaSelectionRS[0]->BoardType ?? '';
                     ?>
                     
                      @foreach($travellandaSelectionRS as $travellandaSelectionRS1)
                     
                     <div class="clearfix v-section-info">
                        <ul class="list-items list-items-3 list-items-4  clearfix" >
                            <li>
                              <span class="text-black font-weight-bold">Room <?php echo $count; ?></span>
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           <li>
                              <span class="text-black font-weight-bold">Room Name:</span>{{$data->rooms}} x {{$travellandaSelectionRS1->Rooms->Room->RoomName}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                            <li>
                             
                              <span class="text-black font-weight-bold">Room id:</span>{{$travellandaSelectionRS1->Rooms->Room->RoomId}}
                             
                              
                           </li>
                           <li>
                             
                              <span class="text-black font-weight-bold">Board Type:</span>{{$travel_bordtype}}
                             
                              
                           </li>
                            <li>
                              
                              <span class="text-black font-weight-bold">Passenger:</span>{{$travellandaSelectionRS1->Rooms->Room->NumAdults}} Adult , {{$travellandaSelectionRS1->Rooms->Room->NumChildren}} Children
                              
                           </li>
                          
                           
                           
                           <li>
                              
                              <span class="text-black font-weight-bold">Room Price:</span> 
                              <?php
                              $currency=Session::get('currency');
                              echo $currency; 
                              
                              ?>   {{$travellandaSelectionRS1->Rooms->Room->RoomPrice}}
                              
                           </li>
                           
                                                           
                           
                           
                                  
                         
                        </ul>
                     </div>
                     <?php
                     $count=$count + 1;
                     
                     ?>
                     @endforeach
                     <?php
                     }
                     ?>
                    
                     
               <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Cancellation Policy</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>     
             
            <?php
            
            if(isset($data->travellanda_policy))
            {
            ?>       
         <?php
         $travellanda_cancellation_response=$data->travellanda_policy;
         $travellanda_cancellation_response=json_decode($travellanda_cancellation_response);
         
         
         
         ?> 
         
         
         
         <div class="clearfix v-section-info">
                        <ul class="list-items list-items-3 list-items-4  clearfix" >
                            
                           <li>
                              <span class="text-black font-weight-bold">CancellationDeadline:</span>{{$travellanda_cancellation_response->Body->CancellationDeadline ?? ''}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                            <li>
                             
                              <span class="text-black font-weight-bold">TotalPrice:</span>{{$travellanda_cancellation_response->Body->Currency ?? ''}}  {{$travellanda_cancellation_response->Body->TotalPrice ?? ''}}
                             
                              
                           </li>
                           </ul>
                           </div>
         
         
                    
   <table class="table">
  <thead>
    <tr>
      <th scope="col">From</th>
      <th scope="col">Type</th>
      <th scope="col">Value</th>
      
    </tr>
  </thead>
  <tbody>
      @if(isset($travellanda_cancellation_response->Body->Policies->Policy))
      @foreach($travellanda_cancellation_response->Body->Policies->Policy as $Policy)
    <tr>
      <th scope="row">{{$Policy->From}}</th>
      <td>{{$Policy->Type}}</td>
      <td>
          <?php
                         
                         $currency=Session::get('currency');
                              echo $currency; 
                         ?>
          
          {{$Policy->Value}}</td>
      
    </tr>
    @endforeach
    @endif
  </tbody>
</table>


 <div class="clearfix v-section-info">
     <p>Note:</p>
     <?php
     if(isset($travellanda_cancellation_response->Body->Alerts->Alert))
     {
    print_r($travellanda_cancellation_response->Body->Alerts->Alert);
    
     }
        ?>
 </div>
                    
                    
     <?php
     
            }
     ?>               
                    
                    
                    
                    
                  
                 <?php
                 
                 if($data->booking_status == 'Confirmed' || $data->booking_status == 'Non-Refundable')
                 {
                 ?>  
                    
                 <div class="col-md-4 col-sm-12 mt-3 mb-5">
                 
                     <a href="javascript:;" data-toggle="modal" data-target="#exampleModal" class="btn" style="background-color:#d2b254; color:white;">Cancellation</a>
           
                     
                     
                 
            
                 </div>
                 <?php
                 
                 }
                 ?>
                 
                  </section>
                      
                  
                  <!--apply for umrah visa-->
               </div>
               <!--Sidrbar start-->
               
           
               <div class="col-md-4 col-sm-12">
                  <div class="v-heading-icon clearfix mt-3" style="background: #ae8c32" >
                     <div class="float-left">
                        <img src="{{asset('public/admin_package/frontend/images/lead.png') }}">
                     </div>
                     <div class="v-heading-icon-title float-left" style="">
                        <h3 style="font-size: 24px;margin-top: 7px;color: #fff;">Lead Passenger Details</h3>
                     </div>
                  </div>
                  
                  
                  <div class="clearfix v-section-info" style="padding: 5px 10px;border: 1px solid #5d646d;">
                      
                      <?php
                      
                      $lead_passenger_details=$data->lead_passenger_details;
                      $lead_passenger_details=json_decode($lead_passenger_details);
                      
                      ?>
                      
                      
                     <ul class="list-items list-items-3 list-items-4  clearfix" >
                        <!--<li>-->
                        <!--   <span class="text-black font-weight-bold">Passport No:</span> <?php print_r($lead_passenger_details->lead_passport_no); ?>-->
                        <!--   <p class="f-20 text-black font-weight-bold"></p>-->
                        <!--</li>-->
                        <!--<li><span class="text-black font-weight-bold">Nationality:</span></li>-->
                        <li><span class="text-black font-weight-bold">Full Name:</span><?php echo $lead_passenger_details->lead_first_name . ' '. $lead_passenger_details->lead_last_name;  ?>
                        <p class="f-20 text-black font-weight-bold"></p>
                        </li>
                        <li><span class="text-black font-weight-bold">Title:</span><?php print_r($lead_passenger_details->lead_title); ?>
                         <p class="f-20 text-black font-weight-bold"></p>
                        </li>
                      
                        <li class="d-block">
                           <div class="row">
                              <div class="col-sm-5">
                                 <span class="text-black font-weight-bold">Phone Number:</span>
                              </div>
                              <div class="col-sm-7">
                               
                                 <p class=""><?php print_r($lead_passenger_details->lead_phone); ?></p>
                              </div>
                           </div>
                        </li>
                        
                        <li class="d-block">
                           <div class="row">
                              <div class="col-sm-5">
                                 <span class="text-black font-weight-bold">Email:</span>
                                 
                              </div>
                              <div class="col-sm-7">
                             
                                 <p class=""><?php print_r($lead_passenger_details->lead_email); ?></p>
                              </div>
                           </div>
                        </li>
                     </ul>
                  </div>
                 
                  <!-- end icon-box -->
                  <?php
                  $travellandaSelectionRS=$data->checkavailability_again_rs;
                     $travellandaSelectionRS=json_decode($travellandaSelectionRS);
                     
                  if(isset($travellandaSelectionRS[0]->Rooms->Room->RoomPrice))
                     {
                       $grand_total=$travellandaSelectionRS[0]->Rooms->Room->RoomPrice;  
                     }
                     else
                     {
                  $grand_total=0;
                  
                  foreach($travellandaSelectionRS[0]->Rooms->Room as $travellandaSelectionRS)
                  {
                      $grand_total= $grand_total + $travellandaSelectionRS->RoomPrice;
                  }
                     }
                  
                  ?>
                  
                  <div class="vochure-sidebar-title mt-5 text-center">
                     <h3>Grand Total</h3>
                  </div>
                  <ul class="list-items list-items-2 clearfix" >
                     <div class="grand-total">
                         
                         <?php
                         
                         $currency=Session::get('currency');
                              echo $currency; 
                         ?>
                         {{$grand_total ?? ''}}
                        <li class="text-black font-weight-bold"></li>
                     </div>
                  </ul>
                
                 
                
                  <div class="vochure-sidebar-title mt-5 text-center">
                     <h3>Contact Information</h3>
                  </div>
                  <ul class="list-items list-items-5  clearfix">
                     <li>
                        <p class="text-black font-weight-bold">Feel free to contact us any time.</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Phone:</span>
                        <p>0121 777 2522</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Email:</span>
                        <p>info@alhijaztours.net</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Address:</span>
                        <p>1a Nansen Road Sparkhill
Birmingham B11 4DR UK</p>
                     </li>
                    
                  </ul>
              
               </div>
            </div>
         </div>
      </div>
      
      <?php
      }
      if($data->provider == 'hotelbeds')
      {
      ?>
      
      <div class="vochure-content">
         <div class="container">
            <div class="button-group-voucher" style="display: flex; justify-content: flex-end;">
               <div class="text-right mt-3 mr-2">
                  <button type="submit" class="btn btn-secondary" onclick="window.print()">Print  Voucher </button>
               </div>
               <!--<div class="text-right mt-3 mr-2">-->
               <!--   <a href=""><button type="button" class="btn btn-secondary">Invoice</button></a>-->
               <!--</div>-->
               <!--<div class="text-right mt-3">-->
               <!--   <input type="hidden" name="" value="165389811372985682">-->
               <!--   <input type="hidden" id="invoice_number" value="165389811372985682" />-->
               <!--   <a href=""><button type="button" class="btn btn-secondary">Arabic</button></a>-->
               <!--</div>-->
            </div>
            @if(session()->has('message'))
                            <div class="alert alert-success">
                                {{session('message')}}
                            </div>
                            @endif
            <div class="row">
               <div class="col-md-8 col-sm-12">
                     
                  <section class="vochure-detail-section mt-3">
                     <div class="v-heading-icon v-heading-top clearfix">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/icon-tour.png') }}">
                        </div>
                        <div class="v-heading-icon-title float-left">
                           <h2></h2>
                        </div>
                     </div>
                     <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Hotel Information</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                     
                     <?php
                     
                      $apiKey = '4b11b3c941ea25825a4de05ec398c4ab';
        $secret = 'afe693d5e4';
    
        $signature = hash("sha256", $apiKey.$secret.time());                                            
            
     $curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.hotelbeds.com/hotel-content-api/1.0/'.$hotelbeds->booking->hotel->code.'/details?language=ENG&useSecondaryLanguage=False',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Api-key: 4b11b3c941ea25825a4de05ec398c4ab',
    "X-Signature: $signature",
    'Accept: application/json',
    'Accept-Encoding: gzip'
  ),
));

$response = curl_exec($curl);
//echo $response;
curl_close($curl);
$data1 = json_decode($response);
   
        $ho_beds_details = $data1->hotel ?? '';
                     
                     
                     
                    //  print_r($hotelbeds);
                    
                    //  dd($hotelbeds);
                    
                    
                   
                     
                     ?>
                     
                     
                     <div class="clearfix v-section-info">
                        <ul class="list-items list-items-3 list-items-4  clearfix" >
                           <li>
                              <span class="text-black font-weight-bold">Hotel Name:</span>{{$hotelbeds->booking->hotel->name}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                            <li>
                              <span class="text-black font-weight-bold">Hotel City:</span><?php print_r($ho_beds_details->city->content ?? ''); ?>
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           <li>
                              <span class="text-black font-weight-bold">Hotel Address:</span><?php print_r($ho_beds_details->address->content ?? ''); ?>
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           <li>
                              <span class="text-black font-weight-bold">Hotel Category:</span>{{$hotelbeds->booking->hotel->categoryName ?? ''}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                           <li>
                              <span class="text-black font-weight-bold">Booking Status:</span>{{$data->booking_status ?? ""}}
                            
                              
                              
                              
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                           
                           
                           <li>
                              <span class="text-black font-weight-bold">Booking Reference No:</span>{{$hotelbeds->booking->reference ?? ""}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                         
                              <li>
                              <span class="text-black font-weight-bold">Booking Date:</span>{{$hotelbeds->booking->creationDate}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li> 
                          
                          
                           <li><span class="text-black font-weight-bold">Passenger:</span>{{$data->adults}} Adult ,  {{$data->childs}} Children</li>
                           
                           
                           <?php
                            $exchange_price=json_decode($data->exchange_price);
                            $exchange_currency=json_decode($data->exchange_currency);
                            $grand_total=0;
                            foreach($exchange_price as $price)
                            {
                            $grand_total=$price + $grand_total;
                            }
                           ?>
                           
                           
                           <li><span class="text-black font-weight-bold">Hotel Price:</span>{{$exchange_currency[0]}}  {{$grand_total}}</li>
                           
                           
                           
                                                           
                           <li><span class="text-black font-weight-bold">Check-In:</span>{{$hotelbeds->booking->hotel->checkIn}}</li>
                           <li><span class="text-black font-weight-bold">Check-Out:</span>{{$hotelbeds->booking->hotel->checkOut}}</li>
                           
                           
                           
                           <?php
                           
                          $startTimeStamp = strtotime($hotelbeds->booking->hotel->checkIn);                                   
                            $endTimeStamp = strtotime($hotelbeds->booking->hotel->checkOut);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                           
                           
                           ?>
                           
                           
                           
                           <li><span class="text-black font-weight-bold">Duration:</span><?php print_r($numberDays); ?>  Nights</li>
                           
                                  
                         
                        </ul>
                     </div>
                     
                     
                     
                     
                     
                     
                     
                     <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Room Information</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                     
                     <?php
                    
                            $exchange_price=json_decode($data->exchange_price);
                            $exchange_currency=json_decode($data->exchange_currency);
                           
                     $count=1;
                     ?>
                     
                     
                     @foreach($hotelbeds->booking->hotel->rooms as $rooms)
                     
                    
                     
                     <div class="clearfix v-section-info">
                         
                         
                         <div class="v-heading-icon clearfix mt-3">
                        
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Room #<?php echo $count; ?></h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                         
                         
                        <ul class="list-items list-items-3 list-items-4  clearfix" >
                            
                           <li>
                              <span class="text-black font-weight-bold">Room Name:</span>{{$rooms->name}}
                              
                              
                           </li>
                            <li>
                             
                              <span class="text-black font-weight-bold">Room code:</span>{{$rooms->code}}
                             
                              
                           </li>
                           <li>
                             
                              <span class="text-black font-weight-bold">Room Status:</span>{{$rooms->status}}
                             
                              
                           </li>
                           
                           @foreach($rooms->rates as $rates)
                            <?php
                     
                     foreach($exchange_price as $price)
                     {
                     ?>
                           <li>
                              
                              <span class="text-black font-weight-bold">Room Price:</span>{{$exchange_currency[0]}} {{$price}}
                              
                              
                           </li>
                           
                           <li>
                             
                              <span class="text-black font-weight-bold">Board Type:</span>{{$rates->boardName}}
                             
                              
                           </li>
                           <li>
                             
                              <span class="text-black font-weight-bold">Room Quantity:</span>{{$rates->rooms}}
                             
                              
                           </li>
                           <li>
                              
                              <span class="text-black font-weight-bold">Passenger:</span>{{$rates->adults}} Adult , {{$rates->children}} Children
                              
                           </li>
                           <li>
                             
                              <span class="text-black font-weight-bold">Note:</span>
                            {{$rates->rateComments ?? ''}}
                              
                           </li>
                           
                           
                           <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Remarks</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                              
                           </div>
                        </div>
                     </div>  
                            
                            
                            
                            <div>
                               <?php
                               $remark=$hotelbeds->booking->remark;
                              
                              
                               ?>
                               <p><?php  print_r($remark); ?></p>
                           </div>
                            
                            
                            
                            
                          <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Cancellation Policy</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>  
                           
                         <table class="table">
  <thead>
    <tr>
      <th scope="col">From</th>
      
      <th scope="col">Amount</th>
      
    </tr>
  </thead>
  <tbody>
     
      @foreach($rates->cancellationPolicies as $Policy)
    <tr>
      <th scope="row">{{$Policy->from}}</th>
      
      <td>{{$hotelbeds->booking->hotel->currency}}  {{$Policy->amount}}</td>
      
    </tr>
   
    @endforeach
     <?php
    }
    ?>
@endforeach
  </tbody>
</table>  
                           
                           
                                                           
                           
                           
                                  
                         
                        </ul>
                     </div>
                    
                     <?php
                     $count=$count + 1;
                     
                     ?>
                     @endforeach
                     
                  
           
                    
                    
                    
                  
                 <?php
                 
                 if($data->booking_status == 'Confirmed')
                 {
                 ?>  
                    
                 <div class="col-md-4 col-sm-12 mt-3 mb-5">
                 
                     <a href="javascript:;" data-toggle="modal" data-target="#exampleModal_hotel_beds" class="btn" style="background-color:#d2b254; color:white;">Cancellation</a>
           
                     
                     
                 
            
                 </div>
                 <?php
                 
                 }
                 ?>
                 
                  </section>
                      
                  
                  <!--apply for umrah visa-->
               </div>
               <!--Sidrbar start-->
               
           
               <div class="col-md-4 col-sm-12">
                  <div class="v-heading-icon clearfix mt-3" style="background: #ae8c32" >
                     <div class="float-left">
                        <img src="{{asset('public/admin_package/frontend/images/lead.png') }}">
                     </div>
                     <div class="v-heading-icon-title float-left" style="">
                        <h3 style="font-size: 24px;margin-top: 7px;color: #fff;">Lead Passenger Details</h3>
                     </div>
                  </div>
                  
                  
                  <div class="clearfix v-section-info" style="padding: 5px 10px;border: 1px solid #5d646d;">
                      
                      <?php
                      
                      $lead_passenger_details=$data->lead_passenger_details;
                      $lead_passenger_details=json_decode($lead_passenger_details);
                      
                      ?>
                      
                      
                     <ul class="list-items list-items-3 list-items-4  clearfix" >
                        <!--<li>-->
                        <!--   <span class="text-black font-weight-bold">Passport No:</span> <?php print_r($lead_passenger_details->lead_passport_no); ?>-->
                        <!--   <p class="f-20 text-black font-weight-bold"></p>-->
                        <!--</li>-->
                        <!--<li><span class="text-black font-weight-bold">Nationality:</span></li>-->
                        <li><span class="text-black font-weight-bold">Full Name:</span><?php echo $lead_passenger_details->lead_first_name . ' '. $lead_passenger_details->lead_last_name;  ?>
                        <p class="f-20 text-black font-weight-bold"></p>
                        </li>
                        <li><span class="text-black font-weight-bold">Title:</span><?php print_r($lead_passenger_details->lead_title); ?>
                         <p class="f-20 text-black font-weight-bold"></p>
                        </li>
                      
                        <li class="d-block">
                           <div class="row">
                              <div class="col-sm-5">
                                 <span class="text-black font-weight-bold">Phone Number:</span>
                              </div>
                              <div class="col-sm-7">
                               
                                 <p class=""><?php print_r($lead_passenger_details->lead_phone); ?></p>
                              </div>
                           </div>
                        </li>
                        
                        <li class="d-block">
                           <div class="row">
                              <div class="col-sm-5">
                                 <span class="text-black font-weight-bold">Email:</span>
                                 
                              </div>
                              <div class="col-sm-7">
                             
                                 <p class=""><?php print_r($lead_passenger_details->lead_email); ?></p>
                              </div>
                           </div>
                        </li>
                     </ul>
                  </div>
                 
                  <!-- end icon-box -->
                  <?php
                    $exchange_price=json_decode($data->exchange_price);
                            $exchange_currency=json_decode($data->exchange_currency);
                            $grand_total=0;
                            foreach($exchange_price as $price)
                            {
                            $grand_total=$price + $grand_total;
                            }
                  
                  ?>
                  
                  <div class="vochure-sidebar-title mt-5 text-center">
                     <h3>Grand Total</h3>
                  </div>
                  <ul class="list-items list-items-2 clearfix" >
                     <div class="grand-total">
                         {{$exchange_currency[0]}}  {{$grand_total}}
                        
                        <li class="text-black font-weight-bold"></li>
                     </div>
                  </ul>
                
                 
                  <ul class="list-items list-items-5  clearfix">
                     <li>
                        <p class="text-black font-weight-bold">
                            Payable through {{$hotelbeds->booking->hotel->supplier->name}}, acting as agent for the service operating company, details of which can be provided upon request. VAT: {{$hotelbeds->booking->hotel->supplier->vatNumber}} Reference: {{$hotelbeds->booking->reference}}".
                            </p>
                     </li>
                     
                     
                    
                    
                  </ul>
                
                  <div class="vochure-sidebar-title mt-5 text-center">
                     <h3>Contact Information</h3>
                  </div>
                  <ul class="list-items list-items-5  clearfix">
                     <li>
                        <p class="text-black font-weight-bold">Feel free to contact us any time.</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Phone:</span>
                        <p>0121 777 2522</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Email:</span>
                        <p>info@alhijaztours.net</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Address:</span>
                        <p>1a Nansen Road Sparkhill
Birmingham B11 4DR UK</p>
                     </li>
                    
                  </ul>
              
               </div>
            </div>
         </div>
      </div>
      <?php
      }
      
     
       if($data->provider == 'tbo')
      {
           ?>
           
           
           
           <?php
        $tboSelectionRS=json_decode($data->checkavailability_again_rs);  
               
        
        

     $request_data = array(
    'HotelCode' => $tboSelectionRS->HotelResult[0]->HotelCode,
   
    );
//   $searchdata=json_encode($searchdata);
  $curl = curl_init();
     curl_setopt_array($curl, array(
     CURLOPT_URL => 'https://admin.synchronousdigital.com/api/get_tbo_hotel_details',
     CURLOPT_RETURNTRANSFER => true,
     CURLOPT_ENCODING => '',
     CURLOPT_MAXREDIRS => 10,
     CURLOPT_TIMEOUT => 0,
     CURLOPT_FOLLOWLOCATION => true,
     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
     CURLOPT_CUSTOMREQUEST => 'POST',
     CURLOPT_POSTFIELDS =>  $request_data,
     CURLOPT_HTTPHEADER => array(
        'Cookie: laravel_session=gnq21xtzzbBtgOgSa0iVWPIX9vSDzHcKrUozAnSL'
     ),
     ));
  
     $response = curl_exec($curl);
     curl_close($curl);
     $tbo_hotel_detail= $response; 
     $tbo_hotel_detail=json_decode($tbo_hotel_detail);
    //  print_r($tbo_hotel_detail); 
     
     
     $tbo_hotel_detail=$tbo_hotel_detail->data;
    
     
     $slug='tbo';
    // print_r($image);die();
     
     
     
    ?>
      
      
      
      
      
      
      
      
      <?php
           $tboBookingRS=json_decode($data->booking_rs);  
$ConfirmationNumber=$tboBookingRS->ConfirmationNumber;
                //  print_r($tboBookingRS);
                
                $tbo_BookingDetail_rs=json_decode($data->tbo_BookingDetail_rs);
          ?>
          
         
         
                 
          <div class="container">
         <div class="row">
            <div class="col-12 col-md-12">
               <section class="modal_umrah_tech">
                  <div class="modal fade" id="exampleModal_hotel_tbo" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                     <div class="modal-dialog modal-md">
                        <div class="modal-content">
                           <div class="modal-header justify-content-center">
                           </div>
                           <div class="modal-body">
                              <div class="container">
                                 <div class="row">
                                    <div class="col-12 col-md-12 text-center">
                                       <h1>Are You Sure!</h1>
                                       <h4>Your Reservation will be Cancelled By doing this Action</h4>
                                    </div>
                                
                                 </div>
                            
<form class="g-3" method="post"  action="{{URL::to('admin/booking_cancle')}}/{{$tboBookingRS->ConfirmationNumber}}/{{$data->provider}}">
           {{ csrf_field() }}
  <div class="row">
  <div class="col-md-12">
    <label for="inputPassword4" class="form-label">Total Amount</label>
    
    
    <?php
                  $grand_total=0;
                 foreach($tbo_BookingDetail_rs->BookingDetail->Rooms as $roomDetailsIn)
                 {
                     $grand_total=$grand_total + $roomDetailsIn->TotalFare;
                 }
                  
                  ?>
    
    
    <input type="text" class="form-control" value='<?php 
    print_r($tbo_BookingDetail_rs->BookingDetail->Rooms[0]->Currency); 
    
       print_r($grand_total);  ?>'  name="total_amount" >
    
    
    <input type="hidden" value= "{{$ConfirmationNumber}}" name="confirmationCode">
  </div>
      </div>                            
            <div class="modal-footer text-center">
                              <button  type="submit" name="submit" class="btn btn-secondary">Submit</button>
                           </div>                        
      </form> 
                              </div>
                           </div>
                           
                        </div>
                     </div>
                  </div>
               </section>
            </div>
         </div>
      </div>
      
      
      
      
      
      
      
      
      <div class="vochure-content">
         <div class="container">
            <div class="button-group-voucher" style="display: flex; justify-content: flex-end;">
               <div class="text-right mt-3 mr-2">
                  <button type="submit" class="btn btn-secondary" onclick="window.print()">Print  Voucher </button>
               </div>
               <!--<div class="text-right mt-3 mr-2">-->
               <!--   <a href=""><button type="button" class="btn btn-secondary">Invoice</button></a>-->
               <!--</div>-->
               <!--<div class="text-right mt-3">-->
               <!--   <input type="hidden" name="" value="165389811372985682">-->
               <!--   <input type="hidden" id="invoice_number" value="165389811372985682" />-->
               <!--   <a href=""><button type="button" class="btn btn-secondary">Arabic</button></a>-->
               <!--</div>-->
            </div>
            <div class="row">
               <div class="col-md-8 col-sm-12">
                     
                  <section class="vochure-detail-section mt-3">
                     <div class="v-heading-icon v-heading-top clearfix">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/icon-tour.png') }}">
                        </div>
                        <div class="v-heading-icon-title float-left">
                           <h2></h2>
                        </div>
                     </div>
                     <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Hotel Information</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                     
                   
                     
                      <?php
                           
                           $startTimeStamp = strtotime($data->check_in);                                   
                            $endTimeStamp = strtotime($data->check_out);  
                            $totalFare= Session::get('roomDetailsIn->TotalFare');
                            

                                                                                    
                           
                           ?>
                     
                     <div class="clearfix v-section-info">
                        <ul class="list-items list-items-3 list-items-4  clearfix" >
                           <li>
                              <span class="text-black font-weight-bold">Hotel Name:</span>{{$tbo_BookingDetail_rs->BookingDetail->HotelDetails->HotelName ?? ''}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                            <li>
                              <span class="text-black font-weight-bold">Hotel Address:</span>{{$tbo_hotel_detail->address}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                            <li>
                              <span class="text-black font-weight-bold">Country Name:</span>{{$tbo_hotel_detail->country_name}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                            <li>
                              <span class="text-black font-weight-bold">City:</span>{{$tbo_BookingDetail_rs->BookingDetail->HotelDetails->City ?? ''}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                             <li>
                              <span class="text-black font-weight-bold">Hotel Ratings :</span>{{$tbo_BookingDetail_rs->BookingDetail->HotelDetails->Rating ?? ''}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                           
                           <li>
                              <span class="text-black font-weight-bold">Booking Status:</span>{{$data->booking_status ?? ''}}
                            
                              
                              
                              
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                           
                           
                           <li>
                              <span class="text-black font-weight-bold">Booking Confirmation No:</span>{{$tbo_BookingDetail_rs->BookingDetail->ConfirmationNumber ?? ''}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                            <li>
                              <span class="text-black font-weight-bold">Invoice Number:</span>{{$tbo_BookingDetail_rs->BookingDetail->InvoiceNumber ?? ''}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                         
                              <li>
                              <span class="text-black font-weight-bold">Booking Date:</span>{{$tbo_BookingDetail_rs->BookingDetail->BookingDate ?? ''}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li> 
                          
                          
                           <li><span class="text-black font-weight-bold">Passenger:</span>Adults {{$data->adults}} , Child {{$data->childs}} </li>
                           
                           
                           
                           <li><span class="text-black font-weight-bold">Hotel Price:</span> USD {{$totalFare ?? ''}} </li>
                           
                           
                                                           
                           <li><span class="text-black font-weight-bold">Check-In:</span>{{$data->check_in}}</li>
                           <li><span class="text-black font-weight-bold">Check-Out:</span>{{$data->check_out}}</li>
                           
                            <?php
                           
                           $startTimeStamp = strtotime($data->check_in);                                   
                            $endTimeStamp = strtotime($data->check_out);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                        //   print_r($travellandaSelectionRS);die();
                           
                           ?>
                           
                          
                           
                           
                           <li><span class="text-black font-weight-bold">Duration:</span>{{$numberDays}}  Nights</li>
                           
                           
                           
                                  
                         
                        </ul>
                     </div>
                     
                  
                     
                     
                     
                     
                     
                     
                     
                     <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Room Information</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                     
                   
                     
                     
                    
                     
                     <div class="clearfix v-section-info">
                         
                         
                         
                     
                     
                         
                       
                        <ul class="list-items list-items-3 list-items-4  clearfix" >
                            
                            <?php
                            $count_room=1;
                            ?>
                              @foreach($tbo_BookingDetail_rs->BookingDetail->Rooms as $roomDetailsIn)
                              
                              
                         
                         @php Session::put('roomDetailsIn->TotalFare', $roomDetailsIn->TotalFare) @endphp
                            <div class="v-heading-icon clearfix mt-3">
                             
                             @php
                             
                              $roomDetail= $data->checkavailability_again_rs;
                           $roomDetails= json_decode($roomDetail);
                           
                           
                  
               @endphp
                        
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Room #<?php print_r($count_room); ?></h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                           <li>
                              <span class="text-black font-weight-bold">Room Name:</span><?php print_r($roomDetailsIn->Name[0]); ?>
                              
                              
                           </li>
                            <li>
                             
                              <span class="text-black font-weight-bold">Room code:</span><?php print_r($roomDetailsIn->Inclusion); ?>
                             
                              
                           </li>
                           <li>
                             
                              <span class="text-black font-weight-bold">Room Quantity:</span><?php print_r($data->rooms); ?>
                             
                              
                           </li>
                           
                       
                           
                           
                           <li>

                              <span class="text-black font-weight-bold">Total Fare: </span> USD {{$roomDetailsIn->TotalFare ?? ''}} 
                              
                              
                           </li>
                           
                           
                           <li>
                             
                              <span class="text-black font-weight-bold">Board Type:</span>  <?php print_r($roomDetailsIn->MealType); ?>
                             
                              
                           </li>
                           <li>
                              
                              <span class="text-black font-weight-bold">Passenger: </span>Adults {{$data->adults}} , Child {{$data->childs}}
                              
                           </li>
                           
                          
                           <li>
                             
                              <span class="text-black font-weight-bold">Note:</span>
                               @foreach($tboSelectionRS->HotelResult[0]->RateConditions as $RateConditionsIn)
                           <?php print_r($RateConditionsIn)?>
                              @endforeach
                           
                            
                              
                           </li>
                           
                          
                           
                           
                           
                            
                          <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Cancellation Policy</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>  
                           
                         <table class="table">
  <thead>
      
      
    <tr>
        
      <th scope="col">FromDate</th>
      
      <th scope="col">Charge Type</th>
       <th scope="col">Cancellation Charge</th>
      
    </tr>
   
  </thead>
  <tbody>
      <?php
      
      
      foreach($roomDetailsIn->CancelPolicies as $CancelPolicies)
      {
      ?>
     
    <tr>
      <th scope="row">{{$CancelPolicies->FromDate}}</th>
      
      <td>{{$CancelPolicies->ChargeType}}</td>
      <td>USD {{$CancelPolicies->CancellationCharge}}</td>
      
    </tr>

<?php
}
?>

  </tbody>
</table>  
                           
                           
                                                           
                           <?php
                           
                              
                              
                           $count_room=$count_room+1;
                           
                           ?>
                           
                            @endforeach  
                            
                         
                        </ul>
                        
                       
                       
                     </div>
                    
                     
           
                    
                    
                    
                  
                 <?php
                 
                 if($data->booking_status == 'Confirmed')
                 {
                 ?>  
                    
                 <div class="col-md-4 col-sm-12 mt-3 mb-5">
                 
                     <a href="javascript:;" data-toggle="modal" data-target="#exampleModal_hotel_tbo" class="btn" style="background-color:#d2b254; color:white;">Cancellation</a>
           
                     
                     
                 
            
                 </div>
                 <?php
                 
                 }
                 ?>
                 
                  </section>
                      
                  
                  <!--apply for umrah visa-->
               </div>
               <!--Sidrbar start-->
               @php
               
               $leadPassenger= $data->lead_passenger_details;
               $leadPassengerDetail= json_decode($leadPassenger);
                 
               
               
               @endphp
               

               
           
               <div class="col-md-4 col-sm-12">
                  <div class="v-heading-icon clearfix mt-3" style="background: #ae8c32" >
                     <div class="float-left">
                        <img src="{{asset('public/admin_package/frontend/images/lead.png') }}">
                     </div>
                     <div class="v-heading-icon-title float-left" style="">
                        <h3 style="font-size: 24px;margin-top: 7px;color: #fff;">Lead Passenger Details</h3>
                     </div>
                  </div>
                  
                
                  <div class="clearfix v-section-info" style="padding: 5px 10px;border: 1px solid #5d646d;">
                       <ul class="list-items list-items-3 list-items-4  clearfix" >
                           
                          
                           
                        <li>
                           <span class="text-black font-weight-bold">Passport No:</span>
                           <p class="f-20 text-black font-weight-bold">{{$leadPassengerDetail->lead_passport_no}}</p>
                        </li>
                        <li><span class="text-black font-weight-bold">Nationality:</span>{{$leadPassengerDetail->lead_passport_no}}</li>
                        <li><span class="text-black font-weight-bold">Full Name:</span>
                        {{$leadPassengerDetail->lead_first_name}}&nbsp;{{$leadPassengerDetail->lead_last_name}}
                        <p class="f-20 text-black font-weight-bold"></p>
                        </li>
                        <li><span class="text-black font-weight-bold">Title:</span>
                        {{$leadPassengerDetail->lead_title}}
                         <p class="f-20 text-black font-weight-bold"></p>
                        </li>
                      
                        <li class="d-block">
                           <div class="row">
                              <div class="col-sm-5">
                                  
                                 <span class="text-black font-weight-bold">Phone Number:</span>
                                <p> </p>
                              </div>
                              <div class="col-sm-7">
                               
                                 <p class="">{{$leadPassengerDetail->lead_phone}}</p>
                              </div>
                           </div>
                        </li>
                        
                        <li class="d-block">
                           <div class="row">
                              <div class="col-sm-5">
                                 <span class="text-black font-weight-bold">Email:</span>
                                 
                                 
                              </div>
                              
                             
                              
                              
                              <div class="col-sm-7">
                             
                                 <p class="">{{$leadPassengerDetail->lead_email}}</p>
                              </div>
                           </div>
                        </li>
                     </ul>
                  </div>
                 
                  <!-- end icon-box -->
                  <?php
                  
                  $grand_total=0;
               
                  ?>
                  
                  <div class="vochure-sidebar-title mt-5 text-center">
                     <h3>Grand Total</h3>
                  </div>
                  <ul class="list-items list-items-2 clearfix" >
                     <div class="grand-total">
                         USD   <?php print_r($roomDetailsIn->TotalFare); ?>
                       
                        
                        <li class="text-black font-weight-bold"></li>
                     </div>
                  </ul>
                  
                 
                
                 
                
                  <div class="vochure-sidebar-title mt-5 text-center">
                     <h3>Contact Information</h3>
                  </div>
                  <ul class="list-items list-items-5  clearfix">
                     <li>
                        <p class="text-black font-weight-bold">Feel free to contact us any time.</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Phone:</span>
                        <p>0121 777 2522</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Email:</span>
                        <p>info@alhijaztours.net</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Address:</span>
                        <p>1a Nansen Road Sparkhill
Birmingham B11 4DR UK</p>
                     </li>
                    
                  </ul>
              
               </div>
            </div>
         </div>
      </div>
      <?php
      }
      
      
      if($data->provider == 'ratehawk')
      {
           ?>
           
          
           
           <?php
       
      $ratehawk_details_rs=$data->ratehawk_details_rs;
      $ratehawk_details_rs=json_decode($ratehawk_details_rs);
      $ratehawk_selection_rs=$data->ratehawk_selection_rs;
      $ratehawk_selection_rs=json_decode($ratehawk_selection_rs);
      $ratehawk_partner_order_id=$ratehawk_selection_rs->data->partner_order_id ?? '';
      
      
      
      
      $ratehawk_details_rs1=$data->ratehawk_details_rs1;
      $ratehawk_details_rs1=json_decode($ratehawk_details_rs1);
      
      $ratehawk_selection_rq_arr=$data->ratehawk_selection_rq_arr;
            $ratehawk_selection_rq_arr=json_decode($ratehawk_selection_rq_arr);
            $ratehawk_room_rate=[];
            foreach($ratehawk_selection_rq_arr as $ratehawk_selection_rq_arr1)
            {
                foreach($ratehawk_details_rs1->hotels[0]->rates as $ratehawk_details_rs1)
                {
                    if($ratehawk_details_rs1->book_hash == $ratehawk_selection_rq_arr1->book_hash)
                    {
                        $ratehawk_room_rate[]=$ratehawk_details_rs1;
                    }
                }
            }
      
      
     
    ?>
      
      
      
      
      
      
      
      
      
          
         
         
                 
          <div class="container">
         <div class="row">
            <div class="col-12 col-md-12">
               <section class="modal_umrah_tech">
                  <div class="modal fade" id="exampleModal_hotel_tbo" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                     <div class="modal-dialog modal-md">
                        <div class="modal-content">
                           <div class="modal-header justify-content-center">
                           </div>
                           <div class="modal-body">
                              <div class="container">
                                 <div class="row">
                                    <div class="col-12 col-md-12 text-center">
                                       <h1>Are You Sure!</h1>
                                       <h4>Your Reservation will be Cancelled By doing this Action</h4>
                                    </div>
                                
                                 </div>
                            
<form class="g-3" method="post"  action="{{URL::to('booking_cancle')}}/{{$ratehawk_partner_order_id}}/{{$data->provider}}">
           @csrf
  <div class="row">
  <div class="col-md-12">
    <label for="inputPassword4" class="form-label">Total Amount</label>
     <?php
      $ratehawk_details_rs1=$data->ratehawk_details_rs1;
      $ratehawk_details_rs1=json_decode($ratehawk_details_rs1);
      $grand_total=0;
                  foreach($ratehawk_room_rate as $rates)
                  {
        foreach($rates->payment_options->payment_types as $payment_types)
          {
              
              $grand_total= $payment_types->amount + $grand_total;
          }
      }
                  
                  ?>
    <input type="text" class="form-control" value='<?php print_r($ratehawk_details_rs1->hotels[0]->rates[0]->payment_options->payment_types[0]->currency_code ?? '') ?>   {{$grand_total}}'>
    
    
    <input type="hidden" value= "{{$grand_total}}" name="confirmationCode">
  </div>
      </div>                            
            <div class="modal-footer text-center">
                              <button  type="submit" name="submit" class="btn btn-secondary">Submit</button>
                           </div>                        
      </form> 
                              </div>
                           </div>
                           
                        </div>
                     </div>
                  </div>
               </section>
            </div>
         </div>
      </div>
      
      
      
      
      
      
      
      
      <div class="vochure-content">
         <div class="container">
            <div class="button-group-voucher" style="display: flex; justify-content: flex-end;">
               <div class="text-right mt-3 mr-2">
                  <button type="submit" class="btn btn-secondary" onclick="window.print()">Print  Voucher </button>
               </div>
               <!--<div class="text-right mt-3 mr-2">-->
               <!--   <a href=""><button type="button" class="btn btn-secondary">Invoice</button></a>-->
               <!--</div>-->
               <!--<div class="text-right mt-3">-->
               <!--   <input type="hidden" name="" value="165389811372985682">-->
               <!--   <input type="hidden" id="invoice_number" value="165389811372985682" />-->
               <!--   <a href=""><button type="button" class="btn btn-secondary">Arabic</button></a>-->
               <!--</div>-->
            </div>
            <div class="row">
               <div class="col-md-8 col-sm-12">
                     
                  <section class="vochure-detail-section mt-3">
                     <div class="v-heading-icon v-heading-top clearfix">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/icon-tour.png') }}">
                        </div>
                        <div class="v-heading-icon-title float-left">
                           <h2></h2>
                        </div>
                     </div>
                     <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Hotel Information</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                     
                   
                     
                      <?php
                           
                          

                                                                                    
                           
                           ?>
                     
                     <div class="clearfix v-section-info">
                        <ul class="list-items list-items-3 list-items-4  clearfix" >
                           <li>
                              <span class="text-black font-weight-bold">Hotel Name:</span>{{$ratehawk_details_rs->name}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                            <li>
                              <span class="text-black font-weight-bold">Hotel Address:</span>{{$ratehawk_details_rs->address}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                            <li>
                              <span class="text-black font-weight-bold">Country Name:</span>
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>{{$ratehawk_details_rs->region->name}}
                           </li>
                           
                            <li>
                              <span class="text-black font-weight-bold">City:</span>{{$ratehawk_details_rs->region->name}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                             <li>
                              <span class="text-black font-weight-bold">Hotel Ratings :</span>{{$ratehawk_details_rs->star_rating}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                           
                           <li>
                              <span class="text-black font-weight-bold">Booking Status:</span>{{$data->booking_status}}
                            
                              
                              
                              
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                           
                           
                           <li>
                              <span class="text-black font-weight-bold">Booking Confirmation No:</span>{{$data->invoice_no}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                         
                              <li>
                              <span class="text-black font-weight-bold">Booking Date:</span>{{$data->created_at}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li> 
                          
                          
                           <li><span class="text-black font-weight-bold">Passenger:</span>Adults  {{$data->adults}}, Child  {{$data->childs}}</li>
                           
                           <li><span class="text-black font-weight-bold">Hotel Price:</span></li>
                           
                           
                                                           
                           <li><span class="text-black font-weight-bold">Check-In:</span>{{$data->check_in}}</li>
                           <li><span class="text-black font-weight-bold">Check-Out:</span>{{$data->check_out}}</li>
                           
                            <?php
                           
                           $startTimeStamp = strtotime($data->check_in);                                   
                            $endTimeStamp = strtotime($data->check_out);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                        //   print_r($travellandaSelectionRS);die();
                           
                           ?>
                           
                          
                           
                           
                           <li><span class="text-black font-weight-bold">Duration:</span>{{$numberDays}}  Nights</li>
                           
                           
                           
                                  
                         
                        </ul>
                     </div>
                     
                  
                     
                     
                     
                     
                     
                     
                     
                     <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Room Information</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                     
                   
                     
                     
                    
                     
                     <div class="clearfix v-section-info">
                         
                         
                         <div class="v-heading-icon clearfix mt-3">
                             
                            
                        
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Room </h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                     
                     
                         
                       
                        <ul class="list-items list-items-3 list-items-4  clearfix" >
                            
                       <?php
                       
      
      
        $exchange_price=json_decode($data->exchange_price);
        $exchange_currency=json_decode($data->exchange_currency);
        
      
                       foreach($ratehawk_room_rate as $rates)
                       {
                           
                       foreach($exchange_price as $price)
                       {
                           
                      
                       
                       ?>
                            
                           <li>
                              <span class="text-black font-weight-bold">Room Name:</span>{{$rates->room_name}}
                              
                              
                           </li>
                            <li>
                             
                              <span class="text-black font-weight-bold">Room book:</span>{{$rates->book_hash}}
                             
                              
                           </li>
                           <li>
                             
                              <span class="text-black font-weight-bold">Room Quantity:</span>{{$data->rooms}}
                             
                              
                           </li>
                           
                        
                           
                           <li>

                              <span class="text-black font-weight-bold">Room Price: </span>{{$exchange_currency[0]}} {{$price}}
                              
                              
                           </li>
                           
                           <li>
                             
                              <span class="text-black font-weight-bold">Board Type:</span>  {{$rates->meal}}
                             
                              
                           </li>
                           <li>
                              
                              <span class="text-black font-weight-bold">Passenger: </span>Adults  {{$data->adults}}, Child  {{$data->childs}}
                              
                           </li>
                           
                          
                           <li>
                             
                              <span class="text-black font-weight-bold">Note:</span>
                              
                           
                            
                              
                           </li>
                           
                         
                           
                           
                           
                            
                          <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Cancellation Policy</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>  
                           
                         <table class="table">
  <thead>
      
      
    <tr>
        
      <th scope="col">start_at</th>
      
      <th scope="col">end_at</th>
       <th scope="col">amount_charge</th>
        
      
    </tr>
   
  </thead>
  <tbody>
      <?php
      
      
      
     
          foreach($rates->payment_options->payment_types[0]->cancellation_penalties->policies as $policies)
          {
      ?>
     
    <tr>
      <th scope="row">{{$policies->start_at}}</th>
      
      <td>{{$policies->end_at}}</td>
      <td>{{$rates->payment_options->payment_types[0]->currency_code}} {{$policies->amount_charge}}</td>
      
      
    </tr>

<?php
}

?>

  </tbody>
</table>  
                           
                           
                                                           
      <?php
                       }
                       }
                         ?>                     
                           
                                  
                         
                        </ul>
                        
                       
                       
                     </div>
                    
                     
           
                    
                    
                    
                  
                 <?php
                 
                 if($data->booking_status == 'Confirmed')
                 {
                 ?>  
                    
                 <div class="col-md-4 col-sm-12 mt-3 mb-5">
                 
                     <a href="javascript:;" data-toggle="modal" data-target="#exampleModal_hotel_tbo" class="btn" style="background-color:#d2b254; color:white;">Cancellation</a>
           
                     
                     
                 
            
                 </div>
                 <?php
                 
                 }
                 ?>
                 
                  </section>
                      
                  
                  <!--apply for umrah visa-->
               </div>
               <!--Sidrbar start-->
               
               

               
           
               <div class="col-md-4 col-sm-12">
                  <div class="v-heading-icon clearfix mt-3" style="background: #ae8c32" >
                     <div class="float-left">
                        <img src="{{asset('public/admin_package/frontend/images/lead.png') }}">
                     </div>
                     <div class="v-heading-icon-title float-left" style="">
                        <h3 style="font-size: 24px;margin-top: 7px;color: #fff;">Lead Passenger Details</h3>
                     </div>
                  </div>
                  <?php
                  
                  $lead_passenger_details=$data->lead_passenger_details;
                  $lead_passenger_details=json_decode($lead_passenger_details);
                  ?>
                
                  <div class="clearfix v-section-info" style="padding: 5px 10px;border: 1px solid #5d646d;">
                       <ul class="list-items list-items-3 list-items-4  clearfix" >
                        <li>
                           <span class="text-black font-weight-bold">Passport No:</span>
                           <p class="f-20 text-black font-weight-bold"></p>
                        </li>
                        <li><span class="text-black font-weight-bold">Nationality:</span></li>
                        <li><span class="text-black font-weight-bold">Full Name:</span>
                        &nbsp;{{$lead_passenger_details->lead_first_name}} {{$lead_passenger_details->lead_last_name}}
                        <p class="f-20 text-black font-weight-bold"></p>
                        </li>
                        <li><span class="text-black font-weight-bold">Title:</span>{{$lead_passenger_details->lead_title}}
                        
                         <p class="f-20 text-black font-weight-bold"></p>
                        </li>
                      
                        <li class="d-block">
                           <div class="row">
                              <div class="col-sm-5">
                                  
                                 <span class="text-black font-weight-bold">Phone Number:</span>
                                <p> </p>
                              </div>
                              <div class="col-sm-7">
                               
                                 <p class="">{{$lead_passenger_details->lead_phone}}</p>
                              </div>
                           </div>
                        </li>
                        
                        <li class="d-block">
                           <div class="row">
                              <div class="col-sm-5">
                                 <span class="text-black font-weight-bold">Email:</span>
                                 
                                 
                              </div>
                              
                             
                              
                              
                              <div class="col-sm-7">
                             
                                 <p class="">{{$lead_passenger_details->lead_email}}</p>
                              </div>
                           </div>
                        </li>
                     </ul>
                  </div>
                 
                  <!-- end icon-box -->
                  <?php
                   $exchange_price=json_decode($data->exchange_price);
        $exchange_currency=json_decode($data->exchange_currency);
                  $ratehawk_details_rs1=$data->ratehawk_details_rs1;
      $ratehawk_details_rs1=json_decode($ratehawk_details_rs1);
      $grand_total=0;
                  foreach($exchange_price as $price)
                  {
        
              
              $grand_total= $price + $grand_total;
          
      }
                  
                  ?>
                  
                  <div class="vochure-sidebar-title mt-5 text-center">
                     <h3>Grand Total</h3>
                  </div>
                  <ul class="list-items list-items-2 clearfix" >
                     <div class="grand-total">
                   
                    <?php print_r($exchange_currency[0] ?? '') ?>   {{$grand_total}}
                        
                        <li class="text-black font-weight-bold"></li>
                     </div>
                  </ul>
                  
                 
                
                 
                
                  <div class="vochure-sidebar-title mt-5 text-center">
                     <h3>Contact Information</h3>
                  </div>
                  <ul class="list-items list-items-5  clearfix">
                     <li>
                        <p class="text-black font-weight-bold">Feel free to contact us any time.</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Phone:</span>
                        <p>0121 777 2522</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Email:</span>
                        <p>info@alhijaztours.net</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Address:</span>
                        <p>1a Nansen Road Sparkhill
Birmingham B11 4DR UK</p>
                     </li>
                    
                  </ul>
              
               </div>
            </div>
         </div>
      </div>
      <?php
      }
      
       if($data->provider == 'hotels')
      {
           ?>
           
          
           
           <?php
       
      $hotel_checkavailability=$data->checkavailability_rq;
      $hotel_checkavailability=json_decode($hotel_checkavailability);
      $rooms_checkavailability=$data->checkavailability_again_rs;
      $rooms_checkavailability=json_decode($rooms_checkavailability);
      $rooms_checkavail=$data->checkavailability_rs;
      $rooms_checkavail=json_decode($rooms_checkavail);
      
     
    ?>
      
      
 
      
      
      <div class="vochure-content">
         <div class="container">
            <div class="button-group-voucher" style="display: flex; justify-content: flex-end;">
               <div class="text-right mt-3 mr-2">
                  <button type="submit" class="btn btn-secondary" onclick="window.print()">Print  Voucher </button>
               </div>
               <!--<div class="text-right mt-3 mr-2">-->
               <!--   <a href=""><button type="button" class="btn btn-secondary">Invoice</button></a>-->
               <!--</div>-->
               <!--<div class="text-right mt-3">-->
               <!--   <input type="hidden" name="" value="165389811372985682">-->
               <!--   <input type="hidden" id="invoice_number" value="165389811372985682" />-->
               <!--   <a href=""><button type="button" class="btn btn-secondary">Arabic</button></a>-->
               <!--</div>-->
            </div>
            <div class="row">
               <div class="col-md-8 col-sm-12">
                     
                  <section class="vochure-detail-section mt-3">
                     <div class="v-heading-icon v-heading-top clearfix">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/icon-tour.png') }}">
                        </div>
                        <div class="v-heading-icon-title float-left">
                           <h2></h2>
                        </div>
                     </div>
                     <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Hotel Information</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                     
                   
                     
                      
                     
                     <div class="clearfix v-section-info">
                        <ul class="list-items list-items-3 list-items-4  clearfix" >
                           <li>
                              <span class="text-black font-weight-bold">Hotel Name:</span>{{$hotel_checkavailability->property_name ?? ''}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                            <li>
                              <span class="text-black font-weight-bold">Hotel Address:</span>{{$hotel_checkavailability->property_address ?? ''}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                            <li>
                              <span class="text-black font-weight-bold">Country Name:</span>
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>{{$hotel_checkavailability->property_country ?? ''}}
                           </li>
                           
                            <li>
                              <span class="text-black font-weight-bold">City:</span>{{$hotel_checkavailability->property_city ?? ''}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                             <li>
                              <span class="text-black font-weight-bold">Hotel Ratings :</span>{{$hotel_checkavailability->star_type ?? ''}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                           
                           <li>
                              <span class="text-black font-weight-bold">Booking Status:</span>{{$data->booking_status}}
                            
                              
                              
                              
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                           
                           
                           
                           <li>
                              <span class="text-black font-weight-bold">Invoice No:</span>{{$data->invoice_no}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li>
                         
                              <li>
                              <span class="text-black font-weight-bold">Booking Date:</span>{{$data->created_at}}
                              
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status"></p>
                           </li> 
                          
                          
                           <li><span class="text-black font-weight-bold">Passenger:</span>Adults  {{$data->adults}}, Child  {{$data->childs}}</li>
                           
                           <!--<li><span class="text-black font-weight-bold">Hotel Price:</span></li>-->
                           
                           
                                                           
                           <li><span class="text-black font-weight-bold">Check-In:</span>{{$data->check_in}}</li>
                           <li><span class="text-black font-weight-bold">Check-Out:</span>{{$data->check_out}}</li>
                           
                            <?php
                           
                           $startTimeStamp = strtotime($data->check_in);                                   
                            $endTimeStamp = strtotime($data->check_out);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                        //   print_r($travellandaSelectionRS);die();
                           
                           ?>
                           
                          
                           
                           
                           <li><span class="text-black font-weight-bold">Duration:</span>{{$numberDays}}  Nights</li>
                           
                           
                           
                                  
                         
                        </ul>
                     </div>
                     
                  
                     
                     
                     
                     
                     
                     
                     
                     <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Room Information</h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                     
                   
                     
                     
                    
                     
                     <div class="clearfix v-section-info">
                         
                         
                         
                     
                     
                         
                       
                        <ul class="list-items list-items-3 list-items-4  clearfix" >
                            
                       <?php
                       
   
      
      
      $counter_rooms=1;
   
                       foreach($rooms_checkavailability  as $key => $rooms)
                       {
                           
                      
                       
                       ?>
                       
                       
                       
                       
                       <div class="v-heading-icon clearfix mt-3">
                             
                            
                        
                        <div class="row">
                           <div class="col-md-8">
                              <div class="v-heading-icon-title float-left">
                                 <h3>Room # {{$counter_rooms}} </h3>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                       
                       
                             <li>
                             
                              <span class="font-weight-bold" style="color: red;"><?php if($rooms->rooms_on_request == 1){ echo 'Room On Request';}else{ echo ''; }  ?></span>
                             
                              
                           </li>
                           <li>
                              <span class="text-black font-weight-bold">Room Name:</span>{{$rooms->rooms_name}}
                              
                              
                           </li>
                            <li>
                             
                              <span class="text-black font-weight-bold">Room Meal Type:</span>{{$rooms->rooms_meal_type}}
                             
                              
                           </li>
                          
                            <li>
                             
                              <span class="text-black font-weight-bold">Room View:</span>{{$rooms->room_view}}
                             
                              
                           </li>
                           
                           <li>
                             
                              <span class="text-black font-weight-bold">Room Quantity:</span>{{$rooms->rooms_quantity}}
                             
                              
                           </li>
                           
                        <?php
                        if($rooms->grand_total_price_week_weekend != 0)
                        {
                        
                        ?>
                           
                           <li>

                              <span class="text-black font-weight-bold">Room Price: </span>{{$rooms->currency ?? ''}} {{$rooms->exchange_price_weekdays}}/Per Night
                              
                              
                           </li>
                           <?php
                           
                        }
                        else
                        {
                        ?>
                        <li>

                              <span class="text-black font-weight-bold">Room Price: </span>{{$rooms->currency ?? ''}} {{$rooms->exchange_price_for_all_days}}/Per Night
                              
                              
                              
                           </li>
                        
                        <?php
                        }
                        ?>
                          
                           <li>
                              
                              <span class="text-black font-weight-bold">Passenger: </span>Adults   {{$data->adults}}, Child  {{$data->childs}}
                              
                           </li>
                           
                          
                           <li>
                             
                              <span class="text-black font-weight-bold">Note:</span>
                              
                           {{$rooms->room_description ?? ''}}
                            
                              
                           </li>
                           
                         <?php
                         if(isset($rooms->weekdays))
                         {
                             $weekdays=json_decode($rooms->weekdays);
                              $weekends=json_decode($rooms->weekends);
                         ?>
                           <li>
                               
           <span class="text-black font-weight-bold">Price For Nights:</span>                    
<div class="row">
<?php
$st_date = $data->check_in;
$st_date = date('Y-m-d', strtotime('+1 day', strtotime($st_date)));
$ed_date = $data->check_out;

// $dateMonthYearArr = array();
$st_dateTS = strtotime($st_date);

$ed_dateTS = strtotime($ed_date);
$grand_total_weekdays=0;
$grand_total_weekends=0;
$grand_total_price_all_days=0;
for ($currentDateTS = $st_dateTS; $currentDateTS <= $ed_dateTS; $currentDateTS += (60 * 60 * 24)) {
// use date() and $currentDateTS to format the dates in between
$currentDateStr = date("Y-m-d",$currentDateTS);
$currentDateStr1 = date("l",$currentDateTS);
$dateMonthYearArr[] = $currentDateStr;

$date_formates=date("D,M d",$currentDateTS);
?>
                                   
                                   
                                  
<div class="col-md-3">
<div class="item" style="border: 2px solid #d2b254;border-radius: 5px;margin-right: 2px;padding: 3px;width:100px;text-align: center;">

<?php

print $date_formates;
echo '<br>';
// print $currentDateStr;
// echo '<br>';
// print $currentDateStr1;
// echo '<br>';

  
    if(isset($weekdays))
    {
    foreach($weekdays as $weekday)
    {
        if($weekday == $currentDateStr1)
        {
            if($currentDateStr1 == 'Monday' || $currentDateStr1 == 'Tuesday' || $currentDateStr1 == 'Wednesday'|| $currentDateStr1 == 'Thursday'|| $currentDateStr1 == 'Friday'|| $currentDateStr1 == 'Saturday'|| $currentDateStr1 == 'Sunday')
            {
            $curr=$rooms->currency;
             print_r($curr .' '.$rooms->exchange_price_weekdays);
            
            }
        }
    }

}




  
     if(isset($weekends))
    {
    foreach($weekends as $weekend)
    {
        if($weekend == $currentDateStr1)
        {
             if($currentDateStr1 == 'Monday' || $currentDateStr1 == 'Tuesday' || $currentDateStr1 == 'Wednesday'|| $currentDateStr1 == 'Thursday'|| $currentDateStr1 == 'Friday'|| $currentDateStr1 == 'Saturday'|| $currentDateStr1 == 'Sunday')
            {
           $curr=$rooms->currency;
             print_r($curr .' '.$rooms->exchange_price_weekends);
             
        }
        }
    }
    }



    if($rooms->price_week_type == 'for_all_days')
    {
    $more_price_all_days=$rooms->exchange_price_for_all_days;
    $all_days=array(
        '0'=>'Monday',
        '1'=>'Tuesday',
        '2'=>'Wednesday',
        '3'=>'Thursday',
        '4'=>'Friday',
        '5'=>'Saturday',
        '6'=>'Sunday',
        );
     if(isset($more_price_all_days))
    {
    foreach($all_days as $all_day)
    {
        if($all_day == $currentDateStr1)
        {
             if($currentDateStr1 == 'Monday' || $currentDateStr1 == 'Tuesday' || $currentDateStr1 == 'Wednesday'|| $currentDateStr1 == 'Thursday'|| $currentDateStr1 == 'Friday'|| $currentDateStr1 == 'Saturday'|| $currentDateStr1 == 'Sunday')
            {
            $curr=$rooms->currency;
            
             print_r($curr .' '.$rooms->exchange_price_for_all_days);
             
              
        }
        }
    }
    }
    }





?>
</div> 
</div>
<?php
}
?>
                                  
                                  
                               </div>
                               
                               
                              
                           </li>
                           <?php
                         }
                           ?>
                           
                            
                         
                           
                        
                           
                           
                                                           
      <?php
      $counter_rooms=$counter_rooms+1;
                       
                       }
                       
                       
                         ?>                     
                           
                                  
                         
                        </ul>
                        
                       
                       
                     </div>
                    
                     
           
                    
                    
                    
                  
                 <?php
                 
                 if($data->booking_status == 'Confirmed')
                 {
                 ?>  
                    
                 <div class="col-md-4 col-sm-12 mt-3 mb-5">
                 
                     <a href="javascript:;" data-toggle="modal" data-target="#exampleModal_hotel_tbo" class="btn" style="background-color:#d2b254; color:white;">Cancellation</a>
           
                     
                     
                 
            
                 </div>
                 <?php
                 
                 }
                 ?>
                 
                  </section>
                      
                  
                  <!--apply for umrah visa-->
               </div>
               <!--Sidrbar start-->
               
               

               
           
               <div class="col-md-4 col-sm-12">
                  <div class="v-heading-icon clearfix mt-3" style="background: #ae8c32" >
                     <div class="float-left">
                        <img src="{{asset('public/admin_package/frontend/images/lead.png') }}">
                     </div>
                     <div class="v-heading-icon-title float-left" style="">
                        <h3 style="font-size: 24px;margin-top: 7px;color: #fff;">Lead Passenger Details</h3>
                     </div>
                  </div>
                  <?php
                  
                  $lead_passenger_details=$data->lead_passenger_details;
                  $lead_passenger_details=json_decode($lead_passenger_details);
                  ?>
                
                  <div class="clearfix v-section-info" style="padding: 5px 10px;border: 1px solid #5d646d;">
                       <ul class="list-items list-items-3 list-items-4  clearfix" >
                        <!--<li>-->
                        <!--   <span class="text-black font-weight-bold">Passport No:</span>-->
                        <!--   <p class="f-20 text-black font-weight-bold"></p>-->
                        <!--</li>-->
                        <!--<li><span class="text-black font-weight-bold">Nationality:</span></li>-->
                        <li><span class="text-black font-weight-bold">Full Name:</span>
                        &nbsp;{{$lead_passenger_details->lead_first_name}} {{$lead_passenger_details->lead_last_name}}
                        <p class="f-20 text-black font-weight-bold"></p>
                        </li>
                        <li><span class="text-black font-weight-bold">Title:</span>{{$lead_passenger_details->lead_title}}
                        
                         <p class="f-20 text-black font-weight-bold"></p>
                        </li>
                      
                        <li class="d-block">
                           <div class="row">
                              <div class="col-sm-5">
                                  
                                 <span class="text-black font-weight-bold">Phone Number:</span>
                                <p> </p>
                              </div>
                              <div class="col-sm-7">
                               
                                 <p class="">{{$lead_passenger_details->lead_phone}}</p>
                              </div>
                           </div>
                        </li>
                        
                        <li class="d-block">
                           <div class="row">
                              <div class="col-sm-5">
                                 <span class="text-black font-weight-bold">Email:</span>
                                 
                                 
                              </div>
                              
                             
                              
                              
                              <div class="col-sm-7">
                             
                                 <p class="">{{$lead_passenger_details->lead_email}}</p>
                              </div>
                           </div>
                        </li>
                     </ul>
                  </div>
                 
                  <!-- end icon-box -->
                  <?php
 $rooms_checkavailability=$data->checkavailability_again_rs;
      $rooms_checkavailability=json_decode($rooms_checkavailability);
      $grand_total=0;
                  foreach($rooms_checkavailability as $rates)
                  {
                      if($rates->price_week_type == 'for_all_days')
                      {
                        $grand_total= $rates->grand_total_price_all_days + $grand_total;  
                      }
                      else
                      {
                         $grand_total= $rates->grand_total_price_week_weekend + $grand_total; 
                      }
                      
                      
              
                       
          
      }
                  
                  ?>
                  
                  <div class="vochure-sidebar-title mt-5 text-center">
                     <h3>Grand Total</h3>
                  </div>
                  <ul class="list-items list-items-2 clearfix" >
                     <div class="grand-total">
                   
                    GBP   {{$grand_total ?? '0'}}
                        
                        <li class="text-black font-weight-bold"></li>
                     </div>
                  </ul>
                  
                 
                
                 
                
                  <div class="vochure-sidebar-title mt-5 text-center">
                     <h3>Contact Information</h3>
                  </div>
                  <ul class="list-items list-items-5  clearfix">
                     <li>
                        <p class="text-black font-weight-bold">Feel free to contact us any time.</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Phone:</span>
                        <p>0121 777 2522</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Email:</span>
                        <p>info@alhijaztours.net</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Address:</span>
                        <p>1a Nansen Road Sparkhill
Birmingham B11 4DR UK</p>
                     </li>
                    
                  </ul>
              
               </div>
            </div>
         </div>
      </div>
      <?php
      }
      
      
      ?>
      
  
      <script src="https://umrahtech.com/public/assets/frontend/js/jquery-3.4.1.min.js"></script>
      <script src="https://umrahtech.com/public/assets/frontend/js/jquery-ui.js"></script>
      <script src="https://umrahtech.com/public/assets/frontend/js/popper.min.js"></script>
      <script src="https://umrahtech.com/public/assets/frontend/js/bootstrap.min.js"></script>
      <script src="https://umrahtech.com/public/assets/frontend/js/main.js"></script>
      
   
     
  
     
    
     
      
     
     
      
   </body>
</html>