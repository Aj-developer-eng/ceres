<?php

 $child_count = Session::get('child_searching');
  $hotel_beds_code=Session::get('hotel_beds_code');
 $adult_count1 = Session::get('adult');
 $room_search=Session()->get('room_searching');

   $adult_count=$adult_count1;
   
   $adult_count_travelanda=$adult_count1 + $child_count;
  $slug= Session::get('provider');
    //print_r($slug);die();
    $search_id=Session::get('search_id');
     $other_passenger = Session()->get('other_adults',[]);
     $ratehawk_select_room=Session::get('ratehawk_select_room');
     $country_nationality=Session::get('country_nationality');
// $cart=Session::get('cart');
// dd($ratehawk_select_room);die();

$hotels_checkavailability=Session::get('hotels_checkavailability');
$rooms_checkavailability=Session::get('rooms_checkavailability');

?>

@extends('template/frontend/userdashboard/layout/default')
 @section('content')
                    <!--Add More Passenger Model Start-->
<div class="modal fade" id="exampleModal_other_passenger" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add More Passenger</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <form class="row g-3" method="post"  action="{{URL::to('admin/add_other_passengar')}}">
           @csrf
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">Title</label>
    <select class="form-control" name="title">
        <option value="">Select Title</option>
        <option value="Mr.">Mr.</option>
        <option value="Mrs.">Mrs.</option>
    </select>
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">First Name</label>
    <input type="text" class="form-control" value="{{$other_passengar_decode[0]->other_first_name ?? ''}}"  name="other_first_name" >
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">Last Name</label>
    <input type="text" class="form-control" value="{{$other_passengar_decode[0]->other_last_name ?? ''}}"  name="other_last_name">
  </div>
  <div class="col-md-6">
    <label for="inputEmail4"  class="form-label">Nationality</label>
    <select class="form-control selectpicker" data-live-search="true" name="other_nationality">
         <option value="{{$country_nationality}}">{{$country_nationality}}</option>
        
        <!--<option value="">Select Nationality</option>-->
        <!--@foreach($countries as $countries)-->
        <!--<option value="{{$countries->name}}">{{$countries->name}}</option>-->
        <!--@endforeach-->
       
    </select>
  </div>
  
  <div class="col-12" style="text-align: right;">
    <button type="submit" name="submit"  class="btn btn-primary">Save</button>
  </div>
</form>
      </div>
      
    </div>
  </div>
</div>
<!--Add More Passenger Model End-->



 <!--Add Child Passenger Model Start-->
<div class="modal fade" id="exampleModal_booking_popup" tabindex="-1" aria-labelledby="exampleModalLabel1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel1">Booking Process</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          
          <div class="checkout-page__top" style="margin-top: 15px;margin-bottom: 15px !important;color: #17c917f5;">
    
    
    <?php
    if($slug == 'hotelbeds')
    {
      $current=date('Y-m-d');
      $hotelbedSelectionRS=$get_data->checkavailability_again_rs;
        $hotelbedSelectionRS=json_decode($hotelbedSelectionRS);
        $hotelbedSelectionRS=$hotelbedSelectionRS->hotel;
        $from=date('Y-m-d', strtotime($hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies[0]->from));
      
     
     if(isset($hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies))
    {
      if($from > $current)
      {
      
      ?> 
 <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
     
     <div class="col-md-11" style="padding-left: 0px;">
                                                    <?php
                                                     $price=$hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies[0]->amount ?? '';
                                                    $currency=$hotelbedSelectionRS->currency ?? '';
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                    ?>
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" > GBP {{$exchange_price ?? ''}}  will be deducted upon cancellation From {{$hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies[0]->from ?? ''}}</a>

        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >Pay us before  {{$hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies[0]->from}}  and avoid to cancel your booking.</a>
        
        </div>
        </div>
        
      <?php
      
      }
      else
      {
      
      ?>
     
      
      <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        </div>
        </div>
      
      
             

      <?php
      }
    }
    }
     if($slug == 'travellanda')
    {
      $current=date('Y-m-d');
      $travellanda_cancellation_response=$get_data->travellanda_policy;
        $travellanda_cancellation_response=json_decode($travellanda_cancellation_response);
      
     
    if(isset($travellanda_cancellation_response->Body->CancellationDeadline))
    {
      if($travellanda_cancellation_response->Body->CancellationDeadline < $current)
      {
      ?> 

        <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        </div>
        </div>
      <?php
      
      }
      else
      {
      
      ?>
      <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >RISK FREE! No cancellation fee before <?php echo  date('d M, Y', strtotime($travellanda_cancellation_response->Body->CancellationDeadline))?> (property local time)</a></br>
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >Pay us before <?php echo  date('d M, Y', strtotime($travellanda_cancellation_response->Body->CancellationDeadline))?>  and avoid to cancel your booking.</a>
        </div>
        </div>
      
      
      
      
             

      <?php
      }
    }
    }
    
     if($slug == 'tbo')
    {
       $tboSelectionRS=json_decode($get_data->checkavailability_again_rs);
      $current=date('Y-m-d');
    //   print_r($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies);
       foreach($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies as $CancelPolicies)
      {
         if($CancelPolicies->ChargeType == 'Percentage')
         {
             $from=$CancelPolicies->FromDate;
        
       $from=date('Y-m-d', strtotime($from));
     if(isset($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies))
    {
      if($from > $current)
      {
      
      ?> 
<div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >RISK FREE! No cancellation fee before <?php echo  date('d M, Y', strtotime($from))?>  (property local time)</a></br>
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >Pay us before <?php echo  date('d M, Y', strtotime($from))?>   and avoid to cancel your booking.</a>
        </div>
        </div>
        
        
      <?php
      
      }
      else
      {
      
      ?>
      
      
      <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        </div>
        </div>
      
      
             

      <?php
      }
    }
    }
      }
      }
    
    if($slug == 'ratehawke')
    {
        $current=date('Y-m-d');
       $from=date('Y-m-d', strtotime($array_ratehawk[0]->payment_options->payment_types[0]->cancellation_penalties->policies[0]->end_at));
     if(isset($array_ratehawk[0]->payment_options->payment_types[0]->cancellation_penalties))
    {
      if($from < $current)
      {
      
      ?> 

        <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        </div>
        </div>
      <?php
      
      }
      else
      {
      
      ?>
      <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
      
 <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >RISK FREE! No cancellation fee before <?php echo  date('d M, Y', strtotime($from))?>  (property local time)</a></br>
        <a style="color: #ff0000;text-decoration: none;" class="btn btn-link p-md-1 my-1" >Pay us before <?php echo  date('d M, Y', strtotime($from))?>   and avoid to cancel your booking.</a>
        </div>
        </div>
      
      
      
      
             

      <?php
      }
    }
    } 
    
      if($slug == 'hotels')
    {
        ?>
       

        <div class="row">
          <div class="col-md-1" style="padding-left: 22px;">
             <img style="width:30px;" src="{{asset('public/admin_package/frontend/images/detail_img/image_2022_09_06T19_27_06_769Z.png')}}" class="card-img-top" alt="..."> 
          </div>
          <?php
      if(isset($rooms_checkavailability[0]->cancellation_policy))
    {
      if($rooms_checkavailability[0]->cancellation_policy->guests_pay == 'of the full stay')
      {

      ?>
       <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>
        </div>
      <?php
    }
    else
    {
    ?>
    
     <div class="col-md-11" style="padding-left: 0px;">
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1">Refundable</a>
        </div>
    
<?php
    }
    }
      ?>

        </div>
        
        <?php
      
    
    } 
   
      
      ?>
    
    
    
              </div>
          
          <div class="col-12" style="text-align: right;">
              <?php
              $booking_status=$get_data->booking_status;
              if($booking_status != 'Non Refundable')
              {
              ?>
              
              
               <a class="" href="{{URL::to('admin/confrimbooking')}}/{{$search_id}}/{{$slug}}" style="color:#277019;"  >Confirm booking</a>
           
            
   
   <?php
   
              }
              else
              {
                  ?>
                  <a class="" href="javascript:;" style="color:#277019;"  >Keep tracking your reservation by using Track ID:{{$search_id}}</a>
                  <?php
                 
              }
   ?>
  </div>
        
      </div>
      
    </div>
  </div>
</div>
<!--Add child Passenger Model End-->


 <!--Add Child Passenger Model Start-->
<div class="modal fade" id="exampleModal_child" tabindex="-1" aria-labelledby="exampleModalLabel1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel1">Add Child Passenger</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <form class="row g-3" method="post"  action="{{URL::to('admin/add_child_passengar')}}">
           @csrf
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">Title</label>
    <select class="form-control" name="title">
        <option value="">Select Title</option>
        <option value="Mr.">Mr.</option>
        <option value="Mrs.">Mrs.</option>
    </select>
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">First Name</label>
    <input type="text" class="form-control" value="{{$other_passengar_decode[0]->other_first_name ?? ''}}"  name="other_first_name" >
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">Last Name</label>
    <input type="text" class="form-control" value="{{$other_passengar_decode[0]->other_last_name ?? ''}}"  name="other_last_name">
  </div>
  <div class="col-md-6">
    <label for="inputEmail4"  class="form-label">Nationality</label>
    <select class="form-control selectpicker" data-live-search="true" name="other_nationality">
        <option value="">Select Nationality</option>
        
        <option value="pakistan">pakistan</option>
       
       
    </select>
  </div>
  
  <div class="col-12" style="text-align: right;">
    <button type="submit" name="submit"  class="btn btn-primary">Save</button>
  </div>
</form>
      </div>
      
    </div>
  </div>
</div>
<!--Add child Passenger Model End-->
<!-- Start Content-->
<div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    
                                    <h4 class="page-title">Checkout</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                       
                                        @if(session()->has('message'))
                                        
                                        <div class="alert alert-primary alert-dismissible bg-primary text-white border-0 fade show" role="alert">
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                                        <strong>{{session('message')}} </strong> 
                                    </div>
                                        
                            
                            @endif

                                            <!-- Billing Content-->
                                            
                                                <div class="row">
                                                    <div class="col-lg-8">
                                                        <!--<h4 class="mt-2">Billing information</h4>-->

                                                        <!--<p class="text-muted mb-4">Fill the form below in order to-->
                                                        <!--    send you the order's invoice.</p>-->

                                                        <form method="post" class="row g-3 mt-2" action="{{URL::to('admin/add_lead_passengar')}}">
                                                             @csrf
                                                            <div class="row">
                                                                <div class="col-md-4">
                                                                    <div class="mb-3">
                                                                        <label for="billing-first-name" class="form-label">Title</label>
                                                                        <select class="form-control" name="lead_title">
                                                                            <option value="">Select Title</option>
                                                                            <option value="Mr.">Mr.</option>
                                                                            <option value="Mrs.">Mrs.</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <div class="mb-3">
                                                                        <label for="billing-first-name" class="form-label">First Name</label>
                                                                        <input class="form-control" type="text" placeholder="Enter your first name" id="billing-first-name" required value="{{ $lead_passengar_decode->lead_first_name ?? '' }}"  name="lead_first_name" />
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <div class="mb-3">
                                                                        <label for="billing-last-name" class="form-label">Last Name</label>
                                                                        <input class="form-control" type="text" placeholder="Enter your last name" id="billing-last-name" required value="{{ $lead_passengar_decode->lead_last_name ?? '' }}"  name="lead_last_name" />
                                                                    </div>
                                                                </div>
                                                            </div> <!-- end row -->
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <label for="billing-email-address" class="form-label">Email Address <span class="text-danger">*</span></label>
                                                                        <input class="form-control" type="email" placeholder="Enter your email" id="billing-email-address" required value="{{ $lead_passengar_decode->lead_email ?? '' }}"  name="lead_email" />
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <label for="billing-phone" class="form-label">Phone <span class="text-danger">*</span></label>
                                                                        <input class="form-control" type="text" placeholder="(xx) xxx xxxx xxx" id="billing-phone" required  value="{{ $lead_passengar_decode->lead_phone ?? '' }}"  name="lead_phone" />
                                                                    </div>
                                                                </div>
                                                            </div> <!-- end row -->
                                                            
                                                            <div class="row">
 <div class="col-12">
    <div class="checkout-note">
        <p><i class="fa-regular fa-money-bill-1"></i>  Pay us with in 20 Minutes and confirm your booking, We will be holding your selection for 20 Minutes.</p>

      
    </div>
    
   
    
</div>
<div class="col-12">
    <h5>Let us know what you need</h5>
    <p>Requests are fulfilled on a first come, first served basis. We'll send yours right after you book.</p>
</div>

<p>Do you have a smoking preference?</p>
<div class="col-6">
    
    <div class="form-check">
  <input class="form-check-input" type="radio" name="non_smoking" value="Non Smoking" id="flexRadioDefault1">
  <label class="form-check-label" for="flexRadioDefault1">
     Non-smoking
  </label>
</div>
</div>
<div class="col-6">
<div class="form-check">
  <input class="form-check-input" type="radio" name="non_smoking" value="Smoking" id="flexRadioDefault2" checked>
  <label class="form-check-label" for="flexRadioDefault2">
    smoking
  </label>
</div>
</div>

<p>What bed configuration do you prefer?</p>
<div class="col-6">
  <div class="form-check">
  <input class="form-check-input" type="radio" name="large_bed" value="I'd like a large bed" id="flexRadioDefault3">
  <label class="form-check-label" for="flexRadioDefault3">
   I'd like a large bed
  </label>
</div>

</div>
<div class="col-6">
    <div class="form-check">
  <input class="form-check-input" type="radio" name="large_bed" value="I'd like twin beds" id="flexRadioDefault4" checked>
  <label class="form-check-label" for="flexRadioDefault4">
   I'd like twin beds
  </label>
</div>

</div>




<div class="collapse" id="collapseExamplenote">
           <div class="paragraph" style="border: 1px solid #d4d4d4;padding: 20px;">
             <p class="mb-1"><span class="text-muted">We'll make sure your property or host gets your request quickly.</span></p>
             <div class="row">
            <div class="col-6">
<div class="form-check">
  <input class="form-check-input" type="checkbox" name="high_floor" value="I'd like a room on a high floor." id="flexCheckIndeterminate13">
  <label class="form-check-label" for="flexCheckIndeterminate13">
    I'd like a room on a high floor
  </label>
</div>
</div>
<div class="col-6">
<div class="form-check">
  <input class="form-check-input" type="checkbox" name="baby_cot" value="I’d like to have a baby cot." id="flexCheckIndeterminate14">
  <label class="form-check-label" for="flexCheckIndeterminate14">
  I’d like to have a baby cot<br>
  (additional charges may apply)
  </label>
</div>
</div>
<div class="col-6">
<div class="form-check">
  <input class="form-check-input" type="checkbox" name="quiet_room" value="I’d like a quiet room." id="flexCheckIndeterminate15">
  <label class="form-check-label" for="flexCheckIndeterminate15">
    I’d like a quiet room
  </label>
</div>
</div>
<div class="col-6">
<div class="form-check">
  <input class="form-check-input" type="checkbox" name="airport_transfer" value="I'd like an airport transfer." id="flexCheckIndeterminate16">
  <label class="form-check-label" for="flexCheckIndeterminate16">
  I'd like an airport transfer
  </label>
</div>
</div>
<div class="col-12">
    <label for="inputAddress2" class="form-label">Additional notes:</label>
    
<textarea name="additional_notes" class="form-control"></textarea>
</div>
</div>




          </div>
        </div>
         
      
<div class="col-12">
<a style="color: #123ee5 !important;" class="btn btn-link link-info p-md-1 my-1" data-bs-toggle="collapse" href="#collapseExamplenote" role="button" aria-expanded="false" aria-controls="collapseExamplenote">Click here for more requests</a>
 </div>
                                                            </div>
                                                           

                                                            <div class="row mt-4">
                                                                 <?php
                                                      $adults = 0;
                                                        $children = 0;
                                                     $check_data=Session::get('other_adults');
                                                      $check_data_child=Session::get('other_child');
                                                   
                                                   
                                                
                                                      
                                                
                                                if(session('other_adults'))
                                                    {
                                                       $saveAdults = count(session('other_adults'));
                                                      
                                                        $saveAdults = $saveAdults + 1; 
                                                        // print_r($saveAdults);
                                                        
                                                    }
                                                else
                                                   {
                                                     $saveAdults = 1;  
                                                   }
                                                   
                                                   if(session('other_child'))
                                                    {
                                                       $saveChild = count(session('other_child'));
                                                      
                                                        $saveChild = $saveChild + 1; 
                                                       
                                                        
                                                    }
                                                else
                                                   {
                                                     $saveChild = 1;  
                                                   }
                                                   if(empty($lead_passengar_decode)){
                                                     ?>
                                                                
                                                                    <div class="text-sm-end">
                                                                        <button type="submit" name="submit"  class="btn btn-danger" style="float:right">
                                                                             Add Lead Passengar </button>
                                                                    </div>
                                                                    
                                                                    <?php
                                                }else
                                                {
                                                    if($saveAdults < $adult_count && $saveAdults = $adult_count)
                                                    
                                                      {
                                                        //   print_r($saveAdults);
                                                        //             print_r($adult_count);
                                                          
                                                                        
                                                      ?>
                                                      <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_other_passenger" class="btn" style="background-color:#277019; color:white;float: right; width:200px;">Add other Passengar</a>
                                                                
                                                    <?php
                                                                   
                                                    
                                                      }
                                                     
                                                      else{
                                                          
                                                          
                                                        
                                                                if($saveChild <= $child_count)
                                                                
                                                                {
                                                                    // print_r($saveChild);
                                                                    // print_r($child_count);
                                                                 ?>   
                                                                    
                                                                
                                                            <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_child" class="btn" style="background-color:#277019; color:white;float: right; width:200px;">Add Child Passengar</a>
                                                            <?php
                                                                }
                                                                else
                                                                {
                                                                //     print_r($saveChild); 
                                                                //   print_r($child_count);
                                                                    ?>
                                                                     <!--<a class="btn" href="{{URL::to('')}}/confrimbooking/{{$search_id}}/{{$slug}}" style="background-color:#277019; color:white;"  >Confirm booking</a> -->
                                                                  
                                                   
                                                                     <a class="btn" href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_booking_popup" style="background-color:#277019; color:white;width:200px;"  >Submit booking</a> 
                                                                     <?php
                                                                   
                                                                }
                                                          
                                                      }
                                                           ?>
                                                           
                                                           
                                                           
                                                           
                                                    </br>
                                                    <?php
                                                    if($slug == 'travellanda')
                                                    {
                                                        if($saveAdults <= $adult_count_travelanda)
                                                        {
                                                    ?>
                                                    <!--<a href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn" style="background-color:#277019; color:white;float: right;">Add other Passengar</a>-->
                                                    
                                                     
                                                     <?php
                                                     
                                                        }
                                                        else
                                                        {
                                                     ?>
                                                     
                                                     
                                                   <!--<a class="btn" href="{{URL::to('')}}/confrimbooking/{{$optid."$$".$roomid}}/{{$slug}}" style="background-color:#277019; color:white;"  >Confirm booking</a>-->
                                                     
                                                     <?php
                                                     
                                                        }
                                                     ?>
                                                     
                                                     
                                                     
                                                     
                                                     <?php
                                                     
                                                    }
                                                    else
                                                    {
                                                        ?>
                                                        
                                                       <!--<a class="btn" href="{{URL::to('')}}/confrimbooking/{{$search_id}}/{{$slug}}" style="background-color:#277019; color:white;"  >Confirm booking</a> -->
                                                        
                                                    <?php
                                                    }
                                                    ?>
                                                     
                                                     <?php
                                                     
                                                     
                                                }
                                                     ?>
                                                      
                                                                
                                                            </div> <!-- end row -->
                                                        </form>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <div class="border p-3 mt-4 mt-lg-0 rounded">
                                                            
            
                                                                   <?php
       
       if($slug == "travellanda")
       {
       
       ?>             
                    
    <div class="col-md-4">
        <?php
        
        $travellandadetailRS=$get_data->checkavailability_rs;
        $travellandadetailRS=json_decode($travellandadetailRS);
        
        $travellandaSelectionRS=$get_data->checkavailability_again_rs;
        $travellandaSelectionRS=json_decode($travellandaSelectionRS);
        $travellandaSelectionRS1=$get_data->checkavailability_again_rs;
         $travellandaRoomDetails=json_decode($travellandaSelectionRS1);
          //print_r($travellandaRoomDetails);die();
        $travel_BoardType=$travellandaSelectionRS[0]->BoardType ?? '';
        // print_r($travellandaSelectionRS[0]->Rooms->Room);die();
         $travellanda_cancellation_response=$get_data->travellanda_policy;
        $travellanda_cancellation_response=json_decode($travellanda_cancellation_response);
           //print_r($travellanda_cancellation_response);die();
        
        
        
        
        
        $Facilities=$res_details->get_res->Facilities ?? '';
         $Facilities=json_decode($Facilities);
        ?>
        <div class="modal fade" id="hoteltravellanda_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php print_r($res_details->get_res->Latitude ?? ''); ?>,<?php print_r($res_details->get_res->Longitude ?? ''); ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
        <div class="checkout-note" style="width: 300%;">
    <p>  
       <i class="fa-regular fa-calendar-days"></i>    We have limited availability at this price - book now! </p>
    </div>
    <div class="mb-4" style="width: 324% !important;border-bottom: 2px solid black;">

                                            <div class="">

                                                <h5>  <svg id="Flat" height="35" viewBox="0 0 512 512" width="35" xmlns="http://www.w3.org/2000/svg"><g><path d="m90 448h-2v-24a24 24 0 0 0 -24-24h-16a24 24 0 0 0 -24 24v64h104v-8l-8-2a30 30 0 0 0 -30-30z" fill="#79d8eb"></path><path d="m422 448h2v-24a24 24 0 0 1 24-24h16a24 24 0 0 1 24 24v64h-104v-8l8-2a30 30 0 0 1 30-30z" fill="#79d8eb"></path><path d="m120 256h272v232h-272z" fill="#fac850" transform="matrix(-1 0 0 -1 512 744)"></path><g><path d="m320 456v-248h-128v248h-72v32h272v-32z" fill="#fa5d3f"></path><path d="m232 424h48v64h-48z" fill="#fac850"></path><g fill="#fff9f8"><path d="m216 320h16v16h-16z"></path><path d="m248 320h16v16h-16z"></path><path d="m280 320h16v16h-16z"></path><path d="m216 352h16v16h-16z"></path><path d="m248 352h16v16h-16z"></path><path d="m280 352h16v16h-16z"></path><path d="m216 384h16v16h-16z"></path><path d="m248 384h16v16h-16z"></path><path d="m280 384h16v16h-16z"></path><path d="m216 256h16v16h-16z"></path><path d="m248 256h16v16h-16z"></path><path d="m280 256h16v16h-16z"></path><path d="m216 288h16v16h-16z"></path><path d="m248 288h16v16h-16z"></path><path d="m280 288h16v16h-16z"></path></g></g><path d="m256.004 24 22.419 45.427 50.132 7.284-36.276 35.36 8.564 49.929-44.839-23.573-44.839 23.573 8.563-49.929-36.275-35.36 50.131-7.284z" fill="#fac850"></path><path d="m386.327 112 15.551 31.511 34.775 5.053-25.163 24.528 5.94 34.635-31.103-16.352-31.104 16.352 5.94-34.635-25.163-24.528 34.775-5.053z" fill="#fac850"></path><path d="m453.486 216 10.666 21.61 23.848 3.466-17.257 16.821 4.074 23.752-21.331-11.214-21.33 11.214 4.074-23.752-17.257-16.821 23.848-3.466z" fill="#fac850"></path><path d="m125.673 112-15.551 31.511-34.775 5.053 25.163 24.528-5.94 34.635 31.103-16.352 31.104 16.352-5.94-34.635 25.163-24.528-34.775-5.053z" fill="#fac850"></path><path d="m58.514 216-10.666 21.61-23.848 3.466 17.257 16.821-4.074 23.752 21.331-11.214 21.33 11.214-4.074-23.752 17.257-16.821-23.848-3.466z" fill="#fac850"></path><g fill="#fffdfa"><path d="m144 288h24v16h-24z"></path><path d="m144 328h24v16h-24z"></path><path d="m144 368h24v16h-24z"></path><path d="m144 408h24v16h-24z"></path><path d="m344 368h24v16h-24z"></path><path d="m344 408h24v16h-24z"></path><path d="m344 288h24v16h-24z"></path><path d="m344 328h24v16h-24z"></path></g><path d="m224 184h64v48h-64z" fill="#fac850"></path></g></svg>&nbsp;Hotel Booking Details</h5>

                                                <div class="detail-group">

                                                   

                                                    

                                                   

                                                    <ul class="list-group hotel_append_div">
                                                        <li class="d-flex justify-content-between"><b>Room Fare:</b></li>
                                                        
         <?php
        
        if($room_search == 1)
        {
        
        
        
            
            $total_price =$travellandaSelectionRS[0]->Rooms->Room->RoomPrice;
       
        }
        else
        {
        
        
        $total_price=0;
        $count=1;
        foreach($travellandaRoomDetails as $Room)
        // foreach($travellandaRoomDetails[0]->Rooms->Room as $Room)
            {
            
            $total_price =$Room->Rooms->Room->RoomPrice + $total_price;
        }
        
        }
        ?>
       
                                                        
      <?php
        
        if($room_search == 1)
        {
        
        ?>
          <li class="d-flex justify-content-between">
              <p style="width: 200px;font-weight: 500;font-size: 13px;">{{$room_search}} x {{$travellandaSelectionRS[0]->Rooms->Room->RoomName}} - <?php print_r($travel_BoardType) ?> Included</p>
              &nbsp;<b class="exchange_price1_1_1"> GBP {{$total_price}}</b>
          
          </li> 
        <?php
        $count_1=1;
        }
        else
        {
           $count_1=1;
            foreach($travellandaRoomDetails as $Room)
            {
          
      
        ?>
        
         <li class="d-flex justify-content-between">
              <p style="width: 200px;font-weight: 500;font-size: 13px;">{{$room_search}} x {{$Room->Rooms->Room->RoomName}} - <?php print_r($travel_BoardType) ?> Included</p>
              &nbsp;<b class="exchange_price1_1_{{$count_1}}" >GBP {{$Room->Rooms->Room->RoomPrice}}</b>
          
          </li>
        

        <?php
        $count_1=$count_1+1;
            }
        }
        
        ?>
        
        
              
         
<?php
                                                        
        $val=$count_1 +1;
        $val1=$count_1 +2;
       ?>
                                                               
        
<li class="d-flex justify-content-between"><b>Sub Total:</b>&nbsp;<p class="" >GBP {{$total_price}}</p>

    </li>
   <li class="d-flex justify-content-between"><b>Total Price:</b>&nbsp;<p class="" >GBP {{$total_price}}</p>
   
   </li> 
        
        
                                                        <!--<li class="d-flex justify-content-between"><b>Taxes and Fees:</b>&nbsp;<p>0</p></li>-->
                                                        <!-- <li class="d-flex justify-content-between"><b>VAT (15%) on Service Charges:</b>&nbsp;<p>0</p></li>-->
                                                       
                                                        
                                                         <li class="d-flex mt-0 justify-content-end">
                                                                    <div class="mb-2 d-flex  price-vat-tag h-15px">
                                                                        <svg class="mr-2" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="10" height="10" viewBox="0 0 503.151 503.151" style="enable-background:new 0 0 503.151 503.151;" xml:space="preserve">
                                                                            <path style="fill:#4CAF50;" d="M471.172,0H309.337c-8.483,0.022-16.616,3.387-22.635,9.365L9.369,286.699
                                                                            	c-12.492,12.496-12.492,32.752,0,45.248l161.835,161.835c12.496,12.492,32.752,12.492,45.248,0l277.333-277.333
                                                                            	c6.018-5.992,9.39-14.142,9.365-22.635V32C503.151,14.335,488.837,0.012,471.172,0z M385.839,170.667
                                                                            	c-29.455,0-53.333-23.878-53.333-53.333S356.383,64,385.839,64s53.333,23.878,53.333,53.333S415.294,170.667,385.839,170.667z"></path>
                                                                            <g>
                                                                        </g></svg>
                                                                        <small class="f-0-6-r">Inclusive of VAT &amp; Taxes</small>
                                                                    </div>
                                                                </li>


                                                    </ul>

                                                </div>

                                            </div>

                                        </div>
                                        
                                        
                                        
       <div class="" style="width: 324% !important;">
           <div class="row">
      <div class="col-md-4">
          <?php
         $Images=$res_details->Images ?? '';
        
        //  print_r($Images);
         
         ?>
         <?php
         if(isset($Images->Image))
         {
         ?>
 
   <img src="<?php print_r($Images->Image[0]) ?>" class="card-img-top" alt="...">
 
  <?php
  
  }
  ?>
         
      </div>
      <div class="col-md-8">
          <h6 style="padding-top: 5px;"><?php print_r($travellandadetailRS->HotelName); ?></h6>
          
          
          
          
          <p style="font-size: 11px;font-weight: 700;">
          <?php 
    
    $Location=$res_details->Location ?? '';
   print_r($res_details->Address ?? '');
   
 
    ?>
    
    
    
    
    
    
    
    
    
    <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#hoteltravellanda_map"><i class="fa-solid fa-location-dot"></i></a>

          
          </p>
      </div>
      
  </div>
  <?php
                           
                           $startTimeStamp = strtotime($get_data->check_in);                                   
                            $endTimeStamp = strtotime($get_data->check_out);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                        //   print_r($travellandaSelectionRS);die();
                           
                           ?>
                           
                           
                           
                           

 
 <div class="row">
              <div class="col-md-9"> <span style="font-size: 13px;line-height: 22px;font-weight: bolder;margin: 8px 0px;margin-left: 25px;"><i class="far fa-calendar-check mr-1" aria-hidden="true"></i><?php echo  date('M d, Y', strtotime($get_data->check_in))?> &nbsp;&nbsp;<i class="fas fa-sign-out-alt mr-1" aria-hidden="true"></i><?php echo  date('M d, Y', strtotime($get_data->check_out))?>  </span></div>
              <div class="col-md-3">
                  <p style="font-weight: 700;color: #14b314;font-size: 13px;line-height: 22px;"><?php echo $numberDays . 'Nights';  ?></p>
              </div>
          </div>
 
<div class="checkout-note">
    <p>  
      <i class="fa-regular fa-circle-check"></i>  Well done! You're getting this property's lowest price! </p>
    </div>
    
  <div class="" style="border-top: 1px solid #d2d2d2;">
      
   <div class="detail-group">
<ul class="list-group">

<li class="d-flex justify-content-between"><b>Passenger:</b>&nbsp;<p class="text-right"><?php echo $get_data->adults .' Adults, ' .$get_data->childs . ' Children ';     ?>  </p></li>

 <li class="d-flex justify-content-between"><b>Rooms:</b>&nbsp;<p><?php echo $get_data->rooms . ' Rooms';     ?> </p></li>
 
 
 
        

<!--<li class="d-flex justify-content-between"><b>Room Capacity:</b>&nbsp;<p>2 Adults, 0 Children </p></li>-->
   
         <div style="border: 1px solid #d2d2d2;padding: 20px;" class="collapse" id="collapseExample1">
            <div class="collapse" id="collapseExample1">
            <h5>Cancellation Policy</h5>
             <p class="mb-1"><span class="text-muted">Cancellation Deadline: {{$travellanda_cancellation_response->Body->CancellationDeadline ?? ''}}</span></p>
              <p class="mb-1"><span class="text-muted">Total Price: {{$travellanda_cancellation_response->Body->Currency ?? ''}} {{$travellanda_cancellation_response->Body->TotalPrice ?? ''}}</span></p>
          <table class="table">
              <thead>
                  <th>From</th>
                   <th>Type</th>
                    <th>Value</th>
              </thead>
              <tbody>
           
                <?php
                foreach($travellanda_cancellation_response->Body->Policies->Policy as $Policy)
                {
                
                ?>
              <tr>
                
                <td>
                  <p class="mb-1"><span class="text-muted">{{$Policy->From}}</span></p>
                </td>
                 <td>
                  <p class="mb-1"><span class="text-muted">{{$Policy->Type}}</span></p>
                </td>
                 <td>
                  <p class="mb-1"><span class="text-muted">{{$travellanda_cancellation_response->Body->Currency ?? ''}} {{$Policy->Value}}</span></p>
                </td>
                
              </tr>
              <?php
               
                }
              
              ?>
            
          </tbody>
        </table>
        </div>
        </div>
            
       
       
        
        


                                                        <li class="d-flex justify-content-between">
                                                            
                                                             <?php
      $current=date('Y-m-d');
     if(isset($travellanda_cancellation_response->Body->CancellationDeadline))
    {
      if($travellanda_cancellation_response->Body->CancellationDeadline < $current)
      {
      
      ?> 

     <a style="color: #14b314;" class="btn btn-link link-info p-md-1 my-1">Non Refundable</a>

      <?php
      
      }
      else
      {
      
      ?>
     <a style="color: #14b314;" class="btn btn-link link-info p-md-1 my-1" data-bs-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample1">Refundable</a>


      <?php
      }
    }
      ?>
                                                            
                                                              

          
                                                            
                                                            
                                                       </li>

                                                    </ul>

                                                </div>   
    

    
    
   
  </div>
</div>
        
        
        
        
     
        
        
        
        
        
   
                </div>
                    
                    
            <?php
       }
       ?>
       <?php
        if($slug == "hotelbeds")
       {
       
       ?>             
                    
    <div class="col-md-4">
        <?php
        
        $hotelbedSelectionRS=$get_data->checkavailability_again_rs;
        if(isset($hotelbedSelectionRS))
        {
        $hotelbedSelectionRS=json_decode($hotelbedSelectionRS);
        $hotelbedSelectionRS=$hotelbedSelectionRS->hotel;
       
       
        $hotelbeds_images=$hotelbeds_details->images ?? '';
        // $hotelbeds_images=json_decode($hotelbeds_images);
        
        
        $apiKey = '833583586f0fd4fccd3757cd8a57c0a8';
        $secret = 'ae2dc887d0';
    
        $signature = hash("sha256", $apiKey.$secret.time());                                            
            
     $curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.test.hotelbeds.com/hotel-content-api/1.0/hotels/'.$hotelbedSelectionRS->code.'/details?language=ENG&useSecondaryLanguage=False',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Api-key: 833583586f0fd4fccd3757cd8a57c0a8',
    "X-Signature: $signature",
    'Accept: application/json',
    'Accept-Encoding: gzip'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
$data1 = json_decode($response);
$ho_beds_details = $data1->hotel;
} 
        
        
        ?>
        <div class="modal fade" id="hoteltravellanda_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php print_r($res_details->get_res->Latitude ?? ''); ?>,<?php print_r($res_details->get_res->Longitude ?? ''); ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
        <div class="checkout-note" style="width: 300%;">
    <p>  
       <i class="fa-regular fa-calendar-days"></i>    We have limited availability at this price - book now! </p>
    </div>
    <div class="mb-4" style="width: 324% !important;border-bottom: 2px solid black;">

                                            <div class="">

                                                <h5>  <svg id="Flat" height="35" viewBox="0 0 512 512" width="35" xmlns="http://www.w3.org/2000/svg"><g><path d="m90 448h-2v-24a24 24 0 0 0 -24-24h-16a24 24 0 0 0 -24 24v64h104v-8l-8-2a30 30 0 0 0 -30-30z" fill="#79d8eb"></path><path d="m422 448h2v-24a24 24 0 0 1 24-24h16a24 24 0 0 1 24 24v64h-104v-8l8-2a30 30 0 0 1 30-30z" fill="#79d8eb"></path><path d="m120 256h272v232h-272z" fill="#fac850" transform="matrix(-1 0 0 -1 512 744)"></path><g><path d="m320 456v-248h-128v248h-72v32h272v-32z" fill="#fa5d3f"></path><path d="m232 424h48v64h-48z" fill="#fac850"></path><g fill="#fff9f8"><path d="m216 320h16v16h-16z"></path><path d="m248 320h16v16h-16z"></path><path d="m280 320h16v16h-16z"></path><path d="m216 352h16v16h-16z"></path><path d="m248 352h16v16h-16z"></path><path d="m280 352h16v16h-16z"></path><path d="m216 384h16v16h-16z"></path><path d="m248 384h16v16h-16z"></path><path d="m280 384h16v16h-16z"></path><path d="m216 256h16v16h-16z"></path><path d="m248 256h16v16h-16z"></path><path d="m280 256h16v16h-16z"></path><path d="m216 288h16v16h-16z"></path><path d="m248 288h16v16h-16z"></path><path d="m280 288h16v16h-16z"></path></g></g><path d="m256.004 24 22.419 45.427 50.132 7.284-36.276 35.36 8.564 49.929-44.839-23.573-44.839 23.573 8.563-49.929-36.275-35.36 50.131-7.284z" fill="#fac850"></path><path d="m386.327 112 15.551 31.511 34.775 5.053-25.163 24.528 5.94 34.635-31.103-16.352-31.104 16.352 5.94-34.635-25.163-24.528 34.775-5.053z" fill="#fac850"></path><path d="m453.486 216 10.666 21.61 23.848 3.466-17.257 16.821 4.074 23.752-21.331-11.214-21.33 11.214 4.074-23.752-17.257-16.821 23.848-3.466z" fill="#fac850"></path><path d="m125.673 112-15.551 31.511-34.775 5.053 25.163 24.528-5.94 34.635 31.103-16.352 31.104 16.352-5.94-34.635 25.163-24.528-34.775-5.053z" fill="#fac850"></path><path d="m58.514 216-10.666 21.61-23.848 3.466 17.257 16.821-4.074 23.752 21.331-11.214 21.33 11.214-4.074-23.752 17.257-16.821-23.848-3.466z" fill="#fac850"></path><g fill="#fffdfa"><path d="m144 288h24v16h-24z"></path><path d="m144 328h24v16h-24z"></path><path d="m144 368h24v16h-24z"></path><path d="m144 408h24v16h-24z"></path><path d="m344 368h24v16h-24z"></path><path d="m344 408h24v16h-24z"></path><path d="m344 288h24v16h-24z"></path><path d="m344 328h24v16h-24z"></path></g><path d="m224 184h64v48h-64z" fill="#fac850"></path></g></svg>&nbsp;Hotel Booking Details</h5>

                                                <div class="detail-group">

                                                   

                                                    

                                                   

                                                    <ul class="list-group hotel_append_div">
                                                        <li class="d-flex justify-content-between"><b>Room Fare:</b></li>
                                                        
    <?php
        
        foreach($hotelbedSelectionRS->rooms as $rooms)
        {
        foreach($rooms->rates as $rates)
        {
            
        ?>
          <?php
          $price=$rates->net;
           $currency=$hotelbedSelectionRS->currency ?? '';
          $exchange_price=all_currency_manage($currency,$price);
          ?>
          <li class="d-flex justify-content-between">
              <p style="width: 200px;font-weight: 500;font-size: 13px;">{{$rates->rooms}} X {{$rooms->name}} - {{$rates->boardName}}</p>
              &nbsp;<b class="exchange_price1_1_1"> GBP {{$exchange_price}}</b>
          
          </li> 
        <?php
                                                        
        }
        }
     ?>
     
     <?php
        $total=0;
        foreach($hotelbedSelectionRS->rooms as $rooms)
        {
            
        foreach($rooms->rates as $rates)
        {
          $total=$total + $rates->net;  
        ?>
                                                     
<?php
                                                        
        }
        
        
        ?>
         <?php
          $price=$total;
           $currency=$hotelbedSelectionRS->currency ?? '';
          $exchange_price=all_currency_manage($currency,$price);
          ?>                                                          
        
<li class="d-flex justify-content-between"><b>Sub Total:</b>&nbsp;<p class="" >GBP {{$exchange_price}}</p>

    </li>
   <li class="d-flex justify-content-between"><b>Total Price:</b>&nbsp;<p class="" >GBP {{$exchange_price}}</p>
   
   </li> 
        
        
                                                        <!--<li class="d-flex justify-content-between"><b>Taxes and Fees:</b>&nbsp;<p>0</p></li>-->
                                                        <!-- <li class="d-flex justify-content-between"><b>VAT (15%) on Service Charges:</b>&nbsp;<p>0</p></li>-->
                                                       
                                                        
                                                         <li class="d-flex mt-0 justify-content-end">
                                                                    <div class="mb-2 d-flex  price-vat-tag h-15px">
                                                                        <svg class="mr-2" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="10" height="10" viewBox="0 0 503.151 503.151" style="enable-background:new 0 0 503.151 503.151;" xml:space="preserve">
                                                                            <path style="fill:#4CAF50;" d="M471.172,0H309.337c-8.483,0.022-16.616,3.387-22.635,9.365L9.369,286.699
                                                                            	c-12.492,12.496-12.492,32.752,0,45.248l161.835,161.835c12.496,12.492,32.752,12.492,45.248,0l277.333-277.333
                                                                            	c6.018-5.992,9.39-14.142,9.365-22.635V32C503.151,14.335,488.837,0.012,471.172,0z M385.839,170.667
                                                                            	c-29.455,0-53.333-23.878-53.333-53.333S356.383,64,385.839,64s53.333,23.878,53.333,53.333S415.294,170.667,385.839,170.667z"></path>
                                                                            <g>
                                                                        </g></svg>
                                                                        <small class="f-0-6-r">Inclusive of VAT &amp; Taxes</small>
                                                                    </div>
                                                                </li>


                                                    </ul>

                                                </div>

                                            </div>

                                        </div>
                                        
                                        
                                        
       <div class="" style="width: 324% !important;">
           <div class="row">
      <div class="col-md-4">
          <?php
         
         if(isset($hotelbeds_images))
         {
         ?>
 
   <img src="https://photos.hotelbeds.com/giata/bigger/{{$hotelbeds_images[0]->path ?? ''}}" class="card-img-top" alt="...">
 
<?php
         }
         else
         {
  ?>
  
  <img src="" class="card-img-top" alt="...">
  
  <?php
         }
  ?>
         
      </div>
      <div class="col-md-8">
          <h6 style="padding-top: 5px;"><?php print_r($hotelbedSelectionRS->name); ?></h6>
          
          
          
          
          <p style="font-size: 11px;font-weight: 700;">
          <?php print_r($ho_beds_details->address->content ?? '');  print_r($ho_beds_details->city->content ?? '');?>
    
    
    
    
    
    
    
    
    
    <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#hoteltravellanda_map"><i class="fa-solid fa-location-dot"></i></a>

          
          </p>
      </div>
      
  </div>
 <?php
                           
                           $startTimeStamp = strtotime($hotelbedSelectionRS->checkIn);                                   
                            $endTimeStamp = strtotime($hotelbedSelectionRS->checkOut);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                           
                           
                           ?>
                           
                           
                           
                           

 
 <div class="row">
              <div class="col-md-9"> <span style="font-size: 13px;line-height: 22px;font-weight: bolder;margin: 8px 0px;margin-left: 25px;"><i class="far fa-calendar-check mr-1" aria-hidden="true"></i><?php echo  date('M d, Y', strtotime($get_data->check_in))?> &nbsp;&nbsp;<i class="fas fa-sign-out-alt mr-1" aria-hidden="true"></i><?php echo  date('M d, Y', strtotime($get_data->check_out))?>  </span></div>
              <div class="col-md-3">
                  <p style="font-weight: 700;color: #14b314;font-size: 13px;line-height: 22px;"><?php echo $numberDays . 'Nights';  ?></p>
              </div>
          </div>
            
 
<div class="checkout-note">
    <p>  
      <i class="fa-regular fa-circle-check"></i>  Well done! You're getting this property's lowest price! </p>
    </div>
    
  <div class="" style="border-top: 1px solid #d2d2d2;">
      
   <div class="detail-group">
<ul class="list-group">

<li class="d-flex justify-content-between"><b>Passenger:</b>&nbsp;<p class="text-right"><?php echo $get_data->adults .' Adults, ' .$get_data->childs . ' Children ';     ?>  </p></li>

 <li class="d-flex justify-content-between"><b>Rooms:</b>&nbsp;<p><?php echo $get_data->rooms . ' Rooms';     ?> </p></li>
 
 
 
        

         <?php
        
        foreach($hotelbedSelectionRS->rooms as $rooms)
        {
        foreach($rooms->rates as $rates)
        {
            
        ?>
         
         <!--<li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">{{$rates->rooms}} X {{$rooms->name}} - {{$rates->boardName}}</p>&nbsp;<b> {{$hotelbedSelectionRS->currency ?? ''}} {{$rates->net}}</b></li> -->

<li class="d-flex justify-content-between"><b>Room Capacity:</b>&nbsp;<p><?php echo $rates->adults .' Adults, ' .$rates->children . ' Children ';     ?></p></li>
   
         <div style="border: 1px solid #d2d2d2;padding: 20px;" class="collapse" id="collapseExample1">
            <h5>Cancellation Policy</h5>
            
          <table class="table">
              <thead>
                  <th>From</th>
                 
                    <th>Value</th>
              </thead>
              <tbody>
           
                <?php
                foreach($rates->cancellationPolicies as $cancellationPolicies)
                {
                
                ?>
              <tr>
                
                <td>
                  <p class="mb-1"><span class="text-muted">{{$cancellationPolicies->from}}</span></p>
                </td>
                
                 <td>
                      <?php
                                                     $price=$cancellationPolicies->amount ?? '';
                                                    $currency=$hotelbedSelectionRS->currency ?? '';
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                    ?>
                  <p class="mb-1"><span class="text-muted">GBP {{$exchange_price}}</span></p>
                </td>
                
              </tr>
              <?php
               
                }
              
              ?>
            
          </tbody>
        </table>
        </div>
            
       
       
        
        <?php
        }
        }
        ?>



                                                        <li class="d-flex justify-content-between">
                                                            
                                                        <?php
      $current=date('Y-m-d');
       $from=date('Y-m-d', strtotime($hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies[0]->from));
     if(isset($hotelbedSelectionRS->rooms[0]->rates[0]->cancellationPolicies))
    {
      if($from > $current)
      {
      
      ?> 
      
         <a style="color: #14b314;" class="btn btn-link link-info p-md-1 my-1" data-bs-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample1">Refundable</a>   
         
        
       
      <?php
      
      }
      else
      {
      
      ?>
      
        <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>      

      <?php
      }
    }
      ?>    
                                                            
                                                            
                                                       </li>
   
         
            
       
       
        
        




                                                    </ul>

                                                </div>   
    

    
    
   
  </div>
</div>
        
        
        
        
     
        
        
        
        
        
   
                </div>
                    
                    
            <?php
       }
       }
       ?>
       
       <?php
     if($slug == 'tbo')
       {
           ?>
           
           
           <div class="col-md-4">
        
        <?php
        $tboSelectionRS=json_decode($get_data->checkavailability_again_rs);
        // print_r($tboSelectionRS);
       

       $request_data = array(
    'HotelCode' =>$tboSelectionRS->HotelResult[0]->HotelCode,
   
    );
//   $searchdata=json_encode($searchdata);
  $curl = curl_init();
     curl_setopt_array($curl, array(
     CURLOPT_URL => 'https://admin.synchronousdigital.com/api/get_tbo_hotel_details',
     CURLOPT_RETURNTRANSFER => true,
     CURLOPT_ENCODING => '',
     CURLOPT_MAXREDIRS => 10,
     CURLOPT_TIMEOUT => 0,
     CURLOPT_FOLLOWLOCATION => true,
     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
     CURLOPT_CUSTOMREQUEST => 'POST',
     CURLOPT_POSTFIELDS =>  $request_data,
     CURLOPT_HTTPHEADER => array(
        'Cookie: laravel_session=gnq21xtzzbBtgOgSa0iVWPIX9vSDzHcKrUozAnSL'
     ),
     ));
  
     $response = curl_exec($curl);
     curl_close($curl);
     $tbo_hotel_detail= $response; 
     $tbo_hotel_detail=json_decode($tbo_hotel_detail);
     $tbo_hotel_detail=$tbo_hotel_detail->data;
 
  $hotel_facilities= $tbo_hotel_detail->hotel_facilities;
     $hotel_facilities = json_decode($hotel_facilities);
    //  print_r($hotel_facilities);
 
 
     $tbo_hotel_image= $tbo_hotel_detail->images;
     $image= json_decode($tbo_hotel_image);
     $tbo_hotel_attractions= $tbo_hotel_detail->attractions;
     $attractions = json_decode($tbo_hotel_attractions);
     $map=$tbo_hotel_detail->map;
    $map = explode('|', $map);
     
  
     
     
    // print_r($tbo_hotel_detail);die();
        
        ?>
                
<div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php print_r($map[0]); ?>,<?php print_r($map[1]); ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
<div class="checkout-note" style="width: 300%;">
    <p>  
       <i class="fa-regular fa-calendar-days"></i>    We have limited availability at this price - book now! </p>
    </div>
 <div class="mb-4" style="width: 324% !important;border-bottom: 2px solid black;">

                                            <div class="">

                                                <h5>  <svg id="Flat" height="35" viewBox="0 0 512 512" width="35" xmlns="http://www.w3.org/2000/svg"><g><path d="m90 448h-2v-24a24 24 0 0 0 -24-24h-16a24 24 0 0 0 -24 24v64h104v-8l-8-2a30 30 0 0 0 -30-30z" fill="#79d8eb"></path><path d="m422 448h2v-24a24 24 0 0 1 24-24h16a24 24 0 0 1 24 24v64h-104v-8l8-2a30 30 0 0 1 30-30z" fill="#79d8eb"></path><path d="m120 256h272v232h-272z" fill="#fac850" transform="matrix(-1 0 0 -1 512 744)"></path><g><path d="m320 456v-248h-128v248h-72v32h272v-32z" fill="#fa5d3f"></path><path d="m232 424h48v64h-48z" fill="#fac850"></path><g fill="#fff9f8"><path d="m216 320h16v16h-16z"></path><path d="m248 320h16v16h-16z"></path><path d="m280 320h16v16h-16z"></path><path d="m216 352h16v16h-16z"></path><path d="m248 352h16v16h-16z"></path><path d="m280 352h16v16h-16z"></path><path d="m216 384h16v16h-16z"></path><path d="m248 384h16v16h-16z"></path><path d="m280 384h16v16h-16z"></path><path d="m216 256h16v16h-16z"></path><path d="m248 256h16v16h-16z"></path><path d="m280 256h16v16h-16z"></path><path d="m216 288h16v16h-16z"></path><path d="m248 288h16v16h-16z"></path><path d="m280 288h16v16h-16z"></path></g></g><path d="m256.004 24 22.419 45.427 50.132 7.284-36.276 35.36 8.564 49.929-44.839-23.573-44.839 23.573 8.563-49.929-36.275-35.36 50.131-7.284z" fill="#fac850"></path><path d="m386.327 112 15.551 31.511 34.775 5.053-25.163 24.528 5.94 34.635-31.103-16.352-31.104 16.352 5.94-34.635-25.163-24.528 34.775-5.053z" fill="#fac850"></path><path d="m453.486 216 10.666 21.61 23.848 3.466-17.257 16.821 4.074 23.752-21.331-11.214-21.33 11.214 4.074-23.752-17.257-16.821 23.848-3.466z" fill="#fac850"></path><path d="m125.673 112-15.551 31.511-34.775 5.053 25.163 24.528-5.94 34.635 31.103-16.352 31.104 16.352-5.94-34.635 25.163-24.528-34.775-5.053z" fill="#fac850"></path><path d="m58.514 216-10.666 21.61-23.848 3.466 17.257 16.821-4.074 23.752 21.331-11.214 21.33 11.214-4.074-23.752 17.257-16.821-23.848-3.466z" fill="#fac850"></path><g fill="#fffdfa"><path d="m144 288h24v16h-24z"></path><path d="m144 328h24v16h-24z"></path><path d="m144 368h24v16h-24z"></path><path d="m144 408h24v16h-24z"></path><path d="m344 368h24v16h-24z"></path><path d="m344 408h24v16h-24z"></path><path d="m344 288h24v16h-24z"></path><path d="m344 328h24v16h-24z"></path></g><path d="m224 184h64v48h-64z" fill="#fac850"></path></g></svg>&nbsp;Hotel Booking Details</h5>

                                                <div class="detail-group">

                                                   

                                                    

                                                   

                                                    <ul class="list-group hotel_append_div" >
                                                        <li class="d-flex justify-content-between"><b>Room Fare:</b></li>
                                                        
                                                        <?php
                                                        foreach($tboSelectionRS->HotelResult[0]->Rooms as $Rooms)
                                                        {
                                                        
                                                       
                                                     $price=$Rooms->TotalFare ?? '';
                                                    $currency=$tboSelectionRS->HotelResult[0]->Currency ?? '';
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                    ?>
         <li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">{{$Rooms->Name[0]}} - {{$Rooms->MealType}}</p>&nbsp;
         <b class="exchange_price1_1_1">GBP {{$exchange_price}}</b>
          
         </li> 
                                                               
        <?php
        
                                                        }
        ?>
        <?php
        $grand_TotalFare=0;
       foreach($tboSelectionRS->HotelResult[0]->Rooms as $Rooms)
       {
         $grand_TotalFare=$grand_TotalFare + $Rooms->TotalFare; 
       }
     ?>
      <?php
                                                     $price=$grand_TotalFare ?? '';
                                                    $currency=$tboSelectionRS->HotelResult[0]->Currency ?? '';
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                    ?>
<li class="d-flex justify-content-between"><b>Sub Total:</b>&nbsp;
<p class="exchange_price1_1_2">GBP {{$exchange_price}}</p>

</li>
   <li class="d-flex justify-content-between"><b>Total Price:</b>&nbsp;
   <p class="exchange_price1_1_3">GBP {{$exchange_price}}</p>

   </li>
   
        
        
                                                        <!--<li class="d-flex justify-content-between"><b>Taxes and Fees:</b>&nbsp;<p>0</p></li>-->
                                                        <!-- <li class="d-flex justify-content-between"><b>VAT (15%) on Service Charges:</b>&nbsp;<p>0</p></li>-->
                                                       
                                                        
                                                         <li class="d-flex mt-0 justify-content-end">
                                                                    <div class="mb-2 d-flex  price-vat-tag h-15px">
                                                                        <svg class="mr-2" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="10" height="10" viewBox="0 0 503.151 503.151" style="enable-background:new 0 0 503.151 503.151;" xml:space="preserve">
                                                                            <path style="fill:#4CAF50;" d="M471.172,0H309.337c-8.483,0.022-16.616,3.387-22.635,9.365L9.369,286.699
                                                                            	c-12.492,12.496-12.492,32.752,0,45.248l161.835,161.835c12.496,12.492,32.752,12.492,45.248,0l277.333-277.333
                                                                            	c6.018-5.992,9.39-14.142,9.365-22.635V32C503.151,14.335,488.837,0.012,471.172,0z M385.839,170.667
                                                                            	c-29.455,0-53.333-23.878-53.333-53.333S356.383,64,385.839,64s53.333,23.878,53.333,53.333S415.294,170.667,385.839,170.667z"></path>
                                                                            <g>
                                                                        </g></svg>
                                                                        <small class="f-0-6-r">Inclusive of VAT &amp; Taxes</small>
                                                                    </div>
                                                                </li>


                                                    </ul>

                                                </div>

                                            </div>

                                        </div>
                                        <div class="checkout-note" style="width:300%;">
    <p>  
      <i class="fa-regular fa-circle-check"></i>  Well done! You're getting this property's lowest price! </p>
    </div>
    
    
    
    
    

   <div class="" style="width: 324% !important;">
           <div class="row">
      <div class="col-md-4">
          <img src="{{$image[0]}}" class="card-img-top" alt="...">
      </div>
      <div class="col-md-8">
          <h6 style="padding-top: 5px;">{{$tbo_hotel_detail->hotel_name}}</h6>
          <p style="font-size: 11px;font-weight: 700;">{{$tbo_hotel_detail->address}}<a href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map"><i class="fa-solid fa-location-dot"></i></a>

          
          </p>
      </div>
      
  </div>
 
 
 <?php
                           
                           $startTimeStamp = strtotime($get_data->check_in);                                   
                            $endTimeStamp = strtotime($get_data->check_out);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                           
                           
                           ?>

 <div class="row">
              <div class="col-md-9"> <span style="font-size: 14px;line-height: 22px;font-weight: bolder;margin: 8px 0px;margin-left: 25px;"><i class="far fa-calendar-check mr-1" aria-hidden="true"></i> <?php echo  date('d M, Y', strtotime($get_data->check_in));?>&nbsp;&nbsp;<i class="fas fa-sign-out-alt mr-1" aria-hidden="true"></i><?php echo date('d M, Y', strtotime($get_data->check_in)); ?>  </span></div>
              <div class="col-md-3">
                  <p style="font-weight: 700;color: #14b314;font-size: 13px;line-height: 22px;"><?php echo $numberDays . ' Nights';  ?></p>
              </div>
          </div>
 

    
  <div class="card-body" style="border-top: 1px solid #d2d2d2;">
      
   <div class="detail-group">
<ul class="list-group">

<li class="d-flex justify-content-between"><b>Passenger:</b>&nbsp;<p class="text-right"><?php echo $get_data->adults .' Adults, ' .$get_data->childs . ' Children ';     ?> </p></li>

 <li class="d-flex justify-content-between"><b>Rooms:</b>&nbsp;<p><?php echo $get_data->rooms . '  Rooms' ?></p></li>
 
 
 <!--<li class="d-flex justify-content-between"><b>Room Fare:</b></li> -->
                  
        <?php
                                                        foreach($tboSelectionRS->HotelResult[0]->Rooms as $Rooms)
                                                        {
                                                        
                                                        ?>
          
         <!--<li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">1 X {{$Rooms->Name[0]}} - {{$Rooms->MealType}}</p>&nbsp;<b> {{$tboSelectionRS->HotelResult[0]->Currency}} {{$Rooms->TotalFare}}</b></li> -->
                                                               
        <?php
        
                                                        }
        ?> 

<!--<li class="d-flex justify-content-between"><b>Room Capacity:</b>&nbsp;<p>2 Adults, 0 Children </p></li>-->
   
         <div style="border: 1px solid #d2d2d2;padding: 20px;" class="collapse" id="collapseExample1">
            <h5>Cancellation Policy</h5>
            
          <table class="table">
              <thead>
                  <tr><th>From Date</th>
                 
                    <!--<th>Charge Type</th>-->
                    <th>Cancellation Charge</th>
              </tr></thead>
              <tbody>
            <?php
                foreach($tboSelectionRS->HotelResult[0]->Rooms as $Rooms)
                    {
                      foreach($Rooms->CancelPolicies as $CancelPolicies) 
                      {
                    ?>
                 <tr>
                
                <td>
                  <p class="mb-1"><span class="text-muted">{{$CancelPolicies->FromDate}}</span></p>
                </td>
                
                <!-- <td>-->
                <!--  <p class="mb-1"><span class="text-muted">{{$CancelPolicies->ChargeType}}</span></p>-->
                <!--</td>-->
                <td>
                  <p class="mb-1"><span class="text-muted"> {{$CancelPolicies->CancellationCharge}} {{$CancelPolicies->ChargeType}}</span></p>
                </td>
                
              </tr>
               <?php
                    }
                 }
        ?> 
                          
          </tbody>
        </table>
        </div>
            
       
       
        
        


                                                        <li class="d-flex justify-content-between">
                                                            
                                                              
               <?php
      $tboSelectionRS=json_decode($get_data->checkavailability_again_rs);
      $current=date('Y-m-d');
    //   print_r($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies);
       foreach($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies as $CancelPolicies)
      {
         if($CancelPolicies->ChargeType == 'Percentage')
         {
             $from=$CancelPolicies->FromDate;
         
       $from=date('Y-m-d', strtotime($from));
     if(isset($tboSelectionRS->HotelResult[0]->Rooms[0]->CancelPolicies))
    {
      if($from > $current)
      {
      ?> 
      
            
          <a style="color: #14b314;" class="btn btn-link link-info p-md-1 my-1" data-bs-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample1">Refundable</a>
      
       
      <?php
      
      }
      else
      {
      
      ?>
      
         <a style="color: red !important;" class="btn btn-link link-info p-md-1 my-1"> Non Refundable</a>      

      <?php
      }
    }
         }
      }
      ?>

          
                                                            
                                                            
                                                       </li>

                                                    </ul>

                                                </div>   
    

    
    
   
  </div>
</div>
        
        
        
        
        
   
                </div>
           
           
           <?php
           
       }
       ?>
       
       <?php
       
    if($slug == 'hotels')
       {
           ?>
           
           
           <div class="col-md-4">
        
        <?php
        
        
        
         
     
    

        
        ?>
                
<div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php  ?>,<?php  ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
<div class="checkout-note" style="width:300px;">
    <p>  
       <i class="fa-regular fa-calendar-days"></i>    We have limited availability at this price - book now! </p>
    </div>
<div class="mb-4" style="width: 270px;">

                                            <div class="">

                                                <h5>  <svg id="Flat" height="35" viewBox="0 0 512 512" width="35" xmlns="http://www.w3.org/2000/svg"><g><path d="m90 448h-2v-24a24 24 0 0 0 -24-24h-16a24 24 0 0 0 -24 24v64h104v-8l-8-2a30 30 0 0 0 -30-30z" fill="#79d8eb"></path><path d="m422 448h2v-24a24 24 0 0 1 24-24h16a24 24 0 0 1 24 24v64h-104v-8l8-2a30 30 0 0 1 30-30z" fill="#79d8eb"></path><path d="m120 256h272v232h-272z" fill="#fac850" transform="matrix(-1 0 0 -1 512 744)"></path><g><path d="m320 456v-248h-128v248h-72v32h272v-32z" fill="#fa5d3f"></path><path d="m232 424h48v64h-48z" fill="#fac850"></path><g fill="#fff9f8"><path d="m216 320h16v16h-16z"></path><path d="m248 320h16v16h-16z"></path><path d="m280 320h16v16h-16z"></path><path d="m216 352h16v16h-16z"></path><path d="m248 352h16v16h-16z"></path><path d="m280 352h16v16h-16z"></path><path d="m216 384h16v16h-16z"></path><path d="m248 384h16v16h-16z"></path><path d="m280 384h16v16h-16z"></path><path d="m216 256h16v16h-16z"></path><path d="m248 256h16v16h-16z"></path><path d="m280 256h16v16h-16z"></path><path d="m216 288h16v16h-16z"></path><path d="m248 288h16v16h-16z"></path><path d="m280 288h16v16h-16z"></path></g></g><path d="m256.004 24 22.419 45.427 50.132 7.284-36.276 35.36 8.564 49.929-44.839-23.573-44.839 23.573 8.563-49.929-36.275-35.36 50.131-7.284z" fill="#fac850"></path><path d="m386.327 112 15.551 31.511 34.775 5.053-25.163 24.528 5.94 34.635-31.103-16.352-31.104 16.352 5.94-34.635-25.163-24.528 34.775-5.053z" fill="#fac850"></path><path d="m453.486 216 10.666 21.61 23.848 3.466-17.257 16.821 4.074 23.752-21.331-11.214-21.33 11.214 4.074-23.752-17.257-16.821 23.848-3.466z" fill="#fac850"></path><path d="m125.673 112-15.551 31.511-34.775 5.053 25.163 24.528-5.94 34.635 31.103-16.352 31.104 16.352-5.94-34.635 25.163-24.528-34.775-5.053z" fill="#fac850"></path><path d="m58.514 216-10.666 21.61-23.848 3.466 17.257 16.821-4.074 23.752 21.331-11.214 21.33 11.214-4.074-23.752 17.257-16.821-23.848-3.466z" fill="#fac850"></path><g fill="#fffdfa"><path d="m144 288h24v16h-24z"></path><path d="m144 328h24v16h-24z"></path><path d="m144 368h24v16h-24z"></path><path d="m144 408h24v16h-24z"></path><path d="m344 368h24v16h-24z"></path><path d="m344 408h24v16h-24z"></path><path d="m344 288h24v16h-24z"></path><path d="m344 328h24v16h-24z"></path></g><path d="m224 184h64v48h-64z" fill="#fac850"></path></g></svg>&nbsp;Hotel Booking Details</h5>

                                                <div class="detail-group">

                                                   

                                                    

                                                   

                                                    <ul class="list-group hotel_append_div">
                                                        
                                                        <li class="d-flex justify-content-between"><b>Room Fare:</b></li>
                                                        
                                         <?php
                                         if(isset($rooms_checkavailability))
                                         {
                                             $count=1;
                                             foreach($rooms_checkavailability as $rooms_check)
                                             {
                                             if($rooms_check->grand_total_price_week_weekend != 0.00)
                                             {
                                         
                                         ?>
                                         
                                          <li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">{{$rooms_check->rooms_name ?? ''}} - {{$rooms_check->rooms_meal_type ?? ''}}</p>&nbsp;
                                          <b class="" >{{$rooms_check->grand_total_price_week_weekend ?? ''}} </b>
                                         
                                          </li> 
                                         
                                         <?php
                                             }
                                             else
                                             {
                                         ?>
                                         
                                         <li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">{{$rooms_check->rooms_name ?? ''}} - {{$rooms_check->rooms_meal_type ?? ''}}</p>&nbsp;
                                         <b class="">{{$rooms_check->grand_total_price_all_days ?? '0'}} </b>
                                         
                                         
                                         </li>  
                                         
                                         <?php
                                             }
                                         ?>
          
                

                                                               
         <?php
         $count=$count+1;
                                             }
                                         }
        ?>
        
        
        <?php
         $grand_total=0;
         $counts=$count+1;
          $counts1=$count+2;
          if(isset($rooms_checkavailability))
           {
        foreach($rooms_checkavailability as $rooms_check)
        {
            if($rooms_check->grand_total_price_week_weekend != NULL)
            {
                 $grand_total=$grand_total + $rooms_check->grand_total_price_week_weekend ?? 0;
            }
            if($rooms_check->grand_total_price_all_days != NULL)
            {
             $grand_total=$grand_total + $rooms_check->grand_total_price_all_days ?? 0;   
            }
           
        }
        
        }
        
        ?>
        
        
<li class="d-flex justify-content-between"><b>Sub Total:</b>&nbsp;
<b  >{{$grand_total}} </b>
                                        
</li>
   <li class="d-flex justify-content-between"><b>Total Price:</b>&nbsp;
<b  >{{$grand_total ?? ''}} </b>
                                        
   </li>
  
       
        
                                                        <!--<li class="d-flex justify-content-between"><b>Taxes and Fees:</b>&nbsp;<p>0</p></li>-->
                                                        <!-- <li class="d-flex justify-content-between"><b>VAT (15%) on Service Charges:</b>&nbsp;<p>0</p></li>-->
                                                       
                                                        
                                                         <li class="d-flex mt-0 justify-content-end">
                                                                    <div class="mb-2 d-flex  price-vat-tag h-15px">
                                                                        <svg class="mr-2" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="10" height="10" viewBox="0 0 503.151 503.151" style="enable-background:new 0 0 503.151 503.151;" xml:space="preserve">
                                                                            <path style="fill:#4CAF50;" d="M471.172,0H309.337c-8.483,0.022-16.616,3.387-22.635,9.365L9.369,286.699
                                                                            	c-12.492,12.496-12.492,32.752,0,45.248l161.835,161.835c12.496,12.492,32.752,12.492,45.248,0l277.333-277.333
                                                                            	c6.018-5.992,9.39-14.142,9.365-22.635V32C503.151,14.335,488.837,0.012,471.172,0z M385.839,170.667
                                                                            	c-29.455,0-53.333-23.878-53.333-53.333S356.383,64,385.839,64s53.333,23.878,53.333,53.333S415.294,170.667,385.839,170.667z"></path>
                                                                            <g>
                                                                        </g></svg>
                                                                        <small class="f-0-6-r">Inclusive of VAT &amp; Taxes</small>
                                                                    </div>
                                                                </li>


                                                    </ul>

                                                </div>

                                            </div>

                                        </div>
                                        <div class="checkout-note" style="width:300px;">
    <p>  
      <i class="fa-regular fa-circle-check"></i>  Well done! You're getting this property's lowest price! </p>
    </div>
    
    
    
    
    

     <div class="" style="width: 286px;">
           <div class="row">
      <div class="col-md-4">
          <?php
                                            

?>
          <img src="https://alhijaztours.net/public/uploads/package_imgs/{{$hotels_checkavailability->property_img ?? ''}}" class="card-img-top" alt="...">
      </div>
      <div class="col-md-8">
          <h6 style="padding-top: 5px;">{{$hotels_checkavailability->property_name ?? ''}}</h6>
          <p style="font-size: 11px;font-weight: 700;">{{$hotels_checkavailability->property_address ?? ''}}<a href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map"><i class="fa-solid fa-location-dot"></i></a>

          
          </p>
      </div>
      
  </div>
 
 
 <?php
                           
                           $startTimeStamp = strtotime($get_data->check_in);                                   
                            $endTimeStamp = strtotime($get_data->check_out);                                     

                            $timeDiff = abs($endTimeStamp - $startTimeStamp);                            

                            $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  


                            $numberDays = intval($numberDays);                                           

                                                                                        

                            // echo floor((strtotime($data->check_in)-strtotime($data->check_out))/(60*60*24)); 
                           
                           
                           ?>

 <div class="row">
              <div class="col-md-9"> <span style="font-size: 14px;line-height: 22px;font-weight: bolder;margin: 8px 0px;margin-left: 25px;"><i class="far fa-calendar-check mr-1" aria-hidden="true"></i> <?php echo  date('d M, Y', strtotime($get_data->check_in));?>&nbsp;&nbsp;<i class="fas fa-sign-out-alt mr-1" aria-hidden="true"></i><?php echo date('d M, Y', strtotime($get_data->check_out)); ?>  </span></div>
              <div class="col-md-3">
                  <p style="font-weight: 700;color: #14b314;font-size: 13px;line-height: 22px;"><?php echo $numberDays . ' Nights';  ?></p>
              </div>
          </div>
 

    
  <div class="" style="border-top: 1px solid #d2d2d2;">
      
   <div class="detail-group">
<ul class="list-group">

<li class="d-flex justify-content-between"><b>Passenger:</b>&nbsp;<p class="text-right"><?php echo $get_data->adults .' Adults, ' .$get_data->childs . ' Children ';     ?> </p></li>

 <li class="d-flex justify-content-between"><b>Rooms:</b>&nbsp;<p><?php echo $get_data->rooms . '  Rooms' ?></p></li>
 
 
 <!--<li class="d-flex justify-content-between"><b>Room Fare:</b></li> -->
                  
 
          
     <?php
                                         if(isset($rooms_checkavailability))
                                         {
                                             foreach($rooms_checkavailability as $rooms_check)
                                             {
                                             
                                         
                                      if($rooms_check->grand_total_price_week_weekend != NULL)
                                             {          
          
                  
                                         
                                         ?>
                                          <!--<li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">{{$rooms_check->rooms_name ?? ''}} - {{$rooms_check->rooms_meal_type ?? ''}}</p>&nbsp;<b>{{$rooms_check->currency ?? ''}} {{$rooms_check->grand_total_price_week_weekend ?? ''}} </b></li> -->
                                         
                                         <?php
                                             }
                                             else
                                             {
                                         ?>
                                         <!--<li class="d-flex justify-content-between"><p style="width: 200px;font-weight: 500;font-size: 13px;">{{$rooms_check->rooms_name ?? ''}} - {{$rooms_check->rooms_meal_type ?? ''}}</p>&nbsp;<b>{{$rooms_check->currency ?? ''}} {{$rooms_check->grand_total_price_all_days ?? ''}} </b></li>  -->
                                         
                                         <?php
                                             }
                                         ?>

                                                               
       
<a style="color: #14b314;" class="btn btn-link link-info p-md-1 my-1" data-bs-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample1">Cancellation Policy</a>   
        
        
       

<!--<li class="d-flex justify-content-between"><b>Room Capacity:</b>&nbsp;<p>2 Adults, 0 Children </p></li>-->
   
         <div style="border: 1px solid #d2d2d2;padding: 20px;" class="collapse" id="collapseExample1">
            <h5>Cancellation Policy</h5>
            
          <table class="table">
              <thead>
                  <tr>
                      <th>cancellation_policy</th>
                 
                    <th>guests_pay_days</th>
                    <th>guests_pay</th>
                     <th>prepaymentpolicy</th>
              </tr>
              </thead>
              
              
              <tbody>
            

<?php
if(isset($rooms_check->cancellation_policy))
{
            
             ?>    
                 <tr>
                
                <td>
                  <p class="mb-1"><span class="text-muted">{{$rooms_check->cancellation_policy->concellation_policy ?? ''}}</span></p>
                </td>
                
                 <td>
                  <p class="mb-1"><span class="text-muted">{{$rooms_check->cancellation_policy->guests_pay_days ?? ''}}</span></p>
                </td>
                <td>
                  <p class="mb-1"><span class="text-muted"> {{$rooms_check->cancellation_policy->guests_pay ?? ''}}</span></p>
                </td>
                <td>
                  <p class="mb-1"><span class="text-muted"> {{$rooms_check->cancellation_policy->prepaymentpolicy ?? ''}}</span></p>
                </td>
                
              </tr>
          <?php
}
                                             }
                                         }
        ?>
                          
          </tbody>
        </table>
        </div>
            
       
       
        
        




                                                    </ul>

                                                </div>   
    

    
    
   
  </div>
</div>
        
        
        
        
        
   
                </div>
           
           
           <?php
           
       }
       
       ?>
       
       
       
       
       
       
       
       
       
       
       
                                                            <!-- end table-responsive -->
                                                        </div> <!-- end .border-->
            
                                                    </div> <!-- end col -->            
                                                </div> <!-- end row-->
                                     
                                            <!-- End Billing Information Content-->

                                            

                                            

                                       

                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col -->
                        </div>
                        <!-- end row-->

                    </div>
                    
<!-- container -->

@endsection
@section('scripts')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
@stop