@extends('template/frontend/userdashboard/layout/default')
 @section('content')
<div class="container-fluid">

<!-- start page title -->
    <div class="row mt-5">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="header-title">Search Packages</h4>
                    <p class="text-muted font-14">
                        
                    </p>
                    <div class="row justify-content-center search-pack">
                        <div class="col-md-12">
                        <ul class="nav nav-pills bg-nav-pills nav-justified mb-3">
                           
                            <li class="nav-item">
                                <a href="#profile1" data-bs-toggle="tab" aria-expanded="true" class="nav-link rounded-0 active">
                                   
                                   Search Packages
                                </a>
                            </li>
                             <li class="nav-item">
                                <a href="#hotel" data-bs-toggle="tab" aria-expanded="true" class="nav-link rounded-0">
                                   
                                   Hotels
                                </a>
                            </li>
                             <li class="nav-item">
                                <a href="#transfer" data-bs-toggle="tab" aria-expanded="true" class="nav-link rounded-0">
                                   
                                  Transfer
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#settings1" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                                   Search Activites
                                </a>
                            </li>
                        </ul>
                                        
                        <div class="tab-content">
                            
                            <div class="tab-pane show active" id="profile1">
                               <form action="{{ URL::to('search_tour') }}" target="blank" method="post">
                                @csrf
                           
  
                                <div class="row">
                                    <div class="col-md-3">
                                         <label>Select Category</label>
                                        <div class="form-item" style="postion:relative">
                                            <select name="category" class="form-control">
                                                @if(isset($all_categories))
                                                   @foreach($all_categories as $cat_res)
                                                        <option value="{{ $cat_res->id }}">{{ $cat_res->title }}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                            
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                         <label>Departure From</label>
                                            <div class="form-item">
                                                <i class="awe-icon awe-icon-marker-1"></i>
                                                <input type="text" name="city" class="form-control" id="departure_city" value="Country, city, airport...">
                                                <input type="text" name="booking_person" hidden readonly value="admin">

                                            </div>
                                    </div>
                                    <div class="col-md-3">
                                        <label>Departure Date</label>
                                        <div class="form-item">
                                            <i class="awe-icon awe-icon-calendar"></i>
                                            <input type="date" name="start" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <button class="btn btn-primary" style="margin-top: 1.5rem;" type="submit" name="submit">Search</button>
                                    </div>
                                    
                                </div>

                            </form>
                            </div>
                            <div class="tab-pane" id="hotel">
                               <form action="{{ URL::to('search_hotels') }}" target="blank" method="post">
                                @csrf
                           
  
                                <div class="row">
                                    
                                    <div class="col-md-3">
                                           <label>Destinations</label>
                                            <div class="form-item" style="postion:relative">
                                                  <input name="" id="departure_airport_code" class="form-control" autocomplete="off" placeholder="Enter Destination">
                                                  <div class="col-xl-1" style="margin-top: 25px;text-align: center; display:none">
                                                     <label for=""></label>
                                                     <span id="Change_Location" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                                                  </div>
                                                  <input type="hidden" name="country" placeholder="Search City" id="country">
                                                  <input type="hidden" name="lat" placeholder="Search City" id="lat">
                                                  <input type="hidden" name="long" placeholder="Search City" id="long">
                                                  <input type="hidden" name="pin" placeholder="Search City" id="pin">
                                                  <input type="hidden" name="cityd" placeholder="Search City" id="city">
                                                  <input type="hidden" name="country_code" placeholder="Search City" id="country_code">
                                                
                                            </div>
                                    </div>
                                    <div class="col-md-3">
                                        
                                            <label class="form-label">Hotel Stay</label>
                                            <input type="text" class="form-control" name="daterange" id="demo2" placeholder="Check In ~ Check Out" >
                                        
                                    </div>
                                    <div class="col-md-6" style="postion:relative;">
                                        <div class="">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>Adults</label>
                                                    <input type="number" class="form-control display_popup" name="adult" id="total_adults" value="2" readonly>
                                                </div>
                                                <div class="col-md-4">
                                                     <label>Childs</label>
                                                    <input type="number" class="form-control display_popup" name="child" id="total_childs" value="0" readonly>
                                                </div>
                                                <div class="col-md-4">
                                                    <label>Rooms</label>
                                                    <input type="number" class="form-control display_popup" name="room" id="total_rooms" value="1" min="1" readonly>
                                                </div>
                                            </div>
                                            <button class="btn btn-primary d-none" type="button" onclick="add_rooms()">Add Rooms</button>
                                        </div>
                                        <div class="formpopupTransfers  formpopup" id="room_div" style="background-color:#edf8ff;box-shadow: 9px 12px 15px -4px #808080bd;border-radius: 6px;padding: 1rem; postion:absolute; width: 350px; display: none;">
                                               
                                               <div class="row" style="max-height:230px; overflow-y:scroll;">
                                                    <div class="col-md-12">
                                                        <div class="row" >
                                                               <div class="col-md-12">
                                                                   <div class="text-center mb-2 w-100 pt-2 color-dow pb-2" style="border-bottom: 3px solid #8383d1;"><span><i class="fa-solid fa-bed"></i> Room 1</span></div>
                                                               </div>
                                                               
                                                               <div class="col-md-8">
                                                                   <div class="textgray13" style="margin-top: 10px;">
                                                                      <span class="textblack13med">Adult </span> 12 + Years
                                                                   </div>
                                                               </div>
                                                               
                                                               <div class="col-md-4">
                                                                   <input type="number" name="snAdults[]" id="room_adult1" value="2" class="form-control calculate_total_adults">
                                                               </div>
                                                               
                                                                <div class="col-md-8 mt-2">
                                                                   <div class="textgray13" style="margin-top: 10px;">
                                                                      <span class="textblack13med">Children  </span> 2-12 Years
                                                                   </div>
                                                               </div>
                                                               
                                                               <div class="col-md-4 mt-2">
                                                                   <select class="form-control calculate_total_adults" name="snChildren[]" id="child_room1" onchange="display_childern(1)">
                                                                      <option value="0">0</option>
                                                                      <option value="1">1</option>
                                                                      <option value="2">2</option>
                                                                      <option value="3">3</option>
                                                                      <option value="4">4</option>
                                                                   </select>
                                                               </div>
                                                               
                                                               <div class="row">
                                                                   <div class="col-md-3" id="room1_child_ages1" style="display:none;">
                                                                       <div class="textgray13" style="margin-top: 10px;">
                                                                          <lable>Child 1</lable>
                                                                          <select class="form-control" name="snAges1[]">
                                                                              <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>5</option>
                                                                                <option>6</option>
                                                                                <option>7</option>
                                                                                <option>8</option>
                                                                                <option>9</option>
                                                                                <option>10</option>
                                                                                <option>11</option>
                                                                                <option>12</option>
                                                                          </select>
                                                                       </div>
                                                                   </div>
                                                                    <div class="col-md-3" id="room1_child_ages2" style="display:none;">
                                                                       <div class="textgray13" style="margin-top: 10px;">
                                                                          <lable>Child 2</lable>
                                                                          <select class="form-control" name="snAges2[]">
                                                                             <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>5</option>
                                                                                <option>6</option>
                                                                                <option>7</option>
                                                                                <option>8</option>
                                                                                <option>9</option>
                                                                                <option>10</option>
                                                                                <option>11</option>
                                                                                <option>12</option>
                                                                          </select>
                                                                       </div>
                                                                   </div>
                                                                    <div class="col-md-3" id="room1_child_ages3" style="display:none;">
                                                                       <div class="textgray13" style="margin-top: 10px;" >
                                                                          <lable>Child 3</lable>
                                                                          <select class="form-control" name="snAges3[]">
                                                                              <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>5</option>
                                                                                <option>6</option>
                                                                                <option>7</option>
                                                                                <option>8</option>
                                                                                <option>9</option>
                                                                                <option>10</option>
                                                                                <option>11</option>
                                                                                <option>12</option>
                                                                          </select>
                                                                       </div>
                                                                   </div>
                                                                    <div class="col-md-3" id="room1_child_ages4" style="display:none;">
                                                                       <div class="textgray13" style="margin-top: 10px;">
                                                                          <lable>Child 4</lable>
                                                                          <select class="form-control" name="snAges4[]">
                                                                              <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>5</option>
                                                                                <option>6</option>
                                                                                <option>7</option>
                                                                                <option>8</option>
                                                                                <option>9</option>
                                                                                <option>10</option>
                                                                                <option>11</option>
                                                                                <option>12</option>
                                                                          </select>
                                                                       </div>
                                                                   </div>
                                                               </div>
                                                               
                                                                <input type="text" hidden name="rooms_counter[]" value="1">
                                                           </div>
                                                           
                                                        <div class="row" >
                                                            <div class="col-md-12" id="more_rooms_div">
                                                                
                                                            </div>
                                                        </div>
                                                      
                                                    </div>
                                               </div>
                                              <div class="row" style="border-top: 2px solid gray;margin-top: 0.5rem; padding-top:1rem;">
                                                  <div class="col-md-12">
                                                    <button class="btn btn-success btn-sm" type="button" onclick="add_more_rooms()">Add More Rooms</button>
                                                    <button class="btn btn-danger btn-sm" type="button" onclick="close_rooms()">Close</button>
                                                   </div>
                                                  
                                              </div>
                                        </div>
                                
                                    </div>
                                    
                                    <div class="col-md-4">
                                         <label class="form-label">Select Nationality</label>
                                         <select name="slc_nationality" class="form-control" required>
                                            <option value="">Select Nationality</option>
                                            @foreach($countries as $countries)
                                            <option value="{{$countries->iso2}}">{{$countries->name}}</option>
                                            @endforeach
                                         </select>
                                    </div>
                                     
                                    <div class="col-md-2">
                                        <button class="btn btn-primary" style="margin-top: 1.5rem;" type="submit" name="submit">Search</button>
                                    </div>
                                    
                                </div>

                            </form>
                            </div>
                            <div class="tab-pane" id="settings1">
                               <form action="{{ URL::to('search_activities') }}" target="blank" method="post">
                                @csrf
                           
  
                                <div class="row">
                                    
                                    <div class="col-md-3">
                                         <label>Where To Go?</label>
                                            <div class="form-item">
                                                <input type="text" name="city" class="form-control"  id="pakages_city" placeholder="Country, city, airport..."  >
                                            <div style="postion:absolute">
                                                <ul class="list-group" id="cites_result"></ul>
                                            </div>
                                                <input type="text" name="booking_person" hidden readonly value="admin">

                                            </div>
                                    </div>
                                    <div class="col-md-3">
                                        <label>Departure Date</label>
                                        <div class="form-item">
                                            <i class="awe-icon awe-icon-calendar"></i>
                                            <input type="date" name="start" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <button class="btn btn-primary" style="margin-top: 1.5rem;" type="submit" name="submit">Search</button>
                                    </div>
                                    
                                </div>

                            </form>
                            </div>
                        </div>
                        
                        </div>
                    </div> 
                    <!-- end tab-content-->
                    
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div> <!-- end row-->
                           
<!-- end row -->

</div>
@endsection
@section('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.slim.js" integrity="sha256-HwWONEZrpuoh951cQD1ov2HUK5zA5DwJ1DNUXaM6FsY=" crossorigin="anonymous"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY&sensor=false&libraries=places"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
        <!--<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />-->
        
<script>
   
  function initAutocomplete() {
        var departure_city = document.getElementById('departure_city');
        var autocomplete = new google.maps.places.Autocomplete(departure_city);
      }
      
       $("#pakages_city").keyup(function(e){
              
              var city_lettar = $("#pakages_city").val();
              
                    $.ajax({
                                type: 'POST',
                                url: '{{URL::to('cites_suggestions')}}',
                                data: {_token: '{{ csrf_token() }}',
                                    'city_lettar': city_lettar,
                                     'table':'Activities'
            
                                },
                                success: function(msg){
                                var city = JSON.parse(msg);
                                console.log(city);
                                var list_data = '';
                               
                                for(var i=0; i<city.length; i++){
                                    
                                    list_data = list_data+`<li class="list-group-item" onClick="selectCity('${city[i]}')" >${city[i]}</li>`;
                                }
                                // 
                                
                                $('#cites_result').html(list_data)
                                //  $('#cites_result').css('display','block')
                                console.log(list_data);
                                
                               
            
                                
                                }
                                
                        
                        });
            });
            
                  
    function selectCity(val) {
        $("#pakages_city").val(val);
        // $('#cites_result').css('display','none')
        // $("#suggesstion-box").hide();
    }
    
  function updateConfig() {
            var options = {};
            $('.config-demo').daterangepicker(options, function(start, end, label) {
                console.log('New date range selected: ' + start.format('DD-MM-YYYY') + ' to ' + end.format('DD-MM-YYYY') + ' (predefined range: ' + label + ')'); 
                
                var days = datediff(parseDate(start.format('MM-DD-YYYY')), parseDate(end.format('MM-DD-YYYY')));
               
               var ele = $(this);
                console.log(ele);
                console.log(ele[0].element[0].attributes.id.value);
                var current_id = ele[0].element[0].attributes.id.value;
                $('#day'+current_id+'').val(days)
                
            }).click();
        }
        
        updateConfig();
  
  
  function add_rooms(){
      console.log('function is call now');
      $('#room_div').css('display','block');
  }
  
   function close_rooms(){
      console.log('function is call now');
      $('#room_div').css('display','none');
  }
  
  var room_counter = 1;
  function add_more_rooms(){
      room_counter++;
      var roomHtml = `<div class="row" >
                           <div class="col-md-12">
                               <div class="text-center mb-2 w-100 pt-2 color-dow pb-2" style="border-bottom: 3px solid #8383d1;"><span><i class="fa-solid fa-bed"></i> Room ${room_counter}</span></div>
                           </div>
                           
                           <div class="col-md-8">
                               <div class="textgray13" style="margin-top: 10px;">
                                  <span class="textblack13med">Adult </span> 12 + Years
                               </div>
                           </div>
                           
                           <div class="col-md-4">
                               <input type="number" name="snAdults[]" id="room_adult${room_counter}" value="2" class="form-control calculate_total_adults">
                           </div>
                           
                            <div class="col-md-8 mt-2">
                               <div class="textgray13" style="margin-top: 10px;">
                                  <span class="textblack13med">Children  </span> 2-12 Years
                               </div>
                           </div>
                           
                           <div class="col-md-4 mt-2">
                               <select class="form-control calculate_total_adults" name="snChildren[]" id="child_room${room_counter}" onchange="display_childern(${room_counter})">
                                  <option value="0">0</option>
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                  <option value="3">3</option>
                                  <option value="4">4</option>
                               </select>
                           </div>
                           
                           <div class="row">
                               <div class="col-md-3" id="room${room_counter}_child_ages1" style="display:none;">
                                   <div class="textgray13" style="margin-top: 10px;">
                                      <lable>Child 1</lable>
                                      <select class="form-control" name="child_ages${room_counter}[]">
                                           <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                            <option>6</option>
                                            <option>7</option>
                                            <option>8</option>
                                            <option>9</option>
                                            <option>10</option>
                                            <option>11</option>
                                            <option>12</option>
                                      </select>
                                   </div>
                               </div>
                                <div class="col-md-3" id="room${room_counter}_child_ages2" style="display:none;">
                                   <div class="textgray13" style="margin-top: 10px;">
                                      <lable>Child 2</lable>
                                      <select class="form-control" name="child_ages${room_counter}[]">
                                           <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                            <option>6</option>
                                            <option>7</option>
                                            <option>8</option>
                                            <option>9</option>
                                            <option>10</option>
                                            <option>11</option>
                                            <option>12</option>
                                      </select>
                                   </div>
                               </div>
                                <div class="col-md-3" id="room${room_counter}_child_ages3" style="display:none;">
                                   <div class="textgray13" style="margin-top: 10px;" >
                                      <lable>Child 3</lable>
                                      <select class="form-control" name="child_ages${room_counter}[]">
                                           <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                            <option>6</option>
                                            <option>7</option>
                                            <option>8</option>
                                            <option>9</option>
                                            <option>10</option>
                                            <option>11</option>
                                            <option>12</option>
                                      </select>
                                   </div>
                               </div>
                                <div class="col-md-3" id="room${room_counter}_child_ages4" style="display:none;">
                                   <div class="textgray13" style="margin-top: 10px;">
                                      <lable>Child 4</lable>
                                      <select class="form-control" name="child_ages${room_counter}[]">
                                           <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                            <option>6</option>
                                            <option>7</option>
                                            <option>8</option>
                                            <option>9</option>
                                            <option>10</option>
                                            <option>11</option>
                                            <option>12</option>
                                      </select>
                                   </div>
                               </div>
                           </div>
                           
                            <input type="text" hidden name="rooms_counter[]" value="${room_counter}">
                               </div>`;
                   
        $('#more_rooms_div').append(roomHtml);
        
        
        
        $('.calculate_total_adults').on('key change',function(){
              calculateTotalAdutls()
          })
          
          calculateTotalAdutls();
  }
  
  
  function display_childern(room_counter){
    var noOfChilds = $('#child_room'+room_counter+'').val();
    
    var diff = +noOfChilds + +1;
    for(i =1; i <= noOfChilds; i++){
        $('#room'+room_counter+'_child_ages'+i+'').css('display','block');
    }
    
    
    console.log('differ is '+diff);
    for(i = diff; i <= 4; i++){
        console.log('i value is '+i);
        $('#room'+room_counter+'_child_ages'+i+'').css('display','none');
    }
  }
  
  function calculateTotalAdutls(){
      console.log('functin is call now');
      
      var TotalAdults = 0;
      var Totalchilds = 0;
      for(i = 1; i <= room_counter; i++){
          var adults = $('#room_adult'+i+'').val();
          var noOfChilds = $('#child_room'+i+'').val();
          
          TotalAdults = +TotalAdults + +adults;
          Totalchilds = +Totalchilds + +noOfChilds;
      }
    console.log('total adults is '+TotalAdults);
    console.log('total childs is '+Totalchilds);
    
    $('#total_adults').val(TotalAdults);
    $('#total_childs').val(Totalchilds);
    $('#total_rooms').val(room_counter);
  }
  
  $('.calculate_total_adults').on('key change',function(){
      calculateTotalAdutls()
  })
  
  $('.display_popup').on('click',function(){
      console.log('You Click on it');
      $('#room_div').css('display','block');
  })
   
</script>

<script>
   let departure_city_tour,places,places1,return_places,return_places1,places_T,places1_T,return_places_T,return_places1_T ,input, address, city;
   google.maps.event.addDomListener(window, "load", function () {
       var places = new google.maps.places.Autocomplete(
           document.getElementById("departure_airport_code")
       );
       
       var departure_city_tour = new google.maps.places.Autocomplete(
           document.getElementById("departure_city_tour")
       );
       
   google.maps.event.addListener(places, "place_changed", function () {
           var place = places.getPlace();
          console.log('place id'+place.id);
          
          place.place_id
          
           if(place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['locality', 'political']))[0])
            {
             const city1 = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['locality', 'political']))[0].short_name;
              console.log('city1='+city1);
            }
            else
            {
              const city1 = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['administrative_area_level_2', 'political']))[0].short_name;
              console.log('city1='+city1);  
            }
            
            
            
            
            // if(place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['administrative_area_level_1', 'political']))[0])
            // {
            //  const state1 = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['administrative_area_level_1', 'political']))[0].short_name; 
            //   console.log('state1='+state1);
            // }
            
            if(place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['locality', 'political']))[0])
            {
              const displayCity1 = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['locality', 'political']))[0].long_name;
              console.log('displayCity1='+displayCity1);
              $('#city').val(displayCity1);
            }
            else
            {
              const displayCity1 = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['administrative_area_level_2', 'political']))[0].long_name;
              console.log('displayCity1='+displayCity1); 
              $('#city').val(displayCity1);
            }
            
            
            
            
            // if(place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['administrative_area_level_1', 'political']))[0])
            // {
            //  const displayState1 = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['administrative_area_level_1', 'political']))[0].long_name;
            //  console.log('displayState1='+displayState1);
            // }
            
            
            if(place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['country', 'political']))[0])
            {
             const country_code = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['country', 'political']))[0].short_name;
             console.log('country_code='+country_code);
             $('#country_code').val(country_code);
            }
            if(place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['country', 'political']))[0])
            {
             const country = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['country', 'political']))[0].long_name;
             console.log('country='+country);
             $('#country').val(country);
            }
          
          
          
          
          
          
           var address = place.formatted_address;
           var latitude = place.geometry.location.lat();
           var longitude = place.geometry.location.lng();
           var latlng = new google.maps.LatLng(latitude, longitude);
           var geocoder = (geocoder = new google.maps.Geocoder());
           geocoder.geocode({ latLng: latlng }, function (results, status) {
               if (status == google.maps.GeocoderStatus.OK) {
                   if (results[0]) {
                       var address = results[0].formatted_address;
                       var pin =
                       results[0].address_components[
                   results[0].address_components.length - 1
                 ].short_name;
                  console.log('pin'+pin);
                       var country =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].long_name;
                       var state =
                         results[0].address_components[
                           results[0].address_components.length - 3
                         ].long_name;
                         console.log('state'+state);
                       var city =
                         results[0].address_components[
                           results[0].address_components.length - 4
                         ].long_name;
                       var country_code =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].short_name;
                    //   $('#country').val(country);
                       $('#lat').val(latitude);
                       $('#long').val(longitude);
                       $('#pin').val(pin);
                    //   $('#city').val(city);
                    //   $('#country_code').val(country_code);
                   }
               }
           });
       });
       
        google.maps.event.addListener(departure_city_tour, "place_changed", function () {
           var place = places.getPlace();
           // console.log(place);
           var address = place.formatted_address;
           var latitude = place.geometry.location.lat();
           var longitude = place.geometry.location.lng();
           var latlng = new google.maps.LatLng(latitude, longitude);
           var geocoder = (geocoder = new google.maps.Geocoder());
           geocoder.geocode({ latLng: latlng }, function (results, status) {
               if (status == google.maps.GeocoderStatus.OK) {
                   if (results[0]) {
                       var address = results[0].formatted_address;
                       var pin =
                       results[0].address_components[
                   results[0].address_components.length - 1
                 ].long_name;
                       var country =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].long_name;
                       var state =
                         results[0].address_components[
                           results[0].address_components.length - 3
                         ].long_name;
                       var city =
                         results[0].address_components[
                           results[0].address_components.length - 4
                         ].long_name;
                       var country_code =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].short_name;
                       $('#country').val(country);
                       $('#lat').val(latitude);
                       $('#long').val(longitude);
                       $('#pin').val(pin);
                       $('#city').val(city);
                       $('#country_code').val(country_code);
                   }
               }
           });
       });
   });
   
    google.maps.event.addDomListener(window, "load", function () {
       var places = new google.maps.places.Autocomplete(
           document.getElementById("get_nationality")
       );
   google.maps.event.addListener(places, "place_changed", function () {
           var place = places.getPlace();
           // console.log(place);
           var address = place.formatted_address;
           var latitude = place.geometry.location.lat();
           var longitude = place.geometry.location.lng();
           var latlng = new google.maps.LatLng(latitude, longitude);
           var geocoder = (geocoder = new google.maps.Geocoder());
           geocoder.geocode({ latLng: latlng }, function (results, status) {
               if (status == google.maps.GeocoderStatus.OK) {
                   if (results[0]) {
                       var address = results[0].formatted_address;
                       var pin =
                       results[0].address_components[
                   results[0].address_components.length - 1
                 ].long_name;
                       var country =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].long_name;
                       var state =
                         results[0].address_components[
                           results[0].address_components.length - 3
                         ].long_name;
                       var city =
                         results[0].address_components[
                           results[0].address_components.length - 4
                         ].long_name;
                       var country_code =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].short_name;
                       $('#country_n').val(country);
                       $('#lat_n').val(latitude);
                       $('#long_n').val(longitude);
                       $('#pin_n').val(pin);
                       $('#city_n').val(city);
                       $('#country_code_n').val(country_code);
                   }
               }
           });
       });
   });
   
</script>

<script>
              
            $(window).on('load', function () {
                 
                   
                   
                   
                var today = new Date();
                var end =  new Date(today);
                 end.setDate(end.getDate() + 730);
            $('#demo2').daterangepicker({
                "autoApply": true,
                "startDate": today,
                "endDate": end,
                "minDate": today,
                "maxDate":end
            });
            $('#demo2').val('');
            $('#demo2').attr("placeholder","Check In ~ Check Out");
            $('#demo2').on('apply.daterangepicker', function(ev, picker) {
            ev.stopPropagation();
            var startDate = picker.startDate.format('MM/DD/YYYY');
            var endDate = picker.endDate.format('MM/DD/YYYY');
            var startDate = new Date(startDate);
            var endDate = new Date(endDate);
            var diffTime = Math.abs(startDate - endDate);
            var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
            
              
            
            
             
            
            
            });


             $(document).ready(function(){
              $('.daterangepicker').append('<div class="date-selector"></div>');  
            });


                $('html, body').animate({
                    scrollTop: $("#mySearch").offset().top
                }, 2000);
                
                flatpickr(".single-picker", {
                    dateFormat: "m-d-Y",
                });
                // initialization of HSMegaMenu component
                $('.js-mega-menu').HSMegaMenu({
                    event: 'hover',
                    pageContainer: $('.container'),
                    breakpoint: 1199.98,
                    hideTimeOut: 0
                });

                // Page preloader
                setTimeout(function() {
                  $('#jsPreloader').fadeOut(500)
                }, 800);
            });

            
               
        </script>
@stop
