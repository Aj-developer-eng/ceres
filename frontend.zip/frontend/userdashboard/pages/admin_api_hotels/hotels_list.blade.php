
<?php
//print_r($hotel_res);die();
  $hotel=$hotel_res->hotel;
     $hotels = (array) $hotel;
//print_r($custom_hotels);die();
?>
<style>
.preloader {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background-color: transparent !important;
    z-index: 999999999;
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
}
 #ModalLoadingSpinner {
            background: rgb(234 235 237);
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 9999;
        }

        .ModalLoadingSpinner__content {
                 text-align: center;
                width: 700px;
                margin: 0 auto;
                position: relative;
        }

.ModalLoadingSpinner__content h3{
    text-align:center;
}
.modal-backdrop.show {
    z-index: 0 !important;
}


</style>   
   <div class="preloader">
            <div id="ModalLoadingSpinner">
                <div class="ModalLoadingSpinner__content">
                    <img class="content-img" src="{{asset('public/admin_package/frontend/image_loader/hotel.gif')}}" />
                    <h3>In Search of Great Deals...</h3>
           
                </div>
            </div>
        </div>
@extends('template/frontend/userdashboard/layout/default')
 @section('content')
 
 <?php
 $room_search=Session()->get('room_searching');
         $child_count = Session::get('child_searching');
   
        $adult_count = Session::get('adult');
       $lat = Session::get('hotel_beds_latitude');
         $lng = Session::get('hotel_beds_longitude');
         
          $checkin = Session::get('newstart');
          $checkin=strtotime($checkin);
          $check_in=date('d-M', $checkin);
         $checkout = Session::get('newend');
         $checkout=strtotime($checkout);
          $check_out=date('d-M', $checkout);
          
          
         $total_hotel = 1;
         $temp=1;
 ?>
 <style>
     
     .parent_row {
            box-shadow: 9px 12px 15px -4px #808080bd;
            padding: 0.5rem 0px;
            border: 1px solid #80808038;
            border-radius: 7px;
        }
        .img-responsive{
            width: 100%;height: 150px;
        }
 </style>
<div class="container-fluid">
<input type="text" style="display:none;" class="counter" value="5">
<!-- start page title -->
    <div class="row mt-5">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
 
                    <h4 class="header-title"> <span class="total_hotel_count"></span> Hotel Available</h4>
                    <p class="text-muted font-14">
                        
                    </p>
                    <div class="row justify-content-center search-pack">
                        <div class="col-md-12 scroll_div">
                            
                            
                            <div class="row hotel_append_div" id="filter_data">
                                
                                <!--Custom Hotels-->
                                
                                @if($hotels)
                                    @foreach($hotels as $cust_hotel_res)
                                    <?php
                                    if(isset($cust_hotel_res->property_name))
                                    {
                                    ?>
                                        <div class="col-md-12 mb-4">
                                        <div class="row parent_row">
                                            <div class="col-md-3">
                                                <div class="">
                                                    <img class="tour-img" style="width:100%; height: 150px;" src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $cust_hotel_res->property_img ?? '' }}" alt="">
                                                    
                                                </div>
                                            </div>
                                             
                                            <div class="col-md-6">
                                                <h5 class="card-title">
                                                    <a href="{{URL::to('')}}/hotel/detail/{{$cust_hotel_res->id}}/{{$cust_hotel_res->property_name}}/{{'hotel'}}" style="text-decoration:none;font-size: 1.5rem;">{{$cust_hotel_res->property_name  ?? ''}}</a>
                                                </h5>
                                                <h6 class="departure-date"><i class="fa-solid fa-plane-departure"></i>   
                                                 <i class="dripicons-location"></i>
                                                    {{$cust_hotel_res->property_address  ?? ''}}{{$cust_hotel_res->property_country  ?? ''}}{{$cust_hotel_res->property_city  ?? ''}} </h6>
                                                <p>{{ $cust_hotel_res->star_type ?? '' }}.0 
                                                
                                                <?php
                                                      if($cust_hotel_res->star_type == 1){
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                       }
                                                        if($cust_hotel_res->star_type == 2){
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         }
                                            
                                              
                                                        if($cust_hotel_res->star_type == 3){
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                          }
                                            
                                              
                                                       if($cust_hotel_res->star_type == 4){
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                           
                                                       }
                                            
                                              
                                                         if($cust_hotel_res->star_type == 5){
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                          }
                                                  ?>                                                    
                                                </p><p>
                                                </p><p class="tour-description">
                                                    
                                                     <?php
                                                    if(isset($cust_hotel_res->property_desc)){
                                                        ?>
                                                        {{ Str::limit($cust_hotel_res->property_desc, 50) }}
                                                        <?php
                                                    }
                                                     ?>
                                                    </p>
                                                <hr>
                                                <div class="row f-13">
                                                    
                                                    <?php
                                                        if(isset($cust_hotel_res->facilities)){
                                                        $facilities=unserialize($cust_hotel_res->facilities);
                                                        
                                                    ?>
                                                         @if(isset($facilities))
                                                             @foreach($facilities as $facilities_res)
                                                                @if($loop->iteration <= 4)
                                                                     <div class="col-md-6">
                                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="dripicons-checkmark" style="color:green;"></i>{{$facilities_res}}</p>
                                                                                                                                
                                                                     </div>
                                                                     
                                                         @endif
                                                       
                                                        @endforeach
                                                         @endif
                                                      <?php
                                                        }
                                                         ?>
                                                </div>
                                            
                                                    
                                                </div>
                                          
                                            <div class="col-md-3 pt-2">
                                                    <h6>
                                                          <?php
                                                           $r_count=1;
                                                           ?>
                                                        @foreach($hotel_res->rooms as $rooms)
                                                             @if(isset($cust_hotel_res->id))
                                                                @if($rooms->hotel_id == $cust_hotel_res->id)
                                                                    @if($r_count <= 1)
                                                                       <?php
                                                                       if(isset($rooms->rooms_on_rq))
                                                                       {
                                                                          if($rooms->rooms_on_rq == 1)
                                                                          {
                                                                              echo 'On Request';
                                                                          }
                                                                          else
                                                                          {
                                                                           echo '';   
                                                                          }
                                                                       }
                                                                       $r_count=$r_count + 1;
                                                                       ?>
                                                                    @endif
                                                                @endif
                                                             @endif
                                                        @endforeach
                                                    </h6>
                                                   <div class="price">
                                            <?php
                                               $r_count=1;
                                               ?>
                                            @foreach($hotel_res->rooms as $rooms)
                                             @if(isset($cust_hotel_res->id))
                                             
                                            @if($rooms->hotel_id == $cust_hotel_res->id)
                                            
                                                @if($r_count <= 1)
                                                <?php
                                                if($rooms->weekdays_price_wi_markup != null)
                                                {
                                                    $price=$rooms->weekdays_price_wi_markup;
                                                    if($cust_hotel_res->currency_symbol == '﷼')
                                                    {
                                                    $currency='SAR';
                                                    }
                                                    else
                                                    {
                                                    $currency=$cust_hotel_res->currency_symbol;
                                                    }
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                ?> 
                                            Week Days Price
                                            
                                            
                                            
                                             
                                                <span  class="amount" style="">GBP {{$exchange_price ?? ''}}</span>
                                                
                                                <?php
                                                }
                                                else
                                                {
                                                $price=$rooms->price_all_days_wi_markup;
                                                    if($cust_hotel_res->currency_symbol == '﷼')
                                                    {
                                                    $currency='SAR';
                                                    }
                                                    else
                                                    {
                                                    $currency=$cust_hotel_res->currency_symbol;
                                                    }
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                ?>
                                                All Days Price
                                                 <span class="amount" style="">GBP {{$exchange_price ?? ''}}</span>
                                                
                                                
                                                
                                                <?php
                                                
                                                }
                                                 $r_count=$r_count + 1;
                                                ?>
                                                @endif
                                            @endif
                                            @endif
                                            <?php
                                            
                                            
                                            ?>
                                            @endforeach
                                            
                                            
                                        </div>
                                                 <span class="time_length" style="font-size: 13px;"> <?php echo $check_in?> TO <?php  echo $check_out; ?></span></br>
                                                <div class="time_length"><i class="fa fa-moon-o" aria-hidden="true"></i> <?php echo $room_search  . 'Rooms' . ',' . $adult_count  . 'Adults' . ',' . $child_count .  'Children' ; ?></div>
                                                 <a href="{{URL::to('')}}/hotel/detail/{{$cust_hotel_res->id}}/{{$cust_hotel_res->property_name}}/{{'hotel'}}" style="text-decoration:none;" class="btn btn-primary form-control">Book Now</a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    }
                                    ?>
                                    @endforeach
                                @endif
                                
                                <!--Travelenda Hotels-->
                                
                                @isset($travellanda_hotels)
                                
                                <?php 
                                    $travellandahotelcount = count($travellanda_hotels);
                                     $total_hotel = $total_hotel + $travellandahotelcount;
                                ?>
                                    @foreach($travellanda_hotels as $travel_res)
                                    
                                        <?php
                                        if($loop->iteration <= 5){
                               
                                             $hotel_bed_data_arr =[];
                                             
                                             
                                                          
                                             $data_request="<Request>
                                                    <Head>
                                                  <Username>1124fb7683cf22910ea6e3c97473bb9c</Username>
                                                    <Password>rY8qm76g5dGH</Password>
                                                    <RequestType>GetHotelDetails</RequestType>
                                                    </Head>
                                                    <Body>
                                                    <HotelIds> 
                                                    <HotelId>".$travel_res->HotelId."</HotelId>
                                                    </HotelIds>
                                                    </Body>
                                                </Request>";


                                            $url = "http://xmldemo.travellanda.com/xmlv1/GetHotelDetailsRequest.xsd";
                                                $timeout = 20;
                                                $data = array('xml' => $data_request);
                                                $headers = array(
                                                "Content-type: application/x-www-form-urlencoded",
                                            );
                                            $ch = curl_init();
                                            $payload = http_build_query($data);
                                            curl_setopt($ch, CURLOPT_URL,$url);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
                                            curl_setopt($ch, CURLOPT_POST, true);
                                            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
                                            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                                    
                                            $response = curl_exec($ch);
                                            // echo $response;die();
                                            $xml = simplexml_load_string($response);
                                            $json = json_encode($xml);
                                          //print_r($json);
                                            $hotel_details_data = json_decode($json);
                                             
                                             
                                             $hotel_details =$hotel_details_data->Body->Hotels->Hotel;
                                           
                                        
                                    
                                         $travellanda_images=$hotel_details->Images ?? '';
                                         //$travellanda_images=json_decode($travellanda_images);
                                         
                                         $travellanda_Facilities=$hotel_details->Facilities ?? '';
                                         //$travellanda_Facilities=json_decode($travellanda_Facilities);
                                         
                                          $travellanda_Facilities_more=$hotel_details->Facilities ?? '';
                                         //$travellanda_Facilities_more=json_decode($travellanda_Facilities_more);
                                      
                                         
                                         $travellanda_Description=$hotel_details->Description ?? '';
                                         //$travellanda_Description=json_decode($travellanda_Description);
                                        //  print_r($travellanda_Facilities);
     
     

                                        ?>
                                        <div class="col-md-12 mb-4">
                                        <div class="row parent_row">
                                            <div class="col-md-3">
                                                <div class="">
                                                    <img class="tour-img" style="width:100%; height: 150px;" src="{{$travellanda_images->Image[0] ?? ''}}" alt="">
                                                    
                                                </div>
                                            </div>
                                             
                                            <div class="col-md-6">
                                                <h5 class="card-title">
                                                    <a href="{{URL::to('')}}/hotel/detail/{{$travel_res->HotelId}}/{{$travel_res->HotelName}}/{{'travellanda'}}" style="text-decoration:none;font-size: 1.5rem;">{{$travel_res->HotelName ?? ""}}</a>
                                                </h5>
                                                <h6 class="departure-date"><i class="fa-solid fa-plane-departure"></i>   
                                                 <i class="dripicons-location"></i>
                                                    {{$hotel_details->Address  ?? ''}}</h6>
                                                <p>{{ $hotel_details->StarRating }}.0 
                                                
                                                <?php
                                                      if($hotel_details->StarRating == 1){
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                       }
                                                        if($hotel_details->StarRating == 2){
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         }
                                            
                                              
                                                        if($hotel_details->StarRating == 3){
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                          }
                                            
                                              
                                                       if($hotel_details->StarRating == 4){
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                           
                                                       }
                                            
                                              
                                                         if($hotel_details->StarRating == 5){
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                          }
                                                  ?>                                                    
                                                </p><p>
                                                </p><p class="tour-description">
                                                    
                                                     <?php
                                                    if(isset($travellanda_Description)){
                                                        ?>
                                                        {!! Str::limit($travellanda_Description, 175, ' ...') !!}
                                                        <?php
                                                    }
                                                     ?>
                                                    </p>
                                                <hr>
                                                <div class="row f-13">
                                                    
                                                    
                                                    <?php
                                                        if(isset($travellanda_Facilities->Facility)){
                                                        // $facilities=unserialize($cust_hotel_res->facilities);
                                                        
                                                    ?>
                                                         @if(isset($travellanda_Facilities->Facility))
                                                             @foreach($travellanda_Facilities->Facility as $travellanda_Facilities)
                                                                @if($loop->iteration <= 4)
                                                                     <div class="col-md-6">
                                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="dripicons-checkmark" style="color:green;"></i>{{$travellanda_Facilities->FacilityName}}</p>
                                                                                                                                
                                                                     </div>
                                                                     
                                                         @endif
                                                       
                                                        @endforeach
                                                         @endif
                                                      <?php
                                                        }
                                                         ?>
                                                </div>
                                            
                                                    
                                                </div>
                                          
                                            <div class="col-md-3 pt-2">
                                                    <h6>
                                                   
                                                    </h6>
                                                    <div class="price">
                                                       
                                                                <?php
                                                                $count_rooms=0;
                                                                ?>
                                                                <?php
                                                                if($room_search == 1)
                                                                {
                                                                   if(isset($travel_res->Options->Option))
                                                                {
                                                                    $count_rooms = count($travel_res->Options->Option);
                                                                              
                                                                }  
                                                                }
                                                                else
                                                                {
                                                                
                                                                foreach($travel_res->Options->Option as $op)
                                                                {
                                                                 $count_rooms = 0;   
                                                                }
                                                                    
                                                                              
                                                                   
                                                                }
                                                               
                                                                ?>
                                                                
                                                                <h6>
                                                                    
                                                                     <?php print_r($count_rooms); ?> Rooms Available with 
                                                                      <?php
                                                                      if(isset($travel_res->Options->Option->BoardType))
                                                                      {
                                                                     print_r($travel_res->Options->Option->BoardType);   
                                                                      }
                                                                      else
                                                                      {
                                                                          print_r($travel_res->Options->Option[0]->BoardType);
                                                                       
                                                                      }
                                                                      ?>
                                                                </h6>
                                                            <?php
                                            if(isset($travel_res->Options->Option->TotalPrice))
                                               {
                                                   
                                                   
                                              
                                            ?>
                                            
                                            
                                             
                                                
                                            
                                            <span id="addCls" class="amount" style="font-size: 15px;">
                                            
                                            
                                            GBP {{$travel_res->Options->Option->TotalPrice ?? ''}} 
                                            </span>
                                           
                                           
                                            
                                            
                                            <?php
                                            
                                               }
                                               else
                                               {
                                            ?>
                                            
                                            <span class="amount">
                                               
                                                GBP {{$travel_res->Options->Option[0]->TotalPrice ?? ''}}
                                                
                                                
                                                </span>
                                                
                                               
                                            
                                            <?php
                                               }
                                            
                                            ?>
                                                                
                                                                
                                                              

                                                </div>
                                                <span class="time_length" style="font-size: 13px;"> <?php echo $check_in?> TO <?php  echo $check_out; ?></span></br>
                                                <div class="time_length"><i class="fa fa-moon-o" aria-hidden="true"></i> <?php echo $room_search  . 'Rooms' . ',' . $adult_count  . 'Adults' . ',' . $child_count .  'Children' ; ?></div>
                                                 <a href="{{URL::to('')}}/hotel/detail/{{$travel_res->HotelId}}/{{$travel_res->HotelName}}/{{'travellanda'}}" style="text-decoration:none;" class="btn btn-primary form-control">Book Now</a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                        <?php 
                                        }
                                        ?>
                                    @endforeach
                                @endisset
                                
                                
                                <!--hotelbeds listing start-->
                                @if(isset($hotelbed_hotels) && $hotelbed_hotels != "")
                                
                               <?php
$hotelbedhotelcount = count($hotelbed_hotels);
$total_hotel = $total_hotel + $hotelbedhotelcount;
$hotel_bed_data_arr=[];
$list_count=1;

?>
                                   @foreach($hotelbed_hotels as $hotela)
                                    
                                        <?php
                                        if($loop->iteration <= 5)
                                        {
                                            
                                          
                    $hotelbeds_count_rooms=0;
                    foreach($hotela->rooms as $rooms)
                    {
                      $hotelbeds_count_rooms=$hotelbeds_count_rooms+1;  
                    }
      $apiKey = '4b11b3c941ea25825a4de05ec398c4ab';
        $secret = 'afe693d5e4';
    
        $signature = hash("sha256", $apiKey.$secret.time());                                            
            
     $curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.hotelbeds.com/hotel-content-api/1.0/hotels/'.$hotela->code.'/details?language=ENG&useSecondaryLanguage=False',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Api-key: 4b11b3c941ea25825a4de05ec398c4ab',
    "X-Signature: $signature",
    'Accept: application/json',
    'Accept-Encoding: gzip'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
$data1 = json_decode($response);
   
        if(isset($data1->hotel)){
            $travel_content = $data1->hotel;
        }else{
            $travel_content = null;
        }
        
        // dd($travel_content);
   
   
   
    
     $hotel_beds_images=$travel_content->images ?? '';
     
     
     $hotel_beds_facilities=$travel_content->facilities ?? '';
    
    //  print_r($hotel_beds_facilities);
     
     
 $apiKey = '4b11b3c941ea25825a4de05ec398c4ab';
        $secret = 'afe693d5e4';
        $signature = hash("sha256", $apiKey.$secret.time());
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.hotelbeds.com/hotel-content-api/1.0/types/facilities?fields=all&language=ENG&from=1&to=100&useSecondaryLanguage=True',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Api-key: 4b11b3c941ea25825a4de05ec398c4ab',
    "X-Signature: $signature",
    'Accept: application/json',
    'Accept-Encoding: gzip'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
// echo $response;
$response_facilities=json_decode($response);
$result='';
$single_hotel_bad = ['hotel_data'=>$hotela,'hotel_details'=>$result,'facilities_data'=>$response_facilities];

array_push($hotel_bed_data_arr,$single_hotel_bad);
     

                                        ?>
                                        <div class="col-md-12 mb-4">
                                        <div class="row parent_row">
                                            <div class="col-md-3">
                                                
                                                <div class="">
                                                    <?php
                                            if(isset($hotel_beds_images))
                                            {
                                            ?>
                                            <img class="tour-img" style="width:100%; height: 150px;" src="https://photos.hotelbeds.com/giata/bigger/{{$hotel_beds_images[0]->path ?? ''}}" alt="">
                                            <?php
                                            }
                                            else
                                            {
                                                
                                            ?>
                                            
                                            <img class="tour-img" style="width:100%; height: 150px;" src="{{asset('public/admin_package/frontend/images/detail_img/no-photo-available-icon-4.jpg')}}" alt="">
                                            <?php
                                            
                                            }
                                            ?>
                                                    
                                                    
                                                </div>
                                            </div>
                                             
                                            <div class="col-md-6">
                                                <h5 class="card-title">
                                                    <a href="{{URL::to('')}}/hotel/detail/{{$hotela->code}}/{{$hotela->name}}/{{'hotelbeds'}}" style="text-decoration:none;font-size: 1.5rem;">{{$hotela->name}}</a>
                                                </h5>
                                                <h6 class="departure-date"><i class="fa-solid fa-plane-departure"></i>   
                                                 <i class="dripicons-location"></i>
                                                 <?php
                                         
                                          print_r($travel_content->address->content ?? '');
                                     
                                          ?>
                                                   </h6>
                                                <p>5.0 
                                                
                                                <?php
                                                $StarRating=5;
                                                      if($StarRating == 1){
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                       }
                                                        if($StarRating == 2){
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         }
                                            
                                              
                                                        if($StarRating == 3){
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                          }
                                            
                                              
                                                       if($StarRating == 4){
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                           
                                                       }
                                            
                                              
                                                         if($StarRating == 5){
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                          }
                                                  ?>                                                    
                                                </p><p>
                                                </p>
                                                <p class="tour-description">
                                                    
                                                     
                                                    </p>
                                                <hr>
                                                <div class="row f-13">
                                                    
                                                    
                                                   <?php
                                         $facilities_count=1;
                                          if(isset($hotel_beds_facilities)  AND !empty($hotel_beds_facilities))
                                          {
                                          foreach($hotel_beds_facilities as $hotel_beds_facilities)
                                          {
                                              if(isset($response_facilities->facilities))
                                          {
                                              foreach($response_facilities->facilities as $res_facilities)
                                          {
                                              
                                              
                                            if($res_facilities->code ?? '' == $hotel_beds_facilities->facilityCode)
                                              {  
                                              
                                              if($facilities_count <= 5)
                                              {
                                          ?>
                                                                     <div class="col-md-6">
                                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="dripicons-checkmark" style="color:green;"></i>{{$res_facilities->description->content}}</p>
                                                                                                                                
                                                                     </div>
                                                                     
                                                        <?php
                                              } 
                                              
                                              $facilities_count=$facilities_count + 1; 
                                          }
                                          }
                                          }
                                           
                                          
                                          
                                          }
                    }
                                    ?>
                                                </div>
                                            
                                                    
                                                </div>
                                          
                                            <div class="col-md-3 pt-2">
                                                    <h6>
                                                   
                                                    </h6>
                                                    <div class="price">
                                                       
                                                                <?php
                   $count_board=0;
                    foreach($hotela->rooms as $rooms)
                    {
                         
                      foreach($rooms->rates as $rates)
                      {
                        if($rates->boardName == 'ROOM ONLY')
                        {
                            if($count_board == 1)
                            {
                            echo 'ROOM ONLY';
                            }
                        }
                        if($rates->boardName == 'ENGLISH BREAKFAST')
                        {
                            if($count_board == 1)
                            {
                            echo 'ENGLISH BREAKFAST';
                            }
                        }
                        if($rates->boardName == 'CONTINENTAL BREAKFAST')
                        {
                            if($count_board == 1)
                            {
                            echo 'CONTINENTAL BREAKFAST';
                            }
                        }
                        $count_board=$count_board+1;
                      }
                      
                    }
                    // print_r($hotelbeds_count_rooms);
                    ?>
                                                                
                                                                <h6>
                                                                    
                                                                     <?php print_r($hotelbeds_count_rooms); ?> Rooms Available with 
                                                                      
                                                                </h6>
                                                            
                                                            
                                                            <?php
                                            $currency=$hotela->currency;
                                            $minRate=$hotela->minRate;
                                            $exchange_price=all_currency_manage($currency,$minRate);
                                            
                                            ?>
                                            
                                            
                                             
                                                
                                            
                                            <span id="addCls" class="amount" style="font-size: 15px;">
                                            
                                            
                                            GBP {{$exchange_price ?? ''}} 
                                            </span>
                                           
                                           
                                            
                                            
                                           
                                                                
                                                                
                                                              

                                                </div>
                                                <span class="time_length" style="font-size: 13px;"> <?php echo $check_in?> TO <?php  echo $check_out; ?></span></br>
                                                <div class="time_length"><i class="fa fa-moon-o" aria-hidden="true"></i> <?php echo $room_search  . 'Rooms' . ',' . $adult_count  . 'Adults' . ',' . $child_count .  'Children' ; ?></div>
                                                 <a href="{{URL::to('')}}/hotel/detail/{{$hotela->code}}/{{$hotela->name}}/{{'hotelbeds'}}" style="text-decoration:none;" class="btn btn-primary form-control">Book Now</a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                        <?php 
                                        }
                                        ?>
                                    @endforeach
                                @endisset
                                <!--hotelbeds listing end-->
                                
                                
                                <!--tbo listing start -->
                                @if(isset($tbo_response->HotelResult))
                                
                                <?php
                   $tbohotelcount = count($tbo_response->HotelResult);
                   $total_hotel = $total_hotel + $tbohotelcount;
                   
                   $tbo_count_hotel=1;
                   ?>
                                     @foreach($tbo_response->HotelResult as $hotela) 
                                    
                                        <?php
                                        if($loop->iteration <= 5){
                               
                                        
                                  
            
     $request_data = array(
    'HotelCode' => $hotela->HotelCode,
   
    );
//   $searchdata=json_encode($searchdata);
  $curl = curl_init();
     curl_setopt_array($curl, array(
     CURLOPT_URL => 'https://admin.synchronousdigital.com/api/get_tbo_hotel_details',
     CURLOPT_RETURNTRANSFER => true,
     CURLOPT_ENCODING => '',
     CURLOPT_MAXREDIRS => 10,
     CURLOPT_TIMEOUT => 0,
     CURLOPT_FOLLOWLOCATION => true,
     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
     CURLOPT_CUSTOMREQUEST => 'POST',
     CURLOPT_POSTFIELDS =>  $request_data,
     CURLOPT_HTTPHEADER => array(
        'Cookie: laravel_session=gnq21xtzzbBtgOgSa0iVWPIX9vSDzHcKrUozAnSL'
     ),
     ));
  
     $response = curl_exec($curl);
     curl_close($curl);
     $tbo_hotel_detail= $response; 
     $tbo_hotel_detail=json_decode($tbo_hotel_detail);
     $tbo_hotel_detail=$tbo_hotel_detail->data ?? '';
     $tbo_hotel_image= $tbo_hotel_detail->images ?? '';
     $image= json_decode($tbo_hotel_image);
     $tbo_hotel_attractions= $tbo_hotel_detail->attractions ?? '';
     $attractions = json_decode($tbo_hotel_attractions);
     
     $slug='tbo';
    // print_r($image);die();
     
     
     
    ?>
                                        <div class="col-md-12 mb-4">
                                        <div class="row parent_row">
                                            <div class="col-md-3">
                                                <div class="">
                                                    <img class="tour-img" style="width:100%; height: 150px;" src="{{URL::to($image[1])}}" alt="">
                                                    
                                                </div>
                                            </div>
                                             
                                            <div class="col-md-6">
                                                <h5 class="card-title">
                                                    <a href="{{URL::to('')}}/hotel/detail/{{$tbo_hotel_detail->hotel_code ?? ''}}/{{$tbo_hotel_detail->hotel_name ?? ''}}/{{$slug}}" style="text-decoration:none;font-size: 1.5rem;">{{$tbo_hotel_detail->hotel_name  ?? ''}}</a>
                                                </h5>
                                                <h6 class="departure-date"><i class="fa-solid fa-plane-departure"></i>   
                                                 <i class="dripicons-location"></i>
                                                    {{$tbo_hotel_detail->address  ?? ''}}{{$tbo_hotel_detail->country_name  ?? ''}}{{$tbo_hotel_detail->city_name  ?? ''}}
                                                    </h6>
                                                <p>5.0 
                                                
                                                <?php
                                                $StarRating=5;
                                                      if($StarRating == 1){
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                       }
                                                        if($StarRating == 2){
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         }
                                            
                                              
                                                        if($StarRating == 3){
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                          }
                                            
                                              
                                                       if($StarRating == 4){
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                           
                                                       }
                                            
                                              
                                                         if($StarRating == 5){
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                          }
                                                  ?>                                                    
                                                </p><p>
                                                </p><p class="tour-description">
                                                    
                                                    
                                                    {{$tbo_hotel_detail->phone_no  ?? ''}}
                                                    </p>
                                                <hr>
                                                
                                            
                                                    
                                                </div>
                                          
                                            <div class="col-md-3 pt-2">
                                                    <h6>
                                                   
                                                    </h6>
                                                    <div class="price">
                                                       
                                                                
                                                          <?php
                                            $currency=$hotela->Currency;
                                            $minRate=$hotela->Rooms[0]->TotalFare;
                                            $exchange_price=all_currency_manage($currency,$minRate);
                                            
                                            
                                            ?>
                                             
                                                
                                            
                                            <span id="addCls" class="amount" style="font-size: 15px;">
                                            
                                            
                                            GBP {{$exchange_price ?? ''}} 
                                            </span>
                                           
                                           
                                            
                                            
                                            
                                                                
                                                                
                                                              

                                                </div>
                                                <span class="time_length" style="font-size: 13px;"> <?php echo $check_in?> TO <?php  echo $check_out; ?></span></br>
                                                <div class="time_length"><i class="fa fa-moon-o" aria-hidden="true"></i> <?php echo $room_search  . 'Rooms' . ',' . $adult_count  . 'Adults' . ',' . $child_count .  'Children' ; ?></div>
                                                 <a href="{{URL::to('')}}/hotel/detail/{{$tbo_hotel_detail->hotel_code  ?? ''}}/{{$tbo_hotel_detail->hotel_name  ?? ''}}/{{$slug}}" style="text-decoration:none;" class="btn btn-primary form-control">Book Now</a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                        <?php 
                                        }
                                        ?>
                                    @endforeach
                                @endisset
                                <!--tbo listing end-->
                                
                                
                                
                                
                                 <!--ratehawk listing start -->
                              @if(isset($rate_hawke_res_search->data->hotels)) 
                                
                                <?php
                    $ratehawkhotelcount = count($rate_hawke_res_search->data->hotels);
                    $total_hotel = $total_hotel + $ratehawkhotelcount;
                    
                    $ratehawk_count=1;
                    
                    ?>
                                   @foreach($rate_hawke_res_search->data->hotels as $hotels) 
                                    
                                         <?php
                    if($ratehawk_count <= 5)
                    {
                  
$data_req='{
    "id": "'.$hotels->id.'",
    "language": "en"
}';


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.worldota.net/api/b2b/v3/hotel/info/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>$data_req,
  CURLOPT_HTTPHEADER => array(
    'Authorization: Basic NDM4MTo3NjJkNWY4MS02Y2YyLTRlYTItOWUyZC0wZTljY2QwODZhYzI=',
    'Content-Type: application/json',
    'Cookie: uid=TfTb5mL04HmDUEWsBqSiAg=='
  ),
));

$response = curl_exec($curl);
// echo $response;
curl_close($curl);

$rate_hawke_hotel_details=json_decode($response);
$rate_hawke_hotel_details=$rate_hawke_hotel_details->data;

$slug='ratehawke';
?>
                                        <div class="col-md-12 mb-4">
                                        <div class="row parent_row">
                                            <div class="col-md-3">
                                                <div class="">
                                                     <?php
                                            
$image=$rate_hawke_hotel_details->images[0];
$image = explode('{size}', $image);
$img=$image[0]. '1024x768'.$image[1];

                                            ?>
                                                    <img class="tour-img" style="width:100%; height: 150px;" src="{{$img}}" alt="">
                                                    
                                                </div>
                                            </div>
                                             
                                            <div class="col-md-6">
                                                <h5 class="card-title">
                                                    <a href="{{URL::to('')}}/hotel/detail/{{$rate_hawke_hotel_details->id}}/{{$rate_hawke_hotel_details->name}}/{{$slug}}" style="text-decoration:none;font-size: 1.5rem;">{{$rate_hawke_hotel_details->name  ?? ''}}</a>
                                                </h5>
                                                <h6 class="departure-date"><i class="fa-solid fa-plane-departure"></i>   
                                                 <i class="dripicons-location"></i>
                                                   {{$rate_hawke_hotel_details->address  ?? ''}}
                                           {{$rate_hawke_hotel_details->region->country_code  ?? ''}},{{$rate_hawke_hotel_details->region->name  ?? ''}}<br>
                                           {{$rate_hawke_hotel_details->kind  ?? ''}}
                                                    </h6>
                                                <p>5.0 
                                                
                                                <?php
                                                $StarRating=5;
                                                      if($StarRating == 1){
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                       }
                                                        if($StarRating == 2){
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                               echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         }
                                            
                                              
                                                        if($StarRating == 3){
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                          }
                                            
                                              
                                                       if($StarRating == 4){
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                           
                                                       }
                                            
                                              
                                                         if($StarRating == 5){
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="dripicons-star" style="color:#ffd762;"></i>';
                                                          }
                                                  ?>                                                    
                                                </p><p>
                                                </p><p class="tour-description">
                                                    
                                                    
                                                  {{$rate_hawke_hotel_details->phone  ?? ''}}
                                                    </p>
                                                <hr>
                                                
                                            
                                                    
                                                </div>
                                          
                                            <div class="col-md-3 pt-2">
                                                    <h6>
                                                   
                                                    </h6>
                                                    <div class="price">
                                                       
                                                                
                                                         
                                             
                                                
                                            
                                            <span id="addCls" class="amount" style="font-size: 15px;">
                                            
                                            
                                            GBP {{$hotels->rates[0]->payment_options->payment_types[0]->amount  ?? ''}}
                                            </span>
                                           
                                           
                                            
                                            
                                            
                                                                
                                                                
                                                              

                                                </div>
                                                <span class="time_length" style="font-size: 13px;"> <?php echo $check_in?> TO <?php  echo $check_out; ?></span></br>
                                                <div class="time_length"><i class="fa fa-moon-o" aria-hidden="true"></i> <?php echo $room_search  . 'Rooms' . ',' . $adult_count  . 'Adults' . ',' . $child_count .  'Children' ; ?></div>
                                                 <a href="{{URL::to('')}}/hotel/detail/{{$rate_hawke_hotel_details->id}}/{{$rate_hawke_hotel_details->name}}/{{$slug}}" style="text-decoration:none;" class="btn btn-primary form-control">Book Now</a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                        <?php 
                                        }
                                         $ratehawk_count=$ratehawk_count+1;
                                        ?>
                                    @endforeach
                                @endisset
                                <!--ratehawk listing end-->
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                            </div>
                            
                             <!-- loader start-->
                             <div class="text-center mt-10" id="loder_hides" style="color: #d2b254;"> 
                <p>
              <img style="max-width: 40%;margin-left: 27%;height: auto;vertical-align: middle;border: 0;" src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif"/>
                </p>
                    
                    <span style="font-size: 25px;" class="count-string">Please Wait While We Get More Results.....</span>
                    
                    <input type="text" style="display:none;" class="hotelcount" value="">
                      </div> 
                       <!-- loader end-->
                      
                      
                      
                      
                        </div>
                    </div> 
                    <!-- end tab-content-->
                    
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div> <!-- end row-->
                           
<!-- end row -->

</div>
@endsection
@section('scripts')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<!--<script src="https://code.jquery.com/jquery-3.6.0.slim.js" integrity="sha256-HwWONEZrpuoh951cQD1ov2HUK5zA5DwJ1DNUXaM6FsY=" crossorigin="anonymous"></script>-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY&sensor=false&libraries=places"></script>

<script>

$(document).ready(function(){
     var initialdisplyedhotelcount = $(".hotel_append_div").children().length;
    
    // $(".div_length").html(initialdisplyedhotelcount);

     
     $('.total_hotel_count').html(initialdisplyedhotelcount);
}); 
  $(window).on('load', function() {
 $(".preloader").css("display", "none");
}); 
 
</script>
<script>
   
$(document).ready(function(){
     var initialdisplyedhotelcount = $(".hotel_append_div").children().length;
      var grand_hotel_count = initialdisplyedhotelcount;
        var counter_hotel=0;
       
    
    
    

    var count = true;
   var iteration_count = $('.counter').val();
var temp2='<?php echo  $temp; ?>';
$(window).scroll(function() { 
    
    // 

    var scrolldisplyedhotelcount = $(".hotel_append_div").children().length;
     

    
     
     if ($(window).scrollTop() + window.innerHeight > $(".scroll_div").height() - 50) {
       //console.log('scorp');
       if(count){
             count = false;
        
         //console.log('scorp');


                                $.ajax({
                                     url :  '{{URL::to('iteration_filter1')}}',
                                     type: 'POST',
                                    data: {_token: '{{ csrf_token() }}', 
                                  "iteration_count":  $('.counter').val(),
                                  
                                          },
                                // dataType: 'json',
                            success: function(response){
                               
                                var hotel_result = response['extracted_hotel_arr'];
                                
                                var hotel_type_result = response['extracted_hotel_type_arr'];
                                console.log(hotel_result);
                                var hotelcount = response['session_hotel_count'];
                            




for (var i = 0; i < hotel_result.length; i++) {
    
    
    if(hotel_type_result[i] == 'travellanda'){
        
        
        
        var room_count = hotel_result[i]['Options']['Option'].length;
        if(hotel_result[i]['Options']['Option'][0])
        {
           var boardtype = hotel_result[i]['Options']['Option'][0]['BoardType'];  
        }
        else
        {
            var boardtype = '';  
        }
         if(hotel_result[i]['Options']['Option'][0])
        {
          var TotalPrice = hotel_result[i]['Options']['Option'][0]['TotalPrice'];
        }
        else
        {
            var TotalPrice = '';  
        }
       
        // var TotalPrice = hotel_result[i]['Options']['Option'][0]['TotalPrice'];
        
       
         //var TotalPrice = 600;
        
        //  console.log(room_count);
        
        var travellanda_append_data=`  <div class="col-md-12 mb-4">
                                        <div class="row parent_row">
                                            <div class="col-md-3">
                                                <div class="image-cover img-${hotel_result[i]['HotelId']}">
                                            
                                          <img class="img-responsive" src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif"  alt="">

                                            
                                        </div>
                                            </div>
                                             
                                            <div class="col-md-6">
                                                <h5 class="card-title">
                                                    <a href="{{URL::to('')}}/hotel/detail/${hotel_result[i]['HotelId']}/${hotel_result[i]['HotelName']}/{{'travellanda'}}" style="text-decoration:none;font-size: 1.5rem;">${hotel_result[i]['HotelName']}</a>
                                                </h5>
                                                <h6 class="departure-date"><i class="fa-solid fa-plane-departure"></i>   
                                                 <i class="dripicons-location"></i>
                                                 <span class="location-${hotel_result[i]['HotelId']}-address"></span>
                                                   </h6>
                                     <div class="item-hotel-star">`
                                            if(hotel_result[i]['StarRating'] == "1"){
            travellanda_append_data +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                            
                       
                    </ul>
                </div>
            </div>`
            }
            if(hotel_result[i]['StarRating'] == "2"){
            travellanda_append_data +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                           <i class="dripicons-star" style="color:#ffd762;"></i>
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                           
                       
                    </ul>
                </div>
            </div>`
            }
            if(hotel_result[i]['StarRating'] == "3"){
            travellanda_append_data +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                            
                       
                    </ul>
                </div>
            </div>`
            }
            if(hotel_result[i]['StarRating'] == "4"){
            travellanda_append_data +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                       
                    </ul>
                </div>
            </div>`
            }
            if(hotel_result[i]['StarRating'] == "5"){
            travellanda_append_data +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                            <i class="dripicons-star" style="color:#ffd762;"></i>
                       
                    </ul>
                </div>
            </div>`
            }
                                         travellanda_append_data +=`</div>
                                        
                                        
                                        
                                        
                                       
                                        
                                        
                                        <div class="row">
                                            <div class="col-md-10">
                                                
                                            
                                        
                                     
                                </div>
                                        <div class="col-md-2">
                                      <button style="display: none;" data-popover-target="popover_${hotel_result[i]['HotelId']}" type="button" class="btn tooltip-btn btn-primary">Facilities</button>
                                      </div>
                                      </div> 
                                      
                                      <div class="item-address board_div" style="color:green;">`
                                          travellanda_append_data +=`<p><i class="fa-solid fa-check"></i>${boardtype}</p>`
                                           
                                            
                                            
                                            
                                            
                                            
                                          
                                        travellanda_append_data +=`</div>
                                                <p>
                                                </p><p class="tour-description">
                                                    
                                                    
                                                    </p>
                                                <hr>
                                                <div class="row f-13">
                                                    
                                                    
                                                   
                                                </div>
                                            
                                                    
                                                </div>
                                          
                                            <div class="col-md-3 pt-2">
                                                    <h6>
                                                   
                                                    </h6>
                                                    <div class="price">
                                                       
                                                               
                                                                
                                                                <h6>
                                                                    
                                                                      ${room_count} Rooms Available with 
                                                                     ${boardtype}
                                                                </h6>
                                                            
                                            
                                            
                                             
                                                
                                            
                                            <span id="addCls" class="amount" style="font-size: 15px;">
                                            
                                            
                                            GBP ${TotalPrice}
                                            </span>
                                                        
                                                              

                                                </div>
                                                <span class="time_length" style="font-size: 13px;"> <?php echo $check_in?> TO <?php  echo $check_out; ?></span></br>
                                                <div class="time_length"><i class="fa fa-moon-o" aria-hidden="true"></i> <?php echo $room_search  . 'Rooms' . ',' . $adult_count  . 'Adults' . ',' . $child_count .  'Children' ; ?></div>
                                                 <a href="{{URL::to('')}}/hotel/detail/${hotel_result[i]['HotelId']}/${hotel_result[i]['HotelName']}/{{'travellanda'}}" style="text-decoration:none;" class="btn btn-primary form-control">Book Now</a>
                                            </div>
                                        </div>
                                    </div>`;
        

            

        
$('.hotel_append_div').append(travellanda_append_data);
 gettravellandaHotelDetailsAndFacilities(hotel_result[i]['HotelId'],hotel_result[i]['HotelId']);
        
        
        
        
        
    }
    
    
     
    

  console.log('i'+i); 
 counter_hotel=counter_hotel+1; 
 temp2=+temp2 + +1;
}



 



var increased = parseFloat($('.counter').val()) + 5;

$('.counter').val(increased);
count = true;
             
                            }
                                });
          
       }
      
      
    }
    console.log('grand_hotel_count ='+grand_hotel_count); 
       var grand_hotel_count1=counter_hotel+initialdisplyedhotelcount;
        console.log('grand_hotel_count1 ='+grand_hotel_count1); 
     if(grand_hotel_count1 == grand_hotel_count)
    {
        
        $("#loder_hides").css("display", "none");
    }
   
});

function getHotelDetailsAndFacilities(hotel_code,inc_id){
    // console.log(hotel_code);
    $.ajax({
            url: '{{ URL::to("get_hotel_detail_ajaxdd1") }}',
            method: "POST",
            data: {
                _token: '{{ csrf_token() }}', 
                code: hotel_code, 
            },
            success: function (response) {
               
                var hotel_bed_content =JSON.parse(response);
                //  console.log(hotel_bed_content);
                // console.log(['images'][0]['path']);
                var img_path = hotel_bed_content['images'][0]['path'];
                var address = hotel_bed_content['address']['content'];
                var board = hotel_bed_content['boards'];
                var description = hotel_bed_content['description']['content'];
                var faciliti = hotel_bed_content['facilities'];
                console.log(faciliti[0]['description']['content']);
                // console.log("address"+address);
                // console.log(board[0]['description']['content']);
                
                var img = `<img src="https://photos.hotelbeds.com/giata/bigger/${img_path}" class="img-responsive" alt="">`;
                  $('.img-'+inc_id+'').html(img);
                  
                  $('.location-'+inc_id+'-address').html(`<p><i class="awe-icon awe-icon-marker-2"></i> ${address}</p>`);
                  var text = description;
                 var des = text.substr(0, 50);
                  $('.item-'+inc_id+'-content').html(`<p>${des}</p>`);
                  for(var i = 0;i < 5; i++){
                  $('.hotel_facility'+inc_id+'').append(`<p>${faciliti[i]['description']['content']}</p>`);
                  }
                  
                  for(var i = 0;i < 2; i++){
                    //  $('.g-attributes-'+inc_id+'-board').append(`<span class="item term"><i class="icofont-medal"></i>${board[i]['description']['content']}</span>`);  
                  }
                 
           
            }
    }).done(function( msg ) {
                console.log('hotelbed is complete now ');
            
        });
}





function gettravellandaHotelDetailsAndFacilities(hotel_code,inc_id){
    $.ajax({
            url: '{{ URL::to("get_travellandahotel_detail_ajax1") }}',
            method: "POST",
            data: {
                _token: '{{ csrf_token() }}', 
                code: hotel_code, 
            },
            success: function (response) {
                console.log(response);
                var travellanda_content =JSON.parse(response);
                var travellanda_contents =JSON.parse(travellanda_content);
                // console.log(travellanda_contents['Body']['Hotels']['Hotel']['Images']['Image'][0]);
                var img_path = travellanda_contents['Body']['Hotels']['Hotel']['Images']['Image'][0];
                var address = travellanda_contents['Body']['Hotels']['Hotel']['Address'];
                var Location = travellanda_contents['Body']['Hotels']['Hotel']['Location'];
                var board = travellanda_contents['Body']['Hotels']['Hotel']['Facilities']['Facility']
                var description = travellanda_contents['Body']['Hotels']['Hotel']['Description'];
                // console.log(img_path);
                // console.log(address);
                // console.log(board);
                // console.log(description);
                
                var img = `<img src="${img_path}" class="img-responsive" alt="">`;
                  $('.img-'+inc_id+'').html(img);
                  
                  $('.location-'+inc_id+'-address').html(`<p><i class="icofont-paper-plane"></i> ${address}</p>`);
                  var text = description;
                 var des = text.substr(0, 50);
                  
                  
                  
                  $('.item-'+inc_id+'-content').html(`<p>${des}</p>`);
                  
                  for(var i = 0;i < 2; i++){
                     $('.g-attributes-'+inc_id+'-board').append(`<span class="item term"><i class="icofont-medal"></i>${board[i]['FacilityName']}</span>`);  
                  }
            }
    }).done(function( msg ) {
                //console.log('travellanda is complete now ');
            
        });
}





function gettboHotelDetailsAndFacilities(hotel_code,inc_id){
    $.ajax({
            url: '{{ URL::to("get_tbohotel_detail_ajax1") }}',
            method: "POST",
            data: {
                _token: '{{ csrf_token() }}', 
                code: hotel_code, 
            },
            success: function (response) {

                var tbo_content =JSON.parse(response);
                var tbo_content =JSON.parse(tbo_content);
                
                var hotelcode = tbo_content['data']['hotel_code'];
                
                var img = tbo_content['data']['images'];
               
                var img_pathz = JSON.parse(img);
                var img_path = img_pathz[1];
                 
                var hotel_name = tbo_content['data']['hotel_name'];
                
                var address = tbo_content['data']['address'];
                 
                var rating = tbo_content['data']['hotel_rating'];
                
                var phone_no = tbo_content['data']['phone_no'];
                // console.log(img_path);
                // console.log(address);
                // console.log(rating);
                // console.log(phone_no);
                
                var img = `<img src="${img_path}" class="img-responsive" alt="">`;
                  $('.img-'+inc_id+'').html(img);
                  
                var title =  $('.hotel_title_'+inc_id+'').html(`<h2>
                                                <a href="{{URL::to('')}}/hotel/detail/${hotelcode}/${hotel_name}/{{'tbo'}}">${hotel_name}</a>
                                  </h2>`)
                var title =  $('.hotel_book_'+inc_id+'').html(`
                                                <a style="background: rgb(40, 135, 28);color: #fff;" class="awe-btn" href="{{URL::to('')}}/hotel/detail/${hotelcode}/${hotel_name}/{{'tbo'}}">Book Now</a>
                                 `)
                  
                  $('.location-'+inc_id+'-address').html(`<p><i class="awe-icon awe-icon-marker-2"></i> ${address}</p>`);
              
                  $('.available_room_'+inc_id+'').html(`<p>${phone_no}</p>`);
                  
                  var unorderlist =`<ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">`
                  if(rating == 1){
                      unorderlist+=`<li><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 2){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 3){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 4){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 5){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  
                  
                  
                  `</ul>`;
                  
                  
                  $('.rating-'+inc_id+'').html(unorderlist);
                  
               
               
            }
    }).done(function( msg ) {
                console.log('tbo is complete now ');
            
        });
}




function getratehawkHotelDetailsAndFacilities(hotel_code,inc_id){
    $.ajax({
            url: '{{ URL::to("get_ratehawkhotel_detail_ajax1") }}',
            method: "POST",
            data: {
                _token: '{{ csrf_token() }}', 
                code: hotel_code, 
            },
            success: function (response) {

                var rate_content =JSON.parse(response);
               
                var hotelcode = rate_content['id'];
                
                var img_path = rate_content['images'][0];
                var strArray = img_path.split("{size}");
                var img_path = strArray[0]+'1024x768'+strArray[1];
                console.log(strArray);
               
                var hotel_name = rate_content['name'];
                
                var address = rate_content['address'];
                 
                var rating = rate_content['star_rating'];
                
                var phone_no = rate_content['phone'];
                // console.log(img_path);
                // console.log(address);
                // console.log(rating);
                // console.log(phone_no);
                
                var img = `<img src="${img_path}" class="img-responsive" alt="">`;
                  $('.img-'+inc_id+'').html(img);
                  
                var title =  $('.hotel_title_'+inc_id+'').html(`<h2>
                                                <a href="{{URL::to('')}}/hotel/detail/${hotelcode}/${hotel_name}/{{'ratehawke'}}">${hotel_name}</a>
                                  </h2>`)
                var title =  $('.hotel_book_'+inc_id+'').html(`
                                                <a style="background: rgb(40, 135, 28);color: #fff;" class="awe-btn" href="{{URL::to('')}}/hotel/detail/${hotelcode}/${hotel_name}/{{'ratehawke'}}">Book Now</a>
                                 `)
                  
                  $('.location-'+inc_id+'-address').html(`<p><i class="awe-icon awe-icon-marker-2"></i> ${address}</p>`);
              
                  $('.available_room_'+inc_id+'').html(`<p>${phone_no}</p>`);
                  
                  var unorderlist =`<ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">`
                  if(rating == 1){
                      unorderlist+=`<li><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 2){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 3){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 4){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 5){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  
                  
                  
                  `</ul>`;
                  
                  
                  $('.rating-'+inc_id+'').html(unorderlist);
                  
              
    
            }
    }).done(function( msg ) {
                console.log('ratehawk is complete now ');
            
        });
}
});





</script>
@stop
