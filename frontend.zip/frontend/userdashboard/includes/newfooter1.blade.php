<?php $currency=Session::get('currency_symbol'); ?>
        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6">
                            <script>document.write(new Date().getFullYear())</script> © Synchronous Digital
                        </div>
                        <div class="col-md-6">
                            <div class="text-md-end footer-links d-none d-md-block">
                                <a href="javascript: void(0);">About</a>
                                <a href="javascript: void(0);">Support</a>
                                <a href="javascript: void(0);">Contact Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- end Footer -->
    </div>
</div>

    <div class="end-bar">

        <div class="rightbar-title">
            <a href="javascript:void(0);" class="end-bar-toggle float-end">
                <i class="dripicons-cross noti-icon"></i>
            </a>
            <h5 class="m-0">Settings</h5>
        </div>

        <div class="rightbar-content h-100" data-simplebar>

            <div class="p-3">
                <div class="alert alert-warning" role="alert">
                    <strong>Customize </strong> the overall color scheme, sidebar menu, etc.
                </div>

                <!-- Settings -->
                <h5 class="mt-3">Color Scheme</h5>
                <hr class="mt-1" />

                <div class="form-check form-switch mb-1">
                    <input class="form-check-input" type="checkbox" name="color-scheme-mode" value="light" id="light-mode-check" checked>
                    <label class="form-check-label" for="light-mode-check">Light Mode</label>
                </div>

                <div class="form-check form-switch mb-1">
                    <input class="form-check-input" type="checkbox" name="color-scheme-mode" value="dark" id="dark-mode-check">
                    <label class="form-check-label" for="dark-mode-check">Dark Mode</label>
                </div>
   

                <!-- Width -->
                <h5 class="mt-4">Width</h5>
                <hr class="mt-1" />
                <div class="form-check form-switch mb-1">
                    <input class="form-check-input" type="checkbox" name="width" value="fluid" id="fluid-check" checked>
                    <label class="form-check-label" for="fluid-check">Fluid</label>
                </div>

                <div class="form-check form-switch mb-1">
                    <input class="form-check-input" type="checkbox" name="width" value="boxed" id="boxed-check">
                    <label class="form-check-label" for="boxed-check">Boxed</label>
                </div>
    

                <!-- Left Sidebar-->
                <h5 class="mt-4">Left Sidebar</h5>
                <hr class="mt-1" />
                <div class="form-check form-switch mb-1">
                    <input class="form-check-input" type="checkbox" name="theme" value="default" id="default-check">
                    <label class="form-check-label" for="default-check">Default</label>
                </div>

                <div class="form-check form-switch mb-1">
                    <input class="form-check-input" type="checkbox" name="theme" value="light" id="light-check" checked>
                    <label class="form-check-label" for="light-check">Light</label>
                </div>

                <div class="form-check form-switch mb-3">
                    <input class="form-check-input" type="checkbox" name="theme" value="dark" id="dark-check">
                    <label class="form-check-label" for="dark-check">Dark</label>
                </div>

                <div class="form-check form-switch mb-1">
                    <input class="form-check-input" type="checkbox" name="compact" value="fixed" id="fixed-check" checked>
                    <label class="form-check-label" for="fixed-check">Fixed</label>
                </div>

                <div class="form-check form-switch mb-1">
                    <input class="form-check-input" type="checkbox" name="compact" value="condensed" id="condensed-check">
                    <label class="form-check-label" for="condensed-check">Condensed</label>
                </div>

                <div class="form-check form-switch mb-1">
                    <input class="form-check-input" type="checkbox" name="compact" value="scrollable" id="scrollable-check">
                    <label class="form-check-label" for="scrollable-check">Scrollable</label>
                </div>

                <div class="d-grid mt-4">
                    <button class="btn btn-primary" id="resetBtn">Reset to Default</button>
        
                    <a href="https://themes.getbootstrap.com/product/hyper-responsive-admin-dashboard-template/"
                        class="btn btn-danger mt-3" target="_blank"><i class="mdi mdi-basket me-1"></i> Purchase Now</a>
                </div>
            </div> <!-- end padding-->

        </div>
    </div>

    <div class="rightbar-overlay"></div>
 
    <!-- bundle -->
    <script src="{{asset('public/admin_package/assets/js/vendor.min.js')}}"></script>
    <script src="{{asset('public/admin_package/assets/js/app.min.js')}}"></script>

    <!-- third party js -->
    <script src="{{asset('public/admin_package/assets/js/vendor/apexcharts.min.js')}}"></script>
    
    <script src="{{asset('public/admin_package/assets/js/pages/demo.apex-column.js')}}"></script>
    
    <script src="{{asset('public/admin_package/assets/js/vendor/jquery-jvectormap-1.2.2.min.js')}}"></script>
    <script src="{{asset('public/admin_package/assets/js/vendor/jquery-jvectormap-world-mill-en.js')}}"></script>
    <!-- third party js ends -->
    
    <script src="{{asset('public/admin_package/assets/js/vendor/dataTables.keyTable.min.js')}}"></script>
    <script src="{{asset('public/admin_package/assets/js/vendor/dataTables.select.min.js')}}"></script>
    <script src="{{asset('public/admin_package/assets/js/vendor/fixedColumns.bootstrap5.min.js')}}"></script>
    <script src="{{asset('public/admin_package/assets/js/vendor/fixedHeader.bootstrap5.min.js')}}"></script>
    <!-- third party js ends -->

    <!-- demo app -->
    <script src="{{asset('public/admin_package/assets/js/pages/demo.datatable-init.js')}}"></script>
    <!-- quill js -->
    <script src="{{asset('public/admin_package/assets/js/vendor/quill.min.js')}}"></script>
    <!-- quill Init js-->
    <script src="{{asset('public/admin_package/assets/js/pages/demo.quilljs.js')}}"></script>
    <script src="{{asset('public/admin_package/assets/js/pages/demo.form-wizard.js')}}"></script>
    
    <script src="{{asset('public/admin_package/assets/js/vendor/dropzone.min.js')}}"></script>
    <!-- init js -->
    <script src="{{asset('public/admin_package/assets/js/ui/component.fileupload.js')}}"></script>
    
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>

    <script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
    
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css'>
    
    <!--datetimepicker-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
    
    
    <!-- Init js-->
    <script src="{{asset('public/admin_package/assets/js/pages/demo.tasks.js')}}"></script>
    <!--<script src="assets/js/pages/demo.tasks.js"></script>-->
    
    <!-- Todo js -->
    <script src="{{asset('public/admin_package/assets/js/ui/component.todo.js')}}"></script>
    
    <!-- demo app -->
    <script src="{{asset('public/admin_package/assets/js/pages/demo.crm-dashboard.js')}}"></script>
    <!-- end demo js-->
    
    <script src="{{asset('public/admin_package/assets/js/pages/demo.crm-project.js')}}"></script>
    
    <script src="{{asset('public/admin_package/assets/js/pages/demo.dashboard-wallet.js')}}"></script>
    <script src="https://apexcharts.com/samples/assets/stock-prices.js"></script>
    <script src="https://apexcharts.com/samples/assets/series1000.js"></script>
    <script src="https://apexcharts.com/samples/assets/github-data.js"></script>
    <script src="https://apexcharts.com/samples/assets/irregular-data-series.js"></script>
        
    @yield('scripts')

    <!--booking packages script start By JaMsHaid ChEeNa-->
    <script src="https://transloadit.edgly.net/releases/uppy/v1.6.0/uppy.min.js"></script>

    <script>
        $(document).ready(function () {
            $("#currency_conversion").on('change', function(){
                var value_c = $('option:selected', this).val();
                var attr_conversion_type = $('option:selected', this).attr('attr_conversion_type');
            
                $("#select_exchange_type").val(attr_conversion_type);
                    const usingSplit = value_c.split(' ');
                    var value_1 = usingSplit['0'];
                    var value_2 = usingSplit['2'];
                    exchange_currency_funs(value_1,value_2);
                });
            });

            function exchange_currency_funs(value_1,value_2){
                $(".currency_value1").html(value_1);
                $(".currency_value2").html(value_1);
                $(".currency_value3").html(value_1);
                $(".currency_value_exchange_1").text(value_2);
                $(".currency_value_exchange_2").text(value_2);
                $(".currency_value_exchange_3").text(value_2);  
            }
        
            var uppy = Uppy.Core()
            .use(Uppy.Dashboard, {
                inline: true,
                target: '#drag-drop-area'
            })
            .use(Uppy.Tus, {endpoint: 'https://master.tus.io/files/'}) //you can put upload URL here, where you want to upload images
            uppy.on('complete', (result) => {
                // console.log('Upload complete! We’ve uploaded these files:', result.successful)
            })
    </script>
    
    <script type="text/javascript">
        
        $(document).ready(function(){
            $('#select_contries').change(function(){
                 var country_id = $(this).val();
                //  alert(country_id);
                $.ajax({
                    url:"{{URL::to('get_cites_book')}}" + '/' + country_id,
                    method: "GET",
                    data: {
                    	country_id:country_id
                    },
                    success:function(data){
                        //  console.log(data);  
         	            $("#all_cities").empty();
                        
                        $.each(data.all_cities, function (key, value) {
                            $("#all_cities").append('<option value="' + value.name + '">' + value.name + '</option>');
                        });
                    }
                });  
            });
        });
        
    </script>
         
    <script type="text/javascript">
        
        $(document).ready(function(){
            $('#bookingPackage').change(function(){
                var id = this.selectedOptions[0].value;
                var title  = this.selectedOptions[0].text;
                if(this.selectedOptions[0].text)
                {
                    $.ajax({
                        url:"{{URL::to('super_admin/get_booking_package_tour')}}" + '/' + title,
                        method: "GET",
                        data: {
                        	title:title
                        },
                        success:function(data){
                            var tour_data_id = data.tours_packages['id'];
                            var tour_data_customer_id = data.tours_packages['customer_id'];
                            var tour_external_packages = data.tours_packages['external_packages'];
                            // alert(data_package_name);
                            var tour_title = data.tours_packages['title'];
                            var tour_content = data.tours_packages['content'];
                            var tour_categories = data.tours_packages['categories'];
                            // var tour_categories = JSON.stringify(tour_categories);
                            // console.log(tour_categories);
                            var tour_tour_attributes = data.tours_packages['tour_attributes'];
                            var tour_start_date = data.tours_packages['start_date'];
                            var tour_end_date = data.tours_packages['end_date'];
                            var tour_time_duration = data.tours_packages['time_duration'];
                            var tour_tour_min_people = data.tours_packages['tour_min_people'];
                            var tour_tour_max_people = data.tours_packages['tour_max_people'];
                            var tour_Itinerary_details = data.tours_packages['Itinerary_details'];
                            var tour_itinerary_details_1 = data.tours_packages['tour_itinerary_details_1'];
                            var tour_location = data.tours_packages['tour_location'];
                            var tour_real_address = data.tours_packages['tour_real_address'];
                            var tour_pricing = data.tours_packages['tour_pricing'];
                            var tour_sale_price = data.tours_packages['tour_sale_price'];
                            var tour_publish = data.tours_packages['tour_publish'];
                            var tour_author = data.tours_packages['tour_author'];
                            var tour_feature = data.tours_packages['tour_feature'];
                            var tour_defalut_state = data.tours_packages['defalut_state'];
                            var tour_featured_image = data.tours_packages['tour_featured_image'];
                            var tour_banner_image = data.tours_packages['tour_banner_image'];
                            var tour_extra_price = data.tours_packages['tour_extra_price'];
                            var tour_extra_price_1 = data.tours_packages['tour_extra_price_1'];
                            var tour_faq = data.tours_packages['tour_faq'];
                            var tour_faq_1 = data.tours_packages['tour_faq_1'];
                            var tour_property_country = data.tours_packages['property_country'];
                            var tour_property_city = data.tours_packages['property_city'];
                            var tour_hotel_name = data.tours_packages['hotel_name'];
                            var tour_hotel_rooms_type = data.tours_packages['hotel_rooms_type'];
                            var tour_price_per_night = data.tours_packages['price_per_night'];
                            var tour_total_price_per_night = data.tours_packages['total_price_per_night'];
                            var tour_sharing1 = data.tours_packages['tour_sharing1'];
                            var tour_sharing2 = data.tours_packages['tour_sharing2'];
                            var tour_sharing3 = data.tours_packages['tour_sharing3'];
                            var tour_sharing4 = data.tours_packages['tour_sharing4'];
                            
                            $("#form_fields").empty();
                            var tour_packages_data ='<div class="card mt-3"><div class="card-body"><h4>Tour Package Details</h4><div class="mb-3"><div class="row"><div class="col-md-2"><h4>Title : </h4></div>  <div class="col-md-2"><p>'+ tour_title +'</p></div></div> <div class="row"><div class="col-md-2"><h4>Content : </h4></div>  <div class="col-md-10"><p>'+ tour_content +'</p></div></div> <div class="row"><div class="col-md-2"><h4>Departure : </h4></div>  <div class="col-md-10"><p>'+ tour_end_date +'</p></div></div> <div class="row"><div class="col-md-2"><h4>Arrival : </h4></div>  <div class="col-md-10"><p>'+ tour_start_date +'</p></div></div> <div class="row"><div class="col-md-2"><h4>Time Duration : </h4></div>  <div class="col-md-10"><p>'+ tour_time_duration +'</p></div></div> <div class="row"><div class="col-md-2"><h4>Minimum People : </h4></div>  <div class="col-md-10"><p>'+ tour_tour_min_people +'</p></div></div> <div class="row"><div class="col-md-2"><h4>Maximum People : </h4></div>  <div class="col-md-10"><p>'+ tour_tour_max_people +'</p></div></div> <div class="row"><div class="col-md-2"><h4>Tour Location : </h4></div>  <div class="col-md-10"><p>'+ tour_location +'</p></div></div> <div class="row"><div class="col-md-4"><h4>Tour Real Address : </h4></div>  <div class="col-md-8"><p>'+ tour_real_address +'</p></div></div>  <div class="row"><div class="col-md-3"><h4>Tour Pricing : </h4></div>  <div class="col-md-3"><p>'+ tour_pricing +'</p></div><div class="col-md-3"><h4>Tour Sale Pricing : </h4></div>  <div class="col-md-3"><p>'+ tour_sale_price +'</p></div></div>                                   </div><a href="javascript:;" data-bs-toggle="modal" data-bs-target="#bs-example-modal-lg" style="float: right;" class="btn btn-info">Book Now</a></div></div>';
                            
                            $("#form_fields").append(tour_packages_data);
                	    }
                	});
                }
                
                if(this.selectedOptions[0].value)
                {
                    $.ajax({
                        url:"{{URL::to('super_admin/get_booking_package')}}" + '/' + id,
                        method: "GET",
                        data: {
                        	id:id
                        },
                        success:function(data){
                            var data_id = data.umrah_packages['id'];
                            var data_customer_id = data.umrah_packages['customer_id'];
                            var data_package_name = data.umrah_packages['package_name'];
                            // alert(data_package_name);
                            var data_check_in = data.umrah_packages['check_in'];
                            var data_check_out = data.umrah_packages['check_out'];
                            var data_status = data.umrah_packages['status'];
                            var data_makkah_hotel_name = data.umrah_packages['makkah_hotel_name'];
                            var data_makkah_location = data.umrah_packages['makkah_location'];
                            var data_makkah_check_in = data.umrah_packages['makkah_check_in'];
                            var data_makkah_check_out = data.umrah_packages['makkah_check_out'];
                            var data_makkah_no_of_nights = data.umrah_packages['makkah_no_of_nights'];
                            var data_makkah_sharing_1 = data.umrah_packages['makkah_sharing_1'];
                            var data_makkah_sharing_2 = data.umrah_packages['makkah_sharing_2'];
                            var data_makkah_sharing_3 = data.umrah_packages['makkah_sharing_3'];
                            var data_makkah_sharing_4 = data.umrah_packages['makkah_sharing_4'];
                            var data_makkah_price = data.umrah_packages['makkah_price'];
                            var data_makkah_board_basis = data.umrah_packages['makkah_board_basis'];
                            var data_makkah_room_views = data.umrah_packages['makkah_room_views'];
                            
                            var data_madina_hotel_name = data.umrah_packages['madina_hotel_name'];
                            var data_check_madina_location = data.umrah_packages['madina_location'];
                            var data_madina_check_in = data.umrah_packages['madina_check_in'];
                            var data_madina_check_out = data.umrah_packages['madina_check_out'];
                            var data_madina_no_of_nights = data.umrah_packages['madina_no_of_nights'];
                            var data_madina_sharing_1 = data.umrah_packages['madina_sharing_1'];
                            var data_madina_sharing_2 = data.umrah_packages['madina_sharing_2'];
                            var data_madina_sharing_3 = data.umrah_packages['madina_sharing_3'];
                            var data_madina_sharing_4 = data.umrah_packages['madina_sharing_4'];
                            var data_makkah_price = data.umrah_packages['madina_price'];
                            var data_madina_board_basis = data.umrah_packages['madina_board_basis'];
                            var data_madina_room_views = data.umrah_packages['madina_room_views'];
                            
                            var data_transfer_pickup_location = data.umrah_packages['transfer_pickup_location'];
                            var data_transfer_drop_location = data.umrah_packages['transfer_drop_location'];
                            var data_transfer_pickup_date_time = data.umrah_packages['transfer_pickup_date_time'];
                            var data_transfer_vehicle = data.umrah_packages['transfer_vehicle'];
                            
                            var data_flights_airline = data.umrah_packages['flights_airline'];
                            var data_flights_departure_airport = data.umrah_packages['flights_departure_airport'];
                            var data_flights_arrival_airport = data.umrah_packages['flights_arrival_airport'];
                            var data_flights_departure__return_airport = data.umrah_packages['flights_departure__return_airport'];
                            var data_flights_arrival_return_airport = data.umrah_packages['flights_arrival_return_airport'];
                            var data_flights_departure__return_date = data.umrah_packages['flights_departure__return_date'];
                            var data_flights_arrival_return_date = data.umrah_packages['flights_arrival_return_date'];
                            var data_flights_price = data.umrah_packages['flights_price'];
                            
                            var data_visa_fee = data.umrah_packages['visa_fee'];
                            var data_visit_visa_fee = data.umrah_packages['visit_visa_fee'];
                            var data_details_visa = data.umrah_packages['details_visa'];
                            
                            var data_administration_charges = data.umrah_packages['administration_charges'];
                            var data_administration_details = data.umrah_packages['administration_details'];
                            
                            $("#form_fields").empty();
    
                            var umrah_packages_data ='<div class="card mt-3"><div class="card-body"><h4>Umrah Package Details</h4><div class="mb-3"><div class="row"><div class="col-md-6"><label class="form-label">Package Name</label><input name="package_name" class="form-control" value='+ data_package_name +' /></div><div class="col-md-6"><label class="form-label">Check In</label><input type="date" name="check_in" class="form-control" /></div><div class="col-md-6"><label class="form-label">Check Out</label><input type="date" name="check_out" class="form-control"  /></div><div class="col-md-6"><label class="form-label">Status</label><input name="status" class="form-control" /></div></div></div></div></div>';
                            $("#form_fields").append(umrah_packages_data);
                        }
                    });
                }       
            });
        });
        
    </script>

    <script>
        $(document).ready(function () {
            $('#example').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });
            $('#example1').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });
            $('#example2').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });
            $('#example3').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });
            $('#example4').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });
        }); 
    </script>

    <script>

        $(document).ready(function () {
            $("#makkah_check_out").on('change',function(){
                var dateInmakkah = $('#makkah_check_in').val();
                var dateOutmakkah = $('#makkah_check_out').val();
                const date1 = new Date(dateInmakkah);
                const date2 = new Date(dateOutmakkah);
                const diffTime = Math.abs(date2 - date1);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                var diff=(diffDays);
                $("#makkah_no_of_nights").val(diff);
            });
        });

        $("#enter_makkah_sharing_1_price").keyup(function(){
            var price = $("#makkah_no_of_nights").val();
            var pa =$("#enter_makkah_sharing_1_price").val();
            var t_price= price * pa;
            $("#makkah_sharing_1_total_price").val(t_price);
        });
    
        $("#enter_makkah_sharing_2_price").keyup(function(){
            var price = $("#makkah_no_of_nights").val();
            var pa =$("#enter_makkah_sharing_2_price").val();
            var t_price= price * pa;
            $("#makkah_sharing_2_total_price").val(t_price);
        });
    
        $("#enter_makkah_sharing_3_price").keyup(function(){
            var price = $("#makkah_no_of_nights").val();
            var pa =$("#enter_makkah_sharing_3_price").val();
            var t_price= price * pa;
            $("#makkah_sharing_3_total_price").val(t_price);
        });
    
        $("#enter_makkah_sharing_4_price").keyup(function(){
            var price = $("#makkah_no_of_nights").val();
            var pa =$("#enter_makkah_sharing_4_price").val();
            var t_price= price * pa;
            $("#makkah_sharing_4_total_price").val(t_price);
        });

        $("#Sharing_1").on('click',function(){
            $("#Sharing_1_slide_down").slideToggle();
            $("#Sharing_1_slide_down").val(t_price);
        });

        $("#Sharing_2").on('click',function(){
            $("#Sharing_2_slide_down").slideToggle();
        });
        
        $("#Sharing_3").on('click',function(){
            $("#Sharing_3_slide_down").slideToggle();
        });
        
        $("#Sharing_4").on('click',function(){
            $("#Sharing_4_slide_down").slideToggle();
        });
                     
        $(document).ready(function () {
            $("#madina_check_out").on('change',function(){
                var dateInmakkah = $('#madina_check_in').val();
                var dateOutmakkah = $('#madina_check_out').val();
                const date1 = new Date(dateInmakkah);
                const date2 = new Date(dateOutmakkah);
                const diffTime = Math.abs(date2 - date1);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                var diff=(diffDays);
                $("#madina_no_of_nights").val(diff);
            });
        });

        $("#enter_madina_sharing_1_price").keyup(function(){
            var price = $("#madina_no_of_nights").val();
            var pa =$("#enter_madina_sharing_1_price").val();
            var t_price= price * pa;
            $("#madina_sharing_1_total_price").val(t_price);
        });
        
        $("#enter_madina_sharing_2_price").keyup(function(){
            var price = $("#madina_no_of_nights").val();
            var pa =$("#enter_madina_sharing_2_price").val();
            var t_price= price * pa;
            $("#madina_sharing_2_total_price").val(t_price);
        });
        
        $("#enter_madina_sharing_3_price").keyup(function(){
            var price = $("#madina_no_of_nights").val();
            var pa =$("#enter_madina_sharing_3_price").val();
            var t_price= price * pa;
            $("#madina_sharing_3_total_price").val(t_price);
        });
        
        $("#enter_madina_sharing_4_price").keyup(function(){
            var price = $("#madina_no_of_nights").val();
            var pa =$("#enter_madina_sharing_4_price").val();
            var t_price= price * pa;
            $("#madina_sharing_4_total_price").val(t_price);
        });

        $("#Sharing_1_madina").on('click',function(){
            $("#Sharing_1_slide_down_madina").slideToggle();
            $("#Sharing_1_slide_down_madina").val(t_price);
        });
        
        $("#Sharing_2_madina").on('click',function(){
            $("#Sharing_2_slide_down_madina").slideToggle();
        });
        
        $("#Sharing_3_madina").on('click',function(){
            $("#Sharing_3_slide_down_madina").slideToggle();
        });
        
        $("#Sharing_4_madina").on('click',function(){
            $("#Sharing_4_slide_down_madina").slideToggle();
        });

    </script>
    
    <script>
    
        function add_numberElse(){
            var flights_prices=parseFloat($("#flights_prices").val());  
            if(isNaN(flights_prices)) 
            {
                flights_prices=0;
            }
            else
            {
                var flights_prices=parseFloat($("#flights_prices").val()); 
            }
           //alert(flights_prices);
            var visa_price_select=parseFloat($("#exchange_rate_visa_total_amount").val());  
            if(isNaN(visa_price_select)) 
            {
                visa_price_select=0;
            }
            else
            {
                var visa_price_select=parseFloat($("#exchange_rate_visa_total_amount").val());
            }
      
            var transportation_price_per_person_select=parseFloat($("#exchange_rate_transportation_price_per_person").val());
            if(isNaN(transportation_price_per_person_select)) 
            {
                transportation_price_per_person_select=0;
            }
            else
            {
                var transportation_price_per_person_select=parseFloat($("#exchange_rate_transportation_price_per_person").val());
            }
            
            var count =$("#city_No").val();
            
            // var city_slc =$(".city_slc").val();
            // console.log(city_slc);
            // var count = city_slc.length;
            // console.log('count : '+count);
            
            // console.log('Cites are '+count);
            var quad_hotel=0;
            var triple_hotel=0;
            var double_hotel=0;
            var more_quad_hotel=0;
            var more_triple_hotel=0;
            var more_double_hotel=0;
       
            for(var i=1; i<=5; i++){
                var hotel_acc_type = $('#hotel_acc_type_'+i+'').val();
                //console.log('hotel_acc_type '+hotel_acc_type)
                var hotel_markup = parseFloat($("#hotel_acc_price_"+i+'').val());
                
                if(isNaN(hotel_markup)) 
                {
                    hotel_markup=0;
                }
                else
                {
                    var hotel_markup=parseFloat($("#hotel_acc_price_"+i+'').val());
                }
                
                if(hotel_acc_type == 'Quad')
                {
                   quad_hotel = quad_hotel + hotel_markup;
                    var quad_hotel1 = quad_hotel.toFixed(2);
                    $('#quad_cost_price').val(quad_hotel1);
                    
                //   console.log('quad single hotel '+quad_hotel)
                }
                if(hotel_acc_type == 'Triple')
                {
                   triple_hotel = triple_hotel + hotel_markup;
                   var triple_hotel1 = triple_hotel.toFixed(2);
                   $('#triple_cost_price').val(triple_hotel1);
                }
                if(hotel_acc_type == 'Double')
                {
                   double_hotel = double_hotel + hotel_markup;
                   var double_hotel1 = double_hotel.toFixed(2);
                     $('#double_cost_price').val(double_hotel1);
                }
                       
            }
            
            var sumData = flights_prices + visa_price_select + transportation_price_per_person_select;
            //console.log('sumdata : '+sumData);
            //console.log('quad_hotel : '+quad_hotel);
            if(quad_hotel != 0){
                var quadCost = quad_hotel + sumData;
               
            }else{
                var quadCost = 0;
            }
             //console.log('quadCost total amount jm : '+quadCost);
            if(triple_hotel != 0){
                var tripleCost = triple_hotel + sumData;
            }else{
                var tripleCost = 0;
            }
            
            if(double_hotel != 0){
                var doubleCost = double_hotel + sumData;
            }else{
                var doubleCost = 0;
            }
            //console.log('double_hotel total amount jm : '+doubleCost);
            quadCost = quadCost.toFixed(2);
            $('#quad_cost_price').val(quadCost);
            tripleCost = tripleCost.toFixed(2);
            $('#triple_cost_price').val(tripleCost);
            doubleCost = doubleCost.toFixed(2);
          $('#double_cost_price').val(doubleCost);
    
            // console.log('quad '+quad_hotel+' triple '+triple_hotel+' double '+double_hotel);
            
            for(var k=1; k<=50; k++){
                
                var more_hotel_acc_type=$('#more_hotel_acc_type_'+k+'').val(); 
                var more_hotel_markup=$('#more_hotel_acc_price_'+k+'').val();  
                
                if(isNaN(more_hotel_markup)) 
                {
                    more_hotel_markup=0;
                }
                else
                {
                    var more_hotel_markup=parseFloat($("#more_hotel_acc_price_"+k+'').val());
                }
                if(more_hotel_acc_type == 'Quad')
                {
                   more_quad_hotel = more_quad_hotel + more_hotel_markup;
                   var more_quad_hotel1 = more_quad_hotel.toFixed(2);
                //   console.log('more_quad_hotel ' + more_quad_hotel1); 
                    //  $('#quad_cost_price').val(more_quad_hotel1);
                }
                if(more_hotel_acc_type == 'Triple')
                {
                    more_triple_hotel = more_triple_hotel + more_hotel_markup;
                    var more_triple_hotel1 = more_triple_hotel.toFixed(2);
                    // console.log('more_triple_hotel ' + more_triple_hotel);
                    // $('#triple_cost_price').val(more_triple_hotel1);
                }
                if(more_hotel_acc_type == 'Double')
                {
                   more_double_hotel = more_double_hotel + more_hotel_markup;
                   var more_double_hotel1 = more_double_hotel.toFixed(2);
                //   console.log('more_double_hotel ' + more_double_hotel);
                //   $('#double_cost_price').val(more_double_hotel1);
                }
            }
            
            // console.log('quad more '+more_quad_hotel+' triple more '+more_triple_hotel+' double more '+more_double_hotel);
            
            var morequadCost = sumData + more_quad_hotel;
            morequadCost = morequadCost.toFixed(2);
            
            if(more_quad_hotel == 0){
                // console.log('if morequadCost');
                if(quadCost != 0){
                    $('#quad_cost_price').val(quadCost);   
                }else{
                    $('#quad_cost_price').val(0);   
                }
            }else{
                // console.log('elseif morequadCost');
                $('#quad_cost_price').val(morequadCost);   
            }
            
            var moretripleCost = sumData + more_triple_hotel;
            moretripleCost = moretripleCost.toFixed(2);
            
            if(more_triple_hotel == 0){
                // console.log('if moretripleCost');
                if(tripleCost != 0){
                    $('#triple_cost_price').val(tripleCost);   
                }else{
                    $('#triple_cost_price').val(0);   
                }  
            }else{
                // console.log('elseif moretripleCost');
                $('#triple_cost_price').val(moretripleCost);   
            }
            
            
            var moredoubleCost = sumData + more_double_hotel;
            moredoubleCost = moredoubleCost.toFixed(2);
            
            if(more_double_hotel == 0){
                // console.log('if moredoubleCost');
                if(doubleCost != 0){
                    //$('#double_cost_price').val(doubleCost);   
                }else{
                    $('#double_cost_price').val(0);   
                }   
            }else{
                // console.log('elseif moredoubleCost');
                //$('#double_cost_price').val(moredoubleCost);
            }
        }
    
        function add_numberElse_1(){
            var count =$("#city_No").val();
            // var city_slc =$(".city_slc").val();
            // var count = city_slc.length;
            //   console.log('Cites are '+count);
            var quad_hotel=0;
            var triple_hotel=0;
            var double_hotel=0;
            var more_quad_hotel=0;
            var more_triple_hotel=0;
            var more_double_hotel=0;
            
            var total_markup=parseFloat($("#total_markup").val());  
            if(isNaN(total_markup)) 
            {
                total_markup=0;
            }
            else
            {
                var total_markup=parseFloat($("#total_markup").val()); 
            }
            
            var total_visa_markup=parseFloat($("#total_visa_markup").val());  
            if(isNaN(total_visa_markup)) 
            {
                total_visa_markup=0;
            }
            else
            {
                var total_visa_markup=parseFloat($("#total_visa_markup").val());
            }
            
            var transportation_markup_total=parseFloat($("#transportation_markup_total").val());
            if(isNaN(transportation_markup_total)) 
            {
                transportation_markup_total=0;
            }
            else
            {
                var transportation_markup_total=parseFloat($("#transportation_markup_total").val());
            }
           
            for(var i=1; i<=5; i++){
                var hotel_acc_type=$('#hotel_acc_type_'+i+'').val();
                console.log("hotel_acc_type : " + hotel_acc_type);
                var hotel_markup=parseFloat($("#hotel_markup_total_"+i+'').val());
                console.log("hotel_markup : " + hotel_markup);
                
                if(isNaN(hotel_markup)) 
                { 
                    hotel_markup=0;
                }
                else
                {
                    var hotel_markup=parseFloat($("#hotel_markup_total_"+i+'').val());
                }
                
                if(hotel_acc_type == 'Quad')
                {
                    quad_hotel = quad_hotel + hotel_markup + more_quad_hotel;
                    var quad_hotel1 = quad_hotel.toFixed(2);
                    $('#quad_grand_total_amount').val(quad_hotel1);
                }
                if(hotel_acc_type == 'Triple')
                {
                    triple_hotel = triple_hotel  +hotel_markup + more_triple_hotel;
                    var triple_hotel1 = triple_hotel.toFixed(2);
                    $('#triple_grand_total_amount').val(triple_hotel1);
                }
                if(hotel_acc_type == 'Double')
                {
                    double_hotel = double_hotel + hotel_markup  + more_double_hotel;
                    var double_hotel1 = double_hotel.toFixed(2);
                    $('#double_grand_total_amount').val(double_hotel1);
                }
            }
            
            var sumData = total_markup + total_visa_markup + transportation_markup_total;
            $('#without_acc_sale_price').val(sumData);
            
            console.log('sumData : '+sumData);
            
            if(quad_hotel != 0){
               var quadCost = quad_hotel + sumData;
            }else{
                var quadCost = 0;
            }
            
            if(triple_hotel != 0){
                var tripleCost = triple_hotel + sumData;
            }else{
                var tripleCost = 0;
            }
            
            if(double_hotel != 0){
                var doubleCost = double_hotel + sumData;
            }else{
                var doubleCost = 0;
            }
            
            quadCost = quadCost.toFixed(2);
            $('#quad_grand_total_amount').val(quadCost);
            tripleCost = tripleCost.toFixed(2);
            $('#triple_grand_total_amount').val(tripleCost);
            doubleCost = doubleCost.toFixed(2);
            $('#double_grand_total_amount').val(doubleCost);
            
            for(var k=1; k<=20; k++){
                var more_hotel_acc_type=$('#more_hotel_acc_type_'+k+'').val(); 
                var more_hotel_markup=$('#more_hotel_markup_total_'+k+'').val();     
                if(isNaN(more_hotel_markup)) 
                {
                    more_hotel_markup=0;
                }
                else
                {
                    var more_hotel_markup=parseFloat($("#more_hotel_markup_total_"+k+'').val());
                }
                if(more_hotel_acc_type == 'Quad')
                {
                    more_quad_hotel = more_quad_hotel + more_hotel_markup;
                    // console.log('more_quad_hotel ' + more_quad_hotel);
                    var more_quad_hotel1 = 0;
                    more_quad_hotel1 = more_quad_hotel.toFixed(2);
                    $('#quad_grand_total_amount').val(more_quad_hotel1);
                }
                if(more_hotel_acc_type == 'Triple')
                {
                    more_triple_hotel = more_triple_hotel + more_hotel_markup;
                    // console.log('more_triple_hotel ' + more_triple_hotel);
                    var more_triple_hotel1 = 0;
                    more_triple_hotel1 = more_triple_hotel.toFixed(2);
                    $('#triple_grand_total_amount').val(more_triple_hotel1);
                }
                if(more_hotel_acc_type == 'Double')
                {
                    more_double_hotel = more_double_hotel +more_hotel_markup;
                    // console.log('more_double_hotel ' + more_double_hotel);
                    var more_double_hotel1 = 0;
                    more_double_hotel1 = more_double_hotel.toFixed(2);
                    $('#double_grand_total_amount').val(more_double_hotel1);
                }
            }
        
            var morequadCost = sumData + more_quad_hotel;
            morequadCost = morequadCost.toFixed(2);
            
            if(more_quad_hotel == 0){
                // console.log('if morequadCost');
                if(quadCost != 0){
                    $('#quad_grand_total_amount').val(quadCost);   
                }else{
                    $('#quad_grand_total_amount').val(0);   
                }   
            }else{
                // console.log('elseif morequadCost');
                $('#quad_grand_total_amount').val(morequadCost);   
            }
            
            var moretripleCost = sumData + more_triple_hotel;
            moretripleCost = moretripleCost.toFixed(2);
            
            if(more_triple_hotel == 0){
                // console.log('if moretripleCost');
                if(tripleCost != 0){
                    $('#triple_grand_total_amount').val(tripleCost);   
                }else{
                    $('#triple_grand_total_amount').val(0);   
                }   
            }else{
                // console.log('elseif moretripleCost');
                $('#triple_grand_total_amount').val(moretripleCost);   
            }
            
            
            var moredoubleCost = sumData + more_double_hotel;
            moredoubleCost = moredoubleCost.toFixed(2);
            
            if(more_double_hotel == 0){
                // console.log('if moredoubleCost');
                if(doubleCost != 0){
                    $('#double_grand_total_amount').val(doubleCost);   
                }else{
                    $('#double_grand_total_amount').val(0);   
                }   
            }else{
                // console.log('elseif moredoubleCost');
                $('#double_grand_total_amount').val(moredoubleCost);
            }
            
        }
        
    </script>

    <script>

        $("#Itinerary").on('click',function(){
            $("#Itinerary_select").slideToggle();
        });
        
        $("#extra_price").on('click',function(){
            $("#extraprice_select").slideToggle();
        });
        
        $("#faq").on('click',function(){
            $("#faq_select").slideToggle();
        });
        
        $("#destination1").on('click',function(){
            $("#select_destination1").slideToggle();
        });
        
        $("#flights_inc").on('click',function(){
            $("#select_flights_inc").slideToggle();
        });
        
        $("#transportation").on('click',function(){
            $("#select_transportation").slideToggle();
        });
        
        $("#visa_inc").on('click',function(){
            $("#select_visa_inc").slideToggle();
        });
    
        $(document).on('click','#flights_inc',function(){
            $.ajax({    
                type: "GET",
                url: "get_other_Airline_Name",             
                dataType: "html",                  
                success: function(data){ 
                    var data1 = JSON.parse(data);
                    var data2 = JSON.parse(data1['airline_Name']);
                	$("#other_Airline_Name2").empty();
                	$("#return_other_Airline_Name2").empty();
                    $.each(data2['airline_Name'], function(key, value) {
                        $("#other_Airline_Name2").append('<option attr=' +value.other_Airline_Name+ ' value=' +value.other_Airline_Name+ '>' +value.other_Airline_Name+'</option>');
                        $("#return_other_Airline_Name2").append('<option attr=' +value.other_Airline_Name+ ' value=' +value.other_Airline_Name+ '>' +value.other_Airline_Name+'</option>');
                    });  
                }
            });
        });
        
        $(document).on('click','#add_hotel_accomodation',function(){
            $.ajax({    
                type: "GET",
                url: "get_other_Hotel_Name",             
                dataType: "html",                  
                success: function(data){
                    var data1 = JSON.parse(data);
                    $(".other_Hotel_Name").empty();
                    $(".other_Hotel_Type").empty();
                    $.each(data1['hotel_Name'], function(key, data2) {
                        // console.log(data2['other_Hotel_Name']);
                        var other_Hotel_Name_Data = `<option attr="${data2.other_Hotel_Name}" value="${data2.other_Hotel_Name}"> ${data2.other_Hotel_Name}</option>`;
                        $(".other_Hotel_Name").append(other_Hotel_Name_Data);
                    });
                    $.each(data1['hotel_Type'], function(key, data3) {
                    	var other_Hotel_Name_Type = `<option attr="${data3.id}" value="${data3.other_Hotel_Type}"> ${data3.other_Hotel_Type}</option>`;
                        $(".other_Hotel_Type").append(other_Hotel_Name_Type);
                    });
                    
                }
            });
        });
        
        $(document).on('click','#accomodation',function(){
            $.ajax({    
                type: "GET",
                url: "get_other_Hotel_Name",             
                dataType: "html",                  
                success: function(data){
                    var data1 = JSON.parse(data);
                    $(".other_Hotel_Name").empty();
                    $(".other_Hotel_Type").empty();
                    $.each(data1['hotel_Name'], function(key, data2) {
                        // console.log(data2['other_Hotel_Name']);
                        var other_Hotel_Name_Data = `<option attr="${data2.other_Hotel_Name}" value="${data2.other_Hotel_Name}"> ${data2.other_Hotel_Name}</option>`;
                        $(".other_Hotel_Name").append(other_Hotel_Name_Data);
                    });
                    $.each(data1['hotel_Type'], function(key, data3) {
                    	var other_Hotel_Name_Type = `<option attr="${data3.id}" value="${data3.other_Hotel_Type}"> ${data3.other_Hotel_Type}</option>`;
                        $(".other_Hotel_Type").append(other_Hotel_Name_Type);
                    });
                    
                }
            });
        });
    
        $('#submitForm_hotel_name').on('click',function(e){
            e.preventDefault();
            let other_Hotel_Name = $('#other_Hotel_Name').val();
            $.ajax({
                url: "super_admin/submit_other_Hotel_Name",
                type:"POST",
                data:{
                    "_token": "{{ csrf_token() }}",
                    other_Hotel_Name:other_Hotel_Name,
                },
                success:function(response){
                    if(response){
                        // console.log(response);
                        var data1 = response
                        // console.log(data1);
                        var data = data1['hotel_Name_get'];
                        // console.log(data);
                        $(".other_Hotel_Name").empty();
                        $.each(data, function(key, value) {
                            var other_Hotel_Name_Data = `<option attr="${value.other_Hotel_Name}" value="${value.other_Hotel_Name}"> ${value.other_Hotel_Name}</option>`;
                            $(".other_Hotel_Name").append(other_Hotel_Name_Data);
                        });
                        alert('Other Hotel Name Added SuccessFUl!');
                    }
                    $('#success-message').text(response.success);
                },
            });
        });
        
        $('#submitForm_hotel_type').on('click',function(e){
            e.preventDefault();
            let other_Hotel_Type = $('#other_Hotel_Type').val();
            $.ajax({
                url: "submit_other_Hotel_Type",
                type:"POST",
                data:{
                    "_token": "{{ csrf_token() }}",
                    other_Hotel_Type:other_Hotel_Type,
                },
                success:function(response){
                    if(response){
                        var data1 = JSON.parse(response)
                        var data = data1['hotel_Name_get'];
                        $(".other_Hotel_Type").empty();
                        $.each(data, function(key, value) {
                            var other_Hotel_Type_Data = `<option attr="${value.id}" value="${value.other_Hotel_Type}"> ${value.other_Hotel_Type}</option>`;
                            $(".other_Hotel_Type").append(other_Hotel_Type_Data);
                        });
                        alert('Other Hotel Name Added SuccessFUl!');
                    }
                    $('#success-message').text(response.success);
                },
            });
        });
        
        $(document).on('click','#accomodation_edit',function(){
            $.ajax({    
                type: "GET",
                url: "edit_tour/get_other_Hotel_Name",             
                dataType: "html",                  
                success: function(data){
                    var data1 = JSON.parse(data);
                    $(".other_Hotel_Name").empty();
                    $(".other_Hotel_Type").empty();
                    $.each(data1['hotel_Name'], function(key, data2) {
                        // console.log(data2['other_Hotel_Name']);
                        var other_Hotel_Name_Data = `<option attr="${data2.other_Hotel_Name}" value="${data2.other_Hotel_Name}"> ${data2.other_Hotel_Name}</option>`;
                        $(".other_Hotel_Name").append(other_Hotel_Name_Data);
                    });
                    $.each(data1['hotel_Type'], function(key, data3) {
                    	var other_Hotel_Name_Type = `<option attr="${data3.id}" value="${data3.other_Hotel_Type}"> ${data3.other_Hotel_Type}</option>`;
                        $(".other_Hotel_Type").append(other_Hotel_Name_Type);
                    });
                    
                }
            });
        });
        
        $("#accomodation").on('click',function(){
            
            $("#append_accomodation_data_cost1").empty();
            $("#append_accomodation_data_cost").empty();
            $("#append_accomodation").empty();
            var packages_get_city = $('#packages_get_city').val();
            var decodeURI_city = JSON.parse(packages_get_city);
            var city_slc =$(".city_slc").val();
            var count = city_slc.length;
            var j=0;
            for (let i = 1; i <= count; i++) {
        
                var data = `<div class="mb-2" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;">
                                <h4>
                                    City #${i} (${decodeURI_city[i-1]})
                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon_${i}"
                                        data-bs-toggle="tooltip" data-bs-placement="right" title="Fill all the information of City ${decodeURI_city[i-1]}">
                                    </i>
                                </h4> 
                    <div class="row">
                        
                        <input type="hidden" name="hotel_city_name[]" id="hotel_city_name" value="${decodeURI_city[i-1]}"/>
                    <div class="col-xl-3">
                        <label for="">Hotel Name</label>
                        <div class="input-group">
                            <select type="text" onchange="hotel_fun(${i})" id="acc_hotel_name_${i}" name="acc_hotel_name[]" class="form-control other_Hotel_Name acc_hotel_name_class_${i}">
                            
                            </select>
                            <span title="Add Hotel Name" class="input-group-btn input-group-append">
                                <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#hotel-name-modal" type="button">+</button>
                            </span>
                        </div>
                    </div>
                    <div class="col-xl-3"><label for="">Check In</label><input type="date" id="makkah_accomodation_check_in_${i}" name="acc_check_in[]" class="form-control date makkah_accomodation_check_in_class_${i}">
                    </div><div class="col-xl-3"><label for="">Check Out</label><input type="date" id="makkah_accomodation_check_out_date_${i}"  name="acc_check_out[]" onchange="makkah_accomodation_check_out(${i})"  class="form-control date makkah_accomodation_check_out_date_class_${i}"></div>
                    <div class="col-xl-3"><label for="">No Of Nights</label><input type="text" id="acomodation_nights_${i}" name="acc_no_of_nightst[]" class="form-control acomodation_nights_class_${i}"></div>
                    
                    <div class="col-xl-2"><label for="">Room Type</label>
                        <div class="input-group">
                            <select onchange="hotel_type_fun(${i})" name="acc_type[]" id="hotel_type_${i}" class="form-control other_Hotel_Type hotel_type_class_${i}"  data-placeholder="Choose ...">
                                <option value="">Choose ...</option>
                                <option attr="4" value="Quad">Quad</option>
                                <option attr="3" value="Triple">Triple</option>
                                <option attr="2" value="Double">Double</option>
                            </select>
                            <span title="Add Hotel Type" class="input-group-btn input-group-append">
                                <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#hotel-type-modal" type="button">+</button>
                            </span>
                        </div>
                        
                    </div>
                    <div class="col-xl-2"><label for="">Quantity</label><input type="text" id="simpleinput" name="acc_qty[]" class="form-control acc_qty_class_${i}"></div>
                    
                    <div class="col-xl-2">
                    <label for="">Pax</label>
                    <input type="text" id="simpleinput" name="acc_pax[]" class="form-control acc_pax_class_${i}" readonly>
                    </div>
                    <div class="col-xl-3">
                    <label for="">Price Per Person/Night</label>
                    <div class="input-group">
                        <span class="input-group-btn input-group-append">
                            <a class="btn btn-primary bootstrap-touchspin-up">
                               <?php echo $currency; ?>
                            </a>
                        </span>
                        <input type="text" id="makkah_acc_price_${i}" onchange="makkah_acc_price_funs(${i})" value="" name="acc_price[]" class="form-control makkah_acc_price_class_${i}">
                    </div>
                    
                    </div>
                    
                    <div class="col-xl-3"><label for="">Total Amount/Per Person</label>
                     <div class="input-group">
                        <span class="input-group-btn input-group-append">
                            <a class="btn btn-primary bootstrap-touchspin-up">
                               <?php echo $currency; ?>
                            </a>
                        </span>
                        <input readonly type="text"  id="makkah_acc_total_amount_${i}"  name="acc_total_amount[]" class="form-control makkah_acc_total_amount_class_${i}">
                    </div>
                    </div>
                    
                    <div id="append_add_accomodation_${i}"></div>
                    <div class="mt-2"><a href="javascript:;" onclick="add_more_accomodation(${i})"  id="" class="btn btn-info" style="float: right;"> + Add More </a></div>
                    
                    
                      <div class="col-xl-12">
                         <div class="mb-3">
                         
                         
                         
                         
                          <label for="simpleinput" class="form-label">Room Amenities</label>
                          <textarea name="hotel_whats_included[]" class="form-control" id="" cols="10" rows="0"></textarea>
                          
                         </div>
                      </div>
                    
                    <div class="col-xl-12"><label for="">Image</label><input type="file"  id=""  name="accomodation_image${j}[]" class="form-control" multiple></div>
                    </div></div>`;
          
          
                var data_cost=`<div class="row" id="${i}">
                                <input type="text" name="hotel_name_markup[]" hidden>
                                <div class="col-xl-3">
                                    <h4 class="" id="">Accomodation Cost ${decodeURI_city[i-1]}</h4>
                                </div>
                                <div class="col-xl-9"></div>
                                
                            
                             <div class="col-xl-3">
                                    
                      <input type="text" id="hotel_acc_type_${i}" readonly="" name="room_type[]" class="form-control id_cot">
                            </div>
                             <div class="col-xl-3">
                                <div class="input-group">
                                    <input type="text" id="hotel_acc_price_${i}" readonly="" name="without_markup_price[]" class="form-control">
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                           <?php echo $currency; ?>
                                        </a>
                                    </span>
                                </div>
                            </div>
                             <div class="col-xl-2">
                                     
                                      <select name="markup_type[]" onchange="hotel_markup_type(${i})" id="hotel_markup_types_${i}" class="form-control">
                                            <option value="">Markup Type</option>
                                            <option value="%">Percentage</option>
                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                      </select>
                      
                            </div>
                            <div class="col-xl-2">
                                     
                     <input type="hidden" id="" name="" class="form-control">
                     
                     <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                    <input type="text"  class="form-control" id="hotel_markup_${i}" name="markup[]">
                    <span class="input-group-btn input-group-append">
                        <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="hotel_markup_mrk_${i}">%</div></button>
                        </span>
                        </div>
                     
                     
                     
                            </div>
                            <div class="col-xl-2">
                                <div class="input-group">
                                    <input type="text" id="hotel_markup_total_${i}" name="markup_price[]" class="form-control id_cot">
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                           <?php echo $currency; ?>
                                        </a>
                                    </span>
                                </div> 
                            </div>
                            </div>`;
          
              
                $("#append_accomodation_data_cost").append(data_cost);
              
                $("#append_accomodation").append(data);
                
                $('.acc_qty_class_'+i+'').on('change',function(){
                    
                    var acc_qty_class = $(this).val();
                    // console.log(acc_qty_class);
                    var hotel_type = $('.hotel_type_class_'+i+'').find('option:selected').attr('attr');
                    // console.log(hotel_type);
                    var mult = parseFloat(acc_qty_class) * parseFloat(hotel_type);
                    // console.log(mult);
                    $('.acc_pax_class_'+i+'').val(mult);
                    
                });
                
                j = j + 1;
            }
        
            var select_ct =$(".select_ct").val();
            
            var count_1 = select_ct.length;
            
            for (let i = 1; i <= count_1; i++) {
                // console.log(i);
              var data1 = `<div class="mb-2" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;"><h4>City #${i} </h4><div class="row"><div class="col-xl-3"><label for="">Hotel Name</label><input type="text" id="simpleinput" name="acc_hotel_name[]" class="form-control">
            </div><div class="col-xl-3"><label for="">Check In</label><input type="date" id="simpleinput" name="acc_check_in[]" class="form-control">
            </div><div class="col-xl-3"><label for="">Check Out</label><input type="date" id="simpleinput" name="acc_check_out[]" class="form-control"></div><div class="col-xl-3"><label for="">No Of Nights</label><input type="text" id="nights" name="acc_no_of_nightst[]" class="form-control"></div><div class="col-xl-3"><label for="">Room Type</label>
            <select name="acc_type[]" id="property_city" class="form-control"  data-placeholder="Choose ..."><option value="">Choose ...</option><option value="Quad">Quad</option><option value="Triple">Triple</option><option value="Double">Double</option></select></div>
            <div class="col-xl-3"><label for="">Quantity</label><input type="text" id="simpleinput" name="acc_qty[]" class="form-control"></div>
            <div class="col-xl-3"><label for="">Pax</label><input type="text" id="simpleinput" name="acc_pax[]" class="form-control"></div><div class="col-xl-3"><label for="">Price</label>
            <input type="text" id="simpleinput" name="acc_price[]" class="form-control"></div><div class="col-xl-3"><label for="">Currency</label><select name="acc_currency[]" id="property_city" class="form-control"><option value="">Choose ...</option><option value="SAR">SAR</option><option value="Dollar">Dollar</option><option value="Pound">Pound</option></select></div><div class="col-xl-3"><label for="">Comission</label><input type="text" id="simpleinput" name="acc_commision[]" class="form-control"></div><div class="col-xl-3"><label for="">Sale Price</label><input type="text" id="simpleinput" name="acc_sale_Porice[]" class="form-control"></div><div class="col-xl-3"><label for="">Total Amount</label><input type="text" id="simpleinput" name="acc_total_amount[]" class="form-control"></div>
            <div id="append_add_accomodations_${i}"></div><div class="mt-2"><a href="javascript:;" onclick="add_more_accomodations(${i})"  id="" class="btn btn-info" style="float: right;"> + Add More </a></div></div></div>`;
              $("#append_accomodation").append(data1);   
              
            }
        
            $("#select_accomodation").slideToggle();
        });
    
        $("#add_hotel_accomodation").on('click',function(){
            
            $('#tour_location_city').removeAttr('value');
            $('#packages_get_city').removeAttr('value');
            
            var city_No = $('#city_No').val();
            if(city_No > 0){
                
                $("#append_accomodation_data_cost1").empty();
                $("#append_accomodation_data_cost").empty();
                $("#append_accomodation").empty();
                
                var packages_get_city = $('#city_No').val();
                
                var j = 0;
                for (let i = 1; i <= city_No; i++) {
                    var data = `<div class="mb-2" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;" id="del_hotel${i}">
                                    
                                    <h4>
                                        City #${i}
                                    </h4> 
                                    <div class="row" style="padding-bottom: 25px;">
                                        
                                        <div class="col-xl-3">
                                            <label for="">Select City</label>
                                            <input type="hidden" id="lat_city${i}" name="lat_city[]" value="">
                                            <input type="hidden" id="lan_city${i}" name="lan_city[]" value="">
                                            <input type="hidden" id="country_code_city${i}" name="country_code_city[]" value="">
                                            <select type="text" id="property_city_new${i}" onchange="put_tour_location(${i})" name="hotel_city_name[]" class="form-control property_city_new"></select>
                                        </div>
                        
                                        <div class="col-xl-3">
                                            <label for="">Hotel Name</label>
                                            <div class="input-group">
                                                <input type="text" onchange="hotel_fun(${i})" id="acc_hotel_name_${i}" name="acc_hotel_name[]" class="form-control acc_hotel_name_class_${i}">
                                                
                                                <!--<span title="Add Hotel Name" class="input-group-btn input-group-append">
                                                    <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#hotel-name-modal" type="button">+</button>
                                                </span>!-->
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-3"><label for="">Check In</label><input type="date" id="makkah_accomodation_check_in_${i}" name="acc_check_in[]" class="form-control date makkah_accomodation_check_in_class_${i}">
                                        </div><div class="col-xl-3"><label for="">Check Out</label><input type="date" id="makkah_accomodation_check_out_date_${i}"  name="acc_check_out[]" onchange="makkah_accomodation_check_out(${i})"  class="form-control date makkah_accomodation_check_out_date_class_${i}"></div>
                                        
                                        <div class="col-xl-3"><label for="">No Of Nights</label>
                                        <input readonly type="text" id="acomodation_nights_${i}" name="acc_no_of_nightst[]" class="form-control acomodation_nights_class_${i}"></div>
                                        
                                        <input readonly type="hidden" id="acc_nights_key_${i}" value="${i}" class="form-control">
                                        
                                        
                                        <div class="col-xl-3"><label for="">Room Type</label>
                                            <div class="input-group">
                                                <select onchange="hotel_type_fun(${i})" name="acc_type[]" id="hotel_type_${i}" class="form-control other_Hotel_Type hotel_type_class_${i}"  data-placeholder="Choose ...">
                                                    <option value="">Choose ...</option>
                                                    <option attr="4" value="Quad">Quad</option>
                                                    <option attr="3" value="Triple">Triple</option>
                                                    <option attr="2" value="Double">Double</option>
                                                </select>
                                                <span title="Add Hotel Type" class="input-group-btn input-group-append">
                                                    <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#hotel-type-modal" type="button">+</button>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-xl-3"><label for="">Quantity</label><input type="text" id="simpleinput" name="acc_qty[]" class="form-control acc_qty_class_${i}"></div>
                                        
                                        <div class="col-xl-3">
                                            <label for="">Pax</label>
                                            <input type="text" id="simpleinput" name="acc_pax[]" class="form-control acc_pax_class_${i}" readonly>
                                        </div>
                                        
                                        <div class="col-xl-3">
                                            <label for="">Meal Type</label>
                                            <select name="hotel_meal_type[]" id="hotel_meal_type_${i}" class="form-control"  data-placeholder="Choose ...">
                                                <option value="">Choose ...</option>
                                                <option value="Room only">Room only</option>
                                                <option value="Breakfast">Breakfast</option>
                                                <option value="Lunch">Lunch</option>
                                                <option value="Dinner">Dinner</option>
                                            </select>
                                        </div>
                                        
                                        <div class="col-xl-3">
                                        <label for="">Price Per Person/Night</label>
                                        <div class="input-group">
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                  <?php echo $currency; ?>
                                                </a>
                                            </span>
                                            <input type="text" id="makkah_acc_price_${i}" onchange="makkah_acc_price_funs(${i})" value="" name="acc_price[]" class="form-control makkah_acc_price_class_${i}">
                                        </div>
                        
                                        </div>
                                        
                                        <div class="col-xl-3"><label for="">Total Amount/Per Person</label>
                                         <div class="input-group">
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                  <?php echo $currency; ?>
                                                </a>
                                            </span>
                                            <input readonly type="text"  id="makkah_acc_total_amount_${i}"  name="acc_total_amount[]" class="form-control makkah_acc_total_amount_class_${i}">
                                        </div>
                                        </div>
                        
                                        <div id="append_add_accomodation_${i}"></div>
                                        <div class="mt-2"><a href="javascript:;" onclick="add_more_accomodation(${i})"  id="" class="btn btn-info" style="float: right;"> + Add More </a></div>
                                        
                                        <div class="col-xl-12">
                                            <div class="mb-3">
                                                <label for="simpleinput" class="form-label">Room Amenities</label>
                                                <textarea name="hotel_whats_included[]" class="form-control" id="" cols="10" rows="0"></textarea>
                                              
                                            </div>
                                        </div>
                        
                                        <div class="col-xl-12"><label for="">Image</label><input type="file"  id=""  name="accomodation_image${j}[]" class="form-control" multiple></div>
                                        
                                        <div class="mt-2">
                                            <a href="javascript:;" onclick="remove_hotels(${i})" id="${i}" class="btn btn-danger" style="float: right;"> 
                                                Delete Hotel
                                            </a>
                                        </div>
                                        
                                    </div>
                                </div>`;
          
          
                    var data_cost=`<div class="row" id="costing_acc${i}" style="margin-bottom:20px;">
                    
                                        <input type="hidden" id="hotel_Type_Costing" name="markup_Type_Costing[]" value="hotel_Type_Costing" class="form-control">
                                        
                                        <input type="text" name="hotel_name_markup[]" hidden>
                                        <div class="col-xl-3">
                                        </div>
                                        <div class="col-xl-9"></div>
                                    
                                
                                        <div class="col-xl-3">
                                        
                                        <input type="text" id="hotel_acc_type_${i}" readonly="" name="room_type[]" class="form-control id_cot">
                                            </div>
                                             <div class="col-xl-3">
                                                <div class="input-group">
                                                    <input type="text" id="hotel_acc_price_${i}" readonly="" name="without_markup_price[]" class="form-control">
                                                    <span class="input-group-btn input-group-append">
                                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                                          <?php echo $currency; ?>
                                                        </a>
                                                    </span>
                                                </div>
                                            </div>
                                             <div class="col-xl-2">
                                                     
                                                      <select name="markup_type[]" onchange="hotel_markup_type(${i})" id="hotel_markup_types_${i}" class="form-control">
                                                            <option value="">Markup Type</option>
                                                            <option value="%">Percentage</option>
                                                            <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                                      </select>
                                      
                                            </div>
                                            <div class="col-xl-2">
                                                <input type="hidden" id="" name="" class="form-control">
                                                <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                                    <input type="text"  class="form-control" id="hotel_markup_${i}" name="markup[]">
                                                    <span class="input-group-btn input-group-append">
                                                    <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="hotel_markup_mrk_${i}">%</div></button>
                                                    </span>
                                                </div>
                                            </div>
                                        <div class="col-xl-2">
                                            <div class="input-group">
                                                <input type="text" id="hotel_markup_total_${i}" name="markup_price[]" class="form-control id_cot">
                                                <span class="input-group-btn input-group-append">
                                                    <a class="btn btn-primary bootstrap-touchspin-up">
                                                      <?php echo $currency; ?>
                                                    </a>
                                                </span>
                                            </div> 
                                        </div>
                                    </div>`;
          
                    $("#append_accomodation_data_cost").append(data_cost);
                  
                    $("#append_accomodation").append(data);
                    
                    $('.acc_qty_class_'+i+'').on('change',function(){
                        
                        var acc_qty_class = $(this).val();
                        // console.log(acc_qty_class);
                        var hotel_type = $('.hotel_type_class_'+i+'').find('option:selected').attr('attr');
                        // console.log(hotel_type);
                        var mult = parseFloat(acc_qty_class) * parseFloat(hotel_type);
                        // console.log(mult);
                        $('.acc_pax_class_'+i+'').val(mult);
                        
                    });
                    
                    $('#property_city_new'+i+'').on('change',function(){
                       var id = $(this).find('option:selected').attr('attr');
                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                            }
                        });
                        $.ajax({
                            url: '/country_cites_laln/'+id,
                            method: 'post',
                            data: {
                                "_token": "{{ csrf_token() }}",
                                "id": id,
                            },
                            success: function(result){
                                var city_D              = result['city_D'];
                                var lat_city            = city_D['latitude'];
                                var lan_city            = city_D['longitude'];
                                var country_code_city   = city_D['country_code'];
                                $('#lat_city'+i+'').val(lat_city);
                                $('#lan_city'+i+'').val(lan_city);
                                $('#country_code_city'+i+'').val(country_code_city);
                                
                            },
                            error:function(error){
                                console.log(error);
                            }
                        });
                       
                    });
                    
                    var country = $('#property_country').val();
                
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                        }
                    });
                    
                    $.ajax({
                        url: "{{ url('/country_cites1') }}",
                        method: 'post',
                        data: {
                            "_token": "{{ csrf_token() }}",
                            "id": country,
                        },
                        success: function(result){
                            // console.log('cites is call now');
                            // console.log(result);
                            $('.property_city_new').html(result);
                        },
                        error:function(error){
                            // console.log(error);
                        }
                    });
                    
                    j = j + 1;
                    
                    var places_D1 = new google.maps.places.Autocomplete(
                        document.getElementById('acc_hotel_name_'+i+'')
                    );
                    
                    google.maps.event.addListener(places_D1, "place_changed", function () {
                        var places_D1 = places_D1.getPlace();
                        // console.log(places_D1);
                        var address = places_D1.formatted_address;
                        var latitude = places_D1.geometry.location.lat();
                        var longitude = places_D1.geometry.location.lng();
                        var latlng = new google.maps.LatLng(latitude, longitude);
                        var geocoder = (geocoder = new google.maps.Geocoder());
                        geocoder.geocode({ latLng: latlng }, function (results, status) {
                            if (status == google.maps.GeocoderStatus.OK) {
                                if (results[0]) {
                                    var address = results[0].formatted_address;
                                    var pin = results[0].address_components[
                                        results[0].address_components.length - 1
                                    ].long_name;
                                    var country =  results[0].address_components[
                                        results[0].address_components.length - 2
                                      ].long_name;
                                    var state = results[0].address_components[
                                            results[0].address_components.length - 3
                                        ].long_name;
                                    var city = results[0].address_components[
                                            results[0].address_components.length - 4
                                        ].long_name;
                                    var country_code = results[0].address_components[
                                            results[0].address_components.length - 2
                                        ].short_name;
                                    $('#country').val(country);
                                    $('#lat').val(latitude);
                                    $('#long').val(longitude);
                                    $('#pin').val(pin);
                                    $('#city').val(city);
                                    $('#country_code').val(country_code);
                                }
                            }
                        });
                    });
                    
                }
            
                $("#select_accomodation").slideToggle();
                
            }
            else{
                alert("Select Hotels Quantity");
            }
            
        });
        
        // var city_No         = $('#city_No').val();
        var city_No1        = $('#city_No1').val();
        var img_Counter1    = $('#img_Counter1').val();
        // var i               = city_No;
        var j               = img_Counter1;
        
        $("#add_hotel_accomodation_edit").on('click',function(){
            
            city_No1 = parseFloat(city_No1) + 1;
            $('#city_No1').val(city_No1);
            
            var city_No = $('#city_No').val();
            var i       = parseFloat(city_No) + 1;
            $('#city_No').val(i);
            
            var data = `<div class="mb-2" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;" id="del_hotel${i}">
                            <h4>
                                City #${i}
                            </h4> 
                            <div class="row" style="padding-bottom: 25px;">
                                <div class="col-xl-3">
                                    <label for="">Select City</label>
                                    <input type="hidden" id="lat_city${i}" name="lat_city[]" value="">
                                    <input type="hidden" id="lan_city${i}" name="lan_city[]" value="">
                                    <input type="hidden" id="country_code_city${i}" name="country_code_city[]" value="">
                                    <select type="text" id="property_city_new${i}" onchange="put_tour_location_else(${i})" name="hotel_city_name[]" class="form-control property_city_new${i}"></select>
                                </div>
                
                                <div class="col-xl-3">
                                    <label for="">Hotel Name</label>
                                    <div class="input-group">
                                        
                                        <input type="text" onchange="hotel_fun(${i})" id="acc_hotel_name_${i}" name="acc_hotel_name[]" class="form-control acc_hotel_name_class_${i}">
                                    </div>
                                </div>
                                
                                <div class="col-xl-3"><label for="">Check In</label><input type="date" id="makkah_accomodation_check_in_${i}" name="acc_check_in[]" class="form-control date makkah_accomodation_check_in_class_${i}">
                                </div><div class="col-xl-3"><label for="">Check Out</label>
                                <input type="date" id="makkah_accomodation_check_out_date_${i}" name="acc_check_out[]" onchange="makkah_accomodation_check_out(${i})"  class="form-control date makkah_accomodation_check_out_date_class_${i}"></div>
                                
                                <div class="col-xl-3"><label for="">No Of Nights</label>
                                <input readonly type="text" id="acomodation_nights_${i}" value="" name="acc_no_of_nightst[]" class="form-control acomodation_nights_class_${i}"></div>
                                
                                <input readonly type="hidden" id="acc_nights_key_${i}" value="${i}" class="form-control">
                                
                                
                                <div class="col-xl-3"><label for="">Room Type</label>
                                    <div class="input-group">
                                        <select onchange="hotel_type_fun(${i})" name="acc_type[]" id="hotel_type_${i}" class="form-control other_Hotel_Type${i} hotel_type_class_${i}"  data-placeholder="Choose ...">
                                            <option value="">Choose ...</option>
                                            <option attr="4" value="Quad">Quad</option>
                                            <option attr="3" value="Triple">Triple</option>
                                            <option attr="2" value="Double">Double</option>
                                        </select>
                                        <span title="Add Hotel Type" class="input-group-btn input-group-append">
                                            <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#hotel-type-modal" type="button">+</button>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-xl-3"><label for="">Quantity</label><input type="text" id="simpleinput" name="acc_qty[]" class="form-control acc_qty_class_${i}"></div>
                                
                                <div class="col-xl-3">
                                    <label for="">Pax</label>
                                    <input type="text" id="simpleinput" name="acc_pax[]" class="form-control acc_pax_class_${i}" readonly>
                                </div>
                                
                                <div class="col-xl-3">
                                    <label for="">Meal Type</label>
                                    <select name="hotel_meal_type[]" id="hotel_meal_type_${i}" class="form-control" data-placeholder="Choose ...">
                                        <option value="">Choose ...</option>
                                        <option value="Room only">Room only</option>
                                        <option value="Breakfast">Breakfast</option>
                                        <option value="Lunch">Lunch</option>
                                        <option value="Dinner">Dinner</option>
                                    </select>
                                </div>
                                
                                <div class="col-xl-3">
                                <label for="">Price Per Person/Night</label>
                                <div class="input-group">
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                          <?php echo $currency; ?>
                                        </a>
                                    </span>
                                    <input type="text" id="makkah_acc_price_${i}" onchange="makkah_acc_price_funs(${i})" value="" name="acc_price[]" class="form-control makkah_acc_price_class_${i}">
                                </div>
                
                                </div>
                                
                                <div class="col-xl-3"><label for="">Total Amount/Per Person</label>
                                 <div class="input-group">
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up">
                                          <?php echo $currency; ?>
                                        </a>
                                    </span>
                                    <input readonly type="text"  id="makkah_acc_total_amount_${i}"  name="acc_total_amount[]" class="form-control makkah_acc_total_amount_class_${i}">
                                </div>
                                </div>
                
                                <div id="append_add_accomodation_${i}"></div>
                                <div class="mt-2"><a href="javascript:;" onclick="add_more_accomodation_edit(${i})"  id="" class="btn btn-info" style="float: right;"> + Add More </a></div>
                                
                                <div class="col-xl-12">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Room Amenities</label>
                                        <textarea name="hotel_whats_included[]" class="form-control" id="" cols="10" rows="0"></textarea>
                                      
                                    </div>
                                </div>
                
                                <div class="col-xl-12">
                                    <label for="">Image</label>
                                    <input type="file"  id=""  name="accomodation_image${j}[]" class="form-control accomodation_image_edit${j}" multiple>
                                    
                                    <div class="row" style="padding:5px" style="" id="dvPreview"></div>
                                </div>
                                
                                
                                <div class="mt-2">
                                    <a href="javascript:;" onclick="remove_hotels(${i})" id="${i}" class="btn btn-danger" style="float: right;"> 
                                        Delete Hotel
                                    </a>
                                </div>
                                
                            </div>
                        </div>`;
    
    
            var data_cost=`<div class="row" id="costing_acc${i}" style="margin-bottom:20px;">
                                <input type="hidden" id="hotel_Type_Costing" name="markup_Type_Costing[]" value="hotel_Type_Costing" class="form-control">
                                <input type="text" name="hotel_name_markup[]" hidden>
                                <div class="col-xl-3">
                                </div>
                                <div class="col-xl-9"></div>
                            
                        
                                <div class="col-xl-3">
                                
                                <input type="text" id="hotel_acc_type_${i}" readonly="" name="room_type[]" class="form-control id_cot">
                                    </div>
                                     <div class="col-xl-3">
                                        <div class="input-group">
                                            <input type="text" id="hotel_acc_price_${i}" readonly="" name="without_markup_price[]" class="form-control">
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                  <?php echo $currency; ?>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                     <div class="col-xl-2">
                                             
                                              <select name="markup_type[]" onchange="hotel_markup_type(${i})" id="hotel_markup_types_${i}" class="form-control">
                                                    <option value="">Markup Type</option>
                                                    <option value="%">Percentage</option>
                                                    <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                              </select>
                              
                                    </div>
                                    <div class="col-xl-2">
                                        <input type="hidden" id="" name="" class="form-control">
                                        <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                            <input type="text"  class="form-control" id="hotel_markup_${i}" name="markup[]">
                                            <span class="input-group-btn input-group-append">
                                            <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="hotel_markup_mrk_${i}">%</div></button>
                                            </span>
                                        </div>
                                    </div>
                                <div class="col-xl-2">
                                    <div class="input-group">
                                        <input type="text" id="hotel_markup_total_${i}" name="markup_price[]" class="form-control id_cot">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up">
                                              <?php echo $currency; ?>
                                            </a>
                                        </span>
                                    </div> 
                                </div>
                            </div>`;
          
                    $("#append_accomodation_data_cost").append(data_cost);
                  
                    $("#append_accomodation").append(data);
                    
                    $('#property_city_new'+i+'').on('change',function(){
                        var id = $(this).find('option:selected').attr('attr');
                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                            }
                        });
                        $.ajax({
                            url: '/country_cites_laln/'+id,
                            method: 'post',
                            data: {
                                "_token": "{{ csrf_token() }}",
                                "id": id,
                            },
                            success: function(result){
                                var city_D              = result['city_D'];
                                var lat_city            = city_D['latitude'];
                                var lan_city            = city_D['longitude'];
                                var country_code_city   = city_D['country_code'];
                                $('#lat_city'+i+'').val(lat_city);
                                $('#lan_city'+i+'').val(lan_city);
                                $('#country_code_city'+i+'').val(country_code_city);
                            },
                            error:function(error){
                                console.log(error);
                            }
                        });
                       
                    });
                    
                    $('.acc_qty_class_'+i+'').on('change',function(){
                        
                        var acc_qty_class = $(this).val();
                        // console.log(acc_qty_class);
                        var hotel_type = $('.hotel_type_class_'+i+'').find('option:selected').attr('attr');
                        // console.log(hotel_type);
                        var mult = parseFloat(acc_qty_class) * parseFloat(hotel_type);
                        // console.log(mult);
                        $('.acc_pax_class_'+i+'').val(mult);
                        
                    });
                    
                    var country = $('#property_country').val();
                
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                        }
                    });
                    
                    $.ajax({
                        url: "{{ url('/country_cites1') }}",
                        method: 'post',
                        data: {
                            "_token": "{{ csrf_token() }}",
                            "id": country,
                        },
                        success: function(result){
                            // console.log('cites is call now');
                            // console.log(result);
                            $('.property_city_new'+i+'').html(result);
                        },
                        error:function(error){
                            // console.log(error);
                        }
                    });
                    
                    $('.accomodation_image_edit'+j+'').change(function () {
                        var c = $('#del_counter1').val();
                        if (typeof (FileReader) != "undefined") {
                            var dvPreview = $("#dvPreview");
                            dvPreview.html("");
                            var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
                            $($(this)[0].files).each(function () {
                                var file = $(this);
                                if (regex.test(file[0].name.toLowerCase())) {
                                    var reader = new FileReader();
                                    reader.onload = function (e) {
                                        
                                        var img = $("<img />");
                                        img.attr("style", "height:150px;width:233px;margin-bottom: 10px");
                                        img.attr("src", e.target.result);
                                        img.attr("id", j);
                                        
                                        var img_Name = e.target.result;
                                        
                                        // console.log(img);
                                        // console.log(e);
                                        
                                        var befor_Img = `<div class="col-md-3" id="accImg${c}" style="text-align: center;">
                                                            <input type="text" name="accomodation_image_else${j}[]" class="form-control" value="${img_Name}" readonly hidden>
                                                        </div>`;
                                        
                                        var after_Img = `<button class="btn btn-danger" type="button" onclick="remove_acc_img(${c})" style="margin-bottom: 10px">Delete</button>`;
                                        
                                        dvPreview.append(befor_Img)
                                        
                                        var accImg = $('#accImg'+c+'');
                                        
                                        accImg.append(img);
                                        accImg.append(after_Img);
                                        
                                        // var final_Append = `<div>${img}<br>${after_Img}</div>`;
                                        // accImg.append(final_Append);
                                        
                                        c = parseFloat(c)+1;
                                    }
                                    reader.readAsDataURL(file[0]);
                                } else {
                                    alert(file[0].name + " is not a valid image file.");
                                    dvPreview.html("");
                                    return false;
                                }
                            });
                        } else {
                            alert("This browser does not support HTML5 FileReader.");
                        }
                    });
                    
                    j = parseFloat(j) + 1;
                    
                    $.ajax({    
                        type: "GET",
                        url: "get_other_Hotel_Name",             
                        dataType: "html",                  
                        success: function(data){
                            var data1 = JSON.parse(data);
                            $('.other_Hotel_Name'+i+'').empty();
                            $('.other_Hotel_Type'+i+'').empty();
                            $.each(data1['hotel_Name'], function(key, data2) {
                                // console.log(data2['other_Hotel_Name']);
                                var other_Hotel_Name_Data = `<option attr="${data2.other_Hotel_Name}" value="${data2.other_Hotel_Name}"> ${data2.other_Hotel_Name}</option>`;
                                $('.other_Hotel_Name'+i+'').append(other_Hotel_Name_Data);
                            });
                            $.each(data1['hotel_Type'], function(key, data3) {
                            	var other_Hotel_Name_Type = `<option attr="${data3.id}" value="${data3.other_Hotel_Type}"> ${data3.other_Hotel_Type}</option>`;
                                $('.other_Hotel_Type'+i+'').append(other_Hotel_Name_Type);
                            });
                            
                        }
                    });
                    
                    var places_D1 = new google.maps.places.Autocomplete(
                        document.getElementById('acc_hotel_name_'+i+'')
                    );
                    
                    google.maps.event.addListener(places_D1, "place_changed", function () {
                        var places_D1 = places_D1.getPlace();
                        // console.log(places_D1);
                        var address = places_D1.formatted_address;
                        var latitude = places_D1.geometry.location.lat();
                        var longitude = places_D1.geometry.location.lng();
                        var latlng = new google.maps.LatLng(latitude, longitude);
                        var geocoder = (geocoder = new google.maps.Geocoder());
                        geocoder.geocode({ latLng: latlng }, function (results, status) {
                            if (status == google.maps.GeocoderStatus.OK) {
                                if (results[0]) {
                                    var address = results[0].formatted_address;
                                    var pin = results[0].address_components[
                                        results[0].address_components.length - 1
                                    ].long_name;
                                    var country =  results[0].address_components[
                                        results[0].address_components.length - 2
                                      ].long_name;
                                    var state = results[0].address_components[
                                            results[0].address_components.length - 3
                                        ].long_name;
                                    var city = results[0].address_components[
                                            results[0].address_components.length - 4
                                        ].long_name;
                                    var country_code = results[0].address_components[
                                            results[0].address_components.length - 2
                                        ].short_name;
                                    $('#country').val(country);
                                    $('#lat').val(latitude);
                                    $('#long').val(longitude);
                                    $('#pin').val(pin);
                                    $('#city').val(city);
                                    $('#country_code').val(country_code);
                                }
                            }
                        });
                    });
                    
                $("#select_accomodation").slideToggle();
            
        });
    
        $("#accomodation_edit").on('click',function(){
            
            $("#append_accomodation_data_cost1").empty();
            $("#append_accomodation_data_cost").empty();
            $("#append_accomodation").empty();
            var packages_get_city = $('#packages_get_city').val();
            var decodeURI_city = JSON.parse(packages_get_city);
            var city_slc =$(".city_slc").val();
            var count = city_slc.length;
            var j=0;
            for (let i = 1; i <= count; i++) {
                
                var data = `<div class="mb-2" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;">
                                <h4>
                                    City #${i} (${decodeURI_city[i-1]})
                                    <i class="dripicons-information" style="font-size: 17px;" id="title_Icon_${i}"
                                        data-bs-toggle="tooltip" data-bs-placement="right" title="Fill all the information of City ${decodeURI_city[i-1]}">
                                    </i>
                                </h4> 
                                    <div class="row">
                                        
                                        <input type="hidden" name="hotel_city_name[]" id="hotel_city_name" value="${decodeURI_city[i-1]}"/>
                                    <div class="col-xl-3">
                                        <label for="">Hotel Name</label>
                                        <div class="input-group">
                                            <select type="text" onchange="hotel_fun(${i})" id="acc_hotel_name_${i}" name="acc_hotel_name[]" class="form-control other_Hotel_Name acc_hotel_name_class_${i}">
                                            
                                            </select>
                                            <span title="Add Hotel Name" class="input-group-btn input-group-append">
                                                <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#hotel-name-modal" type="button">+</button>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3"><label for="">Check In</label><input type="date" id="makkah_accomodation_check_in_${i}" name="acc_check_in[]" class="form-control date makkah_accomodation_check_in_class_${i}">
                                    </div><div class="col-xl-3"><label for="">Check Out</label><input type="date" id="makkah_accomodation_check_out_date_${i}"  name="acc_check_out[]" onchange="makkah_accomodation_check_out(${i})"  class="form-control date makkah_accomodation_check_out_date_class_${i}"></div>
                                    <div class="col-xl-3"><label for="">No Of Nights</label><input type="text" id="acomodation_nights_${i}" name="acc_no_of_nightst[]" class="form-control acomodation_nights_class_${i}"></div>
                                    
                                    <div class="col-xl-2"><label for="">Room Type</label>
                                        <div class="input-group">
                                            <select onchange="hotel_type_fun(${i})" name="acc_type[]" id="hotel_type_${i}" class="form-control other_Hotel_Type hotel_type_class_${i}"  data-placeholder="Choose ...">
                                                <option value="">Choose ...</option>
                                                <option attr="4" value="Quad">Quad</option>
                                                <option attr="3" value="Triple">Triple</option>
                                                <option attr="2" value="Double">Double</option>
                                            </select>
                                            <span title="Add Hotel Type" class="input-group-btn input-group-append">
                                                <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#hotel-type-modal" type="button">+</button>
                                            </span>
                                        </div>
                                        
                                        </div>
                                        <div class="col-xl-2"><label for="">Quantity</label><input type="text" id="simpleinput" name="acc_qty[]" class="form-control acc_qty_class_${i}"></div>
                                        
                                        <div class="col-xl-2">
                                        <label for="">Pax</label>
                                        <input type="text" id="simpleinput" name="acc_pax[]" class="form-control acc_pax_class_${i}" readonly>
                                        </div>
                                        <div class="col-xl-3">
                                        <label for="">Price Per Person/Night</label>
                                        <div class="input-group">
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                  <?php echo $currency; ?>
                                                </a>
                                            </span>
                                            <input type="text" id="makkah_acc_price_${i}" onchange="makkah_acc_price_funs(${i})" value="" name="acc_price[]" class="form-control makkah_acc_price_class_${i}">
                                        </div>
                                        
                                        </div>
                    
                                        <div class="col-xl-3"><label for="">Total Amount/Per Person</label>
                                         <div class="input-group">
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                  <?php echo $currency; ?>
                                                </a>
                                            </span>
                                            <input readonly type="text"  id="makkah_acc_total_amount_${i}"  name="acc_total_amount[]" class="form-control makkah_acc_total_amount_class_${i}">
                                        </div>
                                        </div>
                                        
                                        <div id="append_add_accomodation_${i}"></div>
                                        <div class="mt-2"><a href="javascript:;" onclick="add_more_accomodation(${i})"  id="" class="btn btn-info" style="float: right;"> + Add More </a></div>
                                        
                                        
                                          <div class="col-xl-12">
                                             <div class="mb-3">
                                             
                                             
                                             
                                             
                                              <label for="simpleinput" class="form-label">Room Amenities</label>
                                              <textarea name="hotel_whats_included[]" class="form-control" id="" cols="10" rows="0"></textarea>
                                              
                                             </div>
                                          </div>
                                        
                                        <div class="col-xl-12"><label for="">Image</label><input type="file"  id=""  name="accomodation_image${j}[]" class="form-control" multiple></div>
                                        </div></div>`;
          
            
                var data_cost=`<div class="row" id="${i}">
                                    <input type="text" name="hotel_name_markup[]" hidden>
                                    <div class="col-xl-3">
                                        <h4 class="" id="">Accomodation Cost ${decodeURI_city[i-1]}</h4>
                                    </div>
                                    <div class="col-xl-9"></div>
                                    
                                
                                    <div class="col-xl-3">
                                    
                                    <input type="text" id="hotel_acc_type_${i}" readonly="" name="room_type[]" class="form-control id_cot">
                                        </div>
                                         <div class="col-xl-3">
                                            <div class="input-group">
                                                <input type="text" id="hotel_acc_price_${i}" readonly="" name="without_markup_price[]" class="form-control">
                                                <span class="input-group-btn input-group-append">
                                                    <a class="btn btn-primary bootstrap-touchspin-up">
                                                      <?php echo $currency; ?>
                                                    </a>
                                                </span>
                                            </div>
                                    </div>
                                     <div class="col-xl-2">
                                             
                                              <select name="markup_type[]" onchange="hotel_markup_type(${i})" id="hotel_markup_types_${i}" class="form-control">
                                                    <option value="">Markup Type</option>
                                                    <option value="%">Percentage</option>
                                                    <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                              </select>
                              
                                    </div>
                                    <div class="col-xl-2">
                                         
                                     <input type="hidden" id="" name="" class="form-control">
                                     
                                     <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                        <input type="text"  class="form-control" id="hotel_markup_${i}" name="markup[]">
                                        <span class="input-group-btn input-group-append">
                                    <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="hotel_markup_mrk_${i}">%</div></button>
                                    </span>
                                    </div>
                     
                     
                     
                                    </div>
                                    <div class="col-xl-2">
                                        <div class="input-group">
                                            <input type="text" id="hotel_markup_total_${i}" name="markup_price[]" class="form-control id_cot">
                                            <span class="input-group-btn input-group-append">
                                                <a class="btn btn-primary bootstrap-touchspin-up">
                                                  <?php echo $currency; ?>
                                                </a>
                                            </span>
                                        </div> 
                                    </div>
                                </div>`;
          
              
                $("#append_accomodation_data_cost").append(data_cost);
                $("#append_accomodation").append(data);
                $('.acc_qty_class_'+i+'').on('change',function(){
                    
                    var acc_qty_class = $(this).val();
                    // console.log(acc_qty_class);
                    var hotel_type = $('.hotel_type_class_'+i+'').find('option:selected').attr('attr');
                    // console.log(hotel_type);
                    var mult = parseFloat(acc_qty_class) * parseFloat(hotel_type);
                    // console.log(mult);
                    $('.acc_pax_class_'+i+'').val(mult);
                    
                });
                
                j = j + 1;
            }
        
            var select_ct =$(".select_ct").val();
            
            var count_1 = select_ct.length;
            
            for (let i = 1; i <= count_1; i++) {
                // console.log(i);
              var data1 = `<div class="mb-2" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;"><h4>City #${i} </h4><div class="row"><div class="col-xl-3"><label for="">Hotel Name</label><input type="text" id="simpleinput" name="acc_hotel_name[]" class="form-control">
            </div><div class="col-xl-3"><label for="">Check In</label><input type="date" id="simpleinput" name="acc_check_in[]" class="form-control">
            </div><div class="col-xl-3"><label for="">Check Out</label><input type="date" id="simpleinput" name="acc_check_out[]" class="form-control"></div><div class="col-xl-3"><label for="">No Of Nights</label><input type="text" id="nights" name="acc_no_of_nightst[]" class="form-control"></div><div class="col-xl-3"><label for="">Room Type</label>
            <select name="acc_type[]" id="property_city" class="form-control"  data-placeholder="Choose ..."><option value="">Choose ...</option><option value="Quad">Quad</option><option value="Triple">Triple</option><option value="Double">Double</option></select></div>
            <div class="col-xl-3"><label for="">Quantity</label><input type="text" id="simpleinput" name="acc_qty[]" class="form-control"></div>
            <div class="col-xl-3"><label for="">Pax</label><input type="text" id="simpleinput" name="acc_pax[]" class="form-control"></div><div class="col-xl-3"><label for="">Price</label>
            <input type="text" id="simpleinput" name="acc_price[]" class="form-control"></div><div class="col-xl-3"><label for="">Currency</label><select name="acc_currency[]" id="property_city" class="form-control"><option value="">Choose ...</option><option value="SAR">SAR</option><option value="Dollar">Dollar</option><option value="Pound">Pound</option></select></div><div class="col-xl-3"><label for="">Comission</label><input type="text" id="simpleinput" name="acc_commision[]" class="form-control"></div><div class="col-xl-3"><label for="">Sale Price</label><input type="text" id="simpleinput" name="acc_sale_Porice[]" class="form-control"></div><div class="col-xl-3"><label for="">Total Amount</label><input type="text" id="simpleinput" name="acc_total_amount[]" class="form-control"></div>
            <div id="append_add_accomodations_${i}"></div><div class="mt-2"><a href="javascript:;" onclick="add_more_accomodations(${i})"  id="" class="btn btn-info" style="float: right;"> + Add More </a></div></div></div>`;
              $("#append_accomodation").append(data1);   
              
            }
        
            $("#select_accomodation").slideToggle();
        });
    
        $('#save_Accomodation').on('click',function(e){
            e.preventDefault();
            
            var select_ct =$("#property_city").val();
            var count_1 = select_ct.length;
            // console.log(count_1);
            for(i=0; i < count_1; i++){
                var acc_hotel_name = [];
                var id  = $(this).val();
                var hotel_city_name = $("#hotel_city_name").val();
                var acc_hotel_name1 = $('.acc_hotel_name_class_'+i+'').val();
                // console.log(acc_hotel_name1);
                acc_hotel_name.push(acc_hotel_name1);
                // console.log(acc_hotel_name);
                var acc_check_in = $('.makkah_accomodation_check_in_class_'+i+'').val();
                var acc_check_out = $('.makkah_accomodation_check_out_date_class_'+i+'').val();
                var acc_no_of_nights = $('.acomodation_nights_class_'+i+'').val();
                var acc_type = $('.hotel_type_class_'+i+'').val();
                var acc_qty = $('.acc_qty_class_'+i+'').val();
                var acc_pax = $('.acc_pax_class_'+i+'').val();
                var acc_price = $('.makkah_acc_price_class_'+i+'').val();
                var acc_total_amount = $('.makkah_acc_total_amount_class_'+i+'').val();
            }
            
            $.ajax({    
                type: 'POST',
                url: 'save_Accomodation/'+id,
                data:{
                    '_token'                    : '{{ csrf_token() }}',
                    'id'                        : id,
                    'hotel_city_name'           : hotel_city_name,
                    'acc_hotel_name'            : acc_hotel_name,
                    'acc_check_in'              : acc_check_in,
                    'acc_check_out'             : acc_check_out,
                    'acc_no_of_nights'          : acc_no_of_nights,
                    'acc_type'                  : acc_type,
                    'acc_qty'                   : acc_qty,
                    'acc_pax'                   : acc_pax,
                    'acc_price'                 : acc_price,
                    'acc_total_amount'          : acc_total_amount,
                },
                success: function(data){
                    // console.log(data);
                    // alert('Accomodation Details Saved SuccessFUl!');
                }
            });
        });
    
        var img_id=1;
        var img_id2=2;
        $("#more_images").on('click',function(){
            
            var more_img = document.getElementById('more_img');
            var more_images_length = more_img.children.length;
            
            // console.log(more_images_length);
            
            if(more_images_length < 10){
                var images=`<div class="row" id="click_delete_img_${img_id}"><div class="col-xl-12">
                <div class="mb-3">
                    <label for="simpleinput" class="form-label">Multipal Image</label>
                    <div>
            	        <input type="file" id="" name="gallery_images[]" class="form-control gallery_imagesP${img_id2}" onchange="validate1(${img_id2})">
            	        <span class="file_error${img_id2}"></span>
                    </div>
                </div>
                </div><div class="mt-2"><a href="javascript:;" onclick="deleteRowimg(${img_id})" id="${img_id}" class="btn btn-info" style="float: right;"> delete </a></div></div>`;
                $("#more_img").append(images);
                img_id ++;
                img_id2 ++;
            }
              
        });
    
        function remove_hotels(id){
            
            $('#del_hotel'+id+'').remove();
            $('#costing_acc'+id+'').remove();
            
            var city_No1 = $('#city_No').val();
            var city_No = parseFloat(city_No1) - 1;
            $('#city_No').val(city_No);
            
            put_tour_location();
            put_tour_location_else();
            add_numberElse();
        }
        
        function put_tour_location(id){
            
            $('#tour_location_city').removeAttr('value');
            
            var city_No = $('#city_No').val();
            var arr2    = [];
            
            for(var i=1; i<=city_No; i++){
                var property_city_new  = $('#property_city_new'+i+'').val();
                if(property_city_new == null || property_city_new == '' || property_city_new == 0){
                    // console.log('NULL');
                }else{
                    arr2.push(property_city_new);
                }
            }
            var json_data = JSON.stringify(arr2);
            $('#tour_location_city').val(json_data);
            $('#packages_get_city').val(json_data);
            
        }
        
        function put_tour_location_else(id){
            
            $('#tour_location_city1').removeAttr('value');
            
            // var city_No  = $('#city_No').val();
            var city_No1 = $('#city_No1').val();
            var arr2     = [];
            
            for(var i=1; i<=city_No1; i++){
                var property_city_new  = $('#property_city_new'+i+'').val();
                if(property_city_new == null || property_city_new == '' || property_city_new == 0){
                    // console.log('NULL');
                }else{
                    arr2.push(property_city_new);
                }
            }
            var json_data = JSON.stringify(arr2);
            $('#tour_location_city1').val(json_data);
            $('#tour_location_city_else').val(json_data);
            $('#packages_get_city').val(json_data);
            
        }
        
        function deleteRowimg(id){
            $('#click_delete_img_'+id+'').remove();
        }

    </script>
    
    <script>
         
        $('#exchange_rate_child').keyup(function() {
                    var child_visa_price =  $('#child_visa_price').val();
                    var child_transportation_price =  $('#child_transportation_price').val();
                    var exchange_rate_child =  $('#exchange_rate_child').val();
                    var currency_conversion = $("#select_exchange_type").val();
                    
                     
                    if(currency_conversion == 'Divided')
                    {
                       var child_visa_price = parseFloat(child_visa_price) / parseFloat(exchange_rate_child);
                       var child_transportation_price = parseFloat(child_transportation_price) / parseFloat(exchange_rate_child);
                    }
                    else
                    {
                       var child_visa_price = parseFloat(child_visa_price) * parseFloat(exchange_rate_child);
                       var child_transportation_price = parseFloat(child_transportation_price) * parseFloat(exchange_rate_child);
                    }
                    
                    var exchange_rate_child_visa_price = child_visa_price.toFixed(2);
                    var exchange_rate_child_transportation_price = child_transportation_price.toFixed(2);
                    $('#exchange_rate_child_visa_price').val(exchange_rate_child_visa_price);
                    $('#exchange_rate_child_transportation_price').val(exchange_rate_child_transportation_price);
                    
                   
                    $('#child_visa_cost').val(exchange_rate_child_visa_price);
                     $('#child_Transporation_cost').val(exchange_rate_child_transportation_price);
                     
                     
                      var child_flight_price =  $('#child_flight_price').val();
                    child_total_cost_price=parseFloat(exchange_rate_child_visa_price) + parseFloat(exchange_rate_child_transportation_price) + parseFloat(child_flight_price);
                   $('#child_total_cost_price').val(child_total_cost_price);
                   $('#child_total_sale_price').val(child_total_cost_price);
                   
                });
                
        $('#exchange_rate_child_infant').keyup(function() {
                    var child_visa_price_infant =  $('#child_visa_price_infant').val();
                    var child_transportation_price_infant =  $('#child_transportation_price_infant').val();
                    var exchange_rate_child_infant =  $('#exchange_rate_child_infant').val();
                     var infant_flight_cost =  $('#child_flight_price_infant').val();
                    var currency_conversion = $("#select_exchange_type").val();
                    
                     
                    if(currency_conversion == 'Divided')
                    {
                       var child_visa_price_infant = parseFloat(child_visa_price_infant) / parseFloat(exchange_rate_child_infant);
                       var child_transportation_price_infant = parseFloat(child_transportation_price_infant) / parseFloat(exchange_rate_child_infant);
                    }
                    else
                    {
                       var child_visa_price_infant = parseFloat(child_visa_price_infant) * parseFloat(exchange_rate_child_infant);
                       var child_transportation_price_infant = parseFloat(child_transportation_price_infant) * parseFloat(exchange_rate_child_infant);
                    }
                    
                    var exchange_rate_child_visa_price_infant = child_visa_price_infant.toFixed(2);
                    var exchange_rate_child_transportation_price_infant = child_transportation_price_infant.toFixed(2);
                    $('#exchange_rate_child_visa_price_infant').val(exchange_rate_child_visa_price_infant);
                    $('#exchange_rate_child_transportation_price_infant').val(exchange_rate_child_transportation_price_infant);
                    
                   
                   $('#infant_flight_cost').val(infant_flight_cost);
                   $('#infant_visa_cost').val(exchange_rate_child_visa_price_infant);
                     $('#infant_Transporation_cost').val(exchange_rate_child_transportation_price_infant);
                    
                     var child_flight_price_infant =  $('#child_flight_price_infant').val();
                    infant_total_cost_price=parseFloat(exchange_rate_child_visa_price_infant) + parseFloat(exchange_rate_child_transportation_price_infant) + parseFloat(child_flight_price_infant);
                   $('#infant_total_cost_price').val(infant_total_cost_price);
                   $('#infant_total_sale_price').val(infant_total_cost_price);
                   
                });
         
        $('#exchange_rate_transportation_Old').keyup(function() {
                    var transportation_price_per_vehicle =  $('#transportation_price_per_vehicle').val();
                    var transportation_vehicle_total_price =  $('#transportation_vehicle_total_price').val();
                    var transportation_price_per_person =  $('#transportation_price_per_person').val();
                    
                    var exchange_rate_transportation =  $('#exchange_rate_transportation').val();
                    
                    var currency_conversion = $("#select_exchange_type").val();
                    
                     
                    if(currency_conversion == 'Divided')
                    {
                       var exchange_rate_transportation_price_per_vehicle = parseFloat(transportation_price_per_vehicle) / parseFloat(exchange_rate_transportation);
                       var exchange_rate_transportation_vehicle_total_price = parseFloat(transportation_vehicle_total_price) / parseFloat(exchange_rate_transportation);
                       var exchange_rate_transportation_price_per_person = parseFloat(transportation_price_per_person) / parseFloat(exchange_rate_transportation);
                    }
                    else
                    {
                      var exchange_rate_transportation_price_per_vehicle = parseFloat(transportation_price_per_vehicle) * parseFloat(exchange_rate_transportation);
                       var exchange_rate_transportation_vehicle_total_price = parseFloat(transportation_vehicle_total_price) * parseFloat(exchange_rate_transportation);
                       var exchange_rate_transportation_price_per_person = parseFloat(transportation_price_per_person) * parseFloat(exchange_rate_transportation);
                    }
                    
                    var exchange_rate_transportation_price_per_vehicle = exchange_rate_transportation_price_per_vehicle.toFixed(2);
                    var exchange_rate_transportation_vehicle_total_price = exchange_rate_transportation_vehicle_total_price.toFixed(2);
                    var exchange_rate_transportation_price_per_person = exchange_rate_transportation_price_per_person.toFixed(2);
                    $('#exchange_rate_transportation_price_per_vehicle').val(exchange_rate_transportation_price_per_vehicle);
                    $('#exchange_rate_transportation_vehicle_total_price').val(exchange_rate_transportation_vehicle_total_price);
                    $('#exchange_rate_transportation_price_per_person').val(exchange_rate_transportation_price_per_person);
                    
                   
                    
                    $('#transportation_price_per_person_select').val(exchange_rate_transportation_price_per_person);
                 add_numberElse();
calculateGrandWithoutAccomodation();
                   
                });
                
        $('#exchange_rate_visa').keyup(function() {
                    var visa_fee =  $('#visa_fee').val();
                    var exchange_rate_visa =  $('#exchange_rate_visa').val();
                    var currency_conversion = $("#select_exchange_type").val();
                    
                     console.log('visa_fee' + visa_fee);
                      console.log('exchange_rate_visa' + exchange_rate_visa);
                       console.log('currency_conversion' + currency_conversion);
                    if(currency_conversion == 'Divided')
                    {
                       var total_visa = parseFloat(visa_fee) / parseFloat(exchange_rate_visa);
                    }
                    else
                    {
                       var total_visa = parseFloat(visa_fee) * parseFloat(exchange_rate_visa);
                    }
                    
                    var total_visa = total_visa.toFixed(2);
                    $('#exchange_rate_visa_total_amount').val(total_visa);
                    
                   $('#visa_price_select').val(total_visa);
                    
                    add_numberElse();
  calculateGrandWithoutAccomodation();
                   
                });
         
        function makkah_acc_room_price_funs(id){
            // var switch_hotel_name = $('#switch_hotel_name'+id+'').val();
            // if(switch_hotel_name == 1){
            //     var hotel_type_price = $('#hotel_type_'+id+'').val();
            // }else{
            //     var hotel_type_price = $('.hotel_type_select_class_'+id+'').val();
            // }
            
            var hotel_type_price = $('#hotel_type_'+id+'').val();
            var room_price = $('#makkah_acc_room_price_'+id+'').val();
            console.log('room_price' + room_price);
            var acomodation_nights = $('#acomodation_nights_'+id+'').val();
             
             
             if(hotel_type_price == 'Double')
             {
                 hotel_type_price = 2;
             }
             if(hotel_type_price == 'Triple')
             {
                 hotel_type_price = 3;
             }
             if(hotel_type_price == 'Quad')
             {
                 hotel_type_price = 4;
             }
             console.log('hotel_type_price' + hotel_type_price);
             var total=parseFloat(room_price)/parseFloat(hotel_type_price);
           var grand_total=parseFloat(total) * parseFloat(acomodation_nights);
           
          
           
             $('#makkah_acc_price_'+id+'').val(total);
             $('#makkah_acc_total_amount_'+id+'').val(grand_total);
             
             
           
            
            
         }
            
        var double_cost_price = 0;
        var triple_cost_price = 0;
        var quad_cost_price =0;
            
        function exchange_rate_price_funs(id){
             
            
             var makkah_acc_room_price = $('#makkah_acc_room_price_'+id+'').val();
             var makkah_acc_price = $('#makkah_acc_price_'+id+'').val();
             var makkah_acc_total_amount = $('#makkah_acc_total_amount_'+id+'').val();
             var hotel_type_price = $('#hotel_type_'+id+'').val();
             
             var exchange_rate_price_funs = $('#exchange_rate_price_funs_'+id+'').val();
             
             
             var currency_conversion = $("#select_exchange_type").val();
              console.log('currency_conversion' + currency_conversion);
              
              
             if(currency_conversion == 'Divided')
             {
               var price_per_room_exchangeRate=parseFloat(makkah_acc_room_price)/parseFloat(exchange_rate_price_funs);
             var price_per_person_exchangeRate=parseFloat(makkah_acc_price)/parseFloat(exchange_rate_price_funs);
             var price_total_exchangeRate=parseFloat(makkah_acc_total_amount)/parseFloat(exchange_rate_price_funs);  
             }
             else
             {
               var price_per_room_exchangeRate=parseFloat(makkah_acc_room_price) * parseFloat(exchange_rate_price_funs);
             var price_per_person_exchangeRate=parseFloat(makkah_acc_price) * parseFloat(exchange_rate_price_funs);
             var price_total_exchangeRate=parseFloat(makkah_acc_total_amount) * parseFloat(exchange_rate_price_funs);  
             }
             
             
             
             
            var price_per_room_exchangeRate = price_per_room_exchangeRate.toFixed(2);
             var price_per_person_exchangeRate = price_per_person_exchangeRate.toFixed(2);
              var price_total_exchangeRate = price_total_exchangeRate.toFixed(2);
             
             
             $('#price_per_room_exchange_rate_'+id+'').val(price_per_room_exchangeRate);
             $('#price_per_person_exchange_rate_'+id+'').val(price_per_person_exchangeRate);
             $('#price_total_amout_exchange_rate_'+id+'').val(price_total_exchangeRate);
              $('#hotel_acc_price_'+id+'').val(price_total_exchangeRate);
              
              
             
             if(hotel_type_price == 'Double')
             {
                double_cost_price = parseFloat(double_cost_price) + parseFloat(price_total_exchangeRate);
              console.log('double_cost_price' + double_cost_price);
                $('#double_cost_price').val(double_cost_price);
             }
             if(hotel_type_price == 'Triple')
             {
                 triple_cost_price = parseFloat(triple_cost_price) + parseFloat(price_total_exchangeRate);
              console.log('double_cost_price' + triple_cost_price);
              $('#triple_cost_price').val(triple_cost_price);
             }
             if(hotel_type_price == 'Quad')
             {
               quad_cost_price = parseFloat(quad_cost_price) + parseFloat(price_total_exchangeRate);
              console.log('quad_cost_price' + quad_cost_price);
             $('#quad_cost_price').val(quad_cost_price);
             }
             
             
             
                
             
              
             
             
         }
         
        function more_makkah_acc_room_price_funs(id,cityId){  
             var room_price = $('#more_makkah_acc_room_price_funs_'+id+'').val();
            
             var hotel_type_price = $('#more_hotel_type_'+id+'').val();
           
             var acomodation_nights = $('#acomodation_nights_'+cityId+'').val();
             
             
             console.log('acomodation_nights' + acomodation_nights);
            
             if(hotel_type_price == 'Double')
             {
                 hotel_type_price = 2;
             }
             if(hotel_type_price == 'Triple')
             {
                 hotel_type_price = 3;
             }
             if(hotel_type_price == 'Quad')
             {
                 hotel_type_price = 4;
             }
            
             var total=parseFloat(room_price)/parseFloat(hotel_type_price);
           var grand_total=parseFloat(total) * parseFloat(acomodation_nights);
           
           total=total.toFixed(2);
           grand_total=grand_total.toFixed(2);
             $('#more_acc_price_get_'+id+'').val(total);
             $('#more_acc_total_amount_'+id+'').val(grand_total);
              
            
            
         }
            
        var double_cost_price   = 0;
        var triple_cost_price   = 0;
        var quad_cost_price     = 0;
        
        function more_exchange_rate_price_funs(id){
             var makkah_acc_room_price = $('#more_makkah_acc_room_price_funs_'+id+'').val();
             var makkah_acc_price = $('#more_acc_price_get_'+id+'').val();
             var makkah_acc_total_amount = $('#more_acc_total_amount_'+id+'').val();
              var hotel_type_price = $('#more_hotel_type_'+id+'').val();
               console.log('more_hotel_type_price' + hotel_type_price);
             var exchange_rate_price_funs = $('#more_exchange_rate_price_funs_'+id+'').val();
             
             
             var currency_conversion = $("#select_exchange_type").val();
            //   console.log('makkah_acc_room_price' + makkah_acc_room_price);
            //   console.log('makkah_acc_price' + makkah_acc_price);
            //   console.log('makkah_acc_total_amount' + makkah_acc_total_amount);
            //   console.log('exchange_rate_price_funs' + exchange_rate_price_funs);
            //   console.log('currency_conversion' + currency_conversion);
              
              
             if(currency_conversion == 'Divided')
             {
               var price_per_room_exchangeRate=parseFloat(makkah_acc_room_price)/parseFloat(exchange_rate_price_funs);
             var price_per_person_exchangeRate=parseFloat(makkah_acc_price)/parseFloat(exchange_rate_price_funs);
             var price_total_exchangeRate=parseFloat(makkah_acc_total_amount)/parseFloat(exchange_rate_price_funs);  
             }
             else
             {
               var price_per_room_exchangeRate=parseFloat(makkah_acc_room_price) * parseFloat(exchange_rate_price_funs);
             var price_per_person_exchangeRate=parseFloat(makkah_acc_price) * parseFloat(exchange_rate_price_funs);
             var price_total_exchangeRate=parseFloat(makkah_acc_total_amount) * parseFloat(exchange_rate_price_funs);  
             }
             
             
             
             
            var price_per_room_exchangeRate = price_per_room_exchangeRate.toFixed(2);
             var price_per_person_exchangeRate = price_per_person_exchangeRate.toFixed(2);
              var price_total_exchangeRate = price_total_exchangeRate.toFixed(2);
             
             
             $('#more_price_per_room_exchange_rate_'+id+'').val(price_per_room_exchangeRate);
             $('#more_price_per_person_exchange_rate_'+id+'').val(price_per_person_exchangeRate);
             $('#more_price_total_amout_exchange_rate_'+id+'').val(price_total_exchangeRate);
             //$('#more_acc_total_amount_'+id+'').val(price_total_exchangeRate);
             $('#more_hotel_acc_price_'+id+'').val(price_total_exchangeRate);
             
             
              
             
             if(hotel_type_price == 'Double')
             {
                double_cost_price = parseFloat(double_cost_price) + parseFloat(price_total_exchangeRate);
              console.log('double_cost_price' + double_cost_price);
                $('#double_cost_price').val(double_cost_price);
             }
             if(hotel_type_price == 'Triple')
             {
                 triple_cost_price = parseFloat(triple_cost_price) + parseFloat(price_total_exchangeRate);
              console.log('triple_cost_price' + triple_cost_price);
              $('#triple_cost_price').val(triple_cost_price);
             }
             if(hotel_type_price == 'Quad')
             {
               quad_cost_price = parseFloat(quad_cost_price) + parseFloat(price_total_exchangeRate);
              console.log('more_quad_cost_price' + quad_cost_price);
             $('#quad_cost_price').val(quad_cost_price);
             }
             
              
             
         }
         
        function hotel_fun(id){
            var acc_hotel_name = $('#acc_hotel_name_'+id+'').val();
            $('#hotel_name_acc_'+id+'').val(acc_hotel_name);
            $('#hotel_name_markup'+id+'').val(acc_hotel_name);
            
            var property_city_newN  = $('#property_city_new'+id+'').find('option:selected').attr('value');
            var start_dateN         = $('#makkah_accomodation_check_in_'+id+'').val();
            var enddateN            = $('#makkah_accomodation_check_out_date_'+id+'').val();
            var acomodation_nightsN = $("#acomodation_nights_"+id+'').val();
            var acc_qty_classN      = $(".acc_qty_class_"+id+'').val();
            var switch_hotel_name   = $('#switch_hotel_name'+id+'').val();
            if(switch_hotel_name == 1){
                var acc_hotel_nameN     = $('#acc_hotel_name_'+id+'').val();
            }else{
                var acc_hotel_nameN     = $('.get_room_types_'+id+'').val();
            }
            var html_data = `Accomodation Cost ${property_city_newN} <a class="btn">(Hotel Name : <b style="color: #cdc0c0;">${acc_hotel_nameN}</b>) (Quantity : <b style="color: #cdc0c0;">${acc_qty_classN}</b>) (Check in : <b style="color: #cdc0c0;">${start_dateN}</b>) (Check Out : <b style="color: #cdc0c0;">${enddateN}</b>) (Nights : <b style="color: #cdc0c0;">${acomodation_nightsN}</b>)</a>`;
            $('#acc_cost_html_'+id+'').html(html_data);
        }
     
        function hotel_type_fun(id){
            var hotel_type = $('#hotel_type_'+id+'').val();
            $('#hotel_acc_type_'+id+'').val(hotel_type);
        }
      
        function hotel_markup_type(id){
            var ids     = $('#hotel_markup_types_'+id+'').val();
            var prices  = $('#hotel_acc_price_'+id+'').val();
            add_numberElse();
            if(ids == '%')
            {
                $('#hotel_markup_mrk_'+id+'').text(ids);
                $('#hotel_markup_'+id+'').keyup(function() {
                    var markup_val =  $('#hotel_markup_'+id+'').val();
                    var total1 = (prices * markup_val/100) + parseFloat(prices);
                    var total = total1.toFixed(2);
                    $('#hotel_markup_total_'+id+'').val(total);
                    $('#hotel_invoice_markup_'+id+'').val(total);
                    add_numberElse_1();
                });
            }
            else
            {
                $('#hotel_markup_mrk_'+id+'').text(ids);
                $('#hotel_markup_'+id+'').keyup(function() {
                    var markup_val =  $('#hotel_markup_'+id+'').val();
                    var total1 = parseFloat(prices) + parseFloat(markup_val);
                    var total = total1.toFixed(2);
                    $('#hotel_markup_total_'+id+'').val(total);
                    $('#hotel_invoice_markup_'+id+'').val(total);
                    add_numberElse_1();
                });
            }
        }
     
    </script>

    @yield('slug')

    <script>
    
        function set_exchange_rate_funs(id){
            var makkah_acc_total_amount =$("#makkah_acc_total_amount_"+id+'').val();
            var set_exchange_rate =$("#set_exchange_rate_"+id+'').val();
            console.log("makkah_acc_total_amount " + makkah_acc_total_amount);
            console.log("set_exchange_rate " + set_exchange_rate);
            var total_exchange_price = parseFloat(makkah_acc_total_amount) * parseFloat(set_exchange_rate);
            $("#set_exchange_rate_price_"+id+'').val(total_exchange_price);
        }
        
        function makkah_acc_price_funs(id){
            var makkah_acc_price = $('#makkah_acc_price_'+id+'').val();
            var nights = $("#acomodation_nights_"+id+'').val();
            var total1 = parseFloat(nights) * parseFloat(makkah_acc_price);
            var total  = total1.toFixed(2);
            $("#makkah_acc_total_amount_"+id+'').val(total);
            var pr =$("#makkah_acc_total_amount_"+id+'').val();
            $('#hotel_acc_price_'+id+'').val(pr);
            add_numberElse();
        }
 
        function makkah_accomodation_check_out(id){
            var start_date = $('#makkah_accomodation_check_in_'+id+'').val();
            var enddate = $('#makkah_accomodation_check_out_date_'+id+'').val();
            const date1 = new Date(start_date);
            const date2 = new Date(enddate);
            const diffTime = Math.abs(date2 - date1);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
            var diff=(diffDays);
            $("#acomodation_nights_"+id+'').val(diff);
        }

    </script>

    <script>
        var divId = 1;
        var ids = [];
        //  var temp = 1;
        function add_more_accomodation(id){
            
          
            var acc_nights_key = $('#acc_nights_key_'+id+'').val();
            // var packages_get_city = $('#property_city_new'+id+'').find('option:selected').attr('attr');
            // console.log(packages_get_city);
            // var packages_get_city = $('#packages_get_city').val();
            // var decodeURI_city = JSON.parse(packages_get_city);
            // ids.push(divId);
            
            var decodeURI_city = $('#property_city_new'+id+'').val();
        
            var data1 = `<div id="click_delete_${divId}" class="mb-2 mt-3" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;">
                            <input readonly type="hidden" id="acc_nights1_${divId}" value="${acc_nights_key}" class="form-control">
                        
                            <input type='hidden' name="more_hotel_city[]" value="${decodeURI_city}" id="more_hotel_city${divId}"/>
                            <div class="row" style="padding:20px;"><div class="col-xl-3"><label for="">Room Type</label>
                                <div class="input-group">
                                            <select onchange="more_hotel_type_fun(${divId})" name="more_acc_type[]" id="more_hotel_type_${divId}" class="form-control other_Hotel_Type more_hotel_type_class_${divId}"  data-placeholder="Choose ...">
                                                <option value="">Choose...</option>
                                                <option attr="4" value="Quad">Quad</option>
                                                <option attr="3" value="Triple">Triple</option>
                                                <option attr="2" value="Double">Double</option>
                                            </select>
                                            <span title="Add Hotel Type" class="input-group-btn input-group-append">
                                                <button class="btn btn-primary bootstrap-touchspin-up" data-bs-toggle="modal" data-bs-target="#hotel-type-modal" type="button">+</button>
                                            </span>
                                        </div>
                                
                            </div>
                            <div class="col-xl-3"><label for="">Quantity</label><input onchange="more_acc_qty_class(${divId})" type="text" id="simpleinput" name="more_acc_qty[]" class="form-control more_acc_qty_class_${divId}"></div>
                            <div class="col-xl-3"><label for="">Pax</label><input type="text" id="simpleinput" name="more_acc_pax[]" class="form-control more_acc_pax_class_${divId}" readonly></div>
                            
                            <div class="col-xl-3">
                                <label for="">Meal Type</label>
                                <select name="more_hotel_meal_type[]" id="hotel_meal_type_${divId}" class="form-control"  data-placeholder="Choose ...">
                                    <option value="">Choose ...</option>
                                    <option value="Room only">Room only</option>
                                    <option value="Breakfast">Breakfast</option>
                                    <option value="Lunch">Lunch</option>
                                    <option value="Dinner">Dinner</option>
                                </select>
                            </div>
                            
                            <h4 class="mt-4">Purchase Price1</h4>
                            
                             <div class="col-xl-4">
                            <label for="">Price Per Room/Night</label>
                             <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                              
                                            </a>
                                        </span>
                                <input type="text" onchange="more_makkah_acc_room_price_funs(${divId},${id})" id="more_makkah_acc_room_price_funs_${divId}" name="more_price_per_room_purchase[]" class="form-control">
                            </div>
                        
                            </div>
                            
                            <div class="col-xl-4">
                            <label for="">Price Per Person/Night5</label>
                             <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                              
                                            </a>
                                        </span>
                                <input type="text" onchange="more_acc_price(${divId})" id="more_acc_price_get_${divId}" name="more_acc_price_purchase[]" class="form-control">
                            </div>
                        
                            </div>
                            <div class="col-xl-4">
                            <label for="">Total Amount/Per Person</label>
                             <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                               
                                            </a>
                                        </span>
                                <input readonly type="text" id="more_acc_total_amount_${divId}" name="more_acc_total_amount_purchase[]" class="form-control"></div>
                            </div>
                            
                            
                            <div class="col-xl-6">
                            <label for="">Exchange Rate</label>
                             <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up currency_value1">
                                               
                                            </a>
                                        </span>
                                <input type="text" id="more_exchange_rate_price_funs_${divId}" onchange="more_exchange_rate_price_funs(${divId})" name="more_exchange_rate_price[]" class="form-control"></div>
                            </div>
                            <div class="col-xl-6">
                            </div>
                            
                            
                            <h4 class="mt-4">Sale Price</h4>
                            
                             <div class="col-xl-4">
                            <label for="">Price Per Room/Night</label>
                             <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                              
                                            </a>
                                        </span>
                                <input type="text" id="more_price_per_room_exchange_rate_${divId}" name="more_price_per_room_sale[]" class="form-control">
                            </div>
                        
                            </div>
                            
                            <div class="col-xl-4">
                            <label for="">Price Per Person/Night5</label>
                             <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                              
                                            </a>
                                        </span>
                                <input type="text"  id="more_price_per_person_exchange_rate_${divId}" name="more_acc_price[]" class="form-control">
                            </div>
                        
                            </div>
                            <div class="col-xl-4">
                            <label for="">Total Amount/Per Person</label>
                             <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                              
                                            </a>
                                        </span>
                                <input readonly type="text" id="more_price_total_amout_exchange_rate_${divId}" name="more_acc_total_amount[]" class="form-control"></div>
                            </div>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            <div class="mt-2">
                            <a href="javascript:;"  onclick="deleteRowacc(${divId})"  id="${divId}" class="btn btn-info" style="float: right;">Delete </a></div></div></div>`;
        
        
        var data_cost=`<div style="padding-bottom: 5px;" class="row click_delete_${divId}" id="click_delete_${divId}">
                            <div class="col-xl-3">
                                <input type="text" name="more_hotel_name_markup[]" hidden id="more_hotel_name_markup${divId}">
                                <h4 class="" id="">More Accomodation Cost ${decodeURI_city}</h4>
                            </div>
                            <div class="col-xl-9"></div>
                            
                            <div class="col-xl-3">
                                
                                <input type="hidden" id="more_hotel_Type_Costing" name="more_markup_Type_Costing[]" value="more_hotel_Type_Costing" class="form-control">
                                
                                <input type="text" id="more_hotel_acc_type_${divId}" readonly="" name="more_room_type[]" class="form-control">
                            </div>
                             <div class="col-xl-3">
                                <div class="input-group">
                                    <input type="text" id="more_hotel_acc_price_${divId}" readonly="" name="more_without_markup_price[]" class="form-control">
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                          
                                        </a>
                                    </span>
                                    
                                </div>
                            </div>
                             <div class="col-xl-2">
                                     
                                      <select name="more_markup_type[]" onchange="more_hotel_markup_type_acc(${divId})" id="more_hotel_markup_types_${divId}" class="form-control">
                                          <option value="">Markup Type</option>
                                          <option value="%">Percentage</option>
                                          <option value="<?php echo $currency; ?>">Fixed Amount</option>
                                      </select>
                      
                            </div>
                            <div class="col-xl-2">
                                     
                                <input type="hidden" id="" name="" class="form-control">
                                <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                    <input type="text"  class="form-control" id="more_hotel_markup_${divId}" name="more_markup[]">
                                    <span class="input-group-btn input-group-append">
                                <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="more_hotel_markup_mrk_${divId}">%</div></button>
                                </span>
                            </div>
                        
                            </div>
                            <div class="col-xl-2">
                                <div class="input-group">
                                    <input type="text" id="more_hotel_markup_total_${divId}" name="more_markup_price[]" value="" class="form-control">
                                    <span class="input-group-btn input-group-append">
                                        <a class="btn btn-primary bootstrap-touchspin-up currency_value_exchange_1">
                                          
                                        </a>
                                    </span>
                                </div>
                            </div>
                            </div>`;
        
        $("#append_accomodation_data_cost1").append(data_cost);
        $("#append_add_accomodation_"+id+'').append(data1);
        
        var more_hotel_city = $('#more_hotel_city'+divId+'').val()
        $('#more_hotel_name_markup'+divId+'').val(more_hotel_city);
        
        divId=divId + 1;
        
  console.log(ids);
        
        // temp=temp + 1;
        
        
        var value_c = $("#currency_conversion").val();
        
                // var v = ( this.code );
                 //alert(code);
         
const usingSplit = value_c.split(' ');
var value_1 = usingSplit['0'];
var value_2 = usingSplit['3'];

console.log(value_1);
console.log(value_2);
              
exchange_currency_funs(value_1,value_2);

        }
    </script>

    <script>
        var divId1       = 0;
        var newdivId     = $("#newdivId").val();
        
        function add_more_accomodation_edit(id){
            console.log('More accomodations is call now'+id);
            var acc_nights_key = $('#acc_nights_key_'+id+'').val();
            // console.log(acc_nights_key);
            var divId = parseFloat(newdivId) + divId1;
            
            // divId = divId;
            // console.log('divId : '+divId);
            
            var city_Name = $('#property_city_new'+id+'').val();
            
            var data1 = `<div id="click_delete_${divId}" class="mb-2 mt-3" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;">
                            
                            <input readonly type="hidden" id="acc_nights1_${divId}" value="${acc_nights_key}" class="form-control">
                            
                            <input type='hidden' name="more_hotel_city[]" value="${city_Name}" id="more_hotel_city${divId}"/>
                            <div class="row">
                                <div class="col-xl-4">
                                    <label for="">Room Type</label>
                                    <select onchange="more_hotel_type_fun(${divId})" name="more_acc_type[]" id="more_hotel_type_${divId}" class="form-control other_Hotel_Type more_hotel_type_class_${divId}"  data-placeholder="Choose ...">
                                        <option value="">Choose...</option>
                                        <option attr="4" value="Quad">Quad</option>
                                        <option attr="3" value="Triple">Triple</option>
                                        <option attr="2" value="Double">Double</option>
                                    </select>
                                </div>
                                <div class="col-xl-4">
                                    <label for="">Quantity</label>
                                    <input onchange="more_acc_qty_class(${divId})" type="text" id="simpleinput" name="more_acc_qty[]" class="form-control more_acc_qty_class_${divId}">
                                </div>
                                <div class="col-xl-4">
                                    <label for="">Pax</label>
                                    <input type="text" id="simpleinput" name="more_acc_pax[]" class="form-control more_acc_pax_class_${divId}" readonly>
                                </div>
                                
                                <div class="col-xl-3">
                                    <label for="">Meal Type</label>
                                    <select name="more_hotel_meal_type[]" id="hotel_meal_type_${divId}" class="form-control"  data-placeholder="Choose ...">
                                        <option value="">Choose ...</option>
                                        <option value="Room only">Room only</option>
                                        <option value="Breakfast">Breakfast</option>
                                        <option value="Lunch">Lunch</option>
                                        <option value="Dinner">Dinner</option>
                                    </select>
                                </div>
                                
                                <div class="col-xl-4">
                                    <label for="">Price Per Person/Night</label>
                                    <div class="input-group">
                                        <input type="text" onchange="more_acc_price(${divId})" id="more_acc_price_get_${divId}" name="more_acc_price[]" class="form-control">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up">
                                               <?php echo $currency; ?>
                                            </a>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-xl-4">
                                    <label for="">Total Amount/Per Person</label>
                                    <div class="input-group">
                                        <input readonly type="text" id="more_acc_total_amount_${divId}" name="more_acc_total_amount[]" class="form-control">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up">
                                               <?php echo $currency; ?>
                                            </a>
                                        </span>
                                    </div>
                                </div>
                                <div class="mt-2">
                                    <a href="javascript:;"  onclick="deleteRowacc(${divId})"  id="${divId}" class="btn btn-info" style="float: right;">Delete </a>
                                </div>
                            </div>
                        </div>`;
        
        
            var data_cost=`<div style="padding-bottom: 5px;" class="row click_delete_${divId}" id="click_delete1_${divId}">
                            <input type="text" name="more_hotel_name_markup[]" hidden id="more_hotel_name_markup${divId}">
                            <input type="hidden" id="more_hotel_Type_Costing" name="more_markup_Type_Costing[]" value="more_hotel_Type_Costing" class="form-control">
                            <div class="col-xl-3">
                                <h4 class="" id="">More Accomodation Cost ${city_Name}</h4>
                            </div>
                            <div class="col-xl-9"></div>
                            
                            <div class="col-xl-3">
                                    
                                <input type="text" id="more_hotel_acc_type_${divId}" readonly="" name="more_room_type[]" class="form-control">
                            </div>
                             <div class="col-xl-3">
                                <input type="text" id="more_hotel_acc_price_${divId}" readonly="" name="more_without_markup_price[]" class="form-control">
                            </div>
                             <div class="col-xl-2">
                                     
                                      <select name="more_markup_type[]" onchange="more_hotel_markup_type_acc(${divId})" id="more_hotel_markup_types_${divId}" class="form-control">
                                          <option value="">Markup Type</option>
                                          <option value="%">Percentage</option>
                                      </select>
                      
                            </div>
                            <div class="col-xl-2">
                                <input type="hidden" id="" name="" class="form-control">
                            <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                                <input type="text"  class="form-control" id="more_hotel_markup_${divId}" name="markup[]">
                                <span class="input-group-btn input-group-append">
                                    <button class="btn btn-primary bootstrap-touchspin-up" type="button"><div id="more_hotel_markup_mrk_${divId}">%</div></button>
                                </span>
                            </div>
                            </div>
                        <div class="col-xl-2">
                            <input type="text" id="more_hotel_markup_total_${divId}" name="more_markup_price[]" value="" class="form-control">
                        </div>
                        </div>`;
        
            $("#append_accomodation_data_cost1").append(data_cost);
            $("#append_add_accomodation_"+id+'').append(data1);
            
            var more_hotel_city = $('#more_hotel_city'+divId+'').val()
            $('#more_hotel_name_markup'+divId+'').val(more_hotel_city);
            
            divId1 = divId1 + 1;
            
        }
    </script>

    <script>
     
        function more_hotel_fun(id){
            var acc_hotel_name = $('#more_acc_hotel_name_'+id+'').val();
            $('#more_hotel_name_acc_'+id+'').val(acc_hotel_name);
            $('#more_hotel_name_markup'+id+'').val(acc_hotel_name);
            
            var start_dateN         = $('#more_makkah_accomodation_check_in_'+id+'').val();
            var enddateN            = $('#more_makkah_accomodation_check_out_date_'+id+'').val();
            var acomodation_nightsN = $("#more_acomodation_nights_"+id+'').val();
            var acc_qty_classN      = $(".more_acc_qty_class_"+id+'').val();
            var switch_hotel_name   = $('#more_switch_hotel_name'+id+'').val();
            if(switch_hotel_name == 1){
                var acc_hotel_nameN     = $('#more_acc_hotel_name_'+id+'').val();
            }else{
                var acc_hotel_nameN     = $('.more_get_room_types_'+id+'').val();
            }
            var html_data = `(Hotel Name : <b style="color: #cdc0c0;">${acc_hotel_nameN}</b>) (Quantity : <b style="color: #cdc0c0;">${acc_qty_classN}</b>) (Check in : <b style="color: #cdc0c0;">${start_dateN}</b>) (Check Out : <b style="color: #cdc0c0;">${enddateN}</b>) (Nights : <b style="color: #cdc0c0;">${acomodation_nightsN}</b>)`;
            $('#more_acc_cost_html_'+id+'').html(html_data);
        }
 
        function more_hotel_type_fun(id){
            var hotel_type = $('#more_hotel_type_'+id+'').val();
            $('#more_hotel_acc_type_'+id+'').val(hotel_type);
        }
  
        function more_acc_qty_class(id){
            var more_acc_qty_class = $('.more_acc_qty_class_'+id+'').val();
            var more_hotel_type = $('.more_hotel_type_class_'+id+'').find('option:selected').attr('attr');
            var more_mult = parseFloat(more_acc_qty_class) * parseFloat(more_hotel_type);
            $('.more_acc_pax_class_'+id+'').val(more_mult);
        }
    
        function acc_qty_class_update(id){
            var acc_qty_class =$('.acc_qty_class_'+id+'').val();
            var hotel_type = $('.hotel_type_class_'+id+'').find('option:selected').attr('attr');
            var mult = parseFloat(acc_qty_class) * parseFloat(hotel_type);
            $('.acc_pax_class_'+id+'').val(mult);
        }
  
        function more_hotel_markup_type_acc(id){   
            var ids = $('#more_hotel_markup_types_'+id+'').val();
            var prices = $('#more_hotel_acc_price_'+id+'').val();
            add_numberElse();
            if(ids == '%')
            {
                $('#more_hotel_markup_mrk_'+id+'').text(ids);
                $('#more_hotel_markup_'+id+'').keyup(function() {
                    var markup_val =  $('#more_hotel_markup_'+id+'').val();
                    var total1 = (prices * markup_val/100) + parseFloat(prices);
                    var total = total1.toFixed(2);
                    $('#more_hotel_markup_total_'+id+'').val(total);
                    $('#more_hotel_invoice_markup_'+id+'').val(total);
                    add_numberElse_1();
                });
            }
            else
            {
                $('#more_hotel_markup_mrk_'+id+'').text(ids);
                $('#more_hotel_markup_'+id+'').keyup(function() {
                    var markup_val =  $('#more_hotel_markup_'+id+'').val();
                    var total1 = parseFloat(prices) + parseFloat(markup_val);
                    var total = total1.toFixed(2);
                    $('#more_hotel_markup_total_'+id+'').val(total);
                    $('#more_hotel_invoice_markup_'+id+'').val(total);
                    add_numberElse_1();
                });
            }
        }
    </script>

    <script>

        function grandTotalCalc(){
            var grandTotal = 0;
            for(var i =0; i<ids.length; i++){
                $("#more_acc_total_amount_"+id+'').val(total);
                var id = ids[i];
                var total = $("#more_acc_total_amount_"+id+'').val();
                grandTotal = +grandTotal + +total;
                $("#more_hotel_acc_price_"+id+'').val(total);
            }
        }

        function more_acc_price(id){
            var acc_nights = $('#acc_nights1_'+id+'').val();
            var more_acc_price = $('#more_acc_price_get_'+id+'').val();
            var nights = $('#acomodation_nights_'+acc_nights+'').val();
            var total1 = parseFloat(nights) * parseFloat(more_acc_price);
            var total = total1.toFixed(2);
            $("#more_acc_total_amount_"+id+'').val(total);
            var pr =$("#more_acc_total_amount_"+id+'').val();
            $('#more_hotel_acc_price_'+id+'').val(pr);
            grandTotalCalc();
            add_numberElse();
        }
    
    </script>

    <script>
        function deleteRowacc(id){
            $('#click_delete_'+id+'').remove();
            $('.click_delete_'+id+'').remove();
            var indexNo = ids.indexOf(id);
            ids.splice(indexNo,1);
            grandTotalCalc();
            add_numberElse();
        }
    </script>

    <script>
        var divId = 1;
        function add_more_accomodations(divId){
           var data1 = `<div id="click_delete_${divId}" class="mb-2 mt-3" style="border:1px solid #ced4da;padding: 20px 20px 20px 20px;"><div class="row"><div class="col-xl-2"><label for="">Room Type</label>
                        <select name="acc_type[]" id="property_city" class="form-control"  data-placeholder="Choose ..."><option value="">Choose ...</option><option value="Quad">Quad</option><option value="Triple">Triple</option><option value="Double">Double</option></select></div>
                        <div class="col-xl-2"><label for="">Quantity</label><input type="text" id="simpleinput" name="acc_qty[]" class="form-control"></div>
                        <div class="col-xl-2"><label for="">Pax</label><input type="text" id="simpleinput" name="acc_pax[]" class="form-control"></div><div class="col-xl-2"><label for="">Price</label>
                        <input type="text" onclick="deleteRowacc(${divId})" id="simpleinput" name="acc_price[]" class="form-control"></div><div class="col-xl-2"><label for="">Currency</label><select name="acc_currency[]" id="property_city" class="form-control"><option value="">Choose ...</option><option value="SAR">SAR</option><option value="Dollar">Dollar</option><option value="Pound">Pound</option></select></div><div class="col-xl-2"><label for="">Total Amount</label><input type="text" id="simpleinput" name="acc_total_amount[]" class="form-control"></div>
                        <div class="mt-2"><a href="javascript:;"  onclick="deleteRowaccs(${divId})"  id="${divId}" class="btn btn-info" style="float: right;">Delete </a></div></div></div>`;
            $("#append_add_accomodations_"+divId+'').append(data1);
            divId++;
        }
    </script>

    <script>
        function deleteRowaccs(id){
            $('#click_delete_'+id+'').remove();
        }
    </script>

    <script>
        var divId = 1
        var ids=[];
        $("#more_flights_inc").click(function(){
            ids.push(divId);
            var data = `<div class="row" id="click_delete_${divId}">
                            <div class="col-xl-3">
                                <label for="">Departure</label>
                                <input type="date" id="simpleinput" name="more_flights_departure[]" class="form-control">
                            </div>
                            <div class="col-xl-3">
                                <label for="">Arrival</label>
                                <input type="date" id="simpleinput" name="more_flights_arrival[]" class="form-control">
                            </div><div class="col-xl-3"><label for="">AirLine</label><input type="text" id="simpleinput" name="more_flights_airline[]" class="form-control"></div><div class="col-xl-3"><label for="">Price Per Person</label><input type="text" id="more_flights_per_person_price_${divId}" onclick="more_flights(${divId})" name="more_flights_per_person_price" class="form-control"></div><div class="mt-2"><a href="javascript:;" onclick="deleteMoreFlights(${divId})"  id="${divId}" class="btn btn-info" style="float: right;"> Delete </a></div></div>`;
            $("#append_flights").append(data);
            divId++;
        });
    </script>

    <script>
        function grandTotalCalc_flights(){
            var grandTotal_f = 0;
            for(var i =0; i<ids.length; i++){
                 var id = ids[i];
                var total = $("#more_flights_per_person_price_"+id+'').val();
                grandTotal_f = +grandTotal_f + +total;
            }
        }
    
        function more_flights(id){
            $('#more_flights_per_person_price_'+id+'').keyup(function() {
                var more_acc_price = this.value;
                grandTotalCalc_flights();
            });
        }
    </script>

    <script>
        function deleteMoreFlights(id){
            $('#click_delete_'+id+'').remove();
            var indexNo = ids.indexOf(id);
            ids.splice(indexNo,1);
            grandTotalCalc_flights();
        }
    </script>

    <script>
        var divId = 1
        $("#more_transportation").click(function(){
            var data = `<div class="row" id="click_delete_${divId}">
                           <div class="col-xl-4">
                            <label for="">Pick-up Location</label>
                            <input type="text" id="more_transportation_pick_up_location_${divId}" name="more_transportation_pick_up_location[]" class="form-control">
                            </div>
                             <div class="col-xl-4">
                            <label for="">Drop-off Location</label>
                            <input type="text" id="more_transportation_drop_off_location_${divId}" name="more_transportation_drop_off_location[]" class="form-control">
                            </div>
                            <div class="col-xl-4">
                            <label for="">Pick-up Date</label>
                            <input type="date" id="simpleinput" name="more_transportation_pick_up_date[]" class="form-control">
                            </div>
                            <div class="mt-2">
                        <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRowTrans(${divId})"  id="${divId}">Delete</button>
                        </div>
                        </div>`;
            $("#append_transportation").append(data);
        
            var places_MT = new google.maps.places.Autocomplete(
                document.getElementById('more_transportation_pick_up_location_'+divId+'')
            );
                    
            var places1_MT = new google.maps.places.Autocomplete(
                document.getElementById('more_transportation_drop_off_location_'+divId+'')
            );
                    
            google.maps.event.addListener(places_MT, "place_changed", function () {
                var places_D1 = places_MT.getPlace();
                // console.log(places_D1);
                var address = places_D1.formatted_address;
                var latitude = places_D1.geometry.location.lat();
                var longitude = places_D1.geometry.location.lng();
                var latlng = new google.maps.LatLng(latitude, longitude);
                var geocoder = (geocoder = new google.maps.Geocoder());
                geocoder.geocode({ latLng: latlng }, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        if (results[0]) {
                            var address = results[0].formatted_address;
                            var pin = results[0].address_components[
                                results[0].address_components.length - 1
                            ].long_name;
                            var country =  results[0].address_components[
                                results[0].address_components.length - 2
                              ].long_name;
                            var state = results[0].address_components[
                                    results[0].address_components.length - 3
                                ].long_name;
                            var city = results[0].address_components[
                                    results[0].address_components.length - 4
                                ].long_name;
                            var country_code = results[0].address_components[
                                    results[0].address_components.length - 2
                                ].short_name;
                            $('#country').val(country);
                            $('#lat').val(latitude);
                            $('#long').val(longitude);
                            $('#pin').val(pin);
                            $('#city').val(city);
                            $('#country_code').val(country_code);
                        }
                    }
                });
            });
            
            google.maps.event.addListener(places1_MT, "place_changed", function () {
                var places1_D1 = places1_MT.getPlace();
                // console.log(places1_D1);
                var address = places1_D1.formatted_address;
                var latitude = places1_D1.geometry.location.lat();
                var longitude = places1_D1.geometry.location.lng();
                var latlng = new google.maps.LatLng(latitude, longitude);
                var geocoder = (geocoder = new google.maps.Geocoder());
                geocoder.geocode({ latLng: latlng }, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        if (results[0]) {
                            var address = results[0].formatted_address;
                            var pin =
                            results[0].address_components[
                        results[0].address_components.length - 1
                      ].long_name;
                            var country =
                              results[0].address_components[
                                results[0].address_components.length - 2
                              ].long_name;
                            var state =
                              results[0].address_components[
                                results[0].address_components.length - 3
                              ].long_name;
                            var city =
                              results[0].address_components[
                                results[0].address_components.length - 4
                              ].long_name;
                            var country_code =
                              results[0].address_components[
                                results[0].address_components.length - 2
                              ].short_name;
                            $('#country').val(country);
                            $('#lat').val(latitude);
                            $('#long').val(longitude);
                            $('#pin').val(pin);
                            $('#city').val(city);
                            $('#country_code').val(country_code);
                        }
                    }
                });
            });  
        
            divId++;
        });
    </script>

    <script>
    
        function grandTotalCalc_transport(){
            var grandTotal_f = 0;
            for(var i =0; i<ids.length; i++){
                var id = ids[i];
                var total = $("#more_flights_per_person_price_"+id+'').val();
                grandTotal_f = +grandTotal_f + +total;
            }
        }

        function more_flights(id){
            $('#more_flights_per_person_price_'+id+'').keyup(function() {
                var more_acc_price = this.value;
                grandTotalCalc_flights();
            });
        }
        
    </script>

    <script>
        function deleteRowTrans(id){
            $('#click_delete_'+id+'').remove();
        }
    </script>

    <script>
        var divId = 1
        $("#click_more_Itinerary").click(function(){
            var data = `<div class="row" style="border: 2px solid #eef2f7;padding: 10px 10px 10px 10px;" id="click_delete_${divId}">
                            <div class="col-xl-6">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Title</label>
                                        <input type="text" id="simpleinput" name="more_Itinerary_title[]" class="form-control">
                                    </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Short Description</label>
                                    <input type="text" id="simpleinput" name="more_Itinerary_city[]" class="form-control">
                                </div>
                            </div>
                            <div class="col-xl-12">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Content</label>
                                    <textarea name="more_Itinerary_content[]" class="form-control" id="" cols="10" rows="10"></textarea>
                                </div>
                            </div>
                            <div class="col-xl-12">
                                <!--<div class="mb-3">
                                    <label for="simpleinput" class="form-label">image</label>
                                    <input type="file" id="simpleinput" name="more_Itinerary_image[]" class="form-control">
                                </div>!-->
                                <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRow(${divId})"  id="${divId}">Delete</button>
                            </div>
                        </div>`
                        ;
            $("#append_data").append(data);
            divId++;
        });
    </script>

    <script>
        var divId = 2;
        $("#click_Itinerary_edit").click(function(){
                var data = `<div class="row" style="border: 2px solid #eef2f7;padding: 10px 10px 10px 10px;" id="click_delete_${divId}">
                                <div class="col-xl-6">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label">Title</label>
                                            <input type="text" id="simpleinput" name="more_Itinerary_title[]" class="form-control">
                                        </div>
                                </div>
                                <div class="col-xl-6">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Short Description</label>
                                        <input type="text" id="simpleinput" name="more_Itinerary_city[]" class="form-control">
                                    </div>
                                </div>
                                <div class="col-xl-12">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Content</label>
                                        <textarea name="more_Itinerary_content[]" class="form-control" id="" cols="10" rows="10"></textarea>
                                    </div>
                                </div>
                                <div class="col-xl-12">
                                    <!--<div class="mb-3">
                                        <label for="simpleinput" class="form-label">image</label>
                                        <input type="file" id="simpleinput" name="more_Itinerary_image[]" class="form-control">
                                    </div>!-->
                                    <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRow(${divId})"  id="${divId}">Delete</button>
                                </div>
                            </div>`
                            ;
            $("#Itinerary_select_if").append(data);
            divId++;
        });
    </script>

    <script>
        var divId = 0;
        $("#click_more_Itinerary_edit").click(function(){
            var click_more_Itinerary_ID = $("#click_more_Itinerary_ID").val();
            divId = parseFloat(divId) + parseFloat(click_more_Itinerary_ID);
                var data = `<div class="row" style="border: 2px solid #eef2f7;padding: 10px 10px 10px 10px;" id="click_delete_${divId}">
                                <div class="col-xl-6">
                                        <div class="mb-3">
                                            <label for="simpleinput" class="form-label">Title</label>
                                            <input type="text" id="simpleinput" name="more_Itinerary_title[]" class="form-control">
                                        </div>
                                </div>
                                <div class="col-xl-6">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Short Description</label>
                                        <input type="text" id="simpleinput" name="more_Itinerary_city[]" class="form-control">
                                    </div>
                                </div>
                                <div class="col-xl-12">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Content</label>
                                        <textarea name="more_Itinerary_content[]" class="form-control" id="" cols="10" rows="10"></textarea>
                                    </div>
                                </div>
                                <div class="col-xl-12">
                                    <!--<div class="mb-3">
                                        <label for="simpleinput" class="form-label">image</label>
                                        <input type="file" id="simpleinput" name="more_Itinerary_image[]" class="form-control">
                                    </div>!-->
                                    <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRow(${divId})"  id="${divId}">Delete</button>
                                </div>
                            </div>`
                            ;
            $("#append_data").append(data);
            divId++;
        });
    </script>
    
    <script>
        function deleteRow(id){
            $('#click_delete_'+id+'').remove();
        }
    </script>

    <script>
        var divId = 0;
        $("#click_more_extra_price").click(function(){
            var click_more_extra_price_ID = $("#click_more_extra_price_ID").val();
            divId = parseFloat(divId) + parseFloat(click_more_extra_price_ID);
            var data = `<div class="row" style="border: 2px solid #eef2f7;padding: 10px 10px 10px 10px;" id="click_delete_${divId}">
                            <div class="col-xl-6">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Name</label>
                                        <input type="text" id="simpleinput" name="more_extra_price_title[]" class="form-control">
                                    </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Price</label>
                                    <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up">
                                               <?php echo $currency; ?>
                                            </a>
                                        </span>
                                        <input type="text" id="simpleinput" name="more_extra_price_price[]" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Type</label>
                                    <select name="more_extra_price_type[]" id="" class="form-control">
                                    <option value="">Select Type</option>
                                        <option value="0">One-Time</option>
                                        <option value="1">Per-Hour</option>
                                        <option value="2">Per-Day</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="mb-3 mt-4">
                                    <div class="form-check form-check-inline">
                                        <input type="checkbox" class="form-check-input" id="Price_per_person" name="more_extra_price_person[]">
                                        <label class="form-check-label" for="Price_per_person">Price per person</label>
                                    </div>
                                </div>
                                <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRow_extra(${divId})"  id="${divId}">Delete</button>
                            </div>
                        </div>`
                        ;
            $("#append_data_extra_price").append(data);
            divId++;
        });
    </script>

    <script>
        var divId = 1;
        $("#click_more_extra_price_if").click(function(){
            var data = `<div class="row" style="border: 2px solid #eef2f7;padding: 10px 10px 10px 10px;" id="click_delete_${divId}">
                            <div class="col-xl-6">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Name</label>
                                        <input type="text" id="simpleinput" name="more_extra_price_title[]" class="form-control">
                                    </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Price</label>
                                    <div class="input-group">
                                        <span class="input-group-btn input-group-append">
                                            <a class="btn btn-primary bootstrap-touchspin-up">
                                               <?php echo $currency; ?>
                                            </a>
                                        </span>
                                        <input type="text" id="simpleinput" name="more_extra_price_price[]" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Type</label>
                                    <select name="more_extra_price_type[]" id="" class="form-control">
                                    <option value="">Select Type</option>
                                        <option value="0">One-Time</option>
                                        <option value="1">Per-Hour</option>
                                        <option value="2">Per-Day</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="mb-3 mt-4">
                                    <div class="form-check form-check-inline">
                                        <input type="checkbox" class="form-check-input" id="Price_per_person" name="more_extra_price_person[]">
                                        <label class="form-check-label" for="Price_per_person">Price per person</label>
                                    </div>
                                </div>
                                <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRow_extra(${divId})"  id="${divId}">Delete</button>
                            </div>
                        </div>`
                        ;
            $("#extraprice_select").append(data);
            divId++;
        });
    </script>

    <script>
        function deleteRow_extra(id){
            $('#click_delete_'+id+'').remove();
        }
    </script>

    <script>
        var divId = 1
        $("#click_more_faq").click(function(){
            var click_more_faq_ID = $("#click_more_faq_ID").val();
            divId = parseFloat(divId) + parseFloat(click_more_faq_ID);
            // console.log('click_more_faq_ID '+click_more_faq_ID);
            // console.log('divId '+divId);
            var data = `<div class="row" style="border: 2px solid #eef2f7;padding: 10px 10px 10px 10px;" id="click_delete_${divId}">
                            <div class="col-xl-6">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Title</label>
                                        <input type="text" id="simpleinput" name="more_faq_title[]" class="form-control">
                                    </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Content</label>
                                    <textarea name="more_faq_content[]" class="form-control" id="" cols="10" rows="10"></textarea>
                                </div>
                            </div>
                 
                            <div class="col-xl-12">
                            
                                <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRow_faq(${divId})"  id="${divId}">Delete</button>
                            </div>
                        </div>`
                        ;
            $("#append_data_faq").append(data);
            divId++;
        });
    </script>

    <script>
        var divId = 1
        $("#click_more_faq_if").click(function(){
            var data = `<div class="row" style="border: 2px solid #eef2f7;padding: 10px 10px 10px 10px;" id="click_delete_${divId}">
                            <div class="col-xl-6">
                                    <div class="mb-3">
                                        <label for="simpleinput" class="form-label">Title</label>
                                        <input type="text" id="simpleinput" name="more_faq_title[]" class="form-control">
                                    </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="mb-3">
                                    <label for="simpleinput" class="form-label">Content</label>
                                    <textarea name="more_faq_content[]" class="form-control" id="" cols="10" rows="10"></textarea>
                                </div>
                            </div>
                 
                            <div class="col-xl-12">
                            
                                <button style="float: right;" type="button" class="btn btn-info deletButton" onclick="deleteRow_faq(${divId})"  id="${divId}">Delete</button>
                            </div>
                        </div>`
                        ;
            $("#faq_select").append(data);
            divId++;
        });
    </script>

    <script>
        function deleteRow_faq(id){
            $('#click_delete_'+id+'').remove();
        }
    </script>

    <script>
        $(document).ready(function () {
            $("#enddate").on('change',function(){
                var start_date = $('#start_date').val();
                var enddate = $('#enddate').val();
                const date1 = new Date(start_date);
                const date2 = new Date(enddate);
                const diffTime = Math.abs(date2 - date1);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                var diff=(diffDays);
                $("#duration").val(diff);
            });
        });
    </script>

    <script>

        $(document).ready(function () {
        
                selectCities();
                
                $("#end_date").on('change',function(){
                    
                    var countryID   = $('#property_country').val();
                    var cityID      = $('#property_city').val();
                    
                    var start_date  = $('#start_date').val();
                    var end_date    = $('#end_date').val();
                    const date1     = new Date(start_date);
                    const date2     = new Date(end_date);
                    const diffTime  = Math.abs(date2 - date1);
                    const diffDays  = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                    var diff        = (diffDays);
                    $("#duration").val(diff);
                    
                    var next_dateF   = date1.setTime(date1.getTime() + (1000*60*60*24));
                    var next_dateF1  = new Date(next_dateF);
                    console.log('next_dateF1 :'+next_dateF1);
                    
                    var prev_dateF   = date1.setTime(date1.getTime() - (1000*60*60*24));
                    var prev_dateF1  = new Date(prev_dateF);
                    console.log('prev_dateF1 :'+prev_dateF1);
                    
                    var next_dateL   = date2.setTime(date1.getTime() + (1000*60*60*24));
                    var next_dateL1  = new Date(next_dateL);
                    console.log('next_dateL1 :'+next_dateL1);
                    
                    var prev_dateL   = date2.setTime(date2.getTime() - (1000*60*60*24));
                    var prev_dateL1  = new Date(prev_dateL);
                    console.log('prev_dateL1 :'+prev_dateL1);
        
                    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                    $.ajax({
                        url: '{{URL::to('hotel_Room')}}',
                        type: 'POST',
                        data: {
                          _token: CSRF_TOKEN,
                          "start_date": start_date,
                          "end_date": end_date,
                          "cityID" : cityID,
                        },
                        success:function(data) {
                            var a = JSON.parse(data);
                            $("#hotel_name").empty();
                            var result = [];
                            $("#hotel_name").append('<option>select</option>');
                            $.each(a, function (i, e) {
                                var matchingItems = $.grep(result, function (item) {
                                    return item.property_name === e.property_name && item.id === e.id;
                                });
                                if (matchingItems.length === 0){
                                    result.push(e);
                                    $("#hotel_name").append('<option value=' +e.hotel_id+ '>' +e.property_name+'</option>');
                                }
                            });
                            var ass = JSON.stringify(result)            
                        },
                    });
                });
        
                $('#hotel_name').on('change',function(){
                 $('.mkah').css('display','');
                 var id = $(this).val();
                 $.ajax({
                    url: 'roomID/'+id,
                    type: 'GET',
                    data: {
                      "id": id
                    },
                    success:function(data) {
                       var a = JSON.parse(data);
                       $("#hotel_rooms_type").empty();
        
                       jQuery.each(a, function(index, value){
                          var quantity = value.quantity;
                          var weekdays_price = value.weekdays_price;
                          var weekends_price = value.weekends_price;
                          var sum = parseFloat(weekdays_price) + parseFloat(weekends_price);
                          // console.log(sum);
                          // 
                          $("#hotel_rooms_type").append('<option value=' + sum+ '>' + value.room_type+ "(" +quantity+ ")" + '</option>');
                       });
                    },
                  });
              });
        
                $('#hotel_rooms_type').on('change',function(){
                 
                 $('.PPNmakkah').css('display','');
                 $(".MakkahTPNights").css('display','');
        
                 var duration = $('#duration').val();
                //  console.log(duration);
                 var hotel_rooms_type  = $(this).val();
                //  console.log(hotel_rooms_type);
        
                 price_per_night = 0;
        
                 jQuery.each(hotel_rooms_type,function(index,value){
                    price_per_night = parseFloat(price_per_night) + parseFloat(value);
                 });
                 $("#price_per_night").val(price_per_night);
                 var total_price_per_night = parseFloat(duration) * parseFloat(price_per_night);
                //  console.log(total_price_per_night);
                 $("#total_price_per_night").val(total_price_per_night);
              });
        
            });
    
        function selectCities(){
                var country = $('#property_country').val();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "{{ url('/country_cites1') }}",
                    method: 'post',
                    data: {
                        "_token": "{{ csrf_token() }}",
                        "id": country,
                    },
                    success: function(result){
                        $('#property_city').html(result);
                        $('.property_city_new').html(result);
                        
                        var tour_location_city      = $('#tour_location_city').val();
                        var tour_location_city_arr  = JSON.parse(tour_location_city);
                        var tour_location_city_L    = tour_location_city_arr.length;
                        if(tour_location_city_L > 0){
                            for(var i=1; i<=tour_location_city_L; i++){
                                $('#property_city_new'+i+'').removeAttr('value');
                                $('#tour_location_city').removeAttr('value');
                                $('#packages_get_city').removeAttr('value');
                            }
                        }
                    },
                    error:function(error){
                        //  console.log(error);
                    }
                });
            }
          
        function selectCities1(){
                var country = $('#property_country').val();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "{{ url('/country_cites1') }}",
                    method: 'post',
                    data: {
                        "_token": "{{ csrf_token() }}",
                        "id": country,
                    },
                    success: function(result){
                        $('#property_city').html(result);
                        $('.property_city_new').html(result);
                        var tour_location_city = $('#tour_location_city').val();
                        var tour_location_city_arr  = JSON.parse(tour_location_city);
                        var tour_location_city_L    = tour_location_city_arr.length;
                        if(tour_location_city_L > 0){
                            for(var i=1; i<=tour_location_city_L; i++){
                                $('#property_city_new'+i+'').removeAttr('value');
                                $('#tour_location_city').removeAttr('value');
                                $('#packages_get_city').removeAttr('value');
                            }
                        }
                    },
                    error:function(error){
                    }
                });
            }
       
    </script>
    
    <script>
        var today = new Date();
        $('.date').datepicker({
            format      : 'yyyy-mm-dd',
            "autoApply" : true,
            "startDate" : today,
            "minDate"   : today,
        });
    
        $('.date').on('apply.daterangepicker', function(ev, picker) {
            ev.stopPropagation();
            console.log("OKKK");
        });
    </script>
    
    <script src="https://code.iconify.design/2/2.2.1/iconify.min.js"></script>

    @yield('edit_tour_scripts')

</body>

</html>