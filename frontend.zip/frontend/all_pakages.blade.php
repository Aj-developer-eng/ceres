
@extends('template/frontend/includes/master')

@section('page_title')<?php if(isset($metaInfo) && $metaInfo != ''){echo $metaInfo->pageTitle;}?>@endsection


@section('keywords')
    <meta name="keywords" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->focus_keyword;
        }
    ?>"/>
@endsection
@section('page_meta_desc')
    <meta name="description" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->meta_description;
        }
    ?>"/>
@endsection
@section('page_meta_title')
    <meta name="title" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->metaTitle;
        }
    ?>"/>
@endsection
<?php
$dep_of_tour = Session::get('dep_city_for_tour');
// dd($dep_of_tour['lng']);
?>
@section('content')
<!-- ================================
    START HERO-WRAPPER AREA
================================= -->

<style>
    .tour-img{
        width:100%;
        height:145px;
    }
    .departure-date{
            font-size: 16px;
            color: #477fe7;
    }
    
    .tour-description{
        
    }
    .price-div{
        display:flex;
    }
    .tour_length{
        font-size:16px;
        font-weight:bold;
    }
    .time_length{
        width:100%;
        font-size: 13px;
        text-align: center;
    }
    
    .price{
        text-align:center;
    }
    
    .parent_row{
            box-shadow: 9px 12px 15px -4px #808080bd;
    padding: .5rem 0px;
    border: 1px solid #80808038;
    border-radius: 7px;
    }
    
    .noUi-base, .noUi-connects {
    width: 97%;
    height: 100%;
    position: relative;
    z-index: 1;
    }
.f-13{
    font-size: 13px;
}
.category-heading-content .find form {
    margin-top: 38px;
    padding: 30px 40px;
    background-color: rgba(0, 0, 0, 0.8);
}

</style>

<link href="https://api.mapbox.com/mapbox-gl-js/v2.10.0/mapbox-gl.css" rel="stylesheet">
<script src="https://api.mapbox.com/mapbox-gl-js/v2.10.0/mapbox-gl.js"></script>

<script>
    mapboxgl.accessToken = 'pk.eyJ1IjoiYXdhYWIiLCJhIjoiY2w3cTI0azIyMDE5aDNucGw2OTl2dTV2MyJ9.JjhRRvHq8JtA0xDZWxjKgQ';
    
    function CreateMapBox(id,obj){
// console.log(obj);
        var coordinates = JSON.parse(obj);
     var location = coordinates['city_data']
     console.log(location);
        const detail = [[<?php echo($dep_of_tour['lng']) ?>, <?php echo($dep_of_tour['lat']) ?>]];
        
        
 for(var i=0; i<location.length; i++){
    //  console.log('The i is '+i)
     for(var j=0; j<location[i].length; j++){
        //  console.log('The j is '+j);
        
         detail.push([location[i][j]['longitude'], location[i][j]['latitude']]);    
           
        // console.log(location[j]);
        //   detail.push();  
     }
 }
      
        
        const map = new mapboxgl.Map({
        attributionControl: false,
        container: 'map'+id,
        // Choose from Mapbox's core styles, or make your own style with Mapbox Studio
        style: 'mapbox://styles/mapbox/streets-v11',
        center: [<?php echo($dep_of_tour['lng']) ?>, <?php echo($dep_of_tour['lat']) ?>],
        zoom: 2
         });
         map.addControl(new mapboxgl.FullscreenControl());
         
           show_line(detail);


        function show_line(detail){
map.on('load', () => {
map.addSource('route', {
'type': 'geojson',
'data': {
'type': 'Feature',
'properties': {},
'geometry': {
'type': 'LineString',
'coordinates': detail
}
}
});
map.addLayer({
'id': 'route',
'type': 'line',
'source': 'route',
'layout': {
'line-join': 'round',
'line-cap': 'round'
},
'paint': {
'line-color': '#e90606',
'line-width': 4
}
});
});
}
// line end
    }
    
   
    
</script>

<section class="awe-parallax category-heading-section-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class="category-heading-content category-heading-content__2 text-uppercase">
                    <!-- BREADCRUMB -->
                    <div class="breadcrumb">
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><span>Trips</span></li>
                        </ul>
                    </div>
                    <!-- BREADCRUMB -->
                    <div class="find">
                        <h2 class="text-center">Find Your Trip</h2>
                       <form action="{{ URL::to('search_pakages') }}" method="post">
                             @csrf
                            <div class="form-group">
                                 <div class="form-elements">
                                     <label>Select Category</label>
                                    <div class="form-item">
                                        <div class="awe-select-wrapper">
                                            <select class="awe-select" name="category" >
                                             @if(isset($all_categories))
                                           @foreach($all_categories as $cat_res)
                                                <option value="{{ $cat_res->id }}">{{ $cat_res->title }}</option>
                                            @endforeach
                                        @endif
                                        </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-elements">
                                    <label>Departure From</label>
                                    <div class="form-item">
                                        <i class="awe-icon awe-icon-marker-1"></i>
                                        <input type="text" name="city" id="departure_city" value="Country, city, airport...">
                                            @php 
                                            if(isset($request_data['booking_person'])){
                                            @endphp
                                            <input type="text" name="booking_person" readonly value="admin">
                                            
                                            @php
                                            }
                                            @endphp
                                    </div>
                                </div>
                                <div class="form-elements">
                                   <label>Departure Date</label>
                                    <div class="form-item">
                                        <i class="awe-icon awe-icon-calendar"></i>
                                        <input type="text" name="start" class="awe-calendar" value="Check In">
                                    </div>
                                </div>
                               
                               

                                <div class="form-actions">
                                    <input type="submit" value="Find My Trip">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- END / HEADING PAGE -->

        
        <section class="filter-page">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-top">
                            <select class="awe-select">
                                <option>Best Match</option>
                                <option>Best Rate</option>
                            </select>
                        </div>
                    </div>
                      <div class="col-md-3 col-md-pull-9">
                        <div class="page-sidebar">
                            
                            <!-- END / WIDGET -->

                            <!-- WIDGET -->
                            <div class="widget widget_price_filter">
                             
                                
                                <div class="mb-0">
                                    <label class="form-label">Price Level</label>
                                    <div id="kt_slider_basic"></div>
                                
                                    <div class="pt-5">
                                        <div class="fw-bold mb-2">Min: <span id="kt_slider_basic_min"></span></div>
                                        <div class="fw-bold mb-2">Max: <span id="kt_slider_basic_max"></span></div>
                                    </div>
                                </div>
                                
                                
                                <input type="text" id="category" hidden value="{{ $cat_id }}">
                                <input type="text" id="city" hidden value="{{ $request_data['city'] ?? '' }}">
                                <input type="text" id="start" hidden value="{{ $request_data['start'] ?? '' }}">
                            </div>
                            <!-- END / WIDGET -->

                            <!-- WIDGET -->
                            <div class="widget widget_has_radio_checkbox">
                                <h3>Star Rating</h3>
                                <ul>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="5">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="4">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="3">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="2">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="1">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                   
                                </ul>
                            </div>
                            <!-- END / WIDGET -->

                            <!-- WIDGET -->
              
                            <!-- END / WIDGET -->

                            <!-- WIDGET -->
                            <div class="widget widget_has_radio_checkbox">
                                <h3>Included services</h3>
                                <ul>
                                    @if(isset($all_attributes))
                                      @foreach($all_attributes as $att_res)
                                    <li>
                                        <label>
                                            <input type="checkbox" name="attributes" value="{{ $att_res->id }}">
                                            <i class="awe-icon awe-icon-check"></i>
                                            {{ $att_res->title }}
                                        </label>
                                    </li>
                                      @endforeach
                                     @endif
                                   
                                </ul>
                            </div>
                            
                            <button class="btn" style="background-color:#d2b254; color:white;" onclick="getFilterResult()">Filter</button>
                            <!-- END / WIDGET -->

                            <!-- WIDGET -->
                            <div class="widget widget_product_tag_cloud">
                                <h3>Tags</h3>
                                <div class="tagcloud">
                                    <a href="#">Hotel</a>
                                    <a href="#">Motel</a>
                                    <a href="#">Hostel</a>
                                    <a href="#">Homestay</a>
                                </div>
                            </div>
                            <!-- END / WIDGET -->

                        </div>
                    </div>
                    <div class="col-md-9 col-md-push-3">
                        <div class="filter-page__content">
                            <div class="filter-item-wrapper" id="tours_filter">
                                
                             <div class="row">
                                <!-- ITEM -->
                                 <?php
                                $hotel_coordinates = [];
                                ?>
                                @foreach($tours->data as $toure_res)
                                 <?php 
                                    // dd($toure_res->destination_details);
                                    // dd($toure_res);
                                    $locations_array = [];
                                   $destination_details = json_decode($toure_res->destination_details);
                                   $destination_details_more = json_decode($toure_res->destination_details_more);
                        //   dd($destination_details->destination_city);
                        
                                   $tour_location_json = json_decode($toure_res->tour_location);
                                   $decoded_tour_location = $tour_location_json[0];
                                   array_push($locations_array,$decoded_tour_location);
                                   
                                   
                                   
                                //   dd($accomodation_details_more);
                                  
                                   
                                   if($destination_details->destination_city!="" && $destination_details->destination_city!=null){
                                    foreach($destination_details->destination_city as $accomodation_detailz){
                                    //   dd($accomodation_detailz);
                                           array_push($locations_array,$accomodation_detailz);
                                   } 
                                   }
                                   
                                   if($destination_details_more->more_destination_city!="" && $destination_details_more->more_destination_city!=null){
                                    foreach($destination_details_more->more_destination_city as $destination_details_morez){
                                    //   dd($accomodation_detailz);
                                           array_push($locations_array,$destination_details_morez);
                                   } 
                                   }
                                   
                                   
                        $loc_city_list = json_encode($locations_array);
                                   
                                    $data = array('request_cites'=>$loc_city_list);
                                   
                                    $curl = curl_init();
     curl_setopt_array($curl, array(
     CURLOPT_URL => 'https://admin.synchronousdigital.com/api/map_data',
     CURLOPT_RETURNTRANSFER => true,
     CURLOPT_ENCODING => '',
     CURLOPT_MAXREDIRS => 10,
     CURLOPT_TIMEOUT => 0,
     CURLOPT_FOLLOWLOCATION => true,
     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
     CURLOPT_CUSTOMREQUEST => 'POST',
     CURLOPT_POSTFIELDS =>  $data,
     CURLOPT_HTTPHEADER => array(
        'Cookie: laravel_session=gnq21xtzzbBtgOgSa0iVWPIX9vSDzHcKrUozAnSL'
     ),
     ));
  
     $response = curl_exec($curl);
    //  echo $response;die;
     curl_close($curl);
      $loc_data = json_decode($response);
      ?>
                                    <?php 
                                        if(isset($toure_res->flights_details)){
                                            $flight_Detail = json_decode($toure_res->flights_details);
                                        }
                                        
                                        if(isset($toure_res->flights_details_more)){
                                             $flights_details_more = json_decode($toure_res->flights_details_more);
                                        }
                                        
                                       
                                        if(isset($toure_res->flights_details) OR isset($toure_res->flights_details_more)){
                                            if($flight_Detail->flight_type !== 'Indirect'){
                                                $departure_form = $flight_Detail->departure_airport_code;
                                            }else{
                                                if(isset($flights_details_more)){
                                                    $departure_form = $flights_details_more[0]->more_departure_airport_code;
                                                }else{
                                                    $departure_form = '';
                                                }
                                                
                                            }
                                        }else{
                                            $departure_form = '';
                                        }
                                        // print_r($flight_Detail);
                                        // echo "<pre>";
                                        // print_r($flights_details_more);
                                        // echo "</pre>";
                                    ?>
                                
                                    <div class="col-md-12 mb-4">
                                        <div class="row parent_row">
                                            <div class="col-md-3">
                                                <div class="">
                                                    <img class="tour-img" src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $toure_res->tour_banner_image }}" alt="">
                                                    <div id="map<?php echo $toure_res->id ?>" style="height: 150px;">
                                                       
                                                    </div>
                                                </div>
                                            </div>
                                             <script>
                                                     CreateMapBox(<?php echo $toure_res->id ?>,'<?php echo json_encode($loc_data) ?>');
                                                </script>
                                            <div class="col-md-6">
                                                <h5 class="card-title">
                                                    <a href="{{ URL::to('view_detail/'.$toure_res->id.'') }}" style="text-decoration:none;">{{ $toure_res->title }}</a>
                                                </h5>
                                                <h6 class="departure-date"><i class="fa-solid fa-plane-departure"></i>   
                                                <?php
                                                                 
                                                              $dateValue = strtotime(date("d-m-Y", strtotime($toure_res->start_date ?? '' )));
                                                     
                                                                $year = date('Y',$dateValue);
                                                                $monthName = date('F',$dateValue);
                                                                $monthNo = date('d',$dateValue);
                                                                $day = date('l', $dateValue);
                                                                echo ' '.$monthNo . ',' . $monthName . ',' . $year;
                                                                // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                                                              ?>
                                                </h6>
                                                <p>{{ $toure_res->starts_rating }}.0 
                                                
                                                <?php
                                                      if($toure_res->starts_rating == 1){
                                                               echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                       }
                                                        if($toure_res->starts_rating == 2){
                                                               echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                               echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                         }
                                            
                                              
                                                        if($toure_res->starts_rating == 3){
                                                                echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                          }
                                            
                                              
                                                       if($toure_res->starts_rating == 4){
                                                         echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                           
                                                       }
                                            
                                              
                                                         if($toure_res->starts_rating == 5){
                                                                 echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                          }
                                  ?>
                                                     
                                                <p>
                                                <p class="tour-description">{!! Str::limit($toure_res->content, 175, ' ...') !!}</p>
                                                <hr>
                                                <div class="row f-13">
                                                     <div class="col-md-5">
                                                         @if(isset($departure_form))
                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="fa-solid fa-plane-departure"></i> Departure From  </p>
                                                        @endif
                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="fa-solid fa-plane-arrival"></i> Return Date </p>
                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="fa-solid fa-check"></i> Available Spaces  </p>
                                                     </div>
                                                     <div class="col-md-7">
                                                          @if(isset($departure_form))
                                                            <p style="margin-bottom: 0;"> {{ Str::limit($departure_form, 30, ' ...') }} &nbsp</p>
                                                        @endif
                                                        
                                                        <p style="margin-bottom: 0;"> <?php
                                                                 
                                                              $dateValue = strtotime(date("d-m-Y", strtotime($toure_res->end_date ?? '' )));
                                                     
                                                                $year = date('Y',$dateValue);
                                                                $monthName = date('F',$dateValue);
                                                                $monthNo = date('d',$dateValue);
                                                                $day = date('l', $dateValue);
                                                                echo ' '.$monthNo . ',' . $monthName . ',' . $year;
                                                                // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                                                              ?>
                                                              &nbsp
                                                        </p>
                                                         <p style="margin-bottom: 0;"> {{ $toure_res->no_of_pax_days }} </p>
                                                     </div>
                                                    
                                                </div>
                                              
                                            </div>
                                            <div class="col-md-3 pt-2">
                                                    <div class="price">
                                                        <h6 style="font-size:25px; color:#d2b254;">
                                                                {{ $toure_res->currency_symbol }}
                                                                <super>
                                                                 @if($toure_res->quad_grand_total_amount != 0 AND $toure_res->quad_grand_total_amount != null)
                                                                {{ $toure_res->quad_grand_total_amount }}
                                                                
                                                                @elseif($toure_res->triple_grand_total_amount != 0 AND $toure_res->triple_grand_total_amount != null) 
                                                                {{ $toure_res->triple_grand_total_amount }}
                                                                
                                                                @elseif($toure_res->double_grand_total_amount != 0 AND $toure_res->double_grand_total_amount != null) 
                                                                {{ $toure_res->double_grand_total_amount }}
                                                                @endif
                                                                </super>
                                                                 <sub>PP</sub>
                                                                
                                                              
                                                        </h6>
                                                        
                                                </div>
                                                <div class="time_length"><i class="fa fa-moon-o" aria-hidden="true"></i>Tour Length <span class="tour_length">{{ $toure_res->time_duration }} Night</span></div>
                                                <h6 style="text-align:center;color:#477fe7;"><a href="{{ URL::to('view_detail/'.$toure_res->id.'') }}" style="text-decoration:none; font-size:15px;">View Details</a></h6>
                                                 <a href="{{ URL::to('view_detail/'.$toure_res->id.'') }}" style="text-decoration:none;" class="btn btn-primary form-control">Book Now</a>
                                            </div>
                                        </div>
                                    </div>
                               
                                @endforeach 
                                </div>
                                <!-- END / ITEM -->
                            </div>


                            <!-- PAGINATION -->
                            <!-- <div class="page__pagination">
                                <span class="pagination-prev"><i class="fa fa-caret-left"></i></span>
                                <span class="current">1</span>
                                <a href="#">2</a>
                                <a href="#">3</a>
                                <a href="#">4</a>
                                <a href="#" class="pagination-next"><i class="fa fa-caret-right"></i></a>
                            </div> -->
                            <!-- END / PAGINATION -->
                        </div>
                    </div>
                   
                </div>
            </div>
        </section>

<!-- start back-to-top -->
@endsection



@section('scripts')
<script>
    function getFilterResult(){
        console.log('Button is Click now');
        var values = slider.noUiSlider.get();
        var category = $('#category').val();
        var city = $('#city').val();
        var start = $('#start').val();
        
        console.log('Cateogry id is '+category);
           var attributes = [];
            $.each($("input[name='attributes']:checked"), function(){
                attributes.push($(this).val());
            });
            
            var rating_starts = [];
             $.each($("input[name='rating_starts']:checked"), function(){
                rating_starts.push($(this).val());
            });
            
            $.ajax({
                    url: '{{ URL::to("filter_tours") }}',
                    method: "post",
                    data: {
                        _token: '{{ csrf_token() }}', 
                        category: category,
                        city: city,
                        start:start,
                        min:parseInt(values[0]),
                        max:parseInt(values[1]),
                        attr:attributes,
                        starts:rating_starts,
                        request_page:'all_packages'
                    },
                    success: function (response) {
                        console.log(response);
                        var tourData = JSON.parse(response);
                        console.log(tourData);
                        // window.location.reload();
                        
                        var data_html = '<div class="row">';
                        
                        var toursFound = tourData.length;
                        $('#tours_result').html(toursFound+' Result found')
                        
                        for(var i=0; i<tourData.length; i++){
                            console.log('value of i '+tourData[i]['tour_banner_image']);
                                        if(tourData[i]['flights_details'] != null  && tourData[i]['flights_details'] != 'null'){
                                            flight_Detail = JSON.parse(tourData[i]['flights_details']);
                                        }
                                        
                                        if(tourData[i]['flights_details_more'] != null && tourData[i]['flights_details_more'] != 'null'){
                                             flights_details_more = JSON.parse(tourData[i]['flights_details_more']);
                                        }
                                        
                                       
                                        if(tourData[i]['flights_details'] != null  || tourData[i]['flights_details_more'] != null){
                                            if(flight_Detail['flight_type'] !== 'Indirect'){
                                                departure_form = flight_Detail['departure_airport_code'];
                                            }else{
                                                if(flights_details_more !== null && flights_details_more !== 'null'){
                                                    departure_form = flights_details_more[0]['more_departure_airport_code'];
                                                }else{
                                                    departure_form = '';
                                                }
                                                
                                            }
                                        }else{
                                            departure_form = '';
                                        }
                                        
                            var tourId = tourData[i]['id'];
                            
                            if(tourData[i]['content'].length > 125){
                                desc = tourData[i]['content'].substring(0,175);
                                desc +='..'
                            }else{
                                 desc = tourData[i]['content'];
                            }
                            
                             if(departure_form.length > 30){
                                departure_form = departure_form.substring(0,30);
                                departure_form +='..'
                            } 
                            
                            var startDate = new Date(tourData[i]['start_date']); 
                            var StartMonth = startDate.toLocaleString('default', { month: 'long' });
                            
                            var dateObj = new Date(tourData[i]['start_date']);
                            var month = dateObj.getUTCMonth() + 1; //months from 1-12
                            var day = dateObj.getUTCDate();
                            var year = dateObj.getUTCFullYear();
                            
                            startDate = day + "," + StartMonth + "," + year;
                            
                             var endDate = new Date(tourData[i]['end_date']); 
                            var endMonth = endDate.toLocaleString('default', { month: 'long' });
                            
                            var dateObjend = new Date(tourData[i]['end_date']);
                            var month = dateObjend.getUTCMonth() + 1; //months from 1-12
                            var endday = dateObjend.getUTCDate();
                            var endyear = dateObjend.getUTCFullYear();
                            
                            endDate = endday + "," + endMonth + "," + endyear;

                            data_html += ` <div class="col-md-12 mb-4">
                                        <div class="row parent_row">
                                            <div class="col-md-3">
                                                <div class="">
                                                    <img class="tour-img" src="{{ config('img_url') }}/public/uploads/package_imgs/${tourData[i]['tour_banner_image']}" alt="">
                                                    <div>
                                                        <img src="{{ config('img_url') }}/public/uploads/package_imgs/city_map.gif" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <h5 class="card-title">
                                                    <a href="{{ URL::to('view_detail/${tourId}') }}" style="text-decoration:none;">${tourData[i]['title']}</a>
                                                </h5>
                                                <h6 class="departure-date"><i class="fa-solid fa-plane-departure"></i>   
                                                    ${startDate}</h6>
                                                <p>${tourData[i]['starts_rating']}.0 `;
                                                
                                                     if(tourData[i]['starts_rating'] == 1){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        if(tourData[i]['starts_rating'] == 2){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        
                                                          
                                                        if(tourData[i]['starts_rating'] == 3){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        
                                                          
                                                        if(tourData[i]['starts_rating'] == 4){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        
                                                          
                                                        if(tourData[i]['starts_rating'] == 5){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                     
                                  data_html += `</p>
                                                <p class="tour-description">${desc}</p>
                                                <hr>
                                                <div class="row">
                                                     <div class="col-md-5">
                                                       
                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="fa-solid fa-plane-departure"></i> Departure From  </p>
                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="fa-solid fa-plane-arrival"></i> Return  </p>
                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="fa-solid fa-plane-arrival"></i> Available Spaces  </p>
                                                     </div>
                                                     <div class="col-md-7">
                                                            <p style="margin-bottom: 0;"> ${departure_form} </p>
                                                        
                                                        <p style="margin-bottom: 0;"> ${endDate}
                                                        </p>
                                                         <p style="margin-bottom: 0;"> ${tourData[i]['no_of_pax_days']} </p>
                                                     </div>
                                                    
                                                </div>
                                              
                                            </div>
                                            <div class="col-md-3 pt-2">
                                                    <div class="price">
                                                        <h6 style="font-size:25px; color:#d2b254;">
                                                               
                                                                <super>`
                                                                
                                                                  if(tourData[i]['quad_grand_total_amount'] != 0 && tourData[i]['quad_grand_total_amount'] != '' && tourData[i]['quad_grand_total_amount'] != null){
                                                                    data_html +=`${tourData[i]['currency_symbol']} ${tourData[i]['quad_grand_total_amount']}`;
                                                                    }
                                                                    else if(tourData[i]['triple_grand_total_amount'] != 0 && tourData[i]['triple_grand_total_amount'] != '' && tourData[i]['triple_grand_total_amount'] != null){
                                                                    data_html +=`${tourData[i]['triple_grand_total_amount']}`;
                                                                    }else{
                                                                     
                                                                    data_html +=`${tourData[i]['double_grand_total_amount']}`;
                                                                    
                                                                    }
                                                                    
                                                    data_html +=`</super>
                                                                 <sub>PP</sub>
                                                                
                                                              
                                                        </h6>
                                                        
                                                </div>
                                                <div class="time_length"><i class="fa fa-moon-o" aria-hidden="true"></i>Tour Length <span class="tour_length">${tourData[i]['time_duration']} Night</span></div>
                                                <h6 style="text-align:center;color:#477fe7;"><a href="{{ URL::to('view_detail/${tourId}') }}" style="text-decoration:none; font-size:15px;">View Details</a></h6>
                                                 <a href="{{ URL::to('view_detail/${tourId}') }}" style="text-decoration:none;" class="btn btn-primary form-control">Book Now</a>
                                            </div>
                                        </div>
                                    </div>`
                           
                                            
                                            
                                            
                                    }
                                    $('#tours_filter').html(data_html);
                                    console.log(data_html)
                    }
            });
                
        
        console.log(rating_starts);
    }



    
    
    var slider = document.querySelector("#kt_slider_basic");
var valueMin = document.querySelector("#kt_slider_basic_min");
var valueMax = document.querySelector("#kt_slider_basic_max");

noUiSlider.create(slider, {
    start: [1, 10000],
    connect: true,
    range: {
        "min": 0,
        "max": 10000
    }
});

slider.noUiSlider.on("update", function (values, handle) {
    console.log(values)
    if (handle) {
        valueMax.innerHTML = values[handle];
    } else {
        valueMin.innerHTML = values[handle];
    }
    
});


</script>
@endsection
