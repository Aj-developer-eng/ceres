<!DOCTYPE html>
<html class="no-js" lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="ThemeMarch">
    <!-- Site Title -->
    <title>Alhijaztours  - Travel Booking System</title>
    
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="https://alhijaztours.net/public/admin_package/frontend/css/lib/bootstrap.min.css">
    <link rel="stylesheet" href="{{asset('public/invoice/assets/css/style.css')}}">
    
    <style>
        .cs-border_less td{
            padding: 5px 15px;
        }
    .cs-invoice.cs-style1 .cs-invoice_head.cs-type1 {
   
    background: #000;
    padding: 25px;
    }
    .cs-white_color{
     color: #fff; 
    }
    body, html {
    color: #202020;
    font-family: 'Inter', sans-serif;
    font-size: 15px;
    }
    .cs-foot{
    font-size: 16px;
    text-align: center;
    margin-top: 35px;
    background: #000;
    color: #fff;
    padding: 9px;
    }
    </style>
    
</head>

<body>

    <div class="modal fade" id="book-Tour-Now" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel" style="font-size: 30px;">Booking info</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="">
                    <form action="#" method="post">
                        @csrf
                        <div class="row">
                            
                            <input type="text" hidden name="pakage_type" value="tour">
                            
                            <input type="text" hidden name="toure_id" id="toure_id" value="">
                            
                            <div class="col-xl-6">
                                <label class="form-label">Adult</label>
                                <select name="adults" id="adultsID" class="form-control">
                                    <option>0</option>
                                    <option>1</option>
                                    <option>2</option>
                                </select>
                            </div>
                            
                            <div class="col-xl-12 add-to-cart">
                                <button type="submit" class="btn btn-info" id="add_to_cart" style="display:none">
                                    <i class="awe-icon awe-icon-cart"></i>Send
                                </button>
                            </div>
                            
                        </div>
                    </form>
                </div>
                
            </div>
            <div class="modal-footer"></div>
        </div>
    </div>
    
    @if(Session::has('successINV'))
        <div class="alert alert-success" id="alert_hide">
            {{Session::get('successINV')}}
        </div>
    @endif
    
    @if(Session::has('errorINV'))
        <div class="alert alert-danger" id="alert_hide">
            {{Session::get('errorINV')}}
        </div>
    @endif
    
    @if(isset($cart_data))
        @foreach($cart_data as $cart_res)
        <?php  // dd($cart_data); ?>
            <div class="cs-container">
            <div class="cs-invoice cs-style1">
              <div class="cs-invoice_in" id="download_section">
                <div class="cs-invoice_head cs-type1 cs-mb25">
                  <div class="cs-invoice_left">
                    <p class="cs-invoice_number cs-white_color cs-mb0 cs-f16"><b>Invoice No:</b> {{ $id }}</p>
                    <?php 
                     $cart_total_data = json_decode($cart_res->cart_total_data);
                    //  print_r($cart_total_data);
                    //  die;
                    ?>
                    @isset($cart_total_data->agent_info)
                        @if($cart_total_data->agent_info != false)
                            <p class="cs-invoice_number cs-white_color cs-mb0 cs-f16"><b>Agent Name:</b> {{ $cart_res->agent_name }}</p>
                        @endif
                    @endisset
                  </div>
                  <div class="cs-invoice_right cs-text_right">
                    <div class="cs-logo cs-mb5"><img src="{{asset('public/admin_package/frontend/images/logo.png')}}"alt="Logo"></div>
                    <!--<img src="https://client.synchronousdigital.com/public/admin_package/assets/images/logo1-1.png" style="max-width: 15%;">-->
                  </div>
                </div>
                 @if(isset($iternery_array))
                                        @foreach($iternery_array as $itenry_res)
                                            
                <div class="cs-invoice_head cs-mb10">
                  <div class="cs-invoice_left">
                    <p>
                    
                        @if($payment_Status->confirm == 1)
                            @if($package_Type->pakage_type == 'tour')
                            <b class="cs-primary_color cs-f22">Confirmed: {{ $itenry_res[0]->time_duration ?? '' }} Days</b> <br>
                            @else
                            <b class="cs-primary_color cs-f22">Confirmed: {{ $tour_data->duration }} Hours</b> <br>
                            @endif
                        @else
                            @if($package_Type->pakage_type == 'tour')
                            <b class="cs-primary_color cs-f22"> Tentative <i class="fa-solid fa-check"></i></b> <br>
                            <b>{{ $itenry_res[0]->time_duration ?? '' }} Days </b></br>
                             @else
                            <b class="cs-primary_color cs-f22">Tentative: {{ $tour_data->duration }} Hours</b> <br>
                            @endif
                        @endif
                        
                        <?php
                       
                        $leadpassenger_details=$inv_data->passenger_detail;
                        ?>
                        <b class="cs-primary_color">Booked By: 
                         @if($cart_total_data->agent_name == -1)
                         {{$inv_data->passenger_name}}
                        
                        @else
                        @isset($cart_total_data->agent_info)
                             @if($cart_total_data->agent_info != false)
                                {{ $cart_total_data->agent_name }}
                            @else 
                            {{$inv_data->passenger_name}}
                             @endif
                        @endisset
                        @endif
                       
                        </b> <br>
                        
                      <?php
                      
                      $dateValue = strtotime($inv_data->created_at);
        $year = date('Y',$dateValue);
        $monthName = date('F',$dateValue);
        $monthNo = date('d',$dateValue);
        printf("%s, %d, %s\n", $monthName, $monthNo, $year);
                      ?>
                      
                    </p>
                    
                    <!--<h5>Payment Status :</h5>-->
                        @if($package_Type->pakage_type == 'tour')
                            @if(isset($total_package_Payments) || $total_package_Payments != null || $total_package_Payments != '' || $total_package_Payments != 0)
                                @if($recieved_package_Payments == 0)
                                    <b class="cs-primary_color cs-f22">UNPAID</b> <br>
                                @elseif($recieved_package_Payments > 0 && $recieved_package_Payments < $total_package_Payments->total_amount - $recieved_package_Payments)
                                    <b class="cs-primary_color cs-f22">PARTIALLY PAID</b> <br>
                                @else
                                    <b class="cs-primary_color cs-f22">PAID</b> <br>
                                @endif
                            @else
                            @endif
                        @elseif($package_Type->pakage_type == 'activity')
                            
                            @if($recieved_activity_Payments == 0)
                                <b class="cs-primary_color cs-f22">UNPAID</b> <br>
                            @elseif($recieved_activity_Payments > 0 && $recieved_activity_Payments < $total_package_Payments->total_amount - $recieved_activity_Payments)
                                <b class="cs-primary_color cs-f22">PARTIALLY PAID</b> <br>
                            @else
                                <b class="cs-primary_color cs-f22">PAID</b> <br>
                            @endif
                        @else
                        @endif
                  </div>
                  <div class="cs-invoice_right cs-text_right">
                    <b class="cs-primary_color">{{ $cart_res->tour_name }}</b>
                    <p>
                      {{$contact_details->company_name ?? ''}} <br>
                      {{$contact_details->email ?? ''}} <br>
                      {{$contact_details->contact_number ?? ''}}<br>
                      {{$contact_details->address ?? ''}}<br>
                    </p>
                  </div>
                </div>
                <div class="cs-invoice_head cs-50_col cs-mb25">
                  <div class="cs-invoice_left">
                    <b class="cs-primary_color">Adults</b> <br>
                        <?php
                        $leadpassenger_details=$inv_data->passenger_detail;

                        if($leadpassenger_details != 'null')
                        {
                            $adults_details1=json_decode($leadpassenger_details);
                            foreach($adults_details1 as $adults_details1){
                                 $leadgender = $adults_details1->gender;
                    
                      }
                    }
                    ?>
                        <b>Lead Passenger: </b>{{$inv_data->passenger_name}} ({{ $leadgender }})<br>
                    
                    <?php
                        $adults_details=$inv_data->adults_detail;
                        $Adult_No = 1;
                        
                        if($adults_details != 'null')
                        {
                            $adults_details1=json_decode($adults_details);
                            foreach($adults_details1 as $adults_details1){
                    ?>
                               <b> Adult {{ $Adult_No }} : </b>{{ $adults_details1->passengerName }} ( {{$adults_details1->gender}} ) <?php $Adult_No++ ?> <br>
                    <?php
                      }
                    }
                    ?>
                    
                    <?php
                        $child_details=$inv_data->child_detail;
                        if(isset($child_details) AND $child_details !== '""')
                        { 
                            $Child_No = 1;
                            $child_details1=json_decode($child_details);
                            echo '<b class="cs-primary_color">Children</b> <br>';
                            foreach($child_details1 as $child_details1){
                    ?>
                            <b> Child {{ $Child_No }} : </b> {{$child_details1->passengerName}} ( {{$child_details1->gender}} )<?php $Child_No++ ?> <br>
                    
                    <?php
                      }
                    }
                    ?>
                    
                     <?php
                        $infants_details=$inv_data->infant_details;
                        if(isset($infants_details) AND $infants_details !== '""')
                        { 
                            $infant_No = 1;
                            $infants_details1=json_decode($infants_details);
                            echo '<b class="cs-primary_color">Infants</b> <br>';
                            foreach($infants_details1 as $child_details1){
                    ?>
                            <b> Infant {{ $infant_No }} : </b> {{$child_details1->passengerName}} ( {{$child_details1->gender }} )<?php $infant_No++ ?> <br>
                    
                    <?php
                      }
                    }
                    ?>
                    
                  </div>
                  <div class="cs-invoice_right">
                    <ul class="cs-bar_list">
                        <?php 
                            if($package_Type->pakage_type == 'tour'){
                        ?>
                      <li><b class="cs-primary_color"><img style="max-width: 17px;margin-right: 5px;" src="{{asset('public/invoice/assets/img/plane-departure-solid.svg')}}"alt="Logo"> </b>
                      <?php
                      
                      $dateValue = strtotime(date("d-m-Y", strtotime($itenry_res[0]->start_date ?? '' )));
             
                        $year = date('Y',$dateValue);
                        $monthName = date('F',$dateValue);
                        $monthNo = date('d',$dateValue);
                        $day = date('l', $dateValue);
                        echo $day . ',' . $monthNo . ',' . $monthName . ',' . $year;
                        // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                      ?>
                      
                      
                      </li>
                      <li><b class="cs-primary_color"> <img style="max-width: 17px;margin-right: 5px;" src="{{asset('public/invoice/assets/img/plane-arrival-solid.svg')}}"alt="Logo"></b>
                      
                       <?php
                      
                      $dateValue = strtotime(date("d-m-Y", strtotime($itenry_res[0]->end_date ?? '' )));
                             
                        $year = date('Y',$dateValue);
                        $monthName = date('F',$dateValue);
                        $monthNo = date('d',$dateValue);
                        $day = date('l', $dateValue);
                        echo $day . ',' . $monthNo . ',' . $monthName . ',' . $year;
                        // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                        ?>
                        </li>
                        <?php
                        }else{
                            ?>
                            <li>Activtiy Date  : 
                            <?php
                            $dateValue = strtotime(date("d-m-Y", strtotime($cart_res->activity_select_date ?? '' )));
                             
                        $year = date('Y',$dateValue);
                        $monthName = date('F',$dateValue);
                        $monthNo = date('d',$dateValue);
                        $day_select = date('l', $dateValue);
                        echo $day_select . ',' . $monthNo . ',' . $monthName . ',' . $year;
                        
                        $start_time = '';
                        $end_time = '';
                        $Availibilty = json_decode($tour_data->Availibilty);
                        foreach($Availibilty as $id => $av_res){
                            if(isset($av_res->enable)){
                                        $day = '';
                                       
                                          if($id == '1'){
                                                $day = "Monday";
                                                if($day_select == $day){
                                                    
                                                    $start_time = $av_res->from;
                                                    $end_time = $av_res->to;
                                                }
                                          }
                                          
                                           if($id == '2'){
                                                $day = "Tuesday";
                                                if($day_select == $day){
                                                     
                                                    $start_time = $av_res->from;
                                                    $end_time = $av_res->to;
                                                }
                                          }
                                          
                                           if($id == '3'){
                                                $day = "Wednesday";
                                               if($day_select == $day){
                                                   
                                                    $start_time = $av_res->from;
                                                    $end_time = $av_res->to;
                                                }
                                          }
                                          
                                           if($id == '4'){
                                                $day = "Thursday";
                                                if($day_select == $day){
                                                    
                                                    $start_time = $av_res->from;
                                                    $end_time = $av_res->to;
                                                }
                                          }
                                          
                                           if($id == '5'){
                                                $day = "Friday";
                                                
                                                if($day_select == $day){
                                                    $start_time = $av_res->from;
                                                    $end_time = $av_res->to;
                                                }
                                          }
                                          
                                           if($id == '6'){
                                                $day = "Saturday";
                                                if($day_select == $day){
                                                    $start_time = $av_res->from;
                                                    $end_time = $av_res->to;
                                                }
                                          }
                                          
                                           if($id == '7'){
                                                $day = "Sunday";
                                                if($day_select == $day){
                                                    $start_time = $av_res->from;
                                                    $end_time = $av_res->to;
                                                }
                                          }
                            }
                        }
                        ?>
                            </li>
                            <li>Location: {{ $tour_data->location }}</li>
                            <li>Duration: {{ $tour_data->duration }} Hours</li>
                            <li>Start Time: {{ $start_time }} - End Time {{ $end_time }}</li>
                            <?php
                        }
                      ?>
                            
                      
                    </ul>
                    
                    <!--<h5 style="font-size:14px; font-weight: bold; margin-top:40px;" class="mt-5"><i class="fa-solid fa-passport"></i> Visa Included.</h5>-->
                    <!--<h5 style="font-size:14px; font-weight: bold;"><i class="fa-solid fa-bus"></i> Transfer Included.</h5>-->
                    <!--<h5 style="font-size:14px; font-weight: bold;"><i class="fa-solid fa-plane-departure"></i> Flights Included.</h5>-->
                    <!--<h5 style="font-size:14px; font-weight: bold;"><i class="fa-solid fa-hotel"></i> Hotels Included.</h5>-->
                  </div>
                </div>
                                   
                                       @endforeach
                                  @endif
                      <?php
                      ?>
                            <?php 
                            if($package_Type->pakage_type !== 'tour'){
                        ?>
                        <hr>
                          <div class="">
                            <h4><b class="cs-primary_color">Meeting And Pickup</b></h4> <br>
                     
                          </div>
                          <div>
                           {!! $tour_data->meeting_and_pickups !!}
                           
                           </div>
                          <!--<li>-->
                          <!--  <div class="cs-list_left" style="font-size: 13px;">-->
                               
                          <!--    <p class="cs-mb0">-->
                                
                          <!--    </p>-->
                          <!--  </div>-->
                            
                          <!--</li>-->
                         <?php 
                            }
                         ?>
                              <?php
                      
                      if(isset($accomodation_details))
                      { 
                          ?>
                         <div class="row">
                             <div class="col-md-12">
                                 <ul class="cs-list cs-style2">
                                              <div class="cs-list_left">
                                          <b class="cs-primary_color" style="margin-left: 25px; font-size: 18px;"> Accomodation Details</b> <br>
                                          
                                        </div>
                                        <?php
                                            //   $accomodation_details=$tour_batchs->accomodation_details;
                                            // $accomodation_details=json_decode($accomodation_details);
                                              foreach($accomodation_details as $accomodation_details)
                                              { //dd($accomodation_details);
                                          ?>            
                                    
                                      <li>
                                        <div class="cs-list_left" style="font-size: 15px;">
                                           
                                          <b class="cs-primary_color"> <i class="fa-solid fa-hotel"></i> Hotel Name :{{$accomodation_details->acc_hotel_name}} </b> <br><br>
                                         <div class="row">
                                             <div class="col-sm-4">
                                                  <img style="max-width: 17px;margin-right: 5px;" src="{{asset('public/invoice/assets/img/calendar-check-solid.svg')}}" alt="Logo">   Check In:{{$accomodation_details->acc_check_in}} 
                                             </div>
                                             <div class="col-sm-4">
                                                  <img style="max-width: 17px;margin-right: 5px;" src="{{asset('public/invoice/assets/img/calendar-check-solid.svg')}}"alt="Logo">  Check Out: {{$accomodation_details->acc_check_out}}
                                             </div>
                                            @if(isset($accomodation_details->hotel_meal_type) && $accomodation_details->hotel_meal_type != null && $accomodation_details->hotel_meal_type != '')
                                                <div class="col-sm-4">
                                                    <img style="max-width: 17px;margin-right: 5px;" src="{{asset('public/invoice/assets/img/meal-icon.png')}}"alt="Logo">  Meal Type: {{$accomodation_details->hotel_meal_type}}
                                                </div>
                                            @else
                                            @endif
                                             
                                             
                                         </div>
                                         
                                        </div>
                                        
                                      </li>
                                   
                                                      
                                       <?php
                                              }
                                              ?>
                                        </ul> 
                             </div>
                         </div>
                           <?php
                      }
                   ?>  
                      <div class="cs-invoice_head cs-50_col cs-mb25">
                    
                 
                           <div class="cs-invoice_left">
                              
                          </div>
                               
                                  
                    
                           <div class="cs-invoice_right">
                               
                    
                      
                      
                   
                      
                      
                      
                      
                      <?php
                      
                      if(isset($tour_batchs->transportation_details))
                      {?> 
                          <ul class="cs-list cs-style2">
                          <div class="cs-list_left">
                      <b class="cs-primary_color">Transportation Details</b> <br>
                      
                    </div>
                     <?php
                             $transportation_details=$tour_batchs->transportation_details;
                      $transportation_details=json_decode($transportation_details);
                          
                      ?>            
                
                  <li>
                    <div class="cs-list_left">
                      <b class="cs-primary_color"> </b> <br>
                      <p class="cs-mb0" style="line-height: 29px;">
                        <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/location-dot-solid.svg')}}"alt="Logo">  Pick Up :{{$transportation_details->transportation_pick_up_location}} <br>
                        <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/location-dot-solid.svg')}}"alt="Logo">  Drop Off: {{$transportation_details->transportation_drop_off_location}}<br>
                        <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/calendar-solid.svg')}}"alt="Logo">  Pick Up Date: {{$transportation_details->transportation_pick_up_date}}<br>
                       
                        Trip Type: {{$transportation_details->transportation_trip_type}}<br>
                      </p>
                    </div>
                    
                  </li>
               
                                  
                   
                        </ul>
                          
                     
                      <?php
                   
                      }
                   ?>               
                               </div>    
                      </div>
                    
                      <?php
                      
                        if(isset($tour_batchs->flights_details))
                        {
                          
                      ?>            
                <ul class="cs-list cs-style2">
                          <div class="cs-list_left">
                      <b class="cs-primary_color">Flights Details</b> <br>
                      
                    </div>
                    @if(isset($flights_details->flight_type))
                        @if($flights_details->flight_type == 'Direct')
                            <li>
                                <div class="cs-list_left">
                                    <p class="s-mb0" style="line-height: 35px;"> 
                                        <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/plane-departure-solid.svg')}}"alt="Logo"> : {{$flights_details->departure_airport_code ?? ''}} <br>
                                        Departure Flight Number:{{ $flights_details->departure_flight_number ?? '' }}<br>
                                        Departure Date: {{$flights_details->departure_date ?? ''}}<br>
                                    </p>
                                </div>
                                <div class="cs-list_right">
                                    <p class="cs-mb0" style="line-height: 30px;">
                                        <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/plane-arrival-solid.svg')}}"alt="Logo">  : {{ $flights_details->arrival_airport_code ?? '' }}<br>
                                        Arrival Flight Number:</span>{{ $flights_details->arrival_flight_number ?? ''  }}<br>
                                        Arrival Date:</span>{{ $flights_details->arrival_date ?? '' }}<br>
                                        Flight Type: {{$flights_details->flight_type ?? ''}}<br>
                                    </p>
                                </div>
                            </li>
                        @elseif($flights_details->flight_type == 'Indirect')
                            @foreach($flights_detailsI as $value)
                                <li>
                                    <div class="cs-list_left">
                                        <p class="s-mb0" style="line-height: 35px;"> 
                                            <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/plane-departure-solid.svg')}}"alt="Logo"> : {{$value->more_departure_airport_code ?? ''}} <br>
                                            Departure Flight Number:{{ $value->more_departure_flight_number ?? '' }}<br>
                                            Departure Date: {{$value->more_departure_time ?? ''}}<br>
                                        </p>
                                    </div>
                                    <div class="cs-list_right">
                                        <p class="cs-mb0" style="line-height: 30px;">
                                            <img style="border: 0;max-width: 3%;height: auto;vertical-align: middle;" src="{{asset('public/invoice/assets/img/plane-arrival-solid.svg')}}"alt="Logo">  : {{ $value->return_more_departure_airport_code ?? '' }}<br>
                                            Arrival Flight Number:</span>{{ $value->return_more_departure_flight_number ?? ''  }}<br>
                                            Arrival Date:</span>{{ $value->return_more_arrival_time ?? '' }}<br>
                                            Flight Type: {{$value->return_more_departure_Flight_Type ?? ''}}<br>
                                        </p>
                                    </div>
                                </li>
                            @endforeach
                        @else
                            <h4>No Flight Details</h4>
                        @endif
                    @else
                    @endif
               </ul>
                                  
                   <?php
                          
                   
                      }
                   ?>               
                              
                </ul>
                <?php 
                        $cart_total_data = json_decode($cart_res->cart_total_data);
                        // print_r($cart_total_data);
                     ?>
                <div class="cs-table cs-style1">
                  <div class="cs-round_border">
                    <div class="cs-table_responsive">
                      <table class="cs-border_less">
                        <tbody>
                          <tr>
                            <td class="cs-primary_color cs-semi_bold cs-f18" colspan="3">Rooms
                            </td>
                            <td class="cs-primary_color cs-semi_bold cs-f18">
                            </td>
                            <td class="cs-primary_color cs-semi_bold cs-f18">PAX
                            </td>
                            <td class="cs-primary_color cs-semi_bold cs-f18">
                               Price
                            </td>
                          </tr>
                          
                           <?php 
                                $cart_total_data = json_decode($cart_res->cart_total_data);
                                $cart_data_visa = json_decode($cart_res->visa_change_data);
                                
                            //   print_r($cart_total_data);
                          ?>
                          @if($cart_res->adults> 0)
                          <tr>
                            <td>Adults : {{ $cart_res->adults }}</td>
                            <td class="cs-primary_color">
                                <?php 
                                    if($cart_res->childs){
                                ?>
                                Children : {{ $cart_res->childs }}
                                
                                <?php 
                                    }
                                ?>
                            </td>
                            <td class="cs-bold cs-primary_color cs-text_right"></td>
                            <?php 
                            if($package_Type->pakage_type == 'tour'){
                        ?>
                            <td class="cs-bold cs-primary_color cs-text_right">Adult Price : {{ $currency_Symbol->currency_symbol }} {{ $cart_res->sigle_price }}<br>
                            <?php 
                                        if($cart_res->child_price_tour != 0 && $cart_res->child_price_tour != null && $cart_res->child_price_tour !== 'null'){
                                            if($cart_res->childs){
                                            ?>
                                             Child Price:</span>{{ $cart_res->currency }} {{ $cart_res->child_price_tour }}
                                            <?php
                                            }
                                        }
                                     ?></td>
                            <?php 
                            }else{
                                ?>
                            <td class="cs-bold cs-primary_color cs-text_right">Adult Price: {{ $currency_Symbol->currency_symbol }} {{ $cart_res->adult_price }} - Child Price :{{ $currency_Symbol->currency_symbol }} {{ $cart_res->child_price }}</td>
                                <?php
                            }
                        ?>
                          </tr>
                           @endif
                             @if($cart_res->double_adults > 0  || $cart_total_data->double_childs > 0 || $cart_total_data->double_infant > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Double Rooms X {{ $cart_res->double_room }}
                                </td>
                                 <td></td>
                               
                                <td class="cs-primary_color cs-semi_bold cs-f14" >
                                 @isset($cart_res->double_adults)
                                    {{ $cart_res->double_adults }} Adults,
                                @endisset
                                
                                @isset($cart_total_data->double_childs)
                                    {{ $cart_total_data->double_childs }} Child,
                                @endisset
                                
                                @isset($cart_total_data->double_infant)
                                    {{ $cart_total_data->double_infant }} Infants
                                @endisset
                                </td>
                                <td>
                                   {{ $cart_total_data->currency }} {{ $cart_total_data->double_adult_total + $cart_total_data->double_childs_total + $cart_total_data->double_infant_total }}
                                </td>
                           </tr>
                          @endif
                          
                              @if($cart_res->triple_adults > 0  || $cart_total_data->triple_childs > 0 || $cart_total_data->triple_infant > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Triple Rooms X  {{ $cart_res->triple_room }}
                                </td>
                                <td></td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                               @isset($cart_res->triple_adults)
                                    {{ $cart_res->triple_adults }} Adults,
                                @endisset
                                
                                @isset($cart_total_data->triple_childs)
                                    {{ $cart_total_data->triple_childs }} Child,
                                @endisset
                                
                                @isset($cart_total_data->triple_infant)
                                    {{ $cart_total_data->triple_infant }} Infants
                                @endisset
                                </td>
                                <td>
                                    {{ $cart_total_data->currency }} {{ $cart_total_data->triple_adult_total + $cart_total_data->triple_childs_total + $cart_total_data->triple_infant_total }}
                                </td>
                                
                           </tr>
                          @endif
                          
                                 @if($cart_res->quad_adults > 0  || $cart_total_data->quad_childs > 0 || $cart_total_data->quad_infant > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Quad Rooms X  {{ $cart_res->quad_room }}
                                </td>
                                 <td></td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                @isset($cart_res->quad_adults)
                                    {{ $cart_res->quad_adults }} Adults,
                                @endisset
                                
                                @isset($cart_total_data->quad_childs)
                                    {{ $cart_total_data->quad_childs }} Child,
                                @endisset
                                
                                @isset($cart_total_data->quad_infant)
                                    {{ $cart_total_data->quad_infant }} Infants
                                @endisset
                                </td>
                                 <td>
                                    {{ $cart_total_data->currency }} {{ $cart_total_data->quad_adult_total ?? '0' + $cart_total_data->quad_child_total ?? '0' + $cart_total_data->quad_infant_total ?? '0' }}
                                </td>
                                
                               
                           </tr>
                          @endif
                           <tr>
                               <td colspan="12"><hr></td>
                              
                              
                           </tr>
                            <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f18" colspan="3">Rooms
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f18">PAX
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f18">Price Per Person
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f18">Discount
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f18" style="text-align: right;">Total
                                </td>
                              </tr>
                         
                           @if($cart_res->double_adults > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Adults in Double Room
                                    <p style="font-size:13px;">
                                       @isset($cart_data_visa->double_adult_visa_persons)
                                         {{ $cart_data_visa->double_adult_visa_persons }} X {{ $cart_data_visa->double_adult_visa_type }} :{{ $cart_res->currency }} {{ $cart_data_visa->visa_actual_price_change }} (.Incl)
                                         <br>{{ $cart_res->double_adults - $cart_data_visa->double_adult_visa_persons }} X {{ $visa_type }} :{{ $cart_res->currency }} {{ $visa_orignial_fee }} (.Incl)
                                       
                                       @endisset
                                    </p>
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_res->double_adults)
                                    {{ $cart_res->double_adults }} Adult
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->sharing2 }}</td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->double_adult_disc_total }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->double_adult_total }}</td>
                           </tr>
                          @endif
                          
                           @if($cart_total_data->double_childs > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Childs in Double Room
                                    <p style="font-size:13px;">
                                   @isset($cart_data_visa->double_child_visa_persons)
                                         {{ $cart_data_visa->double_child_visa_persons }} X {{ $cart_data_visa->double_child_visa_type }} :{{ $cart_res->currency }} {{ $cart_data_visa->visa_actual_price_change_double_child }} (.Incl)
                                         <br>{{ $cart_total_data->double_childs - $cart_data_visa->double_child_visa_persons }} X {{ $visa_type }} :{{ $cart_res->currency }} {{ $visa_orignial_fee }} (.Incl)
                                       
                                    @endisset
                                    </p>
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14" >
                                 @isset($cart_total_data->double_childs)
                                    {{ $cart_total_data->double_childs }} Child
                                @endisset
                                
                               
                                </td>
                                
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->double_child_price }}</td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->double_child_disc_total }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->double_childs_total }}</td>
                           </tr>
                          @endif
                          
                        @if($cart_total_data->double_infant > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i>  Infants in Double Room
                                    <p style="font-size:13px;">
                                    @isset($cart_data_visa->double_infant_visa_persons)
                                          {{ $cart_data_visa->double_infant_visa_persons }} X {{ $cart_data_visa->double_infant_visa_type }} :{{ $cart_res->currency }} {{ $cart_data_visa->visa_actual_price_change_double_infant }} (.Incl)
                                          <br>{{ $cart_total_data->double_infant - $cart_data_visa->double_infant_visa_persons }} X {{ $visa_type }} :{{ $cart_res->currency }} {{ $visa_orignial_fee }} (.Incl)
                                        
                                     @endisset
                                     </p>
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14" >
                                 @isset($cart_total_data->double_infant)
                                    {{ $cart_total_data->double_infant }} Infant
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->double_infant_price }}</td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->double_infant_disc_total }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->double_infant_total }}</td>
                           </tr>
                          @endif
                          
                          
                          
                          
                        
                          
                           @if($cart_total_data->triple_adults > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Adults in Triple Room
                                        <p style="font-size:13px;">
                                        @isset($cart_data_visa->triple_adult_visa_persons)
                                          {{ $cart_data_visa->triple_adult_visa_persons }} X {{ $cart_data_visa->triple_adult_visa_type }} :{{ $cart_res->currency }} {{ $cart_data_visa->visa_actual_price_change_triple }} (.Incl)
                                          <br>{{ $cart_total_data->triple_adults - $cart_data_visa->triple_adult_visa_persons }} X {{ $visa_type }} :{{ $cart_res->currency }} {{ $visa_orignial_fee }} (.Incl)
                                        
                                        @endisset
                                     </p>
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_total_data->triple_adults)
                                    {{ $cart_total_data->triple_adults }} Adult
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->sharing3 }}</td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->triple_adult_disc_total }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->triple_adult_total }}</td>
                           </tr>
                          @endif
                          
                            @if($cart_total_data->triple_childs > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Child in Triple Room
                                    <p style="font-size:13px;">
                                    @isset($cart_data_visa->triple_child_visa_persons)
                                             {{ $cart_data_visa->triple_child_visa_persons }} X {{ $cart_data_visa->triple_child_visa_type }} :{{ $cart_res->currency }} {{ $cart_data_visa->visa_actual_price_change_triple_child }} (.Incl)
                                             <br>{{ $cart_total_data->triple_childs - $cart_data_visa->triple_child_visa_persons }} X {{ $visa_type }} :{{ $cart_res->currency }} {{ $visa_orignial_fee }} (.Incl)
                                           
                                        @endisset
                                    </p>
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_total_data->triple_childs)
                                    {{ $cart_total_data->triple_childs }} Child
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->triple_child_price }}</td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->triple_child_disc_total }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->triple_childs_total }}</td>
                           </tr>
                          @endif
                          
                        @if($cart_total_data->triple_infant > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Infants in Triple Room
                                    <p style="font-size:13px;">
                                    @isset($cart_data_visa->triple_infant_visa_persons)
                                             {{ $cart_data_visa->triple_infant_visa_persons }} X {{ $cart_data_visa->triple_infant_visa_type }} :{{ $cart_res->currency }} {{ $cart_data_visa->visa_actual_price_change_triple_infant }} (.Incl)
                                             <br>{{ $cart_total_data->triple_infant - $cart_data_visa->triple_infant_visa_persons }} X {{ $visa_type }} :{{ $cart_res->currency }} {{ $visa_orignial_fee }} (.Incl)
                                           
                                        @endisset
                                    </p>
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_total_data->triple_infant)
                                    {{ $cart_total_data->triple_infant }} Infant
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->triple_infant_price }}</td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->triple_infant_disc_total }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->triple_infant_total }}</td>
                           </tr>
                          @endif
                          
                          
                     
                          
                               @if($cart_total_data->quad_adults > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Adults in Quad Room
                                   <p style="font-size:13px;">
                                    @isset($cart_data_visa->quad_adult_visa_persons)
                                             {{ $cart_data_visa->quad_adult_visa_persons }} X {{ $cart_data_visa->quad_adult_visa_type }} :{{ $cart_res->currency }} {{ $cart_data_visa->visa_actual_price_change_quad }} (.Incl)
                                             <br>{{ $cart_total_data->quad_adults - $cart_data_visa->quad_adult_visa_persons }} X {{ $visa_type }} :{{ $cart_res->currency }} {{ $visa_orignial_fee }} (.Incl)
                                           
                                        @endisset
                                    </p>
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_total_data->quad_adults)
                                    {{ $cart_total_data->quad_adults }} Adult
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->sharing4 }}</td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->quad_adult_disc_total }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->quad_adult_total ?? '0' }}</td>
                           </tr>
                          @endif
                          
                         @if($cart_total_data->quad_childs > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i> Child in Quad Room
                                    <p style="font-size:13px;">
                                    @isset($cart_data_visa->quad_child_visa_persons)
                                             {{ $cart_data_visa->quad_child_visa_persons }} X {{ $cart_data_visa->quad_child_visa_type }} :{{ $cart_res->currency }} {{ $cart_data_visa->visa_actual_price_change_quad_child }} (.Incl)
                                             <br>{{ $cart_total_data->quad_childs - $cart_data_visa->quad_child_visa_persons }} X {{ $visa_type }} :{{ $cart_res->currency }} {{ $visa_orignial_fee }} (.Incl)
                                           
                                        @endisset
                                    </p>
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_total_data->quad_childs)
                                    {{ $cart_total_data->quad_childs }} Child
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->quad_child_price ?? '0' }}</td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->quad_child_disc_total }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ number_format((float)$cart_total_data->quad_child_total, 2, '.', '');  }}</td>
                           </tr>
                          @endif
                          
                                @if($cart_total_data->quad_infant > 0)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-bed"></i>  Infant in Quad Room
                                    <p style="font-size:13px;">
                                    @isset($cart_data_visa->quad_infant_visa_persons)
                                             {{ $cart_data_visa->quad_infant_visa_persons }} X {{ $cart_data_visa->quad_infant_visa_type }} :{{ $cart_res->currency }} {{ $cart_data_visa->visa_actual_price_change_quad_infant }} (.Incl)
                                             <br>{{ $cart_total_data->quad_infant - $cart_data_visa->quad_infant_visa_persons }} X {{ $visa_type }} :{{ $cart_res->currency }} {{ $visa_orignial_fee }} (.Incl)
                                           
                                        @endisset
                                    </p>
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                 @isset($cart_total_data->quad_infant)
                                    {{ $cart_total_data->quad_infant }} Infant
                                @endisset
                                
                               
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->quad_infant_price }}</td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->quad_infant_disc_total }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->quad_infant_total }}</td>
                           </tr>
                          @endif
                          
                          
                              @isset($cart_res->without_acc_adults)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-user"></i> Adult Without Bed
                                    <p style="font-size:13px;">
                                    @isset($cart_data_visa->without_acc_adult_visa_persons)
                                             {{ $cart_data_visa->without_acc_adult_visa_persons }} X {{ $cart_data_visa->without_acc_adult_visa_type }} :{{ $cart_res->currency }} {{ $cart_data_visa->visa_actual_price_change_without_acc }} (.Incl)
                                             <br>{{ $cart_total_data->without_acc_adults - $cart_data_visa->without_acc_adult_visa_persons }} X {{ $visa_type }} :{{ $cart_res->currency }} {{ $visa_orignial_fee }} (.Incl)
                                           
                                        @endisset
                                    </p>
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                    {{ $cart_res->without_acc_adults }} Adult
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->without_acc_adult_price }}</td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->without_acc_adult_disc_total }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->without_acc_adult_total }}</td>
                           </tr>
                          @endif
                          
                           @isset($cart_total_data->children)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-child"></i> Child Without Bed
                                    <p style="font-size:13px;">
                                    @isset($cart_data_visa->without_acc_child_visa_persons)
                                             {{ $cart_data_visa->without_acc_child_visa_persons }} X {{ $cart_data_visa->without_acc_child_visa_type }} :{{ $cart_res->currency }} {{ $cart_data_visa->visa_actual_price_change_without_acc_child }} (.Incl)
                                             <br>{{ $cart_total_data->children - $cart_data_visa->without_acc_child_visa_persons }} X {{ $visa_type }} :{{ $cart_res->currency }} {{ $visa_orignial_fee }} (.Incl)
                                           
                                        @endisset
                                    </p>
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                    {{ $cart_total_data->children }} Child
                                </td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->child_price }}</td>
                                <td>{{ $cart_total_data->currency }} {{ $cart_total_data->quad_child_disc_total }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ round($cart_total_data->without_acc_child_total ?? '0', 2); }}</td>
                           </tr>
                          @endif
                          
                            @isset($cart_total_data->infants)
                           <tr>
                                <td class="cs-primary_color cs-semi_bold cs-f14" colspan="3"><i class="fa-solid fa-person-breastfeeding"></i> Infants Without Bed
                                    <p style="font-size:13px;">
                                    @isset($cart_data_visa->without_acc_infant_visa_persons)
                                             {{ $cart_data_visa->without_acc_infant_visa_persons }} X {{ $cart_data_visa->without_acc_infant_visa_type }} :{{ $cart_res->currency }} {{ $cart_data_visa->visa_actual_price_change_without_acc_infant }} (.Incl)
                                             <br>{{ $cart_total_data->infants - $cart_data_visa->without_acc_infant_visa_persons }} X {{ $visa_type }} :{{ $cart_res->currency }} {{ $visa_orignial_fee }} (.Incl)
                                           
                                        @endisset
                                    </p>
                                </td>
                                <td class="cs-primary_color cs-semi_bold cs-f14">
                                    {{ $cart_total_data->infants }} Infant
                                </td>
                                 <td>{{ $cart_total_data->currency }} {{ $cart_total_data->infant_price }}</td>
                                 <td>{{ $cart_total_data->currency }} {{ $cart_total_data->without_acc_infant_disc_total }}</td>
                                <td style="text-align: right;">{{ $cart_total_data->currency }} {{ $cart_total_data->without_acc_infant_total }}</td>
                           </tr>
                          @endif
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                 <?php
                             if($cart_res->Additional_services_names != '' && $cart_res->Additional_services_names != '[]'){
                                $additional_services = json_decode($cart_res->Additional_services_names);
                           ?>
                <div class="cs-table cs-style1 cs-type1 cs-focus_bg">
                  <h3 class="cs-primary_color cs-bold cs-f18">Additional Services</h3>
                  <div class="cs-table_responsive">
                    <table>
                        <thead>
                             <tr>
                              <td class="cs-text_center cs-semi_bold" >Name</td>
                              <td class="cs-text_center cs-semi_bold">Price</td>
                              <td class="cs-text_center cs-semi_bold">Persons</td>
                              <td class="cs-text_center cs-semi_bold">Days</td>
                              <td class="cs-text_center cs-semi_bold">Dates</td>
                              <td class="cs-text_center cs-semi_bold">Total</td>
                            </tr>
                        </thead>
                      <tbody>
                          <?php 
                            foreach($additional_services as $service_res){
                           ?>
                            <tr>
                              <td class="cs-text_center cs-semi_bold" >{{ $service_res->service }}</td>
                              <td class="cs-text_center cs-semi_bold">{{  $cart_res->currency." ".$service_res->service_price }}</td>
                              <td class="cs-text_center cs-semi_bold">{{ $service_res->person }}</td>
                              <td class="cs-text_center cs-semi_bold">{{ $service_res->Service_Days }}</td>
                              <td class="cs-text_center cs-semi_bold"><?php 
                                                            if($service_res->dates != null){
                                                                echo $service_res->dates;
                                                            }else{
                                                                echo '';
                                                            }
                                                      ?></td>
                              <td class="cs-text_center cs-semi_bold">{{ $cart_res->currency }} {{ $service_res->total_price }}</td>
                            </tr>
                          <?php 
                            }
                          ?>
                      </tbody>
                    </table>
                  </div>
                </div>
                
                            <?php 
                             }
                            ?>
                <div class="cs-table cs-style1 cs-mb20">
                  <div class="cs-table_responsive">
                    <table class="cs-border_less">
                      <tbody>
                        @isset($cart_total_data->price_without_disc)
                         <tr>
                          <td></td>
                          <td class="cs-bold cs-primary_color cs-f18" style="float: right;">Package Price :</td>
                          <td class="cs-bold cs-primary_color cs-f18 cs-text_right" style=" width: 140px;">{{ $currency_Symbol->currency_symbol }} {{ $cart_total_data->price_without_disc  }}</td>
                        </tr>
                        @endisset
                        @isset($cart_total_data->discount_Price)
                         <tr>
                          <td></td>
                          <td class="cs-bold cs-primary_color cs-f18" style="float: right;;">Discount Price <?php if($cart_total_data->discount_type == '%') echo " ( ".$cart_total_data->discount_enter_am." % )" ?>:</td>
                          <td class="cs-bold cs-primary_color cs-f18 cs-text_right">{{ $currency_Symbol->currency_symbol }} {{ $cart_total_data->discount_Price  }}</td>
                        </tr>
                          @endisset
                          
                            @isset($cart_total_data->agent_info)
                                @if($cart_total_data->Agent_commission_info  != false)
                                    @isset($cart_total_data->Agent_commission_info)
                                        <tr>
                                      <td></td>
                                      <td class="cs-bold cs-primary_color cs-f18" style="float: right;;">Agent Commission <?php if($cart_total_data->agent_commission_type == '%') echo " ( ".$cart_total_data->agent_commission_enter." % )" ?>:</td>
                                      <td class="cs-bold cs-primary_color cs-f18 cs-text_right">{{ $currency_Symbol->currency_symbol }} {{ $cart_total_data->agent_commsion_am  }}</td>
                                    </tr>
                                    @endisset
                                @endif
                            @endisset
                          
                          
                             @php 
                                            $total = 0;
                                    
                                @endphp
                                @foreach($cart_data as $cart_res)
                                    @php 
                                       $total = $total + $cart_res->price
                                    @endphp
                                @endforeach
                                
                        <tr>
                          <td></td>
                          <td class="cs-bold cs-primary_color cs-f18" style="float: right;;">Total Amount:</td>
                          <td class="cs-bold cs-primary_color cs-f18 cs-text_right">{{ $currency_Symbol->currency_symbol }} {{ $cart_total_data->price }}</td>
                        </tr>

                        
                      </tbody>
                    </table>
                  </div>
                </div>
                
                <div class="cs-table cs-style1 cs-type1 cs-focus_bg">
                  <h3 class="cs-primary_color cs-bold cs-f18">Payment Details</h3>
                  <div class="cs-table_responsive">
                    <table>
                      <tbody>
                        @if($package_Type->pakage_type == 'tour')
                            <tr>
                              <td class="cs-text_center cs-semi_bold" >Package</td>
                              <td class="cs-text_center cs-semi_bold">Paid On</td>
                              <td class="cs-text_center cs-semi_bold">Total Amount</td>
                              <td class="cs-text_center cs-semi_bold">Total Recieved</td>
                              <td class="cs-text_center cs-semi_bold">Remaining</td>
                            </tr>
                            
                            @if(isset($package_Payments))
                                <?php $t_C = $total; ?>
                                @foreach($package_Payments as $value)
                                    <tr>
                                        <td class="cs-primary_color">{{ $cart_res->tour_name }}</td>
                                        <td class="cs-primary_color cs-text_center">
                                            <?php
                                            
                                                $dateValue = strtotime($value->date);
                                                $year = date('Y',$dateValue);
                                                $monthName = date('F',$dateValue);
                                                $monthNo = date('d',$dateValue);
                                                $day = date('l',$dateValue);
                                                printf("%s, %d, %s\n", $monthName, $monthNo, $year);
                                                $t_C = $t_C - $value->recieved_amount;
                                            ?>
                                        </td>
                                        <td class="cs-primary_color cs-text_center">{{ $currency_Symbol->currency_symbol }} {{ $value->total_amount }}</td>
                                        <td class="cs-primary_color cs-text_center">{{ $currency_Symbol->currency_symbol }} {{ $value->recieved_amount }}</td>
                                        <td class="cs-primary_color cs-text_center">{{ $currency_Symbol->currency_symbol }} 
                                            @if($value->remaining_amount < -1)
                                                0
                                            @else
                                                {{  $t_C }}
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        @elseif($package_Type->pakage_type == 'activity')
                            <tr>
                              <td class="cs-text_center cs-semi_bold" >Activity</td>
                              <td class="cs-text_center cs-semi_bold">Paid On</td>
                              <td class="cs-text_right cs-semi_bold">Total Amount</td>
                              <td class="cs-text_center cs-semi_bold">Total Recieved</td>
                              <td class="cs-text_center cs-semi_bold">Remaining</td>
                            </tr>
                            @if(isset($activity_Payments))
                                @foreach($activity_Payments as $value)
                                    <tr>
                                        <td class="cs-primary_color cs-text_center">{{ $cart_res->tour_name }}</td>
                                        <td class="cs-primary_color cs-text_center">
                                            <?php
                                                $dateValue = strtotime($value->created_at);
                                                $year = date('Y',$dateValue);
                                                $monthName = date('F',$dateValue);
                                                $monthNo = date('d',$dateValue);
                                                printf("%s, %d, %s\n", $monthName, $monthNo, $year);
                                            ?>
                                        </td>
                                        <td class="cs-primary_color cs-text_center">{{ $currency_Symbol->currency_symbol }} {{ $value->total_amount }}</td>
                                        <td class="cs-primary_color cs-text_center">{{ $currency_Symbol->currency_symbol }} {{ $value->recieved_amount }}</td>
                                        <!--<td class="cs-primary_color cs-text_center">{{ $currency_Symbol->currency_symbol }} {{ $value->remaining_amount }}</td>-->
                                    </tr>
                                @endforeach
                            @endif
                        @endif
                      </tbody>
                    </table>
                  </div>
                </div>
                
                <div class="cs-table cs-style1 cs-type1">
                  <div class="cs-table_responsive">
                    <table>
                      <tbody>
                        <tr class="cs-table_baseline">
                          <!--<td>-->
                          <!--  <b class="cs-primary_color">Cost Per Person</b> <br>-->
                          <!--  Per Person 66.66 per night included <br>fee & take.-->
                          <!--</td>-->
                            @if($package_Type->pakage_type == 'tour')
                                <td>
                                    <p class="cs-mb5 cs-primary_color cs-semi_bold" style="margin-left: 60%;">Total Paid:</p>
                                    <p class="cs-m0 cs-primary_color cs-semi_bold" style="margin-left: 60%;">Total Balance Due:</p>
                                    <p class="cs-m0 cs-primary_color cs-semi_bold" style="margin-left: 60%;">Over Paid:</p>
                                </td>
                                <td>
                                    <p class="cs-mb5 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ $recieved_package_Payments }}</p>
                                    @if(isset($total_package_Payments) || $total_package_Payments != null || $total_package_Payments != '' || $total_package_Payments != 0)
                                        <?php $ttt = $total_package_Payments->total_amount - $recieved_package_Payments ?>
                                        @if(isset($ttt) && $ttt < -1)
                                            <?php $ttt =  $recieved_package_Payments - $total_package_Payments->total_amount ?>
                                            <p class="cs-m0 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ 0 }}</p>
                                            <p class="cs-mb5 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ $ttt }}</p>
                                        @else
                                            <p class="cs-m0 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ $ttt }}</p>
                                            <p class="cs-mb5 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ 0 }}</p>
                                        @endif
                                    @else
                                        <p class="cs-m0 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ $recieved_package_Payments }}</p>
                                        <p class="cs-mb5 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ 0 }}</p>
                                    @endif
                                </td> 
                            @elseif($package_Type->pakage_type == 'activity')
                                <td>
                                    <p class="cs-mb5 cs-primary_color cs-semi_bold" style="margin-left: 80%;">Total Paid:</p>
                                    <p class="cs-m0 cs-primary_color cs-semi_bold" style="margin-left: 70%;">Total Balance Due:</p>
                                    <p class="cs-m0 cs-primary_color cs-semi_bold" style="margin-left: 70%;">Over Paid:</p>
                                </td>
                                <td>
                                    <p class="cs-mb5 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ $recieved_activity_Payments }}</p>
                                    @if(isset($total_package_Payments) && $total_package_Payments != null && $total_package_Payments != '' && $total_package_Payments != 0)
                                        <p class="cs-m0 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ $total_package_Payments->total_amount - $recieved_activity_Payments }}</p>
                                    @else
                                        <p class="cs-m0 cs-text_left cs-primary_color cs-semi_bold">{{ $currency_Symbol->currency_symbol }} {{ $recieved_activity_Payments }}</p>
                                    @endif
                                </td>
                            @endif
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              
                <div class="cs-invoice_btns cs-hide_print">
                    <a href="javascript:window.print()" class="cs-invoice_btn cs-color1">
                      <svg xmlns="http://www.w3.org/2000/svg" class="ionicon" viewBox="0 0 512 512"><path d="M384 368h24a40.12 40.12 0 0040-40V168a40.12 40.12 0 00-40-40H104a40.12 40.12 0 00-40 40v160a40.12 40.12 0 0040 40h24" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><rect x="128" y="240" width="256" height="208" rx="24.32" ry="24.32" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><path d="M384 128v-24a40.12 40.12 0 00-40-40H168a40.12 40.12 0 00-40 40v24" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><circle cx="392" cy="184" r="24"/></svg>
                      <span>Print</span>
                    </a>
                    <button id="download_btn" class="cs-invoice_btn cs-color2">
                      <svg xmlns="http://www.w3.org/2000/svg" class="ionicon" viewBox="0 0 512 512"><title>Download</title><path d="M336 176h40a40 40 0 0140 40v208a40 40 0 01-40 40H136a40 40 0 01-40-40V216a40 40 0 0140-40h40" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M176 272l80 80 80-80M256 48v288"/></svg>
                      <span>Download</span>
                    </button>
                    
                    <!--<a class="cs-invoice_btn cs-color1" data-bs-toggle="modal" data-bs-target="#book-Tour-Now">-->
                    <!--  <span>Send Email</span>-->
                    <!--</a>-->
                    
                    <div class="button-list">
                        <button style="height: 40px;" type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#send-mail">Send Mail</button>
                    </div>  
                    
                    <div id="send-mail" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <div class="auth-brand text-center mt-2 mb-4 position-relative top-0">
                                        <h3>Send Email</h3>
                                    </div>
                
                                    <form class="ps-3 pe-3" action="{{URL::to('sendemail/send')}}" method="post" enctype="multipart/form-data">
                                        @csrf
                                        
                                        <input type="hidden" value="{{ $cart_data[0]->tour_id }}" name="TourID">
                                        <input type="hidden" value="{{ $cart_data[0]->booking_id }}" name="bookingID">
                                        <input type="hidden" value="{{ $cart_data[0]->invoice_no }}" name="InvoiceNo">
                                        
                                        <div class="mb-3">
                                            <label for="email_Address" class="form-label">Email address</label>
                                            <input class="form-control" type="email" name="email_Address" placeholder="Enter Your Email" required>
                                        </div>
                
                                        <div class="mb-3">
                                            <label for="comment_Area" class="form-label">Comment</label>
                                            <textarea class="form-control" name="comment_Area" placeholder="Enter Your View" cols="135" rows="5" required readonly>Dear @isset($cart_total_data->agent_info) @if($cart_total_data->agent_name == -1){{$inv_data->passenger_name}} @else @if($cart_total_data->agent_info != false) {{ $cart_total_data->agent_name }} @else {{$inv_data->passenger_name}} @endif @endif @else  @endisset,Your booking with Alhijaz tours has been created in {{ $cart_data[0]->tour_name }}.Your Invoice Number is : {{ $cart_data[0]->invoice_no }}.Please find the attachment for detailed Invoice and check the below link for detailed itinerary, https://alhijaztours.net/invoice/{{ $cart_data[0]->invoice_no }}/ . Regards,Team Alhijaz Tours Ltd.</textarea>
                                        </div>
                
                                        <!--<div class="mb-3">-->
                                        <!--    <label for="attachment_Area" class="form-label">Attachment</label>-->
                                        <!--    <input type="file" class="form-control" name="attachment_Area">-->
                                        <!--</div>-->
                
                                        <div class="mb-3 text-center">
                                            <button class="btn btn-primary" type="submit">Send</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <p class="cs-foot"><b>Alhijaz Tours ltd is a acting agent on behalf of Sakeena Tours Atol Number 10941</b></p>
            </div>
          </div>
        @endforeach
    @endif
    
    <script src="{{asset('public/invoice/assets/js/jquery.min.js')}}"></script>
    <script src="{{asset('public/invoice/assets/js/jspdf.min.js')}}"></script>
    <script src="{{asset('public/invoice/assets/js/html2canvas.min.js')}}"></script>
    <script src="{{asset('public/invoice/assets/js/main.js')}}"></script>
    
    <!--Modal-->
    <script src="{{asset('public/admin_package/assets/js/vendor.min.js')}}"></script>
    
    <script>
        $("#alert_hide").fadeOut(7000);
    </script>

</body>
</html>

<?php

die();
?>

<!DOCTYPE html>
<html lang="en">
   <head>
      
      <meta name="author" content="TechyDevs">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Alhijaztours  - Travel Booking System</title>
      <!-- Favicon -->
      <link rel="icon" href="">
      <!-- Google Fonts -->
      <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&amp;display=swap" rel="stylesheet">
      <!-- Template CSS Files -->
      <link rel="stylesheet" href="https://umrahtech.com/public/assets/frontend/css/bootstrap.min.css">
      <link rel="stylesheet" href="https://umrahtech.com/public/assets/frontend/css/line-awesome.css">
      
    
     
      <link rel="stylesheet" href="https://umrahtech.com/public/assets/frontend/css/style.css">
     
   </head>
   <style>
          body{
      font-family: "Roboto", sans-serif !important;
      }
     
      .title-vochure-top .la-check-circle{
      font-size: 100px;
      color: #2e97c0;
      }
      .title-vochure{
      padding-left: 15px;
      padding-top: 15px;
      }
      .title-vochure h1{
      margin: 0;
      padding: 0;
      color: #ae8c32;
      }
      .title-vochure p{
      margin: 0;
      color: #fff;
      font-size: 24px;
      }
      .title-vochure-top .w-32{
      width:120px;
      }
      .vochure-header-border{
      border-bottom: 3px solid #ae8c32
      padding: 15px 
      }
      .vochure-header-border .logo img{
        width: 100%;
    margin-top: 30px;
      }
      .vochure-detail-section{
      border: 1px solid #ddd;
      }
      .v-heading-top{
      
     padding: 5px 0;
    color: #020202;
    text-transform: capitalize;
    border: none;
    border-bottom: 2px solid #ae8c32;
      }
      .v-heading-icon-title{
      padding-top: 3px;
      }
      .v-heading-icon img{
      max-width: 75px;
      padding: 0 15px;
      }
      .v-heading-icon-title h3{
      border-bottom: 2px solid #ae8c32;
      color: #ae8c32;
      }
      .v-section-info{
           padding:  10px 15px;
      }
      .sidebar .v-section-info {
         padding: 5px 10px;
          border: 1px solid #ae8c32;
        margin-top: 9px;
      }
      .vochure-content .list-items-2{
      border: 1px solid #ddd;
      padding: 10px;
      }
      .vochure-content .list-items-5{
      border: 1px solid #ddd;
      padding: 10px;
      }
      .vochure-content button{
      background-color: #ae8c32;
      color: white;
      font-weight: 500;
      border-radius: 25px;
      }
      .vochure-content .list-items-5 p{
      display: inline;
      }
      .vochure-content  .col-sm-4 > ul.list-items.list-notice.clearfix {
      background-color: #efefef;
      border:none;
      }
      .vochure-content .notice{
      padding: 20px;
      font-weight: 500;
      line-height: 1.7;
      }
      .vochure-content .thank-you-section h3{
      margin-top: 2.3em;
      color:#ae8c32;
      font-weight: 300;
      } 
      .vochure-content .thank-you-section button{
      background-color: #ae8c32;
      color: white;
      font-weight: 600;
      border-radius: 25px;
      padding: 8px;
      width: 225px;
      font-size: 16px;
      margin-bottom: 25px;
      } 
      .vochure-content .vochure-detail-section .v-heading > h2{
      padding: 10px;
      padding-left: 5%;
      padding: 10px;
      padding-left: 5%;
      }
      .vochure-content .list-items-2 li {
      display: -webkit-flex;
      display: -ms-flex;
      display: flex;
      -ms-flex-align: center;
      align-items: center;
      -ms-flex-pack: justify;
      justify-content: space-between;
      }
      .vochure-content .grand-total{
      padding: 38px;
      padding-left: 30%;
      font-size: 30px;
      }
      .vochure-content .notice{
      border: none;
      font-size: 14px;
      }
      .vochure-sidebar-title h3{
      background-color: #ae8c32;
      color: #fff;
      padding: 9px 15px;
      text-transform: capitalize;
      }
      .f-20{
      font-size:20px;
      }
      .list-items li {
      margin-bottom: 0;
      }
      .list-items-3 li span{
      width: 40%;
      /* width: 250px; */
      }
      .list-items-3 li{
      justify-content: start;
      word-break: break-word;
      }
      .la-headset{
      line-height: 2;
      }
      .icon-layout-3 .info-icon{
      background-color: #ff0000;
      }
      .table td, .table th {
      padding: 5px;
      }
      @media(max-width: 991px) {
      .title-vochure p {
      font-size: 14px;
      }
      .title-vochure h1 {
      font-size: 20px; 
      }
      .vochure-header-border .logo img {
      width: 85px;
      }
      .title-vochure-top .la-check-circle {
      font-size: 60px;
      }
      .title-vochure {
      padding-top: 5px;
      }
      }
      @media (max-width: 575.98px){
      .vochure-header-border .logo,
      .vochure-header-border .logo a
      {
      width: 100%;
      text-align: center;
      padding-bottom: 10px;
      }
      .list-items-3 li span{
      width: 100%;
      }
      .list-items-3 li{
      display: block;
      }
      
      .v-heading-icon-title h3 {
      font-size: 20px;
      }
      .v-heading-icon-title h2 {
      font-size: 22px;
      }
      .v-heading-icon-title{
      padding-top: 10px;
      }
      }
      .la-check-circle {
      /*color: #ffffff;*/
      background: none;
      }
      body{
      font-size: 14px;
      }
      .additionalServices_box {
      border: solid 1px cornflowerblue;
      padding: 10px;
      }
      .voucher-modal .modal-content{
      border-radius: 0px;
      }
      .voucher-modal .modal-footer{
      border-top: 0px;
      }
      .table{
      font-size: 12px;
      margin-bottom: 0;
      }
      .otp-top .btn{
      background: #113669;
      color: #fff;
      font-size: 12px;
      padding: 4px 10px;  
      }
      .otp-top .btn2{
      background: #068a62;
      }
      .itenery-ul{
        padding-left: 15px;
        padding-top: 15px;
        list-style-type: none;
      }
      .itenery-ul h4{
        font-size:20px;
      }
      .vochure-header {
        background-image:url("{{asset('public/admin_package/frontend/images/bg-vochure.jpg')}}");
      }
      .sidebar .v-heading-icon{
              border: none;
             border-bottom: 2px solid #ae8c32;
             margin-bottom: 10px;
      }
      .total-amout {
          font-size: 18px;
    background: #ae8c32;
    padding: 5px 10px;
    color: #fff !important;
    margin-top: 22px;
      }
   </style>
   <body>
      <!-- start cssload-loader -->
      <div class="preloader" id="preloader">
         <div class="loader">
            <svg class="spinner" viewBox="0 0 50 50">
               <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle>
            </svg>
         </div>
      </div>
      <!-- end cssload-loader -->
      <!-- ================================
         START MODAL AREA
         ================================= -->
    
      <!-- ================================
         END MODAL AREA
         ================================= -->
      <script>
         localStorage.setItem('total_amount', 10933.17);
      </script>
      <!--End PHP-->
      <div class="vochure-header">
         <div class="container">
            <div class="vochure-header-border">
               <div class="row">
                  <div class="col-sm-4">
                     <div class="logo">
                        <a href="#"><img src="{{ asset('public/admin_package/frontend/images/logo.png') }}"  alt="logo"></a>
                     </div>
                  </div>
                  <div class="col-sm-8">
                     <div class="title-vochure-top float-right">
                        <div class="float-left text-right">
                           <img class="w-32" src="{{asset('public/admin_package/frontend/images/confirm.png') }}" alt="Booking Confirm">
                        </div>
                        <div class="title-vochure float-left">
                           <h1>Booking Confirmation</h1>
                           <p>Thanks for Booking with Alhijaz Tours</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- Button trigger modal -->
<!-- Button trigger modal -->


      <div class="vochure-content">
         <div class="container">
             <h6>Inovice No:{{ $id }}</h6>
            <div class="button-group-voucher" style="display: flex; justify-content: flex-end;">
               <div class="text-right mt-3 mr-2">
                  <button type="submit" class="btn btn-secondary" onclick="window.print()">Print  Voucher </button>
                  <button type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModal">Make Payment </button>
               </div>
             
               
            </div>
            <div class="row">
                <div class="col-md-12">
                    @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <strong>{{ session('error') }}</strong>
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    @endif
                    
                     @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                      <strong>{{ session('success') }}</strong>
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    @endif
                </div>
               <div class="col-md-8 col-sm-12">
                     @if(isset($cart_data))
                        @foreach($cart_data as $cart_res)
                  <section class="vochure-detail-section mt-3">
                     <div class="v-heading-icon v-heading-top clearfix">
                        <div class="float-left">
                           <img src="{{asset('public/admin_package/frontend/images/icon-tour.png') }}">
                        </div>
                        <div class="v-heading-icon-title float-left">
                           <h2>{{ $cart_res->tour_name }}</h2>
                        </div>
                     </div>
                    
                     
                     
                      
                     <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                            <img src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                        </div>
                        <div class="v-heading-icon-title float-left">
                            <h3>Tour Information</h3>
                      </div>
                    </div> 
                     
                     
                     <div class="clearfix v-section-info">
                        <ul class="list-items list-items-3 list-items-4  clearfix" >
                           <li>
                              <span class="text-black font-weight-bold">Tour Name:</span>
                              <p class="f-20 text-black font-weight-bold" id="makkah_booking_status">{{ $cart_res->tour_name }}</p>
                           </li>
                          
                           <li><span class="text-black font-weight-bold">Adults:</span>{{ $cart_res->adults }} </li>
                           <li><span class="text-black font-weight-bold">Children:</span>{{ $cart_res->childs }}</li>
                           <li><span class="text-black font-weight-bold">Price per person :</span>{{ $currency_Symbol->currency_symbol }}{{ $cart_res->sigle_price }}</li>
                            @if(isset($iternery_array))
                                @foreach($iternery_array as $itenry_res)
                                    @if($itenry_res[0]->id == $cart_res->tour_id)
                                                           
                           
                           <li><span class="text-black font-weight-bold">Duration:</span></li>
                           
                                    @endif
                           
                               @endforeach
                          @endif
                         
                        </ul>
                     </div>
                     
                     <div class="v-heading-icon clearfix mt-3">
                        <div class="float-left">
                           <img src="https://umrahtech.com/public/assets/frontend/images/Icons/booking-details.png">
                        </div>
                        <div class="v-heading-icon-title float-left">
                            <h3>Day By Day itenery</h3>
                      </div>
                    </div>  
                    
                     @if(isset($iternery_array))
                                @foreach($iternery_array as $itenry_res)
                                
                                    @if($itenry_res[0]->tour_id == $cart_res->tour_id)
                                    
                                    @php
                                        $iternerys_data = json_decode($itenry_res[0]->Itinerary_details);
                                        $iternerys_data1 = json_decode($itenry_res[0]->tour_itinerary_details_1);
                                
                                    @endphp
                  
                   
                    <ul class="itenery-ul">
                         @if(isset($iternerys_data))
                            @foreach($iternerys_data as $itern_data_res)
                        <li>
                            <h4>{{ $itern_data_res->Itinerary_title }} : {{ $itern_data_res->Itinerary_city }} </h4>
                            <p>{{ $itern_data_res->Itinerary_content }}</p>
                        </li>
                            @endforeach
                        @endif
                        @if(isset($iternerys_data1))
                            @foreach($iternerys_data1 as $itern_data_res)
                        <li>
                            <h4>{{ $itern_data_res->more_Itinerary_title }} : {{ $itern_data_res->more_Itinerary_city }} </h4>
                            <p>{{ $itern_data_res->more_Itinerary_content }}</p>
                        </li>
                         @endforeach
                        @endif
                    </ul>
                
                                         @endif
                               @endforeach
                         @endif
            
                
                 
                  </section>
                        @endforeach
                    @endif
                  
                  <!--apply for umrah visa-->
               </div>
               <!--Sidrbar start-->
               
           
               <div class="col-md-4 col-sm-12 sidbar">
                  <div class="v-heading-icon clearfix mt-3" >
                     <div class="float-left">
                        <img src="{{asset('public/admin_package/frontend/images/lead.png') }}">
                     </div>
                     <div class="v-heading-icon-title float-left" style="">
                        <h3>Lead Passenger Details</h3>
                     </div>
                  </div>
                  <div class="clearfix v-section-info" style="border: 1px solid #ddd;">
                     <ul class="list-items list-items-3 list-items-4  clearfix" >
                        <li>
                           <span class="text-black font-weight-bold">Passport No:</span> 
                           <p class="f-20 text-black font-weight-bold">{{ $passenger_Det[0]->passport_no }}</p>
                        </li>
                        <li><span class="text-black font-weight-bold">Nationality:</span>{{ $passenger_Det[0]->Nationality }}</li>
                        <li><span class="text-black font-weight-bold">Full Name:</span>{{ $passenger_Det[0]->name." ".$passenger_Det[0]->lname }}</li>
                        <li><span class="text-black font-weight-bold">Gender:</span>
                          {{ $passenger_Det[0]->gender }}
                        </li>
                      
                        <li class="d-block">
                           <div class="row">
                              <div class="col-sm-5">
                                 <span class="text-black font-weight-bold">Phone Number:</span>
                              </div>
                              <div class="col-sm-7">
                                 {{ $passenger_Det[0]->phone }}
                                 
                              </div>
                           </div>
                        </li>
                        
                        <li class="d-block">
                           <div class="row">
                              <div class="col-sm-5">
                                 <span class="text-black font-weight-bold">Email:</span>
                              </div>
                              <div class="col-sm-7">
                                {{ $passenger_Det[0]->email }}
                                 
                              </div>
                           </div>
                        </li>
                     </ul>
                  </div>
                 
                  <!-- end icon-box -->
                  
                    <div class="v-heading-icon clearfix mt-3" >
                     <div class="float-left">
                        <img src="{{asset('public/admin_package/frontend/images/lead.png') }}">
                     </div>
                     <div class="v-heading-icon-title float-left" style="">
                       <h3>Payment Details</h3>
                     </div>
                  </div>
                  
                
                  <ul class="list-items list-items-2 clearfix" >
                       @if(isset($cart_data))
                       
                        @foreach($cart_data as $cart_res)
                     <li><span class="text-black font-weight-bold">{{ $cart_res->tour_name }}</span>{{ $cart_res->currency }} {{ $cart_res->price }} </li>
                      @php
                        $currency = $cart_res->currency;
                     @endphp
                       @endforeach
                       @endif
                    
                      @php 
                                    $total = 0;
                            
                        @endphp
                        @foreach($cart_data as $cart_res)
                            @php 
                               $total = $total + $cart_res->price
                            @endphp
                            
                        @endforeach
                        <li class="total-amout"><span class="text-black font-weight-bold">Total</span> {{ $currency ?? "" }} {{ $total }}</li>
                    
                  </ul>
                  
                  
                 
                    <div class="v-heading-icon clearfix mt-3" >
                     <div class="float-left">
                        <img src="{{asset('public/admin_package/frontend/images/lead.png') }}">
                     </div>
                     <div class="v-heading-icon-title float-left" style="">
                       <h3>Contact Information</h3>
                     </div>
                  </div>
                
                
                  <ul class="list-items list-items-5  clearfix">
                     <li>
                        <p class="text-black font-weight-bold">Feel free to contact us any time.</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Phone:</span>
                        <p>0121 777 2522</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Email:</span>
                        <p>info@alhijaztours.net</p>
                     </li>
                     <li>
                        <span class="text-black font-weight-bold mr-3">Address:</span>
                        <p>1a Nansen Road Sparkhill
Birmingham B11 4DR UK</p>
                     </li>
                    
                  </ul>
              
               </div>
            </div>
         </div>
      </div>
      
      
      <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Payment Information</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
           <form action="{{ URL::to('save_payments') }}" method="post" enctype= multipart/form-data>
               @csrf
          <div class="modal-body">
                  <div class="v-heading-icon clearfix mt-3" >
                     <div class="float-left">
                        <img src="{{asset('public/admin_package/frontend/images/lead.png') }}">
                     </div>
                     <div class="v-heading-icon-title float-left" style="">
                       <h3>Tour Details</h3>
                     </div>
                  </div>
                  
                
                  <ul class="list-items list-items-2 clearfix" >
                       @if(isset($cart_data))
                       
                        @foreach($cart_data as $cart_res)
                     <li><span class="text-black font-weight-bold">{{ $cart_res->tour_name }}</span>{{ $cart_res->currency }} {{ $cart_res->price }} </li>
                      @php
                        $currency = $cart_res->currency;
                     @endphp
                       @endforeach
                       @endif
                    
                      @php 
                                    $total = 0;
                            
                        @endphp
                        @foreach($cart_data as $cart_res)
                            @php 
                               $total = $total + $cart_res->price
                            @endphp
                            
                        @endforeach
                        <li class="total-amout"><span class="text-black font-weight-bold">Total</span> {{ $currency ?? "" }} {{ $total }}</li>
                    
                  </ul>
                  
           
              <div class="form-row">
                <div class="col-6">
                    <label>Transcation ID</label>
                  <input type="text" class="form-control" required name="transcation_id" placeholder="Enter Transcation ID">
                  <input type="text" class="form-control" required name="invoice_id" hidden value="{{ $id }}" placeholder="Enter Transcation ID">
                </div>
                <div class="col-6">
                     <label>Payment Amunt</label>
                  <input type="text" class="form-control" required name="payment_am" placeholder="Enter Payment Amunt">
                </div>
           
               <div class="col-6">
                   <label>Account No.</label>
                  <input type="text" class="form-control" required name="account_no" placeholder="Payment to (Account No.)">
                </div>
                <div class="col-6">
                   <label>E mail</label>
                  <input type="email" class="form-control" required name="email" value="{{ $passenger_Det[0]->email }}" placeholder="Enter Email">
                </div>
                <div class="col-12">
                    <label>Payment Voucher</label>
                  <input type="file" class="form-control " required name="voucher" placeholder="Upload Payment Voucher">
                </div>
              </div>
           
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save changes</button>
          </div>
           </form>
        </div>
      </div>
    </div>
  
      <script src="https://umrahtech.com/public/assets/frontend/js/jquery-3.4.1.min.js"></script>
      <script src="https://umrahtech.com/public/assets/frontend/js/jquery-ui.js"></script>
      <script src="https://umrahtech.com/public/assets/frontend/js/popper.min.js"></script>
      <script src="https://umrahtech.com/public/assets/frontend/js/bootstrap.min.js"></script>
      <script src="https://umrahtech.com/public/assets/frontend/js/main.js"></script>
      
   
     
  
     
    
     
      
     
     
      
   </body>
</html>