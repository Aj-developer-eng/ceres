@extends('template/frontend/includes/master')

@section('content')
     <!-- BREADCRUMB -->
     <section class="awe-parallax category-heading-section-demo h-300">
            <div class="awe-overlay"></div>
           
            </div>
        </section>
        <!-- END / HEADING PAGE -->
     
        <!-- BREADCRUMB -->

        
        <section class="product-detail">
           <h3>Al Hijaz Tours Complaints Policy & Procedures</h3>
        </section>


<!-- ================================
       START FOOTER AREA
================================= -->
@endsection
@section('scripts')
<!-- LIBRARY JS-->
@endsection