
@extends('template/frontend/includes/master')

@section('content')
<!-- ================================
    START HERO-WRAPPER AREA
================================= -->
   <section class="awe-parallax category-heading-section-demo h-300">
            <div class="awe-overlay"></div>
           
            </div>
        </section>
     <section class="checkout-section-demo">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="checkout-page__top">
                            <div class="title">
                                <h1 class="text-uppercase">Your Bookings</h1>
                            </div>
                            <span class="phone">Support Call: +1-888-8765-1234</span>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="checkout-page__sidebar">
                            <ul>
                                <li class="current"><a href="checkout-yourcart.html">Your Cart</a></li>
                                <li><a href="{{ URL::to('customer_sign_up') }}">Create Account</a></li>
                                <li><a href="checkout-complete.html">Complete order</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="checkout-page__content">
                            <div class="yourcart-content">
                                <div class="content-title">
                                    <h2><i class="awe-icon awe-icon-cart"></i>Your Bookings Details</h2>
                                </div>
                                <div class="cart-content">
                                    <table class="cart-table">
                                        <thead>
                                            <tr>
                                                <th class="product-remove">Sr</th>
                                                <th class="product-name">Tour Name</th>
                                                <th class="product-price">Adult / Children</th>
                                                <th class="product-quantity">
                                                    <div class="row">
                                                        <div class="col-md-6">Sharing</div>
                                                        <div class="col-md-6">Price</div>
                                                    </div>
                                                    
                                                </th>
                                                <th class="product-quantity">Invoice</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @if(isset($tours))
                                            @php $x =1; @endphp
                                            @foreach($tours as $tour_res)
                                            <tr>
                                                <td class="product-quantity">
                                                   {{ $x++ }}
                                                </td>
                                                <td class="product-name">
                                                    <span>{{ $tour_res->tour_name }}</span>
                                                </td>
                                                <td class="product-price">
                                                    {{ $tour_res->adults }} / {{ $tour_res->childs }}
                                                    
                                                    
                                                </td>
                                                <td class="product-quantity">
                                                   <div class="row">
                                                        <div class="col-md-6"><span class="amount">{{ $tour_res->sharingSelect }}</span></div>
                                                        <div class="col-md-6">{{ $tour_res->currency }} {{ $tour_res->price }}</div>
                                                    </div>
                                                    
                                                </td>
                                                
                                                <td class="product-quantity">
                                                    <a href="{{ URL::to('invoice/'.$tour_res->invoice_no.'') }}" target="blank">Invoice</a>
                                                </td>
                                            </tr>
                                            @endforeach
                                            @endif
                                           
                                        </tbody>
                                    </table>
                                 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<!-- start back-to-top -->
@endsection


@section('scripts')
<script>

</script>
@endsection
