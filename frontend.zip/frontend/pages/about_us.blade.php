
@extends('template/frontend/includes/master')
@section('page_title')<?php if(isset($metaInfo) && $metaInfo != ''){echo $metaInfo->pageTitle;}?>@endsection


@section('keywords')
    <meta name="keywords" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->focus_keyword;
        }
    ?>"/>
@endsection
@section('page_meta_desc')
    <meta name="description" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->meta_description;
        }
    ?>"/>
@endsection
@section('page_meta_title')
    <meta name="title" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->metaTitle;
        }
    ?>"/>
@endsection
@section('content')

<!-- ================================
    START HERO-WRAPPER AREA
================================= -->

<!-- END / HEADING PAGE -->

          <section class="awe-parallax page-heading-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class="blog-heading-content text-uppercase">
                    <h2>Home > About Us</h2>
                </div>
            </div>
        </section>
        
         <section class="about-us-section mt-5">
            <div class="container">
                 
                  <div class="row">
                      <div class="col-sm-7"> 
                       <h1>About Alhijaz Tours</h1>
                      <p>Alhijaz Tours is well known within the Hajj and Umrah industry. We have a highly experienced team who know the ins and outs of Umrah and Hajj. We have immense experience on how traveling and accommodation work within Makkah and Medinah so we can make it easier for all pilgrims. Additionally, we have an abundance of knowledge on how one needs to perform their Hajj or Umrah and what they will need to take with them on their journey. We provide all the necessary information and keep our pilgrims updated at all times to make your travels easier. Our highly experienced and well versatile team is ready to take your queries.</p></div>
                      <div class="col-sm-5"><img src="{{ asset('public/admin_package/frontend/images/img/about.png') }}" alt=""></div>  
                  </div>
                 
                  <h3 class="mt-5">Our Goals!</h3>
                  <p>Here at Alhijaz Tours we strive to provide the most desirable Hajj and Umrah packages, which are carefully crafted, by our highly experienced team to allow you to perform your religious obligations with simplicity. We take into account how tiring the journey can be so we always have a team ready to guide you and take care of everything during your travels; so you can be tension-free while visiting the divine land of Makkah & Medinah! Here at Alhijaz Tours we have been diligent in making close contacts and partnerships with highly renowned hotels which are in close proximity to the Haram in Makkah and Masjid Al Nabawi in Medina. Our professional and experienced staff members are always willing to help you to ensure that your journey remains memorable and trouble-free. Our objective of quality services and that is reflected from the commitment and experience of our team. We always feel pride in offering the Hajj and Umrah service with the best cost-effective Hajj packages and Umrah. We keep striving and working to keep expanding our operations and we are constantly improving our network in order to provide the highest level of professional services with low-cost hajj packages and low-cost Umrah packages to those wanting to visit the majestic land of Makkah & Medinah.</p>
                   <div class="row about-4">
                       <div class="col-sm-6">
                          <h3>PROFESSIONALISM</h3>
                          <p>
All our team is professional and they have years of experience to deal with all the issues. Our team treats hajj and umrah pilgrims with respect and provides them the required help whenever they need any assistance with our best umrah packages.</p>
                       </div>
                       <div class="col-sm-6">
                          <h3>COMMUNICATION</h3>
                          <p>
All our team is professional and they have years of experience to deal with all the issues. Our team treats hajj and umrah pilgrims with respect and provides them the required help whenever they need any assistance with our best umrah packages.</p>
                       </div>
                       <div class="col-sm-6">
                          <h3>KNOWLEDGE</h3>
                          <p>
Our team possesses detailed knowledge of all the procedures of Hajj and Umrah services including Visa requirements, airport immigration, transportation arrangements, accommodation, ziyaraat and others. You get all the guidance which helps you to perform hajj and umrah in their true spirit.</p>
                       </div>
                       <div class="col-sm-6">
                          <h3>TEAMWORK</h3>
                          <p>
All the people in our team work with collaboration and they are always willing to help the valuable clients to meet their expectations.</p>
                       </div>
                       
                       
                       
                   </div> 
            </div>
          
        </section>


<!-- start back-to-top -->
@endsection


@section('scripts')

@endsection
