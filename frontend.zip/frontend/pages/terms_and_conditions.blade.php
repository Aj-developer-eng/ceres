
@extends('template/frontend/includes/master')
@section('page_title')<?php if(isset($metaInfo) && $metaInfo != ''){echo $metaInfo->pageTitle;}?>@endsection


@section('keywords')
    <meta name="keywords" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->focus_keyword;
        }
    ?>"/>
@endsection
@section('page_meta_desc')
    <meta name="description" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->meta_description;
        }
    ?>"/>
@endsection
@section('page_meta_title')
    <meta name="title" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->metaTitle;
        }
    ?>"/>
@endsection
@section('content')

<!-- ================================
    START HERO-WRAPPER AREA
================================= -->

<!-- END / HEADING PAGE -->

<style>
    ul {
        list-style-type:disc;
    }
</style>

          <section class="awe-parallax page-heading-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class="blog-heading-content text-uppercase">
                    <h2>Home > Terms & Conditions</h2>
                </div>
            </div>
        </section>
        
         <section class="about-us-section mt-5">
            <div class="container">
                 
                  <div class="row">
                      <div class="col-sm-12"> 
                       <h1>Terms & Conditions</h1>
                          <p>
                                The following terms and conditions set  the rules and regulations for the use of Alhijaz  Travel and Tours's website(Alhijaztours.com). By accessing this website or using any part of it, you are agreeing to be bound by the following terms of use. If you do not wish to consent, you may not and should not access nor use Alhijaz Webite.  
                                These conditions may undergo change or alteration at any time without any given prior notice to you. If you continue to access and use Alhijaz Tours you agree to be bound by the most current version of the conditions of use. Please check these conditions from time to time to see if any changes have been made.
                          </p>
                      </div>
                  </div>
                 
                  <h3 class="mt-5">1-General Terms & Conditions</h3>
                  <ul>
                      <li>
                          <p>
                              The Customer is prohibited from copying, transferring, reusing without modifications, reusing with modifications any of the mentioned above content published in the website.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                              AlHjiaz Tours reserves all the rights of the content published on Alhjiaz Tours platform including but not limited to: Texts, Images, icons, logos, trademarks , video/audio media , links published in the platform.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                              Alhijaz Tours grants the customer a limited, non-transferable license to use this site in line with the terms and conditions. The User may only use this site to create authentic reservations or purchases and shall not use this site for any other purposes.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                              You  hereby agree that, as The Customer, shall not at any time distribute, resell, cross-sell, or permit access to the Services to any third party, permit multiple end users to access the Services using shared login credentials (i.e., a shared email address and password) and the terms contained in this Agreement.
                           </p>
                      </li>
                      
                      <li>
                          <p>
                              AlHijaz Tours reserves the right, at its sole discretion, to suspend The Customer ability to use or access the Services fully or partially at any time while The Platform inspects complaints about violating this Agreement, or for any other reason. Further, it will also have the right to terminate or restrict The Customer use of  the Services if the platform, learns  that The Customer is misusing the Services in any manner whatsoever.
                          </p>
                      </li>
                      
                       <li>
                          <p>
                              The Customer holds responsibility for the accuracy of any data, requested by the website online forms or support team, and submitted via different communications channels of online website forms, email messages, social media or direct phone calls.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                              AlHijaz Tours also retains full rights to change/ add or edit any part or whole of Terms and Conditions at its discretion.
                          </p>
                      </li>
                  </ul>
                  
                  <h3 class="mt-5">2- Hotels Service Terms & Conditions</h3>
                  <ul>
                      <li>
                          <p>
                              Through the platform, we act as a facilitator and merely provide an online platform to the User for selecting and booking a specific hotel according to their requirements. The term Hotels in this context refers to all types of accommodations including hotels, apartments, bed and breakfast stays and any other accommodations.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                             All information relating to the hotel such as the category of the hotel, images, type of room, amenities and facilities available at the hotel are provided by the Hotels. Any difference that may occur between the website pictures and actual settings of the hotel shall be raised by the customer directly to the service provider (The hotel in this case) . We shall hold no responsibility in that process of disagreement and shall not be held responsible of any liability for such discrepancies.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                              The customer is responsible for reviewing the booked transportation service details such transfer route and accuracy of number of passengers, and verifying that the service meets the schedule of other services of flights , accommodations and others.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                              Hotel Rooms that are titled “Non-Refundable” in the search results; once the said hotel or room are booked and confirmed, the full amount is charged and payment cannot be refunded back.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                             The booking voucher issued by the platform in favor of the customer is based merely on the information provided or updated by the service provider. In no circumstances should AlHijaz Tours hold any liability for the hotel’s failure to accommodate the user with a confirmed booking, the standard of service or any inconvenience in the services, or any other service related issues all at The Provider ownership (The Hotel).The service voucher acts as a legal official document which guarantees the rights of the Customer at the hotel site.
                          </p>
                      </li>
                      
                       <li>
                          <p>
                              Check-in time, check-out time, and any changes in booking timing, will be in accordance with the hotel policy & terms. Early check-in or late check-out requests are subject to change as per hotel rooms availability and the hotel may require an additional charge for such services.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                              Any additional service not mentioned on the voucher and afterward requested by the customer on service site shall be charged and paid  by the customer directly.
                          </p>
                      </li>
                  </ul>
                  
                   <h3 class="mt-5">3 -Transportation Service Terms & Conditions</h3>
                  <ul>
                      <li>
                          <p>
                              AlHijaz Tours solely provides a web based platform that links travelers and Travel service providers, none of the displayed transport services are our affiliates.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                            The booking voucher issued by the platform with regards o transportation  to the customer is mainly based on the information provided or updated by the transportation service provider (The Provider) in line with service availability.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                              The Customer acknowledges that the “additional services” is charged separately in addition to the booked transportation.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                              No booking is processed unless the customer confirms accepting the cancellation policy published with each transport service he/ she selects, it is the customer responsibility to review and carefully read each service related cancellation policy.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                             Alhijaz Tours shall not be responsible for the following (as it is The Provider Responsibility) 
                          </p>
                      </li>
                      
                       <li>
                          <p>
                              Conduct of transportation operator's employees, representatives or agents.
                          </p>
                      </li>
                      
                      <li>
                          <p>
                              The vehicle condition, seats etc. not meeting the customer's expectation or as per the description provided by the operator.
                          </p>
                      </li>
                      
                       
                      <li>
                          <p>
                              Cancellation of the trip due to any reasons.
                          </p>
                      </li>
                      
                       
                      <li>
                          <p>
                             Loss or damage of the baggage of the customer.
                          </p>
                      </li>
                      
                       
                      <li>
                          <p>
                              Should any case of the above occur, The Customer can directly contact the service provider which  shall do the necessary measures to resolve any issue faced. 
                          </p>
                      </li>
                  </ul>
                 
            </div>
          
        </section>


<!-- start back-to-top -->
@endsection


@section('scripts')

@endsection
