



<?php

   // print_r($travellanda_roomh);die();
    

//print_r($hotels_rooms);die();
?>

<style>
.preloader {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background-color: transparent !important;
    z-index: 999999999;
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
}
 #ModalLoadingSpinner {
            background: #fff;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 9999;
        }

        .ModalLoadingSpinner__content {
                 text-align: center;
                width: 700px;
                margin: 0 auto;
                position: relative;
        }

.ModalLoadingSpinner__content h3{
    text-align:center;
    font-weight: 600;
    line-height: 1.5em;
    color: #262626;
        font-size: 30px;
}  

.RoomPromotion-dropdown {
   width: 200%;
    position: absolute;
    background: #f9f9f9;
    padding-top: 15px;
    padding-bottom: 15px;
     padding-left: 15px;
    border-radius: 10px;
    z-index: 2;
    transform: scale(0);
    opacity: 0;
    border: 1px solid #ddd;
    -webkit-box-shadow: 2px 2px 22px 5px rgb(232 232 232);
    -moz-box-shadow: 2px 2px 22px 5px rgba(232,232,232,1);
    box-shadow: 2px 2px 22px 5px rgb(232 232 232);
    max-height: 200px;
    overflow-y: scroll;
}

.RoomPromotion_info:hover > .RoomPromotion-dropdown {
    display: block;
    opacity: 1;
    transform: scale(1);
    transition: all 0.5s;
}
.Supplements-dropdown {
   width: 200%;
    position: absolute;
    background: #f9f9f9;
    padding-top: 15px;
    padding-bottom: 15px;
     padding-left: 15px;
    border-radius: 10px;
    z-index: 2;
    transform: scale(0);
    opacity: 0;
    border: 1px solid #ddd;
    -webkit-box-shadow: 2px 2px 22px 5px rgb(232 232 232);
    -moz-box-shadow: 2px 2px 22px 5px rgba(232,232,232,1);
    box-shadow: 2px 2px 22px 5px rgb(232 232 232);
    max-height: 200px;
    overflow-y: scroll;
}

.Supplements_info:hover > .Supplements-dropdown {
    display: block;
    opacity: 1;
    transform: scale(1);
    transition: all 0.5s;
}


</style>

   <div class="preloader">
            <div id="ModalLoadingSpinner">
                <div class="ModalLoadingSpinner__content">
                    <img class="content-img" src="{{asset('public/admin_package/frontend/image_loader/room.gif')}}" />
                    <h3>You are almost done!</h3>
           
                </div>
            </div>
        </div>





   <!--Start CSS links for slider-->
    <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/revslider/public/assets/css/settings.css') }}">
     <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/plugins/combine/traveltour-style-custom.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/plugins/combine/style.css') }}">
       <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/include/css/page-builder.css') }}">
       
          <!--End CSS links for slider-->
@extends('template/frontend/includes/master')

@section('content')


<style>
.display
{
  display: none;
}
.form-check label.btn-success
{
   background:#198754;
   border:1px solid #198754;
}
.form-check label.btn-success svg {
  display: block;
    position: absolute;
    top: 7px;
    left: 15px;
}
.form-check label.btn-primary svg {
  display: none;
}
      html {
  scroll-behavior: smooth;
}


.hotel-nav {
  white-space: nowrap;
  background: #37474F;
  z-index:99;
}
.hotel-nav ul {
  list-style: none;
  margin: 0;
  padding: 0;
}
/* Only stick if you can fit */

.hotel-nav ul li a {
  display: block;
  padding: 0.5rem 1rem;
  color: white;
  text-decoration: none;
}
.hotel-nav ul li a.current {
  background: black;
}

.sticky {
  position: fixed;
  top: 0;
  width: 100%;
}

.sticky + .content {
  padding-top: 102px;
}
      </style>
<style>
          
          .gdlr-core-ilightbox  img{
   
   height: 240px;
   width: 100%;

}
.traveltour-item-pdlr, .gdlr-core-item-pdlr {
    padding-left: 20px;
    padding-right: 20px;
}
.gdlr-core-image-overlay {
    background-color: #000000;
    background-color: rgba(0, 0, 0, 0.6);
}
.product-tabs {
    margin-top: 0 !important;
} 
.room-type-table thead th,
.room-type-table tbody td {
  
    border-bottom: 2px solid #d2b254;
}
.room-type-table tbody td.room-type .room-thumb {
    width: 270px;
    margin-right: 10px;
}
.room-type-table .room-type {
    width: 1%;
    max-width: 270px;
    padding-right: 30px;
}
.detail-sidebar {
    margin-top: 200%;
}
.room-type-table tbody td.room-type .room-thumb {
    width: 270px;
    margin-right: 10px;
}
.room-type-table .room-type {
    width: 1%;
    max-width: 270px;
    padding-right: 30px;
}
.detail-sidebar {
    margin-top: 200%;
}
.room-type-table .form-check .fa-check{
    position: absolute;
    top: 6px;
    left: 30px;
}
/*.start_body*/
/*{*/
/*    border-bottom: 2px solid #006e3b;*/
/*}*/
.disable_border
{
    border:none !important;
}
.owl-item
{
    width: 120px !important;
}
.owl-carousel
{
  width: 800px !important;   
}
       </style>
 <?php
 
 
 $hotel_beds_code=Session::get('hotel_beds_code');
 $hotel_beds_name=Session::get('hotel_beds_name');
 $room_search=Session()->get('room_searching');
 $count_p=Session()->get('room_searching');
  $travellanda_currency=Session::get('travellanda_currency');
//  $room_search=$room_search[0]->Room;
//  print_r($hotel_beds_name);die();
$hotel_beds_latitude=Session::get('hotel_beds_latitude');
$hotel_beds_longitude=Session::get('hotel_beds_longitude');
 $adult_count = Session::get('adult');
  $child_searching = Session::get('child_searching');
                                        $in = Session::get('newstart');
                                        $out = Session::get('newend');
                                        $webbeds_hotel_name = Session::get('webbed_hotel_name');
                                        $webbed_hotel_currency = Session::get('$webbed_hotel_currency');
                                        
                                        
                                        $hotel_res=Session::get('hotels_checkavailability');
                                        
            // print_r($room_search);
            // die;
                                      
?>
        
        
        
     @if(isset($hotel_res) && isset($hotels_rooms))
   
        <!-- HEADING PAGE -->
         
        <section class="awe-parallax category-heading-section-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class=" category-heading-content__2 text-uppercase">
                    <!-- BREADCRUMB -->
                   
                    <!-- BREADCRUMB -->
                    <div class="find">
                       
                         @include('template/frontend/includes/modify_search') 
                    </div>
                </div>
            </div>
        </section>
        <!-- END / HEADING PAGE -->

    <!-- BREADCRUMB -->
        <div class="container">
            <div class="breadcrumb">
            <ul>
                <li><a href="#">Home</a></li>
                <li><span>{{$hotel_res->property_name ?? ""}}</span></li>
                <li><span>{{$hotel_res->property_city ?? ''}}, {{$hotel_res->property_country ?? ''}}</span></li>
            </ul>
        </div>
        </div>
        <!-- BREADCRUMB -->
                                      
                                       
          <section class="hotel-images-section ">
             
            <div class="gdlr-core-pbf-element">
                <div class="gdlr-core-gallery-item gdlr-core-item-pdb clearfix  gdlr-core-gallery-item-style-grid-no-space gdlr-core-item-pdlr ">
                    <div class="gdlr-core-gallery-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">
                       <div class="container">
                       <div class="row">
                           <div class="col-md-4" style="padding-right: 0%;">
                                @if(isset($image))
                           
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15" style="width: 100% !important;">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{$image[0]}}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 100% !important;"  src="{{$image[0]}}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                        @endif
                           </div>
                           <div class="col-md-8" style="padding-left: 0%;">
                                @if(isset($rooms_img_gallary))
                                <?php
                                
                                $img=json_decode($rooms_img_gallary[0]->img_name);
                                
                                ?>
                           <?php 
                           $count=1;
                           ?>
                           @if(isset($img))
                            @foreach($img as $key => $imgs)
                            @if($key > 0)
                            @if($count <= 9)
                       
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="https://alhijaztours.net/public/uploads/more_room_images/{{$imgs}}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 160px;padding: 3px;" src="https://alhijaztours.net/public/uploads/more_room_images/{{$imgs}}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                        @endif
                        @endif
                        <?php 
                           $count++;
                           ?>
                         @endforeach
                    @endif
                     @endif
                           </div>
                       </div>
                          </div>
                  
                    </div>
                </div>
            </div>
        </section>
        
  
  
    <nav class="navbar navbar-expand-lg navbar-dark hotel-nav" id="hotel-nav" >
        <div class="container">    
          <ul class="navbar-nav">
         <li><a href="#section-1">Overview</a></li>
        <li><a href="#section-2">Rooms</a></li>
        <li><a href="#section-3">Facilities</a></li>
        <li><a href="#section-4">Near By Places</a></li>
        <li><a href="#section-5">Location</a></li>

        <li><a href="#section-7">Review &amp; rating</a></li>
       
          </ul>
</div>

    </nav>

    
  

<main>
    <div class="container mt-5">   
  <section id="section-1">
  
    <div class="row">
                    <div class="col-md-8">
                        <div class="product-detail__info">
                            <div class="product-title">
                                <h2>{{$hotel_res->property_name ?? ""}}</h2>
                                <div class="hotel-star">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                            </div>
                           
                            <div class="product-address">
                                <span><svg style="width: 13px;display: inline;margin-right: 7px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--! Font Awesome Pro 6.1.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M168.3 499.2C116.1 435 0 279.4 0 192C0 85.96 85.96 0 192 0C298 0 384 85.96 384 192C384 279.4 267 435 215.7 499.2C203.4 514.5 180.6 514.5 168.3 499.2H168.3zM192 256C227.3 256 256 227.3 256 192C256 156.7 227.3 128 192 128C156.7 128 128 156.7 128 192C128 227.3 156.7 256 192 256z"/></svg>{{$hotel_res->property_address ?? ''}}</span>
                            </div>
                            <!--<div class="product-email">-->
                            <!--    <i class="fa fa-envelope"></i>-->
                            <!--    {{$hotel_bed->minRate ?? ""}} {{$hotel_bed->currency ?? ""}}-->
                            <!--</div>-->

                           

                            <div class="product-descriptions">
                                <p>{{$hotel_res->property_desc ?? ''}}</p>
                            </div>
                            
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                         <!--<div class="rating-trip-reviews">-->
                         <!--       <div class="item good">-->
                         <!--          Hotel Rating  <span class="count">{{$hotel_bed->categoryName ?? ""}}</span>-->
                                    
                         <!--       </div>-->
                               
                         <!--   </div>-->
                        <div class="product-detail__gallery" style="margin-top: 24%;text-align: -webkit-center;">
                            <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map" ><img style="border: 4px solid #d2b254;" src="https://cdn6.agoda.net/images/MAPS-1214/default/property-map-entry-1.svg" alt=""></a> 
                           
                            
                            
                        </div>
                    </div>
                
   </div>
  </section>
  <input type="hidden" value="0" id="total_rooms_selected" />
  <section id="section-2">
       <h5>Room Details</h5>
        <form id="roomsform" action="{{URL::to('')}}/getbooking/hotels" method="post">
                                @csrf
                                
        
      <div class="row">
          <div class="col-sm-10">
              <table class="room-type-table">
                                        <thead>
                                            <tr>
                                                <th class="room-type">Room Type</th>
                                                 <th class="room-people">Room Details</th>
                                               
                                                <!--<th class="room-price">Room Selected</th>-->
                                            </tr>
                                        </thead>
                                        <tbody class="hotel_append_div hotel_append_carousal">
                            
                                
                                <?php
                                  $room_counter=1;
                                  $room_counters=1;
                                  $more_room_counter=20;
                                   $count_price=1;
                                 foreach($hotels_rooms as $Rooms)
                                        {
                                           
                                           
                                        
                                       

                                 ?>
                                
                                
                                
                                 <?php
                                 $room_quantity=1;
                                         
         
              
              
                   
           ?>
                                 
  








                                 
                                            <tr>
                                                <td class="room-type">
                                                    <div class="room-thumb">
                                 <div class="product-slider-wrapper" style="margin-top: 23px;margin-bottom: 31px;">
                                <div class="product-slider">
                                                        
                                 
                                  <img src="https://alhijaztours.net/public/images/rooms/roomGallery/{{$Rooms->room_img ?? ''}}" alt="">
                                 
                                       
                              
                                   
                                </div>
                               
                            </div>
                                  
                                      
                                   
                                    <h7>{{$Rooms->room_type_id ?? ""}} - 
                                                            <?php
                                                            if(isset($Rooms->rooms_on_rq))
                                                            {
                                                                if($Rooms->rooms_on_rq == 1)
                                                                {
                                                                  echo 'On Request';   
                                                                }
                                                                else
                                                                  {
                                                                   echo '';   
                                                                  }
                                                            }
                                                            
                                                            ?>
                                                        </h7><br>
                                    
                                    <ul>
                                    <?php
                                    
                                    if($Rooms->amenitites != null)
                                    {
                                        $amenitites=json_decode($Rooms->amenitites);
                                        if(isset($amenitites))
                                        {
                                        foreach($amenitites as $amenitites_data)
                                        {
 
                                        ?>
                                         <li>{{$amenitites_data ?? ''}}</li>
                                        <?php
                                        }
                                        }
                                        else
                                    {
                                        echo 'NO Amenities';
                                    }
                                        
                                    }
                                    
                                    
                                    
                                    ?>
                                   </ul>
                                   
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                        
                                                </td>
                                                
                                                <td>
                                                    <table style="width:100%">
                                                       
                                                            <th style="width: 25%;">Meal Type</th>
                                                             <!--<th style="width: 28%;">Room Capacity</th>-->
                                                             <th style="width: 40%;">Room Capacity</th>
                                                              <th style="width: 25%;">Price/From</th>
                                                               <th></th>
                                                        
                                                        <tbody class="start_body">
                                                            
                                                            <?php
                                                            
                                                            $select=0;
                                                            
                                                            ?>
                                                        
                                                        
                                                     
                                                     
                                                     
                                                    <tr>
                                                     <td class="disable_border">
                                                          
                                                       
                                                        <p style="font-weight: 700;">{{$Rooms->room_meal_type ?? ""}}</p>
                                                        
                                                     </td>
   
                                                            <td class="disable_border">
                                                    <i style="font-size: 14px;" class="awe-icon awe-icon-users"></i>
                                               {{$adult_count}} Adults, {{$count_p}} Room, {{$child_searching}} Children
                                                   
                                     
                                                </td>
                                               
                                                       
                                                    <td class="disable_border">
 
                                                        <p style="font-size: 19px;color:#d2b254;" > 
                                                            <?php
                                                            if($Rooms->price_all_days_wi_markup != null)
                                                            {
                                                                $price=$Rooms->price_all_days_wi_markup;
                                                                 if($hotel_res->currency_symbol == '﷼')
                                                                    {
                                                                    $currency='SAR';
                                                                    }
                                                                    else
                                                                    {
                                                                    $currency=$hotels->currency_symbol;
                                                                    }
                                                                $exchange_price=all_currency_manage($currency,$price);
                                                    
                                                                $room_price=$exchange_price;
                                                            ?>
                                                             <h7 class="exchange_price1_1_{{$room_counter}}" style="display:none;">{{$room_price}}</h7>
                                                             <p><h7 class="exchange_rate_country_price_{{$room_counter}}"> </h7>/Per Night</p>
                                                             
                                                            <?php
                                                            }
                                                            else
                                                            {
                                                                
                                                                 $price=$Rooms->weekdays_price_wi_markup;
                                                                if($hotel_res->currency_symbol == '﷼')
                                                                    {
                                                                    $currency='SAR';
                                                                    }
                                                                    else
                                                                    {
                                                                    $currency=$hotels->currency_symbol;
                                                                    }
                                                                $exchange_price=all_currency_manage($currency,$price);
                                                                $room_price=$exchange_price;
                                                            ?>
                                                            <h7 class="exchange_price1_1_{{$room_counter}}" style="display:none;">{{$room_price}}</h7>
                                                             <p><h7 class="exchange_rate_country_price_{{$room_counter}}"> </h7>/Per Night</p>
                                                            
                                                            <?php
                                                            
                                                            }
                                                            ?>
                                                            </p>
                                      
                                                       
                                                       
                                                       
                                                       <?php
                           
                                                       $startTimeStamp = strtotime($in);                                   
                                                        $endTimeStamp = strtotime($out);                                     
                            
                                                        $timeDiff = abs($endTimeStamp - $startTimeStamp);                            
                            
                                                        $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  
                            
                            
                                                        $numberDays = intval($numberDays);                                           

                                                                                        

                                                            
                           
                           
                                                            ?>
                                                           
                                                            
                                                            
                                                            
                                                            
                                                            
                                                     </td>
                                                     

                                                   

                                                     </tr>            
                                                                
                                                    <tr>
                                                        <td class="disable_border" colspan="12">
                                                            <table style="width:100%;">
                                                       <thead>
                                                           <tr>
                                                               <th>
                                                               Check Availability
                                                           </th>
                                                           </tr>
                                                       </thead>
                                                       <tbody>
<tr>
<td>
    
   
<div class="owl-carousel" style="text-align:center">
 <!--<div class="row" style="text-align:center;">-->
<?php
$exchange_price_weekdays='';
$exchange_price_weekends='';
$exchange_price_for_all_days='';
$st_date = $in;
$st_date = date('Y-m-d', strtotime('+1 day', strtotime($st_date)));
$ed_date = $out;

// $dateMonthYearArr = array();
$st_dateTS = strtotime($st_date);
$ed_dateTS = strtotime($ed_date);
$grand_total_weekdays=0;
$grand_total_weekends=0;
$grand_total_price_all_days=0;

  $count_price1=$count_price;
for ($currentDateTS = $st_dateTS; $currentDateTS <= $ed_dateTS; $currentDateTS += (60 * 60 * 24)) {
// use date() and $currentDateTS to format the dates in between
$currentDateStr = date("Y-m-d",$currentDateTS);
$currentDateStr1 = date("l",$currentDateTS);


$date_formates=date("D,M d",$currentDateTS);

$dateMonthYearArr[] = $currentDateStr;
?>
 
<div class="item hotel_append_div_carosal" style="border: 2px solid #d2b254;border-radius: 45px;margin-right: 2px;padding: 4px;">

<?php
print $date_formates;
echo '<br>';
// print $currentDateStr;
// echo '<br>';
// print $currentDateStr1;
// echo '<br>';

if(isset($Rooms->weekdays))
{
    $weekdays=json_decode($Rooms->weekdays);
    if(isset($weekdays))
    {
    foreach($weekdays as $weekday)
    {
        if($weekday == $currentDateStr1)
        {
            if($currentDateStr1 == 'Monday' || $currentDateStr1 == 'Tuesday' || $currentDateStr1 == 'Wednesday'|| $currentDateStr1 == 'Thursday'|| $currentDateStr1 == 'Friday'|| $currentDateStr1 == 'Saturday'|| $currentDateStr1 == 'Sunday')
            {
                 $price=$Rooms->weekdays_price_wi_markup;
                                                    if($hotel_res->currency_symbol == '﷼')
                                                                    {
                                                                    $currency='SAR';
                                                                    }
                                                                    else
                                                                    {
                                                                    $currency=$hotels->currency_symbol;
                                                                    }
                 $exchange_price=all_currency_manage($currency,$price);
                 $exchange_price_weekdays=number_format($exchange_price,2);
                  $curr='GBP';
                 ?>
                  <p><?php print_r($curr .' '.$exchange_price); ?></p>
                 
                 <?php
                 
               
            
             $grand_total_weekdays=number_format($grand_total_weekdays + $exchange_price,2);
            }
        }
    }

}
}


if(isset($Rooms->weekends))
{
    $weekends=json_decode($Rooms->weekends);
     if(isset($weekends))
    {
    foreach($weekends as $weekend)
    {
        if($weekend == $currentDateStr1)
        {
             if($currentDateStr1 == 'Monday' || $currentDateStr1 == 'Tuesday' || $currentDateStr1 == 'Wednesday'|| $currentDateStr1 == 'Thursday'|| $currentDateStr1 == 'Friday'|| $currentDateStr1 == 'Saturday'|| $currentDateStr1 == 'Sunday')
            {
             $price=$Rooms->weekends_price_wi_markup;
             
             if($hotel_res->currency_symbol == '﷼')
                                                                    {
                                                                    $currency='SAR';
                                                                    }
                                                                    else
                                                                    {
                                                                    $currency=$hotels->currency_symbol;
                                                                    }
                 
                 $exchange_price=all_currency_manage($currency,$price);
                 $exchange_price_weekends=number_format($exchange_price,2);
                $curr='GBP';
                ?>
                  <p><?php print_r($curr .' '.$exchange_price); ?></p>
                <?php
            
              $grand_total_weekends=number_format($grand_total_weekends + $exchange_price,2);
        }
        }
    }
    }
}

if(isset($Rooms->price_week_type))
{
    if($Rooms->price_week_type == 'for_all_days')
    {
    $price_all_days=$Rooms->price_all_days_wi_markup;
    $all_days=array(
        '0'=>'Monday',
        '1'=>'Tuesday',
        '2'=>'Wednesday',
        '3'=>'Thursday',
        '4'=>'Friday',
        '5'=>'Saturday',
        '6'=>'Sunday',
        );
     if(isset($price_all_days))
    {
       
    foreach($all_days as $all_day)
    {
        if($all_day == $currentDateStr1)
        {
             if($currentDateStr1 == 'Monday' || $currentDateStr1 == 'Tuesday' || $currentDateStr1 == 'Wednesday'|| $currentDateStr1 == 'Thursday'|| $currentDateStr1 == 'Friday'|| $currentDateStr1 == 'Saturday'|| $currentDateStr1 == 'Sunday')
            {
           $price=$Rooms->price_all_days_wi_markup;
           
                 if($hotel_res->currency_symbol == '﷼')
                                                                    {
                                                                    $currency='SAR';
                                                                    }
                                                                    else
                                                                    {
                                                                    $currency=$hotels->currency_symbol;
                                                                    }
                 $exchange_price=all_currency_manage($currency,$price);
                 $exchange_price_for_all_days=number_format($exchange_price,2);
                $curr='GBP';
                ?>
                 <p class="exchange_price1_1_hotel_{{$count_price1}}" style="display:none;" ><?php print_r($exchange_price_for_all_days); ?></p>
                 <p class="exchange_rate_country_price_hotel_{{$count_price1}}"></p>
                <?php
             
              $grand_total_price_all_days=$grand_total_price_all_days + $exchange_price;
        }
        }
        
    }
    }
    }
}


?>
</div>
<?php
$big_grand_all_days_week=number_format($grand_total_price_all_days,2);
$big_grand=number_format($grand_total_weekends + $grand_total_weekdays,2);
$count_price1=$count_price1+1;

}

?>



                                                   
 </div>
 
 
  <?php
                                                     if(isset($Rooms->cancellation_details))
                                                     {
                                                       $cancellation_details=json_decode($Rooms->cancellation_details); 
                                                     }
                                                     else
                                                     {
                                                        $cancellation_details=''; 
                                                     }
                                                   
                                                   
                                                     
                                                     $room_data=array(
                                                         
                                                         'rooms_id'=>$Rooms->id,
                                                         'rooms_name'=>$Rooms->room_type_id,
                                                         'room_price'=>$room_price,
                                                         'rooms_type'=>'outer',
                                                         'rooms_type_id'=>$Rooms->room_type_cat,
                                                         'rooms_type_name'=>$Rooms->room_type_name,
                                                         'rooms_supplier'=>$Rooms->room_supplier_name,
                                                         'rooms_name'=>$Rooms->room_type_id,
                                                         'rooms_on_request'=>$Rooms->rooms_on_rq ?? '',
                                                         'room_view'=>$Rooms->room_view,
                                                         'rooms_meal_type'=>$Rooms->room_meal_type,
                                                         'currency'=>'GBP',
                                                         'price_week_type'=>$Rooms->price_week_type ?? '',
                                                         'grand_total_price_week_weekend'=>$big_grand ?? '',
                                                         'grand_total_price_all_days'=>$big_grand_all_days_week ?? '',
                                                          'weekdays'=>$Rooms->weekdays ?? '',
                                                         'exchange_price_weekdays'=>$exchange_price_weekdays,
                                                         'weekends'=>$Rooms->weekends ?? '',
                                                         'exchange_price_weekends'=>$exchange_price_weekends,
                                                         'exchange_price_for_all_days'=>$exchange_price_for_all_days,
                                                         'rooms_quantity'=>$room_search,
                                                         'rooms_adults'=>$Rooms->max_adults,
                                                         'rooms_children'=>$Rooms->max_child,
                                                         'cancellation_policy'=>array(
                                                             'concellation_policy'=>$cancellation_details->concellation_policy ?? '',
                                                             'guests_pay_days'=>$cancellation_details->guests_pay_days ?? '',
                                                             'guests_pay'=>$cancellation_details->guests_pay ?? '',
                                                             'prepaymentpolicy'=>$cancellation_details->prepaymentpolicy ?? '',
                                                             
                                                             ),
                                                             'additional_meal'=>array(
                                                             
                                                             'additional_meal_type'=>$Rooms->additional_meal_type ?? '',
                                                             'additional_meal_type_charges'=>$Rooms->additional_meal_type_charges ?? '',
                                                            
                                                             
                                                             ),
                                                         
                                                         );
                                                     
                                                     ?>
                                                    
                                                       
                                                       
                                                  
                                                       <div class="form-check" style="width: 300px;float:right;">
                                                            <span style="font-weight:bold;"> Price For  <?php echo  $numberDays; ?> Nights  </span>
                                                        <input  value='<?php print_r(json_encode($room_data));?>' data-room="{{$Rooms->room_meal_type}}" room-id="{{$Rooms->id}}" room-quantity="1" data-for="{{$Rooms->room_meal_type}}{{$room_counter}}"  data-room-type="{{$Rooms->room_type_id}}"   type="checkbox" class="form-check-input selectrooms btn-check" id="{{$Rooms->room_meal_type}}{{$room_counter}}"  autocomplete="off" name="hotels_select_room[]">
                                                        <label style="padding: 5px;position: relative;" class="btn btn-primary font-size-12px w-100 font-bold" for="{{$Rooms->room_meal_type}}{{$room_counter}}">
                                                        <p class="mb-0 text-white" style="font-size: 11px;">Select </p><p class="mb-0 text-white" style="font-size: 11px;">{{$Rooms->room_meal_type}} - 
                                                        <?php
                                                       
                                                         if($Rooms->price_week_type == 'for_week_end')
                                                         {
                                                         ?>
                                                         <?php echo 'GBP' . '  ' . $big_grand; ?>
                                                         
                                                         <?php
                                                         }
                                                         ?>
                                                         
                                                         <?php
                                                         if($Rooms->price_week_type == 'for_all_days')
                                                         {
                                                         ?>
                                                         <p class="exchange_price1_1_hotel1_{{$room_counters}}" style="display:none;">{{$big_grand_all_days_week}}</p>
                                                         <p class="exchange_rate_country_price_hotel1_{{$room_counters}}"></p>
                                                        
                                                         <?php
                                                         }
                                                         ?>
                                                        
                                                        </p>
                                                        <i class="fa-solid fa-check"></i>
                                                                          
                                                                               
                                                                        
                                                                          
                                                                          </label>
                                                                       
                                                                     </div>
 
 
 

 
</td>


                                                      
                                                   
</tr>

</tbody> 
                                                   </table>
                                                        </td>
                                                    </tr>
                                                    
                                                   

                                                    
                                                   
                                               </tbody>
                                               
                                                
                                               
                                               
                                               
                                               <?php
                                               if(!empty($Rooms->more_room_type_details))
                                               {
                                                   $more_room_type_details=json_decode($Rooms->more_room_type_details);
                                                   //print_r($more_room_type_details);
                                                  
                                                   foreach($more_room_type_details as $more_room)
                                                   {
                                                       ?>
                                                       
                                               
                                               <tbody>
                                                  
                                                            
         
                                                        
                                                        
                                                     
                                                     
                                                     
                                                    <tr>
                                                     <td class="disable_border">
                                                          
                                                       
                                                        <p style="font-weight: 700;"><?php print_r($more_room->more_room_type_name ); ?></p><br>

                                                           <p>
                                                               {{$more_room->more_room_type ?? ''}}
                                                             </p> 
                                                               
                                                               
                                                          
                                                   
                                                     </td>
                                                     
                                                            <td class="disable_border">
                                                    <i style="font-size: 14px;" class="awe-icon awe-icon-users"></i>
                                               {{$adult_count}} Adults, {{$count_p}} Room, {{$child_searching}} Children
                                                   
                                     
                                                </td>
                                               
                                                       
                                                    <td class="disable_border">
 
                                                        <p style="font-size: 19px;color:#d2b254;" > 
                                                            <?php
                                                            if(isset($more_room->price_all_days_wi_markup))
                                                            {
                                                            if($more_room->price_all_days_wi_markup != null)
                                                            {
                                                                 $price=$more_room->price_all_days_wi_markup;
                                                                $currency=$hotel_res->currency_symbol;
                                                                $exchange_price=all_currency_manage($currency,$price);
                                                                $room_price=$exchange_price;
                                                                
                                                                
                                                                
                                                            ?>
                                                             <h7> GBP {{$room_price ?? ''}}/Per Night</h7>
                                                            <?php
                                                            }
                                                            else
                                                            {
                                                                $price=$more_room->weekdays_price_wi_markup;
                                                                $currency=$hotel_res->currency_symbol;
                                                                $exchange_price=all_currency_manage($currency,$price);
                                                                $room_price=$exchange_price;
                                                            ?>
                                                             <h7> GBP {{$room_price ?? ''}}/Per Night</h7>
                                                            <?php
                                                            }
                                                            }
                                                            ?>
                                                            </p><br><br>
                                      
                                                       
                                                       
                                                       
                                                       <?php
                           
                                                       $startTimeStamp = strtotime($in);                                   
                                                        $endTimeStamp = strtotime($out);                                     
                            
                                                        $timeDiff = abs($endTimeStamp - $startTimeStamp);                            
                            
                                                        $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  
                            
                            
                                                        $numberDays = intval($numberDays);                                           

                                                                                        

                                                            
                           
                           
                                                            ?>
                                                           
                                                     </td>
                                                     
                                                     
                                                     
                                                  
                                                     </tr>            
                                                               
                                                    
                                                    
                                                    
                                                    
                                                    <tr>
                                                        <td class="disable_border" colspan="12">
                                                            <table style="width:100%;">
                                                       <thead>
                                                           <tr>
                                                               <th>
                                                               Check Availability
                                                           </th>
                                                           </tr>
                                                       </thead>
                                                       <tbody>
<tr>
<td class="disable_border">
 <div class="owl-carousel" style="text-align:center">
<?php
$more_exchange_price_weekdays='';
$more_exchange_price_weekends='';
$more_exchange_price_for_all_days='';
$st_date = $in;
$st_date = date('Y-m-d', strtotime('+1 day', strtotime($st_date)));
$ed_date = $out;

// $dateMonthYearArr = array();
$st_dateTS = strtotime($st_date);

$ed_dateTS = strtotime($ed_date);
$grand_total_weekdays=0;
$grand_total_weekends=0;
$grand_total_price_all_days=0;
for ($currentDateTS = $st_dateTS; $currentDateTS <= $ed_dateTS; $currentDateTS += (60 * 60 * 24)) {
// use date() and $currentDateTS to format the dates in between
$currentDateStr = date("Y-m-d",$currentDateTS);
$currentDateStr1 = date("l",$currentDateTS);
$dateMonthYearArr[] = $currentDateStr;

$date_formates=date("D,M d",$currentDateTS);
?>

<div class="item" style="border: 2px solid #d2b254;border-radius: 45px;margin-right: 2px;padding: 4px;">
<?php

print $date_formates;
echo '<br>';
// print $currentDateStr;
// echo '<br>';
// print $currentDateStr1;
// echo '<br>';

if(isset($more_room->more_weekdays))
{
    $weekdays=json_decode($more_room->more_weekdays);
    if(isset($weekdays))
    {
    foreach($weekdays as $weekday)
    {
        if($weekday == $currentDateStr1)
        {
            if($currentDateStr1 == 'Monday' || $currentDateStr1 == 'Tuesday' || $currentDateStr1 == 'Wednesday'|| $currentDateStr1 == 'Thursday'|| $currentDateStr1 == 'Friday'|| $currentDateStr1 == 'Saturday'|| $currentDateStr1 == 'Sunday')
            {
           $price=$more_room->weekdays_price_wi_markup;
                 $currency=$hotel_res->currency_symbol;
                 $exchange_price=all_currency_manage($currency,$price);
                 $more_exchange_price_weekdays=number_format($exchange_price,2);
                $curr='GBP';
             print_r($curr .' '.$exchange_price);
             $grand_total_weekdays=$grand_total_weekdays + $exchange_price;
            }
        }
    }

}
}


if(isset($more_room->more_weekend))
{
    $weekends=json_decode($more_room->more_weekend);
     if(isset($weekends))
    {
    foreach($weekends as $weekend)
    {
        if($weekend == $currentDateStr1)
        {
             if($currentDateStr1 == 'Monday' || $currentDateStr1 == 'Tuesday' || $currentDateStr1 == 'Wednesday'|| $currentDateStr1 == 'Thursday'|| $currentDateStr1 == 'Friday'|| $currentDateStr1 == 'Saturday'|| $currentDateStr1 == 'Sunday')
            {
           $price=$more_room->weekends_price_wi_markup;
                 $currency=$hotel_res->currency_symbol;
                 $exchange_price=all_currency_manage($currency,$price);
                   $more_exchange_price_weekends=number_format($exchange_price,2);
                  $curr='GBP';
             print_r($curr .' '.$exchange_price);
              $grand_total_weekends=$grand_total_weekends + $exchange_price;
        }
        }
    }
    }
}

if(isset($more_room->more_week_price_type))
{
    if($more_room->more_week_price_type == 'for_all_days')
    {
    $more_price_all_days=$more_room->price_all_days_wi_markup;
    $all_days=array(
        '0'=>'Monday',
        '1'=>'Tuesday',
        '2'=>'Wednesday',
        '3'=>'Thursday',
        '4'=>'Friday',
        '5'=>'Saturday',
        '6'=>'Sunday',
        );
     if(isset($more_price_all_days))
    {
    foreach($all_days as $all_day)
    {
        if($all_day == $currentDateStr1)
        {
             if($currentDateStr1 == 'Monday' || $currentDateStr1 == 'Tuesday' || $currentDateStr1 == 'Wednesday'|| $currentDateStr1 == 'Thursday'|| $currentDateStr1 == 'Friday'|| $currentDateStr1 == 'Saturday'|| $currentDateStr1 == 'Sunday')
            {
           $price=$more_room->price_all_days_wi_markup;
                 $currency=$hotel_res->currency_symbol;
                 $exchange_price=all_currency_manage($currency,$price);
                 $more_exchange_price_for_all_days=number_format($exchange_price,2);
                $curr='GBP';
             print_r($curr .' '.$exchange_price);
              $grand_total_price_all_days=$grand_total_price_all_days + $exchange_price;
        }
        }
    }
    }
    }
}




?>
</div>
<?php
}


$big_grand=number_format($grand_total_weekdays + $grand_total_weekends,2);
$big_grand_all_days=number_format($grand_total_price_all_days,2);
?>
                                                   
 </div>



<?php 
                                                                $room_data=array(
                                                         
                                                                     'rooms_id'=>$Rooms->id,
                                                                     'generate_id'=>$more_room->room_gen_id ?? '',
                                                                     'rooms_name'=>$more_room->more_room_type,
                                                                     'rooms_type'=>'more',
                                                                     'rooms_type_id'=>$more_room->more_room_type_id,
                                                                     'rooms_type_name'=>$more_room->more_room_type_name,
                                                                     'rooms_supplier'=>$more_room->more_room_supplier_name,
                                                                     'rooms_on_request'=>$more_room->more_rooms_on_rq ?? '',
                                                                     'room_view'=>$more_room->more_room_view,
                                                                     'rooms_meal_type'=>$more_room->more_room_meal_type,
                                                                     'price_week_type'=>$more_room->more_week_price_type ?? '',
                                                                     'currency'=>'GBP',
                                                                     'grand_total_price_week_weekend'=>$big_grand ?? '',
                                                                     'grand_total_price_all_days'=>$big_grand_all_days ?? '',
                                                                     'weekdays'=>$more_room->more_weekdays ?? '',
                                                                     'exchange_price_weekdays'=>$more_exchange_price_weekdays,
                                                                     'weekends'=>$more_room->more_weekend ?? '',
                                                                     'exchange_price_weekends'=>$more_exchange_price_weekends,
                                                                     'exchange_price_for_all_days'=>$more_exchange_price_for_all_days,
                                                                     'rooms_quantity'=>$room_search,
                                                                     'rooms_adults'=>$more_room->more_max_adults,
                                                                     'rooms_children'=>$more_room->more_max_childrens,
                                                                     'cancellation_policy'=>array(
                                                                         
                                                                         'concellation_policy'=>$more_room->more_concellation_policy ?? '',
                                                                         'guests_pay_days'=>$more_room->more_guests_pay_days ?? '',
                                                                         'guests_pay'=>$more_room->more_guests_pay ?? '',
                                                                         'more_prepaymentpolicy'=>$more_room->prepaymentpolicy ?? '',
                                                                         
                                                                         ),
                                                                         'additional_meal'=>array(
                                                                         
                                                                         'additional_meal_type'=>$Rooms->additional_meal_type ?? '',
                                                                         'additional_meal_type_charges'=>$Rooms->additional_meal_type_charges ?? '',
                                                                        
                                                                         
                                                                         ),
                                                                     
                                                                     );
                                                         ?>
                                                        
                                                     
                                                     
                                                    
                                                       
                                                       
                                                  
                                                       <div class="form-check" style="width: 300px;float:right;">
                                                          <span style="font-weight:bold;"> Price For  <?php echo  $numberDays; ?> Nights  </span>
                                                               
                                                                         <input  value='<?php print_r(json_encode($room_data));?>' data-room='<?php print_r($more_room->more_room_meal_type ?? ''); ?>' room-id="{{$Rooms->id}}" room-quantity="1" data-for='<?php print_r($more_room->more_room_meal_type ?? ''); ?>{{$room_counter}}'  data-room-type="{{$Rooms->room_type_id}}" room-id="{{$room_counter}}"  type="checkbox" class="form-check-input selectrooms btn-check" id="<?php print_r($more_room->more_room_meal_type ?? ''); ?>{{$more_room_counter}}"  autocomplete="off" name="hotels_select_room[]">
                                                                          <label style="padding: 5px;position: relative;" class="btn btn-primary font-size-12px w-100 font-bold" for="<?php print_r($more_room->more_room_meal_type ?? ''); ?>{{$more_room_counter}}">
                                                                        <p class="mb-0 text-white" style="font-size: 11px;">Select </p><p class="mb-0 text-white" style="font-size: 11px;"><?php print_r($more_room->more_room_meal_type ?? ''); ?> - 
                                                                         <?php
                                                                         if($more_room->more_week_price_type == 'for_week_end')
                                                                         {
                                                                         ?>
                                                                        <?php echo 'GBP' . '  ' . $big_grand; ?>
                                                                        
                                                                         <?php
                                                                         }
                                                                         ?>
                                                                         
                                                                         <?php
                                                                         if($more_room->more_week_price_type == 'for_all_days')
                                                                         {
                                                                         ?>
                                                                          <?php echo 'GBP' . '  ' . $big_grand_all_days; ?>
                                                                       
                                                                         <?php
                                                                         }
                                                                         ?>
                                                                        </p>
                                                                          <i class="fa-solid fa-check"></i>
                                                                          
                                                                               
                                                                        
                                                                          
                                                                          </label>
                                                                       
                                                                     </div>
  
 

</td>
</tr>
</tbody> 
                                                   </table>
                                                        </td>
                                                    </tr>
                                                    
                                                    
                                               </tbody>
                                               
                                               <?php
                                               $more_room_counter=$more_room_counter+1;
                                                   }
                                                   
                                               }
                                               
                                               ?>
                                                    </table>
                                                </td>
                                              
                                                
                                            </tr>
                                            
                                                
                                                    
                                           
                                          
                                           
                                            
                                            
                                            
                                            <?php

                                          
                                          $room_counter=$room_counter+1;
                                             $room_counters=$room_counters+1;
                                             
                                             $count_price=$count_price1;
                                        }
                                        
                                       
                                        
                                            ?>
                                                
                                          
                                        </tbody>
                                    </table>
              
              
          </div>
           <div class="col-sm-2">
              <div class="detail-sidebar">
                                
                 <button type="button" class="btn btn-info book_now" style="padding: 10px 0; width: 100%; background:#027806;border: 1px solid #d2b254;margin-top: 20px;color: white;">Book Now</button>
                </div> 
          </div>
    </div>   
       </form>
     
    
  </section>
  <section id="section-3">
      <div class="property-highlights">
                                <h3>Property highlights</h3>
                                <div class="property-highlights__content">
                                    <div class="row">
                                    @if(isset($hotel_facilities))
                                        @foreach($hotel_facilities as $hotel_facilities)
                                        <div class="col-md-3">
                                    <div class="item">
                                        <i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>
                                        <span>{{$hotel_facilities ?? ""}} </span>
                                    </div>
                                    </div>
                                    @endforeach
                                        @endif
                                </div>
                                </div>
                            </div>
      
 
  </section>
  <section id="section-4">
       <h5>Near By Places</h5>
   
                                        
                                            
                                             @if(isset($attractions))
                                        @foreach($attractions as $attractions)
                                        
                                                
                                                    <p><i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i> Meter Away From  {{$attractions ?? ""}}</p>
                                                
                                               
                                            
                                        
                                        @endforeach 
                                        @endif
                                            
                                            
                                        
                                       
                                   
  </section>
  <section id="section-5">
       <h3>Location</h3>
                                     <div class="col-12 col-md-12">
                             <div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=50%25&amp;height=600&amp;hl=en&amp;q=<?php print_r($hotel_res->latitude ?? ''); ?>,<?php print_r($hotel_res->longitude ?? ''); ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
                              </div>  
  </section>

  <section id="section-7">
       <h3>Reviews</h3>
    <div id="reviews">
                                        <div class="rating-info">
                                            <div class="average-rating-review good">
                                                <span class="count">7.5</span>
                                                <em>Average rating</em>
                                                <span>Good</span>
                                            </div>
                                            <ul class="rating-review">
                                                <li>
                                                    <em>Facility</em>
                                                    <span>7.5</span>
                                                </li>
                                                <li>
                                                    <em>Human</em>
                                                    <span>9.0</span>
                                                </li>
                                                <li>
                                                    <em>Service</em>
                                                    <span>9.5</span>
                                                </li>
                                                <li>
                                                    <em>Interesting</em>
                                                    <span>8.7</span>
                                                </li>
                                            </ul>
                                            <a href="#" class="write-review">Write a review</a>
                                        </div>
                                        <div id="add_review">
                                            <h3 class="comment-reply-title">Add a review</h3>
                                            <form>
                                                <div class="comment-form-author">
                                                    <label for="author">Name <span class="required">*</span></label>
                                                    <input id="author" type="text">
                                                </div>
                                                <div class="comment-form-email">
                                                    <label for="email">Email <span class="required">*</span></label>
                                                    <input id="email" type="text">
                                                </div>
                                                <div class="comment-form-rating">
                                                    <h4>Your Rating</h4>
                                                    <div class="comment-form-rating__content">
                                                        <div class="item facility">
                                                            <label>Facility</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item human">
                                                            <label>Human</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item service">
                                                            <label>Service</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item interesting">
                                                            <label>Interesting</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="comment-form-comment">
                                                    <label for="comment">Your Review</label>
                                                    <textarea id="comment"></textarea>
                                                </div>
                                                <div class="form-submit">
                                                    <input type="submit" class="submit" value="Submit">
                                                </div>
                                            </form>
                                        </div>
                                        <div id="comments">
                                            <ol class="commentlist">
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>Nguyen Gallahendahry</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review good">
                                                                    <span class="count">7.5</span>
                                                                    <em>Average rating</em>
                                                                    <span>Good</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>James Bond not 007</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review good">
                                                                    <span class="count">7.5</span>
                                                                    <em>Average rating</em>
                                                                    <span>Good</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>Bratt not Pitt</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review fine">
                                                                    <span class="count">5.0</span>
                                                                    <em>Average rating</em>
                                                                    <span>Fine</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ol>
                                        </div>
                                    </div>
  </section>
  </div>
</main>
     
     
<div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q<?php print_r($hotel_res->latitude ?? ''); ?>,<?php print_r($hotel_res->longitude ?? ''); ?>=&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
     
        
        
        
        @endif
        <!--end hotel details    -->
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    
        @if(isset($hotel_beds_de_result))
        
        <?php
        
        $hotel_bed=$hotel_beds_de_result;
        
        if($hotel_beds_code == $hotel_bed->code && $hotel_beds_name == $hotel_bed->name)
        {
        
        ?>
       
        
<?php




                   $apiKey = '4b11b3c941ea25825a4de05ec398c4ab';
        $secret = 'afe693d5e4';
    
        $signature = hash("sha256", $apiKey.$secret.time());                                            
            
     $curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.hotelbeds.com/hotel-content-api/1.0/hotels/'.$hotel_bed->code.'/details?language=ENG&useSecondaryLanguage=False',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Api-key: 4b11b3c941ea25825a4de05ec398c4ab',
    "X-Signature: $signature",
    'Accept: application/json',
    'Accept-Encoding: gzip'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
$data1 = json_decode($response);
   
        $travel_content = $data1->hotel;
        // dd($travel_content);
        // print_r($travel_content);
        ?>
        
     
        <!-- HEADING PAGE -->
         
        <section class="awe-parallax category-heading-section-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class=" category-heading-content__2 text-uppercase">
                    <!-- BREADCRUMB -->
                   
                    <!-- BREADCRUMB -->
                    <div class="find">
                       
                         @include('template/frontend/includes/modify_search') 
                    </div>
                </div>
            </div>
        </section>
        <!-- END / HEADING PAGE -->

    <!-- BREADCRUMB -->
        <div class="container">
            <div class="breadcrumb">
            <ul>
                <li><a href="#">Home</a></li>
                <li><span>{{$hotel_bed->destinationName ?? ""}}</span></li>
                <li><span>{{$hotel_bed->name ?? ""}}</span></li>
            </ul>
        </div>
        </div>
        <!-- BREADCRUMB -->
                                      
                                       
         <section class="hotel-images-section ">
             
            <div class="gdlr-core-pbf-element">
                <div class="gdlr-core-gallery-item gdlr-core-item-pdb clearfix  gdlr-core-gallery-item-style-grid-no-space gdlr-core-item-pdlr ">
                    <div class="gdlr-core-gallery-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">
                       <div class="container">
                       <div class="row">
                           <div class="col-md-4" style="padding-right: 0%;">
                                @if(isset($travel_content->images))
                           
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15" style="width: 100% !important;">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="https://photos.hotelbeds.com/giata/bigger/{{$travel_content->images[0]->path}}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 100% !important;"  src="https://photos.hotelbeds.com/giata/bigger/{{$travel_content->images[0]->path}}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                        @endif
                           </div>
                           <div class="col-md-8" style="padding-left: 0%;">
                                @if(isset($travel_content->images))
                           <?php 
                           $count=1;
                           ?>
                           
                            @foreach($travel_content->images as $key => $img)
                            @if($key > 0)
                            @if($count <= 9)
                       
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="https://photos.hotelbeds.com/giata/bigger/{{$img->path}}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 160px;padding: 3px;" src="https://photos.hotelbeds.com/giata/bigger/{{$img->path}}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                        @endif
                        @endif
                        <?php 
                           $count++;
                           ?>
                         @endforeach
                    @endif
                           </div>
                       </div>
                          </div>
                  
                    </div>
                </div>
            </div>
        </section>
        
  
  
    <nav class="navbar navbar-expand-lg navbar-dark hotel-nav" id="hotel-nav" >
        <div class="container">    
          <ul class="navbar-nav">
         <li><a href="#section-1">Overview</a></li>
        <li><a href="#section-2">Rooms</a></li>
        <li><a href="#section-3">Facilities</a></li>
        <li><a href="#section-4">Near By Places</a></li>
        <li><a href="#section-5">Location</a></li>

        <li><a href="#section-7">Review &amp; rating</a></li>
       
          </ul>
</div>

    </nav>

    
  

<main>
    <div class="container mt-5">   
  <section id="section-1">
  
    <div class="row">
                    <div class="col-md-8">
                        <div class="product-detail__info">
                            <div class="product-title">
                                <h2>{{$hotel_bed->name ?? ""}}</h2>
                                <div class="hotel-star">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                            </div>
                           
                            <div class="product-address">
                                <span><svg style="width: 13px;display: inline;margin-right: 7px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--! Font Awesome Pro 6.1.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M168.3 499.2C116.1 435 0 279.4 0 192C0 85.96 85.96 0 192 0C298 0 384 85.96 384 192C384 279.4 267 435 215.7 499.2C203.4 514.5 180.6 514.5 168.3 499.2H168.3zM192 256C227.3 256 256 227.3 256 192C256 156.7 227.3 128 192 128C156.7 128 128 156.7 128 192C128 227.3 156.7 256 192 256z"/></svg>{{$hotel_bed->destinationName ?? ""}}</span>
                            </div>
                            <!--<div class="product-email">-->
                            <!--    <i class="fa fa-envelope"></i>-->
                            <!--    {{$hotel_bed->minRate ?? ""}} {{$hotel_bed->currency ?? ""}}-->
                            <!--</div>-->

                           

                            <div class="product-descriptions">
                                <p>{{$travel_content->description->content ?? ""}}</p>
                            </div>
                            <!--<div class="property-highlights">-->
                            <!--    <h3>Property highlights</h3>-->
                            <!--    <div class="property-highlights__content">-->
                            <!--        <ul>-->
                            <!--        @if(isset($travel_content->amenities))-->
                            <!--            @foreach($travel_content->amenities as $amanity)-->
                            <!--        <div class="item">-->
                                        <!--<i class="awe-icon awe-icon-unlock"></i>-->
                            <!--            <i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>-->
                            <!--            <li>{{$amanity->description->content ?? ""}}</li>-->
                                       
                            <!--        </div>-->
                            <!--         @endforeach-->
                            <!--            @endif-->
                            <!--            </ul>-->
                            <!--    </div>-->
                            <!--</div>-->
                            
                            <!--<div class="property-highlights">-->
                            <!--    <h3>Property highlights</h3>-->
                                
                            <!--     <div class="property-highlights__content">-->
                            <!--        <div class="">-->
                                        
                            <!--                <p><i class="fa-solid fa-envelope-circle-check"></i> {{$travel_content->email ?? ""}} <i class="fa-solid fa-globe"></i> {{$travel_content->web ?? ""}}</p>-->
                                        <!--<ul>-->
                                       
                                         <!--</ul>-->
                            <!--              <ul style="display: flex;">-->
                                             
                            <!--             </ul>-->
                                          
                                          
                            <!--        </div>-->
                                   
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                         <!--<div class="rating-trip-reviews">-->
                         <!--       <div class="item good">-->
                         <!--          Hotel Rating  <span class="count">{{$hotel_bed->categoryName ?? ""}}</span>-->
                                    
                         <!--       </div>-->
                               
                         <!--   </div>-->
                        <div class="product-detail__gallery" style="margin-top: 24%;text-align: -webkit-center;">
                            <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map" ><img style="border: 4px solid #d2b254;" src="https://cdn6.agoda.net/images/MAPS-1214/default/property-map-entry-1.svg" alt=""></a> 
                           
                            
                            
                        </div>
                    </div>
                
   </div>
  </section>
  <input type="hidden" value="0" id="total_rooms_selected" />
  <section id="section-2">
       <h5>Room Details</h5>
        <form id="roomsform" action="{{URL::to('')}}/getbooking/hotelbeds" method="post">
                                @csrf
      <div class="row">
          <div class="col-sm-10">
              <table class="room-type-table">
                                        <thead>
                                            <tr>
                                                <th class="room-type">Room Type</th>
                                                 <th class="room-people">Room Details</th>
                                               
                                                <!--<th class="room-price">Room Selected</th>-->
                                            </tr>
                                        </thead>
                                        <tbody>
                            
                                
                                <?php
                                  $room_counter=1;
                                 foreach($rooms_data as  $rooms_data)
                                        {
                                           
                                        
                                       

                                 ?>
                                
                                 @foreach($hotel_bed->rooms as $room)
                                
                                 <?php
                                 $room_quantity=1;
                                 if($room->code == $rooms_data->roomCode)
                                            
                                     {           
         
              
              
                   
           ?>
                                 
  <div class="modal fade" id="hotel_beds_cancellation" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cancellation Policy</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
@foreach($room->rates as $rates)
@if(isset($rates->cancellationPolicies))
@foreach($rates->cancellationPolicies as $cancellationPolicies)

<div class="col-md-12">
   <i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i> <a style="color: #666;font-size: 14px;text-decoration: none;" href="javascript:;" style="color:red">{{$rates->boardName}}  {{$hotel_bed->currency ?? ''}} {{$cancellationPolicies->amount}} will be deducted upon cancellation till <?php echo  date('d F Y', strtotime($cancellationPolicies->from)) ?></a>
   
</div>


 @endforeach
 @endif
@endforeach
  </div>                                 
      </div>
      
    </div>
  </div>
</div>


<div class="modal fade" id="hotel_beds_fecilities" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Room Facilities</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<?php 
                                                       if(isset($rooms_data->roomFacilities))
                                                       {
                                                        foreach($rooms_data->roomFacilities as $roomFacilities)
                                                        {
                                                            foreach($response_facilities->facilities as $facilities)
                                                            {
                                                                if($roomFacilities->facilityGroupCode == $facilities->facilityGroupCode)
                                                                {
                                                                   
                                                                    ?>
                                                                    <div class="col-md-4">
                                                                      <i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>
                                                                    <?php
                                                                    print_r($facilities->description->content);
                                                                    ?>
                                                                    </div>
                                                                  
                                                                    
                                                                    
                                                                    <?php
                                                                  
                                                                   
                                                                    
                                                                }
                                                               
                                                            }
                                                             
                                                        }
                                                       }
                                                        
                                                        
                                                        ?>
  </div>                                 
      </div>
      
    </div>
  </div>
</div>





                                 
                                            <tr>
                                                <td class="room-type">
                                                    <div class="room-thumb">
                                 <div class="product-slider-wrapper" style="margin-top: 23px;margin-bottom: 31px;">
                                <div class="product-slider">
                                                        <?php
                                                  if($rooms_images != NULL)
                                                  {
                                   foreach($rooms_images as $value)
                                   {
                                 if(isset($value->roomCode))
                               {
                               if($room->code == $value->roomCode)
                               {
                                   ?>
                                 
                                  <img src="https://photos.hotelbeds.com/giata/bigger/{{$value->path}}" alt="">
                                 
                                 
                                   
                                  
                                 
                                  

                                        
                                        
                                    
                              <?php  
                               }
                               }
                               
                                   } 
                                                  }
                                  ?>
                               
                               
                               
                               
                               
                               
                                   
                                                        
                              
                                   
                                </div>
                               
                            </div>
                                   
                                    <h7>{{$room->name ?? ""}}</h7>
                                    <ul style="margin-top: 19px; padding-left: 0px;font-size: 14px;line-height: 1.5;">
                                                            
                                                        <?php 
                                                        $f_count=1;
                                                        if(isset($rooms_data->roomFacilities))
                                                        {
                                                        foreach($rooms_data->roomFacilities as $roomFacilities)
                                                        {
                                                            foreach($response_facilities->facilities as $facilities)
                                                            {
                                                                if($roomFacilities->facilityGroupCode == $facilities->facilityGroupCode)
                                                                {
                                                                   if($f_count <= 3)
                                                                   {
                                                                    ?>
                                                                    
                                                                  
                                                                      <li><i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i> {{$facilities->description->content}}</li>
                                                                      
                                                                 
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    <?php
                                                                   }
                                                                   
                                                                  $f_count=$f_count+1;    
                                                                }
                                                               
                                                            }
                                                             
                                                        }
                                                       
                                                        }
                                                        
                                                        ?>

                                                           <li style="margin-top: 6px;">
                                                               <a  href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotel_beds_fecilities">View More</a>
                                                           </li>

<?php
$current=date('Y-m-d');

if(isset($room->rates[0]->cancellationPolicies) && $room->rates[0]->cancellationPolicies[0]->from > $current)
{
?>
<li style="margin-top: 16px;">
    <!--<span style="color: green;font-size: 13px;font-weight: bold;" >Refundable</span><br>-->
  <!--<i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i> <a style="color: #666666;font-size: 12px;text-decoration: none;font-weight: 700;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotel_beds_cancellation" style="color:red">Cancellation Policy ?</a>-->
 </li>
<?php
}
?>
                                                     
                                                      </ul>
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                        
                                                </td>
                                                
                                                <td>
                                                    <table style="width:100%">
                                                       
                                                            <th style="width: 25%;">Meal Type</th>
                                                             <th style="width: 28%;">Room Capacity</th>
                                                              <th style="width: 25%;">Price</th>
                                                               <th></th>
                                                        
                                                        <tbody class="hotel_append_div">
                                                            
                                                            <?php
                                                            
                                                            $select=$room_counter;
                                                          
                                                            ?>
                                                        
                                                         @foreach($room->rates as $rate)
                                                     
                                                     <?php
                                                     
                                                     
                                                     $obj_hotel_beds=array(
                                                        
                                                       'rate_rateKey'=>$rate->rateKey
                                                        
                                                        );
                                                     ?>
                                                     
                                                    <tr>
                                                     <td>
                                                        <p style="font-weight: 700;">{{$rate->boardName ?? ""}}</p><br>

<?php
$current=date('Y-m-d');
if(isset($rate->cancellationPolicies))
{
foreach($rate->cancellationPolicies as $cancellationPolicies)
{
if($cancellationPolicies->from > $current)
{

$price=$cancellationPolicies->amount;
$currency=$hotel_bed->currency ?? '';
$exchange_price=all_currency_manage($currency,$price);
                                                    ?>
<span style="color: green;font-size: 13px;font-weight: bold;" >Refundable</span><br>
<i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>  <a style="color: #666666c7;font-size: 14px;text-decoration: none;" href="javascript:;">
   GBP {{$exchange_price}} 
   will be deducted upon cancellation From <?php echo  date('d F Y', strtotime($cancellationPolicies->from)) ?>
    </a>
<?php
}
else
{
?>
 <a style="color: red;font-size: 14px;text-decoration: none;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotel_beds_cancellation" style="color:red">Non Refundable</a>
<!--<h9></h9>-->

<?php
}
}
}

?>
                                                        
                                                        <!--<li>Breakfast $ 190 per guest</li>-->
                                                   
                                                     </td>
                                                     
                                                            <td>
                                                    <i style="font-size: 14px;" class="awe-icon awe-icon-users"></i>
                                                  {{$rate->adults}}  Adults , {{$rate->children}} children <br><br> &nbsp;&nbsp;&nbsp;&nbsp; {{$rate->rooms}} Rooms 
                                                </td>
                                               
                                                       
                                                    <td>
                                                     <?php
                                                     $price=$rate->net;
                                                    $currency=$hotel_bed->currency ?? '';
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                    ?>
                                                       <p style="font-size: 19px;color:#d2b254; display:none;" class="exchange_price1_1_{{$select}}">{{$exchange_price}}</p> <br><br>
                                                       <p style="font-size: 19px;color:#d2b254;" class="exchange_rate_country_price_{{$select}}"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></p> <br><br>
                                                       
                                                       
                                                       
                                                       
                                                       
                                                       <?php
                           
                                                       $startTimeStamp = strtotime($in);                                   
                                                        $endTimeStamp = strtotime($out);                                     
                            
                                                        $timeDiff = abs($endTimeStamp - $startTimeStamp);                            
                            
                                                        $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  
                            
                            
                                                        $numberDays = intval($numberDays);                                           

                                                                                        

                                                            
                           
                           
                                                            ?>
                                                            <p style="font-size:12px;" ><i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>  <?php echo 'Price For ' .  $numberDays . ' ' . 'Nights'; ?></p>
                                                     </td>
                                                     
                                                     
                                                     
                                                   <td>
                                                              
                                                       <div class="form-check">
                                                          
                                                               
                                                                         <input  value='<?php print_r(json_encode($obj_hotel_beds));  ?>' data-room="{{$rate->boardName}}" room-id="{{$select}}" room-quantity="{{$rate->rooms}}" data-for="{{$rate->boardName}}{{$room_counter}}"  data-room-type="{{$room->name}}" room-id="{{$room_counter}}"  type="checkbox" class="form-check-input selectrooms btn-check" id="{{$rate->boardName}}{{$room_counter}}"  autocomplete="off" name="hotelbeds_select_room[]">
                                                                          <label style="padding: 5px;position: relative;" class="btn btn-primary font-size-12px w-100 font-bold" for="{{$rate->boardName}}{{$room_counter}}"><p class="mb-0 text-white" style="font-size: 11px;">Select </p><p class="mb-0 text-white" style="font-size: 11px;">{{$rate->boardName}}</p>
                                                                          <i class="fa-solid fa-check"></i>
                                                                          
                                                                               
                                                                        
                                                                          
                                                                          </label>
                                                                       
                                                                     </div>
                                                     
                                                    
                                                 </td>
                                                     </tr>            
                                                                <?php
                                                                $select=$select+1;
                                                  
                                                  
                                                    ?>
                                                    @endforeach
                                               </tbody>
                                                    </table>
                                                </td>
                                              
                                                
                                            </tr>
                                            
                                                
                                                    
                                           
                                          
                                            <?php
                                   
                                     $room_counter=$select;
                                            }
                                       
                                         
                                            ?>
                                            
                                             @endforeach
                                            
                                            <?php
                                            
                                        }
                                        
                                       
                                        
                                            ?>
                                                
                                          
                                        </tbody>
                                    </table>
              
              
          </div>
           <div class="col-sm-2">
              <div class="detail-sidebar">
                                
                 <button type="button" class="btn btn-info book_now" style="padding: 10px 0; width: 100%; background:#027806;border: 1px solid #d2b254;margin-top: 20px;color: white;">Book Now</button>
                </div> 
          </div>
    </div>   
       </form>
     
    
  </section>
  <section id="section-3">
      <div class="property-highlights">
                                <h3>Property highlights</h3>
                                <div class="property-highlights__content">
                                    <div class="row">
                                    @if(isset($travel_content->facilities))
                                        @foreach($travel_content->facilities as $facilities)
                                        <div class="col-md-3">
                                    <div class="item">
                                        <i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>
                                        <span>{{$facilities->description->content ?? ""}} {{$facilities->number ?? ""}} </span>
                                    </div>
                                    </div>
                                    @endforeach
                                        @endif
                                </div>
                                </div>
                            </div>
      
 
  </section>
  <section id="section-4">
       <h5>Near By Places</h5>
   <div class="row">
                                        
                                            
                                             @if(isset($travel_content->interestPoints))
                                        @foreach($travel_content->interestPoints as $interestPoint)
                                        
                                                <div class="col-md-3">
                                                    <p><i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i> {{$interestPoint->distance ?? ""}}Meter Away From  {{$interestPoint->poiName ?? ""}}</p>
                                                
                                                </div>
                                            
                                        
                                        @endforeach 
                                        @endif
                                            
                                            
                                        
                                       
                                    </div>
  </section>
  <section id="section-5">
       <h3>Location</h3>
                                     <div class="col-12 col-md-12">
                             <div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=50%25&amp;height=600&amp;hl=en&amp;q=<?php print_r($hotel_bed->latitude); ?>,<?php print_r($hotel_bed->longitude); ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
                              </div>  
  </section>

  <section id="section-7">
       <h3>Reviews</h3>
    <div id="reviews">
                                        <div class="rating-info">
                                            <div class="average-rating-review good">
                                                <span class="count">7.5</span>
                                                <em>Average rating</em>
                                                <span>Good</span>
                                            </div>
                                            <ul class="rating-review">
                                                <li>
                                                    <em>Facility</em>
                                                    <span>7.5</span>
                                                </li>
                                                <li>
                                                    <em>Human</em>
                                                    <span>9.0</span>
                                                </li>
                                                <li>
                                                    <em>Service</em>
                                                    <span>9.5</span>
                                                </li>
                                                <li>
                                                    <em>Interesting</em>
                                                    <span>8.7</span>
                                                </li>
                                            </ul>
                                            <a href="#" class="write-review">Write a review</a>
                                        </div>
                                        <div id="add_review">
                                            <h3 class="comment-reply-title">Add a review</h3>
                                            <form>
                                                <div class="comment-form-author">
                                                    <label for="author">Name <span class="required">*</span></label>
                                                    <input id="author" type="text">
                                                </div>
                                                <div class="comment-form-email">
                                                    <label for="email">Email <span class="required">*</span></label>
                                                    <input id="email" type="text">
                                                </div>
                                                <div class="comment-form-rating">
                                                    <h4>Your Rating</h4>
                                                    <div class="comment-form-rating__content">
                                                        <div class="item facility">
                                                            <label>Facility</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item human">
                                                            <label>Human</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item service">
                                                            <label>Service</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item interesting">
                                                            <label>Interesting</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="comment-form-comment">
                                                    <label for="comment">Your Review</label>
                                                    <textarea id="comment"></textarea>
                                                </div>
                                                <div class="form-submit">
                                                    <input type="submit" class="submit" value="Submit">
                                                </div>
                                            </form>
                                        </div>
                                        <div id="comments">
                                            <ol class="commentlist">
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>Nguyen Gallahendahry</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review good">
                                                                    <span class="count">7.5</span>
                                                                    <em>Average rating</em>
                                                                    <span>Good</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>James Bond not 007</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review good">
                                                                    <span class="count">7.5</span>
                                                                    <em>Average rating</em>
                                                                    <span>Good</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>Bratt not Pitt</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review fine">
                                                                    <span class="count">5.0</span>
                                                                    <em>Average rating</em>
                                                                    <span>Fine</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ol>
                                        </div>
                                    </div>
  </section>
  </div>
</main>
     
     
<div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php print_r($hotel_bed->latitude); ?>,<?php print_r($hotel_bed->longitude); ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
     
        <?php
    
        }
   
    ?>  
        
        
        @endif
         
         
         
       
         
         
         
       
         
         
         
         
        @if(isset($travellanda_roomh))
      
 <!-- HEADING PAGE -->
        <section class="awe-parallax category-heading-section-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class="category-heading-content category-heading-content__2 text-uppercase">
                   
                    <div class="find">
                        <h2 class="text-center">Find Your Hotel</h2>
                        
                    </div>
                </div>
            </div>
        </section>
        <!-- END / HEADING PAGE -->

    <!-- BREADCRUMB -->
        <div class="container">
            <div class="breadcrumb">
            <ul>
                <li><a href="#">Home</a></li>
                <li><span>{{$travellanda_roomh->StarRating ?? ""}}</span></li>
                <li><span>{{$travellanda_roomh->HotelName ?? ""}}</span></li>
            </ul>
        </div>
        </div>
        <!-- BREADCRUMB -->
  <section class="hotel-images-section ">
             
            <div class="gdlr-core-pbf-element">
                <div class="gdlr-core-gallery-item gdlr-core-item-pdb clearfix  gdlr-core-gallery-item-style-grid-no-space gdlr-core-item-pdlr ">
                    <div class="gdlr-core-gallery-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">
                       <div class="container">
                       <div class="row">
                           <div class="col-md-4" style="padding-right: 0%;">
                                @if(isset($data1->Body->Hotels->Hotel->Images))
                           
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15" style="width: 100% !important;">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{$data1->Body->Hotels->Hotel->Images->Image[0]}}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 100% !important;"  src="{{$data1->Body->Hotels->Hotel->Images->Image[0]}}}}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                        @endif
                           </div>
                           <div class="col-md-8" style="padding-left: 0%;">
                                @if(isset($data1->Body->Hotels->Hotel->Images))
                           <?php 
                           $count=1;
                           ?>
                           
                            @foreach($data1->Body->Hotels->Hotel->Images->Image as $key => $img)
                            @if($key > 0)
                            @if($count <= 9)
                       
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{$img}}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 160px;padding: 3px;" src="{{$img}}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                        @endif
                        @endif
                        <?php 
                           $count++;
                           ?>
                         @endforeach
                    @endif
                           </div>
                       </div>
                          </div>
                  
                    </div>
                </div>
            </div>
        </section>
 
 <nav class="navbar navbar-expand-lg navbar-dark hotel-nav" id="hotel-nav" >
        <div class="container">    
          <ul class="navbar-nav">
         <li><a href="#section-1">Overview</a></li>
        <li><a href="#section-2">Rooms</a></li>
        <li><a href="#section-3">Facilities</a></li>
        <!--<li><a href="#section-4">Near By Places</a></li>-->
        <li><a href="#section-4">Location</a></li>

        <li><a href="#section-5">Review &amp; rating</a></li>
       
          </ul>
</div>

    </nav>
 
 
 <div class="modal fade" id="travellanda_fecilities" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Room Facilities</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<?php 
                                                       
                                                        foreach($data1->Body->Hotels->Hotel->Facilities->Facility as $facilitee)
                                                        {
                                                            
                                                                   
                                                                    ?>
                                                                    <div class="col-md-4">
                                                                      <i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>
                                                                    <?php
                                                                    print_r($facilitee->FacilityName);
                                                                    ?>
                                                                    </div>
                                                                  
                                                                    
                                                                    
                                                                    <?php
                                                                  
                                                                   
                                                                    
                                                               
                                                               
                                                           
                                                             
                                                        }
                                                       
                                                        
                                                        
                                                        ?>
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
 
 <main>
    <div class="container mt-5">   
  <section id="section-1">
  
    <div class="row">
                    <div class="col-md-8">
                        <div class="product-detail__info">
                            <div class="product-title">
                                <h2>{{$travellanda_roomh->HotelName ?? ""}}</h2>
                                <div class="hotel-star">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                            </div>
                           
                            <div class="product-address">
                                <span><svg style="width: 13px;display: inline;margin-right: 7px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--! Font Awesome Pro 6.1.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M168.3 499.2C116.1 435 0 279.4 0 192C0 85.96 85.96 0 192 0C298 0 384 85.96 384 192C384 279.4 267 435 215.7 499.2C203.4 514.5 180.6 514.5 168.3 499.2H168.3zM192 256C227.3 256 256 227.3 256 192C256 156.7 227.3 128 192 128C156.7 128 128 156.7 128 192C128 227.3 156.7 256 192 256z"/></svg> {{$travellanda_roomh->StarRating ?? ""}}        </span>
                            </div>
                            <!--<div class="product-email">-->
                            <!--    <i class="fa fa-envelope"></i>-->
                            <!--    {{$hotel_bed->minRate ?? ""}} {{$hotel_bed->currency ?? ""}}-->
                            <!--</div>-->

                           

                            <div class="product-descriptions">
                                <p>{{$data1->Body->Hotels->Hotel->Description ?? ""}}</p>
                            </div>
                            
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                         <!--<div class="rating-trip-reviews">-->
                         <!--       <div class="item good">-->
                         <!--          Hotel Rating  <span class="count">{{$hotel_bed->categoryName ?? ""}}</span>-->
                                    
                         <!--       </div>-->
                               
                         <!--   </div>-->
                        <div class="product-detail__gallery" style="margin-top: 24%;text-align: -webkit-center;">
                            <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#travelanda_map" ><img style="border: 4px solid #d2b254;" src="https://cdn6.agoda.net/images/MAPS-1214/default/property-map-entry-1.svg" alt=""></a> 
                           
                            
                            
                        </div>
                    </div>
                
   </div>
  </section>
  <input type="hidden" value="0" id="total_rooms_selected" />
  <section id="section-2">
      <h5>Room Details</h5>
       <form id="roomsform" action="{{URL::to('')}}/getbooking/travellanda" method="post">
                                @csrf
       <div class="row">
          <div class="col-sm-10">
               <table class="room-type-table">
                                        <thead>
                                            <tr>
                                                <th class="room-type">Room Type</th>
                                                 <th class="room-people">Room Details</th>
                                               
                                                <!--<th class="room-price">Room Selected</th>-->
                                            </tr>
                                        </thead>
                                        <tbody>
                               
                                
                                <?php
                                $room_counter=1;
                                 $select=1;
                                         if($room_search == 1)
                                         {
                                         ?>
                                         
                                         
                                         @if(isset($travellanda_roomh->Options->Option))
                                         <?php
                                         if(is_array($travellanda_roomh->Options->Option))
                                         {
                                             
                                           ?>
                                           <?php
                                           $start_counter=1;
                                           
                                           ?>
                                           @foreach($travellanda_roomh->Options->Option as $optionz)
                                 
  








                                 
                                            <tr>
                                                <td class="room-type">
                                                    <div class="room-thumb">
                                 <div class="product-slider-wrapper" style="margin-top: 23px;margin-bottom: 31px;">
                                <div class="product-slider">
                                                        
                                 
                                  <img src="{{$data1->Body->Hotels->Hotel->Images->Image[1]}}" alt="">
                                 
                              
                                   
                                </div>
                               
                            </div>
                                   </div>
                                    <div class="room-thumb" style="width: 230px !important;">
                                        <h7>Room Option Id :{{$optionz->OptionId ?? ''}}</h7><br>
                                        <h7>{{$optionz->OnRequest ?? ''}}</h7><br>
                                        <h7>Room Type : {{$optionz->BoardType ?? ''}}</h7><br>
                                        
                                        
                                                                             

<?php
                                                   
                                                   $url = "http://xmldemo.travellanda.com/xmlv1/";
                                                $timeout = 20;
                                                $reqdata = "<Request>
                                                <Head>
                                                <Username>1124fb7683cf22910ea6e3c97473bb9c</Username>
                                                <Password>rY8qm76g5dGH</Password>
                                                <RequestType>HotelPolicies</RequestType>
                                                </Head>
                                                <Body>
                                                <OptionId>$optionz->OptionId</OptionId>
                                                </Body>
                                                </Request>";
                                                $data = array('xml' => $reqdata);
                                                $headers = array(
                                                    "Content-type: application/x-www-form-urlencoded",
                                                );
                                                $ch = curl_init();
                                                $payload = http_build_query($data);
                                                curl_setopt($ch, CURLOPT_URL,$url);
                                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                                curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
                                                curl_setopt($ch, CURLOPT_POST, true);
                                                curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
                                                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                                        
                                                $rawdata = curl_exec($ch);
                                                // print_r(rawdata);die;
                                                $xml = simplexml_load_string($rawdata);
                                                $hotel_policy= json_encode($xml);
                                                $hotel_policy= json_decode($hotel_policy);
                                               // print_r($hotel_policy);
         
                // hotel policy ended
                                                   
                                                   
                                                   ?>
                                                      
                                        
                                        
                                    <h7>{{$optionz->Rooms->Room->RoomName ?? ''}}</h7>
                                    
                                    
                                                    
                                                    
                                                    
                                                    
                                                    </div>
                                                        
                                                </td>
                                                
                                                
                                                
                                                
                                                <td>
                                                    <table>
                                                       
                                                            <th style="width: 25%;">Meal Type</th>
                                                             <th style="width: 28%;">Room Capacity</th>
                                                              <th style="width: 25%;">Price</th>
                                                               <th></th>
                                                        
                                                        <tbody class="hotel_append_div">
                                                            
                                                           
                                               
                                               
                                                <?php
                                            
                                               
                                              $obj=array(
                                                   
                                                  'OptionId'=>$optionz->OptionId,
                                                    'OnRequest'=>$optionz->OnRequest,
                                                     'BoardType'=>$optionz->BoardType,
                                                      'TotalPrice'=>$optionz->TotalPrice,
                                                      'Rooms'=> array(
                                                          'Room'=>array(
                                                         "RoomId"=>$optionz->Rooms->Room->RoomId ?? '',
                                                            "RoomName"=>$optionz->Rooms->Room->RoomName,
                                                            "NumAdults"=>$optionz->Rooms->Room->NumAdults,
                                                            "NumChildren"=>$optionz->Rooms->Room->NumChildren,
                                                            "RoomPrice"=>$optionz->Rooms->Room->RoomPrice,
                                                          ),
                                                          
                                                          ),
                                                  );
                                                  
                                                  
                                               
                                               
                                               
                                              
                                               
                                               ?>
                                                    <tr>
                                                     <td>
                                                         <?php
                                                        if($optionz->BoardType == 'Room Only')
                                                        {
                                                        ?>
                                                        <p style="font-weight: 700;"> {{$optionz->BoardType}}</p><br>
                                                        <?php
                                                        }
                                                        else
                                                        {
                                                        ?>
                                                        
                                                        <p style="font-weight: 700;"> {{$optionz->BoardType}} Included</p><br>
                                                        <?php
                                                        
                                                        }
                                                        ?>
                                                        
                                                   <ul style="margin-top: 19px; padding-left: 0px;font-size: 14px;line-height: 1.5;">
                                        

<div class="modal fade" id="exampleModal_cencel_policy" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cancellation Policy</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        
        <h5>Cancellation Deadline : {{$hotel_policy->Body->CancellationDeadline ?? ''}}</h5>
          <h5>Total Price:{{$hotel_policy->Body->Currency ?? ''}} {{$hotel_policy->Body->TotalPrice ?? ''}}</h5>
          <p>Note:<?php print_r($hotel_policy->Body->Alerts->Alert ?? ''); ?></p>
      <table class="table">
          <thead>
              <tr>
                  <th>From</th>
                   <th>Type</th>
                  <th>Value</th>
                  
              </tr>
          </thead>
          <tbody>
              @if(isset($hotel_policy->Body->Policies->Policy))
              @foreach($hotel_policy->Body->Policies->Policy as $Policy)
              <tr>
                  <td>{{$Policy->From}}</td>
                  <td>{{$Policy->Type}}</td>
                  <td>{{$Policy->Type}} {{$Policy->Value}}</td>
              </tr>
              @endforeach
              @endif
          </tbody>
      </table>                                               
                                                                
      </div>
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div> 
<?php
$current=date('Y-m-d');

if(isset($hotel_policy->Body->Policies->Policy) && $hotel_policy->Body->CancellationDeadline > $current)
{
?>
 <a style="color: red;font-size: 11px;text-decoration: none;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_cencel_policy"><?php print_r($hotel_policy->Body->Policies->Policy[1]->Value); ?> <?php print_r($hotel_policy->Body->Policies->Policy[1]->Type); ?>  will be deducted on cancellation till <?php print_r($hotel_policy->Body->Policies->Policy[1]->From); ?></a>
<?php
}
else
{
?>
<a style="color: red;font-size: 11px;text-decoration: none;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_cencel_policy">Non Refundable</a>
<!--<h9></h9>-->

<?php
}
?>
                                                     
                                                      </ul>
                                                     </td>
                                                     
                                                            <td>
                                                    <i style="font-size: 14px;" class="awe-icon awe-icon-users"></i>
                                                 
                                                  {{$optionz->Rooms->Room->NumAdults}}  Adults , {{$optionz->Rooms->Room->NumChildren}} children <br><br> &nbsp;&nbsp;&nbsp;&nbsp;  
                                                </td>
                                               
                                                       
                                                    <td>
 <?php
   $markup_add=$CustomHotel=config('All');
 $markup_price=$optionz->Rooms->Room->RoomPrice + $markup_add; 
 ?>
                                                        <p style="font-size: 19px;color:#d2b254; display:none;" class="exchange_price1_1_{{$start_counter}}">{{$markup_price}}</p> <br><br>
                                                       <p style="font-size: 19px;color:#d2b254;" class="exchange_rate_country_price_{{$start_counter}}"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></p> <br><br>
                                                       
                                                       
                                                       
                                                       <?php
                           
                                                       $startTimeStamp = strtotime($in);                                   
                                                        $endTimeStamp = strtotime($out);                                     
                            
                                                        $timeDiff = abs($endTimeStamp - $startTimeStamp);                            
                            
                                                        $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  
                            
                            
                                                        $numberDays = intval($numberDays);                                           

                                                                                        

                                                            
                           
                           
                                                            ?>
                                                            <p style="font-size:12px;" ><i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>  <?php echo 'Price For ' .  $numberDays . ' ' . 'Nights'; ?></p>
                                                     </td>
                                                     
                                                     
                                                     
                                                   <td>
                                                              
                                                       <div class="form-check">
                                                          
                                                               
                                                                         <input  value='<?php print_r(json_encode($obj));  ?>' data-room="{{$optionz->BoardType}}" room-id="{{$select}}" room-quantity="1" data-for="{{$optionz->BoardType}}{{$room_counter}}"  data-room-type="{{$optionz->Rooms->Room->RoomName}}" room-id="{{$room_counter}}"  type="checkbox" class="form-check-input selectrooms btn-check" id="{{$optionz->BoardType}}{{$start_counter}}"  autocomplete="off" name="selectrooms[]">
                                                                          <label style="padding: 5px;position: relative;" class="btn btn-primary font-size-12px w-100 font-bold" for="{{$optionz->BoardType}}{{$start_counter}}"><p class="mb-0 text-white" style="font-size: 11px;">Select </p><p class="mb-0 text-white" style="font-size: 11px;">{{$optionz->BoardType}}</p>
                                                                          <i class="fa-solid fa-check"></i>
                                                                          
                                                                               
                                                                        
                                                                          
                                                                          </label>
                                                                       
                                                                     </div>
                                                     
                                                    
                                                 </td>
                                                     </tr> 
                                                     
                                                     
                                                                <?php
                                                                $select=$select+1;
                                                   $room_counter=$room_counter+1;
                                                    ?>
                                                  
                                               </tbody>
                                                    </table>
                                                </td>
                                              
                                                
                                            </tr>
                                            
                                               <?php
                                               $start_counter=$start_counter + 1;
                                               
                                               ?> 
                                                 
                                           @endforeach
                                           <?php  
                                         }
                                         else
                                         {
                                             
                                            
                                             ?>
                                             <!--@foreach($travellanda_roomh->Options->Option as $optionz)-->
                                 
@foreach($travellanda_roomh->Options->Option->Rooms->Room as $Room)








                                 
                                            <tr>
                                                <td class="room-type">
                                                    <div class="room-thumb">
                                 <div class="product-slider-wrapper" style="margin-top: 23px;margin-bottom: 31px;">
                                <div class="product-slider">
                                                        
                                 
                                  <img src="{{$data1->Body->Hotels->Hotel->Images->Image[1]}}" alt="">
                                 
                              
                                   
                                </div>
                               
                            </div>
                                   </div>
                                    <div class="room-thumb" style="width: 230px !important;">
                                    <h7>{{$Room->RoomName ?? ''}}</h7>
                                    
                                    
                                                    
                                                    
                                                    
                                                    
                                                    </div>
                                                        
                                                </td>
                                                
                                                <td>
                                                    <table>
                                                       
                                                            <th style="width: 25%;">Meal Type</th>
                                                             <th style="width: 28%;">Room Capacity</th>
                                                              <th style="width: 25%;">Price</th>
                                                               <th></th>
                                                        
                                                        <tbody>
                                                            
                                                            <?php
                                            
                                               
                                              $obj=array(
                                                   
                                                  'OptionId'=>$travellanda_roomh->Options->Option->OptionId,
                                                    'OnRequest'=>$travellanda_roomh->Options->Option->OnRequest,
                                                     'BoardType'=>$travellanda_roomh->Options->Option->BoardType,
                                                      'TotalPrice'=>$travellanda_roomh->Options->Option->TotalPrice,
                                                      'Rooms'=> array(
                                                          'Room'=>array(
                                                         "RoomId"=>$Room->RoomId ?? '',
                                                            "RoomName"=>$Room->RoomName,
                                                            "NumAdults"=>$Room->NumAdults,
                                                            "NumChildren"=>$Room->NumChildren,
                                                            "RoomPrice"=>$Room->RoomPrice,
                                                          ),
                                                          
                                                          ),
                                                  );
                                                  
                                                  
                                               
                                               
                                               
                                              
                                               
                                               ?>
                                                    <tr>
                                                     <td>
                                                         <?php
                                                        if($travellanda_roomh->Options->Option->BoardType == 'Room Only')
                                                        {
                                                        ?>
                                                        <p style="font-weight: 700;"> {{$travellanda_roomh->Options->Option->BoardType}}</p><br>
                                                        <?php
                                                        }
                                                        else
                                                        {
                                                        ?>
                                                        
                                                        <p style="font-weight: 700;"> {{$travellanda_roomh->Options->Option->BoardType}} Included</p><br>
                                                        <?php
                                                        
                                                        }
                                                        ?>
                                                        
                                                   <ul style="margin-top: 19px; padding-left: 0px;font-size: 14px;line-height: 1.5;">
                                        
                                   

<?php
                                                   $OptionId_s=$travellanda_roomh->Options->Option->OptionId;
                                                   $url = "http://xmldemo.travellanda.com/xmlv1/";
                                                $timeout = 20;
                                                $reqdata = "<Request>
                                                <Head>
                                                <Username>1124fb7683cf22910ea6e3c97473bb9c</Username>
                                                <Password>rY8qm76g5dGH</Password>
                                                <RequestType>HotelPolicies</RequestType>
                                                </Head>
                                                <Body>
                                                <OptionId>$OptionId_s</OptionId>
                                                </Body>
                                                </Request>";
                                                $data = array('xml' => $reqdata);
                                                $headers = array(
                                                    "Content-type: application/x-www-form-urlencoded",
                                                );
                                                $ch = curl_init();
                                                $payload = http_build_query($data);
                                                curl_setopt($ch, CURLOPT_URL,$url);
                                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                                curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
                                                curl_setopt($ch, CURLOPT_POST, true);
                                                curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
                                                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                                        
                                                $rawdata = curl_exec($ch);
                                                // print_r(rawdata);die;
                                                $xml = simplexml_load_string($rawdata);
                                                $hotel_policy= json_encode($xml);
                                                $hotel_policy= json_decode($hotel_policy);
                                                // print_r($hotel_policy);
         
                // hotel policy ended
                                                   
                                                   
                                                   ?>
<div class="modal fade" id="exampleModal_cencel_policy" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cancellation Policy</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        
        <h5>Cancellation Deadline : {{$hotel_policy->Body->CancellationDeadline ?? ''}}</h5>
          <h5>Total Price:{{$hotel_policy->Body->Currency ?? ''}} {{$hotel_policy->Body->TotalPrice ?? ''}}</h5>
          <p>Note:<?php print_r($hotel_policy->Body->Alerts->Alert ?? ''); ?></p>
      <table class="table">
          <thead>
              <tr>
                  <th>From</th>
                   <th>Type</th>
                  <th>Value</th>
                  
              </tr>
          </thead>
          <tbody>
              @if(isset($hotel_policy->Body->Policies->Policy))
              @foreach($hotel_policy->Body->Policies->Policy as $Policy)
              <tr>
                  <td>{{$Policy->From}}</td>
                  <td>{{$Policy->Type}}</td>
                  <td>{{$Policy->Type}} {{$Policy->Value}}</td>
              </tr>
              @endforeach
              @endif
          </tbody>
      </table>                                               
                                                                
      </div>
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div> 
<?php
$current=date('Y-m-d');

if(isset($hotel_policy->Body->Policies->Policy) && $hotel_policy->Body->CancellationDeadline > $current)
{
?>
 <a style="color: red;font-size: 11px;text-decoration: none;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_cencel_policy"><?php print_r($hotel_policy->Body->Policies->Policy[1]->Value); ?> <?php print_r($hotel_policy->Body->Policies->Policy[1]->Type); ?>  will be deducted on cancellation till <?php print_r($hotel_policy->Body->Policies->Policy[1]->From); ?></a>
<?php
}
else
{
?>
<a style="color: red;font-size: 11px;text-decoration: none;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_cencel_policy">Non Refundable</a>
<!--<h9></h9>-->

<?php
}
?>
                                                     
                                                      </ul>
                                                     </td>
                                                     
                                                            <td>
                                                    <i style="font-size: 14px;" class="awe-icon awe-icon-users"></i>
                                                 
                                                  {{$Room->NumAdults}}  Adults , {{$Room->NumChildren}} children <br><br> &nbsp;&nbsp;&nbsp;&nbsp;  
                                                </td>
                                               
                                                       
                                                    <td>
 
<?php
   $markup_add=$CustomHotel=config('All');
 $markup_price=$Room->RoomPrice + $markup_add; 
 ?> 
                                                       <p style="font-size: 19px;color:#d2b254;"><?php echo $travellanda_currency; ?> {{$markup_price}}</p> <br><br>
                                                       
                                                       
                                                       
                                                       <?php
                           
                                                       $startTimeStamp = strtotime($in);                                   
                                                        $endTimeStamp = strtotime($out);                                     
                            
                                                        $timeDiff = abs($endTimeStamp - $startTimeStamp);                            
                            
                                                        $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  
                            
                            
                                                        $numberDays = intval($numberDays);                                           

                                                                                        

                                                            
                           
                           
                                                            ?>
                                                            <p style="font-size:12px;" ><i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>  <?php echo 'Price For ' .  $numberDays . ' ' . 'Nights'; ?></p>
                                                     </td>
                                                     
                                                     
                                                     
                                                   <td>
                                                              
                                                       <div class="form-check">
                                                          
                                                               
                                                                         <input  value='<?php print_r(json_encode($obj));  ?>' data-room="{{$travellanda_roomh->Options->Option->BoardType}}" room-id="{{$select}}" room-quantity="1" data-for="{{$travellanda_roomh->Options->Option->BoardType}}{{$room_counter}}"  data-room-type="{{$Room->RoomName}}" room-id="{{$room_counter}}"  type="checkbox" class="form-check-input selectrooms btn-check" id="{{$travellanda_roomh->Options->Option->BoardType}}{{$room_counter}}"  autocomplete="off" name="selectrooms[]">
                                                                          <label style="padding: 5px;position: relative;" class="btn btn-primary font-size-12px w-100 font-bold" for="{{$travellanda_roomh->Options->Option->BoardType}}{{$room_counter}}"><p class="mb-0 text-white" style="font-size: 11px;">Select </p><p class="mb-0 text-white" style="font-size: 11px;">{{$travellanda_roomh->Options->Option->BoardType}}</p>
                                                                          <i class="fa-solid fa-check"></i>
                                                                          
                                                                               
                                                                        
                                                                          
                                                                          </label>
                                                                       
                                                                     </div>
                                                     
                                                    
                                                 </td>
                                                     </tr>            
                                                                <?php
                                                                $select=$select+1;
                                                   $room_counter=$room_counter+1;
                                                    ?>
                                                  
                                               </tbody>
                                                    </table>
                                                </td>
                                              
                                                
                                            </tr>
                                            
                                                
                                                @endforeach
                                           <!--@endforeach-->
                                             <?php
                                         }
                                         ?>
                                                   
                                            @endif
                                             <tr>
                                               <!--<td style="text-align:right;" colspan="12">  <button type="button" class="btn btn-info book_now" style="padding: 10px 60px 10px 60px;background: #ff6666;border: 1px solid #ff6666;margin-top: 20px;color: white;">Book Now</button></td>-->
                                           </tr>
                                           <?php
                                         }
                                         else
                                         {
                                       ?>
                                        <?php
                                        
                                          if(isset($travellanda_roomh->Options->Option))  
                                        {
                                        ?>
                                      
                                        @foreach($travellanda_roomh->Options->Option as $optionz)
                                            <tr>
                                                <td class="room-type">
                                                    <div class="room-thumb">
                                 <div class="product-slider-wrapper" style="margin-top: 23px;margin-bottom: 31px;">
                                <div class="product-slider">
                                                        
                                 
                                  <img src="{{$data1->Body->Hotels->Hotel->Images->Image[1]}}" alt="">
                                 
                              
                                   
                                </div>
                               
                            </div>
                                   </div>
                                    <div class="room-thumb" style="width: 230px !important;">
                                    <h7>{{$optionz->Rooms->Room[0]->RoomName}}</h7>
                                    
                                    
                                                 <ul style="margin-top: 19px; padding-left: 0px;font-size: 14px;line-height: 1.5;">
                                        
                                   

<?php
                                                   
                                                $url = "http://xmldemo.travellanda.com/xmlv1/";
                                                $timeout = 20;
                                                $reqdata = "<Request>
                                                <Head>
                                                <Username>1124fb7683cf22910ea6e3c97473bb9c</Username>
                                                <Password>rY8qm76g5dGH</Password>
                                                <RequestType>HotelPolicies</RequestType>
                                                </Head>
                                                <Body>
                                                <OptionId>$optionz->OptionId</OptionId>
                                                </Body>
                                                </Request>";
                                                $data = array('xml' => $reqdata);
                                                $headers = array(
                                                    "Content-type: application/x-www-form-urlencoded",
                                                );
                                                $ch = curl_init();
                                                $payload = http_build_query($data);
                                                curl_setopt($ch, CURLOPT_URL,$url);
                                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                                curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
                                                curl_setopt($ch, CURLOPT_POST, true);
                                                curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
                                                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                                        
                                                $rawdata = curl_exec($ch);
                                                // print_r(rawdata);die;
                                                $xml = simplexml_load_string($rawdata);
                                                $hotel_policy= json_encode($xml);
                                                $hotel_policy= json_decode($hotel_policy);
                                                // print_r($hotel_policy);
         
                // hotel policy ended
                                                   
                                                   
                                                   ?>
<div class="modal fade" id="exampleModal_cencel_policy" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cancellation Policy</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        
        <h5>Cancellation Deadline : {{$hotel_policy->Body->CancellationDeadline ?? ''}}</h5>
          <h5>Total Price:{{$hotel_policy->Body->Currency ?? ''}} {{$hotel_policy->Body->TotalPrice ?? ''}}</h5>
          <p>Note:<?php print_r($hotel_policy->Body->Alerts->Alert ?? ''); ?></p>
      <table class="table">
          <thead>
              <tr>
                  <th>From</th>
                   <th>Type</th>
                  <th>Value</th>
                  
              </tr>
          </thead>
          <tbody>
              @if(isset($hotel_policy->Body->Policies->Policy))
              @foreach($hotel_policy->Body->Policies->Policy as $Policy)
              <tr>
                  <td>{{$Policy->From}}</td>
                  <td>{{$Policy->Type}}</td>
                  <td>{{$Policy->Type}} {{$Policy->Value}}</td>
              </tr>
              @endforeach
              @endif
          </tbody>
      </table>                                               
                                                                
      </div>
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div> 
<?php
$current=date('Y-m-d');

if(isset($hotel_policy->Body->Policies->Policy) && $hotel_policy->Body->CancellationDeadline > $current)
{
?>
 <a style="color: red;font-size: 11px;text-decoration: none;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_cencel_policy"><?php print_r($hotel_policy->Body->Policies->Policy[1]->Value); ?> <?php print_r($hotel_policy->Body->Policies->Policy[1]->Type); ?>  will be deducted on cancellation till <?php print_r($hotel_policy->Body->Policies->Policy[1]->From); ?></a>
<?php
}
else
{
?>
<a style="color: red;font-size: 11px;text-decoration: none;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_cencel_policy">Non Refundable</a>
<!--<h9></h9>-->

<?php
}
?>
                                                     
                                                      </ul>     
                                                    
                                                    
                                                   
                                                    </div>
                                                        
                                                </td>
                                                
                                                <td>
                                                    <table class="room-type-table">
                                                       <thead>
                                                            <th style="width: 25%;">Meal Type</th>
                                                             <th style="width: 28%;">Room Capacity</th>
                                                              <th style="width: 25%;">Price</th>
                                                               <th></th>
                                                           </thead>
                                                        <tbody class="hotel_append_div">
                                                            <?php
                                                            
                                                            $room_quantity=1;
                                                            
                                                            ?>
                                                            
                                                        @if(isset($optionz->Rooms->Room))
                                                      
                                                          <?php
                                                         $rooms_obj=array();
                                                          foreach($optionz->Rooms->Room as $room)
                                                          {
                                                              
                                                         $rooms_obj[]=(object)[
                                                         "RoomId"=>$room->RoomId,
                                                            "RoomName"=>$room->RoomName,
                                                            "NumAdults"=>$room->NumAdults,
                                                            "NumChildren"=>$room->NumChildren,
                                                            "RoomPrice"=>$room->RoomPrice,
                                                          ];
                                                              
                                                          }
                                                        //  print_r($rooms_obj);
                                               
                                              $obj=array(
                                                   
                                                  'OptionId'=>$optionz->OptionId,
                                                    'OnRequest'=>$optionz->OnRequest,
                                                     'BoardType'=>$optionz->BoardType,
                                                      'TotalPrice'=>$optionz->TotalPrice,
                                                      'Rooms'=> array(
                                                          'Room'=>$rooms_obj,
                                                          
                                                          ),
                                                  );
                                                  
                                                  
                                               
                                                
                                               
                                              
                                               
                                               ?> 
                                                  
                                                 
                                                          
                                                    <tr>
                                                     <td>
                                                         
                                                         <?php
                                                        if($optionz->BoardType == 'Room Only')
                                                        {
                                                        ?>
                                                        <p style="font-weight: 700;"> {{$optionz->BoardType}}</p><br>
                                                        <?php
                                                        }
                                                        else
                                                        {
                                                        ?>
                                                        
                                                        <p style="font-weight: 700;"> {{$optionz->BoardType}} Included</p><br>
                                                        <?php
                                                        
                                                        }
                                                        ?>
                                                        
                                                 
                                                     </td>
                                                     
                                                            <td>
                                                    <i style="font-size: 14px;" class="awe-icon awe-icon-users"></i>
                                                   
                                                 
                                                  {{$optionz->Rooms->Room[0]->NumAdults}}  Adults , {{$optionz->Rooms->Room[0]->NumChildren}} children  <br><br>{{$room_search}} Rooms &nbsp;&nbsp;&nbsp;&nbsp;  
                                                </td>
                                               
                                                       
                                                    <td>
 
                                                        
                                                       <!--<p style="font-size: 19px;color:#d2b254;"><?php echo $travellanda_currency; ?> {{$optionz->Rooms->Room[0]->RoomPrice}}</p> <br><br>-->
                                                       
                                                       <?php
   $markup_add=$CustomHotel=config('All');
 $markup_price=$optionz->Rooms->Room[0]->RoomPrice + $markup_add; 
 ?> 
                                                        <p style="font-size: 19px;color:#d2b254; display:none;" class="exchange_price1_1_{{$room_counter}}">{{$markup_price}}</p> <br><br>
                                                       <p style="font-size: 19px;color:#d2b254;" class="exchange_rate_country_price_{{$room_counter}}"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></p> <br><br>
                                                       
                                                       
                                                       
                                                       <?php
                           
                                                       $startTimeStamp = strtotime($in);                                   
                                                        $endTimeStamp = strtotime($out);                                     
                            
                                                        $timeDiff = abs($endTimeStamp - $startTimeStamp);                            
                            
                                                        $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  
                            
                            
                                                        $numberDays = intval($numberDays);                                           

                                                                                        

                                                            
                           
                           
                                                            ?>
                                                            <p style="font-size:12px;" ><i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>  <?php echo 'Adults' . $adult_count; ?></p>
                                                            <p style="font-size:12px;" ><i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>  <?php echo 'Price For ' .  $numberDays . ' ' . 'Nights'; ?></p>
                                                     </td>
                                                     
                                                     
                                                     
                                                   <td>
                                                              
                                                       <div class="form-check">
                                                          
                                                              
                                                               
                                                                         <input  value='<?php print_r(json_encode($obj));  ?>' data-room="{{$optionz->BoardType}}" room-id="{{$select}}" room-quantity="{{$room_search}}" data-for="{{$optionz->BoardType}}{{$room_counter}}"  data-room-type="{{$optionz->Rooms->Room[0]->RoomName}}" room-id="{{$room_counter}}"  type="checkbox" class="form-check-input selectrooms btn-check" id="{{$optionz->BoardType}}{{$room_counter}}"  autocomplete="off" name="selectrooms[]">
                                                                          <label style="padding: 5px;position: relative;" class="btn btn-primary font-size-12px w-100 font-bold" for="{{$optionz->BoardType}}{{$room_counter}}"><p class="mb-0 text-white" style="font-size: 11px;">Select </p><p class="mb-0 text-white" style="font-size: 11px;">{{$optionz->BoardType}}</p>
                                                                          <i class="fa-solid fa-check"></i>
                                                                          
                                                                               
                                                                        
                                                                          
                                                                          </label>
                                                                       
                                                                     </div>
                                                     
                                                    
                                                 </td>
                                                     </tr>            
                                                                <?php
                                                                $select=$select+1;
                                                   $room_counter=$room_counter+1;
                                                   $room_quantity=$room_quantity+1;
                                                        
                                                    ?>
                                                   
                                                  
                                                  @endif
                                            
                                               </tbody>
                                                    </table>
                                                </td>
                                              
                                                
                                            </tr>
                                            
                                                
                                                    
                                           @endforeach
                                           
                                             <tr>
                                               <!--<td style="text-align:right;" colspan="12">  <button type="button" class="btn btn-info book_now" style="padding: 10px 60px 10px 60px;background: #ff6666;border: 1px solid #ff6666;margin-top: 20px;color: white;">Book Now</button></td>-->
                                           </tr>
                                           
                                           <?php
                                        }
                                        ?>
                                             
                                             
                                        <?php
                                         }
                                    
                                         ?>
                                            
                                        </tbody>
                                    </table>
          </div>
            <div class="col-sm-2">
              <div class="detail-sidebar">
                                
                 <button type="button" class="btn btn-info book_now" style="padding: 10px 0; width: 100%; background:#027806;border: 1px solid #d2b254;margin-top: 20px;color: white;">Book Now</button>
                </div> 
          </div>
        </div>  
      
   </form>
  </section>
<section class="mt-5" id="section-3">
      <div class="property-highlights">
                                <h3>Property highlights</h3>
                                <div class="property-highlights__content">
                                    
                                        
                                       
                                        
                                                     
                                                  
                                    <div class="row">
                                         <?php
                                        $count=1;
                                        ?>
                                   @foreach($data1->Body->Hotels->Hotel->Facilities->Facility as $facilitee)
                                                     @if($facilitee->FacilityType == "Hotel Facilities")
                                                     <?php
                                                     if($count <= 19)
                                                     {
                                                     ?>
                                        <div class="col-md-3">
                                    <div class="item">
                                        <i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>
                                        <span>{{$facilitee->FacilityName}}</span>
                                    </div>
                                    </div>
                                  <?php
                                                    
                                                    }
                                                    $count=$count+1;
                                                    ?>
                                                     @endif
                                                     
                                    @endforeach
                                    <div class="col-md-3">
                                                               <a  href="javascript:;" data-bs-toggle="modal" data-bs-target="#travellanda_fecilities">View More</a>
                                                           </div>
  
                                </div>
                                </div>
                            </div>
      
 
  </section>
  <section class="mt-5" id="section-4">
       <h3>Location</h3>
                                     <div class="col-12 col-md-12">
                             <div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=50%25&amp;height=600&amp;hl=en&amp;q=<?php print_r($details_travellanda->Latitude); ?>,<?php print_r($details_travellanda->Longitude); ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
                              </div>  
  </section>
  <section class="mt-5 mb-5" id="section-5">
       <h3>Reviews</h3>
    <div id="reviews">
                                        <div class="rating-info">
                                            <div class="average-rating-review good">
                                                <span class="count">7.5</span>
                                                <em>Average rating</em>
                                                <span>Good</span>
                                            </div>
                                            <ul class="rating-review">
                                                <li>
                                                    <em>Facility</em>
                                                    <span>7.5</span>
                                                </li>
                                                <li>
                                                    <em>Human</em>
                                                    <span>9.0</span>
                                                </li>
                                                <li>
                                                    <em>Service</em>
                                                    <span>9.5</span>
                                                </li>
                                                <li>
                                                    <em>Interesting</em>
                                                    <span>8.7</span>
                                                </li>
                                            </ul>
                                            <a href="#" class="write-review">Write a review</a>
                                        </div>
                                        <div id="add_review">
                                            <h3 class="comment-reply-title">Add a review</h3>
                                            <form>
                                                <div class="comment-form-author">
                                                    <label for="author">Name <span class="required">*</span></label>
                                                    <input id="author" type="text">
                                                </div>
                                                <div class="comment-form-email">
                                                    <label for="email">Email <span class="required">*</span></label>
                                                    <input id="email" type="text">
                                                </div>
                                                <div class="comment-form-rating">
                                                    <h4>Your Rating</h4>
                                                    <div class="comment-form-rating__content">
                                                        <div class="item facility">
                                                            <label>Facility</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item human">
                                                            <label>Human</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item service">
                                                            <label>Service</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item interesting">
                                                            <label>Interesting</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="comment-form-comment">
                                                    <label for="comment">Your Review</label>
                                                    <textarea id="comment"></textarea>
                                                </div>
                                                <div class="form-submit">
                                                    <input type="submit" class="submit" value="Submit">
                                                </div>
                                            </form>
                                        </div>
                                        <div id="comments">
                                            <ol class="commentlist">
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>Nguyen Gallahendahry</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review good">
                                                                    <span class="count">7.5</span>
                                                                    <em>Average rating</em>
                                                                    <span>Good</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>James Bond not 007</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review good">
                                                                    <span class="count">7.5</span>
                                                                    <em>Average rating</em>
                                                                    <span>Good</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>Bratt not Pitt</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review fine">
                                                                    <span class="count">5.0</span>
                                                                    <em>Average rating</em>
                                                                    <span>Fine</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ol>
                                        </div>
                                    </div>
  </section>
  </div>
  
</main>
     
     

 
 
 
 
 
 
 
 <div class="modal fade" id="travelanda_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
                             <div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=50%25&amp;height=600&amp;hl=en&amp;q=<?php print_r($details_travellanda->Latitude); ?>,<?php print_r($details_travellanda->Longitude); ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
 
 
 
 
 
 
 
 
        
        @endif
        
        
        
        
        
        
        

        
        
        
       @if(isset($hotel_tbo_detail_result))
    
<?php

       $request_data = array(
    'HotelCode' =>$hotel_tbo_detail_result->HotelCode,
   
    );
//   $searchdata=json_encode($searchdata);
  $curl = curl_init();
     curl_setopt_array($curl, array(
     CURLOPT_URL => 'https://admin.synchronousdigital.com/api/get_tbo_hotel_details',
     CURLOPT_RETURNTRANSFER => true,
     CURLOPT_ENCODING => '',
     CURLOPT_MAXREDIRS => 10,
     CURLOPT_TIMEOUT => 0,
     CURLOPT_FOLLOWLOCATION => true,
     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
     CURLOPT_CUSTOMREQUEST => 'POST',
     CURLOPT_POSTFIELDS =>  $request_data,
     CURLOPT_HTTPHEADER => array(
        'Cookie: laravel_session=gnq21xtzzbBtgOgSa0iVWPIX9vSDzHcKrUozAnSL'
     ),
     ));
  
     $response = curl_exec($curl);
     curl_close($curl);
     $tbo_hotel_detail= $response; 
    //  print_r($tbo_hotel_detail);
     $tbo_hotel_detail=json_decode($tbo_hotel_detail);
     $tbo_hotel_detail=$tbo_hotel_detail->data;

  $hotel_facilities= $tbo_hotel_detail->hotel_facilities;
     $hotel_facilities = json_decode($hotel_facilities);
    
 
 
     $tbo_hotel_image= $tbo_hotel_detail->images;
     $image= json_decode($tbo_hotel_image);
     $tbo_hotel_attractions= $tbo_hotel_detail->attractions;
     $attractions = json_decode($tbo_hotel_attractions);
     
     $map=$tbo_hotel_detail->map;
    $map = explode('|', $map);
     
  
     
     
    // print_r($tbo_hotel_detail);die();
        ?>
        
     
        <!-- HEADING PAGE -->
         
        <section class="awe-parallax category-heading-section-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class=" category-heading-content__2 text-uppercase">
                    <!-- BREADCRUMB -->
                   
                    <!-- BREADCRUMB -->
                    <div class="find">
                       
                         @include('template/frontend/includes/modify_search') 
                    </div>
                </div>
            </div>
        </section>
        <!-- END / HEADING PAGE -->

    <!-- BREADCRUMB -->
        <div class="container">
            <div class="breadcrumb">
            <ul>
                <li><a href="#">Home</a></li>
                <li><span>{{$tbo_hotel_detail->hotel_name ?? ""}}</span></li>
                <li><span>{{$tbo_hotel_detail->city_name}}, {{$tbo_hotel_detail->country_name}}</span></li>
            </ul>
        </div>
        </div>
        <!-- BREADCRUMB -->
                                      
                                       
          <section class="hotel-images-section ">
             
            <div class="gdlr-core-pbf-element">
                <div class="gdlr-core-gallery-item gdlr-core-item-pdb clearfix  gdlr-core-gallery-item-style-grid-no-space gdlr-core-item-pdlr ">
                    <div class="gdlr-core-gallery-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">
                       <div class="container">
                       <div class="row">
                           <div class="col-md-4" style="padding-right: 0%;">
                                @if(isset($image))
                           
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15" style="width: 100% !important;">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{$image[0]}}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 100% !important;"  src="{{$image[0]}}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                        @endif
                           </div>
                           <div class="col-md-8" style="padding-left: 0%;">
                                @if(isset($image))
                           <?php 
                           $count=1;
                           ?>
                           
                            @foreach($image as $key => $img)
                            @if($key > 0)
                            @if($count <= 9)
                       
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{$img}}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 160px;padding: 3px;" src="{{$img}}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                        @endif
                        @endif
                        <?php 
                           $count++;
                           ?>
                         @endforeach
                    @endif
                           </div>
                       </div>
                          </div>
                  
                    </div>
                </div>
            </div>
        </section>
        
  
  
    <nav class="navbar navbar-expand-lg navbar-dark hotel-nav" id="hotel-nav" >
        <div class="container">    
          <ul class="navbar-nav">
         <li><a href="#section-1">Overview</a></li>
        <li><a href="#section-2">Rooms</a></li>
        <li><a href="#section-3">Facilities</a></li>
        <li><a href="#section-4">Near By Places</a></li>
        <li><a href="#section-5">Location</a></li>

        <li><a href="#section-7">Review &amp; rating</a></li>
       
          </ul>
</div>

    </nav>

    
  

<main>
    <div class="container mt-5">   
  <section id="section-1">
  
    <div class="row">
                    <div class="col-md-8">
                        <div class="product-detail__info">
                            <div class="product-title">
                                <h2>{{$tbo_hotel_detail->hotel_name ?? ""}}</h2>
                                <div class="hotel-star">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                            </div>
                           
                            <div class="product-address">
                                <span><svg style="width: 13px;display: inline;margin-right: 7px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--! Font Awesome Pro 6.1.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M168.3 499.2C116.1 435 0 279.4 0 192C0 85.96 85.96 0 192 0C298 0 384 85.96 384 192C384 279.4 267 435 215.7 499.2C203.4 514.5 180.6 514.5 168.3 499.2H168.3zM192 256C227.3 256 256 227.3 256 192C256 156.7 227.3 128 192 128C156.7 128 128 156.7 128 192C128 227.3 156.7 256 192 256z"/></svg>{{$tbo_hotel_detail->address}}</span>
                            </div>
                            <!--<div class="product-email">-->
                            <!--    <i class="fa fa-envelope"></i>-->
                            <!--    {{$hotel_bed->minRate ?? ""}} {{$hotel_bed->currency ?? ""}}-->
                            <!--</div>-->

                           

                            <div class="product-descriptions">
                                <p>{{$tbo_hotel_detail->hotel_description}}</p>
                            </div>
                            
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                         <!--<div class="rating-trip-reviews">-->
                         <!--       <div class="item good">-->
                         <!--          Hotel Rating  <span class="count">{{$hotel_bed->categoryName ?? ""}}</span>-->
                                    
                         <!--       </div>-->
                               
                         <!--   </div>-->
                        <div class="product-detail__gallery" style="margin-top: 24%;text-align: -webkit-center;">
                            <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map" ><img style="border: 4px solid #d2b254;" src="https://cdn6.agoda.net/images/MAPS-1214/default/property-map-entry-1.svg" alt=""></a> 
                           
                            
                            
                        </div>
                    </div>
                
   </div>
  </section>
  <input type="hidden" value="0" id="total_rooms_selected" />
  <section id="section-2">
       <h5>Room Details</h5>
        <form id="roomsform" action="{{URL::to('')}}/preBooking/tbo" method="post">
                                @csrf
                                
        
      <div class="row">
          <div class="col-sm-10">
              <table class="room-type-table">
                                        <thead>
                                            <tr>
                                                <th class="room-type">Room Type</th>
                                                 <th class="room-people">Room Details</th>
                                               
                                                <!--<th class="room-price">Room Selected</th>-->
                                            </tr>
                                        </thead>
                                        <tbody class="hotel_append_div">
                            
                                
                                <?php
                                  $room_counter=1;
                                 
                                 foreach($hotel_tbo_detail_result->Rooms as $Rooms)
                                        {
                                           
                                           
                                        
                                       

                                 ?>
                                
                                
                                
                                 <?php
                                 $room_quantity=1;
                                         
         
              
              
                   
           ?>
                                 
  








                                 
                                            <tr>
                                                <td class="room-type">
                                                    <div class="room-thumb">
                                 <div class="product-slider-wrapper" style="margin-top: 23px;margin-bottom: 31px;">
                                <div class="product-slider">
                                                        
                                 
                                  <img src="{{$image[0]}}" alt="">
                                 
                                       
                              
                                   
                                </div>
                               
                            </div>
                                  
                                      
                                   
                                    <h7>{{$Rooms->Name[0] ?? ""}}</h7><br>
                                    <h7>{{$Rooms->Inclusion}}</h7>
                                   
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                        
                                                </td>
                                                
                                                <td>
                                                    <table style="width:100%">
                                                       
                                                            <th style="width: 25%;">Meal Type</th>
                                                             <!--<th style="width: 28%;">Room Capacity</th>-->
                                                             <th style="width: 28%;">Room Name</th>
                                                              <th style="width: 25%;">Price</th>
                                                               <th></th>
                                                        
                                                        <tbody>
                                                            
                                                            <?php
                                                            
                                                            $select=0;
                                                            
                                                            ?>
                                                        
                                                        
                                                     
                                                     
                                                     
                                                    <tr>
                                                     <td>
                                                          
                                                       
                                                        <p style="font-weight: 700;">{{$Rooms->MealType ?? ""}}</p><br>

                                                           <p>
                                                               
                                                               <?php
                                                               if($Rooms->IsRefundable == 'true')
                                                               {
                                                                   echo 'Refundable : Yes';
                                                               }
                                                               else
                                                               {
                                                                 echo 'Refundable : No';  
                                                               }
                                                               ?>
                                                               
                                                           </p><br>
                                                           <p style="font-weight: 700;">Inclusion : {{$Rooms->Inclusion ?? ""}}</p><br>
                                                        
                                                        <!--<li>Breakfast $ 190 per guest</li>-->
                                                   
                                                     </td>
                                                     
                                                            <td>
                                                    <i style="font-size: 14px;" class="awe-icon awe-icon-users"></i>
                                                    <!--{{$adult_count}} Adults, {{$room_search}} Room-->
                                                    {{$Rooms->Name[0] ?? ""}}
                                                 <?php
                                                     if(isset($room_search->RoomPromotion))
                                                 {
                                                     ?>
                                                 <div class="RoomPromotion_info position-relative" style="font-weight: 700;">Room Promotion
                                                 <div class="RoomPromotion-dropdown">
                                            <?php
                                            
                                            print_r($room_search->RoomPromotion);
                                            ?>
                                                 
                                                 </div>
                                                 
                                                 </div><br>
                                                 <?php
                                                 
                                                 }
                                                 ?>
                                                 <?php
                                                     if(isset($room_search->Supplements))
                                                 {
                                                     ?>
                                                 <div class="Supplements_info position-relative" style="font-weight: 700;">Room Supplements
                                                 <div class="Supplements-dropdown">
                                            <?php
                                            
                                            print_r($room_search->Supplements);
                                            ?>
                                                 
                                                 </div>
                                                 
                                                 </div><br>
                                                 <?php
                                                 
                                                 }
                                                 ?>
                                                </td>
                                               
                                                       
                                                    <td>
                                                    <?php
                                                     $price=$Rooms->TotalFare;
                                                    $currency='USD';
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                                                                           
   $markup_add=$CustomHotel=config('All');
 $markup_price=$exchange_price + $markup_add; 

                                                    ?>
                                                        <!--<p style="font-size: 19px;color:#d2b254;" >  <h7> {{$Rooms->TotalFare}}</h7><br>tax: USD {{$Rooms->TotalTax}} </p><br><br>-->
                                                        <p style="font-size: 19px;color:#d2b254;display:none;" class="exchange_price1_1_{{$room_counter}}" >{{$markup_price}} </p>
                                                        <p style="font-size: 19px;color:#d2b254;" class="exchange_rate_country_price_{{$room_counter}}" > </p>
                                      
                                                       
                                                       
                                                       
                                                       <?php
                           
                                                       $startTimeStamp = strtotime($in);                                   
                                                        $endTimeStamp = strtotime($out);                                     
                            
                                                        $timeDiff = abs($endTimeStamp - $startTimeStamp);                            
                            
                                                        $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  
                            
                            
                                                        $numberDays = intval($numberDays);                                           

                                                                                        

                                                            
                           
                           
                                                            ?>
                                                            <p style="font-size:12px;" ><i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>  <?php echo 'Price For ' .  $numberDays . ' ' . 'Nights'; ?></p>
                                                     </td>
                                                     
                                                     
                                                     
                                                   <td>
                                                              <?php
                                                         $data_tbo_obj=array(
                                                             
                                                             'BookingCode'=>$Rooms->BookingCode,
                                                             );
                                                         
                                                        
                                                     
                                                     
                                                    
                                                       
                                                       
                                                  ?>   
                                                       <div class="form-check">
                                                          
                                                               
                                                                         <input  value='<?php print_r(json_encode($data_tbo_obj));  ?>' data-room="{{$Rooms->MealType}}" room-id="{{$select}}" room-quantity="1" data-for="{{$Rooms->MealType}}{{$room_counter}}"  data-room-type="{{$Rooms->Name[0]}}" room-id="{{$room_counter}}"  type="checkbox" class="form-check-input selectrooms btn-check" id="{{$Rooms->MealType}}{{$room_counter}}"  autocomplete="off" name="tbo_select_room[]">
                                                                          <label style="padding: 5px;position: relative;" class="btn btn-primary font-size-12px w-100 font-bold" for="{{$Rooms->MealType}}{{$room_counter}}"><p class="mb-0 text-white" style="font-size: 11px;">Select </p><p class="mb-0 text-white" style="font-size: 11px;">{{$Rooms->MealType}}</p>
                                                                          <i class="fa-solid fa-check"></i>
                                                                          
                                                                               
                                                                        
                                                                          
                                                                          </label>
                                                                       
                                                                     </div>
                                                     
                                                    
                                                 </td>
                                                     </tr>            
                                                                <?php
                                                                $select=$select+1;
                                                 
                                                    ?>
                                                   
                                               </tbody>
                                                    </table>
                                                </td>
                                              
                                                
                                            </tr>
                                            
                                                
                                                    
                                           
                                          
                                           
                                            
                                            
                                            
                                            <?php
                                              $room_counter=$room_counter+1;
                                        }
                                        
                                       
                                        
                                            ?>
                                                
                                          
                                        </tbody>
                                    </table>
              
              
          </div>
           <div class="col-sm-2">
              <div class="detail-sidebar">
                                
                 <button type="button" class="btn btn-info book_now" style="padding: 10px 0; width: 100%; background:#027806;border: 1px solid #d2b254;margin-top: 20px;color: white;">Book Now</button>
                </div> 
          </div>
    </div>   
       </form>
     
    
  </section>
  <section id="section-3">
      <div class="property-highlights">
                                <h3>Property highlights</h3>
                                <div class="property-highlights__content">
                                    <div class="row">
                                    @if(isset($hotel_facilities))
                                        @foreach($hotel_facilities as $hotel_facilities)
                                        <div class="col-md-3">
                                    <div class="item">
                                        <i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>
                                        <span>{{$hotel_facilities ?? ""}} </span>
                                    </div>
                                    </div>
                                    @endforeach
                                        @endif
                                </div>
                                </div>
                            </div>
      
 
  </section>
  <section id="section-4">
       <h5>Near By Places</h5>
   
                                        
                                            
                                             @if($attractions != NULL)
                                        @foreach($attractions as $attractions)
                                        
                                                
                                                    <p><i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i> Meter Away From  {{$attractions ?? ""}}</p>
                                                
                                               
                                            
                                        
                                        @endforeach 
                                        @endif
                                            
                                            
                                        
                                       
                                   
  </section>
  <section id="section-5">
       <h3>Location</h3>
                                     <div class="col-12 col-md-12">
                             <div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=50%25&amp;height=600&amp;hl=en&amp;q=<?php print_r($map[0]); ?>,<?php print_r($map[1]); ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
                              </div>  
  </section>

  <section id="section-7">
       <h3>Reviews</h3>
    <div id="reviews">
                                        <div class="rating-info">
                                            <div class="average-rating-review good">
                                                <span class="count">7.5</span>
                                                <em>Average rating</em>
                                                <span>Good</span>
                                            </div>
                                            <ul class="rating-review">
                                                <li>
                                                    <em>Facility</em>
                                                    <span>7.5</span>
                                                </li>
                                                <li>
                                                    <em>Human</em>
                                                    <span>9.0</span>
                                                </li>
                                                <li>
                                                    <em>Service</em>
                                                    <span>9.5</span>
                                                </li>
                                                <li>
                                                    <em>Interesting</em>
                                                    <span>8.7</span>
                                                </li>
                                            </ul>
                                            <a href="#" class="write-review">Write a review</a>
                                        </div>
                                        <div id="add_review">
                                            <h3 class="comment-reply-title">Add a review</h3>
                                            <form>
                                                <div class="comment-form-author">
                                                    <label for="author">Name <span class="required">*</span></label>
                                                    <input id="author" type="text">
                                                </div>
                                                <div class="comment-form-email">
                                                    <label for="email">Email <span class="required">*</span></label>
                                                    <input id="email" type="text">
                                                </div>
                                                <div class="comment-form-rating">
                                                    <h4>Your Rating</h4>
                                                    <div class="comment-form-rating__content">
                                                        <div class="item facility">
                                                            <label>Facility</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item human">
                                                            <label>Human</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item service">
                                                            <label>Service</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item interesting">
                                                            <label>Interesting</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="comment-form-comment">
                                                    <label for="comment">Your Review</label>
                                                    <textarea id="comment"></textarea>
                                                </div>
                                                <div class="form-submit">
                                                    <input type="submit" class="submit" value="Submit">
                                                </div>
                                            </form>
                                        </div>
                                        <div id="comments">
                                            <ol class="commentlist">
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>Nguyen Gallahendahry</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review good">
                                                                    <span class="count">7.5</span>
                                                                    <em>Average rating</em>
                                                                    <span>Good</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>James Bond not 007</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review good">
                                                                    <span class="count">7.5</span>
                                                                    <em>Average rating</em>
                                                                    <span>Good</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>Bratt not Pitt</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review fine">
                                                                    <span class="count">5.0</span>
                                                                    <em>Average rating</em>
                                                                    <span>Fine</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ol>
                                        </div>
                                    </div>
  </section>
  </div>
</main>
     
     
<div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
     
        
        
        
        @endif
        
        
        @if(isset($rate_hawke_hotel_details))
    

        <!-- HEADING PAGE -->
         
        <section class="awe-parallax category-heading-section-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class=" category-heading-content__2 text-uppercase">
                    <!-- BREADCRUMB -->
                   
                    <!-- BREADCRUMB -->
                    <div class="find">
                       
                         @include('template/frontend/includes/modify_search') 
                    </div>
                </div>
            </div>
        </section>
        <!-- END / HEADING PAGE -->

    <!-- BREADCRUMB -->
        <div class="container">
            <div class="breadcrumb">
            <ul>
                <li><a href="#">Home</a></li>
                <li><span>{{$rate_hawke_hotel_details->name ?? ""}}</span></li>
                <li><span>{{$rate_hawke_hotel_details->address ?? ""}}</span></li>
            </ul>
        </div>
        </div>
        <!-- BREADCRUMB -->
                                      
                                       
          <section class="hotel-images-section ">
             
            <div class="gdlr-core-pbf-element">
                <div class="gdlr-core-gallery-item gdlr-core-item-pdb clearfix  gdlr-core-gallery-item-style-grid-no-space gdlr-core-item-pdlr ">
                    <div class="gdlr-core-gallery-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">
                       <div class="container">
                       <div class="row">
                           <div class="col-md-4" style="padding-right: 0%;">
                                @if(isset($rate_hawke_hotel_details->images))
<?php
                                            
$image=$rate_hawke_hotel_details->images[0];
$image = explode('{size}', $image);
$img=$image[0]. '1024x768'.$image[1];
?>
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15" style="width: 100% !important;">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{$img}}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 100% !important;"  src="{{$img}}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                        @endif
                           </div>
                           <div class="col-md-8" style="padding-left: 0%;">
                                @if(isset($rate_hawke_hotel_details->images))
                           <?php 
                           $count=1;
                           ?>
                           
                            @foreach($rate_hawke_hotel_details->images as $key => $img)
                            @if($key > 0)
                            @if($count <= 9)
<?php
                                            
$image=$img;
$image = explode('{size}', $image);
$img=$image[0]. '1024x768'.$image[1];
?>
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{$img}}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 160px;padding: 3px;" src="{{$img}}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                        @endif
                        @endif
                        <?php 
                           $count++;
                           ?>
                         @endforeach
                    @endif
                           </div>
                       </div>
                          </div>
                  
                    </div>
                </div>
            </div>
        </section>
        
  
  
    <nav class="navbar navbar-expand-lg navbar-dark hotel-nav" id="hotel-nav" >
        <div class="container">    
          <ul class="navbar-nav">
         <li><a href="#section-1">Overview</a></li>
        <li><a href="#section-2">Rooms</a></li>
        <li><a href="#section-3">Facilities</a></li>
        <li><a href="#section-4">Near By Places</a></li>
        <li><a href="#section-5">Location</a></li>

        <li><a href="#section-7">Review &amp; rating</a></li>
       
          </ul>
</div>

    </nav>

    
  

<main>
    <div class="container mt-5">   
  <section id="section-1">
  
    <div class="row">
                    <div class="col-md-8">
                        <div class="product-detail__info">
                            <div class="product-title">
                                <h2>{{$rate_hawke_hotel_details->name ?? ""}}</h2>
                                <div class="hotel-star">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                            </div>
                           
                            <div class="product-address">
                                <span><svg style="width: 13px;display: inline;margin-right: 7px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--! Font Awesome Pro 6.1.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M168.3 499.2C116.1 435 0 279.4 0 192C0 85.96 85.96 0 192 0C298 0 384 85.96 384 192C384 279.4 267 435 215.7 499.2C203.4 514.5 180.6 514.5 168.3 499.2H168.3zM192 256C227.3 256 256 227.3 256 192C256 156.7 227.3 128 192 128C156.7 128 128 156.7 128 192C128 227.3 156.7 256 192 256z"/></svg>{{$rate_hawke_hotel_details->address}}</span>
                            </div>
                            <!--<div class="product-email">-->
                            <!--    <i class="fa fa-envelope"></i>-->
                            <!--    {{$hotel_bed->minRate ?? ""}} {{$hotel_bed->currency ?? ""}}-->
                            <!--</div>-->

                           

                            <div class="product-descriptions">
                                @foreach($rate_hawke_hotel_details->description_struct as $description_struct)
                                <p>{{$description_struct->title}}</p>
                                @endforeach
                            </div>
                            
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                         <!--<div class="rating-trip-reviews">-->
                         <!--       <div class="item good">-->
                         <!--          Hotel Rating  <span class="count">{{$hotel_bed->categoryName ?? ""}}</span>-->
                                    
                         <!--       </div>-->
                               
                         <!--   </div>-->
                        <div class="product-detail__gallery" style="margin-top: 24%;text-align: -webkit-center;">
                            <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map" ><img style="border: 4px solid #d2b254;" src="https://cdn6.agoda.net/images/MAPS-1214/default/property-map-entry-1.svg" alt=""></a> 
                           
                            
                            
                        </div>
                    </div>
                
   </div>
  </section>
  <input type="hidden" value="0" id="total_rooms_selected" />
  <section id="section-2">
       <h5>Room Details</h5>
        <form id="roomsform" action="{{URL::to('')}}/getbooking/ratehawke" method="post">
                                @csrf
                                
        
      <div class="row">
          <div class="col-sm-10">
              <table class="room-type-table">
                                        <thead>
                                            <tr>
                                                <th class="room-type">Room Type</th>
                                                 <th class="room-people">Room Details</th>
                                               
                                                <!--<th class="room-price">Room Selected</th>-->
                                            </tr>
                                        </thead>
                                        <tbody class="hotel_append_div">
                            
                                
                                <?php
                               
                                  $room_counter=1;
                                  
                                 
                                  
                                  
                                 if(isset($hotel_ratehawke_detail_result))
                                 {
                                 foreach($hotel_ratehawke_detail_result->hotels[0]->rates as $Rooms)
                                        {
                                           
                                           
                                        
                                       

                                 ?>
                                
                                
                                
                                 <?php
                                 $room_quantity=1;
                                         
         
              
              
                   
           ?>
                                 
  








                                 
                                            <tr>
                                                <td class="room-type">
                                                    <div class="room-thumb">
                                 <div class="product-slider-wrapper" style="margin-top: 23px;margin-bottom: 31px;">
                                <div class="product-slider">
                                                        
<?php
                                            
$image=$rate_hawke_hotel_details->images[0];
$image = explode('{size}', $image);
$img=$image[0]. '1024x768'.$image[1];
?>
                                  <img src="{{$img}}" alt="">
                                 
                                       
                              
                                   
                                </div>
                               
                            </div>
                                  
<div class="modal fade" id="exampleModal_cencel_policy" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cancellation Policy</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        
        <h5>free cancellation before : </h5>
          
      <table class="table">
          <thead>
              <tr>
                  <th>start_at</th>
                   <th>end_at</th>
                  <th>amount</th>
                  
              </tr>
          </thead>
          <tbody>
              
              @foreach($Rooms->payment_options->payment_types as $payment_types)
              @if(isset($payment_types->cancellation_penalties->policies))
              @foreach($payment_types->cancellation_penalties->policies as $Policy)
              <tr>
                  <td>{{$Policy->start_at}}</td>
                  <td>{{$Policy->end_at}}</td>
                  <td> {{$Policy->amount_show}}</td>
              </tr>
              @endforeach
              @endif
              @endforeach
              
          </tbody>
      </table>                                               
                                                                
      </div>
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div>    
                                   
                                    <h7>{{$Rooms->room_name ?? ""}}</h7><br>
                                    
                                    @foreach($Rooms->amenities_data as $amenities_data)
                                    <h7>{{$amenities_data}}</h7>
                                    @endforeach
                                    <br>
 

<a style="color: red;font-size: 11px;text-decoration: none;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_cencel_policy">Cancellation Policy</a>
                                   
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                        
                                                </td>
                                                
                                                <td>
                                                    <table style="width:100%">
                                                       
                                                            <th style="width: 25%;">Meal Type</th>
                                                             <th style="width: 28%;">Room Capacity</th>
                                                              <th style="width: 25%;">Price</th>
                                                               <th></th>
                                                        
                                                        <tbody>
                                                            
                                                            <?php
                                                            
                                                            $select=0;
                                                            
                                                            ?>
                                                        
                                                        
                                                     
                                                     
                                                     
                                                    <tr>
                                                     <td>
                                                           
                                                       
                                                        <p style="font-weight: 700;">{{$Rooms->meal}}</p><br>

<?php
$current=date('Y-m-d');

if(isset($Rooms->payment_options->payment_types[0]->cancellation_penalties) && $Rooms->payment_options->payment_types[0]->cancellation_penalties->free_cancellation_before > $current)
{
?>
 <a style="color: red;font-size: 11px;text-decoration: none;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_cencel_policy"><?php print_r($Rooms->payment_options->payment_types[0]->cancellation_penalties->policies[0]->amount_charge); ?>   will be deducted on cancellation till <?php print_r($Rooms->payment_options->payment_types[0]->cancellation_penalties->policies[0]->end_at); ?></a>
<?php
}
else
{
?>
<a style="color: red;font-size: 11px;text-decoration: none;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_cencel_policy">Non Refundable</a>
<!--<h9></h9>-->

<?php
}
?>
                                                        
                                                        <!--<li>Breakfast $ 190 per guest</li>-->
                                                   
                                                     </td>
                                                     
                                                            <td>
                                                    <i style="font-size: 14px;" class="awe-icon awe-icon-users"></i>
                                                    {{$Rooms->rg_ext->capacity}} Adults, {{$Rooms->rg_ext->quality}} Room
                                                 
                                                </td>
                                               
                                                       
                                                    <td>
                                                        @foreach($Rooms->payment_options->payment_types as $payment_types)
 <?php
 
    $markup_add=$CustomHotel=config('All');
 $markup_price=$payment_types->amount + $markup_add;
 ?>
                                                        <p style="font-size: 19px;color:#d2b254;display:none;" class="exchange_price1_1_{{$room_counter}}" >  {{$markup_price}} </p>
                                                        <p style="font-size: 19px;color:#d2b254;" class="exchange_rate_country_price_{{$room_counter}}">   </p><br><br>
                                      
                                                       @endforeach
                                                       
                                                       
                                                       <?php
                           
                                                       $startTimeStamp = strtotime($in);                                   
                                                        $endTimeStamp = strtotime($out);                                     
                            
                                                        $timeDiff = abs($endTimeStamp - $startTimeStamp);                            
                            
                                                        $numberDays = $timeDiff/86400;  // 86400 seconds in one day                  
                            
                            
                                                        $numberDays = intval($numberDays);                                           

                                                                                        

                                                            
                           
                           
                                                            ?>
                                                            <p style="font-size:12px;" ><i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>  <?php echo 'Price For ' .  $numberDays . ' ' . 'Nights'; ?></p>
                                                     </td>
                                                     
                                                     
                                                     
                                                   <td>
                                                             
                                                         
                                                        
                                                     
                                                     
                                                    <?php
                                                    
                                                    $obj=array(
                                                        
                                                        "book_hash"=>$Rooms->book_hash,
                                                        
                                                        
                                                        
                                                        );
                                                    
                                                    
                                                    
                                                    ?>
                                                       
                                                      
                                                 
                                                       <div class="form-check">
                                                          
                                                               
                                                                         <input  value='<?php print_r(json_encode($obj)); ?>' data-room="{{$Rooms->meal}}" room-id="1" room-quantity="1" data-for="{{$Rooms->meal}}{{$room_counter}}"  data-room-type="{{$Rooms->room_name}}"   type="checkbox" class="form-check-input selectrooms btn-check" id="{{$Rooms->meal}}{{$room_counter}}"  autocomplete="off" name="ratehawk_select_room[]">
                                                                          <label style="padding: 5px;position: relative;" class="btn btn-primary font-size-12px w-100 font-bold" for="{{$Rooms->meal}}{{$room_counter}}"><p class="mb-0 text-white" style="font-size: 11px;">Select </p><p class="mb-0 text-white" style="font-size: 11px;">{{$Rooms->meal}}</p>
                                                                          <i class="fa-solid fa-check"></i>
                                                                          
                                                                               
                                                                        
                                                                          
                                                                          </label>
                                                                       
                                                                     </div>
                                                     
                                                    
                                                 </td>
                                                     </tr>            
                                                                <?php
                                                                $select=$select+1;
                                                   $room_counter=$room_counter+1;
                                                    ?>
                                                   
                                               </tbody>
                                                    </table>
                                                </td>
                                              
                                                
                                            </tr>
                                            
                                                
                                                    
                                           
                                          
                                           
                                            
                                            
                                            
                                            <?php
                                        }
                                        }
                                        
                                       
                                        
                                            ?>
                                                
                                          
                                        </tbody>
                                    </table>
              
              
          </div>
           <div class="col-sm-2">
              <div class="detail-sidebar">
                                
                 <button type="button" class="btn btn-info book_now" style="padding: 10px 0; width: 100%; background:#027806;border: 1px solid #d2b254;margin-top: 20px;color: white;">Book Now</button>
                </div> 
          </div>
    </div>   
       </form>
     
    
  </section>
  <section id="section-3">
      <div class="property-highlights">
                                <h3>Property highlights</h3>
                                <div class="property-highlights__content">
                                    <div class="row">
                                    @if(isset($hotel_facilities))
                                        @foreach($hotel_facilities as $hotel_facilities)
                                        <div class="col-md-3">
                                    <div class="item">
                                        <i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i>
                                        <span>{{$hotel_facilities ?? ""}} </span>
                                    </div>
                                    </div>
                                    @endforeach
                                        @endif
                                </div>
                                </div>
                            </div>
      
 
  </section>
  <section id="section-4">
       <h5>Near By Places</h5>
   
                                        
                                            
                                             @if(isset($attractions))
                                        @foreach($attractions as $attractions)
                                        
                                                
                                                    <p><i style="color: #d2b254;" class="awe-icon fa fa-check" aria-hidden="true"></i> Meter Away From  {{$attractions ?? ""}}</p>
                                                
                                               
                                            
                                        
                                        @endforeach 
                                        @endif
                                            
                                            
                                        
                                       
                                   
  </section>
  <section id="section-5">
       <h3>Location</h3>
                                     <div class="col-12 col-md-12">
                             <div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=50%25&amp;height=600&amp;hl=en&amp;q=<?php ?>,<?php  ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
                              </div>  
  </section>

  <section id="section-7">
       <h3>Reviews</h3>
    <div id="reviews">
                                        <div class="rating-info">
                                            <div class="average-rating-review good">
                                                <span class="count">7.5</span>
                                                <em>Average rating</em>
                                                <span>Good</span>
                                            </div>
                                            <ul class="rating-review">
                                                <li>
                                                    <em>Facility</em>
                                                    <span>7.5</span>
                                                </li>
                                                <li>
                                                    <em>Human</em>
                                                    <span>9.0</span>
                                                </li>
                                                <li>
                                                    <em>Service</em>
                                                    <span>9.5</span>
                                                </li>
                                                <li>
                                                    <em>Interesting</em>
                                                    <span>8.7</span>
                                                </li>
                                            </ul>
                                            <a href="#" class="write-review">Write a review</a>
                                        </div>
                                        <div id="add_review">
                                            <h3 class="comment-reply-title">Add a review</h3>
                                            <form>
                                                <div class="comment-form-author">
                                                    <label for="author">Name <span class="required">*</span></label>
                                                    <input id="author" type="text">
                                                </div>
                                                <div class="comment-form-email">
                                                    <label for="email">Email <span class="required">*</span></label>
                                                    <input id="email" type="text">
                                                </div>
                                                <div class="comment-form-rating">
                                                    <h4>Your Rating</h4>
                                                    <div class="comment-form-rating__content">
                                                        <div class="item facility">
                                                            <label>Facility</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item human">
                                                            <label>Human</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item service">
                                                            <label>Service</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                        <div class="item interesting">
                                                            <label>Interesting</label>
                                                            <select class="awe-select">
                                                                <option>5.0</option>
                                                                <option>6.5</option>
                                                                <option>7.5</option>
                                                                <option>8.5</option>
                                                                <option>9.0</option>
                                                                <option>10</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="comment-form-comment">
                                                    <label for="comment">Your Review</label>
                                                    <textarea id="comment"></textarea>
                                                </div>
                                                <div class="form-submit">
                                                    <input type="submit" class="submit" value="Submit">
                                                </div>
                                            </form>
                                        </div>
                                        <div id="comments">
                                            <ol class="commentlist">
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>Nguyen Gallahendahry</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review good">
                                                                    <span class="count">7.5</span>
                                                                    <em>Average rating</em>
                                                                    <span>Good</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>James Bond not 007</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review good">
                                                                    <span class="count">7.5</span>
                                                                    <em>Average rating</em>
                                                                    <span>Good</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="comment-box">
                                                        <div class="avatar">
                                                            <img src="images/img/demo-thumb.jpg" alt="">
                                                        </div>
                                                        <div class="comment-body">
                                                            <p class="meta">
                                                                <strong>Bratt not Pitt</strong>
                                                                <span class="time">December 10, 2012</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>Takes me back to my youth. I love the design of this soda machine. A bit pricy though..!</p>
                                                            </div>

                                                            <div class="rating-info">
                                                                <div class="average-rating-review fine">
                                                                    <span class="count">5.0</span>
                                                                    <em>Average rating</em>
                                                                    <span>Fine</span>
                                                                </div>
                                                                <ul class="rating-review">
                                                                    <li>
                                                                        <em>Facility</em>
                                                                        <span>7.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Human</em>
                                                                        <span>9.0</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Service</em>
                                                                        <span>9.5</span>
                                                                    </li>
                                                                    <li>
                                                                        <em>Interesting</em>
                                                                        <span>8.7</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ol>
                                        </div>
                                    </div>
  </section>
  </div>
</main>
     
     
<div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
     
        
        
        
        @endif
        
        
        
        
        
        
        
        
        
        
           <!--Start js links for slider-->
<script type="text/javascript" src="{{ asset('public/plugins/jquery/jquery.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/plugins/plugins.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/plugins/goodlayers-core/plugins/combine/script.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/plugins/goodlayers-core/include/js/page-builder.js') }}"></script>

<script type="text/javascript" src="{{ asset('public/admin_package/frontend/js/lib/md-map-extend.js') }}"></script>
   <!--End js links for slider-->
        
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
         
 
  <script>

$(document).ready(function(){
           

              var hotel_page_select_currency = $('#exchange_currency_ajt').val();
            //var currency = $('#currency_slc').val();
                var currency= '<?php echo Session()->get('currency_slc'); ?>';
                 var currency_slc_iso= '<?php echo Session()->get('currency_slc_iso'); ?>';
                
                //console.log('currency hotel page='+currency);
               
              var exchange_price = [];
                var initialdisplyedhotelcount = $(".hotel_append_div").children().length;
                for(var count_i=1; count_i<=initialdisplyedhotelcount; count_i++)
                {
              price=$('.exchange_price1_1_'+count_i+'').text();
              exchange_price.push(price);
              
                
                }
//console.log(exchange_price);
    //  console.log(exchange_price);
    
    
$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            url: "{{ url('convert_currency_by_alj') }}",
            method: 'POST',
            data: {
                 "_token": "{{ csrf_token() }}",
                "currency": currency,
              
                "exchange_price": exchange_price,
                 "currency_slc_iso": currency_slc_iso,
            },
            success: function(result){
                 console.log(result);
          result.forEach(function fn(item, index) {
 var count=index + 1;
  console.log(item);
  
  $('.exchange_rate_country_price_'+count+'').html(currency+ ' ' + item);

  

})
                 //
                
               
             
              
            },
            error:function(error){
                console.log(error);
            }
        });
        
        
        
         $('#exchange_currency_ajt').on('change', function() {
                 $('.preloader').fadeIn();
                
                var currency = $(this).find(":selected").val();
                  var currency_slc_iso = $(this).find(":selected").attr('data-iso');
               
              var exchange_price = [];
                var initialdisplyedhotelcount = $(".hotel_append_div").children().length;
                console.log('hotel_append_div'+initialdisplyedhotelcount);
                for(var count_i=1; count_i<=initialdisplyedhotelcount; count_i++)
                {
              price=$('.exchange_price1_1_'+count_i+'').text();
              exchange_price.push(price);
              
                
                }
//console.log(exchange_price);
    //  console.log(exchange_price);
    
    
$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            url: "{{ url('convert_currency_by_alj') }}",
            method: 'POST',
            data: {
                 "_token": "{{ csrf_token() }}",
                "currency": currency,
                "exchange_price": exchange_price,
                "currency_slc_iso": currency_slc_iso,
            },
            success: function(result){
                 console.log(result);
          result.forEach(function fn(item, index) {
 var count=index + 1;
  console.log(item);
  $('.exchange_rate_country_price_'+count+'').html(currency+ ' ' + item);
  $('.preloader').fadeOut();

})
                 //
                
               
             
              
            },
            error:function(error){
                console.log(error);
            }
        });
        
            
 
  
    
    
});
        
        
        
        
        
        
        
             
    

});   
            
 $(document).ready(function(){
           

              var hotel_page_select_currency = $('#exchange_currency_ajt').val();
            //var currency = $('#currency_slc').val();
                var currency= '<?php echo Session()->get('currency_slc'); ?>';
                 var currency_slc_iso= '<?php echo Session()->get('currency_slc_iso'); ?>';
                
                //console.log('currency hotel page='+currency);
               
              var exchange_price = [];
                var hotel_append_carousal = $(".hotel_append_carousal").children().length;
                for(var count_i=1; count_i<=hotel_append_carousal; count_i++)
                {
              price=$('.exchange_price1_1_hotel1_'+count_i+'').text();
              exchange_price.push(price);
              
                
                }
//console.log(exchange_price);
    //  console.log(exchange_price);
    
    
$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            url: "{{ url('convert_currency_by_alj1') }}",
            method: 'POST',
            data: {
                 "_token": "{{ csrf_token() }}",
                "currency": currency,
              
                "exchange_price": exchange_price,
                 "currency_slc_iso": currency_slc_iso,
            },
            success: function(result){
                 console.log(result);
          result.forEach(function fn(item, index) {
 var count=index + 1;
  console.log(item);
  
  $('.exchange_rate_country_price_hotel1_'+count+'').html(currency+ ' ' + item);

  

})
                 //
                
               
             
              
            },
            error:function(error){
                console.log(error);
            }
        });
        
        
        
         $('#exchange_currency_ajt').on('change', function() {
                 $('.preloader').fadeIn();
                
                var currency = $(this).find(":selected").val();
                  var currency_slc_iso = $(this).find(":selected").attr('data-iso');
               
              var exchange_price = [];
                var hotel_append_carousal = $(".hotel_append_carousal").children().length;
                console.log('hotel_append_carousal'+hotel_append_carousal);
                for(var count_i=1; count_i<=hotel_append_carousal; count_i++)
                {
              price=$('.exchange_price1_1_hotel1_'+count_i+'').text();
              exchange_price.push(price);
              
                
                }
//console.log(exchange_price);
    //  console.log(exchange_price);
    
    
$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            url: "{{ url('convert_currency_by_alj1') }}",
            method: 'POST',
            data: {
                 "_token": "{{ csrf_token() }}",
                "currency": currency,
                "exchange_price": exchange_price,
                "currency_slc_iso": currency_slc_iso,
            },
            success: function(result){
                 console.log(result);
          result.forEach(function fn(item, index) {
 var count=index + 1;
  console.log(item);
  $('.exchange_rate_country_price_hotel1_'+count+'').html(currency+ ' ' + item);
  $('.preloader').fadeOut();

})
                 //
                
               
             
              
            },
            error:function(error){
                console.log(error);
            }
        });
        
            
 
  
    
    
});
        
        
        
        
        
        
        
             
    

});            
            
    $(document).ready(function(){
           

              var hotel_page_select_currency = $('#exchange_currency_ajt').val();
            //var currency = $('#currency_slc').val();
                var currency= '<?php echo Session()->get('currency_slc'); ?>';
                 var currency_slc_iso= '<?php echo Session()->get('currency_slc_iso'); ?>';
                
                //console.log('currency hotel page='+currency);
               
              var exchange_price = [];
                var hotel_append_div_carosal = $(".hotel_append_div_carosal").children().length;
                for(var count_i=1; count_i<=hotel_append_div_carosal; count_i++)
                {
              price=$('.exchange_price1_1_hotel_'+count_i+'').text();
              exchange_price.push(price);
              
                
                }
//console.log(exchange_price);
    //  console.log(exchange_price);
    
    
$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            url: "{{ url('convert_currency_by_alj2') }}",
            method: 'POST',
            data: {
                 "_token": "{{ csrf_token() }}",
                "currency": currency,
              
                "exchange_price": exchange_price,
                 "currency_slc_iso": currency_slc_iso,
            },
            success: function(result){
                 console.log(result);
          result.forEach(function fn(item, index) {
 var count=index + 1;
  console.log(item);
  
  $('.exchange_rate_country_price_hotel_'+count+'').html(currency+ ' ' + item);

  

})
                 //
                
               
             
              
            },
            error:function(error){
                console.log(error);
            }
        });
        
        
        
         $('#exchange_currency_ajt').on('change', function() {
                 $('.preloader').fadeIn();
                
                var currency = $(this).find(":selected").val();
                  var currency_slc_iso = $(this).find(":selected").attr('data-iso');
               
              var exchange_price = [];
                var hotel_append_div_carosal = $(".hotel_append_div_carosal").children().length;
                console.log('hotel_append_div_carosal'+hotel_append_div_carosal);
                for(var count_i=1; count_i<=hotel_append_div_carosal; count_i++)
                {
              price=$('.exchange_price1_1_hotel_'+count_i+'').text();
              exchange_price.push(price);
              
                
                }
//console.log(exchange_price);
    //  console.log(exchange_price);
    
    
$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            url: "{{ url('convert_currency_by_alj2') }}",
            method: 'POST',
            data: {
                 "_token": "{{ csrf_token() }}",
                "currency": currency,
                "exchange_price": exchange_price,
                "currency_slc_iso": currency_slc_iso,
            },
            success: function(result){
                 console.log(result);
          result.forEach(function fn(item, index) {
 var count=index + 1;
  console.log(item);
  $('.exchange_rate_country_price_hotel_'+count+'').html(currency+ ' ' + item);
  $('.preloader').fadeOut();

})
                 //
                
               
             
              
            },
            error:function(error){
                console.log(error);
            }
        });
        
            
 
  
    
    
});
        
        
        
        
        
        
        
             
    

});          
            

  
</script>
         
             <script>

    $(document).ready(function(){
            

 
  $(".owl-carousel").owlCarousel({
 
      autoPlay: 3000,
      items : 4,
      itemsDesktop : [1199,3],
      itemsDesktopSmall : [979,3],
      center: true,
      nav:true,
      loop:true,
      responsive: {
        600: {
          items: 4
        }
      }
  });
});
    let mainNavLinks = document.querySelectorAll(".hotel-nav ul li a");
let mainSections = document.querySelectorAll("main section");

let lastId;
let cur = [];


window.addEventListener("scroll", event => {
  let fromTop = window.scrollY;

  mainNavLinks.forEach(link => {
    let section = document.querySelector(link.hash);

    if (
      section.offsetTop <= fromTop &&
      section.offsetTop + section.offsetHeight > fromTop
    ) {
      link.classList.add("current");
    } else {
      link.classList.remove("current");
    }
  });
});
    </script>
 <script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("hotel-nav");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>
<script type="text/javascript">
    $(document).ready(function(){
        $('.travellanda_popup').hide();
        $('.travellanda_book').hide();
        $('.policy_hotelbeds').hide();
        // $('.travellanda_policy_append').html(" ");

  
 
$('.selected_travellanda').on('change',function(){    
        var opt_id = $('.selected_travellanda').val();
       
         var strArray = opt_id.split(" ");
          var optid = strArray[1];
         
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
                    type: 'POST',
                    url: '{{URL::to('')}}/policy',
                    data: {_token: CSRF_TOKEN,
                        'optid': optid,

                    },
                    success: function(msg){
                    var alert = JSON.parse(msg);
                    // console.log(alert);
                    var alert = "<p>"+alert['Alerts']['Alert']+"</p>";
                    // var policy = 
                    $('.policyappend').html(alert);
                   

                    
                    }
                    
            
            });
      
  });
  
  
  
  
  
  
$('.selected_travellanda').on('click',function(){    
        var opt_id = $('.selected_travellanda').val();
       
         var strArray = opt_id.split(" ");
          var optid = strArray[1];
         
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
                    type: 'POST',
                    url: '{{URL::to('')}}/policy',
                    data: {_token: CSRF_TOKEN,
                        'optid': optid,

                    },
                    success: function(msg){
                    var alert = JSON.parse(msg);
                    // console.log(alert);
                    var alert = "<p>"+alert['Alerts']['Alert']+"</p>";
                    // var policy = 
                    $('.policyappend').html(alert);
                   

                    
                    }
                    
            
            });
      
  });
  
  
  
  
  
  
  
  
  
  $('.travellanda_popup').on('click',function(){
      $('.policyappend').show();
  }); 
  $('.policy_close_btn').on('click',function(){
      $('.travellanda_book').show();
      $('.policy_button').hide();

  });
 
        $('.selected_webbeds').find('option').each(function() {
    // console.log($(this).val());
    var data = $(this).val();
     var strArray = data.split(" ");
    //  console.log(strArray);
    var p = strArray[0];
   var m = Math.min(p);
   
console.log(m);
$('.hotel_price').html(m);

});
       
      $('.selected_webbeds').on('change',function(){ 
    
        var room_price = $('.selected_webbeds').val();
         var strArray = room_price.split(" ");
        //  console.log(strArray);
    var p = strArray[0];
        $('.total_room_price').val(p);
      
      
  }); 
  $('.selected_travellanda').find('option').each(function() {
    // console.log($(this).val());
    var data = $(this).val();
     var strArray = data.split(" ");
    //  console.log(strArray);
    var p = strArray[0];
   var m = Math.min(p);
   
console.log(m);
$('.hotel_price_t').html(m);

});
       
      $('.selected_travellanda').on('change',function(){ 
    
        var room_price = $('.selected_travellanda').text();
         var strArray = room_price.split(" - ");
        //  console.log(strArray);
    var price = strArray[0];
        $('.total_room_price_t').html(price);
      
      
  });
  
  
  
  
  
  
  
  
  
  
  $(".selected_travellanda_room_list").change(function () {
    var room_type = $(this).find('option:selected').text();
    var room_type_opt = $(this).find('option:selected').attr('value');
    var strArray = room_type.split(" - ");
         console.log(room_type_opt);
    var type_price = strArray[0];
    //  console.log(room_price);
     $('.selected_travellanda').val(room_type);
     $('.t_otp_id').val(room_type_opt);
      $('.total_room_price_t').html(type_price);

    // $('#flights_departure_code').val(id)


 });
 
 
 
 
 
 
 
 
 
 
 
 $(".select-contain-select").change(function () {
    //  alert("hhfhf");
    var webbeds_room = $(this).find('option:selected').attr('value');
    var webbeds_room_name = $(this).find('option:selected').text();
    
    //  console.log(webbeds_room_name);
var strArray = webbeds_room_name.split(" - ");
        //  console.log(strArray);
    var type_price = strArray[0];
   
    // $('#flights_departure_code').val(id)

$(".webbedsselectedrom").val(webbeds_room);
$(".webbedsselectedromname").val(webbeds_room_name);
$(".total_room_price").html(type_price);


 }); 
 $(".hotelbeds_selected_type").change(function () {
      var hotelbeds_room = $(this).find('option:selected').attr('value');
      var hotelbeds_room_name = $(this).find('option:selected').text();
      var strArray = hotelbeds_room.split("$$");
         console.log(strArray);
    var p = strArray[1];
    var r = strArray[0];
 $('.policy_hotelbeds').show();
 $('.hotelbeds_selected_room').val(hotelbeds_room_name);
 $('.total_room_price_hotelbeds').html(p);
 $('.hotelbeds_selected_room_rate').val(r);

 });
 

 
 
 
 $('.selected_travellanda_room_list').on('change',function(){    
        var opt_id = $('.selected_travellanda').val();
       
         var strArray = opt_id.split(" ");
          var optid = strArray[1];
        //  console.log(opt_id);
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
                    type: 'POST',
                    url: '{{URL::to('')}}/policy',
                    data: {_token: CSRF_TOKEN,
                        'optid': optid,

                    },
                    success: function(msg){
                    var alert = JSON.parse(msg);
                    // console.log(alert);
                    var alert = "<p>"+alert['Alerts']['Alert']+"</p>";
                    // var policy = 
                    $('.policyappend').html(alert);
                   

                    
                    }
                    
            
            });
      
  });
  
  $('.travellanda_cancel_policy_btn').on('click',function(){
      var optid = $('.travellanda_cancel_policy_btn').val();
      
       var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
                    type: 'POST',
                    url: '{{URL::to('')}}/policy',
                    data: {
                        "_token": "{{ csrf_token() }}",
                        'optid': optid,

                    },
                    success: function(msg){
                    var policy = JSON.parse(msg);
                    console.log(policy);
                    var p = policy['Policies']['Policy'];
                    for (var i = 0; i < p.length; i++) {
      var po = `<li>${p[i].Value} ${p[i].Type} will be deducted on cancellation till ${p[i].From}</li>`;
                     
                  }
    // var po = 'ghhahaha';
                    var alert = "<p>Currency: "+policy['Currency']+"</p><p>TotalPrice: "+policy['TotalPrice']+"</p><p>CancellationDeadline: "+policy['CancellationDeadline']+"</p><p><b>"+policy['Alerts']['Alert']+"</p></b><b><ul>"+po+"</b></ul>";
                    // var policy = 
                    // $('.policyappend').html(alert);
                    // console.log(alert);
                    $('#hotelm_cancel_model').modal('show');
$('.travellanda_policy_append').html(alert);
                    
                    }
                    
            
            });
      
      
      
      
  }); 
  
  
 

});
    </script>
<script>

$('.selectrooms').change(function(){
    var room = $(this).attr('data-room');
    var amount = $(this).attr('data-amount');
    var room_type = $(this).attr('data-room-type');
    var room_id = $(this).attr('room-id');
    var room_quantity = $(this).attr('room-quantity');
    var room_for = $(this).attr('data-for');
    if ($(this).is(':checked')) {
        var total_rooms_selected = <?php echo $count_p; ?>;
        
        var total_rooms = $('#total_rooms_selected').val();
        total_rooms = parseInt(total_rooms);
        
        
        total_rooms_selected = parseInt(total_rooms_selected);
   
        var total_rooms = parseInt(total_rooms) + parseInt(room_quantity);
       
        if(total_rooms <= total_rooms_selected){
        
           
            $('#total_rooms_selected').val(total_rooms);
            var price = $('#total_room_price').html();
            price = parseFloat(amount) + parseFloat(price);
               price = price.toFixed(2);
            $('#total_room_price').html(price);
            var close = '<a rel="nofollow" class="close-button cursor-pointer" data-room-id="'+room_id+'" data-amount="'+amount+'" data-quantity="'+room_quantity+'" data-label="'+room_for+'" id="delete_room' + room_id + '">x</a>';
            $('#rooms_title').append('<p id="room_id_calculate' + room_id + '">'+ room_quantity + ' x ' + room_type + ' - ' + room + '- SAR' + amount + '</p>' + close);
        }else{
            this.checked = false;
            alert('Select the room according to the search criteria','danger');
            return 0;
        }
    }else{
        var price = $('#total_room_price').html();
        var total_rooms = $('#total_rooms_selected').val();
         total_rooms = parseInt(total_rooms) - parseInt(room_quantity);
         $('#total_rooms_selected').val(total_rooms);
        price = parseFloat(price) - parseFloat(amount);
         price = price.toFixed(2);
        $('#total_room_price').html(price);
        $('#rooms_title').find('#room_id_calculate' + room_id).remove();
         $('#rooms_title').find('#delete_room' + room_id).remove();
    }
    
})

$('.book_now').click(function(){
   
   var total_rooms_selected = <?php echo $count_p; ?>;
   var total_rooms = $('#total_rooms_selected').val();
   total_rooms = parseInt(total_rooms);
        
        
  total_rooms_selected = parseInt(total_rooms_selected);
 
  if(total_rooms == total_rooms_selected){
      $('#roomsform').submit();
      
    
  }else{
       alert('Select the room according to the search criteria','danger');
  }
 
   
  });
  $('.btn-check').change(function(){
    var id = $(this).attr('id');
   
    var check = $("label[for='"+$(this).attr("id")+"']");
    
      if ($(this).is(':checked')) {
         
          check.removeClass('btn-primary');
          check.addClass('btn-success');
      }else{
           check.removeClass('btn-success');
          check.addClass('btn-primary');
      }
});
                 
</script>
         
@endsection


