
@extends('template/frontend/includes/master')
@section('page_title')<?php if(isset($metaInfo) && $metaInfo != ''){echo $metaInfo->pageTitle;}?>@endsection


@section('keywords')
    <meta name="keywords" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->focus_keyword;
        }
    ?>"/>
@endsection
@section('page_meta_desc')
    <meta name="description" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->meta_description;
        }
    ?>"/>
@endsection
@section('page_meta_title')
    <meta name="title" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->metaTitle;
        }
    ?>"/>
@endsection
@section('content')

<!-- ================================
    START HERO-WRAPPER AREA
================================= -->

<!-- END / HEADING PAGE -->

          <section class="awe-parallax page-heading-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class="blog-heading-content text-uppercase">
                    <h2>Home > Complaints Policy</h2>
                </div>
            </div>
        </section>
        
         <section class="about-us-section mt-5">
            <div class="container">
                 
                  <div class="row">
                      <div class="col-sm-12 mt-5 mb-5"> 
                       <h3 class="text-center">Complaints Policy & Procedures</h3>
                      <p>Alhijaz Tours is well known within the Hajj and Umrah industry. We have a highly experienced team who know the ins and outs of Umrah and Hajj. We have immense experience on how traveling and accommodation work within Makkah and Medinah so we can make it easier for all pilgrims. Additionally, we have an abundance of knowledge on how one needs to perform their Hajj or Umrah and what they will need to take with them on their journey. We provide all the necessary information and keep our pilgrims updated at all times to make your travels easier. Our highly experienced and well versatile team is ready to take your queries.</p></div>
                      
                  </div>
                 
                 
            </div>
          
        </section>


<!-- start back-to-top -->
@endsection


@section('scripts')

@endsection
