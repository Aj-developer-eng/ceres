



@extends('template/frontend/includes/master')
<!-- PRELOADER -->
        <div class="preloader"></div>
        <!-- END / PRELOADER -->

@section('content')
 <!--Start CSS links for slider-->
    <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/revslider/public/assets/css/settings.css') }}">
     <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/plugins/combine/traveltour-style-custom.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/plugins/combine/style.css') }}">
       <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/include/css/page-builder.css') }}">
       <link rel="stylesheet" href="{{asset('public/invoice/assets/css/style.css')}}">
       
          <!--End CSS links for slider-->
<style>
.cs-bar_list {
  margin: 0;
  padding: 0;
  list-style: none;
  position: relative;
}

.cs-bar_list::before {
  content: '';
  height: 75%;
  width: 2px;
  position: absolute;
  left: 4px;
  top: 50%;
  -webkit-transform: translateY(-50%);
          transform: translateY(-50%);
  background-color: #eaeaea;
}

.cs-bar_list li {
  position: relative;
  padding-left: 25px;
}

.cs-bar_list li:before {
  content: '';
  height: 10px;
  width: 10px;
  border-radius: 50%;
  background-color: #eaeaea;
  position: absolute;
  left: 0;
  top: 6px;
}

.cs-bar_list li:not(:last-child) {
  margin-bottom: 10px;
}

.cs-table.cs-style1.cs-type1 {
  padding: 10px 30px;
}

.cs-table.cs-style1.cs-type1 tr:first-child td {
  border-top: none;
}

.cs-table.cs-style1.cs-type1 tr td:first-child {
  padding-left: 0;
}

.cs-table.cs-style1.cs-type1 tr td:last-child {
  padding-right: 0;
}

.cs-table.cs-style1.cs-type2 > * {
  padding: 0 10px;
}

.cs-table.cs-style1.cs-type2 .cs-table_title {
  padding: 20px 0 0 15px;
  margin-bottom: -5px;
}

.cs-table.cs-style2 td {
  border: none;
}

.cs-table.cs-style2 td,
.cs-table.cs-style2 th {
  padding: 12px 15px;
  line-height: 1.55em;
}

.cs-table.cs-style2 tr:not(:first-child) {
  border-top: 1px dashed #eaeaea;
}

.cs-list.cs-style1 {
  list-style: none;
  padding: 0;
  margin: 0;
}

.cs-list.cs-style1 li {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}

.cs-list.cs-style1 li:not(:last-child) {
  border-bottom: 1px dashed #eaeaea;
}

.cs-list.cs-style1 li > * {
  -webkit-box-flex: 0;
      -ms-flex: none;
          flex: none;
  width: 50%;
  padding: 7px 0px;
}

.cs-list.cs-style2 {
  list-style: none;
  margin: 0 0 30px 0;
  padding: 12px 0;
  border: 1px solid #eaeaea;
  border-radius: 5px;
}

.cs-list.cs-style2 li {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}

.cs-list.cs-style2 li > * {
  -webkit-box-flex: 1;
      -ms-flex: 1;
          flex: 1;
  padding: 5px 25px;
}
.cs-bar_list li:before{
    background-color: #e52828;
}
     .gdlr-core-ilightbox  img{
   
   height: 240px;
   width: 100%;

}
.hotel-images-section{
        padding-top: 150px;
} 
.traveltour-item-pdlr, .gdlr-core-item-pdlr {
    padding-left: 20px;
    padding-right: 20px;
}
.gdlr-core-image-overlay {
    background-color: #000000;
    background-color: rgba(0, 0, 0, 0.6);
}
.hotel-nav {
  white-space: nowrap;
  background: #37474F;
  z-index:99;
}
.hotel-nav ul {
  list-style: none;
  margin: 0;
  padding: 0;
}
/* Only stick if you can fit */

.hotel-nav ul li a {
  display: block;
  padding: 0.5rem 1rem;
  color: white;
  text-decoration: none;
}
.hotel-nav ul li a.current {
  background: black;
}

.sticky {
  position: fixed;
  top: 0;
  width: 100%;
}

.sticky + .content {
  padding-top: 102px;
}



/*page css*/
.tc{
     color: #d2b254 !important;
}
section{
    padding-top:60px;
}
.product-title h2{
     color: #d2b254;
         font-size: 26px
}
.product-detail__info .trips .item h6{
    font-size: 18px
}
.font-26{
    font-size: 24px
}
.accordion .ui-accordion-header{
    border: 1px solid #d2b254;
}
.item-from img, .item-to img{
    margin:0 auto;
}
.ui-accordion .ui-accordion-content {
    padding: 1em 2.2em;
}
.detail-sidebar {
    margin-top: 100px;
}
</style>
     <!-- BREADCRUMB -->
    
        
        
        
        
        <?php 
                                        $tour_gallery_images = json_decode($tour_details->gallery_images)
                                    ?>
        
     
        
        
     <section class="hotel-images-section ">
             
            <div class="gdlr-core-pbf-element">
                <div class="gdlr-core-gallery-item gdlr-core-item-pdb clearfix  gdlr-core-gallery-item-style-grid-no-space gdlr-core-item-pdlr ">
                    <div class="gdlr-core-gallery-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">
                       <div class="container">
                       <div class="row">
                           <div class="col-md-4" style="padding-right: 0%;">
                                @if(isset($tour_gallery_images))
                                       
                           
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15" style="width: 100% !important;">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{ config('img_url') }}/public/uploads/package_imgs/{{  $tour_gallery_images[0] }}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 100% !important;"  src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $tour_gallery_images[0] }}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                      
                                    @endif
                           </div>
                           <div class="col-md-8 d-none d-sm-block" style="padding-left: 0%;">
                                @if(isset($tour_gallery_images))
                           <?php 
                           $count=1;
                           ?>
                           
                          
                             @foreach($tour_gallery_images as $key => $gallery_res)
                            @if($key > 0)
                            @if($count <= 9)
                       
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{ config('img_url') }}/public/uploads/package_imgs/{{  $gallery_res }}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 160px;padding: 3px;" src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $gallery_res }}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                        @endif
                        @endif
                        <?php 
                           $count++;
                           ?>
                         @endforeach
                    @endif
                           </div>
                       </div>
                          </div>
                  
                    </div>
                </div>
            </div>
        </section>    
        <!--End Slider-->



<div calss="section-column-2">
     <nav class="navbar navbar-expand-lg navbar-dark hotel-nav" id="hotel-nav" >
                <div class="container">    
                  <ul class="navbar-nav">
                 <li><a href="#section-1">Overview</a></li>
                <li><a href="#section-2">Itinerary Schedule</a></li>
                <li><a href="#section-3">Flights</a></li>
                <li><a href="#section-4">Accomodation</a></li>
                <li><a href="#section-5">Transportion</a></li>
        
                <li><a href="#section-6">Visa</a></li>
                 <li><a href="#section-7">FAQ</a></li>
               
                  </ul>
        </div>

    </nav>
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-md-9">
                  <section id="section-1">
                    <div class="row">
                    <div class="col-md-12">
                         <div class="product-title">
                                <h2>{{ $tour_details->title }}</h2>
                            </div>
                            <div class="product-address">
                                <span>   <i class="fa-solid tc fa-location-dot"></i>   
                                
                                @if(isset($tour_details->tour_location) && $tour_details->tour_location != '' && $tour_details->tour_location != null &&  $tour_details->tour_location != 'null')
                                                @php 
                                                    $locations = json_decode($tour_details->tour_location)
                                                @endphp
                                                
                                                @foreach($locations as $loca_res)
                                                    {{ $loca_res }}
                                                @endforeach
                                            @endif
                                    | <i class="fa-solid tc fa-phone"></i> 0121 777 2522</span>
                            </div>
                        <p class="mt-3">{{ $tour_details->content }}</p>
                        
                    </div>
                    <div class="col-md-6">
                        <h6> <i class="fa-solid fa-person-circle-plus"></i> Whats Included?</h6>
                        <p>{{ $tour_details->whats_included }}</p>
                        </div>
                         <div class="col-md-6">
                        <h6><i class="fa-solid fa-person-circle-minus"></i>  Whats Excluded?</h6>
                        <p>{{ $tour_details->whats_excluded }}</p>
                        
                    
                    </div>
                </div>
                        <div class="product-detail__info">
                          
                            <div class="product-email">
                                <i class="fa fa-envelope"></i>
                                <a href="#">Send Email Inquiry</a>
                            </div>

                            <div class="trips">
                                <div class="item">
                                    <h6>  Departure Date</h6>
                                    <p><i class="fa tc fa-calendar" aria-hidden="true"></i> {{  date("d-m-Y", strtotime($tour_details->start_date)) }}</p>
                                   
                                </div>
                                 <div class="item">
                                    <h6> Return Date</h6>
                                    
                                    <p><i class="fa tc fa-calendar" aria-hidden="true"></i> {{ date("d-m-Y", strtotime($tour_details->end_date)) }}</p>
                                </div>
                                <div class="item">
                                    <h6>Time length</h6>
                                    <p><i class="fa-regular tc fa-moon"></i> {{ $tour_details->time_duration }} Nights</p>
                                </div>
                                <div class="item">
                                    <h6>Category</h6>
                                    <p><i class="fa-solid tc fa-clipboard-check"></i> {{ $category_name }}</p>
                                </div>
                                <div class="item">
                                    <h6>Transport included</h6>
                                    <p><i class="fa fa-bus tc" aria-hidden="true"></i> 
                                        @if(isset($transportation_details))
                                        {{  $transportation_details->transportation_vehicle_type }}
                                        @endif
                                    </p>
                                </div>
                                <div class="item">
                                    <h6>Destinations</h6>
                                    <p title="Makkah, Madina"><i class="fa-solid tc fa-building-circle-check"></i> 
                                    @if(isset($tour_details->tour_location[0])  && $tour_details->tour_location != '' && $tour_details->tour_location != null &&  $tour_details->tour_location != 'null')
                                    
                                        @php 
                                            $locations = json_decode($tour_details->tour_location)
                                        @endphp
                                        
                                       
                                        @foreach($locations as $loca_res)
                                            {{ $loca_res }},
                                        @endforeach
                                        
                                    @endisset
                                        
                                    </p>
                                </div>
                                <div class="item">
                                     <a  class="font-26" href="#" data-bs-toggle="modal" data-bs-target="#exampleModal1">
                                      <i class="fa-regular fa-calendar-xmark"></i> Cancellation Policy ?
                                    </a>
                             
                               
                                </div>
                            </div>

                            <!-- <div class="rating-trip-reviews">
                                <div class="item good">
                                    <span class="count">7.5</span>
                                    <h6>Average rating</h6>
                                    <p>Good</p>
                                </div>
                                <div class="item">
                                    <h6>TripAdvisor ></h6>
                                    <img src="images/trips.png" alt="">
                                </div>
                                <div class="item">
                                    <h6>Reviews</h6>
                                    <p>No review yet</p>
                                </div>
                            </div> -->

                            <table class="ticket-price">
                                <thead>
                                   <tr>
                                        @if($tour_details->double_grand_total_amount != 0 AND $tour_details->double_grand_total_amount != null) 
                                        <th class="adult"><span>Double Price</span></th>
                                        @endif
                                         <?php
                                         if($tour_details->triple_grand_total_amount!= 0 AND $tour_details->triple_grand_total_amount!= null){ 
                                         ?>
                                        <th class="adult"><span>Triple Price</span></th>
                                        <?php
                                        }
                                        ?>
                                        
                                         @if($tour_details->quad_grand_total_amount != 0 AND $tour_details->quad_grand_total_amount != null) 
                                        <th class="kid"><span>Quad Price</span></th>
                                        @endif
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <tr>
                                        @if($tour_details->double_grand_total_amount != 0 AND $tour_details->double_grand_total_amount != null) 
                                        <td class="adult">
                                          <ins>
                                                <span class="amount">{{ $tour_details->currency_symbol." ".$tour_details->double_grand_total_amount ?? '0' }}</span>
                                            </ins>
                                        </td>
                                        @endif
                                        @if($tour_details->triple_grand_total_amount != 0 AND $tour_details->triple_grand_total_amount != null) 
                                        <td class="adult">
                                            <ins>
                                                <span class="amount">{{ $tour_details->currency_symbol." ".$tour_details->triple_grand_total_amount ?? '0' }}</span>
                                            </ins>
                                           
                                        </td>
                                        @endif
                                        @if($tour_details->quad_grand_total_amount != 0 AND $tour_details->quad_grand_total_amount != null) 
                                        <td class="kid">
                                            <ins>
                                                <span class="amount">{{ $tour_details->currency_symbol." ".$tour_details->quad_grand_total_amount ?? '0' }}</span>
                                            </ins>
                                            <!--<del>-->
                                            <!--    <span class="amount">{{ $tour_details->currency_symbol }} {{ $tour_details->double_grand_total_amount }}.00</span>-->
                                            <!--</del>-->
                                        </td>
                                        @endif
                                    </tr>
                                </tbody>
                            </table>


                        </div>
                </section>
               
              
                 <section id="section-2">
                                <h3>Itinerary Schedule</h3>
                                    <div class="trip-schedule-accordion accordion">
                                    @php $itineraryDetails = json_decode($tour_details->Itinerary_details);
                                            $x=1;    
                                        @endphp
                                        @if($itineraryDetails[0]->Itinerary_title !== null)
                                        @foreach($itineraryDetails as $itnary_res)
                                        <h3>Day #1 {{ $itnary_res->Itinerary_title }} : {{ $itnary_res->Itinerary_city }}</h3>
                                        <div>
                                           <div class="row">
                                                <div class="col-md-4">
                                                         <img src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $itnary_res->Itinerary_image }}" alt="destination-img">
                                                      </div>
                                                <div class="col-md-8">
                                                <h6>Description</h6>
                                                <p class="text-justify-content">{{ $itnary_res->Itinerary_content }}</p>
                                            </div>
                                            </div>
                                            
                                           
                                        </div>
                                        @php $x++ @endphp
                                        @endforeach
                                        @endif

                                        @php $itineraryDetails = json_decode($tour_details->Itinerary_details);
                                            $x=1;    
                                        @endphp
                                        @if(isset($iternery1))
                                        @foreach($iternery1 as $itnary_res)
                                        <h3> Day #2 {{ $itnary_res->more_Itinerary_title }} : {{ $itnary_res->more_Itinerary_city }}</h3>
                                        <div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                     <img src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $itnary_res->more_Itinerary_image }}" alt="destination-img">

                                                </div>
                                                <div class="col-md-8">
                                                    <h6>Description</h6>
                                                    <p class="text-justify-content">{{ $itnary_res->more_Itinerary_content }}</p>
                                                </div>
                                            </div>
                                            
                                           
                                        </div>
                                        @php $x++ @endphp
                                        @endforeach
                                        @endif
                                     
                                    </div>
                             
                </section>
                 <section id="section-3">
                    <h3>Flight Details</h3>
                    
                  
                                   
                                     @if(isset($flights_details))
                                     
                                     <?php 
                                        if(isset($flights_details_more)){
                                            $arr_size = sizeOf($flights_details_more);
                                            $first_depaurture = $flights_details_more[0]->more_departure_airport_code;
                                            $last_destination = $flights_details_more[$arr_size - 1]->more_arrival_airport_code;
                                            
                                            
                                            $first_dep_time = date("d-m-Y h:i:sa", strtotime($flights_details_more[0]->more_departure_time)); 
                                            $last_arrival = date("d-m-Y h:i:sa", strtotime($flights_details_more[$arr_size - 1]->more_arrival_time)); 
                                            
                                            $departure_time_original = $flights_details_more[0]->more_departure_time;
                                            $arrival_time_original = $flights_details_more[$arr_size - 1]->more_arrival_time;
                                            
                                        }else{
                                            $last_destination = $flights_details->arrival_airport_code;
                                            $first_depaurture = $flights_details->departure_airport_code;
                                            
                                            $last_arrival = date("d-m-Y h:i:sa", strtotime($flights_details->arrival_time)); 
                                            $first_dep_time = date("d-m-Y h:i:sa", strtotime($flights_details->departure_time)); 
                                            
                                            $departure_time_original = $flights_details->departure_time;
                                            $arrival_time_original = $flights_details->arrival_time;
                                        }
                                        
                                        $departure_time_obj = new DateTime($departure_time_original);
                                        $arrival_time_obj = new DateTime($arrival_time_original);
                                        
                                        $departure_total_interval = $departure_time_obj->diff($arrival_time_obj);
    
                                        // echo ($interval->format("%a") * 24) + $interval->format("%h"). " hours". $interval->format(" %i minutes ");
                                        
                                     ?>
                                    
                                      <div class="row">
                                           @if($flights_details->flight_type !== 'Indirect')
                                            <div class="col-md-6">
                                                <h6>Depart</h6>
                                                
                                                 <div class="row">
                                                    <div class="col-md-8 offset-md-4">
                                                        <h6 style="font-size:1.4rem; font-weigth:500">{{ date("H:i", strtotime($flights_details->departure_time)) }} <span style="font-size:30px; margin:1rem;">&#8594</span> {{ date("H:i", strtotime($flights_details->arrival_time)) }}</h6>
                                                        <h6 class="mt-4" style="font-size:.9rem; font-weigth:500" >{{  $flights_details->other_Airline_Name2 ?? '' }}</h6>
                                                        <h6 style="font-size:.9rem; font-weigth:500">
                                                        <?php
                                                                 
                                                              $dateValue = strtotime(date("d-m-Y", strtotime($flights_details->departure_time ?? '' )));
                                                     
                                                                $year = date('Y',$dateValue);
                                                                $monthName = date('F',$dateValue);
                                                                $monthNo = date('d',$dateValue);
                                                                $day = date('l', $dateValue);
                                                                echo $day . ',' . $monthNo . ',' . $monthName . ',' . $year;
                                                                // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                                                              ?>
                                                            </h6>
                                                    </div>
                                                    
                                                     <div class="col-md-2 text-center">
                                                        <div class="item-thumb">
                                                            <div class="image-thumb">
                                                                <img src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $flights_details->flights_image }}" style="width:100%" alt="">
                                                            </div>
                                                           
                                                        </div>
                                                    </div>
                                                    <div class="col-md-10">
                                                         
                                                       
                                                              
                                                              
                                                             
                                                         <ul class="cs-bar_list">
                                                             <li><b class="cs-primary_color"><i class="fa-solid fa-plane-departure"></i> </b>
                                                                <span class="time">{{ date("H:i", strtotime($flights_details->departure_time)) }}</span><span> {{  $flights_details->departure_airport_code }}</span>
                                                             </li>
                                                             
                                                              <li><b class="cs-primary_color"><i class="fa-solid fa-plane-arrival"></i></b>
                                                                <span class="time">{{ date("H:i", strtotime($flights_details->arrival_time)) }}</span><span>{{  $flights_details->arrival_airport_code }}</span>
                                                             </li>
                                                         </ul>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <h6>Return</h6>
                                                 <div class="row">
                                                    <div class="col-md-8 offset-md-4">
                                                        <h6 style="font-size:1.4rem; font-weigth:500">{{ date("H:i", strtotime($flights_details->return_departure_time)) }} <span style="font-size:30px; margin:1rem;">&#8594</span> {{ date("H:i", strtotime($flights_details->return_arrival_time)) }}</h6>
                                                        <h6 class="mt-4" style="font-size:.9rem; font-weigth:500" >{{  $flights_details->return_other_Airline_Name2 ?? '' }}</h6>
                                                        <h6 style="font-size:.9rem; font-weigth:500">
                                                        <?php
                                                                 
                                                              $dateValue = strtotime(date("d-m-Y", strtotime($flights_details->return_departure_time ?? '' )));
                                                     
                                                                $year = date('Y',$dateValue);
                                                                $monthName = date('F',$dateValue);
                                                                $monthNo = date('d',$dateValue);
                                                                $day = date('l', $dateValue);
                                                                echo $day . ',' . $monthNo . ',' . $monthName . ',' . $year;
                                                                // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                                                              ?>
                                                            </h6>
                                                    </div>
                                                    
                                                     <div class="col-md-2 text-center">
                                                        <div class="item-thumb">
                                                            <div class="image-thumb">
                                                                <img src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $flights_details->flights_image }}" style="width:100%" alt="">
                                                            </div>
                                                            <div class="text">
                                                                <p class="mb-1">{{  $flights_details->return_departure_flight_number }}</p>
                                                                <span>{{  $flights_details->return_departure_Flight_Type ?? '' }}</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-10">
                                                         
                                                       
                                                              
                                                              
                                                             
                                                         <ul class="cs-bar_list">
                                                             <li><b class="cs-primary_color"><i class="fa-solid fa-plane-departure"></i> </b>
                                                                <span class="time">{{ date("H:i", strtotime($flights_details->return_departure_time)) }}</span><span> {{  $flights_details->return_departure_airport_code }}</span>
                                                             </li>
                                                             
                                                              <li><b class="cs-primary_color"><i class="fa-solid fa-plane-arrival"></i></b>
                                                                <span class="time">{{ date("H:i", strtotime($flights_details->return_arrival_time)) }}</span><span>{{  $flights_details->return_arrival_airport_code }}</span>
                                                             </li>
                                                         </ul>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            @endif
                                       <div class="col-md-6">
                                           <div class="row">
                                                @if(isset($flights_details_more))
                                                     @foreach($flights_details_more as $more_fl_res)
                                                     <div class="col-md-12">
                                                <h6 class="mt-4">Depart</h6>
                                                
                                                 <div class="row">
                                                    <div class="col-md-8 offset-md-4">
                                                        <h6 style="font-size:1.4rem; font-weigth:500">{{ date("H:i", strtotime($more_fl_res->more_departure_time)) }} <span style="font-size:30px; margin:1rem;">&#8594</span> {{ date("H:i", strtotime($more_fl_res->more_arrival_time)) }}</h6>
                                                        <h6 class="mt-4" style="font-size:.9rem; font-weigth:500" >{{  $more_fl_res->more_other_Airline_Name2 ?? '' }}</h6>
                                                        <h6 style="font-size:.9rem; font-weigth:500">
                                                        <?php
                                                                 
                                                              $dateValue = strtotime(date("d-m-Y", strtotime($more_fl_res->more_departure_time ?? '' )));
                                                     
                                                                $year = date('Y',$dateValue);
                                                                $monthName = date('F',$dateValue);
                                                                $monthNo = date('d',$dateValue);
                                                                $day = date('l', $dateValue);
                                                                echo $day . ',' . $monthNo . ',' . $monthName . ',' . $year;
                                                                // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                                                              ?>
                                                            </h6>
                                                    </div>
                                                    
                                                     <div class="col-md-2 text-center">
                                                        <div class="item-thumb">
                                                            <div class="image-thumb">
                                                                <img src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $flights_details->flights_image }}" style="width:100%" alt="">
                                                            </div>
                                                            
                                                        </div>
                                                    </div>
                                                    <div class="col-md-10">
                                                         
                                                       
                                                              
                                                              
                                                             
                                                         <ul class="cs-bar_list">
                                                             <li><b class="cs-primary_color"><i class="fa-solid fa-plane-departure"></i> </b>
                                                                <span class="time">{{ date("H:i", strtotime($more_fl_res->more_departure_time)) }}</span><span> {{  $more_fl_res->more_departure_airport_code }}</span>
                                                             </li>
                                                             
                                                              <li class="mt-5"><b class="cs-primary_color"><i class="fa-solid fa-plane-arrival"></i></b>
                                                                <span class="time">{{ date("H:i", strtotime($more_fl_res->more_arrival_time)) }}</span><span>{{  $more_fl_res->more_arrival_airport_code }}</span>
                                                             </li>
                                                         </ul>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                                     @endforeach
                                             @endif
                                           </div>
                                       </div>     
                                            
                                        <div class="col-md-6">
                                            <div class="row">
                                                 @if(isset($flights_details_more))
                                                     @foreach(array_reverse($flights_details_more) as $more_fl_res)
                                                     
                                                      <div class="col-md-12">
                                                <h6 class="mt-4">Return</h6>
                                                
                                                 <div class="row">
                                                    <div class="col-md-8 offset-md-4">
                                                        <h6 style="font-size:1.4rem; font-weigth:500">{{ date("H:i", strtotime($more_fl_res->return_more_departure_time)) }} <span style="font-size:30px; margin:1rem;">&#8594</span> {{ date("H:i", strtotime($more_fl_res->return_more_arrival_time)) }}</h6>
                                                        <h6 class="mt-4" style="font-size:.9rem; font-weigth:500" >{{  $more_fl_res->return_more_other_Airline_Name2 ?? '' }}</h6>
                                                        <h6 style="font-size:.9rem; font-weigth:500">
                                                        <?php
                                                                 
                                                              $dateValue = strtotime(date("d-m-Y", strtotime($more_fl_res->return_more_departure_time ?? '' )));
                                                     
                                                                $year = date('Y',$dateValue);
                                                                $monthName = date('F',$dateValue);
                                                                $monthNo = date('d',$dateValue);
                                                                $day = date('l', $dateValue);
                                                                echo $day . ',' . $monthNo . ',' . $monthName . ',' . $year;
                                                                // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                                                              ?>
                                                            </h6>
                                                    </div>
                                                    
                                                     <div class="col-md-2 text-center">
                                                        <div class="item-thumb">
                                                            <div class="image-thumb">
                                                                <img src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $flights_details->flights_image }}" style="width:100%" alt="">
                                                            </div>
                                                           
                                                        </div>
                                                    </div>
                                                    <div class="col-md-10">
                                                         
                                                       
                                                              
                                                              
                                                             
                                                         <ul class="cs-bar_list">
                                                             <li><b class="cs-primary_color"><i class="fa-solid fa-plane-departure"></i> </b>
                                                                <span class="time">{{ date("H:i", strtotime($more_fl_res->return_more_departure_time)) }}</span><span> {{  $more_fl_res->return_more_departure_airport_code }}</span>
                                                             </li>
                                                             
                                                              <li class="mt-5"><b class="cs-primary_color"><i class="fa-solid fa-plane-arrival"></i></b>
                                                                <span class="time">{{ date("H:i", strtotime($more_fl_res->return_more_arrival_time)) }}</span><span>{{  $more_fl_res->return_more_arrival_airport_code }}</span>
                                                             </li class="mt-5">
                                                         </ul>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        
                                                     @endforeach
                                                     @endif
                                            </div>
                                        </div>
                                              
                                            
                                            
                                              
                                        </div>
                    
                                    
                                    @endif
                                
                 </section>
                 <section id="section-4">
                      
                                    
                                     @if(isset($accomodation_details))
                                         @foreach($accomodation_details as $acc_res)
                                            <div class="hotel-details-top">
                                                <h4>{{  $acc_res->hotel_city_name }} Hotel Details</h4>
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <img src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $acc_res->accomodation_image }}" alt="">
                                                    </div>
                                                    <div class="col-sm-4">
                                                         <h5>Available Rooms</h5>
                                                         <span>  <i class="fa-solid fa-bed"></i> {{ $acc_res->acc_type }}</span>
                                                            @if(isset($accomodation_details_more))
                                                                @foreach($accomodation_details_more as $acc_more_res)
                                                                    @if($acc_more_res->more_hotel_city == $acc_res->hotel_city_name)
                                                                   
                                                                      <span>  <i class="fa-solid fa-bed"></i> {{ $acc_more_res->more_acc_type }}</span>
                                                                    @endif
                                                                @endforeach
                                                            @endif
                                                         <ul class="list-unstyled mt-3">
                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> Check In  : {{  date("d-m-Y", strtotime($acc_res->acc_check_in)) }}</li>
                                                            <li><i class="fa fa-calendar" aria-hidden="true"></i> Check Out : {{  date("d-m-Y", strtotime($acc_res->acc_check_out)) }}</li>
                                                            <li><i class="fa fa-moon-o" aria-hidden="true"></i> No Of Nights : {{  $acc_res->acc_no_of_nightst }}</li>
                                                        </ul>
                                                       
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <h5>Room Amenities </h5>
                                                        {{  $acc_res->hotel_whats_included }}
                                                    </div>
                                                    
                                                </div>    
                                            </div>        
                                        @endforeach
                                        @endif  
                                        
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                      
                                        
                               
                  </section>
                 <section id="section-5">
                         <h3>Transfer Details</h3>
                                    @if(isset($transportation_details))
                                        <table class="initiative-table">
                                                <tbody>
                                                    <tr>
                                                        <th>
                                                            <div class="item-thumb">
                                                                <div class="image-thumb">
                                                                    <img src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $transportation_details->transportation_image }}" alt="">
                                                                </div>
                                                                <div class="text">
                                                                    <span>Vehicle: {{  $transportation_details->transportation_vehicle_type }}</span>
                                                                </div>
                                                            </div>
                                                        </th>
                                                        <td>
                                                            <div class="item-body">
                                                                <div class="item-from">
                                                                    <h3 style="font-size:1.1rem;">Pickup Location</h3>
                                                                    <h6 style="font-size:1rem;">{{  $transportation_details->transportation_pick_up_location }}</h6>
                                                                   <?php 
                                                                    if($transportation_details->transportation_pick_up_date != ''){
                                                                        $pickup_date = date("d-m-Y", strtotime($transportation_details->transportation_pick_up_date));
                                                                        $pickup_time = date("h:i:sa", strtotime($transportation_details->transportation_pick_up_date));
                                                                    }else{
                                                                        $pickup_date = '';
                                                                        $pickup_time = '';
                                                                    }
                                                                    
                                                                    if($transportation_details->transportation_drop_off_location != ''){
                                                                        $drop_off_date = date("d-m-Y", strtotime($transportation_details->transportation_drop_off_location));
                                                                        $drop_off_time = date("h:i:sa", strtotime($transportation_details->transportation_drop_off_location));
                                                                    }else{
                                                                        $drop_off_date = '';
                                                                        $drop_off_time = '';
                                                                    }
                                                                   ?>
                                                                   <h6 style="font-size:.8rem; margin-bottom: 0.5rem;">Pickup Date:{{ $pickup_date  }} </h6>
                                                                   <h6 style="font-size:.8rem; ">Pickup Date:{{ $pickup_time  }} </h6>
                                                                   
                                                                   
                                                                   
                                                                </div>
                                                                <div class="item-time">
                                                                    <i class="fa fa-clock-o"></i>
                                                                    <span>{{ $transportation_details->transportation_total_Time }}</span>
                                                                </div>
                                                                <div class="item-to">
                                                                     <h3 style="font-size:1.1rem;">Drop off Location</h3>
                                                                    <h6 style="font-size:1rem;">{{  $transportation_details->transportation_drop_off_location }}</h6>
                                            
                                                                    <h6 style="font-size:.8rem; margin-bottom: 0.5rem;">Drop off Date:{{ $drop_off_date }} </h6>
                                                                   <h6 style="font-size:.8rem; ">Drop off Time{{ $drop_off_time }} </h6>

                                                                </div>
                                                            </div>
                                                        </td>
                                                        
                                                    </tr>
                                                     @if($transportation_details->transportation_trip_type == 'Return')
                                                      <tr>
                                                        <th>
                                                            <div class="item-thumb">
                                                                <div class="image-thumb">
                                                                </div>
                                                                <div class="text">
                                                                  
                                                                </div>
                                                            </div>
                                                        </th>
                                                         <td>
                                                            <div class="item-body">
                                                                <div class="item-from">
                                                                    <h3>{{  $transportation_details->return_transportation_pick_up_location }}</h3>
                                                                   
                                                                     <h6 style="font-size:.8rem; margin-bottom: 0.5rem;">{{ date("d-m-Y", strtotime($transportation_details->return_transportation_pick_up_date)) }}</h6>
                                                                   <h6 style="font-size:.8rem; ">{{ date("h:i:sa", strtotime($transportation_details->return_transportation_pick_up_date)) }}</h6>
                                                                   
                                                                   
                                                                </div>
                                                                <div class="item-time">
                                                                    <i class="fa fa-clock-o"></i>
                                                                    <span>Retrun</span>
                                                                </div>
                                                                <div class="item-to">
                                                                    <h3>{{  $transportation_details->return_transportation_drop_off_location }}</h3>
                                                                    <h6 style="font-size:.8rem; margin-bottom: 0.5rem;">{{ date("d-m-Y", strtotime($transportation_details->return_transportation_drop_of_date)) }}</h6>
                                                                   <h6 style="font-size:.8rem; ">{{ date("h:i:sa", strtotime($transportation_details->return_transportation_drop_of_date)) }}</h6>
                                                                   
                                                                   
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    
                                                    
                                                    @endif
                                                    
                                                    @if(isset($transportation_details_more))
                                                    @foreach($transportation_details_more as $tran_more)
                                                      <tr>
                                                        <th>
                                                            <div class="item-thumb">
                                                                <div class="image-thumb">
                                                                </div>
                                                                <div class="text">
                                                                  
                                                                </div>
                                                            </div>
                                                        </th>
                                                         <td>
                                                            <div class="item-body">
                                                                <div class="item-from">
                                                                    <h3>{{  $tran_more->more_transportation_pick_up_location }}</h3>
                                                                     <h6 style="font-size:.8rem; margin-bottom: 0.5rem;">{{ date("d-m-Y", strtotime($tran_more->more_transportation_pick_up_date)) }}</h6>
                                                                   <h6 style="font-size:.8rem; ">{{ date("h:i:sa", strtotime($tran_more->more_transportation_pick_up_date)) }}</h6>
                                                                   
                                                                
                                                                   
                                                                </div>
                                                                <div class="item-time">
                                                                    <i class="fa fa-clock-o"></i>
                                                                    <span>Others</span>
                                                                </div>
                                                                <div class="item-to">
                                                                    <h3>{{  $tran_more->more_transportation_drop_off_location }}</h3>
                                                                   
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                     @endforeach
                                                     @endif
                                            
                                                    
                    
                                                       
                                                
                                                </tbody>
                                            </table>
                                             @endif
                                        
                              
                       
                    </section>
                <section id="section-6">
                   <h3>Visa Details</h3>
                                    @if(isset($tour_details->transportation_details))
                                        <table class="initiative-table">
                                                <tbody>
                                                    <tr>
                                                        <th>
                                                            <div class="item-thumb">
                                                                <div class="image-thumb">
                                                                    <img src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $tour_details->visa_image }}" alt="">
                                                                </div>
                                                            </div>
                                                        </th>
                                                        <td>
                                                            <div class="item-body">
                                                                <div class="row">
                                                                    <div class="col-md-4"><h6 style="font-size:18px;">Visa Type</h6>
                                                                        <h6 style="font-size:14px; font-weight:100; text-transform: capitalize;">{{  $visa_type }}</h6>
                                                                    </div>
                                                                    <div class="col-md-8"><h6 style="font-size:18px;">Visa Requirements</h6>
                                                                    <h6 style="font-size:14px; font-weight:100;">{{  $tour_details->visa_rules_regulations }}</h6>
                                                                    
                                                                    </div>
                                                                    
                                                                </div>
                                                            </div>
                                                        </td>
                                                        
                                                    </tr>
                                               
                                                    
                    
                                                       
                                                
                                                </tbody>
                                            </table>
                                             @endif
                                        
                                
                </section>    
                <section id="section-7 mb-5">
                    <h3>frequently asked questions</h3>
                                    <div class="trip-schedule-accordion accordion">
                                    @php $faqDetails = json_decode($tour_details->tour_faq);
                                            $x=1; 
                                        @endphp
                                        @if($faqDetails[0]->faq_title != null)
                                        @foreach($faqDetails as $faq_res)
                                        <h3>{{ $faq_res->faq_title }} </h3>
                                        <div>
                                            <div class="tour-map-wrapper pl-3">
                                              
                                                <p>{{ $faq_res->faq_content }}</p>
                                            </div>
                                            <br>
                                           
                                        </div>
                                        @php $x++ @endphp
                                        @endforeach
                                        @endif
                         

                                        @if(isset($tour_faq_1))
                                        @foreach($tour_faq_1 as $faq_res)
                                        <h3>{{ $faq_res->more_faq_title }}</h3>
                                        <div>
                                            <div class="row">
                                                 <div class="col-md-12">
                                                    <p>{{ $faq_res->more_faq_content }}</p>
                                                </div>
                                                
                                            </div>
                                            
                                           
                                        </div>
                                        @endforeach
                                        @endif

                                     
                                    </div>
                             
                    
                </section>
    
    <!--<div class="owl-carousel2 owl-theme">-->
    <!--    <div class="item"><h4>1</h4></div>-->
    <!--    <div class="item"><h4>2</h4></div>-->
    <!--    <div class="item"><h4>3</h4></div>-->
    <!--    <div class="item"><h4>4</h4></div>-->
    <!--    <div class="item"><h4>5</h4></div>-->
    <!--    <div class="item"><h4>6</h4></div>-->
    <!--    <div class="item"><h4>7</h4></div>-->
    <!--    <div class="item"><h4>8</h4></div>-->
    <!--    <div class="item"><h4>9</h4></div>-->
    <!--    <div class="item"><h4>10</h4></div>-->
    <!--    <div class="item"><h4>11</h4></div>-->
    <!--    <div class="item"><h4>12</h4></div>-->
    <!--</div>-->
                
                
                
               
            </div>
            
            <!--end of colum 8-->
            <div class="col-sm-4 col-md-3">
                 <div class="detail-sidebar">
                            <div class="call-to-book">
                                <i class="awe-icon awe-icon-phone"></i>
                                <em>Call to book</em>
                                <span>0121 777 2522</span>
                            </div>
                            <form action="{{ route('add.to.cart') }}" method="post">
                            @csrf
                            <div class="booking-info">
                                <h3>Booking info</h3>
                                <a  href="#" data-bs-toggle="modal" data-bs-target="#exampleModal1">
                                   Cancellation Policy ?
                                </a>
                                
                           
        
                                <div class="form-select-date">
                                    <div class="form-elements">
                                        <label>Travel Date</label>
                                        <div class="form-item">
                                            <i class="awe-icon awe-icon-calendar"></i>
                                            <input type="text"  readonly class="form-control" value="{{ date("d-m-Y", strtotime($tour_details->start_date)).' '.date("d-m-Y", strtotime($tour_details->end_date)) }}">
                                            <input type="text" name="pakage_type" hidden value="tour">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-elements form-adult">
                                        <label>Adult</label>
                                        <div class="form-item">
                                            <input type="text" hidden name="toure_id" value="{{ $tour_details->id }}">
                                            <select name="adults" id="adults" class="awe-select">
                                                <option>0</option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                                <option>6</option>
                                                <option>7</option>
                                                <option>8</option>
                                                <option>9</option>
                                                <option>10</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-elements form-kids">
                                        <label>Children</label>
                                        <div class="form-item">
                                            <select name="childs" class="awe-select">
                                            <option>0</option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                                <option>6</option>
                                                <option>7</option>
                                                <option>8</option>
                                                <option>9</option>
                                                <option>10</option>
                                            </select>
                                        </div>
                                        <!--<span>11 and under</span>-->
                                    </div>
                                </div>
                                   <div class="form-group mt-2 ">
                                     
                                        <label><strong>Select Package</strong></label>
                                        @if($tour_details->double_grand_total_amount != 0 AND $tour_details->double_grand_total_amount != null) 
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input type="radio" checked class="custom-control-input" id="room1" name="sharing" value="sharing2">
                                            <label title="If One(1), then will be shared with another person."  class="custom-control-label" for="room1">Double Price <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span>{{ $tour_details->currency_symbol." ".$tour_details->double_grand_total_amount ?? '0' }}</span></label>
                                        </div>
                                         @endif
                                         @if($tour_details->triple_grand_total_amount != 0 AND $tour_details->triple_grand_total_amount != null) 
                                        <div class="custom-control custom-radio custom-contANDol-inline">
                                            <input type="radio" checked class="custom-control-input" id="room2" name="sharing" value="sharing3">
                                            <label  title="If less than three(3), then will be shared with another person." class="custom-control-label" for="room2">Triple  Price <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$tour_details->triple_grand_total_amount ?? '0' }}</span></label>
                                        </div>
                                         @endif
                                        @if($tour_details->quad_grand_total_amount != 0 AND $tour_details->quad_grand_total_amount != null) 
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input type="radio" checked class="custom-control-input" id="room3" name="sharing" value="sharing4">
                                            <label title="If less than four(4), then will be shared with another person." class="custom-control-label" for="room3">Quad  Price <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$tour_details->quad_grand_total_amount ?? '0' }}</span></label>
                                        </div>
                                         @endif
        
                                      </div>
                                      
                                      
                                      
                                      
                                      
                                      
                                      @if(isset($additional_service))
                                      <div class="widget widget_has_radio_checkbox">
                                        <h3>Additional Services   
                                            <button type="button" class="border border-light" data-bs-toggle="tooltip" data-bs-placement="top" title="Select Additional Services(Per Person)">
                                                <i class="fa fa-info-circle" aria-hidden="true"></i>
                                            </button>
                                        
                                        </h3>
                                        <ul>
                                            <li>
                                                <label>
                                                    <input type="checkbox" onclick="checkPerPerson('{{ $additional_service[0]->extra_price_person }}','service1','first_checkbox_div',{{ $additional_service[0]->extra_price_type }})" class="custom-control-input" id="service1"  name="additonal_service1" value="{{ $additional_service[0]->extra_price_name }}">
                                                    <i class="awe-icon awe-icon-check"></i>
                                                   {{ $additional_service[0]->extra_price_name }}  
                                                    (<?php if($additional_service[0]->extra_price_type == 0){
                                                            echo "One-Time";
                                                       } 
                                                
                                                        if($additional_service[0]->extra_price_type == 2){
                                                            echo "Per-Day";
                                                        }
                                                      
                                                    ?>)
                                                   <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$additional_service[0]->extra_price_price }}</span>
                                                </label>
                                                 <div id="first_checkbox_div">
                                                 </div>
                                            </li>
                                        @if(isset($additional_service_more))
                                         <?php $x= 2; ?>
                                            @foreach($additional_service_more as $service_res)
                                            <li>
                                                <label>
                                                    <input type="checkbox" id="chechbox{{ $x }}" onclick="checkPerPerson('{{ $service_res->more_extra_price_person }}','chechbox{{ $x }}','first_checkbox{{ $x }}',{{ $service_res->more_extra_price_type }})"  name="additonal_service[]" value="{{ $service_res->more_extra_price_title }}">
                                                    <i class="awe-icon awe-icon-check"></i>
                                                    {{ $service_res->more_extra_price_title }} 
                                                                (<?php if($service_res->more_extra_price_type == 0){
                                                                            echo "One-Time";
                                                                       } 
                                       
                                                                        if($service_res->more_extra_price_type == 2){
                                                                            echo "Per-Day";
                                                                        }
                                                                        
                                                                        
                                                                        
                                                                        
                                                                ?>) 
                                                    <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$service_res->more_extra_price_price }}</span>
                                                </label>
                                                <div id="first_checkbox{{ $x }}">
                                                                 
                                                </div>
                                            </li>
                                             <?php $x++; ?>
                                            @endforeach
                                        @endif
                                            
                                        </ul>
                                    </div>
                                     @endif  
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                               
                                
                                <div class="form-submit">
                                    <div class="add-to-cart">
                                        Select atleast one adult in order to proceed with your booking.
                                        <button type="submit" id="add_to_cart" style="display:none">
                                            <i class="awe-icon awe-icon-cart"></i>Add to Cart
                                        </button>
                                    </div>
                                </div>
                            </div>
                            </form>
                        </div>
            </div>
            
        </div>
        
           <section style="margin-bottom:5rem;">
                        <h5 class="m-3">You May Like</h5>
                        <div class="owl-carousel2 owl-theme mb-5">
                           
                            @if(isset($related_tour))
                                @foreach($related_tour as $toure_res)
                                <div class="item">
                                    <div class="card" style="height:333px;">
                                          <img src="{{ config('img_url') }}/public/uploads/package_imgs/{{  $toure_res->tour_banner_image }}" style="min-height:137px;" class="card-img-top" alt="...">
                                          <div class="card-body">
                                             <div style="display:flex; flex-direction: column; justify-content:space-between;">
                                                 <div>
                                                      <a href="{{ URL::to('view_detail/'.$toure_res->id.'') }}" style="text-decoration:none;">
                                                        <h5 class="card-title" style="font-size:1rem; font-weight: bold;">{{ Str::limit($toure_res->title, 30, ' ...') }}</h5>
                                                      </a>
                                                        <p class="card-text" style="font-weight:bold;">
                                                            {{ Str::limit($tour_details->content, 30, ' ...') }}
                                                        </p>
                                                        <h6 style="font-size:.9rem">Price :{{ $toure_res->currency_symbol }} 
                                                                @if($toure_res->quad_grand_total_amount != 0 AND $toure_res->quad_grand_total_amount != null)
                                                                {{ $toure_res->quad_grand_total_amount }}
                                                                
                                                                @elseif($toure_res->triple_grand_total_amount != 0 AND $toure_res->triple_grand_total_amount != null) 
                                                                {{ $toure_res->triple_grand_total_amount }}
                                                                
                                                                @elseif($toure_res->double_grand_total_amount != 0 AND $toure_res->double_grand_total_amount != null) 
                                                                {{ $toure_res->double_grand_total_amount }}
                                                                @endif
                                                        </h6>
                                                </div> 
                                                <a href="{{ URL::to('view_detail/'.$toure_res->id.'') }}" class="awe-btn">Book now</a>
                                             </div>
                                          </div>
                                    </div>
                              
                                </div>
                                @endforeach 
                             @endif
                            </div>
                </section>
        
     
        
    </div>
    
    
</div>

        
        
             <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Cancellation Policy</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
              
                  <div class="modal-body">
                    
                       <p>{{ $tour_details->cancellation_policy }}</p>
                    
                  </div>
                  <div class="modal-footer">
                    
                  </div>
              
                </div>
              </div>
            </div>


<!-- ================================
       START FOOTER AREA
================================= -->
@endsection
@section('scripts')
<script>

$('.owl-carousel2').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:4
        }
    }
})

function parseDate(str) {
    var mdy = str.split('-');
    return new Date(mdy[2], mdy[0]-1, mdy[1]);
}

function datediff(first, second) {
    // Take the difference between the dates and divide by milliseconds per day.
    // Round to nearest whole number to deal with DST.
    console.log('first is '+first+' second is '+second);
    return Math.round((second-first)/(1000*60*60*24));
}



        function updateConfig() {
            var options = {};
            $('.config-demo').daterangepicker(options, function(start, end, label) {
                console.log('New date range selected: ' + start.format('DD-MM-YYYY') + ' to ' + end.format('DD-MM-YYYY') + ' (predefined range: ' + label + ')'); 
                
                var days = datediff(parseDate(start.format('MM-DD-YYYY')), parseDate(end.format('MM-DD-YYYY')));
               
               var ele = $(this);
                console.log(ele);
                console.log(ele[0].element[0].attributes.id.value);
                var current_id = ele[0].element[0].attributes.id.value;
                $('#day'+current_id+'').val(days)
                
            }).click();
        }
        
        updateConfig();
$('#adults').change(function(){
    var adutls = $(this).val();
    if(adutls >0){
        $('#add_to_cart').css('display','block');
    }else{
         $('#add_to_cart').css('display','none');
    }
    console.log('This is change now'+adutls);
})

var serviceInc = 1;

function checkPerPerson(type,idBox,idAppend,paymentType){
    console.log('the type is '+paymentType);
  
    // if(type !== ''){
           if($('#'+idBox+'').prop('checked')){

                   console.log('Enter here if')
                   if(idBox == 'service1'){
                       if(paymentType == 0){
                            var input = ` <div class="row">
                                            <div class="col-md-6"><input type="text" placeholder="Enter Persons" name="service_adults1"></div>
                                            <div class="col-md-6"><input type="text" placeholder="Enter Days" hidden id="dayrang${serviceInc}" name="service_days1"></div>
                                            <div class="col-md-12"><input type="text" placeholder="Select Date Range"  class=" form-control" hidden id="rang${serviceInc}" name="service_dateRang1"></div>
                                          </div>`;
                       }else{
                            var input = ` <div class="row">
                                            <div class="col-md-6"><input type="text" placeholder="Enter Persons" name="service_adults1"></div>
                                            <div class="col-md-6"><input type="text" placeholder="Enter Days" id="dayrang${serviceInc}" name="service_days1"></div>
                                            <div class="col-md-12"><input type="text" placeholder="Select Date Range" class="config-demo form-control" id="rang${serviceInc}" name="service_dateRang1"></div>
                                          </div>`;
                       }
                      
                   }else{
                       if(paymentType == 0){
                            var input = ` <div class="row">
                                            <div class="col-md-6"><input type="text" placeholder="Enter Persons" name="service_adults[]"></div>
                                            <div class="col-md-6"><input type="text" hidden placeholder="Enter Days" id="dayrang${serviceInc}" name="service_days[]"></div>
                                            <div class="col-md-12"><input type="text" hidden placeholder="Enter Days" class="form-control" id="rang${serviceInc}" name="service_dates[]"></div>
                                          </div>`;
                       }else{
                            var input = `<div class="row">
                                            <div class="col-md-6"><input type="text" placeholder="Enter Persons" name="service_adults[]"></div>
                                            <div class="col-md-6"><input type="text" placeholder="Enter Days" id="dayrang${serviceInc}" name="service_days[]"></div>
                                            <div class="col-md-12"><input type="text" placeholder="Enter Days" class="config-demo form-control" id="rang${serviceInc}" name="service_dates[]"></div>
                                          </div>`;
                       }
                   }
                   
             
                 
                 $('#'+idAppend+'').html(input)
                console.log('this is checked'+idAppend+'yr');
            }else{
                $('#'+idAppend+'').html('')
                console.log('this is not checked');
            }
            
            updateConfig();
    // }
   
    serviceInc++;
}
</script>
<script type="text/javascript" src="{{ asset('public/plugins/jquery/jquery.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/plugins/plugins.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/plugins/goodlayers-core/plugins/combine/script.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/plugins/goodlayers-core/include/js/page-builder.js') }}"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
         
   
         
             <script>
    let mainNavLinks = document.querySelectorAll(".hotel-nav ul li a");
let mainSections = document.querySelectorAll("main section");

let lastId;
let cur = [];


window.addEventListener("scroll", event => {
  let fromTop = window.scrollY;

  mainNavLinks.forEach(link => {
    let section = document.querySelector(link.hash);

    if (
      section.offsetTop <= fromTop &&
      section.offsetTop + section.offsetHeight > fromTop
    ) {
      link.classList.add("current");
    } else {
      link.classList.remove("current");
    }
  });
});
    </script>
 <script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("hotel-nav");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>
<!-- LIBRARY JS-->
@endsection