
@extends('template/frontend/includes/master')
@section('page_title')<?php if(isset($metaInfo) && $metaInfo != ''){echo $metaInfo->pageTitle;}?>@endsection


@section('keywords')
    <meta name="keywords" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->focus_keyword;
        }
    ?>"/>
@endsection
@section('page_meta_desc')
    <meta name="description" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->meta_description;
        }
    ?>"/>
@endsection
@section('page_meta_title')
    <meta name="title" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->metaTitle;
        }
    ?>"/>
@endsection
<style>
    .form-box {
  background: #fff;
  display: block;
  border-radius: 2px;
  border: 1px solid #f0f3f7;
  padding: 20px;
  margin-bottom: 30px;
}
.form-box .fa-solid {
  font-size: 35px;
  float: left;
  color: #d39d00 !important;
}
.form-box .c-detail {
  margin-left: 65px;
  display: table;
  position: relative;
  margin-top: -2px;
}
#page-wrap {
    
    background-color: #eee !important;
}
</style>
@section('content')

<!-- ================================
    START HERO-WRAPPER AREA
================================= -->

<!-- END / HEADING PAGE -->
<section class="awe-parallax category-heading-section-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class="category-heading-content category-heading-content__2 text-uppercase">
                 
                 
                </div>
            </div>
        </section>
        
         <section>
            
            <div class="container">
                <div class="row gx-5 ">
                     <div class="col-md-12 p-5 ">
                       @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <strong>{{ session('error') }}</strong>
                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    @endif
                    
                     @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                      <strong>{{ session('success') }}</strong>
                     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    @endif
                    </div>
                    <div class="col-md-5">
                       <div class="form-box">
							<i class="fa-solid fa-envelope-circle-check"></i>
							<div class="c-detail">
								<strong>Email On:</strong>
								<p>info@alhijaztours.net</p>
							</div>
						</div>
						<div class="form-box">
						<i class="fa-solid fa-headset"></i>
							<div class="c-detail">
								<strong>Call Us:</strong>
								<p>0121 777 2522</p>
							</div>
						</div>
						<div class="form-box">
						<i class="fa-solid fa-map-location-dot"></i>
							<div class="c-detail">
								<strong>Location:</strong>
								<p>1a Nansen Road Sparkhill Birmingham B11 4DR <br> United Kingdom</p>
							</div>
						</div>
                    </div>
                    <div class="col-md-7">
                        <div class="contact-page__form">
                            <div class="title">
                                <span>We would like to know you</span>
                                <h2>CONTACT US</h2>
                            </div>
                            <div class="descriptions">
                                <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque id tempor dolor, id cursus sem. Vestibulum placerat non nibh et sodales. </p>-->
                            </div>
                            <form class="contact-form" action="{{ URL::to('contact_us_sub') }}" method="post">
                                @csrf
                                <div class="form-item">
                                    <input type="text" required value="Your Name *" name="name">
                                </div>
                                <div class="form-item">
                                    <input type="email" required value="Your Email *" name="email">
                                </div>
                                <div class="form-item">
                                    <input type="text" required value="Your Subject" name="subject">
                                </div>
                                <div class="form-item form-captcha">
                                   <input type="text" required value="Your Phone" name="phone">
                                </div>
                                <div class="form-textarea-wrapper">
                                    <textarea required name="message">Company name</textarea>
                                </div>
                                <div class="form-actions">
                                    <input type="submit" value="Send" class="submit-contact">
                                </div>
                                <div id="contact-content"></div>
                            </form>
                        </div>
                    </div>
                     <div class="col-md-12">
                        <div class="contact-page__map">
                       <iframe width="100%" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=1a%20Nansen%20Road,%20Birmingham,%20UK&t=k&z=19&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://123movies-to.org"></a><br><style>.mapouter{position:relative;text-align:right;height:500px;width:600px;}</style><style>.gmap_canvas {overflow:hidden;background:none!important;height:500px;width:100%;}</style>
                        </div>
                    </div>
                </div>
            </div>
        </section>


<!-- start back-to-top -->
@endsection


@section('scripts')
  <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?v=3"></script>
   <script type="text/javascript">
        /*==============================
            Ajax contact form
        ==============================*/
        if($(".contact-form").length > 0) {
          // Validate the contact form
          $('.contact-form').validate({
            // Add requirements to each of the fields
            rules: {
              name: {
                required: true,
                minlength: 2
              },
              email: {
                required: true,
                email: true
              },
              message: {
                required: true,
                minlength: 10
              }
            },

            // Specify what error messages to display
            // when the user does something horrid
            messages: {
              name: {
                required: "Please enter your first name.",
                minlength: $.format("At least {0} characters required.")
              },
              email: {
                required: "Please enter your email.",
                email: "Please enter a valid email."
              },
              message: {
                required: "Please enter a message.",
                minlength: $.format("At least {0} characters required.")
              }
            },

            // Use Ajax to send everything to processForm.php
            submitHandler: function(form) {
              $(".submit-contact").html("Sending...");
              $(form).ajaxSubmit({
                success: function(responseText, statusText, xhr, $form) {
                  $("#contact-content").slideUp(600, function() {
                    $("#contact-content").html(responseText).slideDown(600);
                    $(".submit-contact").html("Send");
                  });
                }
              });
              return false;
            }
          });
        }
    </script>
@endsection
