


<?php

//print_r($hotel_res);die();
  $hotel=$hotel_res->hotel;
     $hotels = (array) $hotel;
?>


<style>
.preloader {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background-color: transparent !important;
    z-index: 999999999;
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
}
 #ModalLoadingSpinner {
            background: rgb(234 235 237);
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 9999;
        }

        .ModalLoadingSpinner__content {
                 text-align: center;
                width: 700px;
                margin: 0 auto;
                position: relative;
        }

.ModalLoadingSpinner__content h3{
    text-align:center;
}
.modal-backdrop.show {
    z-index: 0 !important;
}


</style>   
   <div class="preloader">
            <div id="ModalLoadingSpinner">
                <div class="ModalLoadingSpinner__content">
                    <img class="content-img" src="{{asset('public/admin_package/frontend/image_loader/hotel.gif')}}" />
                    <h3>In Search of Great Deals...</h3>
           
                </div>
            </div>
        </div>
@extends('template/frontend/includes/master')
      

@section('content')
        <!-- HEADING PAGE -->
       
        
        <?php
        
         $room_search=Session()->get('room_searching');
         $child_count = Session::get('child_searching');
   
        $adult_count = Session::get('adult');
       $lat = Session::get('hotel_beds_latitude');
         $lng = Session::get('hotel_beds_longitude');
         
          $checkin = Session::get('newstart');
          $checkin=strtotime($checkin);
          $check_in=date('d-M', $checkin);
         $checkout = Session::get('newend');
         $checkout=strtotime($checkout);
          $check_out=date('d-M', $checkout);
          
          
         $total_hotel = 1;
         $temp=1;
        ?>
    
        
        <section class="awe-parallax category-heading-section-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class=" category-heading-content__2 text-uppercase">
                    <!-- BREADCRUMB -->
                   
                    <!-- BREADCRUMB -->
                    <div class="find">
                       
                         @include('template/frontend/includes/modify_search') 
                    </div>
                </div>
            </div>
        </section>
        <!-- END / HEADING PAGE -->
        
        
        <!--//scroll change(10-21-2022)/////start-->
        <input type="text" style="display:none;" class="counter" value="5">
        <!--//scroll change(10-21-2022)/////end-->
        <section class="filter-page">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-right">
                        <div class="page-top">
                            <div class="total_hotel_count"></div>
                            
                             <button class="btn map_btn" data-bs-toggle="modal" data-bs-target="#hotelBedCan" style="background-color:#d2b254; color:white;">Map Search</button>
                            <select class="awe-select">
                                <option>Best Match</option>
                                <option>Best Rate</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-9 col-md-push-3 scroll_div">
                        <div class="filter-page__content">
                            <div class="filter-item-wrapper hotel_append_div" id="filter_data">
                                
                                
                      <!--hotel listing started By Jamshaid CheEna-->          
                                
                                
           
                    @if($hotels)
                @foreach($hotels as $hotels)
               <?php
               
               if(isset($hotels->property_name))
               {
               ?>
                
                    
                        <div class="hotel-item">
                                    <div class="item-media">
                                        <div class="image-cover">
                                            <img src="https://alhijaztours.net/public/uploads/package_imgs/{{$hotels->property_img ?? ''}}" alt="" height="30" width="30">
                                        </div>
                                    </div>
                                    <div class="item-body">
                                        <div class="item-title">
                                            <h2>
                                                <a href="{{URL::to('')}}/hotel_detail/{{$hotels->id ?? ''}}/{{$hotels->property_name ?? ''}}/{{$hotels->property_type  ?? ''}}">{{$hotels->property_name  ?? ''}}</a>
                    
                                            </h2>
                                        </div>
                                        
                                    <?php
                                    if(isset($hotels->star_type))
                                    {
                                    if($hotels->star_type == 1)
                                    {
                                    
                                    ?>
                                    <div class="item-hotel-star">
                                           
                                            <i class="fa fa-star"></i>
                                        </div>
                                    <?php
                                    }
                                    }
                                    ?>
                                    <?php
                                    if(isset($hotels->star_type))
                                    {
                                    if($hotels->star_type == 2)
                                    {
                                    
                                    ?>
                                    <div class="item-hotel-star">
                                           
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                    <?php
                                    }
                                    }
                                    ?>
                                    <?php
                                    if(isset($hotels->star_type))
                                    {
                                    if($hotels->star_type == 3)
                                    {
                                    
                                    ?>
                                    <div class="item-hotel-star">
                                            
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                    <?php
                                    }
                                    }
                                    ?>
                                    <?php
                                    if(isset($hotels->star_type))
                                    {
                                    if($hotels->star_type == 4)
                                    {
                                    
                                    ?>
                                    <div class="item-hotel-star">
                                            
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                    <?php
                                    }
                                    }
                                    ?>
                                    <?php
                                    if(isset($hotels->star_type))
                                    {
                                    if($hotels->star_type == 5)
                                    {
                                    
                                    ?>
                                    <div class="item-hotel-star">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                    <?php
                                    }
                                    }
                                    ?>
                                        <?php
                                        if(isset($hotels->property_desc))
                                        {
                                            
                                       ?>
                                        <div class="item-address">
                                           {{ Str::limit($hotels->property_desc, 50) }}
                                     
                                        </div>
                                        <?php
                                        }
                                        ?>
                                        <div class="item-address">
                                            <i class="awe-icon awe-icon-marker-2"></i>
                                           {{$hotels->property_address  ?? ''}}{{$hotels->property_country  ?? ''}}{{$hotels->property_city  ?? ''}}
                                        </div>
                                        
                                        <?php
                                        if(isset($hotels->facilities))
                                        {
                                        $facilities=unserialize($hotels->facilities);
                                        $fac=1;
                                        ?>
                                        <div class="row item-address" style="color:green;">
                                            @if(isset($facilities))
                                             @foreach($facilities as $facilities_res)
                                                @if($fac <= 4)
                                                <div class="col-md-6">
                                                    <p><i class="fa-solid fa-check"></i>{{$facilities_res}}</p> 
                                                </div>
                                           
                                             @endif
                                                <?php
                                                $fac=$fac+1;
                                                ?>
                                                @endforeach
                                                 @endif
                                                
                                            </div>
                                             <?php
                                        }
                                                 ?>
                                        <!--<div class="item-footer">-->
                                         
                                        <!--    <span class="avatar-tooltip"> <strong>{{$hotels->property_phone  ?? ''}}</strong></span>-->
                                        <!--</div>-->
                                    </div>
                                     <div class="item-price-more">
                                         
                                         <div class="price">
                                           <span class="amount" style="font-size: 13px;">
                                               <?php
                                               $r_count=1;
                                               ?>
                                            @foreach($hotel_res->rooms as $rooms)
                                             @if(isset($hotels->id))
                                            @if($rooms->hotel_id == $hotels->id)
                                            @if($r_count <= 1)
                                           <?php
                                           
                                           if(isset($rooms->rooms_on_rq))
                                           {
                                              if($rooms->rooms_on_rq == 1)
                                              {
                                                  echo 'On Request';
                                              }
                                              else
                                              {
                                               echo '';   
                                              }
                                           }
                                           $r_count=$r_count + 1;
                                           ?>
                                            @endif
                                            @endif
                                            @endif
                                            @endforeach
                                           </span>
                                            </div>
                                         <div class="price" style="font-weight: bold;color: #666666;">
                                             
                                             
                                             <span class="amount" style="font-size: 13px;"> <?php echo $check_in?> <i class="fa-solid fa-arrow-right"></i> <?php  echo $check_out; ?></span></br>
                                           <span class="amount" style="font-size: 13px;"> <?php echo $adult_count  . 'Adults' . ',' . $child_count .  'Children' ; ?></span>
                                            </div>
                                            </div>
                                    <div class="item-price-more">
                                         
                                        <div class="price">
                                            <?php
                                               $r_count=1;
                                               ?>
                                            @foreach($hotel_res->rooms as $rooms)
                                             @if(isset($hotels->id))
                                            @if($rooms->hotel_id == $hotels->id)
                                                @if($r_count <= 1)
                                                <?php
                                                if($rooms->weekdays_price_wi_markup != null)
                                                {
                                                    $price=$rooms->weekdays_price_wi_markup;
                                                    if($hotels->currency_symbol == '﷼')
                                                    {
                                                    $currency='SAR';
                                                    }
                                                    else
                                                    {
                                                    $currency=$hotels->currency_symbol;
                                                    }
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                ?> 
                                            Week Days Price
                                            
                                            
                                            <?php
                                            
                                            // $CustomHotel=config('CustomHotel');
                                          
                                          $CustomHotel=0;
                                            $exchange_price1=$exchange_price + $CustomHotel;
                                            ?>
                                             
                                                <span  class="amount exchange_price1_1_{{$temp}}" style="display:none;">{{$exchange_price1}}</span>
                                                <span class="amount exchange_rate_country_price_{{$temp}}" style="font-size: 20px;"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></span>
                                                <?php
                                                }
                                                else
                                                {
                                                $price=$rooms->price_all_days_wi_markup;
                                                    if($hotels->currency_symbol == '﷼')
                                                    {
                                                    $currency='SAR';
                                                    }
                                                    else
                                                    {
                                                    $currency=$hotels->currency_symbol;
                                                    }
                                                    $exchange_price=all_currency_manage($currency,$price);
                                                ?>
                                                <?php
                                            
                                             $CustomHotel=0;
                                            $exchange_price1=$exchange_price + $CustomHotel;
                                            ?>
                                                All Days Price
                                                 <span class="amount exchange_price1_1_{{$temp}}" style="display:none;">{{$exchange_price1 ?? ''}}</span>
                                                <span class="amount exchange_rate_country_price_{{$temp}}" style="font-size: 20px;"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></span>
                                                
                                                
                                                <?php
                                                
                                                }
                                                 $r_count=$r_count + 1;
                                                ?>
                                                @endif
                                            @endif
                                            @endif
                                            <?php
                                            
                                            
                                            ?>
                                            @endforeach
                                            
                                            
                                        </div>
                                        <a href="{{URL::to('')}}/hotel_detail/{{$hotels->id  ?? ''}}/{{$hotels->property_name  ?? ''}}/{{$hotels->property_type  ?? ''}}" class="awe-btn">Book now</a>
                                    </div>
                                </div>
                                
                       
                       <?php
                       $temp=$temp+1;
               }
                       ?>
                     
                    @endforeach
                   
                    @else
                        
                       <div class="item-media">
                                        <!--<h7>No Available rooms for given criteria</h7>-->
                                    </div>   
                        
                    @endif
                 
                 <!--hotel listing Ended By Jamshaid CheEna-->
                                      
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                <!-- ITEM -->
                                 

<?php
if($travellanda_hotels != '')
{
    $travellandahotelcount = count($travellanda_hotels);
   $total_hotel = $total_hotel + $travellandahotelcount;
?>

<?php

$list_count=1;

?>
@foreach($travellanda_hotels as $hotelz)


<?php
if($list_count <= 5)
{

?>
                                         
       <?php
         $hotel_bed_data_arr =[];
         
         
                      
         $data_request="<Request>
                <Head>
              <Username>1124fb7683cf22910ea6e3c97473bb9c</Username>
                <Password>rY8qm76g5dGH</Password>
                <RequestType>GetHotelDetails</RequestType>
                </Head>
                <Body>
                <HotelIds> 
                <HotelId>".$hotelz->HotelId."</HotelId>
                </HotelIds>
                </Body>
            </Request>";


$url = "http://xmldemo.travellanda.com/xmlv1/GetHotelDetailsRequest.xsd";
            $timeout = 20;
            $data = array('xml' => $data_request);
            $headers = array(
            "Content-type: application/x-www-form-urlencoded",
        );
        $ch = curl_init();
        $payload = http_build_query($data);
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        // echo $response;die();
        $xml = simplexml_load_string($response);
        $json = json_encode($xml);
      //print_r($json);
        $hotelz1 = json_decode($json);
         
         
         $hotelz1=$hotelz1->Body->Hotels->Hotel;
       
    

     $travellanda_images=$hotelz1->Images ?? '';
     //$travellanda_images=json_decode($travellanda_images);
     
     $travellanda_Facilities=$hotelz1->Facilities ?? '';
     //$travellanda_Facilities=json_decode($travellanda_Facilities);
     
      $travellanda_Facilities_more=$hotelz1->Facilities ?? '';
     //$travellanda_Facilities_more=json_decode($travellanda_Facilities_more);
  
     
     $travellanda_Description=$hotelz1->Description ?? '';
     //$travellanda_Description=json_decode($travellanda_Description);
    //  print_r($travellanda_Facilities);
     
     
    ?>
    
    
    
    
    
                                <div class="hotel-item">
                                    <!--moda start-->
                                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Facilities</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        
                                                         
       <ul class="list-unstyled">
           
           <div class="row">
               @if(isset($travellanda_Facilities->Facility))
                @foreach($travellanda_Facilities->Facility as $travellanda_Facilities)  
               <div class="col-md-4">
                   <li>{{$travellanda_Facilities->FacilityName}}</li>
               </div>
               @endforeach
                @endif
               
           </div>
        
       </ul>                                                    
                                                                
      </div>
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="exampleModal_description" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Description</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        
                                                         
      <p>
         <?php
        print_r($travellanda_Description ?? '');
         ?> 
      </p>                                                
                                                                
      </div>
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div> 
                                    <!--moda end-->
                                    <div class="item-media">
                                        <div class="image-cover">
                                            <img src="{{$travellanda_images->Image[0] ?? ''}}" alt="">
                                        </div>
                                    </div>
                                    <div class="item-body">
                                        <div class="item-title">
                                            <h2>
                                                <a href="{{URL::to('')}}/hotel_detail/{{$hotelz->HotelId}}/{{$hotelz->HotelName}}/{{'travellanda'}}">{{$hotelz->HotelName ?? ""}}</a>
                                            </h2>
                                        </div>
                                        <div class="item-hotel-star">
                                            <?php
                                            
                                            if($hotelz1->StarRating == '5')
                                            {
                                            ?>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <?php
                                            }
                                           
                                            if($hotelz1->StarRating == '4')
                                            {
                                            ?>
                                            
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <?php
                                            }
                                            
                                            if($hotelz1->StarRating == '3')
                                            {
                                            ?>
                                            
                                            
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <?php
                                            }
                                           
                                            if($hotelz1->StarRating == '2')
                                            {
                                            ?>
                                            
                                            
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <?php
                                            }
                                            if($hotelz1->StarRating == '1')
                                            {
                                            ?>
                                            
                                            
                                            
                                            <i class="fa fa-star"></i>
                                            <?php
                                            }
                                            ?>
                                        </div>
                                        <div class="item-address">
                                            <i class="awe-icon awe-icon-marker-2"></i>
                                          <?php
                                        
                                          print_r($hotelz1->Address ?? ''); 
                                          ?>
                                        </div>
                                        <div class="item-address">
                                            <?php
                                          
                                            // print_r($hotelz1->Location ?? '');   
                                          
                                         
                                          
                                          ?>
                                        </div>
                                        
                                        <div class="row">
                                            
                                            <div class="col-md-6">
                                                <div class="item-icon">
                                              <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal">Facilities</a>
                                            </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="item-icon">
                                              <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#exampleModal_description">Description</a>
                                            </div>
                                            </div>
                                            
                                            
                                        </div>
                                        <?php
$count_rooms=0;
?>
<?php
if(isset($hotelz->Options->Option))
{
?>
     @foreach($hotelz->Options->Option as $Option) 
                                         
                                                  <?php
                                $count_rooms=$count_rooms+1;
                                ?>
                               
                      @endforeach
                      <?php
                      
}
else
{
                      
?>
@if($hotelz->Options->Option) 
                                         
                                                  <?php
                                $count_rooms=$count_rooms+1;
                                ?>
                               
                      @endif

<?php

}
?>
                            <div class="row">
                                            
                                            <div class="col-md-12">
                                                <div class="item-icon">
                                              <?php print_r($count_rooms); ?> Rooms Available with 
                                              <?php
                                              if(isset($hotelz->Options->Option->BoardType))
                                              {
                                             print_r($hotelz->Options->Option->BoardType);   
                                              }
                                              else
                                              {
                                                  print_r($hotelz->Options->Option[0]->BoardType);
                                               
                                              }
                                              ?>
                                            </div>
                                            </div>
                                            
                                            
                                            
                                        </div> 
                                        
                                        
                                            
                                        <div class="item-footer">
                                             
                                          
                                           
                                     
                                          
                                            <!--<span class="avatar-tooltip"> <strong>Travellanda</strong></span>-->
                                        </div>
                                    </div>
                                    <div class="item-price-more" >
                                        <div class="price" style="font-weight: bold;color: #666666;">
                                           <?php echo $check_in?> <i class="fa-solid fa-arrow-right"></i> <?php echo $check_out; ?></span></br>
                                           <span class="amount" style="font-size: 13px;"> <?php echo $adult_count  . 'Adults' . ',' . $child_count .  'Children' ; ?></span>
                                            </div>
                                            </div>
                                    <div class="item-price-more" style="margin-top: 20px;">
                                        <div class="price">
                                            <?php
                                            if(isset($hotelz->Options->Option->TotalPrice))
                                               {
                                                   
                                                   
                                              
                                            ?>
                                            
                                            
                                             
                                                
                                            
                                            <span id="addCls" class="amount exchange_price1_1_{{$temp}}" style="font-size: 15px; display:none;">
                                            <?php
                                            
                                            
                                            $Travellanda=config('All');
                                         
                                            $price1=$hotelz->Options->Option->TotalPrice + $Travellanda;
                                           
                                            
                                            print_r($price1); 
                                            ?>
                                            </span>
                                           
                                            <span class="amount exchange_rate_country_price_{{$temp}}" style="font-size: 20px;"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></span>
                                            
                                            
                                            <?php
                                            
                                               }
                                               else
                                               {
                                            ?>
                                            
                                            <span class="amount exchange_price1_1_{{$temp}}" style="font-size: 15px;display:none;">
                                               <?php
                                            
                                            
                                            $Travellanda=config('Travellanda');
                                         
                                            $price1=$hotelz->Options->Option[0]->TotalPrice + $Travellanda;
                                           
                                            
                                            print_r($price1); 
                                            ?>
                                                
                                                </span>
                                                
                                                <span class="amount exchange_rate_country_price_{{$temp}}" style="font-size: 20px;"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></span>
                                            
                                            <?php
                                               }
                                            
                                            ?>
                                            
                                            
                                        </div>
                                        <a href="{{URL::to('')}}/hotel_detail/{{$hotelz->HotelId}}/{{$hotelz->HotelName}}/{{'travellanda'}}" class="awe-btn">Book now</a>
                                    </div>
                                </div>
                      
                      <?php
   $temp=$temp+1;                    
}
$list_count=$list_count+1;

                      ?>
                    @endforeach
                   <?php
}
else
{
                   ?>
    
                          
                  <?php
                  
}
                  ?>
                    
                    
                    
                    
                    
                    
                    
                    
                    @if(isset($hotelbed_hotels) && $hotelbed_hotels != "")
        
<?php
$hotelbedhotelcount = count($hotelbed_hotels);
$total_hotel = $total_hotel + $hotelbedhotelcount;
$hotel_bed_data_arr=[];
$list_count=1;

?>
        
                    @foreach($hotelbed_hotels as $hotela)
                    
                    <?php
                    if($list_count <= 5)
                    {
                    ?>
                    
                    
                    <?php
                    $hotelbeds_count_rooms=0;
                    foreach($hotela->rooms as $rooms)
                    {
                      $hotelbeds_count_rooms=$hotelbeds_count_rooms+1;  
                    }
                    // print_r($hotelbeds_count_rooms);
                    ?>

                    
                    
<?php

     $apiKey = '4b11b3c941ea25825a4de05ec398c4ab';
        $secret = 'afe693d5e4';
    
        $signature = hash("sha256", $apiKey.$secret.time());                                            
            
     $curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.hotelbeds.com/hotel-content-api/1.0/hotels/'.$hotela->code.'/details?language=ENG&useSecondaryLanguage=False',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Api-key: 4b11b3c941ea25825a4de05ec398c4ab',
    "X-Signature: $signature",
    'Accept: application/json',
    'Accept-Encoding: gzip'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
$data1 = json_decode($response);
   
        if(isset($data1->hotel)){
            $travel_content = $data1->hotel;
        }else{
            $travel_content = null;
        }
        
        // dd($travel_content);
   
   
   
    
     $hotel_beds_images=$travel_content->images ?? '';
     
     
     $hotel_beds_facilities=$travel_content->facilities ?? '';
    
    //  print_r($hotel_beds_facilities);
     
     
 $apiKey = '4b11b3c941ea25825a4de05ec398c4ab';
        $secret = 'afe693d5e4';
        $signature = hash("sha256", $apiKey.$secret.time());
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.hotelbeds.com/hotel-content-api/1.0/types/facilities?fields=all&language=ENG&from=1&to=100&useSecondaryLanguage=True',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Api-key: 4b11b3c941ea25825a4de05ec398c4ab',
    "X-Signature: $signature",
    'Accept: application/json',
    'Accept-Encoding: gzip'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
// echo $response;
$response_facilities=json_decode($response);
$result='';
$single_hotel_bad = ['hotel_data'=>$hotela,'hotel_details'=>$result,'facilities_data'=>$response_facilities];

array_push($hotel_bed_data_arr,$single_hotel_bad);

   
        ?>
        
        
        
        
        
        
        
        
                    
                    <div class="hotel-item">
                         <!--moda start-->
                        <div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php print_r($hotela->latitude); ?>,<?php print_r($hotela->longitude); ?>&amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
 <!--moda end-->
                                    <div class="item-media">
                                        <div class="image-cover">
                                            <?php
                                            if(isset($hotel_beds_images))
                                            {
                                            ?>
                                            <img src="https://photos.hotelbeds.com/giata/bigger/{{$hotel_beds_images[0]->path ?? ''}}" alt="" height="30" width="30">
                                            <?php
                                            }
                                            else
                                            {
                                                
                                            ?>
                                            
                                            <img src="{{asset('public/admin_package/frontend/images/detail_img/no-photo-available-icon-4.jpg')}}" alt="" height="30" width="30">
                                            <?php
                                            
                                            }
                                            ?>
                                            
                                            
                                        </div>
                                    </div>
                                    <div class="item-body">
                                        <div class="item-title">
                                            <h2>
                                                <a href="{{URL::to('')}}/hotel_detail/{{$hotela->code}}/{{$hotela->name}}/{{'hotelbeds'}}">{{$hotela->name}}</a>
                                            </h2>
                                        </div>
                                        <div class="item-hotel-star">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        
                                        
                                        <div class="item-address">
                                            <i class="awe-icon awe-icon-marker-2"></i>
                                          <?php
                                         
                                          print_r($travel_content->address->content ?? '');
                                     
                                          ?>
                                        </div>
                                        
                                       
                                        
                                        
                                        <div class="row">
                                            <div class="col-md-10">
                                                
                                            
                                        
                                      <div class="tagcloud">
                                          <?php
                                          $facilities_count=1;
                                        //   echo "awab";
                                        //   print_r($hotel_beds_facilities);
                                        //           die;
                                          if(isset($hotel_beds_facilities) AND !empty($hotel_beds_facilities))
                                          {
                                          foreach($hotel_beds_facilities as $hotel_beds_facilities)
                                          {
                                              if(isset($response_facilities->facilities))
                                              {
                                                  
                                              foreach($response_facilities->facilities as $res_facilities)
                                          {
                                            if($res_facilities->code == $hotel_beds_facilities->facilityCode)
                                              {  
                                              
                                              if($facilities_count <= 3)
                                              {
                                          ?>
                                    <a href="#">{{$res_facilities->description->content}}</a>
                                    <?php
                                              }
                                            $facilities_count=$facilities_count + 1;  
                                          }
                                          }
                                          }
                                          }
                    }
                                    ?>
                                    
                                    <!--<a href="#">More</a>-->
                                </div>
                                </div>
                                        <div class="col-md-2">
                                       <button data-popover-target="popover_{{$list_count}}" type="button" class="btn tooltip-btn btn-primary">Facilities</button>
                                       </div>
                                      </div> 
                                      
                                       <div class="item-address" style="color:green;">
                                           <i class="fa-solid fa-check"></i>
                                            <!--<i class="awe-icon awe-icon-marker-2"></i>-->
                                             <?php
                   $count_board=0;
                    foreach($hotela->rooms as $rooms)
                    {
                         
                      foreach($rooms->rates as $rates)
                      {
                        if($rates->boardName == 'ROOM ONLY')
                        {
                            if($count_board == 1)
                            {
                            echo 'ROOM ONLY';
                            }
                        }
                        if($rates->boardName == 'ENGLISH BREAKFAST')
                        {
                            if($count_board == 1)
                            {
                            echo 'ENGLISH BREAKFAST';
                            }
                        }
                        if($rates->boardName == 'CONTINENTAL BREAKFAST')
                        {
                            if($count_board == 1)
                            {
                            echo 'CONTINENTAL BREAKFAST';
                            }
                        }
                        $count_board=$count_board+1;
                      }
                      
                    }
                    // print_r($hotelbeds_count_rooms);
                    ?>
                                          
                                        </div>
                                       
                                       
                                       <div class="item-address" style="color:red;">
                                            <!--<i class="awe-icon awe-icon-marker-2"></i>-->
                                          <?php
                                         
                                         echo  $hotelbeds_count_rooms . ' '. 'Rooms Available';
                                          ?>
                                        </div>
                                       
                                    <div id="popover_{{$list_count}}" role="tooltip" class="tooltip-custom absolute invisible opacity-0 transition-opacity duration-300 ">
                                       
                                       <div class="row">
                                        <div calss="col-12">
                                            <h3>Hotel Facilities</h3></div>
                                            <?php
                                         $facilities_count=1;
                                          if(isset($hotel_beds_facilities)  AND !empty($hotel_beds_facilities))
                                          {
                                          foreach($hotel_beds_facilities as $hotel_beds_facilities)
                                          {
                                              if(isset($response_facilities->facilities))
                                          {
                                              foreach($response_facilities->facilities as $res_facilities)
                                          {
                                              
                                              
                                            if($res_facilities->code ?? '' == $hotel_beds_facilities->facilityCode)
                                              {  
                                              
                                              if($facilities_count <= 5)
                                              {
                                          ?>
                                   
                                    <div class="col-sm-6"> <i class="awe-icon awe-icon-check"></i>{{$res_facilities->description->content}}</div>
                                    <?php
                                              } 
                                              
                                              $facilities_count=$facilities_count + 1; 
                                          }
                                          }
                                          }
                                           
                                          
                                          
                                          }
                    }
                                    ?>
                                           
                                            
                                       </div>
                                       
                                        <div data-popper-arrow></div>
                                    </div>

  <!--<button data-popover-target="popoverCancellation_{{$list_count}}" type="button" class="btn tooltip-btn btn-success">Cancellation Policy</button>-->
   
<div id="popoverCancellation_{{$list_count}}" role="tooltip" class="tooltip-custom absolute invisible opacity-0 transition-opacity duration-300 ">
   
   <div class="row">
    <div calss="col-12">
        <h3>cancellation policy</h3></div>    
       <div class="col-sm-12"><span class="RoomFeature__PopoverItem"><span><span><span class="green fontsmallb"></span></span>Risk-free booking!<span></span> Cancel before August 21, 2022 and you'll pay nothing!<span><br></span><span><br></span> Any cancellation received within 2 days prior to the arrival date will incur the first night's charge. Failure to arrive at your hotel or property will be treated as a No-Show .</span></span></div>
      
   </div>
   
    <div data-popper-arrow></div>
</div>
                                        
                                        <div class="item-footer">
                                            <!--<div class="item-rate">-->
                                            <!--    <span>{{$hotela->categoryName}}</span>-->
                                            <!--</div>-->
                                            
                                            <!--<span class="avatar-tooltip"> <strong>HotelBeds</strong></span>-->

                                        </div>
                                    </div>
                                
                                        
                                    <div class="item-price-more" style="margin: 5px 0;" >
                                        <div class="price">
                                           <span class="amount" style="font-size: 13px; margin-bottom: 5px;"><a style="background:none;color: #28871c;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map">Map View</a> </span>
                                            </div>
                                        <div class="price" style="font-weight: bold;color: #666666;">
                                             <?php echo $check_in?> <i class="fa-solid fa-arrow-right"></i> <?php echo $check_out; ?></span></br>
                                           <span class="amount" style="font-size: 13px;"> <?php echo $adult_count  . 'Adults' . ',' . $child_count .  'Children' ; ?></span>
                                            </div>
                                            </div>
                                    <div class="item-price-more" style="margin:0px 0px 0px 0px;">
                                       <div class="price" style="font-weight: bold;color: #666666;">
                                            <?php
                                            $currency=$hotela->currency;
                                            $minRate=$hotela->minRate;
                                            $exchange_price=all_currency_manage($currency,$minRate);
                                            
                                            
                                            $Hotelbeds=config('All');
                                             $exchange_price1=$Hotelbeds+$exchange_price;
                                            ?>
                                            
                                            <!--<span class="amount" style="font-size: 20px;">{{$hotela->currency ?? ""}} {{$hotela->minRate ?? ""}}</span>-->
                                             <span class="amount exchange_price1_1_{{$temp}}" style="font-size: 20px; display:none;">{{$exchange_price1 ?? ""}}</span>
                                             <span class="amount exchange_rate_country_price_{{$temp}}" style="font-size: 20px;"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></span>
                                            
                                        </div>
                                        <div class="vat-top"><i class="awe-icon awe-icon-info"></i> Inclusive of VAT and Taxes</div>
                                        <a href="{{URL::to('')}}/hotel_detail/{{$hotela->code}}/{{$hotela->name}}/{{'hotelbeds'}}" class="awe-btn">Book now</a>
                                        <!--<a href="#" class="awe-btn">Book now</a>-->
                                    </div>
                                </div>
                              
                    <?php
                     $temp=$temp+1;
                    }
                    
                    $list_count=$list_count + 1;
                    ?>
                    @endforeach
                    @else
                    <div class="item-media">
                                        <h7>Hotels Are Not Found</h7>
                                    </div>
                    
                    
                    @endif
                    
                    
                    
                 <!--tbo listing Start By Jamshaid ChEena   -->
                 
                                                               
                   @if(isset($tbo_response->HotelResult))
                   
                   <?php
                   $tbohotelcount = count($tbo_response->HotelResult);
                   $total_hotel = $total_hotel + $tbohotelcount;
                   
                   $tbo_count_hotel=1;
                   ?>
                   
                    @foreach($tbo_response->HotelResult as $hotela) 
                    
                        <?php
                        
                        if($tbo_count_hotel <= 5)
                        {
                        ?> 
                    
                    
                    
                     <?php
                                  
            
     $request_data = array(
    'HotelCode' => $hotela->HotelCode,
   
    );
//   $searchdata=json_encode($searchdata);
  $curl = curl_init();
     curl_setopt_array($curl, array(
     CURLOPT_URL => 'https://admin.synchronousdigital.com/api/get_tbo_hotel_details',
     CURLOPT_RETURNTRANSFER => true,
     CURLOPT_ENCODING => '',
     CURLOPT_MAXREDIRS => 10,
     CURLOPT_TIMEOUT => 0,
     CURLOPT_FOLLOWLOCATION => true,
     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
     CURLOPT_CUSTOMREQUEST => 'POST',
     CURLOPT_POSTFIELDS =>  $request_data,
     CURLOPT_HTTPHEADER => array(
        'Cookie: laravel_session=gnq21xtzzbBtgOgSa0iVWPIX9vSDzHcKrUozAnSL'
     ),
     ));
  
     $response = curl_exec($curl);
     curl_close($curl);
     $tbo_hotel_detail= $response; 
     $tbo_hotel_detail=json_decode($tbo_hotel_detail);
     $tbo_hotel_detail=$tbo_hotel_detail->data ?? '';
     $tbo_hotel_image= $tbo_hotel_detail->images ?? '';
     $image= json_decode($tbo_hotel_image);
     $tbo_hotel_attractions= $tbo_hotel_detail->attractions ?? '';
     $attractions = json_decode($tbo_hotel_attractions);
     
     $slug='tbo';
    // print_r($image);die();
     
     
     
    ?>
                    
                    
                        <div class="hotel-item">
                                    <div class="item-media">
                                        <div class="image-cover">
                                            <img src="{{URL::to($image[1])}}" alt="" height="30" width="30">
                                        </div>
                                    </div>
                                    <div class="item-body">
                                        <div class="item-title">
                                            <h2>
                                                <a href="{{URL::to('')}}/hotel_detail/{{$tbo_hotel_detail->hotel_code ?? ''}}/{{$tbo_hotel_detail->hotel_name ?? ''}}/{{$slug}}">{{$tbo_hotel_detail->hotel_name  ?? ''}}</a>
                    
                                            </h2>
                                        </div>
                                    
                                        <div class="item-hotel-star">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="item-address">
                                            <i class="awe-icon awe-icon-marker-2"></i>
                                           {{$tbo_hotel_detail->address  ?? ''}}{{$tbo_hotel_detail->country_name  ?? ''}}{{$tbo_hotel_detail->city_name  ?? ''}}
                                        </div>
                                        <div class="item-footer">
                                            <div class="item-rate">
                                                <span></span>
                                            </div>
                                            <div class="item-icon">
                                                <i class="awe-icon awe-icon-gym"></i>
                                                <i class="awe-icon awe-icon-car"></i>
                                                <i class="awe-icon awe-icon-food"></i>
                                                <i class="awe-icon awe-icon-level"></i>
                                                <i class="awe-icon awe-icon-wifi"></i>
                                            </div>
                                            <span class="avatar-tooltip"> <strong>{{$tbo_hotel_detail->phone_no  ?? ''}}</strong></span>
                                        </div>
                                    </div>
                                     <div class="item-price-more" style="margin: 0px 0;">
                                        <div class="price" style="font-weight: bold;color: #666666;">
                                             <?php echo $check_in?> <i class="fa-solid fa-arrow-right"></i> <?php echo $check_out; ?></span></br>
                                           <span class="amount" style="font-size: 13px;"> <?php echo $adult_count  . 'Adults' . ',' . $child_count .  'Children' ; ?></span>
                                            </div>
                                            </div>
                                    <div class="item-price-more" style="margin: 0px 0;">
                                         
                                        <div class="price">
                                             <?php
                                            $currency=$hotela->Currency;
                                            $minRate=$hotela->Rooms[0]->TotalFare;
                                            $exchange_price=all_currency_manage($currency,$minRate);
                                            
                                             $TBO=config('All');
                                             $exchange_price1=$TBO+$exchange_price;
                                            ?>
                                            
                                             <span class="amount exchange_price1_1_{{$temp}}" style="font-size: 20px;display:none;">{{$exchange_price1 ?? ''}}</span>
                                              <span class="amount exchange_rate_country_price_{{$temp}}" style="font-size: 20px;"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></span>
                                        </div>
                                        <a href="{{URL::to('')}}/hotel_detail/{{$tbo_hotel_detail->hotel_code  ?? ''}}/{{$tbo_hotel_detail->hotel_name  ?? ''}}/{{$slug}}" class="awe-btn">Book now</a>
                                    </div>
                                </div>
                                
                               
                       <?php
                       $temp=$temp+1;
                        }
                         
                        $tbo_count_hotel=$tbo_count_hotel + 1;
                       ?> 
                    @endforeach
                    @else
                        
                       <div class="item-media">
                                        <!--<h7>No Available rooms for given criteria</h7>-->
                                    </div>   
                        
                    @endif
                 
                 <!--tbo listing Ended By Jamshaid CheEna-->
                 
                 
                 
                 
                  <!--RateHawke listing Start By Jamshaid ChEena   -->
                 
                                                               
                   @if(isset($rate_hawke_res_search->data->hotels)) 
                   <?php
                    $ratehawkhotelcount = count($rate_hawke_res_search->data->hotels);
                    $total_hotel = $total_hotel + $ratehawkhotelcount;
                    
                    $ratehawk_count=1;
                    
                    ?>
                    @foreach($rate_hawke_res_search->data->hotels as $hotels) 
                    
                    <?php
                    if($ratehawk_count <= 5)
                    {
                  
$data_req='{
    "id": "'.$hotels->id.'",
    "language": "en"
}';


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.worldota.net/api/b2b/v3/hotel/info/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>$data_req,
  CURLOPT_HTTPHEADER => array(
    'Authorization: Basic NDM4MTo3NjJkNWY4MS02Y2YyLTRlYTItOWUyZC0wZTljY2QwODZhYzI=',
    'Content-Type: application/json',
    'Cookie: uid=TfTb5mL04HmDUEWsBqSiAg=='
  ),
));

$response = curl_exec($curl);
// echo $response;
curl_close($curl);

$rate_hawke_hotel_details=json_decode($response);
$rate_hawke_hotel_details=$rate_hawke_hotel_details->data;

$slug='ratehawke';
?>
                        <div class="hotel-item">
                                    <div class="item-media">
                                        <div class="image-cover">
                                            <?php
                                            
$image=$rate_hawke_hotel_details->images[0];
$image = explode('{size}', $image);
$img=$image[0]. '1024x768'.$image[1];

                                            ?>
                                            <img src="{{$img}}" alt="" height="30" width="30">
                                        </div>
                                    </div>
                                    <div class="item-body">
                                        <div class="item-title">
                                            <h2>
                                                <a href="{{URL::to('')}}/hotel_detail/{{$rate_hawke_hotel_details->id}}/{{$rate_hawke_hotel_details->name}}/{{$slug}}">{{$rate_hawke_hotel_details->name  ?? ''}}</a>
                    
                                            </h2>
                                        </div>
                                    
                                        <div class="item-hotel-star">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="item-address">
                                            <i class="awe-icon awe-icon-marker-2"></i>
                                            {{$rate_hawke_hotel_details->address  ?? ''}}
                                           {{$rate_hawke_hotel_details->region->country_code  ?? ''}},{{$rate_hawke_hotel_details->region->name  ?? ''}}<br>
                                           {{$rate_hawke_hotel_details->kind  ?? ''}}
                                        </div>
                                        <div class="item-footer">
                                            <div class="item-rate">
                                                <span>{{$rate_hawke_hotel_details->phone  ?? ''}}</span>
                                            </div>
                                            <div class="item-icon">
                                                <i class="awe-icon awe-icon-gym"></i>
                                                <i class="awe-icon awe-icon-car"></i>
                                                <i class="awe-icon awe-icon-food"></i>
                                                <i class="awe-icon awe-icon-level"></i>
                                                <i class="awe-icon awe-icon-wifi"></i>
                                            </div>
                                            <span class="avatar-tooltip"> <strong></strong></span>
                                        </div>
                                    </div>
                                    <div class="item-price-more" >
                                       
                                        <div class="price" style="font-weight: bold;color: #666666;">
                                             <?php echo $check_in?> <i class="fa-solid fa-arrow-right"></i> <?php echo $check_out; ?></span></br>
                                           <span class="amount" style="font-size: 13px;"> <?php echo $adult_count  . 'Adults' . ',' . $child_count .  'Children' ; ?></span>
                                            </div>
                                            </div>
                                    <div class="item-price-more">
                                        <div class="price">
                                            <?php
                                             $Ratehawk=config('All');
                                             $exchange_price1=$Ratehawk + $hotels->rates[0]->payment_options->payment_types[0]->amount;
                                            ?>
                                            <span class="amount exchange_price1_1_{{$temp}}" style="font-size: 20px; display:none;">{{$exchange_price1  ?? ''}}</span></span>
                                            
                                            <span class="amount exchange_rate_country_price_{{$temp}}" style="font-size: 20px;"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></span>
                                            <!--<span class="amount">{{$hotels->rates[0]->payment_options->payment_types[0]->currency_code  ?? ''}} {{$hotels->rates[0]->payment_options->payment_types[0]->amount  ?? ''}}</span>-->
                                        </div>
                                        <a href="{{URL::to('')}}/hotel_detail/{{$rate_hawke_hotel_details->id}}/{{$rate_hawke_hotel_details->name}}/{{$slug}}" class="awe-btn">Book now</a>
                                    </div>
                                </div>
                                
                               
                        <?php
                        $temp=$temp+1;
                    }
                        $ratehawk_count=$ratehawk_count+1;
                         
                        ?>
                    @endforeach
                    
                    @else
                        
                       
                        
                    @endif
                 
                 <!--RateHawke listing Ended By Jamshaid CheEna-->
           
                        </div>
                        
                        
                        
                        
                    
                        
                          <div class="text-center mt-10" id="loder_hides" style="color: #d2b254;"> 
                <p>
              <img style="max-width: 40%;margin-left: 27%;height: auto;vertical-align: middle;border: 0;" src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif"/>
                </p>
                    <!--<span class="count-string">{{ __("Showing :from - :to of :total Hotels",["total"=>$total_hotel]) }}</span>-->
                    <span style="font-size: 25px;" class="count-string">Please Wait While We Get More Results.....</span>
                    <!--<span class="count-string">Please Wait While We Get More Results..... <b class="div_length"></b> Hotels From: {{$total_hotel}} Hotels</span>-->
                    <input type="text" style="display:none;" class="hotelcount" value="{{$total_hotel}}">
                      </div> 
                      
                      
                      
                      
                      
                               
                            </div>
                    </div>
                    
                    <div class="col-md-3 col-md-pull-9">
                        <div class="page-sidebar">
                            <div class="sidebar-title">
                                <h2>Hotel filter</h2>
                                <div class="clear-filter">
                                    <a href="#">Clear all</a>
                                </div>
                            </div>
                            <!-- WIDGET -->
                           
                            <!-- END / WIDGET -->

                            <!-- WIDGET -->
                             <div class="widget widget_price_filter">
                                <h3>Price Level</h3>
                                <div class="mb-0">
                                    <label class="form-label">Price Level</label>
                                    <div id="kt_slider_basic"></div>
                                
                                    <div class="pt-5">
                                        <div class="fw-bold mb-2">Min: <span id="kt_slider_basic_min"></span></div>
                                        <div class="fw-bold mb-2">Max: <span id="kt_slider_basic_max"></span></div>
                                    </div>
                                </div>
                            </div>
                            <!-- END / WIDGET -->

                            <!-- WIDGET -->
                            <div class="widget widget_has_radio_checkbox">
                                <h3>Star Rating</h3>
                                <ul>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="5">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="4">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="3">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="2">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="1">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                   
                                </ul>
                            </div>
                            <!-- END / WIDGET -->

                            <!-- WIDGET -->
                            <div class="widget widget_has_radio_checkbox">
                                <h3>Distance</h3>
                                <ul>
                                    <li>
                                        <label>
                                            <input type="checkbox">
                                            <i class="awe-icon awe-icon-check"></i>
                                            Near Airport
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox">
                                            <i class="awe-icon awe-icon-check"></i>
                                            Near Shopping District
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox">
                                            <i class="awe-icon awe-icon-check"></i>
                                            Near Attractions
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox">
                                            <i class="awe-icon awe-icon-check"></i>
                                            Near Traffic station
                                        </label>
                                    </li>
                                </ul>
                            </div>
                            <!-- END / WIDGET -->

                            <!-- WIDGET -->
                            
                            <button class="btn" style="background-color:#d2b254; color:white;" onclick="getFilterResult()">Filter</button>
                          
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        
        
           <div class="modal fade" id="hotelBedCan" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                      <div class="modal-dialog modal-xl modal-fullscreen">
                                        <div class="modal-content">
                                          <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Map View</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                          </div>
                                          <div class="modal-body">
                                              <script src="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v5.0.0/mapbox-gl-geocoder.min.js"></script>
<link rel="stylesheet" href="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v5.0.0/mapbox-gl-geocoder.css" type="text/css">
                                          <style>
.mapboxgl-ctrl-logo{
    display: none !important;
}
.mapboxgl-popup-content {
    width:150px;
max-width: 800px;
font: 12px/20px 'Helvetica Neue', Arial, Helvetica, sans-serif;
color:black;
background-color: #d2b254;
}







</style>

                                    <div id="map" style="height: 100%;
                                     width: 100%;"></div> 
                                     
                                          </div>
                                          
                                        </div>
                                      </div>
                                    </div>
        
        
@endsection

<!--//scroll change(10-21-2022)/////start-->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>

     function onloader()
            {
               var currency = $('#exchange_currency_ajt').val();
                
                
                
               
              var exchange_price = [];
                var initialdisplyedhotelcount = $(".hotel_append_div").children().length;
                for(var count_i=1; count_i<=initialdisplyedhotelcount; count_i++)
                {
               price=$('.exchange_price1_1_'+count_i+'').text();
               exchange_price.push(price);
              
                
                }
//console.log(exchange_price);
    //  console.log(exchange_price);
    
    
$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            url: "{{ url('convert_currency_by_alj') }}",
            method: 'POST',
            data: {
                 "_token": "{{ csrf_token() }}",
                "currency": currency,
                "exchange_price": exchange_price,
            },
            success: function(result){
                 console.log(result);
           result.forEach(function fn(item, index) {
 var count=index + 1;
   console.log(item);
   $('.exchange_rate_country_price_'+count+'').html(currency+ ' ' + item);
  

})
                 //
                
               
             
              
            },
            error:function(error){
                console.log(error);
            }
        });
        
            
            }
            

  
</script>

<script>
   
$(document).ready(function(){
     var initialdisplyedhotelcount = $(".hotel_append_div").children().length;
    
    $(".div_length").html(initialdisplyedhotelcount);
     var hotel_count = $('.hotelcount').val();
      var grand_hotel_count = $('.hotelcount').val();
        var counter_hotel=0;
       
    
     $('.total_hotel_count').html(`<span style="float: left;color: #d2b254;font-size: x-large;">${hotel_count} Hotel Available</span>`);
    

    var count = true;
   var iteration_count = $('.counter').val();
var temp2='<?php echo  $temp; ?>';
$(window).scroll(function() { 
    
    // 

    var scrolldisplyedhotelcount = $(".hotel_append_div").children().length;
     
    $(".div_length").html(scrolldisplyedhotelcount);
    
     
     if ($(window).scrollTop() + window.innerHeight > $(".scroll_div").height() - 50) {
       //console.log('scorp');
       if(count){
             count = false;
        
          

                                 
                                $.ajax({
                                     url :  '{{URL::to('iteration_filter')}}',
                                     type: 'POST',
                                    data: {_token: '{{ csrf_token() }}', 
                                  "iteration_count":  $('.counter').val(),
                                  
                                          },
                                // dataType: 'json',
                            success: function(response){
                               
                                var hotel_result = response['extracted_hotel_arr'];
                                //console.log(hotel_result);
                                var hotel_type_result = response['extracted_hotel_type_arr'];
                                var hotelcount = response['session_hotel_count'];
                            




for (var i = 0; i < hotel_result.length; i++) {
    
    if(hotel_type_result[i] == 'hotel_bed'){
         var room_count = hotel_result[i]['rooms'].length;
         var hotelbed_data = hotel_result[i];
         var type = hotel_type_result[i];
         var key = i;
       
         var price_markup='<?php echo config('All'); ?>';
         
         var total_price=parseInt(hotel_result[i]['maxRate']) + parseInt(price_markup);
         
        var div =`<div class="hotel-item">
        <div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=${hotel_result[i]['latitude']},${hotel_result[i]['longitude']} &amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>



<div class="modal fade" id="hotelbeds_facility${hotel_result[i]['code']}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Facilities</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12 hotel_facility${hotel_result[i]['code']}">
                                

</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>


                                    <div class="item-media">
                                        <div class="image-cover img-${hotel_result[i]['code']}">
                                            
                                           <img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt="">

                                            
                                        </div>
                                    </div>
                                    <div class="item-body">
                                        <div class="item-title">
                                            <h2>
                                                <a href="{{URL::to('')}}/hotel_detail/${hotel_result[i]['code']}/${hotel_result[i]['name']}/{{'hotelbeds'}}">${hotel_result[i]['name']}</a>
                                            </h2>
                                        </div>
                                        <div class="item-hotel-star">`
                                            if(hotel_result[i]['categoryName'] == "1 STARS"){
            div +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <li><i class="fa fa-star"></i></li>
                       
                    </ul>
                </div>
            </div>`
            }
            if(hotel_result[i]['categoryName'] == "2 STARS"){
            div +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                       
                    </ul>
                </div>
            </div>`
            }
            if(hotel_result[i]['categoryName'] == "3 STARS"){
            div +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                       
                    </ul>
                </div>
            </div>`
            }
            if(hotel_result[i]['categoryName'] == "4 STARS"){
            div +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                       
                    </ul>
                </div>
            </div>`
            }
            if(hotel_result[i]['categoryName'] == "5 STARS"){
            div +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                       
                    </ul>
                </div>
            </div>`
            }
                                         div +=`</div>
                                        
                                        
                                        <div class="item-address location-${hotel_result[i]['code']}-address">
                                            <i class="awe-icon awe-icon-marker-2"></i>
                                         
                                         ${hotel_result[i]['destinationName']}
                                     
                                       
                                        </div>
                                        
                                       
                                        
                                        
                                        <div class="row">
                                            <div class="col-md-10">
                                                
                                            
                                        
                                     
                                </div>
                                        <div class="col-md-2">
                                       <button data-popover-target="popover_${hotel_result[i]['code']}" data-bs-toggle="modal" data-bs-target="#hotelbeds_facility${hotel_result[i]['code']}" type="button" class="btn tooltip-btn btn-primary">Facilities</button>
                                       </div>
                                      </div> 
                                      
                                       <div class="item-address board_div" style="color:green;">`
                                           div +=`<p><i class="fa-solid fa-check"></i>${hotel_result[i]['rooms'][0]['rates'][0]['boardName']}</p>`
                                           
                                            
                                            
                                            
                                            
                                            
                                          
                                        div +=`</div>
                                       
                                       
                                       <div class="item-address available_room" style="color:red;">
                                            <!--<i class="awe-icon awe-icon-marker-2"></i>-->
                                          ${room_count} Rooms Available
                                        </div>
                                       
                                    <div id="popover_${hotel_result[i]['code']}" role="tooltip" class="tooltip-custom absolute invisible opacity-0 transition-opacity duration-300 ">
                                       
                                       <div class="row">
                                        <div calss="col-12 ">
                                            <h3 style="display: none;">Hotel Facilities</h3></div>
                                          
                                   
                                    <div class="col-sm-6 facility_popover_div_${hotel_result[i]['code']}"> <i class="awe-icon awe-icon-check"></i>res_facilities->description->content</div>
                                   
                                            
                                       </div>
                                       
                                        <div data-popper-arrow></div>
                                    </div>

 
   
<div id="popoverCancellation_${hotel_result[i]['code']}" role="tooltip" class="tooltip-custom absolute invisible opacity-0 transition-opacity duration-300 ">
   
   <div class="row">
    <div calss="col-12">
        <h3>cancellation policy</h3></div>    
       <div class="col-sm-12"><span class="RoomFeature__PopoverItem"><span><span><span class="green fontsmallb"></span></span>Risk-free booking!<span></span> Cancel before August 21, 2022 and you'll pay nothing!<span><br></span><span><br></span> Any cancellation received within 2 days prior to the arrival date will incur the first night's charge. Failure to arrive at your hotel or property will be treated as a No-Show .</span></span></div>
      
   </div>
   
    <div data-popper-arrow></div>
</div>
                                        
                                        <div class="item-footer">
                                           

                                        </div>
                                    </div>
                                
                                        
                                    <div class="item-price-more" >
                                        <div class="price">
                                           <span class="amount" style="font-size: 13px; margin-bottom: 2px;"><a style="background:none;color: #28871c;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map">Map View</a> </span>
                                            </div>
                                        <div class="price">
                                        <?php echo $check_in?> <i class="fa-solid fa-arrow-right"></i> <?php echo $check_out; ?></span></br>
                                           <span class="amount" style="font-size: 13px;"> {{$adult_count}}Adults {{$child_count}}Children</span>
                                            </div>
                                            </div>
                                    <div class="item-price-more">
                                        <div class="price">
                                             
                                            <span class="amount exchange_price1_1_${temp2}" style="font-size: 20px;display:none;">${total_price}</span>
                                            <span class="amount exchange_rate_country_price_${temp2}" style="font-size: 20px;"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></span>
                                            
                                        </div>
                                        <div class="vat-top"><i class="awe-icon awe-icon-info"></i> Inclusive of VAT and Taxes</div>
                                        <a style="margin-top: 6px !important;" href="{{URL::to('')}}/hotel_detail/${hotel_result[i]['code']}/${hotel_result[i]['name']}/{{'hotelbeds'}}" class="awe-btn">Book now</a>
                                        <!--<a href="#" class="awe-btn">Book now</a>-->
                                    </div>
                                </div>`;
            
$('.hotel_append_div').append(div);
 getHotelDetailsAndFacilities(hotel_result[i]['code'],hotel_result[i]['code']);
    }
    
    
    if(hotel_type_result[i] == 'travellanda'){
        
        
        var price_markup='<?php echo config('All'); ?>';
        
        var room_count = hotel_result[i]['Options']['Option'].length;
        if(hotel_result[i]['Options']['Option'][0])
        {
           var boardtype = hotel_result[i]['Options']['Option'][0]['BoardType'];  
        }
        else
        {
            var boardtype = '';  
        }
         if(hotel_result[i]['Options']['Option'][0])
        {
          var TotalPrice = parseInt(hotel_result[i]['Options']['Option'][0]['TotalPrice']) + parseInt(price_markup);
        }
        else
        {
            var TotalPrice = '';  
        }
       
        // var TotalPrice = hotel_result[i]['Options']['Option'][0]['TotalPrice'];
        
       
         //var TotalPrice = 600;
        
        //  console.log(room_count);
        
        var div =`<div class="hotel-item">
                    <div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=${hotel_result[i]['latitude']},${hotel_result[i]['longitude']} &amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
                                    <div class="item-media">
                                        <div class="image-cover img-${hotel_result[i]['HotelId']}">
                                            
                                          <img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt="">

                                            
                                        </div>
                                    </div>
                                    <div class="item-body">
                                        <div class="item-title">
                                            <h2>
                                                <a href="{{URL::to('')}}/hotel_detail/${hotel_result[i]['HotelId']}/${hotel_result[i]['HotelName']}/{{'travellanda'}}">${hotel_result[i]['HotelName']}</a>
                                            </h2>
                                        </div>
                                        <div class="item-hotel-star">`
                                            if(hotel_result[i]['StarRating'] == "1"){
            div +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <li><i class="fa fa-star"></i></li>
                       
                    </ul>
                </div>
            </div>`
            }
            if(hotel_result[i]['StarRating'] == "2"){
            div +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                       
                    </ul>
                </div>
            </div>`
            }
            if(hotel_result[i]['StarRating'] == "3"){
            div +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                       
                    </ul>
                </div>
            </div>`
            }
            if(hotel_result[i]['StarRating'] == "4"){
            div +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                       
                    </ul>
                </div>
            </div>`
            }
            if(hotel_result[i]['StarRating'] == "5"){
            div +=`<div class="star-rate">
                <div class="list-star">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                       
                    </ul>
                </div>
            </div>`
            }
                                         div +=`</div>
                                        
                                        
                                        <div class="item-address location-${hotel_result[i]['HotelId']}-address">
                                            <i class="awe-icon awe-icon-marker-2"></i>
                                         
                                         
                                     
                                       
                                        </div>
                                        
                                       
                                        
                                        
                                        <div class="row">
                                            <div class="col-md-10">
                                                
                                            
                                        
                                     
                                </div>
                                        <div class="col-md-2">
                                      <button style="display: none;" data-popover-target="popover_${hotel_result[i]['HotelId']}" type="button" class="btn tooltip-btn btn-primary">Facilities</button>
                                      </div>
                                      </div> 
                                      
                                      <div class="item-address board_div" style="color:green;">`
                                          div +=`<p><i class="fa-solid fa-check"></i>${boardtype}</p>`
                                           
                                            
                                            
                                            
                                            
                                            
                                          
                                        div +=`</div>
                                       
                                       
                                      <div class="item-address available_room" style="color:red;">
                                            <!--<i class="awe-icon awe-icon-marker-2"></i>-->
                                          ${room_count} Rooms Available
                                        </div>
                                       
                                    <div id="popover_${hotel_result[i]['HotelId']}" role="tooltip" class="tooltip-custom absolute invisible opacity-0 transition-opacity duration-300 ">
                                       
                                      <div class="row">
                                        <div calss="col-12 ">
                                            <h3 style="display: none;">Hotel Facilities</h3></div>
                                          
                                   
                                    <div class="col-sm-6 facility_popover_div_${hotel_result[i]['HotelId']}"> <i class="awe-icon awe-icon-check"></i></div>
                                   
                                            
                                      </div>
                                       
                                        <div data-popper-arrow></div>
                                    </div>

 
   
<div id="popoverCancellation_${hotel_result[i]['HotelId']}" role="tooltip" class="tooltip-custom absolute invisible opacity-0 transition-opacity duration-300 ">
   
  <div class="row">
    <div calss="col-12">
        <h3>cancellation policy</h3></div>    
      <div class="col-sm-12"><span class="RoomFeature__PopoverItem"><span><span><span class="green fontsmallb"></span></span>Risk-free booking!<span></span> Cancel before August 21, 2022 and you'll pay nothing!<span><br></span><span><br></span> Any cancellation received within 2 days prior to the arrival date will incur the first night's charge. Failure to arrive at your hotel or property will be treated as a No-Show .</span></span></div>
      
  </div>
   
    <div data-popper-arrow></div>
</div>
                                        
                                        <div class="item-footer">
                                           

                                        </div>
                                    </div>
                                
                                        
                                    <div class="item-price-more" >
                                        <div class="price">
                                          <span class="amount" style="font-size: 13px;display: none; margin-bottom: 2px;"><a style="background:none;color: #28871c;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map">Map View</a> </span>
                                            </div>
                                        <div class="price">
                                        <?php echo $check_in?> <i class="fa-solid fa-arrow-right"></i> <?php echo $check_out; ?></span></br>
                                          <span class="amount" style="font-size: 13px;"> {{$adult_count}}Adults {{$child_count}}Children</span>
                                            </div>
                                            </div>
                                    <div class="item-price-more">
                                        <div class="price">
                                             
                                            
                                               
                                            <span class="amount exchange_price1_1_${temp2}" style="font-size: 20px;display:none;">${TotalPrice} </span>
                                             <span class="amount exchange_rate_country_price_${temp2}" style="font-size: 20px;"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></span>
                                            
                                        </div>
                                        <div class="vat-top"><i class="awe-icon awe-icon-info"></i> Inclusive of VAT and Taxes</div>
                                        <a style="margin-top: 6px !important;" href="{{URL::to('')}}/hotel_detail/${hotel_result[i]['HotelId']}/${hotel_result[i]['HotelName']}/{{'travellanda'}}" class="awe-btn">Book now</a>
                                        <!--<a href="#" class="awe-btn">Book now</a>-->
                                    </div>
                                </div>`;
            

        
$('.hotel_append_div').append(div);
 gettravellandaHotelDetailsAndFacilities(hotel_result[i]['HotelId'],hotel_result[i]['HotelId']);
        
        
        
        
        
    }


    if(hotel_type_result[i] == 'tbo'){
       var tbo_data = hotel_result[i];
       var type = hotel_type_result[i];
       var key = i;
       var price_markup='<?php echo config('All'); ?>';
       var price = parseInt(hotel_result[i]['Rooms'][0]['TotalFare']) + parseInt(price_markup);
       var currency = hotel_result[i]['Currency'];
       
        
       
        
        var div =`<div class="hotel-item">
                    <div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=latitude,longitude &amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
                                    <div class="item-media">
                                        <div class="image-cover img-${hotel_result[i]['HotelCode']}">
                                            
                                          <img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt="">

                                            
                                        </div>
                                    </div>
                                    <div class="item-body">
                                        <div class="item-title hotel_title_${hotel_result[i]['HotelCode']}">
                                            <h2>
                                                <a href="{{URL::to('')}}/hotel_detail/${hotel_result[i]['HotelCode']}/name/{{'Tbo'}}">name</a>
                                            </h2>
                                        </div>
                                        <div class="item-hotel-star">
                                          
          <div class="star-rate">
                <div class="list-star rating-${hotel_result[i]['HotelCode']}">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">
                        
                            <li><i class="fa fa-star"></i></li>
                       
                    </ul>
                </div>
            </div>
        
           
                                         </div>
                                        
                                        
                                        <div class="item-address location-${hotel_result[i]['HotelCode']}-address">
                                            <i class="awe-icon awe-icon-marker-2"></i>
                                         
                                         destinationName
                                     
                                       
                                        </div>
                                        
                                       
                                        
                                        
                                        <div class="row">
                                            <div class="col-md-10">
                                                
                                            
                                        
                                     
                                </div>
                                        <div class="col-md-2">
                                      <button style="display: none;" data-popover-target="popover_${hotel_result[i]['HotelCode']}" type="button" class="btn tooltip-btn btn-primary">Facilities</button>
                                      </div>
                                      </div> 
                                      
                                      <div class="item-address board_div" style="color:green;display: none;">`
                                          div +=`<p><i class="fa-solid fa-check"></i>roomsboardName</p>`
                                           
                                            
                                            
                                            
                                            
                                            
                                          
                                        div +=`</div>
                                       
                                       
                                      <div class="item-address available_room_${hotel_result[i]['HotelCode']}" style="color:red;>
                                          
                                          Rooms Available
                                        </div>
                                       
                                    <div id="popover_${hotel_result[i]['HotelCode']}" role="tooltip" class="tooltip-custom absolute invisible opacity-0 transition-opacity duration-300 ">
                                       
                                      <div class="row">
                                        <div calss="col-12 ">
                                            <h3 style="display: none;">Hotel Facilities</h3></div>
                                          
                                   
                                    <div class="col-sm-6 facility_popover_div_${hotel_result[i]['HotelCode']}"> <i class="awe-icon awe-icon-check"></i></div>
                                   
                                            
                                      </div>
                                       
                                        <div data-popper-arrow></div>
                                    </div>

 
   
<div id="popoverCancellation_${hotel_result[i]['HotelCode']}" role="tooltip" class="tooltip-custom absolute invisible opacity-0 transition-opacity duration-300 ">
   
  <div class="row">
    <div calss="col-12">
        <h3>cancellation policy</h3></div>    
      <div class="col-sm-12"><span class="RoomFeature__PopoverItem"><span><span><span class="green fontsmallb"></span></span>Risk-free booking!<span></span> Cancel before August 21, 2022 and you'll pay nothing!<span><br></span><span><br></span> Any cancellation received within 2 days prior to the arrival date will incur the first night's charge. Failure to arrive at your hotel or property will be treated as a No-Show .</span></span></div>
      
  </div>
   
    <div data-popper-arrow></div>
</div>
                                        
                                        <div class="item-footer">
                                <div class="item-rate">
                                                <span></span>
                                            </div>
                                            <div class="item-icon">
                                                <i class="awe-icon awe-icon-gym"></i>
                                                <i class="awe-icon awe-icon-car"></i>
                                                <i class="awe-icon awe-icon-food"></i>
                                                <i class="awe-icon awe-icon-level"></i>
                                                <i class="awe-icon awe-icon-wifi"></i>
                                            </div>
                                        </div>
                                    </div>
                                
                                        
                                    <div class="item-price-more" >
                                        <div class="price">
                                          <span class="amount" style="font-size: 13px; margin-bottom: 2px;"><a style="background:none;color: #28871c;display: none;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map">Map View</a> </span>
                                            </div>
                                        <div class="price">
                                        <?php echo $check_in?> <i class="fa-solid fa-arrow-right"></i> <?php echo $check_out; ?></span></br>
                                          <span class="amount" style="font-size: 13px;"> {{$adult_count}}Adults {{$child_count}}Children</span>
                                            </div>
                                            </div>
                                    <div class="item-price-more book-now-btn-${hotel_result[i]['HotelCode']}">
                                        <div class="price">
                                            
                                          
                                             <span class="amount exchange_price1_1_${temp2}" style="font-size: 20px;display:none;">${price}</span>
                                            <span class="amount exchange_rate_country_price_${temp2}" style="font-size: 20px;"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></span>
                                            
                                        </div>
                                        <div class="vat-top"><i class="awe-icon awe-icon-info"></i> Inclusive of VAT and Taxes</div>
<div class="hotel_book_${hotel_result[i]['HotelCode']}"><a style="margin-top: 6px !important;" href="{{URL::to('')}}/hotel_detail/${hotel_result[i]['HotelCode']}/name/{{'Tbo'}}" class="awe-btn">Book now</a></div>
                                       
                                    </div>
                                </div>`;
            

        
$('.hotel_append_div').append(div);
 gettboHotelDetailsAndFacilities(hotel_result[i]['HotelCode'],hotel_result[i]['HotelCode']);
        
        
        
        
        
    }
    
    
    if(hotel_type_result[i] == 'ratehawk'){
    var ratehawk_data = hotel_result[i];
    var type = hotel_type_result[i];
    var key = i;
    
    var price_markup='<?php echo config('All'); ?>';
    
   var currency = hotel_result[i]['rates'][0]['payment_options']['payment_types'][0]['show_currency_code'];
   var price = parseInt(hotel_result[i]['rates'][0]['payment_options']['payment_types'][0]['show_amount']) + parseInt(price_markup);
        
        var div =`<div class="hotel-item">
                    <div class="modal fade" id="hotelbeds_map" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hotel Location</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="row">
<div class="col-12 col-md-12">
                                
<div style="width: 95%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=latitude,longitude &amp;t=&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
</div>  
  </div>                                 
      </div>
      
    </div>
  </div>
</div>
                                    <div class="item-media">
                                        <div class="image-cover img-${hotel_result[i]['id']}">
                                            
                                          <img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt="">

                                            
                                        </div>
                                    </div>
                                    <div class="item-body">
                                        <div class="item-title hotel_title_${hotel_result[i]['id']}">
                                            <h2>
                                                <a href="{{URL::to('')}}/hotel_detail/${hotel_result[i]['id']}/name/{{'ratehawke'}}">ratehawkname</a>
                                            </h2>
                                        </div>
                                        <div class="item-hotel-star">
                                          
          <div class="star-rate">
                <div class="list-star rating-${hotel_result[i]['id']}">
                    <ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;">
                        
                            <li><i class="fa fa-star"></i></li>
                       
                    </ul>
                </div>
            </div>
        
           
                                         </div>
                                        
                                        
                                        <div class="item-address location-${hotel_result[i]['id']}-address">
                                            <i class="awe-icon awe-icon-marker-2"></i>
                                         
                                         destinationName
                                     
                                       
                                        </div>
                                        
                                       
                                        
                                        
                                        <div class="row">
                                            <div class="col-md-10">
                                                
                                            
                                        
                                     
                                </div>
                                        <div class="col-md-2">
                                      <button style="display: none;" data-popover-target="popover_${hotel_result[i]['id']}" type="button" class="btn tooltip-btn btn-primary">Facilities</button>
                                      </div>
                                      </div> 
                                      
                                      <div class="item-address board_div" style="color:green;display: none;">`
                                          div +=`<p><i class="fa-solid fa-check"></i>roomsboardName</p>`
                                           
                                            
                                            
                                            
                                            
                                            
                                          
                                        div +=`</div>
                                       
                                       
                                      <div class="item-address available_room_${hotel_result[i]['id']}" style="color:red;>
                                          
                                          Rooms Available
                                        </div>
                                       
                                    <div id="popover_${hotel_result[i]['id']}" role="tooltip" class="tooltip-custom absolute invisible opacity-0 transition-opacity duration-300 ">
                                       
                                      <div class="row">
                                        <div calss="col-12 ">
                                            <h3 style="display: none;">Hotel Facilities</h3></div>
                                          
                                   
                                    <div class="col-sm-6 facility_popover_div_${hotel_result[i]['id']}"> <i class="awe-icon awe-icon-check"></i></div>
                                   
                                            
                                      </div>
                                       
                                        <div data-popper-arrow></div>
                                    </div>

 
   
<div id="popoverCancellation_${hotel_result[i]['HotelCode']}" role="tooltip" class="tooltip-custom absolute invisible opacity-0 transition-opacity duration-300 ">
   
  <div class="row">
    <div calss="col-12">
        <h3>cancellation policy</h3></div>    
      <div class="col-sm-12"><span class="RoomFeature__PopoverItem"><span><span><span class="green fontsmallb"></span></span>Risk-free booking!<span></span> Cancel before August 21, 2022 and you'll pay nothing!<span><br></span><span><br></span> Any cancellation received within 2 days prior to the arrival date will incur the first night's charge. Failure to arrive at your hotel or property will be treated as a No-Show .</span></span></div>
      
  </div>
   
    <div data-popper-arrow></div>
</div>
                                        
                                        <div class="item-footer">
                                <div class="item-rate">
                                                <span></span>
                                            </div>
                                            <div class="item-icon">
                                                <i class="awe-icon awe-icon-gym"></i>
                                                <i class="awe-icon awe-icon-car"></i>
                                                <i class="awe-icon awe-icon-food"></i>
                                                <i class="awe-icon awe-icon-level"></i>
                                                <i class="awe-icon awe-icon-wifi"></i>
                                            </div>
                                        </div>
                                    </div>
                                
                                        
                                    <div class="item-price-more" >
                                        <div class="price">
                                          <span class="amount" style="font-size: 13px; margin-bottom: 2px;"><a style="background:none;color: #28871c;display: none;" href="javascript:;" data-bs-toggle="modal" data-bs-target="#hotelbeds_map">Map View</a> </span>
                                            </div>
                                        <div class="price">
                                        <?php echo $check_in?> <i class="fa-solid fa-arrow-right"></i> <?php echo $check_out; ?></span></br>
                                          <span class="amount" style="font-size: 13px;"> {{$adult_count}}Adults {{$child_count}}Children</span>
                                            </div>
                                            </div>
                                    <div class="item-price-more book-now-btn-${hotel_result[i]['id']}">
                                        <div class="price priceandcurrency_${hotel_result[i]['id']}">
                                            
                                            <span class="amount exchange_price1_1_${temp2}" style="font-size: 20px;display:none;">${price}</span>
                                            <span class="amount exchange_rate_country_price_${temp2}" style="font-size: 20px;"><img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" class="img-responsive" alt=""></span>
                                            
                                        </div>
                                        <div class="vat-top"><i class="awe-icon awe-icon-info"></i> Inclusive of VAT and Taxes</div>
<div class="hotel_book_${hotel_result[i]['id']}"><a style="margin-top: 6px !important;" href="{{URL::to('')}}/hotel_detail/${hotel_result[i]['id']}/name/{{'ratehawke'}}" class="awe-btn">Book now</a></div>
                                       
                                    </div>
                                </div>`;
            

        
$('.hotel_append_div').append(div);
 getratehawkHotelDetailsAndFacilities(hotel_result[i]['id'],hotel_result[i]['id']);
        
        
        
        
        
    }
   onloader();
  console.log('i'+i); 
 counter_hotel=counter_hotel+1; 
 temp2=+temp2 + +1;
}



 



var increased = parseFloat($('.counter').val()) + 5;

$('.counter').val(increased);
count = true;
             
                            }
                                });
          
       }
      
      
    }
    console.log('grand_hotel_count ='+grand_hotel_count); 
       var grand_hotel_count1=counter_hotel+initialdisplyedhotelcount;
        console.log('grand_hotel_count1 ='+grand_hotel_count1); 
     if(grand_hotel_count1 >= grand_hotel_count)
    {
        
        $("#loder_hides").css("display", "none");
    }
   
});

function getHotelDetailsAndFacilities(hotel_code,inc_id){
    // console.log(hotel_code);
    $.ajax({
            url: '{{ URL::to("get_hotel_detail_ajaxdd") }}',
            method: "POST",
            data: {
                _token: '{{ csrf_token() }}', 
                code: hotel_code, 
            },
            success: function (response) {
               
                var hotel_bed_content =JSON.parse(response);
                //  console.log(hotel_bed_content);
                // console.log(['images'][0]['path']);
                var img_path = hotel_bed_content['images'][0]['path'];
                var address = hotel_bed_content['address']['content'];
                var board = hotel_bed_content['boards'];
                var description = hotel_bed_content['description']['content'];
                var faciliti = hotel_bed_content['facilities'];
                console.log(faciliti[0]['description']['content']);
                // console.log("address"+address);
                // console.log(board[0]['description']['content']);
                
                var img = `<img src="https://photos.hotelbeds.com/giata/bigger/${img_path}" class="img-responsive" alt="">`;
                  $('.img-'+inc_id+'').html(img);
                  
                  $('.location-'+inc_id+'-address').html(`<p><i class="awe-icon awe-icon-marker-2"></i> ${address}</p>`);
                  var text = description;
                 var des = text.substr(0, 50);
                  $('.item-'+inc_id+'-content').html(`<p>${des}</p>`);
                  for(var i = 0;i < 5; i++){
                  $('.hotel_facility'+inc_id+'').append(`<p>${faciliti[i]['description']['content']}</p>`);
                  }
                  
                  for(var i = 0;i < 2; i++){
                    //  $('.g-attributes-'+inc_id+'-board').append(`<span class="item term"><i class="icofont-medal"></i>${board[i]['description']['content']}</span>`);  
                  }
                 
           
            }
    }).done(function( msg ) {
                console.log('hotelbed is complete now ');
            
        });
}





function gettravellandaHotelDetailsAndFacilities(hotel_code,inc_id){
    $.ajax({
            url: '{{ URL::to("get_travellandahotel_detail_ajax") }}',
            method: "POST",
            data: {
                _token: '{{ csrf_token() }}', 
                code: hotel_code, 
            },
            success: function (response) {
                console.log(response);
                var travellanda_content =JSON.parse(response);
                var travellanda_contents =JSON.parse(travellanda_content);
                // console.log(travellanda_contents['Body']['Hotels']['Hotel']['Images']['Image'][0]);
                var img_path = travellanda_contents['Body']['Hotels']['Hotel']['Images']['Image'][0];
                var address = travellanda_contents['Body']['Hotels']['Hotel']['Address'];
                var board = travellanda_contents['Body']['Hotels']['Hotel']['Facilities']['Facility']
                var description = travellanda_contents['Body']['Hotels']['Hotel']['Description'];
                // console.log(img_path);
                // console.log(address);
                // console.log(board);
                // console.log(description);
                
                var img = `<img src="${img_path}" class="img-responsive" alt="">`;
                  $('.img-'+inc_id+'').html(img);
                  
                  $('.location-'+inc_id+'-address').html(`<p><i class="icofont-paper-plane"></i> ${address}</p>`);
                  var text = description;
                 var des = text.substr(0, 50);
                  
                  $('.item-'+inc_id+'-content').html(`<p>${des}</p>`);
                  
                  for(var i = 0;i < 2; i++){
                     $('.g-attributes-'+inc_id+'-board').append(`<span class="item term"><i class="icofont-medal"></i>${board[i]['FacilityName']}</span>`);  
                  }
            }
    }).done(function( msg ) {
                //console.log('travellanda is complete now ');
            
        });
}





function gettboHotelDetailsAndFacilities(hotel_code,inc_id){
    $.ajax({
            url: '{{ URL::to("get_tbohotel_detail_ajax") }}',
            method: "POST",
            data: {
                _token: '{{ csrf_token() }}', 
                code: hotel_code, 
            },
            success: function (response) {

                var tbo_content =JSON.parse(response);
                var tbo_content =JSON.parse(tbo_content);
                
                var hotelcode = tbo_content['data']['hotel_code'];
                
                var img = tbo_content['data']['images'];
               
                var img_pathz = JSON.parse(img);
                var img_path = img_pathz[1];
                 
                var hotel_name = tbo_content['data']['hotel_name'];
                
                var address = tbo_content['data']['address'];
                 
                var rating = tbo_content['data']['hotel_rating'];
                
                var phone_no = tbo_content['data']['phone_no'];
                // console.log(img_path);
                // console.log(address);
                // console.log(rating);
                // console.log(phone_no);
                
                var img = `<img src="${img_path}" class="img-responsive" alt="">`;
                  $('.img-'+inc_id+'').html(img);
                  
                var title =  $('.hotel_title_'+inc_id+'').html(`<h2>
                                                <a href="{{URL::to('')}}/hotel_detail/${hotelcode}/${hotel_name}/{{'tbo'}}">${hotel_name}</a>
                                  </h2>`)
                var title =  $('.hotel_book_'+inc_id+'').html(`
                                                <a style="background: rgb(40, 135, 28);color: #fff;" class="awe-btn" href="{{URL::to('')}}/hotel_detail/${hotelcode}/${hotel_name}/{{'tbo'}}">Book Now</a>
                                 `)
                  
                  $('.location-'+inc_id+'-address').html(`<p><i class="awe-icon awe-icon-marker-2"></i> ${address}</p>`);
              
                  $('.available_room_'+inc_id+'').html(`<p>${phone_no}</p>`);
                  
                  var unorderlist =`<ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">`
                  if(rating == 1){
                      unorderlist+=`<li><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 2){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 3){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 4){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 5){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  
                  
                  
                  `</ul>`;
                  
                  
                  $('.rating-'+inc_id+'').html(unorderlist);
                  
               
               
            }
    }).done(function( msg ) {
                console.log('tbo is complete now ');
            
        });
}




function getratehawkHotelDetailsAndFacilities(hotel_code,inc_id){
    $.ajax({
            url: '{{ URL::to("get_ratehawkhotel_detail_ajax") }}',
            method: "POST",
            data: {
                _token: '{{ csrf_token() }}', 
                code: hotel_code, 
            },
            success: function (response) {

                var rate_content =JSON.parse(response);
               
                var hotelcode = rate_content['id'];
                
                var img_path = rate_content['images'][0];
                var strArray = img_path.split("{size}");
                var img_path = strArray[0]+'1024x768'+strArray[1];
                console.log(strArray);
               
                var hotel_name = rate_content['name'];
                
                var address = rate_content['address'];
                 
                var rating = rate_content['star_rating'];
                
                var phone_no = rate_content['phone'];
                // console.log(img_path);
                // console.log(address);
                // console.log(rating);
                // console.log(phone_no);
                
                var img = `<img src="${img_path}" class="img-responsive" alt="">`;
                  $('.img-'+inc_id+'').html(img);
                  
                var title =  $('.hotel_title_'+inc_id+'').html(`<h2>
                                                <a href="{{URL::to('')}}/hotel_detail/${hotelcode}/${hotel_name}/{{'ratehawke'}}">${hotel_name}</a>
                                  </h2>`)
                var title =  $('.hotel_book_'+inc_id+'').html(`
                                                <a style="background: rgb(40, 135, 28);color: #fff;" class="awe-btn" href="{{URL::to('')}}/hotel_detail/${hotelcode}/${hotel_name}/{{'ratehawke'}}">Book Now</a>
                                 `)
                  
                  $('.location-'+inc_id+'-address').html(`<p><i class="awe-icon awe-icon-marker-2"></i> ${address}</p>`);
              
                  $('.available_room_'+inc_id+'').html(`<p>${phone_no}</p>`);
                  
                  var unorderlist =`<ul class="booking-item-rating-stars" style="display: flex;margin-bottom: 0rem !important;margin-left: -2rem;">`
                  if(rating == 1){
                      unorderlist+=`<li><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 2){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 3){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 4){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  if(rating == 5){
                      unorderlist+=`<li><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><li>`
                  }
                  
                  
                  
                  `</ul>`;
                  
                  
                  $('.rating-'+inc_id+'').html(unorderlist);
                  
              
    
            }
    }).done(function( msg ) {
                console.log('ratehawk is complete now ');
            
        });
}
});





</script>

<!--//scroll change(10-21-2022)/////end-->
