@extends('template/frontend/includes/master')

@section('content')
    <section class="awe-parallax category-heading-section-demo h-300">
            <div class="awe-overlay"></div>
           
            </div>
        </section>
        <section class="checkout-section-demo">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="checkout-page__top">
                            <div class="title">
                                <h1 class="text-uppercase">Sign Up</h1>
                            </div>
                            <span class="phone">Support Call: 0121 777 2522</span>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="checkout-page__sidebar">
                            <ul>
                                <li><a href="{{ route('cart') }}">Your Cart</a></li>
                                <li class="current"><a href="checkout-customer.php">Customer information</a></li>
                                <li><a href="checkout-complete.php">Complete order</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        @if (session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            {{ session('error') }}
                           <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        @endif
                        <div class="checkout-page__content">
                            <form method="post" class="row g-3" action="{{ url('submit_sign_up') }}">
                                 @csrf
                              <div class="col-md-3">
                                <label for="inputEmail4" class="form-label">First name</label>
                                <input type="text" class="form-control" id="inputEmail4" required value="" name="name">
                              </div>
                              <div class="col-md-3">
                                <label for="inputPassword4" class="form-label">Last name</label>
                                <input type="text" class="form-control" id="inputPassword4" required value="" name="lname">
                              </div>
                              <div class="col-3">
                                <label for="inputAddress" class="form-label">Email</label>
                                <input type="email" class="form-control" id="inputAddress" required value="@if(session('passengerDetail')) {{ session('passengerDetail')[0]['email'] }} @endif" name="email">
                              </div>
                              <div class="col-3">
                                <label for="inputAddress" class="form-label">Password</label>
                                <input type="password" class="form-control" id="inputAddress" required value="@if(session('passengerDetail')) {{ session('passengerDetail')[0]['email'] }} @endif" name="password">
                              </div>
                              
                             
                              
                              <div class="col-4">
                                <label for="inputAddress" class="form-label">Country</label>
                                    <select class="form-select" id="country" onchange="fetch_country_code()" name="country">
                                   @foreach($countries as $country_res)
                                        <option value="{{ $country_res->name }}" >{{ $country_res->name }}</option>
                                    @endforeach
                                    </select>                              
                                </div>
                              
                              <div class="col-4">
                                <label for="inputAddress" class="form-label">Phone</label>
                                <input type="text" class="form-control" required id="country_code" value="" name="phone">
                              </div>
                              <div class="col-md-4">
                                <div class="row" style="margin-top:2.5rem">
                                            <div class="col-md-4">
                                                <label for="">Gender</label>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-check radio-inline">
                                                <input class="form-check-input" type="radio" name="gender" id="gender1" value="male" checked >
                                                <label class="form-check-label" for="gender1">
                                                    Male
                                                </label>
                                            </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-check radio-inline">
                                                <input class="form-check-input" type="radio" name="gender" id="gender2" value="female" >
                                                <label class="form-check-label" for="exampleRadios2">
                                                    Female
                                                </label>
                                                </div>
                                            </div>
                                        
                                         
                                        </div>
                              </div>
                              
                              <div class="col-md-4">
                                <label for="inputEmail4" class="form-label">Passport No</label>
                                <input type="text" class="form-control" required value="" name="passport_no">
                              </div>
                              <div class="col-md-4">
                                <label for="inputPassword4" class="form-label">Nationality</label>
                                        <input type="text" name="passengerType" hidden value="adults" class="form-control">
                                        <select class="form-select" name="Nationality">
                                   @foreach($countries as $country_res)
                                        <option value="{{ $country_res->name }}" >{{ $country_res->name }}</option>
                                    @endforeach
                                    </select>  
                              </div>
                           
                              <div class="col-12">
                                <label for="inputAddress2" class="form-label">Address</label>
                                <input type="text" class="form-control" required value="" type="text" name="address">
                              </div>
                              

                              <div class="col-12">
                                    <button class="btn" style="background-color:#d2b254; color:white;" type="submit">Next</button>
                              </div>
                            </form>
                        </div>
                    
                    </div>
                </div>
            </div>
        </section>
        <!-- Button trigger modal -->

@endsection

@section('scripts')
<script>
    function fetch_country_code(){
        var name = $('#country').val();
        console.log('this is call now'+name);
        $.ajax({
            url: "{{ URL::to('get_country_code') }}",
            method: "post",
            data: {
                _token: '{{ csrf_token() }}', 
                country: name
            },
            success: function (response) {
                // window.location.reload();
                console.log(response);
                $('#country_code').val(response);
            }
        });
    }
    fetch_country_code();
    
    //  <div id="payment_gatway">
                                                                 
    //                                                          </div>
    //                                                          <a href="{{ URL::to('submit_booking') }}" id="checkout_button" style="display:none" class="btn" style="background-color:#d2b254; color:white;">Confirm Booking</a>


    

</script>
@endsection