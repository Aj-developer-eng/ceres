@extends('template/frontend/userdashboard/layout/default')
@section('content')

        <section class="awe-parallax category-heading-section-demo h-300">
            <div class="awe-overlay"></div>
           
            </div>
        </section>
   <section class="checkout-section-demo">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="checkout-page__top">
                            <div class="title">
                                <h1 class="text-uppercase">CHECKOUT</h1>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="col-lg-12">
                        <div class="checkout-page__content">
                            <div class="yourcart-content">
                                <div class="content-title">
                                    <h2><i class="awe-icon awe-icon-cart"></i>Check Your Cart</h2>
                                </div>
                                <div class="cart-content">
                                    <table class="table table-centered w-100 dt-responsive nowrap">
                                        <thead>
                                            <tr>
                                                <th width="15%"></th>
                                                <th width="15%">Title</th>
                                                <th width="27%">Sale Price</th>
                                                <th width="7%">Cost Price</th>
                                                <th width="7%">Markup</th>
                                                <th width="7%">Adults/Children</th>
                                                <th width="11%" style="text-align:right">Total Price</th>
                                                <th width="11%" style="text-align:right">Discount Price</th>
                                                <th width="10%" style="text-align:right">Remove Booking</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php $total = 0; $counter = 1; 
                                                $adults_count = 0;
                                            @endphp
                               
                                            @if(session('cart'))
                                            
                                            <?php 
                                                $main_cart = session('cart');
                                                if($main_cart[1] == 'tour'){
                                                    $cart_data = $main_cart[0];
                                            ?>
                                                      @foreach($cart_data as $id => $details)
                                                    <tr data-id="{{ $id }}">
                                                        <td style="padding:5px;">
                                                            <img style="height:100px;  width:100%; overflow:hidden;" src="{{ config('img_url') }}/public/uploads/package_imgs/{{ $details['image'] }}" alt="" class="flex-shrink-0">    
                                                        </td>
                                                        
                                                        <td>
                                                            <span>{{ $details['name'] }}</span>
                                                        </td>
                                                        
                                                        <td class="product-price">
                                                            <div class="row">
                                                                <div class="col-md-8">
                                                                    <select name="adults" id="sharing{{ $id }}" onchange="changeSharing({{ $id }})" style="font-size:.9rem;" class=" form-select">
                                                                        @if($details['sharing2'] != 0 AND $details['sharing2'] != null AND $details['sharing2'] != '') 
                                                                        <option value="sharing2" @if($details["sharingSelect"] == 'sharing2') selected @endif>Double /{{ $details['currency'] }} {{ $details['sharing2'] }}</option>
                                                                         @endif
                                                                         @if($details['sharing3'] != 0 AND $details['sharing3'] != null AND $details['sharing3'] != '') 
                                                                        <option value="sharing3" @if($details["sharingSelect"] == 'sharing3') selected @endif>Triple /{{ $details['currency'] }} {{ $details['sharing3'] }}</option>
                                                                          @endif
                                                                         @if($details['sharing4'] != 0 AND $details['sharing4'] != null AND $details['sharing4'] != '') 
                                                                        <option value="sharing4" @if($details["sharingSelect"] == 'sharing4') selected @endif>Quad /{{ $details['currency'] }} {{ $details['sharing4'] }}</option>
                                                                        @endif
                                                                    </select>
                                                                </div>
                                                                <div class="col-md-4" style="margin-top: 10px;"><span class="amount" style="font-size:.9rem;">{{ $details['currency'] }} {{ $details['sigle_price'] }}</span>
                                                                    <br>
                                                                    {{ $details['currency'] }} {{ $details['child_price'] }}
                                                                </div>
                                                            </div>
                                                        </td>
                                                        
                                                        <td>
                                                            <div><span>{{ $details['currency'] }}</span><span>{{ $details['cost_price'] ?? '' }}</span></div>
                                                        </td>
                                                        
                                                        <td>
                                                            <div><span>{{ $details['currency'] }}</span><span id="cost_price_final{{$id}}">{{ $details['markup_Price'] ?? '' }}</span></div>
                                                        </td>
                                                        
                                                        <td>
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-elements form-adult">
                                                                        <div class="form-item">
                                                                            <select id="adults{{ $id }}" onchange="changeSharing({{ $id }})" name="adults" class="awe-select">
                                                                                <option @if($details["adults"] == 0) selected @endif>0</option>
                                                                                <option @if($details["adults"] == 1) selected @endif>1</option>
                                                                                <option @if($details["adults"] == 2) selected @endif>2</option>
                                                                                <option @if($details["adults"] == 3) selected @endif>3</option>
                                                                                <option @if($details["adults"] == 4) selected @endif>4</option>
                                                                                <option @if($details["adults"] == 5) selected @endif>5</option>
                                                                                <option @if($details["adults"] == 6) selected @endif>6</option>
                                                                                <option @if($details["adults"] == 7) selected @endif>7</option>
                                                                                <option @if($details["adults"] == 8) selected @endif>8</option>
                                                                                <option @if($details["adults"] == 9) selected @endif>9</option>
                                                                                <option @if($details["adults"] == 10) selected @endif>10</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="form-elements form-adult">
                                                                        <div class="form-item">
                                                                            <select name="children" id="child{{ $id }}" onchange="changeSharing({{ $id }})" class="awe-select">
                                                                                <option @if($details["children"] == 0) selected @endif>0</option>
                                                                                <option @if($details["children"] == 1) selected @endif>1</option>
                                                                                <option @if($details["children"] == 2) selected @endif>2</option>
                                                                                <option @if($details["children"] == 3) selected @endif>3</option>
                                                                                <option @if($details["children"] == 4) selected @endif>4</option>
                                                                                <option @if($details["children"] == 5) selected @endif>5</option>
                                                                                <option @if($details["children"] == 6) selected @endif>6</option>
                                                                                <option @if($details["children"] == 7) selected @endif>7</option>
                                                                                <option @if($details["children"] == 8) selected @endif>8</option>
                                                                                <option @if($details["children"] == 9) selected @endif>9</option>
                                                                                <option @if($details["children"] == 10) selected @endif>10</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                        </td>
                                                        
                                                        <td class="product-subtotal" style="text-align: right;"> 
                                                            <input type="text" value="{{ $details['tour_total_price'] }}" name="tour_total_price" id="total_Price{{$id}}" class="form-control" readonly/>
                                                            <!--<span id="total_Price{{$id}}">{{ $details['tour_total_price'] }}</span>-->
                                                        </td>
                                                        
                                                        <td>
                                                            <input type="text" id="tours_id{{$id}}" value="{{ $id }}" hidden/>
                                                            <input type="number" value="{{ $details['discount_Price'] }}" name="discount_Price" onchange=discount_Price1({{ $id }}) id="discount_Price{{$id}}" class="form-control" />
                                                        </td>
                                                        
                                                        <td style="text-align: right;">
                                                            <button class="btn btn-danger" onclick="removeItem({{ $id }})"><i class="mdi mdi-close"></i></button>
                                                        </td>
                                                    </tr>
                                                    <?php 
                                                        if($details['Additional_services_names'] != ''){
                                                            ?>
                                                    <tr>
                                                        <td><span style="width: 40px;font-size: 18px;font-weight: bolder;">Additonal Service</span></td>
                                                        <td>{{ $details['Additional_services_names'] }}</td>
                                                        <td>{{ $details['currency'] }} {{ $details['services_price'] }} - Days: {{ $details['service_day'] }}
                                                            <input type="text" hidden id="prev_total{{ $details['tourId'] }}inc1" value="{{ $details['services_price'] * ($details['services_persons'] * $details['service_day'])}}">
                                                        </td>
                                                        <td>  <select name="service" id="service{{ $details['tourId'] }}inc1" onchange="changeAddtionalService('{{ $details['Additional_services_names'] }}',{{ $id }},-1,'{{ $details['services_price'] }}','{{ $details['service_day'] }}',1)" class="awe-select">
                                                                    <option @if($details["services_persons"] == 0) selected @endif>0</option>
                                                                    <option @if($details["services_persons"] == 1) selected @endif>1</option>
                                                                    <option @if($details["services_persons"] == 2) selected @endif>2</option>
                                                                    <option @if($details["services_persons"] == 3) selected @endif>3</option>
                                                                    <option @if($details["services_persons"] == 4) selected @endif>4</option>
                                                                    <option @if($details["services_persons"] == 5) selected @endif>5</option>
                                                                    <option @if($details["services_persons"] == 6) selected @endif>6</option>
                                                                    <option @if($details["services_persons"] == 7) selected @endif>7</option>
                                                                    <option @if($details["services_persons"] == 8) selected @endif>8</option>
                                                                    <option @if($details["services_persons"] == 9) selected @endif>9</option>
                                                                    <option @if($details["services_persons"] == 10) selected @endif>10</option>
                                                                </select>
                                                           </td>
                                                        <td style="text-align:right;">{{ $details['currency'] }} {{ $details['services_price'] * ($details['services_persons'] * $details['service_day'])}}</td>
                                                        <td>
                                                                <button class="btn btn-sm" onclick="removeService('{{ $details['Additional_services_names'] }}',{{ $id }},-1,'{{ $details['services_price'] }}','{{ $details['service_day'] }}',1)"><i class="awe-icon awe-icon-close-o"></i></button>
                                                        </td>
                                                    </tr>
                                                            
                                                            <?php
                                                        }
                                                        
                                                        if($details['Additional_services_names_more'] !== 'null'){
                                                            $services_names = json_decode($details['Additional_services_names_more']);
                                                            $services_persons_more = json_decode($details['services_persons_more']);
                                                            $services_price_more = json_decode($details['services_price_more']);
                                                            $services_days_more = json_decode($details['services_days_more']);
                                                            
                                                            $z = 0;
                                                            foreach($services_names as $service_res){
                                                                ?>
                                                    <tr>
                                                        <td>Additonal Service</td>
                                                        <td>{{ $service_res }}</td>
                                                        <td>{{ $details['currency'] }} {{ $services_price_more[$z] }}  - Days: {{ $services_days_more[$z] }}
                                                         <input type="text" hidden id="prev_total{{ $details['tourId'] }}inc{{$z + 2}}" value="{{ $services_price_more[$z] * ($services_persons_more[$z] * $services_days_more[$z])}}">
                                                        </td>
                                                        <td>
                                                            <select name="servicemore" id="service{{ $details['tourId'] }}inc{{$z + 2}}" onchange="changeAddtionalService('{{ $service_res }}',{{ $id }},{{$z}},{{ $services_price_more[$z] }},{{ $services_days_more[$z] }},{{$z + 2}})" class="awe-select">
                                                                    <option @if($services_persons_more[$z] == 0) selected @endif>0</option>
                                                                    <option @if($services_persons_more[$z] == 1) selected @endif>1</option>
                                                                    <option @if($services_persons_more[$z] == 2) selected @endif>2</option>
                                                                    <option @if($services_persons_more[$z] == 3) selected @endif>3</option>
                                                                    <option @if($services_persons_more[$z] == 4) selected @endif>4</option>
                                                                    <option @if($services_persons_more[$z] == 5) selected @endif>5</option>
                                                                    <option @if($services_persons_more[$z] == 6) selected @endif>6</option>
                                                                    <option @if($services_persons_more[$z] == 7) selected @endif>7</option>
                                                                    <option @if($services_persons_more[$z] == 8) selected @endif>8</option>
                                                                    <option @if($services_persons_more[$z] == 9) selected @endif>9</option>
                                                                    <option @if($services_persons_more[$z] == 10) selected @endif>10</option>
                                                                </select>
                                                            </td>
                                                        <td style="text-align:right;">
                                                            {{ $details['currency'] }} {{ $services_price_more[$z] * ($services_persons_more[$z] * $services_days_more[$z])}}</td>
                                                       <td>
                                                                <button class="btn btn-sm" onclick="removeService('{{ $service_res }}',{{ $id }},{{$z}},{{ $services_price_more[$z] }},{{ $services_days_more[$z] }},{{$z + 2}})"><i class="awe-icon awe-icon-close-o"></i></button>
                                                        </td>
                                                    </tr>
                                                                <?php
                                                                $z++;
                                                            }
                                                            
                                                        }
                                                    ?>
                                                  
                                                    @php $total += $details['price'];
                                                    $currency = $details['currency'];
                                                        if($details["adults"] == 0){
                                                            $adults_count++;
                                                        }
                                                    @endphp
                                                    @endforeach
                                            
                                                <?php 
                                                }else{
                                                   $cart_data = $main_cart[0];
                                                  
                                            
                                                    ?>
                                                      @foreach($cart_data as $id => $details)
                                                            <tr data-id="{{ $id }}">
                                                                <td style="padding:5px;">
                                                                    <img style="height:50px;  width:100%; overflow:hidden;" src="{{ config('img_url') }}/public/images/activites//{{ $details['image'] }}" alt="" class="flex-shrink-0">    
                                                                </td>
                                                                <td>
                                                                    <span><a style="font-size:13px" title="View Detail" href="#" onclick="fetch_tour_details({{ $details['generate_id'] }},'{{ $details['pakage_type'] }}')" data-bs-toggle="modal" data-bs-target="#exampleModal">{{ $details['name'] }}</a></span>
                                                                    <br>
                                                                    <a  href="#" data-bs-toggle="modal" data-bs-target="#exampleModal{{ $details['generate_id'] }}">
                                                                       Cancellation Policy ?
                                                                    </a>
                                                                    <br>
                                                                    <span>Activity Date:{{ $details['activity_select_date'] }}</span>
                                                                </td>
                                                                <td class="product-price">
                                                                    <div class="row">

                                                                        <div class="col-md-6">
                                                                            <label>Adult Price: {{ $details['currency']." ".$details['adult_price'] }}</label>
                                                                            <input type="text" id="adultsPrice{{ $id }}" hidden value="{{ $details['adult_price'] }}">
                                                                        </div>
                                                                        <div class="col-md-8">
                                                                            <label>Child Price: {{ $details['currency']." ".$details['child_price'] }}</label>
                                                                            <input type="text" id="childsPrice{{ $id }}" hidden value="{{ $details['child_price'] }}">
                                                                        </div>
                                                                    </div>
                                                                    
                                                                    
                                                                   
                                                                </td>
                                                                <td>
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-elements form-adult">
                                                                                <div class="form-item">
                                                                                    <select id="adults{{ $id }}" onchange="changeActivityData({{ $id }})" name="adults" class="awe-select">
                                                                                        <option @if($details["adults"] == 0) selected @endif>0</option>
                                                                                        <option @if($details["adults"] == 1) selected @endif>1</option>
                                                                                        <option @if($details["adults"] == 2) selected @endif>2</option>
                                                                                        <option @if($details["adults"] == 3) selected @endif>3</option>
                                                                                        <option @if($details["adults"] == 4) selected @endif>4</option>
                                                                                        <option @if($details["adults"] == 5) selected @endif>5</option>
                                                                                        <option @if($details["adults"] == 6) selected @endif>6</option>
                                                                                        <option @if($details["adults"] == 7) selected @endif>7</option>
                                                                                        <option @if($details["adults"] == 8) selected @endif>8</option>
                                                                                        <option @if($details["adults"] == 9) selected @endif>9</option>
                                                                                        <option @if($details["adults"] == 10) selected @endif>10</option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-elements form-adult">
                                                                                <div class="form-item">
                                                                                    <select name="children" id="child{{ $id }}" onchange="changeActivityData({{ $id }})" class="awe-select">
                                                                                        <option @if($details["children"] == 0) selected @endif>0</option>
                                                                                        <option @if($details["children"] == 1) selected @endif>1</option>
                                                                                        <option @if($details["children"] == 2) selected @endif>2</option>
                                                                                        <option @if($details["children"] == 3) selected @endif>3</option>
                                                                                        <option @if($details["children"] == 4) selected @endif>4</option>
                                                                                        <option @if($details["children"] == 5) selected @endif>5</option>
                                                                                        <option @if($details["children"] == 6) selected @endif>6</option>
                                                                                        <option @if($details["children"] == 7) selected @endif>7</option>
                                                                                        <option @if($details["children"] == 8) selected @endif>8</option>
                                                                                        <option @if($details["children"] == 9) selected @endif>9</option>
                                                                                        <option @if($details["children"] == 10) selected @endif>10</option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    
                                                                </td>
                                                                <td class="product-subtotal">
                                                                    <span class="amount">{{ $details['currency'] }} {{ $details['activity_total_price'] }}</span>
                                                                </td>
                                                                <td>
                                                                    <button class="btn btn-sm" onclick="removeItem({{ $id }})"><i class="awe-icon awe-icon-close-o"></i></button>
                                                                </td>
                                                                 <td>
                                                                    <button class="btn btn-sm" title="View Detail" onclick="fetch_tour_details({{ $details['activtyId'] }},'{{ $details['pakage_type'] }}')" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa fa-eye" aria-hidden="true"></i></button>
                                                                </td>
                                                            </tr>
                                                       
                                                                    
                                                                    <?php
                                                                
                                                                
                                                                if($details['Additional_services_names_more'] !== 'null'){
                                                                    $services_names = json_decode($details['Additional_services_names_more']);
                                                                    $services_persons_more = json_decode($details['services_persons_more']);
                                                                    $services_price_more = json_decode($details['services_price_more']);
                                                                    $services_days_more = json_decode($details['services_days_more']);
                                                                    
                                                                    $z = 0;
                                                                    foreach($services_names as $service_res){
                                                                        ?>
                                                            <tr>
                                                                <td>Additonal Service</td>
                                                                <td>{{ $service_res }}</td>
                                                                <td>{{ $details['currency'] }} {{ $services_price_more[$z] }} - Days: {{ $services_days_more[$z] }}
                                                                 <input type="text" hidden id="prev_total{{ $details['activtyId'] }}inc{{$z + 2}}" value="{{ $services_price_more[$z] * ($services_persons_more[$z] * $services_days_more[$z])}}">
                                                                </td>
                                                                <td>
                                                                    <select name="servicemore" id="service{{ $details['activtyId'] }}inc{{$z + 2}}" onchange="changeAddtionalService('{{ $service_res }}',{{ $id }},{{$z}},{{ $services_price_more[$z] }},{{ $services_days_more[$z] }},{{$z + 2}})" class="awe-select">
                                                                            <option @if($services_persons_more[$z] == 0) selected @endif>0</option>
                                                                            <option @if($services_persons_more[$z] == 1) selected @endif>1</option>
                                                                            <option @if($services_persons_more[$z] == 2) selected @endif>2</option>
                                                                            <option @if($services_persons_more[$z] == 3) selected @endif>3</option>
                                                                            <option @if($services_persons_more[$z] == 4) selected @endif>4</option>
                                                                            <option @if($services_persons_more[$z] == 5) selected @endif>5</option>
                                                                            <option @if($services_persons_more[$z] == 6) selected @endif>6</option>
                                                                            <option @if($services_persons_more[$z] == 7) selected @endif>7</option>
                                                                            <option @if($services_persons_more[$z] == 8) selected @endif>8</option>
                                                                            <option @if($services_persons_more[$z] == 9) selected @endif>9</option>
                                                                            <option @if($services_persons_more[$z] == 10) selected @endif>10</option>
                                                                        </select>
                                                                    </td>
                                                                <td style="text-align:right;">
                                                                    {{ $details['currency'] }} {{ $services_price_more[$z] * ($services_persons_more[$z] * $services_days_more[$z])}}</td>
                                                               <td>
                                                                        <button class="btn btn-sm" onclick="removeService('{{ $service_res }}',{{ $id }},{{$z}},{{ $services_price_more[$z] }},{{ $services_days_more[$z] }},{{$z + 2}})"><i class="awe-icon awe-icon-close-o"></i></button>
                                                                </td>
                                                            </tr>
                                                                        <?php
                                                                        $z++;
                                                                    }
                                                                    
                                                                }
                                                            ?>
                                                          
                                                            @php $total += $details['price'];
                                                            $currency = $details['currency'];
                                                                if($details["adults"] == 0){
                                                                    $adults_count++;
                                                                }
                                                            @endphp
                                                            @endforeach
                                                    <?php
                                                }
                                                ?>
                                             @endif
                                        </tbody>
                                    </table>
                                 
                                    <div class="cart-footer">
                                        
                                        <div class="order-total">
                                            <h4 class="title">Order Total</h4>
                                            <span class="amount">{{$currency ?? "" }}</span> <span id="total_Amount1">{{ $total }}</span>
                                        </div>
                                        <div class="cart-submit">
                                            @if($adults_count == 0)
                                            <a href="{{ route('checkout1') }}" class="btn" style="background-color:#d2b254; color:white;">Proceed to Checkout</a>
                                            @else
                                                <span>Please Select At least one adult from each Tour to proccced checkout</span>
                                            @endif
                                            
                                            <!--<input type="submit" value="Continue Checkout" class="checkout">-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tour Detail</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="Tour_data">
        
      </div>
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div>

@if(session('cart'))
    <?php 
    $cart_data_main = session('cart');
    $cart_data = $cart_data_main[0];
    
    if($cart_data_main[1] == 'tour'){
        $model_id = 'tourId';
    }else{
        $model_id = 'generate_id';
    }
    ?>
    @foreach($cart_data as $id => $details)
     <div class="modal fade" id="exampleModal{{ $details[$model_id] }}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Cancellation Policy</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

          </div>
      
          <div class="modal-body">
            
               <p>{{ $details['cancellation_policy'] }}</p>
            
          </div>
          <div class="modal-footer">
            
          </div>
      
        </div>
      </div>
    </div>
    @endforeach
@endif
<!-- ================================
    END CART AREA
================================= -->

<!-- ===============================
       START FOOTER AREA
================================= -->
 
@endsection

@section('scripts')
    <script>
    
    function discount_Price1(id){
        var sharing = $('#sharing'+id+'').val();
        var adults = $('#adults'+id+'').val();
        var child = $('#child'+id+'').val();
        var cost_price_final = $('#cost_price_final'+id+'').html();
        var discount_Price   = $('#discount_Price'+id+'').val();
        var total_Amount1    = $('#total_Amount1').html()
        
        if(parseFloat(discount_Price) > parseFloat(cost_price_final)){
            alert("please enter amount less then markup");
            $('#discount_Price'+id+'').val(0);
            $('#total_Price'+id+'').html(total_Amount1);
        }
        else if(parseFloat(discount_Price) < parseFloat(cost_price_final)){
            var total_Price = parseFloat(total_Amount1) - parseFloat(discount_Price);
            $('#total_Price'+id+'').val(total_Price);
            
            ids = $('#tours_id'+id+'').val();
            $.ajax({
                    url: '{{ route('update.cart2') }}',
                    method: "patch",
                    data: {
                        _token              : '{{ csrf_token() }}', 
                        id                  : id, 
                        discount_Price      : discount_Price,
                        tour_total_price    : total_Price,
                        adults              : adults,
                        childs              : child,
                        sharing             : sharing,
                    },
                    success: function (response) {
                        console.log(response);
                        window.location.reload();
                    }
            });
        }
        else{
            $('#discount_Price'+id+'').val(discount_Price)
        }
    }
    
    function changeAddtionalService(serviceName,id,index,singlePrice,noOfDays,inc){
        
            var persons = $('#service'+id+'inc'+inc+'').val();
            var prev_total = $('#prev_total'+id+'inc'+inc+'').val();
            console.log('enter in else persons '+persons+' prev '+prev_total);
       
        
        console.log('Previous total is '+prev_total+' person '+persons);
        // var adults = $('#adults'+id+'').val();
        // var child = $('#child'+id+'').val();
        
         $.ajax({
                url: '{{ route('update.cart.service') }}',
                method: "POST",
                data: {
                    _token: '{{ csrf_token() }}', 
                    id: id, 
                    index: index,
                    serviceName: serviceName,
                    singlePrice:singlePrice,
                    noOfDays:noOfDays,
                    persons:persons,
                    prev_total :prev_total
                },
                success: function (response) {
                    console.log(response);
                    window.location.reload();
                }
        });
        
            console.log('serviceName is '+serviceName+' id is '+id+' index '+index+' Person '+persons+' singlePrice '+singlePrice+' noOfDays'+noOfDays);
    }
    
    function changeSharing(id){
        var sharing = $('#sharing'+id+'').val();
        var adults = $('#adults'+id+'').val();
        var child = $('#child'+id+'').val();
        
        $.ajax({
                url: '{{ route('update.cart') }}',
                method: "patch",
                data: {
                    _token: '{{ csrf_token() }}', 
                    id: id, 
                    adults: adults,
                    childs: child,
                    sharing:sharing
                },
                success: function (response) {
                    console.log(response);
                    window.location.reload();
                }
        });
        
            console.log('Parent Id is '+id+' shar is '+sharing+' ad '+adults+' ch '+child);
    }
    
    function changeActivityData(id){
        var adultsPrice = $('#adultsPrice'+id+'').val();
        var childsPrice = $('#childsPrice'+id+'').val();
        var adults = $('#adults'+id+'').val();
        var child = $('#child'+id+'').val();
        
         $.ajax({
                url: '{{ route('update.cart.activity') }}',
                method: "post",
                data: {
                    _token: '{{ csrf_token() }}', 
                    id: id, 
                    adults: adults,
                    childs: child,
                    adultsPrice:adultsPrice,
                    childsPrice:childsPrice
                },
                success: function (response) {
                    console.log(response);
                    window.location.reload();
                }
        });
        
    }
    
    function removeItem(id){
                  if(confirm("Are you sure want to remove?")) {
                    $.ajax({
                        url: '{{ route('remove.from.cart') }}',
                        method: "DELETE",
                        data: {
                            _token: '{{ csrf_token() }}', 
                            id: id
                        },
                        success: function (response) {
                            window.location.reload();
                        }
                    });
                }
            }
            
    function removeService(serviceName,id,index,singlePrice,noOfDays,inc){
                 var persons = $('#service'+id+'inc'+inc+'').val();
                 
                 var prev_total = $('#prev_total'+id+'inc'+inc+'').val();
                //   if(confirm("Are you sure want to remove?")) {
                    $.ajax({
                        url: '{{ route('remove_service') }}',
                        method: "post",
                        data: {
                            _token: '{{ csrf_token() }}', 
                            id: id, 
                            index: index,
                            serviceName: serviceName,
                            singlePrice:singlePrice,
                            noOfDays:noOfDays,
                            persons:persons,
                            prev_total :prev_total
                        },
                        success: function (response) {
                            console.log(response);
                            // window.location.reload();
                        }
                    });
                // }
                
                console.log('serviceName is '+serviceName+' id is '+id+' index '+index+' Person '+persons+' singlePrice '+singlePrice+' noOfDays'+noOfDays);
            }
            
    function formatDate(date) {
              return [
                padTo2Digits(date.getDate()),
                padTo2Digits(date.getMonth() + 1),
                date.getFullYear(),
              ].join('/');
            }
            
    function padTo2Digits(num) {
              return num.toString().padStart(2, '0');
            }
    
    function fetch_tour_details(id,type){
                
                console.log('you click on link '+id+type);
                         $.ajax({
                                url: 'fetch_tour_data',
                                method: "post",
                                data: {
                                    _token: '{{ csrf_token() }}', 
                                    id: id, 
                                    type: type,
                                },
                                success: function (response) {
                                    // console.log(response);
                                    var data = JSON.parse(response);
                                    console.log(data);
                                    
                                    if(type == 'tour'){
                                        if(data['tour_data']['tour_location'] !== null){
                                         var tour_location = JSON.parse(data['tour_data']['tour_location']);
                                    
                                        var tours_locations = '';
                                        for(var i=0; i<tour_location.length; i++){
                                            tours_locations += tour_location[i]+",";
                                        }
                                        console.log(tours_locations);
                                        }else{
                                            var tours_locations = '';
                                        }
                                       
                                        var startDate = formatDate(new Date(data['tour_data']['start_date']));
                                        var endDate = formatDate(new Date(data['tour_data']['end_date']));
                                        
                                        console.log(data['accomodation']);
                                        
                                         
                                         
                                          if(data['accomodation'] !== null){
                                         var hotels = '';
                                            for(var i=0; i<data['accomodation'].length; i++){
                                                var acc_check_in = formatDate(new Date(data['accomodation'][i]['acc_check_in']));
                                                var acc_check_out = formatDate(new Date(data['accomodation'][i]['acc_check_out']));
                                                 hotels +=`<table class="room-type-table tours-hotels-table">
                                                            <thead>
                                                                <tr>
                                                                    <th class="room-type">${data['accomodation'][i]['hotel_city_name']} Hotel Details</th>
                                                                    <th class="room-people">Available Rooms </th>
                                                                    <th class="room-condition">Amenities</th>
                                                                  
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td class="room-type">
                                                                        <div class="room-thumb">
                                                                            <img src="{{ config('img_url') }}/public/uploads/package_imgs/${data['accomodation'][i]['accomodation_image']}" alt="">
                                                                        </div>
                                                                        <div class="room-title">
                                                                            <h4>${data['accomodation'][i]['acc_hotel_name']}</h4>
                                                                        </div>
                                                                        
                                                                            <ul class="list-unstyled">
                                                                                <li><i class="fa fa-calendar" aria-hidden="true"></i> Check In  : ${acc_check_in}</li>
                                                                                <li><i class="fa fa-calendar" aria-hidden="true"></i> Check Out : ${acc_check_out}</li>
                                                                                <li><i class="fa fa-moon-o" aria-hidden="true"></i> No Of Nights : ${data['accomodation'][i]['acc_no_of_nightst']}</li>
                                                                            </ul>
                                                                        
                                                                       
                                                                       
                                                                    </td>
                                                                    <td class="room-people">`
                                                                        if(data['accomodation_more'] !== null){
                                                                           for(var k=0; k<data['accomodation_more'].length; k++){
                                                                                if(data['accomodation'][i]['hotel_city_name'] == data['accomodation_more'][k]['more_hotel_city']){
                                                                                    hotels +=`<p>${data['accomodation_more'][k]['more_hotel_city']}</p>`
                                                                                }
                                                                           }
                                                                        }
                                                                    hotels +=`</td>
                                                                    <td class="room-condition">
                                                                        ${data['accomodation'][i]['hotel_whats_included']}
                                                                       
                                                                        
                                                                    </td>
                                                                   
                                                                </tr>
                                                              
                                                             
                                                            </tbody>
                                                        </table>`
                                                      
                                            
                                            }
                                          }else{
                                             var hotels = '';
                                          }
                                          
                                          
                                         
                                          
                                        if(data['flight_det']['arrival_airport_code'] !== null || data['flight_det_more'] !==null){
                                            if (data['flight_det']['other_Airline_Name2'] !== undefined) {
                                                 var airlineName =  data['flight_det']['other_Airline_Name2']
                                            }else{
                                                var airlineName = '';
                                            }
                                            
                                             if (data['flight_det']['departure_Flight_Type'] !== undefined) {
                                                 var departure_Flight_Type =  data['flight_det']['other_Airline_Name2']
                                            }else{
                                                var departure_Flight_Type = '';
                                            }
                                          
                                         
                                         var flight = `<div class="col-md-1 mt-2 mb-2">
                                                                    <i class="fa fa-plane" aria-hidden="true" style="font-size:2rem;"></i>
                                                    </div>
                                                    <div class="col-md-11 mt-2 mb-2"><h5>Flight Details</h5></div>
                                                    
                                                    <div class="col-md-12">
                                                                    <div class="initiative">
                                            <!-- ITEM -->
                                            <div class="initiative__item">
                                                <div class="initiative-top">
                                                    <div class="title">
                                                        <div class="from-to">
                                                            <span class="from">${data['first_depaurture']}</span>
                                                            <i class="awe-icon awe-icon-arrow-right"></i>
                                                            <span class="to">${data['last_destination']}</span>
                                                        </div>
                                                        <div class="time">${data['first_dep_time']} | ${data['last_arrival']}</div>
                                                    </div>
                                                   
                                                </div>
                                                <table class="initiative-table">
                                                    <tbody>`
                                                    if(data['flight_det']['flight_type'] !== 'Indirect'){
                                                        flight += `<tr>
                                                            <th>
                                                                <div class="item-thumb">
                                                                    <div class="image-thumb">
                                                                        <img src="{{ config('img_url') }}/public/uploads/package_imgs/${data['flight_det']['flights_image']}" alt="">
                                                                    </div>
                                                                    <div class="text">
                                                                        <span>${airlineName}</span>
                                                                        <p>${data['flight_det']['departure_flight_number']}</p>
                                                                        <span>${departure_Flight_Type}</span>
                                                                    </div>
                                                                </div>
                                                            </th>
                                                            <td>
                                                                <div class="item-body" style="padding:0px;">
                                                                    <div class="item-from">
                                                                        <h3> <img src="https://client1.synchronousdigital.com/public/images/departure.png" alt="" width="25px">
                                                                        ${data['flight_det']['departure_airport_code']}</h3>
                                                                        <span class="time">${data['flight_times_arr'][0]}</span>
                                                                        <span class="date">${data['flight_date_arr'][0]} </span>
                                                                      
                                                                    </div>
                                                                    <div class="item-time">
                                                                        <i class="fa fa-clock-o"></i>
                                                                        <span>10h 25m</span>
                                                                    </div>
                                                                    <div class="item-to">
                                                                        <h3><img src="https://client1.synchronousdigital.com/public/images/landing.png" alt="" width="25px">
                                                                        ${data['flight_det']['arrival_airport_code']}</h3>
                                                                        <span class="time">${data['flight_times_arrival_arr'][0]} </span>
                                                                        <span class="date">${data['flight_date_arrival_arr'][0]} </span>
                                                                      
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>`;
                                                    }
                                                        
                                                    if(data['flight_det_more'] !== null){
                                                        for(var fl = 0; fl < data['flight_det_more'].length; fl++){
                                                       flight += `<tr>
                                                            <th>
                                                                <div class="item-thumb">
                                                                    <div class="image-thumb">
                                                                        <img src="{{ config('img_url') }}/public/uploads/package_imgs/${data['flight_det']['flights_image']}" alt="">
                                                                    </div>
                                                                    <div class="text">
                                                                        <span>${data['flight_det_more'][fl]['more_other_Airline_Name2']}</span>
                                                                        <p>${data['flight_det_more'][fl]['more_departure_flight_number']}</p>
                                                                        <span>${data['flight_det_more'][fl]['more_departure_Flight_Type']}</span>
                                                                    </div>
                                                                </div>
                                                            </th>
                                                            <td>
                                                                <div class="item-body" style="padding:0px;">
                                                                    <div class="item-from">
                                                                        <h3>${data['flight_det_more'][fl]['more_departure_airport_code']}</h3>
                                                                       <span class="time">${data['flight_times_arr'][1 + fl]}</span>
                                                                        <span class="date">${data['flight_date_arr'][1 + fl]} </span>
                                                                    </div>
                                                                    <div class="item-time">
                                                                        <i class="fa fa-clock-o"></i>
                                                                        <span>${data['flight_det_more'][fl]['more_total_Time']}</span>
                                                                    </div>
                                                                    <div class="item-to">
                                                                        <h3>${data['flight_det_more'][fl]['more_arrival_airport_code']}</h3>
                                                                          <span class="time">${data['flight_times_arrival_arr'][1 + fl]} </span>
                                                                        <span class="date">${data['flight_date_arrival_arr'][1 + fl]} </span>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>`;
                                                        }
                                                        
                                                    }
                                                    
                                                    
                                                    flight += `</tbody>
                                                </table>
                                            </div>
                                            <!-- END / ITEM -->
                                            
                                             <h6>Return Details</h6>
                                             
                                             <div class="initiative__item">
                                                <div class="initiative-top">
                                                    <div class="title">
                                                        <div class="from-to">
                                                            <span class="from">${data['return_data']['ret_first_depaurture']}</span>
                                                            <i class="awe-icon awe-icon-arrow-right"></i>
                                                            <span class="to">${data['return_data']['ret_last_destination']}</span>
                                                        </div>
                                                        <div class="time">${data['return_data']['ret_first_dep_time']} | ${data['return_data']['ret_last_arrival']}</div>
                                                    </div>
                                               
                                                </div>
                                                <table class="initiative-table">
                                                    <tbody>`
                                                    if(data['flight_det']['flight_type'] !== 'Indirect'){
                                                        flight += `<tr>
                                                            <th>
                                                                <div class="item-thumb">
                                                                    <div class="image-thumb">
                                                                        <img src="{{ config('img_url') }}/public/uploads/package_imgs/${data['flight_det']['flights_image']}" alt="">
                                                                    </div>
                                                                    <div class="text">
                                                                        <span>${airlineName}</span>
                                                                        <p>${data['flight_det']['departure_flight_number']}</p>
                                                                        <span>${departure_Flight_Type}</span>
                                                                    </div>
                                                                </div>
                                                            </th>
                                                            <td>
                                                                <div class="item-body" style="padding:0px;">
                                                                    <div class="item-from">
                                                                        <h3>${data['flight_det']['return_departure_airport_code']}</h3>
                                                                        <span class="time">${data['ret_flight_times_arr'][0]}</span>
                                                                        <span class="date">${data['ret_flight_date_arr'][0]} </span>
                                                                      
                                                                    </div>
                                                                    <div class="item-time">
                                                                        <i class="fa fa-clock-o"></i>
                                                                        <span>${data['flight_det']['return_total_Time']}</span>
                                                                    </div>
                                                                    <div class="item-to">
                                                                        <h3>${data['flight_det']['return_arrival_airport_code']}</h3>
                                                                        <span class="time">${data['ret_flight_times_arrival_arr'][0]} </span>
                                                                        <span class="date">${data['ret_flight_date_arrival_arr'][0]} </span>
                                                                      
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>`;
                                                    }
                                                        
                                                    if(data['flight_det_more'] !== null){
                                                        for(var fl = 0; fl < data['flight_det_more'].length; fl++){
                                                       flight += `<tr>
                                                            <th>
                                                                <div class="item-thumb">
                                                                    <div class="image-thumb">
                                                                        <img src="{{ config('img_url') }}/public/uploads/package_imgs/${data['flight_det']['flights_image']}" alt="">
                                                                    </div>
                                                                    <div class="text">
                                                                        <span>${data['flight_det_more'][fl]['more_other_Airline_Name2']}</span>
                                                                        <p>${data['flight_det_more'][fl]['more_departure_flight_number']}</p>
                                                                        <span>${data['flight_det_more'][fl]['more_departure_Flight_Type']}</span>
                                                                    </div>
                                                                </div>
                                                            </th>
                                                            <td>
                                                                <div class="item-body" style="padding:0px;">
                                                                    <div class="item-from">
                                                                        <h3>${data['flight_det_more'][fl]['return_more_departure_airport_code']}</h3>
                                                                       <span class="time">${data['ret_flight_times_arr'][1 + fl]}</span>
                                                                        <span class="date">${data['ret_flight_date_arr'][1 + fl]} </span>
                                                                    </div>
                                                                    <div class="item-time">
                                                                        <i class="fa fa-clock-o"></i>
                                                                        <span>${data['flight_det_more'][fl]['return_more_total_Time']}</span>
                                                                    </div>
                                                                    <div class="item-to">
                                                                        <h3>${data['flight_det_more'][fl]['return_more_arrival_airport_code']}</h3>
                                                                          <span class="time">${data['ret_flight_times_arrival_arr'][1 + fl]} </span>
                                                                        <span class="date">${data['ret_flight_date_arrival_arr'][1 + fl]} </span>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>`;
                                                        }
                                                    }
                                                    flight += `</tbody>
                                                </table>
                                            </div>
                                       
                                        </div>
                                                    </div>`;
                                   
                                          
                                                            }else{
                                                                var flight = '';
                                                            }
                                                            
                                          if(data['transportaion']['transportation_drop_off_location'] !== null){
                                              if(data['transportaion']['transportation_trip_type'] !== 'All_Round')
                                              { var transportation_type = data['transportaion']['transportation_trip_type'] } 
                                              else { var transportation_type = 'All Round '}
                                             
                    var date = new Date(data['transportaion']['transportation_pick_up_date']);
    
                    var transportation_pick_up_date =  date.getDate()+
                      "/"+(date.getMonth()+1)+
                      "/"+date.getFullYear();
                                         var transportaion = `<div class="col-md-1 mt-2 mb-2">
                                                                    <i class="fa fa-car" aria-hidden="true" style="font-size:2rem;"></i>
                                                    </div>
                                                    <div class="col-md-11 mt-2 mb-2"><h5>Transportation Details</h5></div>
                                                    
                                                    <div class="col-md-12">
                                                                      <table class="initiative-table">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th>
                                                                                    <div class="item-thumb">
                                                                                        <div class="image-thumb">
                                                                                            <img src="{{ config('img_url') }}/public/uploads/package_imgs/${ data['transportaion']['transportation_image'] }" alt="">
                                                                                        </div>
                                                                                        <div class="text">
                                                                                            <span>Vehicle: ${ data['transportaion']['transportation_vehicle_type'] }</span>
                                                                                            <span style="display:block">Type: ${transportation_type}</span>
                                                                                        </div>
                                                                                    </div>
                                                                                </th>
                                                                                <td>
                                                                                    <div class="item-body" style="padding:0px;">
                                                                                        <div class="item-from">
                                                                                         <h5 style="font-size:1.1rem;">Pickup Location</h5>
                                                                                            <h6 style="font-size:1rem;">${ data['transportaion']['transportation_pick_up_location'] }</h6>
                                                                                            <span class="date">${ data['tran_date_time']['tran_pick_date'] }</span>
                                                                                            <span class="date">${ data['tran_date_time']['tran_pick_time'] }</span>
                                                                                           
                                                                                        </div>
                                                                                        <div class="item-time">
                                                                                            <i class="fa fa-clock-o"></i>
                                                                                            <span>${data['transportaion']['transportation_total_Time']}</span>
                                                                                        </div>
                                                                                        <div class="item-to">
                                                                                                <h5 style="font-size:1.1rem;">Drop Off Location</h5>
                                                                                            <h6 style="font-size:1rem;">${ data['transportaion']['transportation_drop_off_location'] }</h6>
                                                                                            <span class="date">${ data['tran_date_time']['tran_drop_date'] }</span>
                                                                                            <span class="date">${ data['tran_date_time']['tran_drop_time'] }</span>
                                                                                        </div>
                                                                                    </div>
                                                                                </td>
                                                                                
                                                                            </tr>`;
                                                                            
                                                        if(data['transportaion']['transportation_trip_type'] == 'Return'){
                                                        var date = new Date(data['transportaion']['return_transportation_pick_up_date']);
    
                                                        var return_transportation_pick_up_date =  date.getDate()+
                                                          "/"+(date.getMonth()+1)+
                                                          "/"+date.getFullYear();
                                                         transportaion +=  `<tr>
                                                            <th>
                                                                <div class="item-thumb">
                                                                    <div class="image-thumb">
                                                                    </div>
                                                                    <div class="text">
                                                                      
                                                                    </div>
                                                                </div>
                                                            </th>
                                                             <td>
                                                                <div class="item-body" style="padding:0px;">
                                                                    <div class="item-from">
                                                                        <h3>${  data['transportaion']['return_transportation_pick_up_location'] }</h3>
                                                                       
                                                                        <span class="date">${return_transportation_pick_up_date}</span>
                                                                       
                                                                    </div>
                                                                    <div class="item-time">
                                                                        <i class="fa fa-clock-o"></i>
                                                                        <span>Retrun</span>
                                                                    </div>
                                                                    <div class="item-to">
                                                                        <h3>${ data['transportaion']['return_transportation_drop_off_location'] }</h3>
                                                                       
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>`;
                                                        
                                                        
                                                    } 
                                                    
                                                        if(data['transporation_more'] !== null){
                                                            for(var trans = 0; trans < data['transporation_more'].length; trans++){
                                                        var date = new Date(data['transporation_more'][trans]['more_transportation_pick_up_date']);
    
                                                        var return_transportation_pick_up_date =  date.getDate()+
                                                          "/"+(date.getMonth()+1)+
                                                          "/"+date.getFullYear();
                                                         transportaion +=  `<tr>
                                                            <th>
                                                                <div class="item-thumb">
                                                                    <div class="image-thumb">
                                                                    </div>
                                                                    <div class="text">
                                                                      
                                                                    </div>
                                                                </div>
                                                            </th>
                                                             <td>
                                                                <div class="item-body" style="padding:0px;">
                                                                    <div class="item-from">
                                                                        <h3>${  data['transporation_more'][trans]['more_transportation_drop_off_location'] }</h3>
                                                                       
                                                                        <span class="date">${return_transportation_pick_up_date}</span>
                                                                       
                                                                    </div>
                                                                    <div class="item-time">
                                                                        <i class="fa fa-clock-o"></i>
                                                                        <span>Others</span>
                                                                    </div>
                                                                    <div class="item-to">
                                                                        <h3>${ data['transporation_more'][trans]['more_transportation_pick_up_location'] }</h3>
                                                                       
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>`;
                                                        
                                                            }
                                                    } 
                                                                        
                                                                    
                                                                            
                                            
                                                                               
                                                                        
                                                                     transportaion += `</tbody>
                                                                    </table>
                                                    </div>`;
                                                    
                                   
                              
                                                }else{
                                                    var transportaion = '';
                                                }
                                                            
                                                            
                                          
                                          
                                                if(data['tour_data']['Itinerary_details'][0]['Itinerary_title'] !== null){
                                                    console.log('iterniser '+data['tour_data']['Itinerary_details'])
                                                    var iternaryDetails = JSON.parse(data['tour_data']['Itinerary_details']);
                                                    if(iternaryDetails[0]['Itinerary_title'] !== null){
                                                    console.log(iternaryDetails)
                                                     var iternary = '';
                                                        for(var i=0; i<iternaryDetails.length; i++){
                                                            
                                                             iternary +=`<li>
                                                                            <h4>${iternaryDetails[i]['Itinerary_title']} : ${iternaryDetails[i]['Itinerary_city']} </h4>
                                                                            <p>${iternaryDetails[i]['Itinerary_content']}</p>
                                                                        </li>`
                                                        }
                                                    }else{
                                                        var iternary = '';
                                                    }
                                              }else{
                                                 var iternary = '';
                                              }
                                          
                                          if(data['iternery'] !== null){
                                         var iternary1 = '';
                                            for(var i=0; i<data['iternery'].length; i++){
                                                
                                                 iternary1 +=`<li>
                                                                <h4>${data['iternery'][i]['more_Itinerary_title']} : ${data['iternery'][i]['more_Itinerary_city']} </h4>
                                                                <p>${data['iternery'][i]['more_Itinerary_content']}</p>
                                                            </li>`
                                            }
                                          }else{
                                             var iternary1 = '';
                                          }
                                     
                                            if(data['tour_data']['quad_grand_total_amount'] != 0 || data['tour_data']['quad_grand_total_amount'] != 'null'){
                                                var quadPrice  = "Quad: "+data['tour_data']['currency_symbol']+" "+data['tour_data']['quad_grand_total_amount'];
                                            }else{
                                                var quadPrice = '';
                                            }
                                            
                                             if(data['tour_data']['triple_grand_total_amount'] != 0 || data['tour_data']['triple_grand_total_amount'] != 'null'){
                                                var triplePrice  = "Triple: "+data['tour_data']['currency_symbol']+" "+data['tour_data']['triple_grand_total_amount'];
                                            }else{
                                                var triplePrice = '';
                                            }
                                            
                                            if(data['tour_data']['double_grand_total_amount'] != 0 || data['tour_data']['double_grand_total_amount'] != 'null'){
                                                var doublePrice  = "Double: "+data['tour_data']['currency_symbol']+" "+data['tour_data']['double_grand_total_amount'];
                                            }else{
                                                var doublePrice = '';
                                            } 
                                            
                                            
    
                                        $('#exampleModalLabel').html(data['tour_data']['title']);
                                        var tourHtml = `<div class="row" style="padding:1rem;">
                                                            <div class="col-md-1">
                                                                    <img style="width:50px" src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                                                            </div>
                                                            <div class="col-md-11"><h5>Tour Information</h5></div>
                                                            <div class="col-md-12">
                                                                <div class="row">
                                                                    <div class="col-md-4">
                                                                     <img src="{{ config('img_url') }}/public/uploads/package_imgs/${data['tour_data']['tour_banner_image']}" alt="">
                                                                    </div>
                                                                    <div class="col-md-8">
                                                                        <div class="row">
                                                                             <div class="col-md-3">
                                                                                <p style="margin-bottom:0">Tour Name:</p>
                                                                                <p style="margin-bottom:0">Tour Price:</p>
                                                                                <p style="margin-bottom:0">Check-In:</p>
                                                                                <p style="margin-bottom:0">Check-Out:</p>
                                                                                <p style="margin-bottom:0">Duration:</p>
                                                                                <p style="margin-bottom:0">Destinations:</p>
                                                                            </div>
                                                                            <div class="col-md-9">
                                                                                <p style="margin-bottom:0">${data['tour_data']['title']}</p>
                                                                                <p style="margin-bottom:0">${quadPrice} / ${triplePrice} / ${doublePrice}</p>
                                                                                <p style="margin-bottom:0">${startDate}</p>
                                                                                <p style="margin-bottom:0">${endDate}</p>
                                                                                <p style="margin-bottom:0">${data['tour_data']['time_duration']} Nights</p>
                                                                                <p style="margin-bottom:0">${tours_locations}</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                           
                                                            
                                                            <div class="col-md-1 mt-2 mb-2">
                                                                    <i class="fa fa-building" aria-hidden="true" style="font-size:2rem;"></i>
                                                            </div>
                                                            <div class="col-md-11 mt-2 mb-2"><h5>Hotel Information</h5></div>
                                                              
                                                             <div class="col-md-12">
                                                                <div class="row">
                                                                    ${hotels}
                                                                </div>
                                                             </div>
                                                        <!--   <div class="col-md-1 mt-2 mb-2">
                                                                    <img style="width:50px" src="{{asset('public/admin_package/frontend/images/tick.png') }}">
                                                            </div>
                                                            <div class="col-md-11 mt-2 mb-2"><h5>Day By Day itenery</h5></div>
                                                            
                                                             <div class="col-sm-12">
                                                                  <ul class="itenery-ul">
                                                                      ${iternary}
                                                                      ${iternary1}
                                                                    </ul>
                                                             </div> !-->
                                                          
                                                            
                                                           ${flight}
                                                            
                                                           ${transportaion}
                                                             
                                                            
                                                        </div>`
                                                        $('#Tour_data').html(tourHtml)
                                    }else{
                                         $('#exampleModalLabel').html(data['tour_data']['title']);
                                         
                                         var adultPrice = data['tour_data']['sale_price']
                                         if(data['tour_data']['child_sale_price'] != 0 && data['tour_data']['child_sale_price'] != null){
                                             var childprice = data['tour_data']['child_sale_price'] 
                                         }else{
                                              var childprice = data['tour_data']['sale_price'] 
                                         }
                                         
                                        if(data['tour_data']['what_expect'][0]['title'] !== null){
                                                console.log('iterniser '+data['tour_data']['what_expect'])
                                                var whatExpectDetails = JSON.parse(data['tour_data']['what_expect']);
                                                if(whatExpectDetails[0]['title'] !== null){
                                                console.log(whatExpectDetails)
                                                 var whatExpects = '';
                                                    for(var i=0; i<whatExpectDetails.length; i++){
                                                        
                                                         whatExpects +=`<li>
                                                                        <h4>${whatExpectDetails[i]['title']} </h4>
                                                                        <p>${whatExpectDetails[i]['expect_content']}</p>
                                                                    </li>`
                                                    }
                                                }else{
                                                    var whatExpects = '';
                                                }
                                          }else{
                                             var whatExpects = '';
                                          }
                                          
                                        
                                          
                                         
                                              
                                        var tourHtml = `<div class="row" style="padding:1rem;">
                                                            <div class="col-md-1">
                                                                    <img style="width:50px" src="{{asset('public/admin_package/frontend/images/tour-info.jpg') }}">
                                                            </div>
                                                            <div class="col-md-11"><h5>Activity Information</h5></div>
                                                            <div class="col-md-12">
                                                                <div class="row">
                                                                    <div class="col-md-4">
                                                                     <img src="{{ config('img_url') }}/public/images/activites/${data['tour_data']['featured_image']}" alt="">
                                                                    </div>
                                                                    <div class="col-md-8">
                                                                        <div class="row">
                                                                             <div class="col-md-3">
                                                                                <p style="margin-bottom:0">Activtiy Name:</p>
                                                                                <p style="margin-bottom:0">Adult Price:</p>
                                                                                <p style="margin-bottom:0">Child Price:</p>
                                                                                <p style="margin-bottom:0">Check-In:</p>
                                                                                <p style="margin-bottom:0">Duration:</p>
                                                                                <p style="margin-bottom:0">Destinations:</p>
                                                                            </div>
                                                                            <div class="col-md-9">
                                                                                <p style="margin-bottom:0">${data['tour_data']['title']}</p>
                                                                                <p style="margin-bottom:0">${adultPrice}</p>
                                                                                <p style="margin-bottom:0">${childprice}</p>
                                                                                <p style="margin-bottom:0">${data['tour_data']['activity_date']}</p>
                                                                                <p style="margin-bottom:0">${data['tour_data']['duration']} Hours</p>
                                                                                <p style="margin-bottom:0">${data['tour_data']['tours_locations']}</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                           
                                                             <hr>
                                                          <div class="col-md-1 mt-2 mb-2">
                                                                    <img style="width:50px" src="{{asset('public/admin_package/frontend/images/tick.png') }}">
                                                            </div>
                                                         <div class="col-md-11 mt-2 mb-2"><h5>Availibilty</h5></div>
                                                        
                                                         <div class="col-sm-12">
                                                            ${data['Availibilty']}
                                                         </div>
                                                            
                                                            <hr>
                                                           <div class="col-md-1 mt-2 mb-2">
                                                                    <img style="width:50px" src="{{asset('public/admin_package/frontend/images/tick.png') }}">
                                                            </div>
                                                            <div class="col-md-11 mt-2 mb-2"><h5>What To Expect</h5></div>
                                                            
                                                             <div class="col-sm-12">
                                                                  <ul class="itenery-ul">
                                                                      ${whatExpects}
                                                                  
                                                                    </ul>
                                                             </div> 
                                                             
                                                                <hr>
                                                           <div class="col-md-1 mt-2 mb-2">
                                                                    <img style="width:50px" src="{{asset('public/admin_package/frontend/images/tick.png') }}">
                                                            </div>
                                                         <div class="col-md-11 mt-2 mb-2"><h5>Meeting And Pickupt</h5></div>
                                                        
                                                         <div class="col-sm-12">
                                                              
                                                                  ${data['tour_data']['meeting_and_pickups']}
                                                              
                                                               
                                                         </div> 
                                                         
                                                         
                                                              <hr>
                                                          <div class="col-md-1 mt-2 mb-2">
                                                                    <img style="width:50px" src="{{asset('public/admin_package/frontend/images/tick.png') }}">
                                                            </div>
                                                         <div class="col-md-11 mt-2 mb-2"><h5>What's Included</h5></div>
                                                        
                                                         <div class="col-sm-12">
                                                                <h6>Whats Included?</h6>
                                                                </p>${data['tour_data']['whats_included']}</p>
                                                                
                                                                 <h6>Whats Excluded?</h6>
                                                                </p>${data['tour_data']['whats_excluded']}</p>
                                                                 
                                                              
                                                                </ul>
                                                         </div>
                                                         
                                                            
                                                         
                                                             
                                                            
                                                        </div>`
                                                        $('#Tour_data').html(tourHtml)
                                    }
                                    
                                    
                                                    
                                                    
                                    // window.location.reload();
                                }
                        });
            }
       
    </script>
@endsection

