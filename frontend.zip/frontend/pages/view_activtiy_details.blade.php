

@extends('template/frontend/includes/master')
<!-- PRELOADER -->
        <div class="preloader"></div>
        <!-- END / PRELOADER -->

@section('content')
 <!--Start CSS links for slider-->
    <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/revslider/public/assets/css/settings.css') }}">
     <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/plugins/combine/traveltour-style-custom.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/plugins/combine/style.css') }}">
       <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/include/css/page-builder.css') }}">
       
          <!--End CSS links for slider-->
<style>
     .gdlr-core-ilightbox  img{
   
   height: 240px;
   width: 100%;

}
.hotel-images-section{
        padding-top: 150px;
} 
.traveltour-item-pdlr, .gdlr-core-item-pdlr {
    padding-left: 20px;
    padding-right: 20px;
}
.gdlr-core-image-overlay {
    background-color: #000000;
    background-color: rgba(0, 0, 0, 0.6);
}
.hotel-nav {
  white-space: nowrap;
  background: #37474F;
  z-index:99;
}
.hotel-nav ul {
  list-style: none;
  margin: 0;
  padding: 0;
}
/* Only stick if you can fit */

.hotel-nav ul li a {
  display: block;
  padding: 0.5rem 1rem;
  color: white;
  text-decoration: none;
}
.hotel-nav ul li a.current {
  background: black;
}

.sticky {
  position: fixed;
  top: 0;
  width: 100%;
}

.sticky + .content {
  padding-top: 102px;
}



/*page css*/
.tc{
     color: #d2b254 !important;
}
section{
    padding-top:60px;
}
.product-title h2{
     color: #d2b254;
         font-size: 26px
}
.product-detail__info .trips .item h6{
    font-size: 18px
}
.font-26{
    font-size: 24px
}

.item-from img, .item-to img{
    margin:0 auto;
}
.ui-accordion .ui-accordion-content {
    padding: 1em 2.2em;
}
.detail-sidebar {
    margin-top: 100px;
}
.accordion .ui-accordion-header:before{
      content: "";
    position: absolute;
    border-radius: 50%;
    pointer-events: none;
    z-index: 1;
    -webkit-transition: all 1.2s cubic-bezier(.23,1,.32,1);
    -o-transition: all 1.2s cubic-bezier(.23,1,.32,1);
    transition: all 1.2s cubic-bezier(.23,1,.32,1);
    width: 16px;
    height: 16px;
    background-color: #fff;
   left: -10px;
    top: 0px;
    border: 2px solid #767676;
}
.accordion .ui-accordion-header:after{
    content: "";
    position: absolute;
    border-radius: 50%;
    pointer-events: none;
    z-index: 1;
    -webkit-transition: all 1.2s cubic-bezier(.23,1,.32,1);
    -o-transition: all 1.2s cubic-bezier(.23,1,.32,1);
    transition: all 1.2s cubic-bezier(.23,1,.32,1);
    width: 8px;
    height: 8px;
    background-color: #e60032;
    left: -6px;
    top: 4px;
    -webkit-transform: scale(0);
    -ms-transform: scale(0);
    transform: scale(0);
}
.accordion .ui-accordion-header {
   
    margin-bottom: 20px;
   
    line-height: 18px;
}
.accordion .ui-accordion-header-active:after{
     -webkit-transform: scale(1); */
    -ms-transform: scale(1);
     transform: scale(1);
    }
.accordion .ui-state-hover:before
{
    border: 2px solid #e02044;
}
.trip-schedule-accordion.accordion{
    border-left: 3px dotted #666;
}
.item-from img, .item-to img{
    margin:0 auto;
}
.ui-accordion .ui-accordion-content {
    padding: 0 2.2em;
}
.ui-accordion .ui-accordion-content h6{
        margin-bottom: 4px;
}
</style>
     <!-- BREADCRUMB -->
    
        
        
        
        
        <?php 
                                        $tour_gallery_images = json_decode($tour_details->gallery_images)
                                    ?>
        
     
        
        
     <section class="hotel-images-section ">
             
            <div class="gdlr-core-pbf-element">
                <div class="gdlr-core-gallery-item gdlr-core-item-pdb clearfix  gdlr-core-gallery-item-style-grid-no-space gdlr-core-item-pdlr ">
                    <div class="gdlr-core-gallery-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">
                       <div class="container">
                       <div class="row">
                           <div class="col-md-4" style="padding-right: 0%;">
                                @if(isset($gallery_images))

                           
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15" style="width: 100% !important;">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{ config('img_url1') }}/public/images/activites/{{  $gallery_images[0] ?? '' }}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 100% !important;"  src="{{ config('img_url1') }}/public/images/activites/{{  $gallery_images[0] ?? ''}} " alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                      
                                    @endif
                           </div>
                           <div class="col-md-8" style="padding-left: 0%;">
                                @if(isset($gallery_images))
                           <?php 
                           $count=1;
                           ?>
                           
                          
                             @foreach($gallery_images as $key => $gallery_res)
                            @if($key > 0)
                            @if($count <= 9)
                       
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{ config('img_url1') }}/public/images/activites/{{  $gallery_res }}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 160px;padding: 3px;" src="{{ config('img_url1') }}/public/images/activites/{{  $gallery_res }}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                        @endif
                        @endif
                        <?php 
                           $count++;
                           ?>
                         @endforeach
                    @endif
                           </div>
                       </div>
                          </div>
                  
                    </div>
                </div>
            </div>
        </section>    
        <!--End Slider-->



<div calss="section-column-2">
     <nav class="navbar navbar-expand-lg navbar-dark hotel-nav" id="hotel-nav" >
                <div class="container">    
                  <ul class="navbar-nav">
                 <li><a href="#section-1">Overview</a></li>
                <li><a href="#section-2">What To Expect</a></li>
                <li><a href="#section-3">Availability</a></li>
                <li><a href="#section-4">Meeting And Pickup</a></li>
                <li><a href="#section-5">What's Included</a></li>
               <li><a href="#section-6">FAQ</a></li>
               
                  </ul>
        </div>

    </nav>
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-md-9">
                  <section id="section-1">
                    <div class="row">
                    <div class="col-md-12">
                         <div class="product-title">
                                <h2>{{ $tour_details->title }}</h2>
                            </div>
                            <div class="product-address">
                                <span>   <i class="fa-solid tc fa-location-dot"></i>   
                                
                                @if(isset($tour_details->tour_location) && $tour_details->tour_location != '' && $tour_details->tour_location != null &&  $tour_details->tour_location != 'null')
                                               {{ $tour_details->location }}
                                @endif
                                    | <i class="fa-solid tc fa-phone"></i> 0121 777 2522</span>
                            </div>
                        <p class="mt-3">{{ $tour_details->activity_content }}</p>
                        
                    </div>
                    <div class="col-md-6">
                        <h6> <i class="fa-solid fa-person-circle-plus"></i> Whats Included?</h6>
                        <p>{{ $tour_details->whats_included }}</p>
                        </div>
                         <div class="col-md-6">
                        <h6><i class="fa-solid fa-person-circle-minus"></i>  Whats Excluded?</h6>
                        <p>{{ $tour_details->whats_excluded }}</p>
                        
                    
                    </div>
                </div>
                        <div class="product-detail__info">
                          
                            <div class="product-email">
                                <i class="fa fa-envelope"></i>
                                <a href="#">Send Email Inquiry</a>
                            </div>

                            <div class="trips">
                                <div class="item">
                                    <h6>  Activity Date</h6>
                                    <p><i class="fa tc fa-calendar" aria-hidden="true"></i> {{ $tour_details->activity_date }}</p>
                                   
                                </div>
                                 
                                <div class="item">
                                    <h6>Time length</h6>
                                    <p><i class="fa-regular tc fa-moon"></i> {{ $tour_details->duration }} Hours</p>
                                </div>
                                <div class="item">
                                    <h6>Category</h6>
                                    <p><i class="fa-solid tc fa-clipboard-check"></i> {{  $category_name ?? '' }}</p>
                                </div>
                                
                                <div class="item">
                                    <h6>Location</h6>
                                    <p title="Makkah, Madina"><i class="fa-solid tc fa-building-circle-check"></i> 
                                    {{ $tour_details->location }}
                                        
                                    </p>
                                </div>
                                <div class="item" style="float:none;">
                                     <a  class="font-20" href="#" data-bs-toggle="modal" data-bs-target="#exampleModal1">
                                      <i class="fa-regular fa-calendar-xmark"></i> Cancellation Policy ?
                                    </a>
                             
                               
                                </div>
                            </div>

                            <!-- <div class="rating-trip-reviews">
                                <div class="item good">
                                    <span class="count">7.5</span>
                                    <h6>Average rating</h6>
                                    <p>Good</p>
                                </div>
                                <div class="item">
                                    <h6>TripAdvisor ></h6>
                                    <img src="images/trips.png" alt="">
                                </div>
                                <div class="item">
                                    <h6>Reviews</h6>
                                    <p>No review yet</p>
                                </div>
                            </div> -->

                            <table class="ticket-price">
                                <thead>
                                    <tr>
                                       
                                        <th class="adult"><span>Adults Price</span></th>
                                      
                                         @if($tour_details->child_sale_price != 0 AND $tour_details->child_sale_price != null) 
                                        <th class="kid"><span>Child Price</span></th>
                                        @endif
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                       <tr>
                                        <td class="adult">
                                          <ins>
                                                <span class="amount">{{ $tour_details->currency_symbol." ".$tour_details->sale_price }}</span>
                                            </ins>
                                        </td>
                                        @if($tour_details->child_sale_price != 0 AND $tour_details->child_sale_price != null) 
                                        <td class="adult">
                                            <ins>
                                                <span class="amount">{{ $tour_details->currency_symbol." ".$tour_details->child_sale_price }}</span>
                                            </ins>
                                           
                                        </td>
                                        @endif
                                     
                                    
                                    </tr>
                                </tbody>
                            </table>


                        </div>
                </section>
               
              
                 <section id="section-2">
                                <h3>What To Expect</h3>
                                       <div class="trip-schedule-accordion accordion">
                                        @php 
                                            $x=1;    
                                        @endphp
                                        @if($what_expect !== '')
                                        @foreach($what_expect as $expect_res)
                                        <h3>{{ $expect_res->title }}</h3>
                                        <div>
                                           <div class="row">
                                               
                                                <div class="col-md-12">
                                              
                                                <p class="text-justify-content">{{ $expect_res->expect_content }}</p>
                                            </div>
                                            </div>
                                            
                                           
                                        </div>
                                        @php $x++ @endphp
                                        @endforeach
                                        @endif

                               
                                     
                                    </div>
                             
                </section>
                 <section id="section-3">
                      <h6>Availability</h6>
                    <div class="table-responsive form-group" data-condition="enable_open_hours:is(1)" style="">
                                   <?php
                                   $dates = $tour_details->activity_date;
                                    $ex = explode(" - ", $dates);
                                    $startDate = $ex[0];
                                    $endDate = $ex[1];


    
                                    $rangArray = [];
                                        
                                    $startDate = strtotime($startDate);
                                    $endDate = strtotime($endDate);
                                         
                                    for ($currentDate = $startDate; $currentDate <= $endDate; 
                                                                    $currentDate += (86400)) {
                                                                            
                                        $date = date('l - Y-m-d', $currentDate);
                                        $rangArray[] = $date;
                                    }
  
        
        // foreach ($rangArray as $key => $value) {
        //     // dd($value);
        //     $arr = array(
        //     $value => date('l - d/m/Y', strtotime("this week")),
        // );
        // }
        // echo "<pre>";
        // print_r($rangArray);                   
        // echo "</pre>";
        $avail=[];
        $startTime=[];
        $endTime = [];

                    foreach($rangArray as $key => $datndate){
                          $ex = explode(" - ", $datndate);
                          $exday = $ex[0];
                            foreach($Availibilty as $id => $av_res){
                        
                                if(isset($av_res->enable)){
                                                        ?>
                                                                              
                                                        <?php
                                                    $day = '';
                                                    if($id == '1'){
                                                        $day = "Monday";
                                                        if ($exday == $day) {
                                                          array_push($avail, $datndate);
                                                          array_push($startTime, $av_res->from);
                                                          array_push($endTime, $av_res->to);
                                                        }

                                                            // array_push($avail, $day);
                                                                                       
                                                                    }
                                                                                          
                                                    if($id == '2'){
                                                            $day = "Tuesday";
                                                             if ($exday == $day) {
                                                          array_push($avail, $datndate);
                                                          array_push($startTime, $av_res->from);
                                                          array_push($endTime, $av_res->to);
                                                        }
                                                            // array_push($avail, $day);
                                                         //    $avail = array(
                                                         //     $id=$day,
                                                         // );
                                                                    }
                                                                                          
                                                    if($id == '3'){
                                                            $day = "Wednesday";
                                                             if ($exday == $day) {
                                                          array_push($avail, $datndate);
                                                          array_push($startTime, $av_res->from);
                                                          array_push($endTime, $av_res->to);
                                                        }
                                                            // array_push($avail, $day);
                                                         //    $avail = array(
                                                         //     $id=$day,
                                                         // );
                                                                  }
                                                                                          
                                                    if($id == '4'){
                                                        $day = "Thursday";
                                                         if ($exday == $day) {
                                                          array_push($avail, $datndate);
                                                          array_push($startTime, $av_res->from);
                                                          array_push($endTime, $av_res->to);
                                                        }
                                                    // array_push($avail, $day);
                                                        // $avail = array(
                                                        // $id=$day,
                                                        // );                   
                                                    }
                                                                                          
                                                    if($id == '5'){
                                                        $day = "Friday";
                                                         if ($exday == $day) {
                                                          array_push($avail, $datndate);
                                                          array_push($startTime, $av_res->from);
                                                          array_push($endTime, $av_res->to);
                                                        }
                                                            // array_push($avail, $day);
                                                     //    $avail = array(
                                                     //     $id=$day,
                                                     // );

                                                    }
                                                                                          
                                                    if($id == '6'){
                                                        $day = "Saturday";
                                                         if ($exday == $day) {
                                                          array_push($avail, $datndate);
                                                          array_push($startTime, $av_res->from);
                                                          array_push($endTime, $av_res->to);
                                                        }
                                                            // array_push($avail, $day);
                                                        // $avail = array(
                                                        //     $id=$day,
                                                        // );
                                                    }
                                                                                          
                                                    if($id == '7'){
                                                        $day = "Sunday";
                                                         if ($exday == $day) {
                                                          array_push($avail, $datndate);
                                                          array_push($startTime, $av_res->from);
                                                          array_push($endTime, $av_res->to);
                                                        }
                                                            // array_push($avail, $day);
                                                     //    $avail = array(
                                                     //     $id=$day,
                                                     // );
                                                    }
                                                                                          
                                                            ?>
                                                                                            
                                                                                      
                                                                            
                                                                                <?php
                                                                            }
                                                                         }
                    }
                                                                         
          
  
        
        // foreach ($rangArray as $key => $value) {
        //     // dd($value);
        //     $arr = array(
        //     $value => date('l - d/m/Y', strtotime("this week")),
        // );
        // }
        
    // dd($avail);
    //  echo "<pre>";
    //     print_r($avail);                   
    //     echo "</pre>";
    
                    //  dd($avail);
                    
                                                                        $aviable_days = [];
                                                                        foreach($Availibilty as $id => $av_res){
                                                                            if(isset($av_res->enable)){
                                                                               
                                                                               
                                                                                   
                                                                                      
                                                                                        $day = '';
                                                                                          if($id == '1'){
                                                                                                $day = "Monday";
                                                                                                array_push($aviable_days,1);
                                                                                          }
                                                                                          
                                                                                           if($id == '2'){
                                                                                                $day = "Tuesday";
                                                                                                array_push($aviable_days,2);
                                                                                          }
                                                                                          
                                                                                           if($id == '3'){
                                                                                                $day = "Wednesday";
                                                                                                array_push($aviable_days,3);
                                                                                          }
                                                                                          
                                                                                           if($id == '4'){
                                                                                                $day = "Thursday";
                                                                                                array_push($aviable_days,4);
                                                                                          }
                                                                                          
                                                                                           if($id == '5'){
                                                                                                $day = "Friday";
                                                                                                array_push($aviable_days,5);
                                                                                          }
                                                                                          
                                                                                           if($id == '6'){
                                                                                                $day = "Saturday";
                                                                                                array_push($aviable_days,6);
                                                                                          }
                                                                                          
                                                                                           if($id == '7'){
                                                                                                $day = "Sunday";
                                                                                                array_push($aviable_days,0);
                                                                                          }
                                                                            }
                                                                        }

?>
                                                        <table class="table">
                                                            <thead>
                                                            <tr>
                                                                <th>Day of Week</th>
                                                                <th>Open</th>
                                                                <th>Close</th>
                                                            </tr>
                                                            </thead>
                                                                <tbody>
                                                                    <?php 
                                                    
                                                                        foreach($avail as $id => $av_res){
                                                                            
                                                                                ?>
                                                                                <tr>
                                                                                    <td>
                                                                                       
                                                                                            
                                                                                            {{ $av_res }}
                                                                                      </td>
                                                                                    <td>{{ $startTime[$id] }}</td>
                                                                                    <td>{{ $endTime[$id] }}</td>
                                                                                </tr>
                                                                                <?php
                                                                            
                                                                        }
                                                                    ?>
                                                                </tbody>
                                                        </table>
                                                    </div>
                                   
                       
                                
                 </section>
                 <section id="section-4">
                     
                     
                      <h6>Meeting and Pickups</h6>
                      {!! $tour_details->meeting_and_pickups !!}
                  </section>
                 <section id="section-5">
                          <h6>Whats Included?</h6>
                                    <p>{{ $tour_details->whats_included }}</p>
                                    
                                    <h6>Whats Excluded?</h6>
                                    <p>{{ $tour_details->whats_excluded }}</p>
                       
                    </section>
               
                <section id="section-6 mb-5">
                    <h3>frequently asked questions</h3>
                                    <div class="trip-schedule-accordion accordion">
                                    @php 
                                            $x=1; 
                                        @endphp
                                        @if($faqs_arrs != '')
                                        @foreach($faqs_arrs as $faq_res)
                                        <h3>{{ $faq_res->title }} </h3>
                                        <div>
                                            <div class="tour-map-wrapper pl-3">
                                              
                                                <p>{{ $faq_res->content }}</p>
                                            </div>
                                            <br>
                                           
                                        </div>
                                        @php $x++ @endphp
                                        @endforeach
                                        @endif
                         
                                  

                                     
                                    </div>
                             
                    
                </section>
    
    <!--<div class="owl-carousel2 owl-theme">-->
    <!--    <div class="item"><h4>1</h4></div>-->
    <!--    <div class="item"><h4>2</h4></div>-->
    <!--    <div class="item"><h4>3</h4></div>-->
    <!--    <div class="item"><h4>4</h4></div>-->
    <!--    <div class="item"><h4>5</h4></div>-->
    <!--    <div class="item"><h4>6</h4></div>-->
    <!--    <div class="item"><h4>7</h4></div>-->
    <!--    <div class="item"><h4>8</h4></div>-->
    <!--    <div class="item"><h4>9</h4></div>-->
    <!--    <div class="item"><h4>10</h4></div>-->
    <!--    <div class="item"><h4>11</h4></div>-->
    <!--    <div class="item"><h4>12</h4></div>-->
    <!--</div>-->
                
                
                
               
            </div>
            
            <!--end of colum 8-->
            <div class="col-sm-4 col-md-3">
                 <div class="detail-sidebar">
                            <div class="call-to-book">
                                <i class="awe-icon awe-icon-phone"></i>
                                <em>Call to book</em>
                                <span>0121 777 2522</span>
                            </div>
                            <form action="{{ route('add.to.cart') }}" method="post">
                            @csrf
                            <div class="booking-info">
                                <h3>Booking info</h3>
                                <a  href="#" data-bs-toggle="modal" data-bs-target="#exampleModal1">
                                   Cancellation Policy ?
                                </a>
                                
                           
        
                                <div class="form-select-date">
                                    <div class="form-elements">
                                        <label>Travel Date</label>
                                        <div class="form-item">
                                            <i class="awe-icon awe-icon-calendar"></i>
                                            
                                            <?php 
                                                $complete_date = explode('-',$tour_details->activity_date);
                                                
                                                $start_date = $complete_date[0];
                                                $end_date = $complete_date[1];
                                                
                                                
                                            ?>
                                            
                                            <input type="text"  class="form-control" id="datepicker" name="activity_date" required value="">
                                            <input type="text" name="pakage_type" hidden value="activity">
                                        </div>
                                    </div>
                                </div>
                                
                            
                                <div class="form-select-date">
                                    <div class="form-elements">
                                        <label>Adult Price: {{ $tour_details->currency_symbol." ".$tour_details->sale_price }}</label>
                                        <label>Child Price: @if($tour_details->child_sale_price != 0 AND $tour_details->child_sale_price != null)
                                                           {{ $tour_details->currency_symbol." ".$tour_details->child_sale_price }} 
                                                          @else 
                                                            {{ $tour_details->currency_symbol." ".$tour_details->sale_price }} 
                                                          @endif</label>
                                      
                                    </div>
                                </div>
                                
                                
                                
                                
                                
                                
                                
                                
                                <div class="form-group">
                                    <div class="form-elements form-adult">
                                        <label>Adult</label>
                                        <div class="form-item">
                                            <input type="text" hidden name="toure_id" value="{{ $tour_details->id }}">
                                            <select name="adults" id="adults" class="awe-select">
                                                <option>0</option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                                <option>6</option>
                                                <option>7</option>
                                                <option>8</option>
                                                <option>9</option>
                                                <option>10</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-elements form-kids">
                                        <label>Children </label>
                                        <div class="form-item">
                                            <select name="childs" class="awe-select">
                                            <option>0</option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                                <option>6</option>
                                                <option>7</option>
                                                <option>8</option>
                                                <option>9</option>
                                                <option>10</option>
                                            </select>
                                        </div>
                                        <!--<span>11 and under</span>-->
                                    </div>
                                </div>
                                  
                                 @if(isset($addtional_service_arr))
                                      <div class="widget widget_has_radio_checkbox">
                                        <h3>Additional Services   
                                            <button type="button" class="border border-light" data-bs-toggle="tooltip" data-bs-placement="top" title="Select Additional Services(Per Person)">
                                                <i class="fa fa-info-circle" aria-hidden="true"></i>
                                            </button>
                                        
                                        </h3>
                                        <ul>
                                        
                                      
                                         <?php $x= 2; ?>
                                            @foreach($addtional_service_arr as $service_res)
                                            <li>
                                                <label>
                                                    <input type="checkbox" id="chechbox{{ $x }}" onclick="checkPerPerson('{{ $service_res->service_type }}','chechbox{{ $x }}','first_checkbox{{ $x }}',{{ $service_res->service_type }})"  name="additonal_service[]" value="{{ $service_res->service_name }}">
                                                    <i class="awe-icon awe-icon-check"></i>
                                                    {{ $service_res->service_name }} 
                                                                (<?php if($service_res->service_type == 0){
                                                                            echo "One-Time";
                                                                       } 
                                       
                                                                        if($service_res->service_type == 2){
                                                                            echo "Per-Day";
                                                                        }
                                                                        
                                                                        
                                                                        
                                                                        
                                                                ?>) 
                                                    <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$service_res->service_price }}</span>
                                                </label>
                                                <div id="first_checkbox{{ $x }}">
                                                                 
                                                </div>
                                            </li>
                                             <?php $x++; ?>
                                            @endforeach
                                       
                                            
                                        </ul>
                                    </div>
                                     @endif  
                                      
                                     
                                      <?php 
        $complete_date = explode('-',$tour_details->activity_date);
        
        $start_date = explode('/',$complete_date[0]);
        $month = $start_date[0];
        $day = $start_date[1];
        $year = $start_date[2];
        $end_date = explode('/',$complete_date[1]);
        $month_end = $end_date[0];
        $month_end = trim($month_end,' ');
        $day_end = $end_date[1];
        $year_end = $end_date[2];
        
    ?>
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                               
                                
                                <div class="form-submit">
                                    <div class="add-to-cart">
                                        Select atleast one adult in order to proceed with your booking.
                                        <button type="submit" id="add_to_cart" style="display:none">
                                            <i class="awe-icon awe-icon-cart"></i>Add to Cart
                                        </button>
                                    </div>
                                </div>
                                
                            </div>
                            </form>
                        </div>
            </div>
            
        </div>
       
           <section class="my-5">
                         <h5 class="m-3">You May Like</h5>
                        <div class="owl-carousel owl-carousel6 owl-theme">
                           
                            @if(isset($related_activties))
                                @foreach($related_activties as $toure_res)
                                <div class="item">
                                    <div class="card" style="height:320px;">
                                          <img src="{{ config('img_url1') }}/public/images/activites/{{  $toure_res->featured_image }}" style="height:137px;" class="card-img-top" alt="...">
                                          <div class="card-body">
                                              <a href="{{ URL::to('activity_details/'.$toure_res->id.'') }}" style="text-decoration:none;">
                                                <h5 class="card-title" style="font-size:1rem;">{{ Str::limit($toure_res->title, 30, ' ...') }}</h5>
                                              </a>
                                              
                                                <p><i class="fa-solid fa-location-pin"></i> {{ Str::limit($toure_res->location, 40, ' ...') }}</p>
                                            <a href="{{ URL::to('activity_details/'.$toure_res->id.'') }}" class="awe-btn">Book now</a>
                                    </div>
                              
                                  </div>
                                </div>
                                @endforeach 
                             @endif
                            </div>
                </section>
        
     
        
    </div>
    
    
</div>

        
        
             <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Cancellation Policy</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
              
                  <div class="modal-body">
                    
                       <p>{{ $tour_details->cancellation_policy }}</p>
                    
                  </div>
                  <div class="modal-footer">
                    
                  </div>
              
                </div>
              </div>
            </div>


<!-- ================================
       START FOOTER AREA
================================= -->
@endsection
@section('scripts')
<script>
$('.owl-carousel6').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:4
        }
    }
})

$( function() {
    
    $( "#datepicker" ).datepicker({ 
        minDate: '{{ $month }}/{{ $day }}/{{ $year }}',
        maxDate: '{{ $month_end }}/{{ $day_end }}/{{ $year_end }}',
        changeMonth: false,
        changeYear: false,
        showWeek: false,
        showOtherMonths: true,
        selectOtherMonths: false,
        beforeShowDay: function(date) {
            var avaiableDays = {{ json_encode($aviable_days) }};
            // var avaiableDays = [2,4,6,1];
            console.log(date);
        var day = date.getDay();
        
        // const isBeforeToday = date < new Date(2022,8,01);
        // const isAfterStart = date > new Date(2022,6,01);
        var result = true;
        var counter = 1;
        for(avlDayes = 0; avlDayes < avaiableDays.length; avlDayes++){
             if(day !== avaiableDays[avlDayes]){
                   counter++;
                }
        }
        
        if(counter == avaiableDays.length){
            result = true;
        }else{
            result = false;
        }
      
        return [result];
        }
    });
  } );
  
  
  
  
  
  
  
  
        function updateConfig() {
            var options = {};
            $('.config-demo').daterangepicker(options, function(start, end, label) {
                console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')'); 

            }).click();
        }
        
        updateConfig();
$('#adults').change(function(){
    var adutls = $(this).val();
    if(adutls >0){
        $('#add_to_cart').css('display','block');
    }else{
         $('#add_to_cart').css('display','none');
    }
    console.log('This is change now'+adutls);
})


function checkPerPerson(type,idBox,idAppend,paymentType){
    console.log('the type is '+paymentType);
  
    // if(type !== ''){
           if($('#'+idBox+'').prop('checked')){

                   console.log('Enter here if')
                        if(paymentType == 0){
                            var input = ` <div class="row">
                                            <div class="col-md-6"><input type="text" placeholder="Enter Persons" name="service_adults[]"></div>
                                            <div class="col-md-6"><input type="text" hidden placeholder="Enter Days" name="service_days[]"></div>
                                            <div class="col-md-12"><input type="text" hidden placeholder="Enter Days" class="form-control" name="service_dates[]"></div>
                                          </div>`;
                       }else{
                            var input = `<div class="row">
                                            <div class="col-md-6"><input type="text" placeholder="Enter Persons" name="service_adults[]"></div>
                                            <div class="col-md-6"><input type="text" placeholder="Enter Days" name="service_days[]"></div>
                                            <div class="col-md-12"><input type="text" placeholder="Enter Days" class="config-demo form-control" name="service_dates[]"></div>
                                          </div>`;
                       }
                   
             
                 
                 $('#'+idAppend+'').html(input)
                console.log('this is checked'+idAppend+'yr');
            }else{
                $('#'+idAppend+'').html('')
                console.log('this is not checked');
            }
            
            updateConfig();
    // }
   
    
}
</script>
<script type="text/javascript" src="{{ asset('public/plugins/plugins.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/plugins/goodlayers-core/plugins/combine/script.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/plugins/goodlayers-core/include/js/page-builder.js') }}"></script>

   
         
             <script>
    let mainNavLinks = document.querySelectorAll(".hotel-nav ul li a");
let mainSections = document.querySelectorAll("main section");

let lastId;
let cur = [];


window.addEventListener("scroll", event => {
  let fromTop = window.scrollY;

  mainNavLinks.forEach(link => {
    let section = document.querySelector(link.hash);

    if (
      section.offsetTop <= fromTop &&
      section.offsetTop + section.offsetHeight > fromTop
    ) {
      link.classList.add("current");
    } else {
      link.classList.remove("current");
    }
  });
});
    </script>
 <script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("hotel-nav");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>
<!-- LIBRARY JS-->
@endsection