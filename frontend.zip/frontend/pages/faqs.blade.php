
@extends('template/frontend/includes/master')
@section('page_title')<?php if(isset($metaInfo) && $metaInfo != ''){echo $metaInfo->pageTitle;}?>@endsection


@section('keywords')
    <meta name="keywords" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->focus_keyword;
        }
    ?>"/>
@endsection
@section('page_meta_desc')
    <meta name="description" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->meta_description;
        }
    ?>"/>
@endsection
@section('page_meta_title')
    <meta name="title" content="<?php 
        if(isset($metaInfo) && $metaInfo != ''){
            echo $metaInfo->metaTitle;
        }
    ?>"/>
@endsection
@section('content')

<!-- ================================
    START HERO-WRAPPER AREA
================================= -->

<!-- END / HEADING PAGE -->

    <style>
        ul li{
            list-style-type:disc;
        }
    </style>

          <section class="awe-parallax page-heading-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class="blog-heading-content text-uppercase">
                    <h2>Home > FAQs</h2>
                </div>
            </div>
        </section>
        
         <section class="about-us-section mt-5">
            <div class="container">
                 
                  <div class="row">
                      <div class="col-sm-12 mt-5 mb-5"> 
                       <h3 class="text-center">How do I pay?</h3>
                          <p>
                              Once you have chosen the service and provided information about yourself and other participants, you will be able to pay for your reservation by any convenient way through a secure payment system. Our payment system accepts cards from any banks and countries. The amount of prepayment is determined by the conditions of a Travel Expert. The day before the tour you need to pay for the tour in full (unless otherwise stated in the information about the tour). If you have any difficulties with payment, please contact our manager.
                        </p>
                      </div>
                      
                      <div class="col-sm-12 mt-5 mb-5"> 
                       <h3 class="">Why should I book through Alhijaz Tours?</h3>
                          <p>
                              By booking a tour through Alhijaz Tours you can:
                            Choose from more than 42,000 tours designed by certified travel experts and presented on the same platform;
                            Avoid paying additional fees and tour commissions as the best price is offered by a travel expert directly;
                            Communicate directly with travel experts and get answer to any question you might have immediately;
                            Pay online for services through a reliable and safe payment system;
                            We are happy to help travelers to choose the best tour and to ensure that it is safe and memorable.
                            This is our main goal that we work on every day while adhering to our principles.
                        </p>
                      </div>
                      
                      <div class="col-sm-12 mt-5 mb-5"> 
                       <h3 class="">You can choose and book a tour by the link.</h3>
                          <p>
                             Can I go alone?
                            Of course, many individual travelers choose adventure tours in small groups. Accommodation is in double rooms with a traveller of the same gender or in a single room with surcharge. In most groups there are a few individual travellers who start socializing and become friends already in the first days of the trip!
                            </p>
                      </div>
                      
                       <div class="col-sm-12 mt-5 mb-5"> 
                       <h3 class="">Why do I need to go on a group tour?</h3>
                          <p>
                             Traveling in a small group gives you the opportunity to meet people from a different culture, both in the country you are visiting and within your travel group. Usually travelers get so close that they become lifelong friends and continue to travel together. A small group saves you time and money on the one hand, and saves you stressful planning on the other. Travel expert has already booked transport, accommodation and program for you, you just need to be at the start of your trip and enjoy the trip, and the rest will be taken care of by Travel expert. In addition, an active journey organized in advance allows you to calculate your vacation dates in advance, saving money.
                          </p>
                      
                      </div>
                      
                    <div class="col-sm-12 mt-5 mb-5"> 
                       <h3 class="">Are the flights included?</h3>
                          <p>
                             To find out whether flights are included in your tour, go to "What is included" on the tour page. If the air tickets are not included, you can calculate the approximate price on the tour page in the 'Air tickets' section.
                          </p>
                        
                      </div>
                      
                      <div class="col-sm-12 mt-5 mb-5"> 
                       <h3 class="">What happens after the payment?</h3>
                          <p>
                            Once the deposit has been paid, a confirmation of the transaction and a detailed booking confirmation with further instructions will be sent to the e-mail address provided upon registration at Alhijaz Tours.
                          </p>
                      </div>
                      
                      <div class="col-sm-12 mt-5 mb-5"> 
                       <h3 class="">When do I get my refund?</h3>
                          <p>
                            The refund process can take up to 30 calendar days, but it usually takes 7 days.
                         </p>
                      </div>
                      
                      <div class="col-sm-12 mt-5 mb-5"> 
                       <h3 class="">What payment methods are available on Alhijaz Tours?</h3>
                          <p>
                             At the moment payment is available from any VISA, MasterCard and via bank transfer as well.
                         </p>
                      </div>
                      
                  </div>
                 
                 
            </div>
          
        </section>


<!-- start back-to-top -->
@endsection


@section('scripts')

@endsection
