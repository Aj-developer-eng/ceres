@extends('template/frontend/includes/master')
<!-- PRELOADER -->
        <div class="preloader"></div>
        <!-- END / PRELOADER -->

@section('content')
 <!--Start CSS links for slider-->
    <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/revslider/public/assets/css/settings.css') }}">
     <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/plugins/combine/traveltour-style-custom.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/plugins/combine/style.css') }}">
       <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/include/css/page-builder.css') }}">
   
       
          <!--End CSS links for slider-->
<style>


.cs-bar_list {
  margin: 0;
  padding: 0;
  list-style: none;
  position: relative;
}

.cs-bar_list::before {
  content: '';
  height: 75%;
  width: 2px;
  position: absolute;
  left: 4px;
  top: 50%;
  -webkit-transform: translateY(-50%);
          transform: translateY(-50%);
  background-color: #eaeaea;
}

.cs-bar_list li {
  position: relative;
  padding-left: 25px;
}

.cs-bar_list li:before {
  content: '';
  height: 10px;
  width: 10px;
  border-radius: 50%;
  background-color: #eaeaea;
  position: absolute;
  left: 0;
  top: 6px;
}

.cs-bar_list li:not(:last-child) {
  margin-bottom: 10px;
}

.cs-table.cs-style1.cs-type1 {
  padding: 10px 30px;
}

.cs-table.cs-style1.cs-type1 tr:first-child td {
  border-top: none;
}

.cs-table.cs-style1.cs-type1 tr td:first-child {
  padding-left: 0;
}

.cs-table.cs-style1.cs-type1 tr td:last-child {
  padding-right: 0;
}

.cs-table.cs-style1.cs-type2 > * {
  padding: 0 10px;
}

.cs-table.cs-style1.cs-type2 .cs-table_title {
  padding: 20px 0 0 15px;
  margin-bottom: -5px;
}

.cs-table.cs-style2 td {
  border: none;
}

.cs-table.cs-style2 td,
.cs-table.cs-style2 th {
  padding: 12px 15px;
  line-height: 1.55em;
}

.cs-table.cs-style2 tr:not(:first-child) {
  border-top: 1px dashed #eaeaea;
}

.cs-list.cs-style1 {
  list-style: none;
  padding: 0;
  margin: 0;
}

.cs-list.cs-style1 li {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}

.cs-list.cs-style1 li:not(:last-child) {
  border-bottom: 1px dashed #eaeaea;
}

.cs-list.cs-style1 li > * {
  -webkit-box-flex: 0;
      -ms-flex: none;
          flex: none;
  width: 50%;
  padding: 7px 0px;
}

.cs-list.cs-style2 {
  list-style: none;
  margin: 0 0 30px 0;
  padding: 12px 0;
  border: 1px solid #eaeaea;
  border-radius: 5px;
}

.cs-list.cs-style2 li {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}

.cs-list.cs-style2 li > * {
  -webkit-box-flex: 1;
      -ms-flex: 1;
          flex: 1;
  padding: 5px 25px;
}
.cs-bar_list li:before{
    background-color: #e52828;
}
     .gdlr-core-ilightbox  img{
   
   height: 240px;
   width: 100%;

}
.hotel-images-section{
        padding-top: 150px;
} 

.gdlr-core-image-overlay {
    background-color: #000000;
    background-color: rgba(0, 0, 0, 0.6);
}
.hotel-nav {
  white-space: nowrap;
  background: #37474F;
  z-index:99;
}
.hotel-nav ul {
  list-style: none;
  margin: 0;
  padding: 0;
}
/* Only stick if you can fit */

.hotel-nav ul li a {
  display: block;
  padding: 0.5rem 1rem;
  color: white;
  text-decoration: none;
}
.hotel-nav ul li a.current {
  background: black;
}

.sticky {
  position: fixed;
  top: 0;
  width: 100%;
}

.sticky + .content {
  padding-top: 102px;
}



/*page css*/
.tc{
     color: #d39d00 !important;
}
section{
    padding-top:60px;
}
.product-title h2{
        color: #000000;
    font-size: 26px;
    font-weight: 600;
}
.product-detail__info .trips .item h6{
    font-size: 18px
}
.font-26{
    font-size: 24px
}
.accordion .ui-accordion-header:before{
      content: "";
    position: absolute;
    border-radius: 50%;
    pointer-events: none;
    z-index: 1;
    -webkit-transition: all 1.2s cubic-bezier(.23,1,.32,1);
    -o-transition: all 1.2s cubic-bezier(.23,1,.32,1);
    transition: all 1.2s cubic-bezier(.23,1,.32,1);
    width: 16px;
    height: 16px;
    background-color: #fff;
   left: -10px;
    top: 0px;
    border: 2px solid #767676;
}
.accordion .ui-accordion-header:after{
    content: "";
    position: absolute;
    border-radius: 50%;
    pointer-events: none;
    z-index: 1;
    -webkit-transition: all 1.2s cubic-bezier(.23,1,.32,1);
    -o-transition: all 1.2s cubic-bezier(.23,1,.32,1);
    transition: all 1.2s cubic-bezier(.23,1,.32,1);
    width: 8px;
    height: 8px;
    background-color: #e60032;
    left: -6px;
    top: 4px;
    -webkit-transform: scale(0);
    -ms-transform: scale(0);
    transform: scale(0);
}
.accordion .ui-accordion-header {
   
    margin-bottom: 15px;
   
    line-height: 30px;
}
.accordion .ui-accordion-header-active:after{
     -webkit-transform: scale(1); */
    -ms-transform: scale(1);
     transform: scale(1);
    }
.accordion .ui-state-hover:before
{
    border: 2px solid #e02044;
}
.trip-schedule-accordion.accordion{
    border-left: 3px dotted #666;
}
.item-from img, .item-to img{
    margin:0 auto;
}
.ui-accordion .ui-accordion-content {
    padding: 0 2.2em;
}
.ui-accordion .ui-accordion-content h6{
        margin-bottom: 4px;
}
.detail-sidebar {
    margin-top: 100px;
}
.select-package-top{
    font-size:18px;
    font-size: 18px;
    background: #37474f;
    color: #fff;
    padding: 5px 18px;
}
.ticket-price th, .ticket-price td{
        text-align: center;
}
.initiative-table tbody tr .item-body{
    padding:0;
}
.initiative-table tbody tr .item-body .item-time .fa{
        color: #06a803;
        font-size: 50px;
}

h5, .h5 {
    font-size: 16px;
}



:disabled {
    cursor: default;
    background-color: #e3e3e3 !important;
    border-color: #ababab !important;
}
@media screen and (max-width: 786px){
    #hotel-nav{
        display:none;
    }
    .initiative-table tbody tr th,
    .initiative-table tbody tr {
        display: block;
        width: 100%;
    }
    .initiative-table tbody tr .item-body .item-from, .initiative-table tbody tr .item-body .item-time, .initiative-table tbody tr .item-body .item-to{
            display: block;
            width: 100%;
                text-align: left;
    }
    section {
        padding-top: 0px;
    }
}
@media screen and (max-width: 484px){
      section {
        padding-top: 0px;
    }
    .product-title h2 {
           font-size: 20px;
    }
     h3 {
    font-size: 22px;
    }
    h4 {
    font-size: 18px;
    }
    .image-thumb{
        padding: 15px 70px;
        background-color: #ddd;
    }
    .hotel-details-top{
        margin-top: 25px;
    }

}
</style>
     <!-- BREADCRUMB -->
    
        
        
        
        
        <?php 
                                        $tour_gallery_images = json_decode($tour_details->gallery_images)
                                    ?>
        
     
        
        
     <section class="hotel-images-section ">
             
            <div class="gdlr-core-pbf-element">
                <div class="gdlr-core-gallery-item gdlr-core-item-pdb clearfix  gdlr-core-gallery-item-style-grid-no-space gdlr-core-item-pdlr ">
                    <div class="gdlr-core-gallery-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">
                       <div class="container">
                       <div class="row">
                           <div class="col-md-4" style="padding-right: 0%;">
                                @if(isset($tour_gallery_images))
                                       
                           
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15" style="width: 100% !important;">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $tour_gallery_images[0] ?? '' }}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 100% !important;"  src="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $tour_gallery_images[0] ?? '' }}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                      
                                    @endif
                           </div>
                           <div class="col-md-8 d-none d-sm-block" style="padding-left: 0%;">
                                @if(isset($tour_gallery_images))
                           <?php 
                           $count=1;
                           ?>
                           
                          
                             @foreach($tour_gallery_images as $key => $gallery_res)
                            @if($key > 0)
                            @if($count <= 9)
                       
                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15">
                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $gallery_res }}"  data-ilightbox-group="gdlr-core-img-group-2">
                                    <img style="height: 160px;padding: 3px;" src="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $gallery_res }}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                            </div>
                          
                        </div>
                        @endif
                        @endif
                        <?php 
                           $count++;
                           ?>
                         @endforeach
                    @endif
                           </div>
                       </div>
                          </div>
                  
                    </div>
                </div>
            </div>
        </section>    
        <!--End Slider-->



<div calss="section-column-2">
     <nav class="navbar navbar-expand-lg navbar-dark hotel-nav" id="hotel-nav" >
                <div class="container">    
                <ul class="navbar-nav">
                 <li><a href="#section-1">Overview</a></li>
                <li><a href="#section-2">Itinerary Schedule</a></li>
                <li><a href="#section-3">Flights</a></li>
                <li><a href="#section-4">Accomodation</a></li>
                <li><a href="#section-5">Transportion</a></li>
        
                <li><a href="#section-6">Visa</a></li>
                 <li><a href="#section-7">FAQ</a></li>
               
                  </ul>
        </div>

    </nav>
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-md-9">
                  <section id="section-1">
                    <div class="row">
                    <div class="col-md-12">
                         <div class="product-title">
                                <h2>{{ $tour_details->title }}</h2>
                            </div>
                            <div class="product-address">
                                <span>   <i class="fa-solid tc fa-location-dot"></i>   
                                
                                @if(isset($tour_details->tour_location) && $tour_details->tour_location != '' && $tour_details->tour_location != null &&  $tour_details->tour_location != 'null')
                                                @php 
                                                    $locations = json_decode($tour_details->tour_location)
                                                @endphp
                                                
                                                @foreach($locations as $loca_res)
                                                    {{ $loca_res }}
                                                @endforeach
                                            @endif
                                    | <i class="fa-solid tc fa-phone"></i> 0121 777 2522</span>
                            </div>
                        <p class="mt-3">{!! $tour_details->content !!}</p>
                        
                    </div>
                    <div class="col-md-6">
                        <h6> <i class="fa-solid fa-person-circle-plus"></i> Whats Included?</h6>
                        <p>{!! $tour_details->whats_included !!}</p>
                        </div>
                         <div class="col-md-6">
                        <h6><i class="fa-solid fa-person-circle-minus"></i>  Whats Excluded?</h6>
                        <p>{!! $tour_details->whats_excluded !!}</p>
                        
                    
                    </div>
                </div>
                        <div class="product-detail__info">
                          
                            <div class="product-email">
                                <i class="fa fa-envelope"></i>
                                <a href="#">Send Email Inquiry</a>
                            </div>

                            <div class="trips">
                                <div class="item">
                                    <h6>  Departure Date</h6>
                                    <p><i class="fa tc fa-calendar" aria-hidden="true"></i> {{  date("d-m-Y", strtotime($tour_details->start_date)) }}</p>
                                   
                                </div>
                                 <div class="item">
                                    <h6> Return Date</h6>
                                    
                                    <p><i class="fa tc fa-calendar" aria-hidden="true"></i> {{ date("d-m-Y", strtotime($tour_details->end_date)) }}</p>
                                </div>
                                <div class="item">
                                    <h6>Time length</h6>
                                    <p><i class="fa-regular tc fa-moon"></i> {{ $tour_details->time_duration }} Nights</p>
                                </div>
                                <div class="item">
                                    <h6>Category</h6>
                                    <p><i class="fa-solid tc fa-clipboard-check"></i> {{ $category_name }}</p>
                                </div>
                                <div class="item">
                                    <h6>Transport included</h6>
                                    <p><i class="fa fa-bus tc" aria-hidden="true"></i> 
                                        @if(isset($transportation_details))
                                        {{  $transportation_details->transportation_vehicle_type }}
                                        @endif
                                    </p>
                                </div>
                                <div class="item">
                                    <h6>Destinations</h6>
                                    <p title="Makkah, Madina"><i class="fa-solid tc fa-building-circle-check"></i> 
                                    @if(isset($tour_details->tour_location[0])  && $tour_details->tour_location != '' && $tour_details->tour_location != null &&  $tour_details->tour_location != 'null')
                                    
                                        @php 
                                            $locations = json_decode($tour_details->tour_location)
                                        @endphp
                                        
                                       
                                        @foreach($locations as $loca_res)
                                            {{ $loca_res }},
                                        @endforeach
                                        
                                    @endisset
                                        
                                    </p>
                                </div>
                                <div class="item">
                                     <a   href="#" data-bs-toggle="modal" data-bs-target="#exampleModal1">
                                      <i class="fa-regular fa-calendar-xmark"></i> Cancellation Policy ?
                                    </a>
                             
                               
                                </div>
                            </div>

                            <!-- <div class="rating-trip-reviews">
                                <div class="item good">
                                    <span class="count">7.5</span>
                                    <h6>Average rating</h6>
                                    <p>Good</p>
                                </div>
                                <div class="item">
                                    <h6>TripAdvisor ></h6>
                                    <img src="images/trips.png" alt="">
                                </div>
                                <div class="item">
                                    <h6>Reviews</h6>
                                    <p>No review yet</p>
                                </div>
                            </div> -->

                            <table class="ticket-price">
                                <thead>
                                   <tr>
                                        @if($tour_details->double_grand_total_amount != 0 AND $tour_details->double_grand_total_amount != null) 
                                        <th class="adult"><span>Double Price</span></th>
                                        @endif
                                         <?php
                                         if($tour_details->triple_grand_total_amount!= 0 AND $tour_details->triple_grand_total_amount!= null){ 
                                         ?>
                                        <th class="adult"><span>Triple Price</span></th>
                                        <?php
                                        }
                                        ?>
                                        
                                         @if($tour_details->quad_grand_total_amount != 0 AND $tour_details->quad_grand_total_amount != null) 
                                        <th class="kid"><span>Quad Price</span></th>
                                        @endif
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <tr>
                                        @if($tour_details->double_grand_total_amount != 0 AND $tour_details->double_grand_total_amount != null) 
                                        <td class="adult">
                                          <ins>
                                                <span class="amount">{{ $tour_details->currency_symbol." ".$tour_details->double_grand_total_amount ?? '0' }}</span>
                                            </ins>
                                        </td>
                                        @endif
                                        @if($tour_details->triple_grand_total_amount != 0 AND $tour_details->triple_grand_total_amount != null) 
                                        <td class="adult">
                                            <ins>
                                                <span class="amount">{{ $tour_details->currency_symbol." ".$tour_details->triple_grand_total_amount ?? '0' }}</span>
                                            </ins>
                                           
                                        </td>
                                        @endif
                                        @if($tour_details->quad_grand_total_amount != 0 AND $tour_details->quad_grand_total_amount != null) 
                                        <td class="kid">
                                            <ins>
                                                <span class="amount">{{ $tour_details->currency_symbol." ".$tour_details->quad_grand_total_amount ?? '0' }}</span>
                                            </ins>
                                            <!--<del>-->
                                            <!--    <span class="amount">{{ $tour_details->currency_symbol }} {{ $tour_details->double_grand_total_amount }}.00</span>-->
                                            <!--</del>-->
                                        </td>
                                        @endif
                                    </tr>
                                </tbody>
                            </table>


                        </div>
                </section>
               
              
                 <section id="section-2">
                                <h3>Itinerary Schedule</h3>
                                    <div class="trip-schedule-accordion accordion">
                                    @php $itineraryDetails = json_decode($tour_details->Itinerary_details);
                                            $x=1;    
                                        @endphp
                                        @if(isset($itineraryDetails[0]->Itinerary_title))
                                        @foreach($itineraryDetails as $itnary_res)
                                        <h3>{{ $itnary_res->Itinerary_title }} : {{ $itnary_res->Itinerary_city }}</h3>
                                        <div>
                                           <div class="row">
                                                
                                                <div class="col-md-12">
                                             
                                                <p class="text-justify-content">{{ $itnary_res->Itinerary_content }}</p>
                                            </div>
                                            </div>
                                            
                                           
                                        </div>
                                        @php $x++ @endphp
                                        @endforeach
                                        @endif

                                        @php $itineraryDetails = json_decode($tour_details->Itinerary_details);
                                            $x=1;    
                                        @endphp
                                        @if(isset($iternery1))
                                        @foreach($iternery1 as $itnary_res)
                                        <h3>{{ $itnary_res->more_Itinerary_title }} : {{ $itnary_res->more_Itinerary_city }}</h3>
                                        <div>
                                            <div class="row">
                                               
                                                <div class="col-md-12">
                                                   
                                                    <p class="text-justify-content">{{ $itnary_res->more_Itinerary_content }}</p>
                                                </div>
                                            </div>
                                            
                                           
                                        </div>
                                        @php $x++ @endphp
                                        @endforeach
                                        @endif
                                     
                                    </div>
                             
                </section>
                 <section id="section-3">
                    <h3>Flight Details</h3>
                    
                  
                                   
                                     @if(isset($flights_details) && !empty($flights_details))
                                     
                                     <?php 
                                        if(isset($flights_details_more)){
                                            $arr_size = sizeOf($flights_details_more);
                                            $first_depaurture = $flights_details_more[0]->more_departure_airport_code;
                                            $last_destination = $flights_details_more[$arr_size - 1]->more_arrival_airport_code;
                                            
                                            
                                            $first_dep_time = date("d-m-Y h:i:sa", strtotime($flights_details_more[0]->more_departure_time)); 
                                            $last_arrival = date("d-m-Y h:i:sa", strtotime($flights_details_more[$arr_size - 1]->more_arrival_time)); 
                                            
                                            $departure_time_original = $flights_details_more[0]->more_departure_time;
                                            $arrival_time_original = $flights_details_more[$arr_size - 1]->more_arrival_time;
                                            
                                        }else{
                                            $last_destination = $flights_details->arrival_airport_code;
                                            $first_depaurture = $flights_details->departure_airport_code;
                                            
                                            $last_arrival = date("d-m-Y h:i:sa", strtotime($flights_details->arrival_time)); 
                                            $first_dep_time = date("d-m-Y h:i:sa", strtotime($flights_details->departure_time)); 
                                            
                                            $departure_time_original = $flights_details->departure_time;
                                            $arrival_time_original = $flights_details->arrival_time;
                                        }
                                        
                                        $departure_time_obj = new DateTime($departure_time_original);
                                        $arrival_time_obj = new DateTime($arrival_time_original);
                                        
                                        $departure_total_interval = $departure_time_obj->diff($arrival_time_obj);
    
                                        // echo ($interval->format("%a") * 24) + $interval->format("%h"). " hours". $interval->format(" %i minutes ");
                                        
                                     ?>
                                    
                                      <div class="row">
                                           @if($flights_details->flight_type !== 'Indirect')
                                            <div class="col-md-6">
                                                <h6>Departure</h6>
                                                
                                                 <div class="row">
                                                     <div class="col-md-5">
                                                          <div class="item-thumb">
                                                            <div class="image-thumb">
                                                                <img src="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $flights_details->flights_image }}" style="width:100%" alt="">
                                                            </div>
                                                            
                                                        </div>
                                                     </div>
                                                    <div class="col-md-7">
                                                        <h6 style="font-size:1.4rem; color: #06a803;">{{ date("H:i", strtotime($flights_details->departure_time)) }} <span style="font-size:30px;">&#8594</span> {{ date("H:i", strtotime($flights_details->arrival_time)) }}</h6>
                                                      
                                                        <h6 style="font-size:.9rem; font-weigth:500">
                                                        <?php
                                                                 
                                                              $dateValue = strtotime(date("d-m-Y", strtotime($flights_details->departure_time ?? '' )));
                                                     
                                                                $year = date('Y',$dateValue);
                                                                $monthName = date('F',$dateValue);
                                                                $monthNo = date('d',$dateValue);
                                                                $day = date('l', $dateValue);
                                                                echo $day . ',' . $monthNo . ',' . $monthName . ',' . $year;
                                                                // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                                                              ?>
                                                            </h6>
                                                    </div>
                                                    
                                                    
                                                    <div class="col-md-12 mt-4">
                                                         
                                                         <ul class="cs-bar_list">
                                                             <li><b class="cs-primary_color"><i class="fa-solid fa-plane-departure"></i> </b>
                                                                <span class="time">{{ date("H:i", strtotime($flights_details->departure_time)) }}</span><span> {{  $flights_details->departure_airport_code }}</span>
                                                             </li>
                                                             
                                                              <li class="mt-4"><b class="cs-primary_color"><i class="fa-solid fa-plane-arrival"></i></b>
                                                                <span class="time">{{ date("H:i", strtotime($flights_details->arrival_time)) }}</span><span> {{  $flights_details->arrival_airport_code }}</span>
                                                             </li>
                                                         </ul>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <h6>Return</h6>
                                                 <div class="row">
                                                      <div class="col-md-5">
                                                          <div class="item-thumb">
                                                            <div class="image-thumb">
                                                                <img src="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $flights_details->flights_image }}" style="width:100%" alt="">
                                                            </div>
                                                            
                                                        </div>
                                                     </div>
                                                    <div class="col-md-7">
                                                        <h6 style="font-size:1.4rem;color: #06a803;">{{ date("H:i", strtotime($flights_details->return_departure_time)) }} <span style="font-size:30px; margin:1rem;">&#8594</span> {{ date("H:i", strtotime($flights_details->return_arrival_time)) }}</h6>
                                                        
                                                        <h6 style="font-size:.9rem; font-weigth:500">
                                                        <?php
                                                                 
                                                              $dateValue = strtotime(date("d-m-Y", strtotime($flights_details->return_departure_time ?? '' )));
                                                     
                                                                $year = date('Y',$dateValue);
                                                                $monthName = date('F',$dateValue);
                                                                $monthNo = date('d',$dateValue);
                                                                $day = date('l', $dateValue);
                                                                echo $day . ',' . $monthNo . ',' . $monthName . ',' . $year;
                                                                // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                                                              ?>
                                                            </h6>
                                                    </div>
                                                    
                                                   
                                                    <div class="col-md-12 mt-4">
                                                         
                                                       
                                                         <ul class="cs-bar_list">
                                                             <li><b class="cs-primary_color"><i class="fa-solid fa-plane-departure"></i> </b>
                                                                <span class="time">{{ date("H:i", strtotime($flights_details->return_departure_time)) }}</span><span> {{  $flights_details->return_departure_airport_code }}</span>
                                                             </li>
                                                             
                                                              <li class="mt-4"><b class="cs-primary_color"><i class="fa-solid fa-plane-arrival"></i></b>
                                                                <span class="time">{{ date("H:i", strtotime($flights_details->return_arrival_time)) }}</span><span> {{  $flights_details->return_arrival_airport_code }}</span>
                                                             </li>
                                                         </ul>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            @endif
                                       <div class="col-md-6">
                                           <div class="row">
                                                @if(isset($flights_details_more))
                                                     @foreach($flights_details_more as $more_fl_res)
                                                     <div class="col-md-12">
                                                <h6 class="mt-4">Departure</h6>
                                                
                                                 <div class="row">
                                                     <div class="col-md-5">
                                                          <div class="item-thumb">
                                                            <div class="image-thumb">
                                                                <img src="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $flights_details->flights_image }}" style="width:100%" alt="">
                                                            </div>
                                                            
                                                        </div>
                                                     </div>
                                                    <div class="col-md-7">
                                                        <h6 style="font-size:1.4rem; color: #06a803;">{{ date("H:i", strtotime($more_fl_res->more_departure_time)) }} <span style="font-size:30px; margin:1rem;">&#8594</span> {{ date("H:i", strtotime($more_fl_res->more_arrival_time)) }}</h6>
                                                       
                                                        <h6 style="font-size:.9rem; font-weigth:500">
                                                        <?php
                                                                 
                                                              $dateValue = strtotime(date("d-m-Y", strtotime($more_fl_res->more_departure_time ?? '' )));
                                                     
                                                                $year = date('Y',$dateValue);
                                                                $monthName = date('F',$dateValue);
                                                                $monthNo = date('d',$dateValue);
                                                                $day = date('l', $dateValue);
                                                                echo $day . ',' . $monthNo . ',' . $monthName . ',' . $year;
                                                                // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                                                              ?>
                                                            </h6>
                                                    </div>
                                                    
                                                    
                                                    <div class="col-md-12 mt-4">
                                                         
                                                         <ul class="cs-bar_list">
                                                             <li><b class="cs-primary_color"><i class="fa-solid fa-plane-departure"></i> </b>
                                                                <span class="time">{{ date("H:i", strtotime($more_fl_res->more_departure_time)) }}</span><span> {{  $more_fl_res->more_departure_airport_code }}</span>
                                                             </li>
                                                             
                                                              <li class="mt-4"><b class="cs-primary_color"><i class="fa-solid fa-plane-arrival"></i></b>
                                                                <span class="time">{{ date("H:i", strtotime($more_fl_res->more_arrival_time)) }}</span><span> {{  $more_fl_res->more_arrival_airport_code }}</span>
                                                             </li>
                                                         </ul>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                                     @endforeach
                                             @endif
                                           </div>
                                       </div>     
                                            
                                        <div class="col-md-6">
                                            <div class="row">
                                                 @if(isset($flights_details_more))
                                                     @foreach(array_reverse($flights_details_more) as $more_fl_res)
                                                     
                                                      <div class="col-md-12">
                                                <h6 class="mt-4">Return</h6>
                                                
                                                 <div class="row">
                                                     <div class="col-md-5">
                                                          <div class="item-thumb">
                                                            <div class="image-thumb">
                                                                <img src="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $flights_details->flights_image }}" style="width:100%" alt="">
                                                            </div>
                                                            
                                                        </div>
                                                     </div>
                                                    <div class="col-md-7">
                                                        <h6 style="font-size:1.4rem; color: #06a803;">{{ date("H:i", strtotime($more_fl_res->return_more_departure_time)) }} <span style="font-size:30px; margin:1rem;">&#8594</span> {{ date("H:i", strtotime($more_fl_res->return_more_arrival_time)) }}</h6>
                                                       
                                                        <h6 style="font-size:.9rem; font-weigth:500">
                                                        <?php
                                                                 
                                                              $dateValue = strtotime(date("d-m-Y", strtotime($more_fl_res->return_more_departure_time ?? '' )));
                                                     
                                                                $year = date('Y',$dateValue);
                                                                $monthName = date('F',$dateValue);
                                                                $monthNo = date('d',$dateValue);
                                                                $day = date('l', $dateValue);
                                                                echo $day . ',' . $monthNo . ',' . $monthName . ',' . $year;
                                                                // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                                                              ?>
                                                            </h6>
                                                    </div>
                                                    
                                                  
                                                    <div class="col-md-12 mt-4">
                                                         
                                                       
                                                              
                                                              
                                                             
                                                         <ul class="cs-bar_list">
                                                             <li><b class="cs-primary_color"><i class="fa-solid fa-plane-departure"></i> </b>
                                                                <span class="time">{{ date("H:i", strtotime($more_fl_res->return_more_departure_time)) }}</span><span> {{  $more_fl_res->return_more_departure_airport_code }}</span>
                                                             </li>
                                                             
                                                              <li class="mt-4"><b class="cs-primary_color"><i class="fa-solid fa-plane-arrival"></i></b>
                                                                <span class="time">{{ date("H:i", strtotime($more_fl_res->return_more_arrival_time)) }}</span><span> {{  $more_fl_res->return_more_arrival_airport_code }}</span>
                                                             </li class="mt-5">
                                                         </ul>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        
                                                     @endforeach
                                                     @endif
                                            </div>
                                        </div>
                                              
                                            
                                            
                                              
                                        </div>
                    
                                    
                                    @endif
                                
                 </section>
                 <section id="section-4">
                      
                                    
                                     @if(isset($accomodation_details))
                                         @foreach($accomodation_details as $acc_res)
                                            <div class="hotel-details-top">
                                                <h4>{{  $acc_res->hotel_city_name }} Hotel Details</h4>
                                                <div class="row">
                                                    <div class="col-sm-4 col-md-3">
                                                        <img src="{{ config('img_url1') }}/public/uploads/package_imgs/{{ $acc_res->accomodation_image[0] ?? '' }}" alt="">
                                                    </div>
                                                    <div class="col-sm-4 col-md-5">
                                                         <h5>{{ $acc_res->acc_hotel_name }}</h5>
                                                         <ul>
                                                             <li>
                                                                 <i class="fa-solid fa-bed"></i> Room Type:  <span> {{ $acc_res->acc_type }}</span><span>  @if(isset($accomodation_details_more))
                                                                @foreach($accomodation_details_more as $acc_more_res)
                                                                    @if($acc_more_res->more_hotel_city == $acc_res->hotel_city_name)
                                                                   
                                                                      <span>/{{ $acc_more_res->more_acc_type }}</span>
                                                                    @endif
                                                                @endforeach
                                                            @endif</span>
                                                                 
                                                             </li>
                                                              <li> <i class="fa-solid fa-bed"></i> Check In  : {{  date("d-m-Y", strtotime($acc_res->acc_check_in)) }}</li>
                                                            <li> <i class="fa-solid fa-bed"></i> Check Out : {{  date("d-m-Y", strtotime($acc_res->acc_check_out)) }}</li>
                                                            <li> <i class="fa-solid fa-bed"></i> No Of Nights : {{  $acc_res->acc_no_of_nightst }}</li>
                                                         </ul>
                                                       
                                                          
                                                        
                                                    </div>
                                                    <div class="col-sm-4 col-md-4">
                                                        <h5>Room Amenities </h5>
                                                        {{  $acc_res->hotel_whats_included }}
                                                    </div>
                                                    
                                                </div>    
                                            </div>   
                                            
                                            <section class="hotel-images-section " style="padding-top:10px;">
             
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-gallery-item gdlr-core-item-pdb clearfix  gdlr-core-gallery-item-style-grid-no-space gdlr-core-item-pdlr ">
                                                    <div class="gdlr-core-gallery-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">
                                                       <div class="container">
                                                       <div class="row">
                                                         
                                                           <div class="col-md-12" style="padding-left: 0%;">
                                                                @if(isset($acc_res->accomodation_image))
                                                           <?php 
                                                           $count=1;
                                                           ?>
                                                           
                                                          
                                                             @foreach($acc_res->accomodation_image as $key => $gallery_res)
                                                            @if($key > 0)
                                                            @if($count <= 9)
                                                       
                                                        <div class="gdlr-core-item-list gdlr-core-gallery-column  gdlr-core-column-15" style="width:15%">
                                                            <div class="gdlr-core-gallery-list gdlr-core-media-image">
                                                                <a class="gdlr-core-ilightbox gdlr-core-js "  href="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $gallery_res }}"  data-ilightbox-group="gdlr-core-img-group-2">
                                                                    <img style="height:100px;padding: 3px;" src="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $gallery_res }}" alt="" /><span class="gdlr-core-image-overlay "><i class="gdlr-core-image-overlay-icon gdlr-core-size-22 fa fa-search"  ></i></span></a>
                                                            </div>
                                                          
                                                        </div>
                                                        @endif
                                                        @endif
                                                        <?php 
                                                           $count++;
                                                           ?>
                                                         @endforeach
                                                    @endif
                                                           </div>
                                                       </div>
                                                          </div>
                                                  
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                        @endforeach
                                        @endif  
                                        
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                      
                                        
                               
                  </section>
                 <section id="section-5">
                         <h3>Transfer Details</h3>
                                    @if(isset($transportation_details))
                                        <table class="initiative-table">
                                                <tbody>
                                                    <tr>
                                                        <th>
                                                            <div class="item-thumb">
                                                                <div class="image-thumb">
                                                                    <img src="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $transportation_details->transportation_image }}" alt="">
                                                                </div>
                                                                <div class="text">
                                                                    <span>Vehicle: {{  $transportation_details->transportation_vehicle_type }}</span>
                                                                </div>
                                                            </div>
                                                        </th>
                                                        <td>
                                                            <div class="item-body">
                                                                <div class="item-from">
                                                                    <h3 style="font-size:1.1rem;">Pickup Location</h3>
                                                                    <h6 style="font-size:1rem;">{{  $transportation_details->transportation_pick_up_location }}</h6>
                                                                   <?php 
                                                                    if($transportation_details->transportation_pick_up_date != ''){
                                                                        $pickup_date = date("d-m-Y", strtotime($transportation_details->transportation_pick_up_date));
                                                                        $pickup_time = date("h:i:sa", strtotime($transportation_details->transportation_pick_up_date));
                                                                    }else{
                                                                        $pickup_date = '';
                                                                        $pickup_time = '';
                                                                    }
                                                                    
                                                                    if($transportation_details->transportation_drop_of_date != ''){
                                                                        $drop_off_date = date("d-m-Y", strtotime($transportation_details->transportation_drop_of_date));
                                                                        $drop_off_time = date("h:i:sa", strtotime($transportation_details->transportation_drop_of_date));
                                                                    }else{
                                                                        $drop_off_date = '';
                                                                        $drop_off_time = '';
                                                                    }
                                                                   ?>
                                                                   <h6 style="font-size:.8rem; margin-bottom: 0.5rem;">Pickup Date:{{ $pickup_date  }} </h6>
                                                                   <h6 style="font-size:.8rem; ">Pickup Date:{{ $pickup_time  }} </h6>
                                                                   
                                                                   
                                                                   
                                                                </div>
                                                                <div class="item-time">
                                                                    <i class="fa fa-clock-o"></i>
                                                                    <span>{{ $transportation_details->transportation_total_Time }}</span>
                                                                </div>
                                                                <div class="item-to">
                                                                     <h3 style="font-size:1.1rem;">Drop off Location</h3>
                                                                    <h6 style="font-size:1rem;">{{  $transportation_details->transportation_drop_off_location }}</h6>
                                            
                                                                    <h6 style="font-size:.8rem; margin-bottom: 0.5rem;">Drop off Date:{{ $drop_off_date }} </h6>
                                                                   <h6 style="font-size:.8rem; ">Drop off Time{{ $drop_off_time }} </h6>

                                                                </div>
                                                            </div>
                                                        </td>
                                                        
                                                    </tr>
                                                     @if($transportation_details->transportation_trip_type == 'Return')
                                                      <tr>
                                                        <th>
                                                            <div class="item-thumb">
                                                                <div class="image-thumb">
                                                                </div>
                                                                <div class="text">
                                                                  
                                                                </div>
                                                            </div>
                                                        </th>
                                                         <td>
                                                            <div class="item-body">
                                                                <div class="item-from">
                                                                    <h3>{{  $transportation_details->return_transportation_pick_up_location }}</h3>
                                                                   
                                                                     <h6 style="font-size:.8rem; margin-bottom: 0.5rem;">{{ date("d-m-Y", strtotime($transportation_details->return_transportation_pick_up_date)) }}</h6>
                                                                   <h6 style="font-size:.8rem; ">{{ date("h:i:sa", strtotime($transportation_details->return_transportation_pick_up_date)) }}</h6>
                                                                   
                                                                   
                                                                </div>
                                                                <div class="item-time">
                                                                    <i class="fa fa-clock-o"></i>
                                                                    <span>Retrun</span>
                                                                </div>
                                                                <div class="item-to">
                                                                    <h3>{{  $transportation_details->return_transportation_drop_off_location }}</h3>
                                                                    <h6 style="font-size:.8rem; margin-bottom: 0.5rem;">{{ date("d-m-Y", strtotime($transportation_details->return_transportation_drop_of_date)) }}</h6>
                                                                   <h6 style="font-size:.8rem; ">{{ date("h:i:sa", strtotime($transportation_details->return_transportation_drop_of_date)) }}</h6>
                                                                   
                                                                   
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    
                                                    
                                                    @endif
                                                    
                                                    @if(isset($transportation_details_more))
                                                    @foreach($transportation_details_more as $tran_more)
                                                      <tr>
                                                        <th>
                                                            <div class="item-thumb">
                                                                <div class="image-thumb">
                                                                </div>
                                                                <div class="text">
                                                                  
                                                                </div>
                                                            </div>
                                                        </th>
                                                         <td>
                                                            <div class="item-body">
                                                                <div class="item-from">
                                                                    <h3>{{  $tran_more->more_transportation_pick_up_location }}</h3>
                                                                     <h6 style="font-size:.8rem; margin-bottom: 0.5rem;">{{ date("d-m-Y", strtotime($tran_more->more_transportation_pick_up_date)) }}</h6>
                                                                   <h6 style="font-size:.8rem; ">{{ date("h:i:sa", strtotime($tran_more->more_transportation_pick_up_date)) }}</h6>
                                                                   
                                                                
                                                                   
                                                                </div>
                                                                <div class="item-time">
                                                                    <i class="fa fa-clock-o"></i>
                                                                    <span>Others</span>
                                                                </div>
                                                                <div class="item-to">
                                                                    <h3>{{  $tran_more->more_transportation_drop_off_location }}</h3>
                                                                   
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                     @endforeach
                                                     @endif
                                            
                                                    
                    
                                                       
                                                
                                                </tbody>
                                            </table>
                                             @endif
                                        
                              
                       
                    </section>
                <section id="section-6">
                   <h3>Visa Details</h3>
                                    @if(isset($tour_details->visa_rules_regulations))
                                        <table class="initiative-table">
                                                <tbody>
                                                    <tr>
                                                        <th>
                                                            <div class="item-thumb">
                                                                <div class="image-thumb">
                                                                    <img src="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $tour_details->visa_image }}" alt="">
                                                                </div>
                                                            </div>
                                                        </th>
                                                        <td>
                                                            <div class="item-body">
                                                                <div class="row">
                                                                    <div class="col-md-4"><h6 style="font-size:18px;">Visa Type</h6>
                                                                        <h6 style="font-size:14px; font-weight:100; text-transform: capitalize;">{{  $visa_type }}</h6>
                                                                    </div>
                                                                    <div class="col-md-8"><h6 style="font-size:18px;">Visa Requirements</h6>
                                                                    <h6 style="font-size:14px; font-weight:100;">{{  $tour_details->visa_rules_regulations }}</h6>
                                                                    
                                                                    </div>
                                                                    
                                                                </div>
                                                            </div>
                                                        </td>
                                                        
                                                    </tr>
                                               
                                                    
                    
                                                       
                                                
                                                </tbody>
                                            </table>
                                             @endif
                                        
                                
                </section>    
                <section id="section-7 mb-5">
                    <h3>Frequently Asked Questions</h3>
                                    <div class="trip-schedule-accordion accordion">
                                    @php $faqDetails = json_decode($tour_details->tour_faq);
                                            $x=1; 
                                        @endphp
                                        @if($faqDetails[0]->faq_title != null)
                                        @foreach($faqDetails as $faq_res)
                                        <h3>{{ $faq_res->faq_title }} </h3>
                                        <div>
                                            <div class="tour-map-wrapper pl-3">
                                              
                                                <p>{{ $faq_res->faq_content }}</p>
                                            </div>
                                            <br>
                                           
                                        </div>
                                        @php $x++ @endphp
                                        @endforeach
                                        @endif
                         

                                        @if(isset($tour_faq_1))
                                        @foreach($tour_faq_1 as $faq_res)
                                        <h3>{{ $faq_res->more_faq_title }}</h3>
                                        <div>
                                            <div class="row">
                                                 <div class="col-md-12">
                                                    <p>{{ $faq_res->more_faq_content }}</p>
                                                </div>
                                                
                                            </div>
                                            
                                           
                                        </div>
                                        @endforeach
                                        @endif

                                     
                                    </div>
                             
                    
                </section>
    
    <!--<div class="owl-carousel2 owl-theme">-->
    <!--    <div class="item"><h4>1</h4></div>-->
    <!--    <div class="item"><h4>2</h4></div>-->
    <!--    <div class="item"><h4>3</h4></div>-->
    <!--    <div class="item"><h4>4</h4></div>-->
    <!--    <div class="item"><h4>5</h4></div>-->
    <!--    <div class="item"><h4>6</h4></div>-->
    <!--    <div class="item"><h4>7</h4></div>-->
    <!--    <div class="item"><h4>8</h4></div>-->
    <!--    <div class="item"><h4>9</h4></div>-->
    <!--    <div class="item"><h4>10</h4></div>-->
    <!--    <div class="item"><h4>11</h4></div>-->
    <!--    <div class="item"><h4>12</h4></div>-->
    <!--</div>-->
                
                
                
               
            </div>
            
            <!--end of colum 8-->
            <div class="col-sm-4 col-md-3">
                
                 <div class="detail-sidebar">
                            <div class="select-package-top">
                             <i class="fa-regular fa-hand-pointer"></i>
                               
                                <span>Select Package</span>
                            </div>
                            <form action="{{ route('add.to.cart') }}" method="post">
                            @csrf
                            <div class="booking-info">
                                
                              
                                
                           
        
                                <div class="form-select-date">
                                    <div class="form-elements">
                                        <label>Travel Date</label>
                                        <div class="form-item">
                                            <i class="awe-icon awe-icon-calendar"></i>
                                            <input type="text"  readonly class="form-control" value="{{ date("d-m-Y", strtotime($tour_details->start_date)).' '.date("d-m-Y", strtotime($tour_details->end_date)) }}">
                                            <input type="text" name="pakage_type" hidden value="tour">
                                            <input type="text" name="provider_id" hidden value="{{ $provider }}">
                                        </div>
                                    </div>
                                </div>
                                
                               
                                      
                                      
                                      
                                      @if(isset($additional_service))
                                      <div class="widget widget_has_radio_checkbox">
                                        <h3>Additional Services   
                                            <button type="button" class="border border-light" data-bs-toggle="tooltip" data-bs-placement="top" title="Select Additional Services(Per Person)">
                                                <i class="fa fa-info-circle" aria-hidden="true"></i>
                                            </button>
                                        
                                        </h3>
                                        <ul>
                                            <li>
                                                <label>
                                                    <input type="checkbox" onclick="checkPerPerson('{{ $additional_service[0]->extra_price_person }}','service1','first_checkbox_div',{{ $additional_service[0]->extra_price_type }})" class="custom-control-input" id="service1"  name="additonal_service1" value="{{ $additional_service[0]->extra_price_name }}">
                                                    <i class="awe-icon awe-icon-check"></i>
                                                   {{ $additional_service[0]->extra_price_name }}  
                                                    (<?php if($additional_service[0]->extra_price_type == 0){
                                                            echo "One-Time";
                                                       } 
                                                
                                                        if($additional_service[0]->extra_price_type == 2){
                                                            echo "Per-Day";
                                                        }
                                                      
                                                    ?>)
                                                   <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$additional_service[0]->extra_price_price }}</span>
                                                </label>
                                                 <div id="first_checkbox_div">
                                                 </div>
                                            </li>
                                        @if(isset($additional_service_more))
                                         <?php $x= 2; ?>
                                            @foreach($additional_service_more as $service_res)
                                            <li>
                                                <label>
                                                    <input type="checkbox" id="chechbox{{ $x }}" onclick="checkPerPerson('{{ $service_res->more_extra_price_person }}','chechbox{{ $x }}','first_checkbox{{ $x }}',{{ $service_res->more_extra_price_type }})"  name="additonal_service[]" value="{{ $service_res->more_extra_price_title }}">
                                                    <i class="awe-icon awe-icon-check"></i>
                                                    {{ $service_res->more_extra_price_title }} 
                                                                (<?php if($service_res->more_extra_price_type == 0){
                                                                            echo "One-Time";
                                                                       } 
                                       
                                                                        if($service_res->more_extra_price_type == 2){
                                                                            echo "Per-Day";
                                                                        }
                                                                        
                                                                        
                                                                        
                                                                        
                                                                ?>) 
                                                    <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$service_res->more_extra_price_price }}</span>
                                                </label>
                                                <div id="first_checkbox{{ $x }}">
                                                                 
                                                </div>
                                            </li>
                                             <?php $x++; ?>
                                            @endforeach
                                        @endif
                                            
                                        </ul>
                                    </div>
                                     @endif  
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                               
                                
                                <div class="form-submit">
                                    <div class="add-to-cart">
                                        Select atleast one adult in order to proceed with your booking.
                                        <button type="button" data-bs-toggle="modal" data-bs-target="#booking_modal">
                                            <i class="awe-icon awe-icon-cart"></i>Add to Cart
                                        </button>
                                    </div>
                                </div>
                            </div>
                            </form>
                        </div>
            </div>
            
        </div>
        
           <section style="margin-bottom:5rem;">
                        <h5 class="m-3">You May Like</h5>
                        <div class="owl-carousel2 owl-theme mb-5">
                           
                            @if(isset($related_tour))
                                @foreach($related_tour as $toure_res)
                                <div class="item">
                                    <div class="card">
                                          <img src="{{ config('img_url1') }}/public/uploads/package_imgs/{{  $toure_res->tour_banner_image }}" style="min-height:137px;" class="card-img-top" alt="...">
                                          <div class="card-body">
                                             <div style="display:flex; flex-direction: column; justify-content:space-between;">
                                                 <div>
                                                      <a href="{{ URL::to('view_detail/'.$toure_res->id.'') }}" style="text-decoration:none;">
                                                        <h5 class="card-title" style="font-size:.8rem; font-weight: bold;">{{ Str::limit($toure_res->title, 30, ' ...') }}</h5>
                                                      </a>
                                                        <p class="card-text" style="font-size:12px;">
                                                            {{ Str::limit($tour_details->content, 50, ' ...') }}
                                                        </p>
                                                        <h6 style="font-size:.9rem">Price :{{ $toure_res->currency_symbol }} 
                                                                @if($toure_res->quad_grand_total_amount != 0 AND $toure_res->quad_grand_total_amount != null)
                                                                {{ $toure_res->quad_grand_total_amount }}
                                                                
                                                                @elseif($toure_res->triple_grand_total_amount != 0 AND $toure_res->triple_grand_total_amount != null) 
                                                                {{ $toure_res->triple_grand_total_amount }}
                                                                
                                                                @elseif($toure_res->double_grand_total_amount != 0 AND $toure_res->double_grand_total_amount != null) 
                                                                {{ $toure_res->double_grand_total_amount }}
                                                                @endif
                                                        </h6>
                                                </div> 
                                                <a href="{{ URL::to('view_detail/'.$toure_res->id.'') }}" class="awe-btn">Book now</a>
                                             </div>
                                          </div>
                                    </div>
                              
                                </div>
                                @endforeach 
                             @endif
                            </div>
                </section>
        
     
        
    </div>
    
    
</div>

        
        
             <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Cancellation Policy</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
              
                  <div class="modal-body">
                    
                       <p>{{ $tour_details->cancellation_policy }}</p>
                    
                  </div>
                  <div class="modal-footer">
                    
                  </div>
              
                </div>
              </div>
            </div>
            
            <div class="modal fade" id="booking_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Book Now</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
              
                  <div class="modal-body">
                    
                       
                      <form action="{{ route('add.to.cart1') }}" method="post">
                            @csrf
                            <div class="row">
                                <h6>Booking info</h6>
                                    
                                <div class="col-xl-6">
                                    
                                     <input type="text" name="pakage_type" hidden value="tour">
                                    <input type="text" hidden name="toure_id" value="{{ $tour_details->id }}">
                                    <input type="text" hidden name="request_from" value="website">
                                    
                                       <div class="form-label d-none custom-control custom-radio custom-control-inline" >
                                          <div class="row mt-2">
                                            <div class="col-md-12 mb-2 col-sm-6 form-kids">
                                                <input type="checkbox" class="custom-control-input" id="selectAgent" name="agent_select" value="agent_select">
                                                <label  class="custom-control-label" for="selectAgent">Book for Agent</span></label>
                                            </div>
                                            <div class="col-md-8 col-sm-6 form-kids agent_Name" style="display:none;">
                                                 <label class="form-label">Select Agent</label>
                                                 <select class="form-control"  id="" name="agent_Name">
                                                   <option value="-1">Choose...</option>
                                                    @if(isset($agents_list) && $agents_list !== null && $agents_list !== '')
                                                        @foreach($agents_list as $agents_list_res)
                                                            <option value="{{ $agents_list_res->id }}">{{ $agents_list_res->agent_Name }}</option>
                                                        @endforeach
                                                    @endif
                                                </select>
                                            </div>
                                            <div class="col-md-4 col-sm-6 form-kids agent_Name" style="display:none;">
                                                <input type="checkbox" class="custom-control-input mt-4" id="Agentinfo" name="agent_info" value="agent_select">
                                                <label  class="custom-control-label" for="Agentinfo">Display Agent info</span></label>
                                            </div>
                                            <div class="col-md-4 col-sm-6 form-kids agent_Name" style="display:none;">
                                                <label  class="custom-control-label" for="room1">Commission Type</label>
                                                 <select class="form-control" name="agent_commission_type" id="agent_commission_type">
                                                     <option value="amount">Number</option>
                                                     <option value="%">Percentage</option>
                                                 </select>
                                             </div>
                                            <div class="col-md-4 col-sm-6 form-kids agent_Name" style="display:none;">
                                                <label class="form-label agent_Name">Agent Commisson</label>
                                                
                                                <input type="number" step=".01" name="agent_commission" id="agent_commission_value" class="form-control">
                                            </div>
                                            <div class="col-md-4 col-sm-6 form-kids agent_Name" style="display:none;">
                                                <input type="checkbox" class="custom-control-input mt-4" id="AgentCommissioninfo" name="Agent_commission_info" value="Agent_commission_info">
                                                <label  class="custom-control-label" for="AgentCommissioninfo">Display Commission</span></label>
                                                
                                                <input type="checkbox" class="custom-control-input mt-4" id="add_commission" name="agent_commsion_add_total" value="add_commission">
                                                <label  class="custom-control-label" for="add_commission">Add Commission </span></label>
                                            </div>
                                           
                                            
                                        </div>
                                            
                                                      
                                        </div>
                                            
                                </div>
                                
                                <div class="col-xl-6">
                                    <div class="row ">
                               
                                        <div class="col-md-9 offset-md-3 col-sm-6 form-kids">
                                                    <h6 class="d-none">Sub Total: {{ $tour_details->currency_symbol }} <span id="subTotal_p"></span></h6>
                                                <input type="number" step=".01" hidden placeholder="Grand Total Amount" readonly id="subTotal" name="subTotal" class="form-control">
                                                
                                                <h6 class="d-none">Discount : {{ $tour_details->currency_symbol }} <span id="grandDiscount_p"></span></h6>
                                                <input type="number" step=".01" hidden placeholder="Grand Total Amount" hidden readonly id="grandDiscount" name="grandDiscount" class="form-control">
                                                
                                                <h3 class="agent_Name" style="display:none;">Agent Commisson : {{ $tour_details->currency_symbol }} <span id="agent_commsion_am_p"></span></h3>
                                                <input type="number" step=".01" hidden placeholder="Grand Total Amount" readonly id="agent_commsion_am" name="agent_commsion_am" class="agent_Name form-control">
            
                                                <h6 style="color:green;font-size:20px;">Total    : {{ $tour_details->currency_symbol }} <span id="finalGrandTotal_p"></span></h6>
                                                <input type="number" step=".01" hidden placeholder="Grand Total Amount"  readonly id="finalGrandTotal" name="grandTotalAmount" class="form-control">
                                                
                                                
                                        </div>
                                      
                                         <div class="col-md-9 col-sm-3 form-kids">
                                             
                                         </div>
                                       
                                         
                                    </div>
                                   
                                 
                                   
                                </div>
                                
                                
                                    
                              <input type="text" id="conversion_type" name="conversion_type" hidden value="<?php echo $tour_details->conversion_type ?>">
                              <input type="number" step=".01" readonly name="visa_actual_price_pack" id="visa_actual_price" hidden value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for triple"  class="form-control">
                                    
                                <div class="col-xl-12">
                                         
                                    <label><h6>Select Package</h6></label>
                                    <label><h6>Adult Prices</h6></label>
                                    <h6>Adult Prices</h6>
                                    @if($tour_details->double_grand_total_amount != 0 AND $tour_details->double_grand_total_amount != null) 
                                    
                                    <div class="form-label custom-control custom-radio custom-control-inline">
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 form-kids">
                                                <input type="checkbox"  class="custom-control-input" id="room1double" name="sharing[]" value="sharing2">
                                                <label title="If One(1), then will be shared with another person."  class="custom-control-label" for="room1double">Double Price <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span>{{ $tour_details->currency_symbol." ".$tour_details->double_grand_total_amount ?? '0' }}</span></label>
                                                <button class="btn btn-primary btn-sm d-none" type="button" onclick="editePrice('double_adult_price')">(Edit)</button>
                                                <input type="number" step=".01"  name="double_adult_price" style="padding: 0.3rem;border: #dfd9d9 1px solid;border-radius: 4px;" placeholder="Enter Rooms" value="{{$tour_details->double_grand_total_amount}}" id="double_adult_price" class="d-none edit-price">
            
                                            </div>
                                            <div class="col-md-4 col-sm-6 form-kids">
                                                <label  class="custom-control-label" for="room1">Rooms</label>
                                                <input type="number"   name="double_rooms" placeholder="Enter Rooms" id="double_rooms"  class="form-control form-control-sm">
                                                <input type="number" id="double_remaing_space" hidden>
                                            </div>
                                            <div class="col-md-4 col-sm-6 form-kids">
                                                <label  class="custom-control-label" for="room1">Adults</label>
                                                <input type="number"  name="double_adult" id="double_adult"  placeholder="Enter Adults for Double"  class="form-control form-control-sm">
                                            </div>
                                            
                                             <div class="col-md-4 col-sm-6 form-kids">
                                                <label  class="custom-control-label" for="room1">Total</label>
                                                <input type="number" step=".01"  name="double_adult_total_without_dic" id="double_adult_total_without_dic" hidden readonly placeholder="Total Amount" readonly class="form-control">                               
                                                <h6>{{ $tour_details->currency_symbol }} <span id="double_adult_total_without_dic_p"></span></h6>
                                                
                                            </div>
                                       
                                            <div class="col-md-2 col-sm-6 form-kids d-none">
                                                <label  class="custom-control-label" for="room1">Discount Type</label>
                                                 <select class="form-control" name="double_adult_discount_type" id="double_adult_discount_type">
                                                     <option value="amount">Number</option>
                                                     <!--<option value="%">Percentage</option>-->
                                                 </select>
                                             </div>
                                            <div class="col-md-2 col-sm-6 form-kids d-none">
                                                <label  class="custom-control-label" for="room1">Discount/PP</label>
                                                <input type="number" step=".01"  name="double_adult_disc" id="double_adult_disc"  placeholder="Enter Discount for Double"  class="form-control">
                                            </div>
                                            <div class="col-md-2 col-sm-6 form-kids d-none">
                                                <label  class="custom-control-label" for="room1">Discount/Total</label>
                                                <input type="number" step=".01"  name="double_adult_disc_total" id="double_adult_disc_total"  placeholder="Enter Discount for Double"  class="form-control">
                                            </div>
                                            <div class="col-md-2 col-sm-6 form-kids d-none">
                                                <label  class="custom-control-label" for="room1">Net Total </label>
                                                <input type="number" step=".01"  name="double_adult_total" id="double_adult_total" hidden readonly placeholder="Total Amount" readonly class="form-control">
                                                
                                                <h6> {{ $tour_details->currency_symbol }} <span id="double_adult_total_p"></span></h6>
                                            </div>
                                            
                                            
                                            <!--/////////////////////////-->
                                            <!--Visa Div-->
                                             <!--/////////////////////////-->
                                            <div class="col-md-12 mt-2 col-sm-6 form-kids d-none">
                                              
                                                <input type="checkbox"  class="custom-control-input" id="double_adult_visa_check" name="double_adult_visa_type[]" value="double_adult_visa_type">
                                                <label title=""  class="custom-control-label" for="double_adult_visa_check">Change Visa Type</label>
                                                 
                                             </div>
                                            <div class="col-md-2 col-sm-6 form-kids double_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">Select Visa Type</label>
                                                 <select class="form-control" name="double_adult_visa_type" id="double_adult_visa_type">
                                                     @isset($all_visa_types)
                                                        @foreach($all_visa_types as $visa_res)
                                                     <option value="{{ $visa_res->other_visa_type }}" @if($visa_res->other_visa_type == $tour_details->visa_type) selected @endif>{{ $visa_res->other_visa_type }}</option>
                                                        @endforeach
                                                     @endisset
                                                 </select>
                                             </div>
                                             
                                            <div class="col-md-2 col-sm-6 form-kids double_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">For Persons</label>
                                                <input type="number"  name="double_adult_visa_persons" id="double_adult_visa_persons"  placeholder="Enter Persons for Double"  class="form-control">
                                            </div>
                                            
                                        
                                            <div class="col-md-2 col-sm-6 form-kids double_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">Enter Purchase Rate</label>
                                                <input type="number" step=".01" name="visa_price_double_purc_rate" id="visa_price_double_purc_rate" value="{{ $tour_details->visa_fee_purchase }}"  placeholder="Enter Additional Price for Double"  class="form-control">
                                            </div>
                                            
                                            <div class="col-md-2 col-sm-6 form-kids double_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">Enter Exchange Rate</label>
                                                <input type="number" step=".01" name="visa_price_double_exchange_rate" id="visa_price_double_exchange_rate" value="{{ $tour_details->exchange_rate_visa }}"  placeholder="Enter Additional Price for Double"  class="form-control">
                                            </div>
                                            
                                            <div class="col-md-2 col-sm-6 form-kids double_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">Visa Fee</label>
                                                <input type="number" step=".01" readonly name="visa_actual_price" id="visa_actual_price" hidden value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for Double"  class="form-control">
                                                <input type="number" step=".01" readonly name="visa_actual_price_change" id="visa_actual_price_change" value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for Double"  class="form-control">
                                            </div>
                                            
                                            
                                        </div>
                                        
                                    </div>
                                     @endif
                                     @if($tour_details->triple_grand_total_amount != 0 AND $tour_details->triple_grand_total_amount != null) 
                                  
                                    <div class="form-label custom-control custom-radio custom-contANDol-inline">
                                        <div class="row">
                                            <div class="col-md-12 col-sm-4 form-kids">
                                                <input type="checkbox" class="custom-control-input" id="room2" name="sharing[]" value="sharing3">
                                                <label  title="If less than three(3), then will be shared with another person." class="custom-control-label" for="room2">Triple  Price <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$tour_details->triple_grand_total_amount ?? '0' }}</span></label>
                                                <button class="btn btn-primary btn-sm d-none" type="button" onclick="editePrice('triple_adult_price')">(Edit)</button>
                                                <input type="number" step=".01"  name="triple_adult_price"  placeholder="Enter Rooms" style="padding: 0.3rem;border: #dfd9d9 1px solid;border-radius: 4px;" value="{{$tour_details->triple_grand_total_amount}}" id="triple_adult_price" class="d-none edit-price">
                                            </div>
                                            <div class="col-md-4 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Rooms</label>-->
                                                <input type="number"   name="triple_rooms" placeholder="Enter Rooms" id="triple_rooms" class="form-control form-control-sm">
                                                <input type="number"  id="triple_remaing_space" hidden>
                                            </div>
                                            <div class="col-md-4 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Adults</label>-->
                                                <input type="number"   name="triple_adult" id="triple_adult" placeholder="Enter Adults for Triple"  class="form-control form-control-sm">
                                            </div>
                                            <div class="col-md-4 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Total</label>-->
                                                <input type="number" step=".01"  name="triple_adult_total_without_dic" id="triple_adult_total_without_dic" hidden readonly placeholder="Total Amount" readonly class="form-control">                               
                                                <h6>{{ $tour_details->currency_symbol }} <span id="triple_adult_total_without_dic_p"></span></h6>
                                            </div>
                                       
                                            <div class="col-md-2 col-sm-6 d-none form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Type</label>-->
                                                 <select class="form-control" name="triple_adult_discount_type" id="triple_adult_discount_type">
                                                     <option value="amount">Number</option>
                                                     <!--<option value="%">Percentage</option>-->
                                                 </select>
                                             </div>
                                            <div class="col-md-2 col-sm-6 d-none form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01"  name="triple_adult_disc" id="triple_adult_disc"  placeholder="Enter Discount for Triple"  class="form-control">
                                            </div>
                                             <div class="col-md-2 col-sm-6 d-none form-kids">
                                                <input type="number" step=".01"  name="triple_adult_disc_total" id="triple_adult_disc_total"  placeholder="Enter Discount for Triple"  class="form-control">
                                            </div>
                                            <div class="col-md-2 col-sm-6 d-none form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Net Total </label>-->
                                                <input type="number" step=".01"  name="triple_adult_total" id="triple_adult_total" hidden readonly placeholder="Total Amount" readonly class="form-control">
                                                
                                                <h6> {{ $tour_details->currency_symbol }} <span id="triple_adult_total_p"></span></h6>
                                            </div>
                                            
                                            
                                             <!--/////////////////////////-->
                                            <!--Visa Div-->
                                             <!--/////////////////////////-->
                                          <div class="col-md-12 mt-2 d-none col-sm-6 form-kids">
                                              
                                               <input type="checkbox"  class="custom-control-input" id="triple_adult_visa_check" name="triple_adult_visa_type[]" value="triple_adult_visa_type">
                                               <label title=""  class="custom-control-label" for="triple_adult_visa_check">Change Visa Type</label>
                                                
                                            </div>
                                            <div class="col-md-2 col-sm-6 form-kids triple_visa_change" style="display:none">
                                               <label  class="custom-control-label" for="room1">Select Visa Type</label>
                                                <select class="form-control" name="triple_adult_visa_type" id="triple_adult_visa_type">
                                                    @isset($all_visa_types)
                                                       @foreach($all_visa_types as $visa_res)
                                                    <option value="{{ $visa_res->other_visa_type }}" @if($visa_res->other_visa_type == $tour_details->visa_type) selected @endif>{{ $visa_res->other_visa_type }}</option>
                                                       @endforeach
                                                    @endisset
                                                </select>
                                            </div>
                                            
                                            <div class="col-md-2 col-sm-6 form-kids triple_visa_change" style="display:none">
                                               <label  class="custom-control-label" for="room1">For Persons</label>
                                               <input type="number"  name="triple_adult_visa_persons" id="triple_adult_visa_persons"  placeholder="Enter Persons for triple"  class="form-control">
                                            </div>
                                            
                                            
                                            <div class="col-md-2 col-sm-6 form-kids triple_visa_change" style="display:none">
                                               <label  class="custom-control-label" for="room1">Enter Purchase Rate</label>
                                               <input type="number" step=".01" name="visa_price_triple_purc_rate" id="visa_price_triple_purc_rate" value="{{ $tour_details->visa_fee_purchase }}"  placeholder="Enter Additional Price for triple"  class="form-control">
                                            </div>
                                            
                                            <div class="col-md-2 col-sm-6 form-kids triple_visa_change" style="display:none">
                                               <label  class="custom-control-label" for="room1">Enter Exchange Rate</label>
                                               <input type="number" step=".01" name="visa_price_triple_exchange_rate" id="visa_price_triple_exchange_rate" value="{{ $tour_details->exchange_rate_visa }}"  placeholder="Enter Additional Price for triple"  class="form-control">
                                            </div>
                                            
                                            <div class="col-md-2 col-sm-6 form-kids triple_visa_change" style="display:none">
                                               <label  class="custom-control-label" for="room1">Visa Fee</label>
                                               
                                               <input type="number" step=".01" name="visa_actual_price_change_triple" id="visa_actual_price_change_triple" value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for triple"  class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                     @endif
                                    @if($tour_details->quad_grand_total_amount != 0 AND $tour_details->quad_grand_total_amount != null) 
                                    
                                
                                    <div class="form-label custom-control custom-radio custom-control-inline">
                                          <div class="row">
                                            <div class="col-md-12 col-sm-6 form-kids">
                                                <input type="checkbox" class="custom-control-input" id="room3" name="sharing[]" value="sharing4">
                                                <label title="If less than four(4), then will be shared with another person." class="custom-control-label" for="room3">Quad  Price <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$tour_details->quad_grand_total_amount ?? '0' }}</span></label>
                                                <button class="btn btn-primary btn-sm d-none" type="button" onclick="editePrice('quad_adult_price')">(Edit)</button>
                                                <input type="number" step=".01"  name="quad_adult_price" style="padding: 0.3rem;border: #dfd9d9 1px solid;border-radius: 4px;"  value="{{$tour_details->quad_grand_total_amount}}" id="quad_adult_price" class="d-none edit-price">
            
                                            </div>
                                            <div class="col-md-4 col-sm-6 form-kids">
                                                <input type="number"   name="quad_rooms" placeholder="Enter Rooms" id="quad_rooms" class="form-control form-control-sm">
                                                 <input type="number"  id="quad_remaing_space" hidden>
                                            </div>
                                            <div class="col-md-4 col-sm-6 form-kids">
                                                <input type="number"   name="quad_adult" id="quad_adult" placeholder="Enter Adults for Quad"  class="form-control form-control-sm">
                                            </div>
                                               <div class="col-md-4 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Total</label>-->
                                                <input type="number" step=".01"  name="quad_adult_total_without_dic" id="quad_adult_total_without_dic" hidden readonly placeholder="Total Amount" readonly class="form-control">                               
                                                <h6>{{ $tour_details->currency_symbol }} <span id="quad_adult_total_without_dic_p"></span></h6>
                                            </div>
                                       
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Type</label>-->
                                                 <select class="form-control" name="quad_adult_discount_type" id="quad_adult_discount_type">
                                                     <option value="amount">Number</option>
                                                     <!--<option value="%">Percentage</option>-->
                                                 </select>
                                             </div>
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01"  name="quad_adult_disc" id="quad_adult_disc"  placeholder="Enter Discount for Triple"  class="form-control">
                                            </div>
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <input type="number" step=".01"  name="quad_adult_disc_total" id="quad_adult_disc_total"  placeholder="Enter Discount for Quad"  class="form-control">
                                            </div>
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Net Total </label>-->
                                                <input type="number" step=".01"  name="quad_adult_total" id="quad_adult_total" hidden readonly placeholder="Total Amount" readonly class="form-control">
                                                
                                                <h6> {{ $tour_details->currency_symbol }} <span id="quad_adult_total_p"></span></h6>
                                            </div>
                                            
                                            
                                             <!--/////////////////////////-->
                                            <!--Visa Div-->
                                             <!--/////////////////////////-->
                                             <div class="col-md-12 mt-2 d-none col-sm-6 form-kids">
                                              
                                                <input type="checkbox"  class="custom-control-input" id="quad_adult_visa_check" name="quad_adult_visa_type[]" value="quad_adult_visa_type">
                                                <label title=""  class="custom-control-label" for="quad_adult_visa_check">Change Visa Type</label>
                                                 
                                             </div>
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">Select Visa Type</label>
                                                 <select class="form-control" name="quad_adult_visa_type" id="quad_adult_visa_type">
                                                     @isset($all_visa_types)
                                                        @foreach($all_visa_types as $visa_res)
                                                     <option value="{{ $visa_res->other_visa_type }}" @if($visa_res->other_visa_type == $tour_details->visa_type) selected @endif>{{ $visa_res->other_visa_type }}</option>
                                                        @endforeach
                                                     @endisset
                                                 </select>
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">For Persons</label>
                                                <input type="number"  name="quad_adult_visa_persons" id="quad_adult_visa_persons"  placeholder="Enter Persons for quad"  class="form-control">
                                             </div>
                                             
                                             
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">Enter Purchase Rate</label>
                                                <input type="number" step=".01" name="visa_price_quad_purc_rate" id="visa_price_quad_purc_rate" value="{{ $tour_details->visa_fee_purchase }}"  placeholder="Enter Additional Price for quad"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">Enter Exchange Rate</label>
                                                <input type="number" step=".01" name="visa_price_quad_exchange_rate" id="visa_price_quad_exchange_rate" value="{{ $tour_details->exchange_rate_visa }}"  placeholder="Enter Additional Price for quad"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">Visa Fee</label>
                                                
                                                <input type="number" step=".01" name="visa_actual_price_change_quad" id="visa_actual_price_change_quad" value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for quad"  class="form-control">
                                             </div>
                                        </div>
                                    </div>
                                     @endif
                                     
                                      @if($tour_details->without_acc_sale_price != 0 AND $tour_details->without_acc_sale_price != null) 
                                    
                                
                                    <div class="form-label custom-control custom-radio custom-control-inline">
                                          <div class="row">
                                            <div class="col-md-12 col-sm-6 form-kids">
                                                <input type="checkbox" class="custom-control-input" id="room3" name="sharing[]" value="withoutacc">
                                                <label title="" class="custom-control-label" for="room3">Without Accomodation <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$tour_details->without_acc_sale_price ?? '0' }}</span></label>
                                                <button class="btn btn-primary btn-sm d-none" type="button" onclick="editePrice('without_acc_adult_price')">(Edit)</button>
                                                <input type="number" step=".01"  name="without_acc_adult_price" style="padding: 0.3rem;border: #dfd9d9 1px solid;border-radius: 4px;" placeholder="Enter Rooms" value="{{$tour_details->without_acc_sale_price}}" id="without_acc_adult_price" class="d-none edit-price">
                                            </div>
                                            <div class="col-md-8 col-sm-8 form-kids">
                                                <input type="number"   name="without_acc_adult" id="without_acc_adult" placeholder="Enter Adults Without Accomodation" class="form-control">
                                            </div>
                                            
                                             <div class="col-md-4 col-sm-4 form-kids">
                                                    <!--<label  class="custom-control-label" for="room1">Total</label>-->
                                                    <input type="number" step=".01"  name="without_acc_adult_total_without_dic" id="without_acc_adult_total_without_dic" hidden readonly placeholder="Total Amount" readonly class="form-control">                               
                                                <h6>{{ $tour_details->currency_symbol }} <span id="without_acc_adult_total_without_dic_p"></span></h6>
                                            </div>
                                       
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Type</label>-->
                                                 <select class="form-control" name="without_acc_adult_discount_type" id="without_acc_adult_discount_type">
                                                     <option value="amount">Number</option>
                                                     <!--<option value="%">Percentage</option>-->
                                                 </select>
                                             </div>
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01"  name="without_acc_adult_disc" id="without_acc_adult_disc"  placeholder="Enter Discount for Without Accomodation"  class="form-control">
                                            </div>
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <input type="number" step=".01"  name="without_acc_adult_disc_total" id="without_acc_adult_disc_total"  placeholder="Enter Discount for Quad"  class="form-control">
                                            </div>
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Net Total </label>-->
                                                <input type="number" step=".01"  name="without_acc_adult_total" id="without_acc_adult_total" hidden readonly placeholder="Total Amount" readonly class="form-control">
                                                
                                                <h4> {{ $tour_details->currency_symbol }} <span id="without_acc_adult_total_p"></span></h4>
                                            </div>
                                            
                                            <!--/////////////////////////-->
                                            <!--Visa Div-->
                                             <!--/////////////////////////-->
                                             <div class="col-md-12 d-none mt-2 mb-2 col-sm-6 form-kids">
                                              
                                                <input type="checkbox"  class="custom-control-input" id="without_acc_adult_visa_check" name="without_acc_adult_visa_type[]" value="without_acc_adult_visa_type">
                                                <label title=""  class="custom-control-label" for="without_acc_adult_visa_check">Change Visa Type</label>
                                                 
                                             </div>
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">Select Visa Type</label>
                                                 <select class="form-control" name="without_acc_adult_visa_type" id="without_acc_adult_visa_type">
                                                     @isset($all_visa_types)
                                                        @foreach($all_visa_types as $visa_res)
                                                     <option value="{{ $visa_res->other_visa_type }}" @if($visa_res->other_visa_type == $tour_details->visa_type) selected @endif>{{ $visa_res->other_visa_type }}</option>
                                                        @endforeach
                                                     @endisset
                                                 </select>
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">For Persons</label>
                                                <input type="number" name="without_acc_adult_visa_persons" id="without_acc_adult_visa_persons"  placeholder="Enter Persons for without_acc"  class="form-control">
                                             </div>
                                             
                                             
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">Enter Purchase Rate</label>
                                                <input type="number" step=".01" name="visa_price_without_acc_purc_rate" id="visa_price_without_acc_purc_rate" value="{{ $tour_details->visa_fee_purchase }}"  placeholder="Enter Additional Price for without_acc"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">Enter Exchange Rate</label>
                                                <input type="number" step=".01" name="visa_price_without_acc_exchange_rate" id="visa_price_without_acc_exchange_rate" value="{{ $tour_details->exchange_rate_visa }}"  placeholder="Enter Additional Price for without_acc"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change" style="display:none">
                                                <label  class="custom-control-label" for="room1">Visa Fee</label>
                                                
                                                <input type="number" step=".01" name="visa_actual_price_change_without_acc" id="visa_actual_price_change_without_acc" value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for without_acc"  class="form-control">
                                             </div>
                                    
                                            
                                           
                                        </div>
                                    </div>
                                     @endif
                                     
                                     
                                     
                                     
                                     <input type="text" name="child_price_cost" hidden value="{{ $tour_details->child_grand_total_cost_price }}">
                                     
                
                                </div>
                                <hr>
                                  <div class="row">
                               
                                    <div class="col-md-12 mb-2 col-sm-6 form-kids">
                                            <label class=""><h5>Child Price: {{ $tour_details->currency_symbol." ".$tour_details->child_grand_total_sale_price ?? '0' }}</h5></label>
                                            <button class="btn btn-primary btn-sm d-none" type="button" onclick="editePrice('without_acc_child_price')">(Edit)</button>
                                         <input type="text" name="child_price" style="padding: 0.3rem;border: #dfd9d9 1px solid;border-radius: 4px;" id="without_acc_child_price" class="d-none edit-price" value="{{ $tour_details->child_grand_total_sale_price }}">
                                    </div>
                                     <div class="col-md-8 col-sm-6 form-kids">
                                         <input type="number" placeholder="Enter no of Childs" id="without_acc_child" name="childs" class="form-control">
                                         
                                     </div>
                                     
                                   
                                       <div class="col-md-4 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Total</label>-->
                                            <input type="number" step=".01"  name="without_acc_child_total_without_dic" id="without_acc_child_total_without_dic" hidden readonly placeholder="Total Amount" readonly class="form-control">                               
                                            <h6>{{ $tour_details->currency_symbol }} <span id="without_acc_child_total_without_dic_p"></span></h6>
                                        </div>
                                   
                                        <div class="col-md-2 d-none col-sm-6 form-kids">
                                            <!--<label  class="custom-control-label" for="room1">Discount Type</label>-->
                                             <select class="form-control" name="without_acc_child_discount_type" id="without_acc_child_discount_type">
                                                 <option value="amount">Number</option>
                                                 <!--<option value="%">Percentage</option>-->
                                             </select>
                                         </div>
                                        <div class="col-md-2 d-none col-sm-6 form-kids">
                                            <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                            <input type="number" step=".01"  name="without_acc_child_disc" id="without_acc_child_disc"  placeholder="Enter Discount for Without Accomodation"  class="form-control">
                                        </div>
                                        <div class="col-md-2 d-none col-sm-6 form-kids">
                                            <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                            <input type="number" step=".01"  name="without_acc_child_disc_total" id="without_acc_child_disc_total"  placeholder="Enter Discount for Without Accomodation"  class="form-control">
                                        </div>
                                        <div class="col-md-2 d-none col-sm-6 form-kids">
                                            <!--<label  class="custom-control-label" for="room1">Net Total </label>-->
                                            <input type="number" step=".01"  name="without_acc_child_total" id="without_acc_child_total" hidden readonly placeholder="Total Amount" readonly class="form-control">
                                            
                                            <h4> {{ $tour_details->currency_symbol }} <span id="without_acc_child_total_p"></span></h4>
                                        </div>
                                        
                                         <!--/////////////////////////-->
                                            <!--Visa Div-->
                                             <!--/////////////////////////-->
                                             <div class="col-md-12 d-none mt-2 mb-2 col-sm-6 form-kids">
                                              
                                                <input type="checkbox"   class="custom-control-input" id="without_acc_child_visa_check" name="without_acc_child_visa_type[]" value="without_acc_child_visa_type">
                                                <label title=""  class="custom-control-label" for="without_acc_child_visa_check">Change Visa Type</label>
                                                 
                                             </div>
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Select Visa Type</label>
                                                 <select class="form-control" name="without_acc_child_visa_type" id="without_acc_child_visa_type">
                                                     @isset($all_visa_types)
                                                        @foreach($all_visa_types as $visa_res)
                                                     <option value="{{ $visa_res->other_visa_type }}" @if($visa_res->other_visa_type == $tour_details->visa_type) selected @endif>{{ $visa_res->other_visa_type }}</option>
                                                        @endforeach
                                                     @endisset
                                                 </select>
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">For Persons</label>
                                                <input type="number"  name="without_acc_child_visa_persons" id="without_acc_child_visa_persons"  placeholder="Enter Persons for without_acc"  class="form-control">
                                             </div>
                                             
                                             
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Purchase Rate</label>
                                                <input type="number" step=".01" name="visa_price_without_acc_child_purc_rate" id="visa_price_without_acc_child_purc_rate" value="{{ $tour_details->visa_fee_purchase }}"  placeholder="Enter Additional Price for without_acc"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Exchange Rate</label>
                                                <input type="number" step=".01" name="visa_price_without_acc_child_exchange_rate" id="visa_price_without_acc_child_exchange_rate" value="{{ $tour_details->exchange_rate_visa }}"  placeholder="Enter Additional Price for without_acc"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Visa Fee</label>
                                                
                                                <input type="number" step=".01" name="visa_actual_price_change_without_acc_child" id="visa_actual_price_change_without_acc_child" value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for without_acc"  class="form-control">
                                             </div>
                                </div>
                                
                                  <label><h5>Child Prices with Accomodation</h5></label>
                                  
                                  @if(isset($flights_details) && !empty($flights_details))
                                    <?php 
                                       
                                        
                                        $flight_price_adult = $flights_details->flights_per_person_price;
                                         
                                        
                                        
                                    ?>
                                    
                                  @endif
                                    @if($tour_details->double_grand_total_amount != 0 AND $tour_details->double_grand_total_amount != null) 
                                    <?php
                                        // echo "adult flight $flight_price_adult child ".$tour_details->child_flight_cost_price;
                                        $child_double_price = ($tour_details->double_grand_total_amount - $flight_price_adult) + $tour_details->child_flight_cost_price;
                                        
                                        $child_double_arr = ['type'=>'double','price'=>$child_double_price];
                                        // echo " $child_double_price";
                                    ?>
                                    
                                    <div class="form-label custom-control custom-radio custom-control-inline">
                                        <div class="row">
                                            <div class="col-md-12 mb-2 col-sm-4 form-kids">
                                                <input type="checkbox"  class="custom-control-input" id="childroom1" disabled name="sharingchild[]" value='<?php echo json_encode($child_double_arr); ?>'>
                                                <label title="If One(1), then will be shared with another person."  class="custom-control-label" for="childroom1">Double Price <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span>{{ $tour_details->currency_symbol." ".$child_double_price ?? '0' }}</span></label>
                                                <button class="btn btn-primary btn-sm d-none" type="button" onclick="editePrice('double_child_price')">(Edit)</button>
                                                <input type="text" name="double_child_price" style="padding: 0.3rem;border: #dfd9d9 1px solid;border-radius: 4px;" id="double_child_price" class="d-none edit-price" value="{{ $child_double_price }}">
                                            </div>
                                            
                                            <div class="col-md-8 col-sm-6 form-kids">
                                                <input type="number"  name="double_child" id="double_acc_child" style="display:none;" placeholder="Enter Childs for Double"  class="form-control double_child">
                                                <input type="number"  name="" id="double_acc_child_prev" style="display:none;" placeholder="Enter Childs for Double"  class="form-control">
            
                                            </div>
                                            
                                            <div class="col-md-4 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Total</label>-->
                                                <input type="number" step=".01"  name="double_child_total_without_dic" id="double_child_total_without_dic" hidden readonly placeholder="Total Amount" readonly class=" form-control">                               
                                                <h6 style="display:none;" class="double_child">{{ $tour_details->currency_symbol }} <span id="double_child_total_without_dic_p"></span></h6>
                                                
                                            </div>
                                       
                                            <div class="col-md-2 col-sm-6 d-none form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Type</label>-->
                                                 <select style="display:none;" class="form-control " name="double_child_discount_type" id="double_child_discount_type">
                                                     <option value="amount">Number</option>
                                                     <!--<option value="%">Percentage</option>-->
                                                 </select>
                                             </div>
                                            <div class="col-md-2 col-sm-6 d-none form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01" style="display:none;" name="double_child_disc" id="double_child_disc"  placeholder="Enter Discount for Double"  class="form-control ">
                                            </div>
                                            <div class="col-md-2 col-sm-6 d-none form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01" style="display:none;" name="double_child_disc_total" id="double_child_disc_total"  placeholder="Enter Discount for Double"  class="form-control ">
                                            </div>
                                            <div class="col-md-2 col-sm-6 d-none form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Net Total </label>-->
                                                <input type="number" step=".01"  name="double_child_total" id="double_child_total" hidden readonly placeholder="Total Amount" readonly class="form-control">
                                                
                                                <h4 style="display:none" class=""> {{ $tour_details->currency_symbol }} <span id="double_child_total_p"></span></h4>
                                            </div>
                                            
                                            <!--/////////////////////////-->
                                            <!--Visa Div-->
                                             <!--/////////////////////////-->
                                             <div class="col-md-12 d-none mt-2 mb-2 col-sm-6 form-kids">
                                              
                                                <input type="checkbox"  class="custom-control-input" id="double_child_visa_check" name="double_child_visa_type[]" value="double_child_visa_type">
                                                <label title=""  class="custom-control-label" for="double_child_visa_check">Change Visa Type</label>
                                                 
                                             </div>
                                             <div class="col-md-2 col-sm-6 form-kids double_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Select Visa Type</label>
                                                 <select class="form-control" name="double_child_visa_type" id="double_child_visa_type">
                                                     @isset($all_visa_types)
                                                        @foreach($all_visa_types as $visa_res)
                                                     <option value="{{ $visa_res->other_visa_type }}" @if($visa_res->other_visa_type == $tour_details->visa_type) selected @endif>{{ $visa_res->other_visa_type }}</option>
                                                        @endforeach
                                                     @endisset
                                                 </select>
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids double_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">For Persons</label>
                                                <input type="number"  name="double_child_visa_persons" id="double_child_visa_persons"  placeholder="Enter Persons for double"  class="form-control">
                                             </div>
                                             
                                             
                                             <div class="col-md-2 col-sm-6 form-kids double_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Purchase Rate</label>
                                                <input type="number" step=".01" name="visa_price_double_child_purc_rate" id="visa_price_double_child_purc_rate" value="{{ $tour_details->visa_fee_purchase }}"  placeholder="Enter Additional Price for double"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids double_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Exchange Rate</label>
                                                <input type="number" step=".01" name="visa_price_double_child_exchange_rate" id="visa_price_double_child_exchange_rate" value="{{ $tour_details->exchange_rate_visa }}"  placeholder="Enter Additional Price for double"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids double_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Visa Fee</label>
                                                
                                                <input type="number" step=".01" name="visa_actual_price_change_double_child" id="visa_actual_price_change_double_child" value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for double"  class="form-control">
                                             </div>
                                        </div>
                                        
                                    </div>
                                     @endif
                                     @if($tour_details->triple_grand_total_amount != 0 AND $tour_details->triple_grand_total_amount != null) 
                                    <?php
                                        // echo "adult flight $flight_price_adult child ".$tour_details->child_flight_cost_price;
                                        $child_triple_price = ($tour_details->triple_grand_total_amount - $flight_price_adult) + $tour_details->child_flight_cost_price;
                                        // echo " $child_triple_price";
                                         $child_triple_arr = ['type'=>'triple','price'=>$child_triple_price];
                                    ?>
                                    <div class="form-label custom-control custom-radio custom-contANDol-inline">
                                        <div class="row">
                                            <div class="col-md-12 mb-2 col-sm-4 form-kids">
                                                <input type="checkbox" class="custom-control-input" id="childroom2" disabled name="sharingchild[]" value='<?php echo json_encode($child_triple_arr); ?>'>
                                                <label  title="If less than three(3), then will be shared with another person." class="custom-control-label" for="childroom2">Triple  Price <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$child_triple_price ?? '0' }}</span></label>
                                                 <button class="btn btn-primary btn-sm d-none" type="button" onclick="editePrice('triple_child_price')">(Edit)</button>
                                                 <input type="text" name="triple_child_price" id="triple_child_price" style="padding: 0.3rem;border: #dfd9d9 1px solid;border-radius: 4px;" class="d-none edit-price" value="{{ $child_triple_price }}">
                                            </div>
                                           
                                            <div class="col-md-8 col-sm-6 form-kids">
                                                <input type="number"  name="triple_child" id="triple_acc_child" style="display:none;" placeholder="Enter Childs for Triple"  class="form-control triple_child">
                                                
                                                <input type="number" step=".01"  name="" id="triple_acc_child_prev" style="display:none;" placeholder="Enter Childs for Double"  class="form-control">
                                            </div>
                                            
                                             <div class="col-md-4  col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Total</label>-->
                                                <input type="number" step=".01"  name="triple_child_total_without_dic" id="triple_child_total_without_dic" hidden readonly placeholder="Total Amount" readonly class=" form-control">                               
                                                <h6 style="display:none;" class="triple_child">{{ $tour_details->currency_symbol }} <span id="triple_child_total_without_dic_p"></span></h6>
                                                
                                            </div>
                                       
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Type</label>-->
                                                 <select style="display:none;" class="form-control " name="triple_child_discount_type" id="triple_child_discount_type">
                                                     <option value="amount">Number</option>
                                                     <!--<option value="%">Percentage</option>-->
                                                 </select>
                                             </div>
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01" style="display:none;" name="triple_child_disc" id="triple_child_disc"  placeholder="Enter Discount for Double"  class="form-control ">
                                            </div>
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01" style="display:none;" name="triple_child_disc_total" id="triple_child_disc_total"  placeholder="Enter Discount for Double"  class="form-control ">
                                            </div>
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Net Total </label>-->
                                                <input type="number" step=".01"  name="triple_child_total" id="triple_child_total" hidden readonly placeholder="Total Amount" readonly class="form-control">
                                                
                                                <h4 style="display:none" class=""> {{ $tour_details->currency_symbol }} <span id="triple_child_total_p"></span></h4>
                                            </div>
                                            
                                            
                                             <!--/////////////////////////-->
                                            <!--Visa Div-->
                                             <!--/////////////////////////-->
                                             <div class="col-md-12 d-none mt-2 mb-2 col-sm-6 form-kids">
                                              
                                                <input type="checkbox"  class="custom-control-input" id="triple_child_visa_check" name="triple_child_visa_type[]" value="triple_child_visa_type">
                                                <label title=""  class="custom-control-label" for="triple_child_visa_check">Change Visa Type</label>
                                                 
                                             </div>
                                             <div class="col-md-2 col-sm-6 form-kids triple_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Select Visa Type</label>
                                                 <select class="form-control" name="triple_child_visa_type" id="triple_child_visa_type">
                                                     @isset($all_visa_types)
                                                        @foreach($all_visa_types as $visa_res)
                                                     <option value="{{ $visa_res->other_visa_type }}" @if($visa_res->other_visa_type == $tour_details->visa_type) selected @endif>{{ $visa_res->other_visa_type }}</option>
                                                        @endforeach
                                                     @endisset
                                                 </select>
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids triple_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">For Persons</label>
                                                <input type="number"  name="triple_child_visa_persons" id="triple_child_visa_persons"  placeholder="Enter Persons for triple"  class="form-control">
                                             </div>
                                             
                                             
                                             <div class="col-md-2 col-sm-6 form-kids triple_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Purchase Rate</label>
                                                <input type="number" step=".01" name="visa_price_triple_child_purc_rate" id="visa_price_triple_child_purc_rate" value="{{ $tour_details->visa_fee_purchase }}"  placeholder="Enter Additional Price for triple"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids triple_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Exchange Rate</label>
                                                <input type="number" step=".01" name="visa_price_triple_child_exchange_rate" id="visa_price_triple_child_exchange_rate" value="{{ $tour_details->exchange_rate_visa }}"  placeholder="Enter Additional Price for triple"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids triple_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Visa Fee</label>
                                                
                                                <input type="number" step=".01" name="visa_actual_price_change_triple_child" id="visa_actual_price_change_triple_child" value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for triple"  class="form-control">
                                             </div>
                                        </div>
                                    </div>
                                     @endif
                                    @if($tour_details->quad_grand_total_amount != 0 AND $tour_details->quad_grand_total_amount != null) 
                                    <?php
                                        // echo "adult flight $flight_price_adult child ".$tour_details->child_flight_cost_price;
                                        $child_quad_price = ($tour_details->quad_grand_total_amount - $flight_price_adult) + $tour_details->child_flight_cost_price;
                                        // echo " $child_quad_price";
                                         $child_quad_arr = ['type'=>'quad','price'=>$child_quad_price];
                                    ?>
                                
                                    <div class="form-label custom-control custom-radio custom-control-inline">
                                          <div class="row">
                                            <div class="col-md-12 mb-2 col-sm-6 form-kids">
                                                <input type="checkbox" class="custom-control-input" id="childroom3" disabled name="sharingchild[]" value='<?php echo json_encode($child_quad_arr) ?>'>
                                                <label title="If less than four(4), then will be shared with another person." class="custom-control-label" for="childroom3">Quad  Price <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$child_quad_price ?? '0' }}</span></label>
                                                <button class="btn btn-primary d-none btn-sm" type="button" onclick="editePrice('quad_child_price')">(Edit)</button>
                                                <input type="text" name="quad_child_price" id="quad_child_price" style="padding: 0.3rem;border: #dfd9d9 1px solid;border-radius: 4px;" class="d-none edit-price" value="{{ $child_quad_price }}">
                                            </div>
                                            
                                            <div class="col-md-8 col-sm-6 form-kids">
                                                <input type="number"  name="quad_child" id="quad_acc_child" style="display:none;" placeholder="Enter Childs for Quad"  class="form-control quad_child">
                                             
                                                <input type="number" step=".01"  name="" id="quad_acc_child_prev" style="display:none;" placeholder="Enter Childs for Double"  class="form-control">
                                           
                                            </div>
                                            
                                            <div class="col-md-4 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Total</label>-->
                                                <input type="number" step=".01"  name="quad_child_total_without_dic" id="quad_child_total_without_dic" hidden readonly placeholder="Total Amount" readonly class=" form-control">                               
                                                <h6 style="display:none;" class="quad_child">{{ $tour_details->currency_symbol }} <span id="quad_child_total_without_dic_p"></span></h6>
                                                
                                            </div>
                                       
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Type</label>-->
                                                 <select style="display:none;" class="form-control " name="quad_child_discount_type" id="quad_child_discount_type">
                                                     <option value="amount">Number</option>
                                                     <!--<option value="%">Percentage</option>-->
                                                 </select>
                                             </div>
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01" style="display:none;" name="quad_child_disc" id="quad_child_disc"  placeholder="Enter Discount for Double"  class="form-control ">
                                            </div>
                                             <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01" style="display:none;" name="quad_child_disc_total" id="quad_child_disc_total"  placeholder="Enter Discount for Double"  class="form-control ">
                                            </div>
                                            <div class="col-md-2 d-none col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Net Total </label>-->
                                                <input type="number" step=".01"  name="quad_child_total" id="quad_child_total" hidden readonly placeholder="Total Amount" readonly class="form-control">
                                                
                                                <h4 style="display:none" class=""> {{ $tour_details->currency_symbol }} <span id="quad_child_total_p"></span></h4>
                                            </div>
                                            
                                                <!--/////////////////////////-->
                                            <!--Visa Div-->
                                             <!--/////////////////////////-->
                                             <div class="col-md-12 d-none mt-2 mb-2 col-sm-6 form-kids">
                                              
                                                <input type="checkbox"  class="custom-control-input" id="quad_child_visa_check" name="quad_child_visa_type[]" value="quad_child_visa_type">
                                                <label title=""  class="custom-control-label" for="quad_child_visa_check">Change Visa Type</label>
                                                 
                                             </div>
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Select Visa Type</label>
                                                 <select class="form-control" name="quad_child_visa_type" id="quad_child_visa_type">
                                                     @isset($all_visa_types)
                                                        @foreach($all_visa_types as $visa_res)
                                                     <option value="{{ $visa_res->other_visa_type }}" @if($visa_res->other_visa_type == $tour_details->visa_type) selected @endif>{{ $visa_res->other_visa_type }}</option>
                                                        @endforeach
                                                     @endisset
                                                 </select>
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">For Persons</label>
                                                <input type="number"  name="quad_child_visa_persons" id="quad_child_visa_persons"  placeholder="Enter Persons for quad"  class="form-control">
                                             </div>
                                             
                                             
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Purchase Rate</label>
                                                <input type="number" step=".01" name="visa_price_quad_child_purc_rate" id="visa_price_quad_child_purc_rate" value="{{ $tour_details->visa_fee_purchase }}"  placeholder="Enter Additional Price for quad"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Exchange Rate</label>
                                                <input type="number" step=".01" name="visa_price_quad_child_exchange_rate" id="visa_price_quad_child_exchange_rate" value="{{ $tour_details->exchange_rate_visa }}"  placeholder="Enter Additional Price for quad"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change_child" style="display:none">
                                                <label  class="custom-control-label" for="room1">Visa Fee</label>
                                                
                                                <input type="number" step=".01" name="visa_actual_price_change_quad_child" id="visa_actual_price_change_quad_child" value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for quad"  class="form-control">
                                             </div>
                                        </div>
                                    </div>
                                     @endif
                                     
                                   
                                      
                                     <input type="text" name="infant_price_cost" hidden value="{{ $tour_details->infant_total_cost_price }}">
                                     
                
                                </div>
                                <hr>
                                  <div class="row">
                               
                                    <div class="col-md-12 mb-2 col-sm-6 form-kids">
                                            <label class=""><h6>Infant Price: {{ $tour_details->currency_symbol." ".$tour_details->infant_total_sale_price ?? '0' }}</h6></label>
                                            <button class="btn btn-primary btn-sm d-none" type="button" onclick="editePrice('without_acc_infant_price')">(Edit)</button>
                                            <input type="text" name="infant_price" id="without_acc_infant_price" style="padding: 0.3rem;border: #dfd9d9 1px solid;border-radius: 4px;" class="d-none edit-price" value="{{ $tour_details->infant_total_sale_price }}">
            
                                    </div>
                                    <div class="col-md-8 col-sm-6 form-kids">
                                         <input type="number" placeholder="Enter no of Infants" id="without_acc_infant"  name="Infants" class="form-control">
                                    </div>
                                     
                                    <div class="col-md-4 col-sm-6 form-kids">
                                            <!--<label  class="custom-control-label" for="room1">Total</label>-->
                                        <input type="number" step=".01"  name="without_acc_infant_total_without_dic" id="without_acc_infant_total_without_dic" hidden readonly placeholder="Total Amount" readonly class="form-control">                               
                                        <h6>{{ $tour_details->currency_symbol }} <span id="without_acc_infant_total_without_dic_p"></span></h6>
                                    </div>
                               
                                    <div class="col-md-2 d-none col-sm-6 form-kids">
                                        <!--<label  class="custom-control-label" for="room1">Discount Type</label>-->
                                         <select class="form-control" name="without_acc_infant_discount_type" id="without_acc_infant_discount_type">
                                             <option value="amount">Number</option>
                                             <!--<option value="%">Percentage</option>-->
                                         </select>
                                     </div>
                                    <div class="col-md-2 d-none col-sm-6 form-kids">
                                        <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                        <input type="number" step=".01"  name="without_acc_infant_disc" id="without_acc_infant_disc"  placeholder="Enter Discount for Without Accomodation"  class="form-control">
                                    </div>
                                    <div class="col-md-2 d-none col-sm-6 form-kids">
                                        <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                        <input type="number" step=".01"  name="without_acc_infant_disc_total" id="without_acc_infant_disc_total"  placeholder="Enter Discount for Without Accomodation"  class="form-control">
                                    </div>
                                    <div class="col-md-2 d-none col-sm-6 form-kids">
                                        <!--<label  class="custom-control-label" for="room1">Net Total </label>-->
                                        <input type="number" step=".01"  name="without_acc_infant_total" id="without_acc_infant_total" hidden readonly placeholder="Total Amount" readonly class="form-control">
                                        
                                        <h4> {{ $tour_details->currency_symbol }} <span id="without_acc_infant_total_p"></span></h4>
                                    </div>
                                    
                                  
                                           <!--/////////////////////////-->
                                            <!--Visa Div-->
                                             <!--/////////////////////////-->
                                             <div class="col-md-12 d-none mt-2 mb-2 col-sm-6 form-kids">
                                              
                                                <input type="checkbox"  class="custom-control-input" id="without_acc_infant_visa_check" name="without_acc_infant_visa_type[]" value="without_acc_infant_visa_type">
                                                <label title=""  class="custom-control-label" for="without_acc_infant_visa_check">Change Visa Type</label>
                                                 
                                             </div>
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Select Visa Type</label>
                                                 <select class="form-control" name="without_acc_infant_visa_type" id="without_acc_infant_visa_type">
                                                     @isset($all_visa_types)
                                                        @foreach($all_visa_types as $visa_res)
                                                     <option value="{{ $visa_res->other_visa_type }}" @if($visa_res->other_visa_type == $tour_details->visa_type) selected @endif>{{ $visa_res->other_visa_type }}</option>
                                                        @endforeach
                                                     @endisset
                                                 </select>
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">For Persons</label>
                                                <input type="number"  name="without_acc_infant_visa_persons" id="without_acc_infant_visa_persons"  placeholder="Enter Persons for without_acc"  class="form-control">
                                             </div>
                                             
                                             
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Purchase Rate</label>
                                                <input type="number" step=".01" name="visa_price_without_acc_infant_purc_rate" id="visa_price_without_acc_infant_purc_rate" value="{{ $tour_details->visa_fee_purchase }}"  placeholder="Enter Additional Price for without_acc"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Exchange Rate</label>
                                                <input type="number" step=".01" name="visa_price_without_acc_infant_exchange_rate" id="visa_price_without_acc_infant_exchange_rate" value="{{ $tour_details->exchange_rate_visa }}"  placeholder="Enter Additional Price for without_acc"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids without_acc_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Visa Fee</label>
                                                
                                                <input type="number" step=".01" name="visa_actual_price_change_without_acc_infant" id="visa_actual_price_change_without_acc_infant" value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for without_acc"  class="form-control">
                                             </div>
                                     
                                 </div>
                                
                                  <label><h5>Infant Prices with Accomodation</h5></label>
                                  
                                  @if(isset($flights_details) && !empty($flights_details))
                                    <?php 
                                       
                                        
                                        $flight_price_adult = $flights_details->flights_per_person_price;
                                         
                                        
                                        
                                    ?>
                                    
                                  @endif
                                    @if($tour_details->double_grand_total_amount != 0 AND $tour_details->double_grand_total_amount != null) 
                                    <?php
                                        // echo "adult flight $flight_price_adult Infant ".$tour_details->infant_flight_cost;
                                        $infant_double_price = ($tour_details->double_grand_total_amount - $flight_price_adult) + $tour_details->infant_flight_cost;
                                        
                                        $infant_double_arr = ['type'=>'double','price'=>$infant_double_price];
                                        // echo " $child_double_price";
                                    ?>
                                    
                                    <div class="form-label custom-control custom-radio custom-control-inline">
                                        <div class="row">
                                            <div class="col-md-12 mb-2 col-sm-4 form-kids">
                                                <input type="checkbox"  class="custom-control-input" id="infantroom1" disabled name="sharingInfant[]" value='<?php echo json_encode($infant_double_arr); ?>'>
                                                <label title="If One(1), then will be shared with another person."  class="custom-control-label" for="infantroom1">Double Price <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span>{{ $tour_details->currency_symbol." ".$infant_double_price ?? '0' }}</span></label>
                                                <button class="btn btn-primary btn-sm d-none" type="button" onclick="editePrice('double_infant_price')">(Edit)</button>
                                                <input type="text" name="double_infant_price" style="padding: 0.3rem;border: #dfd9d9 1px solid;border-radius: 4px;" id="double_infant_price" class="d-none edit-price" value="{{ $infant_double_price }}">
            
                                            </div>
                                            
                                            <div class="col-md-8 col-sm-6 form-kids">
                                                <input type="number"  name="double_infant" id="double_acc_infant" style="display:none;" placeholder="Enter Infants for Double"  class="form-control double_infant">
                                                <input type="number" step=".01"  name="" id="infant_acc_child_prev" style="display:none;" placeholder="Enter Infants for Double"  class="form-control">
            
                                                
                                            </div>
                                            
                                       
                                            
                                            <div class="col-md-4 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Total</label>-->
                                                <input type="number" step=".01"  name="double_infant_total_without_dic" id="double_infant_total_without_dic" hidden readonly placeholder="Total Amount" readonly class=" form-control">                               
                                                <h6 style="display:none;" class="double_infant">{{ $tour_details->currency_symbol }} <span id="double_infant_total_without_dic_p"></span></h6>
                                                
                                            </div>
                                       
                                            <div class="col-md-2 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Type</label>-->
                                                 <select style="display:none;" class="form-control" name="double_infant_discount_type" id="double_infant_discount_type">
                                                     <option value="amount">Number</option>
                                                     <!--<option value="%">Percentage</option>-->
                                                 </select>
                                             </div>
                                            <div class="col-md-2 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01" style="display:none;" name="double_infant_disc" id="double_infant_disc"  placeholder="Enter Discount for Double"  class="form-control ">
                                            </div>
                                             <div class="col-md-2 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01" style="display:none;" name="double_infant_disc_total" id="double_infant_disc_total"  placeholder="Enter Discount for Double"  class="form-control ">
                                            </div>
                                            <div class="col-md-2 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Net Total </label>-->
                                                <input type="number" step=".01"  name="double_infant_total" id="double_infant_total" hidden readonly placeholder="Total Amount" readonly class="form-control">
                                                
                                                <h4 style="display:none" class=""> {{ $tour_details->currency_symbol }} <span id="double_infant_total_p"></span></h4>
                                            </div>
                                            
                                            
                                             <!--/////////////////////////-->
                                            <!--Visa Div-->
                                             <!--/////////////////////////-->
                                             <div class="col-md-12 mt-2 d-none mb-2 col-sm-6 form-kids">
                                              
                                                <input type="checkbox"  class="custom-control-input" id="double_infant_visa_check" name="double_infant_visa_type[]" value="double_infant_visa_type">
                                                <label title=""  class="custom-control-label" for="double_infant_visa_check">Change Visa Type</label>
                                                 
                                             </div>
                                             <div class="col-md-2 col-sm-6 form-kids double_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Select Visa Type</label>
                                                 <select class="form-control" name="double_infant_visa_type" id="double_infant_visa_type">
                                                     @isset($all_visa_types)
                                                        @foreach($all_visa_types as $visa_res)
                                                     <option value="{{ $visa_res->other_visa_type }}" @if($visa_res->other_visa_type == $tour_details->visa_type) selected @endif>{{ $visa_res->other_visa_type }}</option>
                                                        @endforeach
                                                     @endisset
                                                 </select>
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids double_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">For Persons</label>
                                                <input type="number"  name="double_infant_visa_persons" id="double_infant_visa_persons"  placeholder="Enter Persons for double"  class="form-control">
                                             </div>
                                             
                                             
                                             <div class="col-md-2 col-sm-6 form-kids double_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Purchase Rate</label>
                                                <input type="number" step=".01" name="visa_price_double_infant_purc_rate" id="visa_price_double_infant_purc_rate" value="{{ $tour_details->visa_fee_purchase }}"  placeholder="Enter Additional Price for double"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids double_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Exchange Rate</label>
                                                <input type="number" step=".01" name="visa_price_double_infant_exchange_rate" id="visa_price_double_infant_exchange_rate" value="{{ $tour_details->exchange_rate_visa }}"  placeholder="Enter Additional Price for double"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids double_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Visa Fee</label>
                                                
                                                <input type="number" step=".01" name="visa_actual_price_change_double_infant" id="visa_actual_price_change_double_infant" value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for double"  class="form-control">
                                             </div>
                                             
                                               
                                        </div>
                                        
                                    </div>
                                     @endif
                                     @if($tour_details->triple_grand_total_amount != 0 AND $tour_details->triple_grand_total_amount != null) 
                                    <?php
                                        // echo "adult flight $flight_price_adult Infant ".$tour_details->infant_flight_cost;
                                        $infant_triple_price = ($tour_details->triple_grand_total_amount - $flight_price_adult) + $tour_details->infant_flight_cost;
                                        // echo " $infant_triple_price";
                                         $infant_triple_arr = ['type'=>'triple','price'=>$infant_triple_price];
                                    ?>
                                    <div class="form-label custom-control custom-radio custom-contANDol-inline">
                                        <div class="row">
                                            <div class="col-md-12 mb-2 col-sm-4 form-kids">
                                                <input type="checkbox" class="custom-control-input" id="infantroom2" disabled name="sharingInfant[]" value='<?php echo json_encode($infant_triple_arr); ?>'>
                                                <label  title="If less than three(3), then will be shared with another person." class="custom-control-label" for="infantroom2">Triple  Price <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$infant_triple_price ?? '0' }}</span></label>
                                                <button class="btn btn-primary d-none btn-sm" type="button" onclick="editePrice('triple_infant_price')">(Edit)</button>
                                                <input type="text" name="triple_infant_price" id="triple_infant_price" style="padding: 0.3rem;border: #dfd9d9 1px solid;border-radius: 4px;" class="d-none edit-price" value="{{ $infant_triple_price }}">
                                            </div>
                                           
                                            <div class="col-md-8 col-sm-6 form-kids">
                                                <input type="number" name="triple_infant" id="triple_acc_infant" style="display:none;" placeholder="Enter Infants for Triple"  class="form-control triple_infant">
                                                <input type="number" step=".01"  name="" id="infant_acc_child_triple_prev" style="display:none;" placeholder="Enter Infants for Double"  class="form-control">
                                                
                                            </div>
                                            
                                            
                                             <div class="col-md-4 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Total</label>-->
                                                <input type="number" step=".01"  name="triple_infant_total_without_dic" id="triple_infant_total_without_dic" hidden readonly placeholder="Total Amount" readonly class=" form-control">                               
                                                <h6 style="display:none;" class="triple_infant">{{ $tour_details->currency_symbol }} <span id="triple_infant_total_without_dic_p"></span></h6>
                                                
                                            </div>
                                       
                                            <div class="col-md-2 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Type</label>-->
                                                 <select style="display:none;" class="form-control " name="triple_infant_discount_type" id="triple_infant_discount_type">
                                                     <option value="amount">Number</option>
                                                     <!--<option value="%">Percentage</option>-->
                                                 </select>
                                            </div>
                                            <div class="col-md-2 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01" style="display:none;" name="triple_infant_disc" id="triple_infant_disc"  placeholder="Enter Discount for Double"  class="form-control ">
                                            </div>
                                            <div class="col-md-2 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01" style="display:none;" name="triple_infant_disc_total" id="triple_infant_disc_total"  placeholder="Enter Discount for Double"  class="form-control ">
                                            </div>
                                            <div class="col-md-2 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Net Total </label>-->
                                                <input type="number" step=".01"  name="triple_infant_total" id="triple_infant_total" hidden readonly placeholder="Total Amount" readonly class="form-control">
                                                
                                                <h4 style="display:none" class=""> {{ $tour_details->currency_symbol }} <span id="triple_infant_total_p"></span></h4>
                                            </div>
                                            
                                             <!--/////////////////////////-->
                                            <!--Visa Div-->
                                             <!--/////////////////////////-->
                                             <div class="col-md-12 d-none mt-2 mb-2 col-sm-6 form-kids">
                                              
                                                <input type="checkbox"  class="custom-control-input" id="triple_infant_visa_check" name="triple_infant_visa_type[]" value="triple_infant_visa_type">
                                                <label title=""  class="custom-control-label" for="triple_infant_visa_check">Change Visa Type</label>
                                                 
                                             </div>
                                             <div class="col-md-2 col-sm-6 form-kids triple_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Select Visa Type</label>
                                                 <select class="form-control" name="triple_infant_visa_type" id="triple_infant_visa_type">
                                                     @isset($all_visa_types)
                                                        @foreach($all_visa_types as $visa_res)
                                                     <option value="{{ $visa_res->other_visa_type }}" @if($visa_res->other_visa_type == $tour_details->visa_type) selected @endif>{{ $visa_res->other_visa_type }}</option>
                                                        @endforeach
                                                     @endisset
                                                 </select>
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids triple_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">For Persons</label>
                                                <input type="number"  name="triple_infant_visa_persons" id="triple_infant_visa_persons"  placeholder="Enter Persons for triple"  class="form-control">
                                             </div>
                                             
                                             
                                             <div class="col-md-2 col-sm-6 form-kids triple_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Purchase Rate</label>
                                                <input type="number" step=".01" name="visa_price_triple_infant_purc_rate" id="visa_price_triple_infant_purc_rate" value="{{ $tour_details->visa_fee_purchase }}"  placeholder="Enter Additional Price for triple"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids triple_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Exchange Rate</label>
                                                <input type="number" step=".01" name="visa_price_triple_infant_exchange_rate" id="visa_price_triple_infant_exchange_rate" value="{{ $tour_details->exchange_rate_visa }}"  placeholder="Enter Additional Price for triple"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids triple_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Visa Fee</label>
                                                
                                                <input type="number" step=".01" name="visa_actual_price_change_triple_infant" id="visa_actual_price_change_triple_infant" value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for triple"  class="form-control">
                                             </div>
                                        </div>
                                    </div>
                                     @endif
                                    @if($tour_details->quad_grand_total_amount != 0 AND $tour_details->quad_grand_total_amount != null) 
                                    <?php
                                        // echo "adult flight $flight_price_adult Infant ".$tour_details->infant_flight_cost;
                                        $infant_quad_price = ($tour_details->quad_grand_total_amount - $flight_price_adult) + $tour_details->infant_flight_cost;
                                        // echo " $infant_quad_price";
                                         $infant_quad_arr = ['type'=>'quad','price'=>$infant_quad_price];
                                    ?>
                                
                                    <div class="form-label custom-control custom-radio custom-control-inline">
                                          <div class="row">
                                            <div class="col-md-12 mb-2 col-sm-6 form-kids">
                                                <input type="checkbox" class="custom-control-input" id="infantroom3" disabled name="sharingInfant[]" value='<?php echo json_encode($infant_quad_arr) ?>'>
                                                <label title="If less than four(4), then will be shared with another person." class="custom-control-label" for="infantroom3">Quad  Price <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$infant_quad_price ?? '0' }}</span></label>
                                                <button class="btn btn-primary d-none btn-sm" type="button" onclick="editePrice('quad_infant_price')">(Edit)</button>
                                                <input type="text" name="quad_infant_price" id="quad_infant_price" style="padding: 0.3rem;border: #dfd9d9 1px solid;border-radius: 4px;" class="d-none edit-price" value="{{ $infant_quad_price }}">
            
                                            </div>
                                            
                                            <div class="col-md-8 col-sm-6 form-kids">
                                                <input type="number"  name="quad_infant" id="quad_acc_infant" style="display:none;" placeholder="Enter Infants for Quad"  class="form-control quad_infant">
                                                <input type="number" step=".01"  name="" id="infant_acc_child_quad_prev" style="display:none;" placeholder="Enter Infants for Double"  class="form-control">
                                            </div>
                                            
                                             
                                            <div class="col-md-4 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Total</label>-->
                                                <input type="number" step=".01"  name="quad_infant_total_without_dic" id="quad_infant_total_without_dic" hidden readonly placeholder="Total Amount" readonly class=" form-control">                               
                                                <h6 style="display:none;" class="quad_infant">{{ $tour_details->currency_symbol }} <span id="quad_infant_total_without_dic_p"></span></h6>
                                                
                                            </div>
                                       
                                            <div class="col-md-2 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Type</label>-->
                                                 <select style="display:none;" class="form-control " name="quad_infant_discount_type" id="quad_infant_discount_type">
                                                     <option value="amount">Number</option>
                                                     <!--<option value="%">Percentage</option>-->
                                                 </select>
                                             </div>
                                            <div class="col-md-2 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01" style="display:none;" name="quad_infant_disc" id="quad_infant_disc"  placeholder="Enter Discount for Double"  class="form-control ">
                                            </div>
                                            <div class="col-md-2 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Discount Amount</label>-->
                                                <input type="number" step=".01" style="display:none;" name="quad_infant_disc_total" id="quad_infant_disc_total"  placeholder="Enter Discount for Double"  class="form-control ">
                                            </div>
                                            <div class="col-md-2 col-sm-6 form-kids">
                                                <!--<label  class="custom-control-label" for="room1">Net Total </label>-->
                                                <input type="number" step=".01"  name="quad_infant_total" id="quad_infant_total" hidden readonly placeholder="Total Amount" readonly class="form-control">
                                                
                                                <h4 style="display:none" class=""> {{ $tour_details->currency_symbol }} <span id="quad_infant_total_p"></span></h4>
                                            </div>
                                            
                                            
                                            <!--/////////////////////////-->
                                            <!--Visa Div-->
                                             <!--/////////////////////////-->
                                             <div class="col-md-12 d-none mt-2 mb-2 col-sm-6 form-kids">
                                              
                                                <input type="checkbox"  class="custom-control-input" id="quad_infant_visa_check" name="quad_infant_visa_type[]" value="quad_infant_visa_type">
                                                <label title=""  class="custom-control-label" for="quad_infant_visa_check">Change Visa Type</label>
                                                 
                                             </div>
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Select Visa Type</label>
                                                 <select class="form-control" name="quad_infant_visa_type" id="quad_infant_visa_type">
                                                     @isset($all_visa_types)
                                                        @foreach($all_visa_types as $visa_res)
                                                     <option value="{{ $visa_res->other_visa_type }}" @if($visa_res->other_visa_type == $tour_details->visa_type) selected @endif>{{ $visa_res->other_visa_type }}</option>
                                                        @endforeach
                                                     @endisset
                                                 </select>
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">For Persons</label>
                                                <input type="number"  name="quad_infant_visa_persons" id="quad_infant_visa_persons"  placeholder="Enter Persons for quad"  class="form-control">
                                             </div>
                                             
                                             
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Purchase Rate</label>
                                                <input type="number" step=".01" name="visa_price_quad_infant_purc_rate" id="visa_price_quad_infant_purc_rate" value="{{ $tour_details->visa_fee_purchase }}"  placeholder="Enter Additional Price for quad"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Exchange Rate</label>
                                                <input type="number" step=".01" name="visa_price_quad_infant_exchange_rate" id="visa_price_quad_infant_exchange_rate" value="{{ $tour_details->exchange_rate_visa }}"  placeholder="Enter Additional Price for quad"  class="form-control">
                                             </div>
                                             
                                             <div class="col-md-2 col-sm-6 form-kids quad_visa_change_infant" style="display:none">
                                                <label  class="custom-control-label" for="room1">Visa Fee</label>
                                                
                                                <input type="number" step=".01" name="visa_actual_price_change_quad_infant" id="visa_actual_price_change_quad_infant" value="{{ $tour_details->visa_fee }}"  placeholder="Enter Persons for quad"  class="form-control">
                                             </div>
                                        </div>
                                    </div>
                                     @endif
                                    
                                    <hr>
                                 
                                    
                                     <div class="row d-none mt-3">
                                        <div class="col-md-12 col-sm-6 form-kids">
                                            <div class="row">
                                                 <div class="col-md-3 col-sm-6 form-kids">
                                                        <label class=""><h5>Discount</h5></label>
                                                </div>
                                                <div class="col-md-4 col-sm-3 form-kids">
                                                     <select class="form-control" name="discount_type" id="over_all_discount_type">
                                                         <option value="amount">Number</option>
                                                         <option value="%">Percentage</option>
                                                     </select>
                                                 </div>
                                                 <div class="col-md-4 col-sm-3 form-kids">
                                                     <input type="number" step=".01" placeholder="Enter Discount Price" id="over_all_discount_value" name="discount_price" class="form-control">
                                                 </div>
                                            </div>
                                        </div>
                                    
                                       
                                       
                                         
                                    </div>
                                    
                                    
                                     <hr>
                                <!--<div class="row">-->
                               
                                <!--    <div class="col-md-3 col-sm-6 form-kids">-->
                                <!--            <label class=""><h5>Discount Amount</h5></label>-->
                                <!--    </div>-->
                                <!--     <div class="col-md-3 col-sm-6 form-kids">-->
                                <!--         <input type="number" step=".01" placeholder="Enter Discount Amount" name="discount_amount" class="form-control">-->
                                <!--     </div>-->
                                     
                                <!--</div>-->
                                          
                                @if(isset($additional_service))
                                    <div class="widget widget_has_radio_checkbox">
                                        <h4>Additional Services   
                                            <button type="button" class="border border-light" data-bs-toggle="tooltip" data-bs-placement="top" title="Select Additional Services(Per Person)">
                                                <i class="fa fa-info-circle" aria-hidden="true"></i>
                                            </button>
                                        </h4>
                                        <ul>
                                            <li>
                                                    <label>
                                                        <input type="checkbox" onclick="checkPerPerson('{{ $additional_service[0]->extra_price_person }}','service1','first_checkbox_div',{{ $additional_service[0]->extra_price_type }})" class="custom-control-input" id="service1"  name="additonal_service1" value="{{ $additional_service[0]->extra_price_name }}">
                                                        <i class="awe-icon awe-icon-check"></i>
                                                       {{ $additional_service[0]->extra_price_name }}  
                                                        (<?php if($additional_service[0]->extra_price_type == 0){
                                                                echo "One-Time";
                                                           } 
                                                    
                                                            if($additional_service[0]->extra_price_type == 2){
                                                                echo "Per-Day";
                                                            }
                                                          
                                                        ?>)
                                                       <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$additional_service[0]->extra_price_price }}</span>
                                                    </label>
                                                     <div id="first_checkbox_div">
                                                     </div>
                                                </li>
                                            @if(isset($additional_service_more))
                                            <?php $x= 2; ?>
                                                @foreach($additional_service_more as $service_res)
                                                    <li>
                                                        <label>
                                                            <input type="checkbox" id="chechbox{{ $x }}" onclick="checkPerPerson('{{ $service_res->more_extra_price_person }}','chechbox{{ $x }}','first_checkbox{{ $x }}',{{ $service_res->more_extra_price_type }})"  name="additonal_service[]" value="{{ $service_res->more_extra_price_title }}">
                                                            <i class="awe-icon awe-icon-check"></i>
                                                            {{ $service_res->more_extra_price_title }} 
                                                                        (<?php if($service_res->more_extra_price_type == 0){
                                                                                    echo "One-Time";
                                                                               } 
                                               
                                                                                if($service_res->more_extra_price_type == 2){
                                                                                    echo "Per-Day";
                                                                                }
                                                                                
                                                                                
                                                                                
                                                                                
                                                                        ?>) 
                                                            <i class="fa fa-long-arrow-right" aria-hidden="true"></i> <span> {{ $tour_details->currency_symbol." ".$service_res->more_extra_price_price }}</span>
                                                        </label>
                                                        <div id="first_checkbox{{ $x }}">
                                                                         
                                                        </div>
                                                    </li>
                                                    <?php $x++; ?>
                                                @endforeach
                                            @endif
                                                
                                        </ul>
                                    </div>
                                @endif  
                                          
                                <div class="form-submit">
                                    <div class="add-to-cart">
                                        
                                        <button type="submit" id="add_to_cart" class="btn" style="background-color:#d2b254; color:white;">
                                            <i class="awe-icon awe-icon-cart"></i>Procced To Checkout
                                        </button>
                                    </div>
                                </div>
                                    
                            </div>
                        </form>
                    
                  </div>
                  <div class="modal-footer">
                    
                  </div>
              
                </div>
              </div>
            </div>


<!-- ================================
       START FOOTER AREA
================================= -->
@endsection
@section('scripts')
<script>

$('.owl-carousel2').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:4
        }
    }
})


     ////////////////////
        // Change Visa Price
        ////////////////////
        
        
        // For Double Adult
        
        $("#double_adult_visa_check").click(function() {
            if ($("#double_adult_visa_check").is(':checked')) {
                  console.log('button is checked')
                $('.double_visa_change').css('display','block')
            } else {
                console.log('button is not checked')
                 $('.double_visa_change').css('display','none')
                 $('#double_adult_visa_persons').val('')
                 $('#visa_add_price_double_ad').val('')
                 caluclateGrandTotal();

            }
        });
        
        function calculateDoubleVisaFee(){
            var conversionType = $('#conversion_type').val();
   
            var purchaseRate = $('#visa_price_double_purc_rate').val();
            var exchangeRate = $('#visa_price_double_exchange_rate').val();
            
            var visaFee = 0;
            if(conversionType == 'Divided'){
                visaFee =  purchaseRate / exchangeRate;
            }else{
                visaFee =  purchaseRate * exchangeRate;
            }
            
            $('#visa_actual_price_change').val(visaFee);
            
            caluclateGrandTotal();
          
          
        }
        
        
        $('#visa_price_double_purc_rate').on('keyup change',function(){
           calculateDoubleVisaFee();
        })
        
        $('#visa_price_double_exchange_rate').on('keyup change',function(){
           calculateDoubleVisaFee();
        })
        
        $('#visa_price_double_purc_rate').on('keyup change',function(){
           calculateDoubleVisaFee();
        })
        
              
        $('#double_adult_visa_persons').on('keyup change',function(){
           caluclateGrandTotal();
        })
        
        // For triple Adult
        
        $("#triple_adult_visa_check").click(function() {
            if ($("#triple_adult_visa_check").is(':checked')) {
                  console.log('button is checked')
                $('.triple_visa_change').css('display','block')
            } else {
                console.log('button is not checked')
                 $('.triple_visa_change').css('display','none')
                 $('#triple_adult_visa_persons').val('')
                 $('#visa_add_price_triple_ad').val('')
                 caluclateGrandTotal();
        
            }
        });
        
        function calculateTripleVisaFee(){
            var conversionType = $('#conversion_type').val();
        
            var purchaseRate = $('#visa_price_triple_purc_rate').val();
            var exchangeRate = $('#visa_price_triple_exchange_rate').val();
            
            var visaFee = 0;
            if(conversionType == 'Divided'){
                visaFee =  purchaseRate / exchangeRate;
            }else{
                visaFee =  purchaseRate * exchangeRate;
            }
            
            $('#visa_actual_price_change_triple').val(visaFee);
            
            caluclateGrandTotal();
          
          
        }
        
        
        $('#visa_price_triple_purc_rate').on('keyup change',function(){
           calculateTripleVisaFee();
        })
        
        $('#visa_price_triple_exchange_rate').on('keyup change',function(){
           calculateTripleVisaFee();
        })
        
        $('#visa_price_triple_purc_rate').on('keyup change',function(){
           calculateTripleVisaFee();
        })
        
              
        $('#triple_adult_visa_persons').on('keyup change',function(){
           caluclateGrandTotal();
        })
        
        // For quad Adult
                
        $("#quad_adult_visa_check").click(function() {
            if ($("#quad_adult_visa_check").is(':checked')) {
                  console.log('button is checked')
                $('.quad_visa_change').css('display','block')
            } else {
                console.log('button is not checked')
                 $('.quad_visa_change').css('display','none')
                 $('#quad_adult_visa_persons').val('')
                 $('#visa_add_price_quad_ad').val('')
                 caluclateGrandTotal();
        
            }
        });
        
        function calculateQuadVisaFee(){
            var conversionType = $('#conversion_type').val();
        
            var purchaseRate = $('#visa_price_quad_purc_rate').val();
            var exchangeRate = $('#visa_price_quad_exchange_rate').val();
            
            var visaFee = 0;
            if(conversionType == 'Divided'){
                visaFee =  purchaseRate / exchangeRate;
            }else{
                visaFee =  purchaseRate * exchangeRate;
            }
            
            $('#visa_actual_price_change_quad').val(visaFee);
            
            caluclateGrandTotal();
          
          
        }
        
        
        $('#visa_price_quad_purc_rate').on('keyup change',function(){
           calculateQuadVisaFee();
        })
        
        $('#visa_price_quad_exchange_rate').on('keyup change',function(){
           calculateQuadVisaFee();
        })
        
        $('#visa_price_quad_purc_rate').on('keyup change',function(){
           calculateQuadVisaFee();
        })
        
              
        $('#quad_adult_visa_persons').on('keyup change',function(){
           caluclateGrandTotal();
        })
        
           // For Without Acc Adult
       
         $("#without_acc_adult_visa_check").click(function() {
         if ($("#without_acc_adult_visa_check").is(':checked')) {
               console.log('button is checked')
             $('.without_acc_visa_change').css('display','block')
         } else {
             console.log('button is not checked')
              $('.without_acc_visa_change').css('display','none')
              $('#without_acc_adult_visa_persons').val('')
              $('#visa_add_price_without_acc_ad').val('')
              caluclateGrandTotal();
     
         }
     });
     
     function calculateWithoutAccVisaFeeAdult(){
         console.log('tttttttttttttttttttttttttttttttttttt');
         var conversionType = $('#conversion_type').val();
         
             var purchaseRate = $('#visa_price_without_acc_purc_rate').val();
             var exchangeRate = $('#visa_price_without_acc_exchange_rate').val();
             
             var visaFee = 0;
             if(conversionType == 'Divided'){
                 visaFee =  purchaseRate / exchangeRate;
             }else{
                 visaFee =  purchaseRate * exchangeRate;
             }
             
             $('#visa_actual_price_change_without_acc').val(visaFee);
             visa_actual_price_change_without_acc
             caluclateGrandTotal();
           
           
         }
         
         
         $('#visa_price_without_acc_purc_rate').on('keyup change',function(){
            calculateWithoutAccVisaFeeAdult();
         })
         
         $('#visa_price_without_acc_exchange_rate').on('keyup change',function(){
            calculateWithoutAccVisaFeeAdult();
         })
         
         $('#visa_price_without_acc_purc_rate').on('keyup change',function(){
            calculateWithoutAccVisaFeeAdult();
         })
         
               
         $('#without_acc_adult_visa_persons').on('keyup change',function(){
            caluclateGrandTotal();
         })
         
            // For Without Acc Child
         
         
          $("#without_acc_child_visa_check").click(function() {
         if ($("#without_acc_child_visa_check").is(':checked')) {
               console.log('button is checked')
             $('.without_acc_visa_change_child').css('display','block')
         } else {
             console.log('button is not checked')
              $('.without_acc_visa_change_child').css('display','none')
              $('#without_acc_child_visa_persons').val('')
              $('#visa_add_price_without_acc_ad').val('')
              caluclateGrandTotal();
     
         }
     });
     
     function calculateWithoutAccVisaFee(){
         var conversionType = $('#conversion_type').val();
         
             var purchaseRate = $('#visa_price_without_acc_child_purc_rate').val();
             var exchangeRate = $('#visa_price_without_acc_child_exchange_rate').val();
             
             var visaFee = 0;
             if(conversionType == 'Divided'){
                 visaFee =  purchaseRate / exchangeRate;
             }else{
                 visaFee =  purchaseRate * exchangeRate;
             }
             
             $('#visa_actual_price_change_without_acc_child').val(visaFee);
             
             caluclateGrandTotal();
           
           
         }
         
         
         $('#visa_price_without_acc_child_purc_rate').on('keyup change',function(){
            calculateWithoutAccVisaFee();
         })
         
         $('#visa_price_without_acc_child_exchange_rate').on('keyup change',function(){
            calculateWithoutAccVisaFee();
         })
         
         $('#visa_price_without_acc_child_purc_rate').on('keyup change',function(){
            calculateWithoutAccVisaFee();
         })
         
               
         $('#without_acc_child_visa_persons').on('keyup change',function(){
            caluclateGrandTotal();
         })
         // For Double Childs
         
         $("#double_child_visa_check").click(function() {
           if ($("#double_child_visa_check").is(':checked')) {
                 console.log('button is checked')
               $('.double_visa_change_child').css('display','block')
           } else {
               console.log('button is not checked')
                $('.double_visa_change_child').css('display','none')
                $('#double_child_visa_persons').val('')
                $('#visa_add_price_double_ad').val('')
                caluclateGrandTotal();
        
           }
        });
        
        
        function calculatedoubleChildVisaFee(){
           var conversionType = $('#conversion_type').val();
           
               var purchaseRate = $('#visa_price_double_child_purc_rate').val();
               var exchangeRate = $('#visa_price_double_child_exchange_rate').val();
               
               var visaFee = 0;
               if(conversionType == 'Divided'){
                   visaFee =  purchaseRate / exchangeRate;
               }else{
                   visaFee =  purchaseRate * exchangeRate;
               }
               
               $('#visa_actual_price_change_double_child').val(visaFee);
               
               caluclateGrandTotal();
             
             
           }
           
           
           $('#visa_price_double_child_purc_rate').on('keyup change',function(){
              calculatedoubleChildVisaFee();
           })
           
           $('#visa_price_double_child_exchange_rate').on('keyup change',function(){
              calculatedoubleChildVisaFee();
           })
           
           $('#visa_price_double_child_purc_rate').on('keyup change',function(){
              calculatedoubleChildVisaFee();
           })
           
                 
           $('#double_child_visa_persons').on('keyup change',function(){
              caluclateGrandTotal();
           })
           
           
           // For triple Childs

        $("#triple_child_visa_check").click(function() {
           if ($("#triple_child_visa_check").is(':checked')) {
                 console.log('button is checked')
               $('.triple_visa_change_child').css('display','block')
           } else {
               console.log('button is not checked')
                $('.triple_visa_change_child').css('display','none')
                $('#triple_child_visa_persons').val('')
                $('#visa_add_price_triple_ad').val('')
                caluclateGrandTotal();
        
           }
        });

        function calculateTripleChildVisaFee(){
           var conversionType = $('#conversion_type').val();
           
               var purchaseRate = $('#visa_price_triple_child_purc_rate').val();
               var exchangeRate = $('#visa_price_triple_child_exchange_rate').val();
               
               var visaFee = 0;
               if(conversionType == 'Divided'){
                   visaFee =  purchaseRate / exchangeRate;
               }else{
                   visaFee =  purchaseRate * exchangeRate;
               }
               
               $('#visa_actual_price_change_triple_child').val(visaFee);
               
               caluclateGrandTotal();
             
             
           }
           
           
           $('#visa_price_triple_child_purc_rate').on('keyup change',function(){
              calculateTripleChildVisaFee();
           })
           
           $('#visa_price_triple_child_exchange_rate').on('keyup change',function(){
              calculateTripleChildVisaFee();
           })
           
           $('#visa_price_triple_child_purc_rate').on('keyup change',function(){
              calculateTripleChildVisaFee();
           })
           
                 
           $('#triple_child_visa_persons').on('keyup change',function(){
              caluclateGrandTotal();
           })
           
           
           // For quad Childs

            $("#quad_child_visa_check").click(function() {
               if ($("#quad_child_visa_check").is(':checked')) {
                     console.log('button is checked')
                   $('.quad_visa_change_child').css('display','block')
               } else {
                   console.log('button is not checked')
                    $('.quad_visa_change_child').css('display','none')
                    $('#quad_child_visa_persons').val('')
                    $('#visa_add_price_quad_ad').val('')
                    caluclateGrandTotal();
            
               }
            });
            
            function calculateQuadChildVisaFee(){
               var conversionType = $('#conversion_type').val();
               
                   var purchaseRate = $('#visa_price_quad_child_purc_rate').val();
                   var exchangeRate = $('#visa_price_quad_child_exchange_rate').val();
                   
                   var visaFee = 0;
                   if(conversionType == 'Divided'){
                       visaFee =  purchaseRate / exchangeRate;
                   }else{
                       visaFee =  purchaseRate * exchangeRate;
                   }
                   
                   $('#visa_actual_price_change_quad_child').val(visaFee);
                   
                   caluclateGrandTotal();
                 
                 
               }
               
               
               $('#visa_price_quad_child_purc_rate').on('keyup change',function(){
                  calculateQuadChildVisaFee();
               })
               
               $('#visa_price_quad_child_exchange_rate').on('keyup change',function(){
                  calculateQuadChildVisaFee();
               })
               
               $('#visa_price_quad_child_purc_rate').on('keyup change',function(){
                  calculateQuadChildVisaFee();
               })
               
                     
               $('#quad_child_visa_persons').on('keyup change',function(){
                  caluclateGrandTotal();
               })
               
               
               // For without_acc infants

            $("#without_acc_infant_visa_check").click(function() {
               if ($("#without_acc_infant_visa_check").is(':checked')) {
                     console.log('button is checked')
                   $('.without_acc_visa_change_infant').css('display','block')
               } else {
                   console.log('button is not checked')
                    $('.without_acc_visa_change_infant').css('display','none')
                    $('#without_acc_infant_visa_persons').val('')
                    $('#visa_add_price_without_acc_ad').val('')
                    caluclateGrandTotal();
            
               }
            });
            
            function calculatewithoutAccinfantVisaFee(){
               var conversionType = $('#conversion_type').val();
               
                   var purchaseRate = $('#visa_price_without_acc_infant_purc_rate').val();
                   var exchangeRate = $('#visa_price_without_acc_infant_exchange_rate').val();
                   
                   var visaFee = 0;
                   if(conversionType == 'Divided'){
                       visaFee =  purchaseRate / exchangeRate;
                   }else{
                       visaFee =  purchaseRate * exchangeRate;
                   }
                   
                   $('#visa_actual_price_change_without_acc_infant').val(visaFee);
                   
                   caluclateGrandTotal();
                 
                 
               }
               
               
               $('#visa_price_without_acc_infant_purc_rate').on('keyup change',function(){
                  calculatewithoutAccinfantVisaFee();
               })
               
               $('#visa_price_without_acc_infant_exchange_rate').on('keyup change',function(){
                  calculatewithoutAccinfantVisaFee();
               })
               
               $('#visa_price_without_acc_infant_purc_rate').on('keyup change',function(){
                  calculatewithoutAccinfantVisaFee();
               })
               
                     
               $('#without_acc_infant_visa_persons').on('keyup change',function(){
                  caluclateGrandTotal();
               })
               
               
               // For Double infants
         
         $("#double_infant_visa_check").click(function() {
           if ($("#double_infant_visa_check").is(':checked')) {
                 console.log('button is checked')
               $('.double_visa_change_infant').css('display','block')
           } else {
               console.log('button is not checked')
                $('.double_visa_change_infant').css('display','none')
                $('#double_infant_visa_persons').val('')
                $('#visa_add_price_double_ad').val('')
                caluclateGrandTotal();
        
           }
        });
        
        
        function calculatedoubleInfantVisaFee(){
           var conversionType = $('#conversion_type').val();
           
               var purchaseRate = $('#visa_price_double_infant_purc_rate').val();
               var exchangeRate = $('#visa_price_double_infant_exchange_rate').val();
               
               var visaFee = 0;
               if(conversionType == 'Divided'){
                   visaFee =  purchaseRate / exchangeRate;
               }else{
                   visaFee =  purchaseRate * exchangeRate;
               }
               
               $('#visa_actual_price_change_double_infant').val(visaFee);
               
               caluclateGrandTotal();
             
             
           }
           
           
           $('#visa_price_double_infant_purc_rate').on('keyup change',function(){
              calculatedoubleInfantVisaFee();
           })
           
           $('#visa_price_double_infant_exchange_rate').on('keyup change',function(){
              calculatedoubleInfantVisaFee();
           })
           
           $('#visa_price_double_infant_purc_rate').on('keyup change',function(){
              calculatedoubleInfantVisaFee();
           })
           
                 
           $('#double_infant_visa_persons').on('keyup change',function(){
              caluclateGrandTotal();
           })
               
               
            // For triple infants
         
         $("#triple_infant_visa_check").click(function() {
           if ($("#triple_infant_visa_check").is(':checked')) {
                 console.log('button is checked')
               $('.triple_visa_change_infant').css('display','block')
           } else {
               console.log('button is not checked')
                $('.triple_visa_change_infant').css('display','none')
                $('#triple_infant_visa_persons').val('')
                $('#visa_add_price_triple_ad').val('')
                caluclateGrandTotal();
        
           }
        });
        
        
        function calculateTripleInfantVisaFee(){
           var conversionType = $('#conversion_type').val();
           
               var purchaseRate = $('#visa_price_triple_infant_purc_rate').val();
               var exchangeRate = $('#visa_price_triple_infant_exchange_rate').val();
               
               var visaFee = 0;
               if(conversionType == 'Divided'){
                   visaFee =  purchaseRate / exchangeRate;
               }else{
                   visaFee =  purchaseRate * exchangeRate;
               }
               
               $('#visa_actual_price_change_triple_infant').val(visaFee);
               
               caluclateGrandTotal();
             
             
           }
           
           
           $('#visa_price_triple_infant_purc_rate').on('keyup change',function(){
              calculateTripleInfantVisaFee();
           })
           
           $('#visa_price_triple_infant_exchange_rate').on('keyup change',function(){
              calculateTripleInfantVisaFee();
           })
           
           $('#visa_price_triple_infant_purc_rate').on('keyup change',function(){
              calculateTripleInfantVisaFee();
           })
           
                 
           $('#triple_infant_visa_persons').on('keyup change',function(){
              caluclateGrandTotal();
           })
           
           
           
            // For quad infants
         
         $("#quad_infant_visa_check").click(function() {
           if ($("#quad_infant_visa_check").is(':checked')) {
                 console.log('button is checked')
               $('.quad_visa_change_infant').css('display','block')
           } else {
               console.log('button is not checked')
                $('.quad_visa_change_infant').css('display','none')
                $('#quad_infant_visa_persons').val('')
                $('#visa_add_price_quad_ad').val('')
                caluclateGrandTotal();
        
           }
        });
        
        
        function calculateQuadInfantVisaFee(){
           var conversionType = $('#conversion_type').val();
           
               var purchaseRate = $('#visa_price_quad_infant_purc_rate').val();
               var exchangeRate = $('#visa_price_quad_infant_exchange_rate').val();
               
               var visaFee = 0;
               if(conversionType == 'Divided'){
                   visaFee =  purchaseRate / exchangeRate;
               }else{
                   visaFee =  purchaseRate * exchangeRate;
               }
               
               $('#visa_actual_price_change_quad_infant').val(visaFee);
               
               caluclateGrandTotal();
             
             
           }
           
           
           $('#visa_price_quad_infant_purc_rate').on('keyup change',function(){
              calculateQuadInfantVisaFee();
           })
           
           $('#visa_price_quad_infant_exchange_rate').on('keyup change',function(){
              calculateQuadInfantVisaFee();
           })
           
           $('#visa_price_quad_infant_purc_rate').on('keyup change',function(){
              calculateQuadInfantVisaFee();
           })
           
                 
           $('#quad_infant_visa_persons').on('keyup change',function(){
              caluclateGrandTotal();
           })   
               
           
        ////////////////////////
        // Change Visa Price End
        ////////////////////////

        // For Childs
        $("#childroom1").click(function() {
            if ($("#childroom1").is(':checked')) {
                  console.log('button is checked')
                $('.double_child').css('display','block')
                checkDoubleChildOrInfantHide('infantroom1',true)
            } else {
                console.log('button is not checked')
                 $('.double_child').css('display','none')
                 $('#double_acc_child').val('')
                 $('#double_child_disc').val(0)
                 caluclateGrandTotal();
                 checkDoubleChildOrInfantHide('infantroom1',false)
                 
            }
        });
        
        $("#childroom2").click(function() {
            if ($("#childroom2").is(':checked')) {
                  console.log('button is checked')
                $('.triple_child').css('display','block')
                checkTripleChildOrInfantHide('infantroom2',true)
            } else {
                console.log('button is not checked')
                 $('.triple_child').css('display','none')
                 $('#triple_acc_child').val('')
                 $('#triple_child_disc').val(0)
                 caluclateGrandTotal();
                 checkTripleChildOrInfantHide('infantroom2',false)
            }
        });
        
        $("#childroom3").click(function() {
            if ($("#childroom3").is(':checked')) {
                  console.log('button is checked')
                $('.quad_child').css('display','block')
                checkQuadChildOrInfantHide('infantroom3',true)
            } else {
                console.log('button is not checked')
                 $('.quad_child').css('display','none')
                 $('#quad_acc_child').val('')
                 $('#quad_child_disc').val(0)
                 caluclateGrandTotal();
                 checkQuadChildOrInfantHide('infantroom3',false)
            }
        });
        
        // For Infants
        $("#infantroom1").click(function() {
            if ($("#infantroom1").is(':checked')) {
                  console.log('button is checked')
                $('.double_infant').css('display','block')
                checkDoubleChildOrInfantHide('childroom1',true)
            } else {
                console.log('button is not checked')
                 $('.double_infant').css('display','none')
                 $('.quad_child').css('display','none')
                 $('#double_acc_infant').val('')
                 $('#double_infant_disc').val(0)
                 caluclateGrandTotal();
                 checkDoubleChildOrInfantHide('childroom1',false)
            }
        });
        
        $("#infantroom2").click(function() {
            if ($("#infantroom2").is(':checked')) {
                  console.log('button is checked')
                $('.triple_infant').css('display','block')
                checkTripleChildOrInfantHide('childroom2',true)
            } else {
                console.log('button is not checked')
                 $('.triple_infant').css('display','none')
                 $('#triple_acc_infant').val('')
                 $('#triple_infant_disc').val(0)
                 caluclateGrandTotal();
                 checkTripleChildOrInfantHide('childroom2',false)
                 
            }
        });
        
        $("#infantroom3").click(function() {
            if ($("#infantroom3").is(':checked')) {
                  console.log('button is checked')
                $('.quad_infant').css('display','block')
                  checkQuadChildOrInfantHide('childroom3',true)
            } else {
                console.log('button is not checked')
                 $('.quad_infant').css('display','none')
                  $('#quad_acc_infant').val('')
                 $('#quad_infant_disc').val(0)
                 caluclateGrandTotal();
                 checkQuadChildOrInfantHide('childroom3',false)
            }
        });
        
        $("#selectAgent").click(function() {
            if ($("#selectAgent").is(':checked')) {
                  console.log('button is checked')
                $('.agent_Name').css('display','block')
            } else {
                console.log('button is not checked')
                 $('.agent_Name').css('display','none')
            }
        });
        
        


    // For Adults Rooms
    $('#double_rooms').on('keyup change',function(){
        var double_rooms = $('#double_rooms').val();
        doubleAdults = double_rooms * 2;
        
        if(doubleAdults <= 0){
            $('#double_adult_visa_persons').val('');
        }
        
        $('#double_adult').val(doubleAdults);
        caluclateGrandTotal();
        checkChildInfantDoubleAv();
        checkDoubleRemaingCap()
    })
    
    $('#triple_rooms').on('keyup change',function(){
        var double_rooms = $('#triple_rooms').val();
        doubleAdults = double_rooms * 3;
        $('#triple_adult').val(doubleAdults);
        caluclateGrandTotal();
        checkChildInfantTripleAv();
        checkTripleRemaingCap()
    })


    $('#quad_rooms').on('keyup change',function(){
        var double_rooms = $('#quad_rooms').val();
        doubleAdults = double_rooms * 4;
        $('#quad_adult').val(doubleAdults);
        caluclateGrandTotal();
        checkChildInfantQuadAv();
        checkQuadRemaingCap()
    })
    
    
    //---------------------------------------------------
    // For Total Calculate
    //---------------------------------------------------
    
      // For Adults Double 
      function adultDoubleCalc(){
          var doubleAdult = $('#double_adult').val();
          var doubleAdultPrice = $('#double_adult_price').val();
          var doubleAdultdiscType = $('#double_adult_discount_type').val();
          var doubleAdultdiscValue = $('#double_adult_disc').val();
          
          if(doubleAdult <= 0){
                $('#double_adult_visa_persons').val('');
          }
              
          
        if ($("#double_adult_visa_check").is(':checked')) {
             var adultsChange = $('#double_adult_visa_persons').val();
             var visa_actual_price = $('#visa_actual_price').val();
             var visa_change_price = $('#visa_actual_price_change').val();
             var adultsWithoutChange = doubleAdult - adultsChange;
             
             var changeDoublePrice = +(doubleAdultPrice - visa_actual_price) + +visa_change_price;
             console.log('Double price change'+changeDoublePrice);
             var changeDoublePriceTot = changeDoublePrice * adultsChange;
                          console.log('Double price changeDoublePriceTot '+changeDoublePriceTot);
                          console.log('Adults without change '+adultsWithoutChange);

             var withoutchangeDoublePriceTot = doubleAdultPrice * adultsWithoutChange;
             console.log('Double price withoutchangeDoublePriceTot '+withoutchangeDoublePriceTot);
             var totalAdultDoublePrice = +changeDoublePriceTot + +withoutchangeDoublePriceTot;
             var totalAdultDoubleGrandP = totalAdultDoublePrice;
             
        } else {
          var totalAdultDoublePrice = doubleAdult * doubleAdultPrice;
          var totalAdultDoubleGrandP = totalAdultDoublePrice;
        }
        
        $('#double_adult_total_without_dic').val(totalAdultDoubleGrandP);
        $('#double_adult_total_without_dic_p').html(totalAdultDoubleGrandP);
          
          if(doubleAdultdiscType == '%'){
              if(doubleAdultdiscValue >100){
                  $('#double_adult_disc').val(100);
                  doubleAdultdiscValue = 100;
              }
              
              
              var discunt_am = (totalAdultDoubleGrandP * doubleAdultdiscValue) / 100;
              totalAdultDoubleGrandP = totalAdultDoubleGrandP - discunt_am;
          }else{
              var discountPP = doubleAdultdiscValue;
              var totalDiscount = discountPP * doubleAdult;
              
              if(totalDiscount != 0){
                  $('#double_adult_disc_total').val(totalDiscount);
              }
              
              var totalDiscount = $('#double_adult_disc_total').val();
              totalAdultDoubleGrandP = totalAdultDoubleGrandP - totalDiscount;
              
          }
          
          $('#double_adult_total').val(totalAdultDoubleGrandP);
          $('#double_adult_total_p').html(totalAdultDoubleGrandP);
      }
      
      function adultTripleCalc(){
          var tripleAdult = $('#triple_adult').val();
          var tripleAdultPrice = $('#triple_adult_price').val();
          var tripleAdultdiscType = $('#triple_adult_discount_type').val();
          var tripleAdultdiscValue = $('#triple_adult_disc').val();
          
          if(tripleAdult <= 0){
               $('#triple_adult_visa_persons').val('');
            }
             
            
            if ($("#triple_adult_visa_check").is(':checked')) {
                var adultsChange = $('#triple_adult_visa_persons').val();
                var visa_actual_price = $('#visa_actual_price').val();
                var visa_change_price = $('#visa_actual_price_change_triple').val();
                var adultsWithoutChange = tripleAdult - adultsChange;
                
                var changetriplePrice = +(tripleAdultPrice - visa_actual_price) + +visa_change_price;
                console.log('triple price change'+changetriplePrice);
                var changetriplePriceTot = changetriplePrice * adultsChange;
                             console.log('triple price changetriplePriceTot '+changetriplePriceTot);
                             console.log('Adults without change '+adultsWithoutChange);
                
                var withoutchangetriplePriceTot = tripleAdultPrice * adultsWithoutChange;
                console.log('triple price withoutchangetriplePriceTot '+withoutchangetriplePriceTot);
                var totalAdulttriplePrice = +changetriplePriceTot + +withoutchangetriplePriceTot;
                var totalAdulttripleGrandP = totalAdulttriplePrice;
                
            } else {
                var totalAdulttriplePrice = tripleAdult * tripleAdultPrice;
                var totalAdulttripleGrandP = totalAdulttriplePrice;
            }
          
          $('#triple_adult_total_without_dic').val(totalAdulttripleGrandP);
          $('#triple_adult_total_without_dic_p').html(totalAdulttripleGrandP);
          
          
          if(tripleAdultdiscType == '%'){
              if(tripleAdultdiscValue >100){
                  $('#triple_adult_disc').val(100);
                  tripleAdultdiscValue = 100;
              }
              var discunt_am = (totalAdulttripleGrandP * tripleAdultdiscValue) / 100;
              totalAdulttripleGrandP = totalAdulttripleGrandP - discunt_am;
          }else{
              var discountPP = tripleAdultdiscValue;
              var totalDiscount = discountPP * tripleAdult;
              
              if(totalDiscount != 0){
                  $('#triple_adult_disc_total').val(totalDiscount);
              }
              
              var totalDiscount = $('#triple_adult_disc_total').val();
              totalAdulttripleGrandP = totalAdulttripleGrandP - totalDiscount;
          }
          
          $('#triple_adult_total').val(totalAdulttripleGrandP);
          $('#triple_adult_total_p').html(totalAdulttripleGrandP);
      }
      
      function adultQuadCalc(){
          var quadAdult = $('#quad_adult').val();
          var quadAdultPrice = $('#quad_adult_price').val();
          var quadAdultdiscType = $('#quad_adult_discount_type').val();
          var quadAdultdiscValue = $('#quad_adult_disc').val();

          
            if(quadAdult <= 0){
               $('#quad_adult_visa_persons').val('');
            }
            
             
            
            if ($("#quad_adult_visa_check").is(':checked')) {
                var adultsChange = $('#quad_adult_visa_persons').val();
                var visa_actual_price = $('#visa_actual_price').val();
                var visa_change_price = $('#visa_actual_price_change_quad').val();
                var adultsWithoutChange = quadAdult - adultsChange;
                
                var changequadPrice = +(quadAdultPrice - visa_actual_price) + +visa_change_price;
                console.log('quad price change'+changequadPrice);
                var changequadPriceTot = changequadPrice * adultsChange;
                             console.log('quad price changequadPriceTot '+changequadPriceTot);
                             console.log('Adults without change '+adultsWithoutChange);
                
                var withoutchangequadPriceTot = quadAdultPrice * adultsWithoutChange;
                console.log('quad price withoutchangequadPriceTot '+withoutchangequadPriceTot);
                var totalAdultQuadPrice = +changequadPriceTot + +withoutchangequadPriceTot;
                var totalAdulQuadGrandP = totalAdultQuadPrice;
                
            } else {
                var totalAdultQuadPrice = quadAdult * quadAdultPrice;
                var totalAdulQuadGrandP = totalAdultQuadPrice;

            }
          
          $('#quad_adult_total_without_dic').val(totalAdulQuadGrandP);
          $('#quad_adult_total_without_dic_p').html(totalAdulQuadGrandP);
          
          
          if(quadAdultdiscType == '%'){
              if(quadAdultdiscValue >100){
                  $('#quad_adult_disc').val(100);
                  quadAdultdiscValue = 100;
              }
              var discunt_am = (totalAdulQuadGrandP * quadAdultdiscValue) / 100;
              totalAdulQuadGrandP = totalAdulQuadGrandP - discunt_am;
          }else{
              var discountPP = quadAdultdiscValue;
              var totalDiscount = discountPP * quadAdult;
              
              if(totalDiscount != 0){
                  $('#quad_adult_disc_total').val(totalDiscount);
              }
              
              var totalDiscount = $('#quad_adult_disc_total').val();
              totalAdulQuadGrandP = totalAdulQuadGrandP - totalDiscount;
          }
          
          $('#quad_adult_total').val(totalAdulQuadGrandP);
          $('#quad_adult_total_p').html(totalAdulQuadGrandP);
      }
      
      function adultWithoutAccomCalc(){
          var WithoutAccomAdult = $('#without_acc_adult').val();
          var WithoutAccomAdultPrice = $('#without_acc_adult_price').val();
          var WithoutAccomAdultdiscType = $('#without_acc_adult_discount_type').val();
          var WithoutAccomAdultdiscValue = $('#without_acc_adult_disc').val();
          
               
              if(WithoutAccomAdult <= 0){
               $('#without_acc_adult_visa_persons').val('');
            }
            
             
            
            if ($("#without_acc_adult_visa_check").is(':checked')) {
                var adultsChange = $('#without_acc_adult_visa_persons').val();
                var visa_actual_price = $('#visa_actual_price').val();
                var visa_change_price = $('#visa_actual_price_change_without_acc').val();
                var adultsWithoutChange = WithoutAccomAdult - adultsChange;
                
                var changewithout_accPrice = +(WithoutAccomAdultPrice - visa_actual_price) + +visa_change_price;
                console.log('without_acc price change'+changewithout_accPrice);
                var changewithout_accPriceTot = changewithout_accPrice * adultsChange;
                             console.log('without_acc price changewithout_accPriceTot '+changewithout_accPriceTot);
                             console.log('Adults without change '+adultsWithoutChange);
                
                var withoutchangewithout_accPriceTot = WithoutAccomAdultPrice * adultsWithoutChange;
                console.log('without_acc price withoutchangewithout_accPriceTot '+withoutchangewithout_accPriceTot);
                var totalAdultWithoutAccomPrice = +changewithout_accPriceTot + +withoutchangewithout_accPriceTot;
                var totalAdulWithoutAccomGrandP = totalAdultWithoutAccomPrice;
                
            } else {
                var totalAdultWithoutAccomPrice = WithoutAccomAdult * WithoutAccomAdultPrice;
                var totalAdulWithoutAccomGrandP = totalAdultWithoutAccomPrice;
            }
            
            
            totalAdulWithoutAccomGrandP = totalAdulWithoutAccomGrandP.toFixed(2)
            
          $('#without_acc_adult_total_without_dic').val(totalAdulWithoutAccomGrandP);
          $('#without_acc_adult_total_without_dic_p').html(totalAdulWithoutAccomGrandP);
          
          
          if(WithoutAccomAdultdiscType == '%'){
              if(WithoutAccomAdultdiscValue >100){
                  $('#without_acc_adult_disc').val(100);
                  WithoutAccomAdultdiscValue = 100;
              }
              var discunt_am = (totalAdulWithoutAccomGrandP * WithoutAccomAdultdiscValue) / 100;
              totalAdulWithoutAccomGrandP = totalAdulWithoutAccomGrandP - discunt_am;
          }else{
                 var discountPP = WithoutAccomAdultdiscValue;
                  var totalDiscount = discountPP * WithoutAccomAdult;
                  
                  if(totalDiscount != 0){
                      $('#without_acc_adult_disc_total').val(totalDiscount);
                  }
                  
                  var totalDiscount = $('#without_acc_adult_disc_total').val();
                  totalAdulWithoutAccomGrandP = totalAdulWithoutAccomGrandP - totalDiscount;
          }
          
          totalAdulWithoutAccomGrandP = totalAdulWithoutAccomGrandP.toFixed(2)
          
          $('#without_acc_adult_total').val(totalAdulWithoutAccomGrandP);
          $('#without_acc_adult_total_p').html(totalAdulWithoutAccomGrandP);
      }
      
      function childWithoutAccomCalc(){
          var WithoutAccomChild = $('#without_acc_child').val();
          var WithoutAccomChildPrice = $('#without_acc_child_price').val();
          var WithoutAccomChilddiscType = $('#without_acc_child_discount_type').val();
          var WithoutAccomChilddiscValue = $('#without_acc_child_disc').val();
          
            if(WithoutAccomChild <= 0){
               $('#without_acc_child_visa_persons').val('');
            }
            
             
            
            if ($("#without_acc_child_visa_check").is(':checked')) {
                var ChildsChange = $('#without_acc_child_visa_persons').val();
                var visa_actual_price = $('#visa_actual_price').val();
                var visa_change_price = $('#visa_actual_price_change_without_acc_child').val();
                var ChildsWithoutChange = WithoutAccomChild - ChildsChange;
                
                var changewithout_accPrice = +(WithoutAccomChildPrice - visa_actual_price) + +visa_change_price;
                console.log('without_acc price change'+changewithout_accPrice);
                var changewithout_accPriceTot = changewithout_accPrice * ChildsChange;
                             console.log('without_acc price changewithout_accPriceTot '+changewithout_accPriceTot);
                             console.log('Childs without change '+ChildsWithoutChange);
                
                var withoutchangewithout_accPriceTot = WithoutAccomChildPrice * ChildsWithoutChange;
                console.log('without_acc price withoutchangewithout_accPriceTot '+withoutchangewithout_accPriceTot);
                var totalChildWithoutAccomPrice = +changewithout_accPriceTot + +withoutchangewithout_accPriceTot;
                var totalChildWithoutAccomGrandP = totalChildWithoutAccomPrice;
                
            } else {
                var totalChildWithoutAccomPrice = WithoutAccomChild * WithoutAccomChildPrice;
                var totalChildWithoutAccomGrandP = totalChildWithoutAccomPrice;
            }

        totalChildWithoutAccomGrandP = totalChildWithoutAccomGrandP.toFixed(2)
          $('#without_acc_child_total_without_dic').val(totalChildWithoutAccomGrandP);
          $('#without_acc_child_total_without_dic_p').html(totalChildWithoutAccomGrandP);
          
          
          if(WithoutAccomChilddiscType == '%'){
              if(WithoutAccomChilddiscValue >100){
                  $('#without_acc_child_disc').val(100);
                  WithoutAccomChilddiscValue = 100;
              }
              var discunt_am = (totalChildWithoutAccomGrandP * WithoutAccomChilddiscValue) / 100;
              totalChildWithoutAccomGrandP = totalChildWithoutAccomGrandP - discunt_am;
          }else{

              var discountPP = WithoutAccomChilddiscValue;
              var totalDiscount = discountPP * WithoutAccomChild;
              
              if(totalDiscount != 0){
                  $('#without_acc_child_disc_total').val(totalDiscount);
              }
              
              var totalDiscount = $('#without_acc_child_disc_total').val();
              totalChildWithoutAccomGrandP = totalChildWithoutAccomGrandP - totalDiscount;
          }
          
          totalChildWithoutAccomGrandP = totalChildWithoutAccomGrandP.toFixed(2)
          $('#without_acc_child_total').val(totalChildWithoutAccomGrandP);
          $('#without_acc_child_total_p').html(totalChildWithoutAccomGrandP);
      }
      
      function childDoubleCalc(){
          var doubleChild = $('#double_acc_child').val();
          var doubleChildPrice = $('#double_child_price').val();
          var doubleChilddiscType = $('#double_child_discount_type').val();
          var doubleChilddiscValue = $('#double_child_disc').val();
          
          if(doubleChild <= 0){
               $('#double_child_visa_persons').val('');
            }
            
             
            
            if ($("#double_child_visa_check").is(':checked')) {
                var ChildsChange = $('#double_child_visa_persons').val();
                var visa_actual_price = $('#visa_actual_price').val();
                var visa_change_price = $('#visa_actual_price_change_double_child').val();
                var ChildsWithoutChange = doubleChild - ChildsChange;
                
                var changedoublePrice = +(doubleChildPrice - visa_actual_price) + +visa_change_price;
                console.log('double price change'+changedoublePrice);
                var changedoublePriceTot = changedoublePrice * ChildsChange;
                             console.log('double price changedoublePriceTot '+changedoublePriceTot);
                             console.log('Childs without change '+ChildsWithoutChange);
                
                var withoutchangedoublePriceTot = doubleChildPrice * ChildsWithoutChange;
                console.log('double price withoutchangedoublePriceTot '+withoutchangedoublePriceTot);
                var totalChildDoublePrice = +changedoublePriceTot + +withoutchangedoublePriceTot;
                var totalChildDoubleGrandP = totalChildDoublePrice;
                
            } else {
                var totalChildDoublePrice = doubleChild * doubleChildPrice;
                var totalChildDoubleGrandP = totalChildDoublePrice;
            }
          
          
          totalChildDoubleGrandP = totalChildDoubleGrandP.toFixed(2);
          $('#double_child_total_without_dic').val(totalChildDoubleGrandP);
          $('#double_child_total_without_dic_p').html(totalChildDoubleGrandP);
          
          
          if(doubleChilddiscType == '%'){
              if(doubleChilddiscValue >100){
                  $('#double_child_disc').val(100);
                  doubleChilddiscValue = 100;
              }
              var discunt_am = (totalChildDoubleGrandP * doubleChilddiscValue) / 100;
              totalChildDoubleGrandP = totalChildDoubleGrandP - discunt_am;
          }else{

              var discountPP = doubleChilddiscValue;
              var totalDiscount = discountPP * doubleChild;
              
              if(totalDiscount != 0){
                  $('#double_child_disc_total').val(totalDiscount);
              }
              
              var totalDiscount = $('#double_child_disc_total').val();
              totalChildDoubleGrandP = totalChildDoubleGrandP - totalDiscount;
          }
          
          totalChildDoubleGrandP = totalChildDoubleGrandP.toFixed(2);
          $('#double_child_total').val(totalChildDoubleGrandP);
          $('#double_child_total_p').html(totalChildDoubleGrandP);
      }
      
      function childTripleCalc(){
          var tripleChild = $('#triple_acc_child').val();
          var tripleChildPrice = $('#triple_child_price').val();
          var tripleChilddiscType = $('#triple_child_discount_type').val();
          var tripleChilddiscValue = $('#triple_child_disc').val();
          
            if(tripleChild <= 0){
                $('#triple_child_visa_persons').val('');
             }
             
              
             
             if ($("#triple_child_visa_check").is(':checked')) {
                 var ChildsChange = $('#triple_child_visa_persons').val();
                 var visa_actual_price = $('#visa_actual_price').val();
                 var visa_change_price = $('#visa_actual_price_change_triple_child').val();
                 var ChildsWithoutChange = tripleChild - ChildsChange;
                 
                 var changetriplePrice = +(tripleChildPrice - visa_actual_price) + +visa_change_price;
                 console.log('triple price change'+changetriplePrice);
                 var changetriplePriceTot = changetriplePrice * ChildsChange;
                              console.log('triple price changetriplePriceTot '+changetriplePriceTot);
                              console.log('Childs without change '+ChildsWithoutChange);
                 
                 var withoutchangetriplePriceTot = tripleChildPrice * ChildsWithoutChange;
                 console.log('triple price withoutchangetriplePriceTot '+withoutchangetriplePriceTot);
                 var totaltripleChildPrice = +changetriplePriceTot + +withoutchangetriplePriceTot;
                 var totaltripleChildGrandP = totaltripleChildPrice;
                 
             } else {
                 var totaltripleChildPrice = tripleChild * tripleChildPrice;
                 var totaltripleChildGrandP = totaltripleChildPrice;
             }
          
          totaltripleChildGrandP = totaltripleChildGrandP.toFixed(2)
          $('#triple_child_total_without_dic').val(totaltripleChildGrandP);
          $('#triple_child_total_without_dic_p').html(totaltripleChildGrandP);
          
          
          if(tripleChilddiscType == '%'){
              if(tripleChilddiscValue >100){
                  $('#triple_child_disc').val(100);
                  tripleChilddiscValue = 100;
              }
              var discunt_am = (totaltripleChildGrandP * tripleChilddiscValue) / 100;
              totaltripleChildGrandP = totaltripleChildGrandP - discunt_am;
          }else{
              var discountPP = tripleChilddiscValue;
              var totalDiscount = discountPP * tripleChild;
              
              if(totalDiscount != 0){
                  $('#triple_child_disc_total').val(totalDiscount);
              }
              
              var totalDiscount = $('#triple_child_disc_total').val();
              totaltripleChildGrandP = totaltripleChildGrandP - totalDiscount;
          }
          
          totaltripleChildGrandP = totaltripleChildGrandP.toFixed(2)
          $('#triple_child_total').val(totaltripleChildGrandP);
          $('#triple_child_total_p').html(totaltripleChildGrandP);
      }
      
      function childQuadCalc(){
          var childQuad = $('#quad_acc_child').val();
          var childQuadPrice = $('#quad_child_price').val();
          var childQuaddiscType = $('#quad_child_discount_type').val();
          var childQuaddiscValue = $('#quad_child_disc').val();
          
          
          if(childQuad <= 0){
                $('#quad_child_visa_persons').val('');
             }
             
              
             
             if ($("#quad_child_visa_check").is(':checked')) {
                 var ChildsChange = $('#quad_child_visa_persons').val();
                 var visa_actual_price = $('#visa_actual_price').val();
                 var visa_change_price = $('#visa_actual_price_change_quad_child').val();
                 var ChildsWithoutChange = childQuad - ChildsChange;
                 
                 var changequadPrice = +(childQuadPrice - visa_actual_price) + +visa_change_price;
                 console.log('quad price change'+changequadPrice);
                 var changequadPriceTot = changequadPrice * ChildsChange;
                              console.log('quad price changequadPriceTot '+changequadPriceTot);
                              console.log('Childs without change '+ChildsWithoutChange);
                 
                 var withoutchangequadPriceTot = childQuadPrice * ChildsWithoutChange;
                 console.log('quad price withoutchangequadPriceTot '+withoutchangequadPriceTot);
                 var totalchildQuadPrice = +changequadPriceTot + +withoutchangequadPriceTot;
                 var totalchildQuadGrandP = totalchildQuadPrice;
                 
             } else {
                 var totalchildQuadPrice = childQuad * childQuadPrice;
                 var totalchildQuadGrandP = totalchildQuadPrice;
             }
          

          totalchildQuadGrandP = totalchildQuadGrandP.toFixed(2);
          $('#quad_child_total_without_dic').val(totalchildQuadGrandP);
          $('#quad_child_total_without_dic_p').html(totalchildQuadGrandP);
          
          
          if(childQuaddiscType == '%'){
              if(childQuaddiscValue >100){
                  $('#quad_child_disc').val(100);
                  childQuaddiscValue = 100;
              }
              var discunt_am = (totalchildQuadGrandP * childQuaddiscValue) / 100;
              totalchildQuadGrandP = totalchildQuadGrandP - discunt_am;
          }else{

              var discountPP = childQuaddiscValue;
              var totalDiscount = discountPP * childQuad;
              
              if(totalDiscount != 0){
                  $('#quad_child_disc_total').val(totalDiscount);
              }
              
              var totalDiscount = $('#quad_child_disc_total').val();
              totalchildQuadGrandP = totalchildQuadGrandP - totalDiscount;
          }
          
          totalchildQuadGrandP = totalchildQuadGrandP.toFixed(2);
          $('#quad_child_total').val(totalchildQuadGrandP);
          $('#quad_child_total_p').html(totalchildQuadGrandP);
      }
      
      function infantWithoutAccomCalc(){
          var WithoutAccomInfant = $('#without_acc_infant').val();
          var WithoutAccomInfantPrice = $('#without_acc_infant_price').val();
          var WithoutAccomInfantdiscType = $('#without_acc_infant_discount_type').val();
          var WithoutAccomInfantdiscValue = $('#without_acc_infant_disc').val();
          
           if(WithoutAccomInfant <= 0){
                $('#without_acc_infant_visa_persons').val('');
             }
             
              
             
             if ($("#without_acc_infant_visa_check").is(':checked')) {
                 var infantChange = $('#without_acc_infant_visa_persons').val();
                 var visa_actual_price = $('#visa_actual_price').val();
                 var visa_change_price = $('#visa_actual_price_change_without_acc_infant').val();
                 var infantWithoutChange = WithoutAccomInfant - infantChange;
                 
                 var changequadPrice = +(WithoutAccomInfantPrice - visa_actual_price) + +visa_change_price;
                 console.log('quad price change'+changequadPrice);
                 var changequadPriceTot = changequadPrice * infantChange;
                              console.log('quad price changequadPriceTot '+changequadPriceTot);
                              console.log('infant without change '+infantWithoutChange);
                 
                 var withoutchangequadPriceTot = WithoutAccomInfantPrice * infantWithoutChange;
                 console.log('quad price withoutchangequadPriceTot '+withoutchangequadPriceTot);
                 var totalInfantWithoutAccomPrice = +changequadPriceTot + +withoutchangequadPriceTot;
                 var totalInfantWithoutAccomGrandP = totalInfantWithoutAccomPrice;
                 
             } else {
                 var totalInfantWithoutAccomPrice = WithoutAccomInfant * WithoutAccomInfantPrice;
                 var totalInfantWithoutAccomGrandP = totalInfantWithoutAccomPrice;
             }
          
          
          totalInfantWithoutAccomGrandP = totalInfantWithoutAccomGrandP.toFixed(2)
          $('#without_acc_infant_total_without_dic').val(totalInfantWithoutAccomGrandP);
          $('#without_acc_infant_total_without_dic_p').html(totalInfantWithoutAccomGrandP);
          
          
          if(WithoutAccomInfantdiscType == '%'){
              if(WithoutAccomInfantdiscValue >100){
                  $('#without_acc_infant_disc').val(100);
                  WithoutAccomInfantdiscValue = 100;
              }
              var discunt_am = (totalInfantWithoutAccomGrandP * WithoutAccomInfantdiscValue) / 100;
              totalInfantWithoutAccomGrandP = totalInfantWithoutAccomGrandP - discunt_am;
          }else{
              var discountPP = WithoutAccomInfantdiscValue;
              var totalDiscount = discountPP * WithoutAccomInfant;
              
              if(totalDiscount != 0){
                  $('#without_acc_infant_disc_total').val(totalDiscount);
              }
              
              var totalDiscount = $('#without_acc_infant_disc_total').val();
              totalInfantWithoutAccomGrandP = totalInfantWithoutAccomGrandP - totalDiscount;
          }
          
          totalInfantWithoutAccomGrandP = totalInfantWithoutAccomGrandP.toFixed(2)
          $('#without_acc_infant_total').val(totalInfantWithoutAccomGrandP);
          $('#without_acc_infant_total_p').html(totalInfantWithoutAccomGrandP);
      }
      
      function infantDoubleCalc(){
          var doubleInfant = $('#double_acc_infant').val();
          var doubleInfantPrice = $('#double_infant_price').val();
          var doubleInfantdiscType = $('#double_infant_discount_type').val();
          var doubleInfantdiscValue = $('#double_infant_disc').val();
          
         if(doubleInfant <= 0){
               $('#double_infant_visa_persons').val('');
            }
            
             
            
            if ($("#double_infant_visa_check").is(':checked')) {
                var InfantsChange = $('#double_infant_visa_persons').val();
                var visa_actual_price = $('#visa_actual_price').val();
                var visa_change_price = $('#visa_actual_price_change_double_infant').val();
                var InfantsWithoutChange = doubleInfant - InfantsChange;
                
                var changedoublePrice = +(doubleInfantPrice - visa_actual_price) + +visa_change_price;
                console.log('double price change'+changedoublePrice);
                var changedoublePriceTot = changedoublePrice * InfantsChange;
                             console.log('double price changedoublePriceTot '+changedoublePriceTot);
                             console.log('Infants without change '+InfantsWithoutChange);
                
                var withoutchangedoublePriceTot = doubleInfantPrice * InfantsWithoutChange;
                console.log('double price withoutchangedoublePriceTot '+withoutchangedoublePriceTot);
                var totalInfantDoublePrice = +changedoublePriceTot + +withoutchangedoublePriceTot;
                var totalInfantDoubleGrandP = totalInfantDoublePrice;
                
            } else {
                var totalInfantDoublePrice = doubleInfant * doubleInfantPrice;
                var totalInfantDoubleGrandP = totalInfantDoublePrice;
            }
          
          totalInfantDoubleGrandP = totalInfantDoubleGrandP.toFixed(2)
          $('#double_infant_total_without_dic').val(totalInfantDoubleGrandP);
          $('#double_infant_total_without_dic_p').html(totalInfantDoubleGrandP);
          
          
          if(doubleInfantdiscType == '%'){
              if(doubleInfantdiscValue >100){
                  $('#double_infant_disc').val(100);
                  doubleInfantdiscValue = 100;
              }
              var discunt_am = (totalInfantDoubleGrandP * doubleInfantdiscValue) / 100;
              totalInfantDoubleGrandP = totalInfantDoubleGrandP - discunt_am;
          }else{

              var discountPP = doubleInfantdiscValue;
              var totalDiscount = discountPP * doubleInfant;
              
              if(totalDiscount != 0){
                  $('#double_infant_disc_total').val(totalDiscount);
              }
              
              var totalDiscount = $('#double_infant_disc_total').val();
              totalInfantDoubleGrandP = totalInfantDoubleGrandP - totalDiscount;
          }
          
          totalInfantDoubleGrandP = totalInfantDoubleGrandP.toFixed(2)
          $('#double_infant_total').val(totalInfantDoubleGrandP);
          $('#double_infant_total_p').html(totalInfantDoubleGrandP);
      }
      
      function infantTripleCalc(){
          var tripleInfant = $('#triple_acc_infant').val();
          var tripleInfantPrice = $('#triple_infant_price').val();
          var tripleInfantdiscType = $('#triple_infant_discount_type').val();
          var tripleInfantdiscValue = $('#triple_infant_disc').val();
          
             if(tripleInfant <= 0){
                $('#triple_infant_visa_persons').val('');
             }
             
              
             
             if ($("#triple_infant_visa_check").is(':checked')) {
                 var InfantsChange = $('#triple_infant_visa_persons').val();
                 var visa_actual_price = $('#visa_actual_price').val();
                 var visa_change_price = $('#visa_actual_price_change_triple_infant').val();
                 var InfantsWithoutChange = tripleInfant - InfantsChange;
                 
                 var changetriplePrice = +(tripleInfantPrice - visa_actual_price) + +visa_change_price;
                 console.log('triple price change'+changetriplePrice);
                 var changetriplePriceTot = changetriplePrice * InfantsChange;
                              console.log('triple price changetriplePriceTot '+changetriplePriceTot);
                              console.log('Infants without change '+InfantsWithoutChange);
                 
                 var withoutchangetriplePriceTot = tripleInfantPrice * InfantsWithoutChange;
                 console.log('triple price withoutchangetriplePriceTot '+withoutchangetriplePriceTot);
                 var totaltripleInfantPrice = +changetriplePriceTot + +withoutchangetriplePriceTot;
                 var totaltripleInfantGrandP = totaltripleInfantPrice;
                 
             } else {
                 var totaltripleInfantPrice = tripleInfant * tripleInfantPrice;
                 var totaltripleInfantGrandP = totaltripleInfantPrice;
             }
          
          totaltripleInfantGrandP = totaltripleInfantGrandP.toFixed(2)
          $('#triple_infant_total_without_dic').val(totaltripleInfantGrandP);
          $('#triple_infant_total_without_dic_p').html(totaltripleInfantGrandP);
          
          
          if(tripleInfantdiscType == '%'){
              if(tripleInfantdiscValue >100){
                  $('#triple_infant_disc').val(100);
                  tripleInfantdiscValue = 100;
              }
              var discunt_am = (totaltripleInfantGrandP * tripleInfantdiscValue) / 100;
              totaltripleInfantGrandP = totaltripleInfantGrandP - discunt_am;
          }else{

              var discountPP = tripleInfantdiscValue;
              var totalDiscount = discountPP * tripleInfant;
              
              if(totalDiscount != 0){
                  $('#triple_infant_disc_total').val(totalDiscount);
              }
              
              var totalDiscount = $('#triple_infant_disc_total').val();
              totaltripleInfantGrandP = totaltripleInfantGrandP - totalDiscount;
          }
          
          totaltripleInfantGrandP = totaltripleInfantGrandP.toFixed(2)
          $('#triple_infant_total').val(totaltripleInfantGrandP);
          $('#triple_infant_total_p').html(totaltripleInfantGrandP);
      }
      
      function infantQuadCalc(){
          var childQuad = $('#quad_acc_infant').val();
          var childQuadPrice = $('#quad_infant_price').val();
          var childQuaddiscType = $('#quad_infant_discount_type').val();
          var childQuaddiscValue = $('#quad_infant_disc').val();
          
            if(childQuad <= 0){
                $('#quad_infant_visa_persons').val('');
             }
             
              
             
             if ($("#quad_infant_visa_check").is(':checked')) {
                 var InfantsChange = $('#quad_infant_visa_persons').val();
                 var visa_actual_price = $('#visa_actual_price').val();
                 var visa_change_price = $('#visa_actual_price_change_quad_infant').val();
                 var InfantsWithoutChange = childQuad - InfantsChange;
                 
                 var changequadPrice = +(childQuadPrice - visa_actual_price) + +visa_change_price;
                 console.log('quad price change'+changequadPrice);
                 var changequadPriceTot = changequadPrice * InfantsChange;
                              console.log('quad price changequadPriceTot '+changequadPriceTot);
                              console.log('Infants without change '+InfantsWithoutChange);
                 
                 var withoutchangequadPriceTot = childQuadPrice * InfantsWithoutChange;
                 console.log('quad price withoutchangequadPriceTot '+withoutchangequadPriceTot);
                 var totalchildQuadPrice = +changequadPriceTot + +withoutchangequadPriceTot;
                 var totalchildQuadGrandP = totalchildQuadPrice;
                 
             } else {
                 var totalchildQuadPrice = childQuad * childQuadPrice;
                 var totalchildQuadGrandP = totalchildQuadPrice;
             }
          
          totalchildQuadGrandP = totalchildQuadGrandP.toFixed(2);
          $('#quad_infant_total_without_dic').val(totalchildQuadGrandP);
          $('#quad_infant_total_without_dic_p').html(totalchildQuadGrandP);
          
          
          if(childQuaddiscType == '%'){
              if(childQuaddiscValue >100){
                  $('#quad_infant_disc').val(100);
                  childQuaddiscValue = 100;
              }
              var discunt_am = (totalchildQuadGrandP * childQuaddiscValue) / 100;
              totalchildQuadGrandP = totalchildQuadGrandP - discunt_am;
          }else{

              var discountPP = childQuaddiscValue;
              var totalDiscount = discountPP * childQuad;
              
              if(totalDiscount != 0){
                  $('#quad_infant_disc_total').val(totalDiscount);
              }
              
              var totalDiscount = $('#quad_infant_disc_total').val();
              totalchildQuadGrandP = totalchildQuadGrandP - totalDiscount;
          }
          
          totalchildQuadGrandP = totalchildQuadGrandP.toFixed(2);
          $('#quad_infant_total').val(totalchildQuadGrandP);
          $('#quad_infant_total_p').html(totalchildQuadGrandP);
      }
    
      
      function caluclateGrandTotal(){
          adultDoubleCalc();
          adultTripleCalc();
          adultQuadCalc();
          adultWithoutAccomCalc();
          
          childWithoutAccomCalc();
          childDoubleCalc();
          childTripleCalc();
          childQuadCalc();
          
          infantWithoutAccomCalc();
          infantDoubleCalc();
          infantTripleCalc();
          infantQuadCalc()
          
           var grandTotalAmount = 0;
                   var subTotalAmount = 0;
        @if($tour_details->double_grand_total_amount != 0 AND $tour_details->double_grand_total_amount != null) 
              var double_adult_total = $('#double_adult_total').val();
              grandTotalAmount = +grandTotalAmount + +double_adult_total
              
              
              
     
              var double_adult_sub_total = $('#double_adult_total_without_dic').val();
              subTotalAmount = +subTotalAmount + +double_adult_sub_total
              
              
                 // For Double Childs
              var double_child_total = $('#double_child_total').val();
              grandTotalAmount = +grandTotalAmount + +double_child_total
              
              var double_child_sub_total = $('#double_child_total_without_dic').val();
              subTotalAmount = +subTotalAmount + +double_child_sub_total
              
              
                      // For Double Infants
              var double_infant_total = $('#double_infant_total').val();
              grandTotalAmount = +grandTotalAmount + +double_infant_total
              
              var double_infant_sub_total = $('#double_infant_total_without_dic').val();
              subTotalAmount = +subTotalAmount + +double_infant_sub_total
              
          @endif
          
          
          @if($tour_details->triple_grand_total_amount != 0 AND $tour_details->triple_grand_total_amount != null) 
               // For Triple Adults
              var triple_adult_total = $('#triple_adult_total').val();
              grandTotalAmount = +grandTotalAmount + +triple_adult_total
              
              var triple_adult_sub_total = $('#triple_adult_total_without_dic').val();
              subTotalAmount = +subTotalAmount + +triple_adult_sub_total
              
              console.log('Grand total is '+grandTotalAmount)
              
                
              // For Triple Childs
              var triple_child_total = $('#triple_child_total').val();
              grandTotalAmount = +grandTotalAmount + +triple_child_total
              
              var triple_child_sub_total = $('#triple_child_total_without_dic').val();
              subTotalAmount = +subTotalAmount + +triple_child_sub_total
              
              
                 // For Triple Infant
              var triple_infant_total = $('#triple_infant_total').val();
              grandTotalAmount = +grandTotalAmount + +triple_infant_total
              
              var triple_infant_sub_total = $('#triple_infant_total_without_dic').val();
              subTotalAmount = +subTotalAmount + +triple_infant_sub_total
              
           @endif
           
           
           @if($tour_details->quad_grand_total_amount != 0 AND $tour_details->quad_grand_total_amount != null) 
                  // For Quad Adults
                  var quad_adult_total = $('#quad_adult_total').val();
                  grandTotalAmount = +grandTotalAmount + +quad_adult_total
                  
                  var quad_adult_sub_total = $('#quad_adult_total_without_dic').val();
                  subTotalAmount = +subTotalAmount + +quad_adult_sub_total
                  
                  console.log('Grand total is '+grandTotalAmount)
                  
                            
                        // For Quad Childs
                  var quad_child_total = $('#quad_child_total').val();
                  grandTotalAmount = +grandTotalAmount + +quad_child_total
                  
                  var quad_child_sub_total = $('#quad_child_total_without_dic').val();
                  subTotalAmount = +subTotalAmount + +quad_child_sub_total
                  
                        // For Quad Infant
                  var quad_infant_total = $('#quad_infant_total').val();
                  grandTotalAmount = +grandTotalAmount + +quad_infant_total
                  
                  var quad_infant_sub_total = $('#quad_infant_total_without_dic').val();
                  subTotalAmount = +subTotalAmount + +quad_infant_sub_total
          
          @endif
          
          @if($tour_details->without_acc_sale_price != 0 AND $tour_details->without_acc_sale_price != null) 
              // For Without Accomodation Adults
              var without_acc_adult_total = $('#without_acc_adult_total').val();
              grandTotalAmount = +grandTotalAmount + +without_acc_adult_total
              
              var without_acc_adult_sub_total = $('#without_acc_adult_total_without_dic').val();
              subTotalAmount = +subTotalAmount + +without_acc_adult_sub_total
    
              
          @endif
          console.log('Grand total is '+grandTotalAmount)
          
          // For Without Accomodation Childs
          var without_acc_child_total = $('#without_acc_child_total').val();
          grandTotalAmount = +grandTotalAmount + +without_acc_child_total
          
          var without_acc_child_sub_total = $('#without_acc_child_total_without_dic').val();
          subTotalAmount = +subTotalAmount + +without_acc_child_sub_total
          
       
        
          
     
          
          
          
           // For Without Accomodation Infant
          var without_acc_infant_total = $('#without_acc_infant_total').val();
          grandTotalAmount = +grandTotalAmount + +without_acc_infant_total
          
          var without_acc_infant_sub_total = $('#without_acc_infant_total_without_dic').val();
          subTotalAmount = +subTotalAmount + +without_acc_infant_sub_total
          
   
          
          
          //-----------------------------------------
          // Grand Discount
          //-----------------------------------------
          var over_all_discount_type = $('#over_all_discount_type').val();
          var over_all_discount_value = $('#over_all_discount_value').val();
          
          
          
        
          if(over_all_discount_type == '%'){
              if(over_all_discount_value >100){
                  $('#over_all_discount_value').val(100);
                  over_all_discount_value = 100;
              }
              var discunt_am_over_all = (grandTotalAmount * over_all_discount_value) / 100;
              grandTotalAmount = grandTotalAmount - discunt_am_over_all;
          }else{
              grandTotalAmount = grandTotalAmount - over_all_discount_value;
          }
          
          var discount = subTotalAmount - grandTotalAmount;
          
          
          //-----------------------------------------
          // Grand Discount
          //-----------------------------------------
          var agent_commission_type = $('#agent_commission_type').val();
          var agent_commission_value = $('#agent_commission_value').val();
          
            if ($("#add_commission").is(':checked')) {
                var commissonAdd = true;
            } else {
                var commissonAdd = false;
            }
          
          
          
         var commsion_am_over_all = 0;
          if(agent_commission_type == '%'){
              if(agent_commission_value >100){
                  $('#agent_commission_value').val(100);
                  agent_commission_value = 100;
              }
              var commsion_am_over_all = (grandTotalAmount * agent_commission_value) / 100;
              if(commissonAdd){
                   grandTotalAmount = +grandTotalAmount + +commsion_am_over_all;
              }
          }else{
              commsion_am_over_all = agent_commission_value;

              if(commissonAdd){
                    grandTotalAmount = +grandTotalAmount + +agent_commission_value;
              }
          }
          
          
          $('#agent_commsion_am_p').html(commsion_am_over_all);
          $('#agent_commsion_am').val(commsion_am_over_all);
          
          $('#finalGrandTotal').val(grandTotalAmount);
          $('#finalGrandTotal_p').html(grandTotalAmount);
          
     
          
          
          
          $('#grandDiscount_p').html(discount);
          $('#grandDiscount').val(discount);
          
        //   
          $('#subTotal').val(subTotalAmount);
          $('#subTotal_p').html(subTotalAmount);
      }
      
   
    
    $('#double_adult').on('keyup change',function(){
      
        
       checkChildInfantDoubleAv();
       checkDoubleRemaingCap();
       checkDoubleAv();
        caluclateGrandTotal();
    })
    
    $('#double_adult_disc').on('keyup change',function(){
        
        if(!$('#double_adult_disc').val()){
            $('#double_adult_disc_total').val('');
        }
       caluclateGrandTotal();
    })
    
     $('#double_adult_disc_total').on('keyup change',function(){
       caluclateGrandTotal();
    })
    
    $('#double_adult_discount_type').on('change',function(){
       caluclateGrandTotal();
    })
    
     $('#triple_adult').on('keyup change',function(){
       
       checkChildInfantTripleAv();
       checkTripleRemaingCap();
       checkTripleAv();
       caluclateGrandTotal();
    })
    
    $('#triple_adult_disc').on('keyup change',function(){
        if(!$('#triple_adult_disc').val()){
            $('#triple_adult_disc_total').val('');
        }
       caluclateGrandTotal();
    })
    
    $('#triple_adult_disc_total').on('keyup change',function(){
       
       caluclateGrandTotal();
    })
    
    $('#triple_adult_discount_type').on('change',function(){
       caluclateGrandTotal();
    })
    
     $('#quad_adult').on('keyup change',function(){
       
       checkChildInfantQuadAv();
       checkQuadRemaingCap();
       checkTripleAv();
       caluclateGrandTotal();
    })
    
    $('#quad_adult_disc').on('keyup change',function(){
        if(!$('#quad_adult_disc').val()){
            $('#quad_adult_disc_total').val('');
        }
       caluclateGrandTotal();
    })
    
     $('#quad_adult_disc_total').on('keyup change',function(){
       
       caluclateGrandTotal();
    })
    
    $('#quad_adult_discount_type').on('change',function(){
       caluclateGrandTotal();
    })
    
    $('#without_acc_adult').on('keyup change',function(){
       caluclateGrandTotal();
    })
    
    $('#without_acc_adult_disc').on('keyup change',function(){
         if(!$('#without_acc_adult_disc').val()){
            $('#without_acc_adult_disc_total').val('');
        }
       caluclateGrandTotal();
    })
   
    $('#without_acc_adult_disc_total').on('keyup change',function(){
       caluclateGrandTotal();
    })
    
    $('#without_acc_adult_discount_type').on('change',function(){
       caluclateGrandTotal();
    })
    
    
    
    
     $('#without_acc_child').on('keyup change',function(){
         
       caluclateGrandTotal();
    })
    
    $('#without_acc_child_disc').on('keyup change',function(){
        if(!$('#without_acc_child_disc').val()){
            $('#without_acc_child_disc_total').val('');
        }
       caluclateGrandTotal();
    })
    
    $('#without_acc_child_disc_total').on('keyup change',function(){
         
       caluclateGrandTotal();
    })
    
    
    $('#without_acc_child_discount_type').on('change',function(){
       caluclateGrandTotal();
    })
    
    $('#double_acc_child').on('keyup change',function(){
       checkDoubleChildOrInfantHide('',false,'double_acc_child');
       checkDoubleChildAv();
       caluclateGrandTotal();
       
    })
    
    $('#double_child_disc').on('keyup change',function(){
        if(!$('#double_child_disc').val()){
            $('#double_child_disc_total').val('');
        }
       caluclateGrandTotal();
    })
    
    $('#double_child_disc_total').on('keyup change',function(){
       caluclateGrandTotal();
    })
    
    $('#double_child_discount_type').on('change',function(){
       caluclateGrandTotal();
    })
    
    $('#triple_acc_child').on('keyup change',function(){
       checkTripleChildOrInfantHide('',false,'triple_acc_child');
       checkTripleChildAv();
       caluclateGrandTotal();
    })
    
    $('#triple_child_disc').on('keyup change',function(){
        if(!$('#triple_child_disc').val()){
            $('#triple_child_disc_total').val('');
        }
       caluclateGrandTotal();
    })
    
    $('#triple_child_disc_total').on('keyup change',function(){
    
       caluclateGrandTotal();
    })
    
    $('#triple_child_discount_type').on('change',function(){
       caluclateGrandTotal();
    })
    
    $('#quad_acc_child').on('keyup change',function(){
       checkQuadChildOrInfantHide('',false,'quad_acc_child');
       checkQuadChildAv();
       caluclateGrandTotal();
    })
    
    $('#quad_child_disc').on('keyup change',function(){
         if(!$('#quad_child_disc').val()){
            $('#quad_child_disc_total').val('');
        }
       caluclateGrandTotal();
    })
    
     $('#quad_child_disc_total').on('keyup change',function(){
     
       caluclateGrandTotal();
    })
    
    $('#quad_child_discount_type').on('change',function(){
       caluclateGrandTotal();
    })
    
    
    
     $('#without_acc_infant').on('keyup change',function(){
       caluclateGrandTotal();
    })
    
    $('#without_acc_infant_disc').on('keyup change',function(){
           if(!$('#without_acc_infant_disc').val()){
            $('#without_acc_infant_disc_total').val('');
        }
       caluclateGrandTotal();
    })
    
      $('#without_acc_infant_disc_total').on('keyup change',function(){
        
       caluclateGrandTotal();
    })
    
    $('#without_acc_infant_discount_type').on('change',function(){
       caluclateGrandTotal();
    })
    
     $('#double_acc_infant').on('keyup change',function(){
       checkDoubleChildOrInfantHide('',false,'double_acc_child');
       checkDoubleInfantdAv();
       caluclateGrandTotal();
    })
    
    $('#double_infant_disc').on('keyup change',function(){
        if(!$('#double_infant_disc').val()){
            $('#double_infant_disc_total').val('');
        }
       caluclateGrandTotal();
    })
    
     $('#double_infant_disc_total').on('keyup change',function(){
     
       caluclateGrandTotal();
    })
    
    $('#double_infant_discount_type').on('change',function(){
       caluclateGrandTotal();
    })
    
    $('#triple_acc_infant').on('keyup change',function(){
       checkTripleChildOrInfantHide('',false,'triple_acc_infant');
       checkTripleInfantdAv();
       caluclateGrandTotal();
    })
    
    $('#triple_infant_disc').on('keyup change',function(){
         if(!$('#triple_infant_disc').val()){
            $('#triple_infant_disc_total').val('');
        }
       caluclateGrandTotal();
    })
    
     $('#triple_infant_disc_total').on('keyup change',function(){
        
       caluclateGrandTotal();
    })
    
    $('#triple_infant_discount_type').on('change',function(){
       caluclateGrandTotal();
    })
    
    $('#quad_acc_infant').on('keyup change',function(){
       checkQuadChildOrInfantHide('',false,'quad_acc_infant');
       checkQuadInfantdAv();
       caluclateGrandTotal();
    })
    
    $('#quad_infant_disc').on('keyup change',function(){
        if(!$('#quad_infant_disc').val()){
            $('#quad_infant_disc_total').val('');
        }
       caluclateGrandTotal();
    })
    
    $('#quad_infant_disc_total').on('keyup change',function(){
   
       caluclateGrandTotal();
    })
    
    $('#quad_infant_discount_type').on('change',function(){
       caluclateGrandTotal();
    })
    
    
    $('#over_all_discount_value').on('keyup change',function(){
       caluclateGrandTotal();
    })
    
    $('#over_all_discount_type').on('change',function(){
       caluclateGrandTotal();
    })
    
     $('#agent_commission_value').on('keyup change',function(){
       caluclateGrandTotal();
    })
    
    $('#agent_commission_type').on('change',function(){
       caluclateGrandTotal();
    })
    
    ///////////////////////////////////////////////////////
    // Rooms Select Conditions Double
    ///////////////////////////////////////////////////////
    
    
    
    function checkDoubleAv(){
          var doubleRooms = $('#double_rooms').val();
         var doubleAdutls = $('#double_adult').val();
         
         doubTotalCapcity = doubleRooms * 2;
         var remainingCapcity = doubTotalCapcity - doubleAdutls;
         $('#double_remaing_space').val(remainingCapcity);
    }
    
    function checkChildInfantDoubleAv(){
         var doubleRooms = $('#double_rooms').val();
         var doubleAdutls = $('#double_adult').val();
         
         doubTotalCapcity = doubleRooms * 2;
         var remainingCapcity = doubTotalCapcity - doubleAdutls;
         if(doubleAdutls < doubTotalCapcity){
             $('#childroom1').attr('disabled',false);
             $('#infantroom1').attr('disabled',false);
         }else{
              $('#childroom1').attr('disabled',true);
              $("#childroom1").prop("checked", false);
              $('#infantroom1').attr('disabled',true);
              $('#infantroom1').prop('checked',false);
              
              $('#double_acc_child').val('');
              $('#double_child_disc').val(0);
              $('#double_acc_child_prev').val(0);
              
              $('#double_acc_infant').val('');
              $('#double_infant_disc').val(0);
              $('#infant_acc_child_prev').val(0);
              
              
              $('.double_child').css('display','none');
              $('.double_infant').css('display','none');
              caluclateGrandTotal();
              
         }
    }
    
    function checkDoubleRemaingCap(){
        var doubleRooms = $('#double_rooms').val();
        var doubleAdutls = $('#double_adult').val();
         
        doubTotalCapcity = doubleRooms * 2;
        var remainingCapcity = doubTotalCapcity - doubleAdutls;
        var StarDoubleRem  = remainingCapcity;
        
        console.log('start remain'+remainingCapcity);
        
        console.log('remainingCapcity'+remainingCapcity);
            
            
            if($("#childroom1").is(':checked')) {
              console.log('Child is checked')
              var double_acc_child = $('#double_acc_child').val();
              
              var afterChildremainingCapcity = remainingCapcity - double_acc_child;
              
              if(afterChildremainingCapcity < 0){
                  $('#childroom1').attr('disabled',true);
                  $("#childroom1").prop("checked", false);
                  $('#infantroom1').attr('disabled',true);
                  $('#infantroom1').prop('checked',false);
                  
                  $('#double_acc_child').val('');
                  $('#double_child_disc').val(0);
                  $('#double_acc_child_prev').val(0);
                  
                  $('#double_acc_infant').val('');
                  $('#double_infant_disc').val(0);
                  $('#infant_acc_child_prev').val(0);
                  
                  
                  $('.double_child').css('display','none');
                  $('.double_infant').css('display','none');
                  
                //   checkDoubleRemaingCap();
                  checkChildInfantDoubleAv();
                  caluclateGrandTotal();
              }else{
                   remainingCapcity = remainingCapcity - double_acc_child;
              }
             
              
              
                                    console.log('remainingCapcity'+remainingCapcity);

            }
            
            if($("#infantroom1").is(':checked')) {
              console.log('infant is checked')
              var double_acc_infant = $('#double_acc_infant').val();
              var afterInfantremainingCapcity = remainingCapcity - double_acc_infant;
              
              console.log('remainingCapcitylastber'+remainingCapcity);
              
              if(afterInfantremainingCapcity < 0){
                  $('#childroom1').attr('disabled',true);
                  $("#childroom1").prop("checked", false);
                  $('#infantroom1').attr('disabled',true);
                  $('#infantroom1').prop('checked',false);
                  
                  $('#double_acc_child').val('');
                  $('#double_child_disc').val(0);
                  $('#double_acc_child_prev').val(0);
                  
                  $('#double_acc_infant').val('');
                  $('#double_infant_disc').val(0);
                  $('#infant_acc_child_prev').val(0);
                  
                  
                  $('.double_child').css('display','none');
                  $('.double_infant').css('display','none');
                //   checkDoubleRemaingCap();
                  checkChildInfantDoubleAv();
                  caluclateGrandTotal();
              }else{
                  console.log('Enter in infant sele');
                   remainingCapcity = remainingCapcity - double_acc_infant;
              }
              
              
                      console.log('remainingCapcitylast'+remainingCapcity);
                      
                      

            }
            
        $('#double_remaing_space').val(remainingCapcity);
        
    }
    
    function checkDoubleChildAv(){
        console.log('double function is call ');
       var availableSpace = $('#double_remaing_space').val();
       var doubleChilds_prev =  $('#double_acc_child_prev').val();
        var doubleChilds = $('#double_acc_child').val();
        
        var enter_childs = doubleChilds - doubleChilds_prev;
         
         console.log(doubleChilds)
         console.log(availableSpace)
         if(enter_childs > availableSpace){
            //  checkDoubleRemaingCap()
             var availableSpace = $('#double_remaing_space').val();
             doubleChilds = $('#double_acc_child_prev').val();
             alert('You can add only '+availableSpace)
             
             if(doubleChilds == 0){
                 $('#double_acc_child').val('');
             }else{
                 $('#double_acc_child').val(doubleChilds);
             }
             
         }else{
             availableSpace = availableSpace - doubleChilds;
             $('#double_remaing_space').val(availableSpace);
              $('#double_acc_child_prev').val(doubleChilds);
              checkDoubleRemaingCap()
         }
        
        
    }
    
     function checkDoubleInfantdAv(){
        console.log('double function is call ');
       var availableSpace = $('#double_remaing_space').val();
       var doubleInfant_prev =  $('#infant_acc_child_prev').val();
        var doubleInfants = $('#double_acc_infant').val();
        
        var enter_infants = doubleInfants - doubleInfant_prev;
         
         if(enter_infants > availableSpace){
            //  checkDoubleRemaingCap()
             var availableSpace = $('#double_remaing_space').val();
             doubleinfants = $('#infant_acc_child_prev').val();
             alert('You can add only '+availableSpace)
             
            if(doubleinfants == 0){
                 $('#double_acc_infant').val('');
             }else{
                  $('#double_acc_infant').val(doubleinfants);
             }
             
           
         }else{
             availableSpace = availableSpace - doubleInfants;
             $('#double_remaing_space').val(availableSpace);
              $('#infant_acc_child_prev').val(doubleInfants);
              checkDoubleRemaingCap()
         }
        
        
    }
    

    function checkDoubleChildOrInfantHide(clickItem,displayValue,currentelment=null){
         console.log('function is call ');
        var doubleRooms = $('#double_rooms').val();
        var doubleAdutls = $('#double_adult').val();
         
        doubTotalCapcity = doubleRooms * 2;
        var remainingCapcity = doubTotalCapcity - doubleAdutls;
        
        if(remainingCapcity == 1){
            if(clickItem != ''){
                 $('#'+clickItem+'').attr('disabled',displayValue);
            }
           
        }
        
    }
    
    ///////////////////////////////////////////////////////
    // Rooms Select Conditions Triple
    ///////////////////////////////////////////////////////
    
    function checkTripleAv(){
          var tirpleRooms = $('#triple_rooms').val();
         var tirpleAdutls = $('#triple_adult').val();
         
         tripleTotalCapcity = tirpleRooms * 3;
         var remainingCapcity = tripleTotalCapcity - tirpleAdutls;
         $('#triple_remaing_space').val(remainingCapcity);
    }
    
    function checkChildInfantTripleAv(){
         var tripleRooms = $('#triple_rooms').val();
         var tripleAdutls = $('#triple_adult').val();
         
         tripleTotalCapcity = tripleRooms * 3;
         var remainingCapcity = tripleTotalCapcity - tripleAdutls;
         if(tripleAdutls < tripleTotalCapcity){
             $('#childroom2').attr('disabled',false);
             $('#infantroom2').attr('disabled',false);
         }else{
              $('#childroom2').attr('disabled',true);
              $("#childroom2").prop("checked", false);
              $('#infantroom2').attr('disabled',true);
              $('#infantroom2').prop('checked',false);
              
              $('#triple_acc_child').val('');
              $('#triple_child_disc').val(0);
              $('#triple_acc_child_prev').val(0);
              
              $('#triple_acc_infant').val('');
              $('#triple_infant_disc').val(0);
              $('#infant_acc_child_triple_prev').val(0);
              
              
              $('.triple_child').css('display','none');
              $('.triple_infant').css('display','none');
              caluclateGrandTotal();
              
         }
    }
    
    function checkTripleRemaingCap(){
        var tripleRooms = $('#triple_rooms').val();
        var tripleAdutls = $('#triple_adult').val();
         
        tripleTotalCapcity = tripleRooms * 3;
        var remainingCapcity = tripleTotalCapcity - tripleAdutls;
        var StarTripleRem  = remainingCapcity;
        
        console.log('start remain'+remainingCapcity);
        
        console.log('remainingCapcity'+remainingCapcity);
            
            
            if($("#childroom2").is(':checked')) {
              console.log('Child is checked')
              var triple_acc_child = $('#triple_acc_child').val();
              
              var afterChildremainingCapcity = remainingCapcity - triple_acc_child;
              
              if(afterChildremainingCapcity < 0){
                  $('#childroom2').attr('disabled',true);
                  $("#childroom2").prop("checked", false);
                  $('#infantroom2').attr('disabled',true);
                  $('#infantroom2').prop('checked',false);
                  
                  $('#triple_acc_child').val('');
                  $('#triple_child_disc').val(0);
                  $('#triple_acc_child_prev').val(0);
                  
                  $('#triple_acc_infant').val('');
                  $('#triple_infant_disc').val(0);
                  $('#infant_acc_child_triple_prev').val(0);
                  
                  
                  $('.triple_child').css('display','none');
                  $('.triple_infant').css('display','none');
                  
                //   checkDoubleRemaingCap();
                  checkChildInfantTripleAv();
                  caluclateGrandTotal();
              }else{
                   remainingCapcity = remainingCapcity - triple_acc_child;
              }
             
              
              
                                    console.log('remainingCapcity'+remainingCapcity);

            }
            
            if($("#infantroom2").is(':checked')) {
              console.log('infant is checked')
              var triple_acc_infant = $('#triple_acc_infant').val();
              var afterInfantremainingCapcity = remainingCapcity - triple_acc_infant;
              
              console.log('remainingCapcitylastber'+remainingCapcity);
              
              if(afterInfantremainingCapcity < 0){
                  $('#childroom2').attr('disabled',true);
                  $("#childroom2").prop("checked", false);
                  $('#infantroom2').attr('disabled',true);
                  $('#infantroom2').prop('checked',false);
                  
                  $('#triple_acc_child').val('');
                  $('#triple_child_disc').val(0);
                  $('#triple_acc_child_prev').val(0);
                  
                  $('#triple_acc_infant').val('');
                  $('#triple_infant_disc').val(0);
                  $('#infant_acc_child_triple_prev').val(0);
                  
                  
                  $('.triple_child').css('display','none');
                  $('.triple_infant').css('display','none');
                //   checkDoubleRemaingCap();
                  checkChildInfantTripleAv();
                  caluclateGrandTotal();
              }else{
                  console.log('Enter in infant sele');
                   remainingCapcity = remainingCapcity - triple_acc_infant;
              }
              
              
                      console.log('remainingCapcitylast'+remainingCapcity);
                      
                      

            }
            
        $('#triple_remaing_space').val(remainingCapcity);
        
    }
    
     function checkTripleChildAv(){
        console.log('double function is call ');
       var availableSpace = $('#triple_remaing_space').val();
       var tripleChilds_prev =  $('#triple_acc_child_prev').val();
        var tripleChilds = $('#triple_acc_child').val();
        
        var enter_childs = tripleChilds - tripleChilds_prev;
         
         console.log(tripleChilds)
         console.log(availableSpace)
         if(enter_childs > availableSpace){
            //  checkDoubleRemaingCap()
             var availableSpace = $('#triple_remaing_space').val();
             tripleChilds = $('#triple_acc_child_prev').val();
             alert('You have Remaining Capcity in Triple '+availableSpace)
             
             
             if(tripleChilds == 0){
                  $('#triple_acc_child').val('');
             }else{
                  $('#triple_acc_child').val(tripleChilds);
             }
            
         }else{
             availableSpace = availableSpace - tripleChilds;
             $('#triple_remaing_space').val(availableSpace);
             $('#triple_acc_child_prev').val(tripleChilds);
             checkTripleRemaingCap()
         }
        
        
    }
    
    function checkTripleInfantdAv(){
        console.log('double function is call ');
       var availableSpace = $('#triple_remaing_space').val();
       var doubleInfant_prev =  $('#infant_acc_child_triple_prev').val();
        var doubleInfants = $('#triple_acc_infant').val();
        
        var enter_infants = doubleInfants - doubleInfant_prev;
         
         if(enter_infants > availableSpace){
            //  checkDoubleRemaingCap()
             var availableSpace = $('#triple_remaing_space').val();
             doubleinfants = $('#infant_acc_child_triple_prev').val();
             alert('You can add only '+availableSpace)
             
             if(doubleinfants == 0){
                 $('#triple_acc_infant').val('');
             }else{
                 $('#triple_acc_infant').val(doubleinfants);
             }
             
         }else{
             availableSpace = availableSpace - doubleInfants;
             $('#triple_remaing_space').val(availableSpace);
              $('#infant_acc_child_triple_prev').val(doubleInfants);
              checkTripleRemaingCap()
         }
        
        
    }
    
    function checkTripleChildOrInfantHide(clickItem,displayValue,currentelment=null){
         console.log('function is call ');
        var tripleRooms = $('#triple_rooms').val();
         var tripleAdutls = $('#triple_adult').val();
         
         tripleTotalCapcity = tripleRooms * 3;
         var remainingCapcity = tripleTotalCapcity - tripleAdutls;
        
        if(remainingCapcity == 1){
            if(clickItem != ''){
                 $('#'+clickItem+'').attr('disabled',displayValue);
            }
           
        }
        
    }


  ///////////////////////////////////////////////////////
    // Rooms Select Conditions Triple
    ///////////////////////////////////////////////////////
    
    function checkQuadAv(){
          var quadRooms = $('#quad_rooms').val();
         var quadAdutls = $('#quad_adult').val();
         
         quadTotalCapcity = quadRooms * 4;
         var remainingCapcity = quadTotalCapcity - quadAdutls;
         $('#quad_remaing_space').val(remainingCapcity);
    }
    
    function checkChildInfantQuadAv(){
        var quadRooms = $('#quad_rooms').val();
         var quadAdutls = $('#quad_adult').val();
         
         quadTotalCapcity = quadRooms * 4;
         var remainingCapcity = quadTotalCapcity - quadAdutls;
         if(quadAdutls < quadTotalCapcity){
             $('#childroom3').attr('disabled',false);
             $('#infantroom3').attr('disabled',false);
         }else{
              $('#childroom3').attr('disabled',true);
              $("#childroom3").prop("checked", false);
              $('#infantroom3').attr('disabled',true);
              $('#infantroom3').prop('checked',false);
              
              $('#quad_acc_child').val('');
              $('#quad_child_disc').val(0);
              $('#quad_acc_child_prev').val(0);
              
              $('#quad_acc_infant').val('');
              $('#quad_infant_disc').val(0);
              $('#infant_acc_child_quad_prev').val(0);
              
              
              $('.quad_child').css('display','none');
              $('.quad_infant').css('display','none');
              caluclateGrandTotal();
              
         }
    }
    
    function checkQuadRemaingCap(){
         var quadRooms = $('#quad_rooms').val();
         var quadAdutls = $('#quad_adult').val();
         
        quadTotalCapcity = quadRooms * 4;
        var remainingCapcity = quadTotalCapcity - quadAdutls;
        var StarQuadRem  = remainingCapcity;
        
        console.log('start remain'+remainingCapcity);
        
        console.log('remainingCapcity'+remainingCapcity);
            
            
            if($("#childroom3").is(':checked')) {
              console.log('Child is checked')
              var quad_acc_child = $('#quad_acc_child').val();
              
              var afterChildremainingCapcity = remainingCapcity - quad_acc_child;
              
              if(afterChildremainingCapcity < 0){
                  $('#childroom3').attr('disabled',true);
                  $("#childroom3").prop("checked", false);
                  $('#infantroom3').attr('disabled',true);
                  $('#infantroom3').prop('checked',false);
                  
                  $('#quad_acc_child').val('');
                  $('#quad_child_disc').val(0);
                  $('#quad_acc_child_prev').val(0);
                  
                  $('#quad_acc_infant').val('');
                  $('#quad_infant_disc').val(0);
                  $('#infant_acc_child_quad_prev').val(0);
                  
                  
                  $('.quad_child').css('display','none');
                  $('.quad_infant').css('display','none');
                  
                //   checkDoubleRemaingCap();
                  checkChildInfantQuadAv();
                  caluclateGrandTotal();
              }else{
                   remainingCapcity = remainingCapcity - quad_acc_child;
              }
             
              
              
                                    console.log('remainingCapcity'+remainingCapcity);

            }
            
            if($("#infantroom3").is(':checked')) {
              console.log('infant is checked')
              var quad_acc_infant = $('#quad_acc_infant').val();
              var afterInfantremainingCapcity = remainingCapcity - quad_acc_infant;
              
              console.log('remainingCapcitylastber'+remainingCapcity);
              
              if(afterInfantremainingCapcity < 0){
                   $('#childroom3').attr('disabled',true);
                  $("#childroom3").prop("checked", false);
                  $('#infantroom3').attr('disabled',true);
                  $('#infantroom3').prop('checked',false);
                  
                  $('#quad_acc_child').val('');
                  $('#quad_child_disc').val(0);
                  $('#quad_acc_child_prev').val(0);
                  
                  $('#quad_acc_infant').val('');
                  $('#quad_infant_disc').val(0);
                  $('#infant_acc_child_quad_prev').val(0);
                  
                  
                  $('.quad_child').css('display','none');
                  $('.quad_infant').css('display','none');
                //   checkDoubleRemaingCap();
                  checkChildInfantQuadAv();
                  caluclateGrandTotal();
              }else{
                  console.log('Enter in infant sele');
                   remainingCapcity = remainingCapcity - quad_acc_infant;
              }
              
              
                      console.log('remainingCapcitylast'+remainingCapcity);
                      
                      

            }
            
        $('#quad_remaing_space').val(remainingCapcity);
        
    }
    
     function checkQuadChildAv(){
        console.log('double function is call ');
       var availableSpace = $('#quad_remaing_space').val();
       var tripleChilds_prev =  $('#quad_acc_child_prev').val();
        var tripleChilds = $('#quad_acc_child').val();
        
        var enter_childs = tripleChilds - tripleChilds_prev;
         
         console.log(tripleChilds)
         console.log(availableSpace)
         if(enter_childs > availableSpace){
            //  checkDoubleRemaingCap()
             var availableSpace = $('#quad_remaing_space').val();
             tripleChilds = $('#quad_acc_child_prev').val();
             alert('You have Remaining Capcity in Quad '+availableSpace)
             
             if(tripleChilds == 0){
                 $('#quad_acc_child').val('');
             }else{
                 $('#quad_acc_child').val(tripleChilds);
             }
             
             
         }else{
             availableSpace = availableSpace - tripleChilds;
             $('#quad_remaing_space').val(availableSpace);
              $('#quad_acc_child_prev').val(tripleChilds);
              checkQuadRemaingCap()
         }
        
        
    }
    
    function checkQuadInfantdAv(){
        console.log('double function is call ');
       var availableSpace = $('#quad_remaing_space').val();
       var doubleInfant_prev =  $('#infant_acc_child_quad_prev').val();
        var doubleInfants = $('#quad_acc_infant').val();
        
        var enter_infants = doubleInfants - doubleInfant_prev;
         
         if(enter_infants > availableSpace){
            //  checkDoubleRemaingCap()
             var availableSpace = $('#quad_remaing_space').val();
             doubleinfants = $('#infant_acc_child_quad_prev').val();
             alert('You can add only '+availableSpace)
             
             if(doubleinfants == 0){
                 $('#quad_acc_infant').val('');
             }else{
                 $('#quad_acc_infant').val(doubleinfants);
             }
             
         }else{
             availableSpace = availableSpace - doubleInfants;
             $('#quad_remaing_space').val(availableSpace);
              $('#infant_acc_child_quad_prev').val(doubleInfants);
              checkQuadRemaingCap()
         }
        
        
    }
    
    function checkQuadChildOrInfantHide(clickItem,displayValue,currentelment=null){
         console.log('function is call ');
        var tripleRooms = $('#quad_rooms').val();
         var tripleAdutls = $('#quad_adult').val();
         
         tripleTotalCapcity = tripleRooms * 4;
         var remainingCapcity = tripleTotalCapcity - tripleAdutls;
        
        if(remainingCapcity == 1){
            if(clickItem != ''){
                 $('#'+clickItem+'').attr('disabled',displayValue);
            }
           
        }
        
    }




function parseDate(str) {
    var mdy = str.split('-');
    return new Date(mdy[2], mdy[0]-1, mdy[1]);
}

function datediff(first, second) {
    // Take the difference between the dates and divide by milliseconds per day.
    // Round to nearest whole number to deal with DST.
    console.log('first is '+first+' second is '+second);
    return Math.round((second-first)/(1000*60*60*24));
}



        function updateConfig() {
            var options = {};
            $('.config-demo').daterangepicker(options, function(start, end, label) {
                console.log('New date range selected: ' + start.format('DD-MM-YYYY') + ' to ' + end.format('DD-MM-YYYY') + ' (predefined range: ' + label + ')'); 
                
                var days = datediff(parseDate(start.format('MM-DD-YYYY')), parseDate(end.format('MM-DD-YYYY')));
               
               var ele = $(this);
                console.log(ele);
                console.log(ele[0].element[0].attributes.id.value);
                var current_id = ele[0].element[0].attributes.id.value;
                $('#day'+current_id+'').val(days)
                
            }).click();
        }
        
        updateConfig();
$('#adults').change(function(){
    var adutls = $(this).val();
    if(adutls >0){
        $('#add_to_cart').css('display','block');
    }else{
         $('#add_to_cart').css('display','none');
    }
    console.log('This is change now'+adutls);
})

var serviceInc = 1;

function checkPerPerson(type,idBox,idAppend,paymentType){
    console.log('the type is '+paymentType);
  
    // if(type !== ''){
           if($('#'+idBox+'').prop('checked')){

                   console.log('Enter here if')
                   if(idBox == 'service1'){
                       if(paymentType == 0){
                            var input = ` <div class="row">
                                            <div class="col-md-6"><input type="number" class="form-control" required placeholder="Enter Persons" min="1" value="1" name="service_adults1"></div>
                                            <div class="col-md-6"><input type="text" placeholder="Enter Days" hidden id="dayrang${serviceInc}" readonly name="service_days1"></div>
                                            <div class="col-md-12"><input type="text" placeholder="Select Date Range"  class=" form-control" hidden id="rang${serviceInc}" name="service_dateRang1"></div>
                                          </div>`;
                       }else{
                            var input = ` <div class="row">
                                            <div class="col-md-6"><input type="number" class="form-control" required placeholder="Enter Persons" min="1" value="1" name="service_adults1"></div>
                                            <div class="col-md-6"><input type="text" placeholder="Enter Days" id="dayrang${serviceInc}" readonly name="service_days1"></div>
                                            <div class="col-md-12"><input type="text" placeholder="Select Date Range" class="config-demo form-control" id="rang${serviceInc}" name="service_dateRang1"></div>
                                          </div>`;
                       }
                      
                   }else{
                       if(paymentType == 0){
                            var input = ` <div class="row">
                                            <div class="col-md-6"><input type="number" class="form-control" required placeholder="Enter Persons" min="1" value="1" name="service_adults[]"></div>
                                            <div class="col-md-6"><input type="text" hidden placeholder="Enter Days" id="dayrang${serviceInc}" readonly name="service_days[]"></div>
                                            <div class="col-md-12"><input type="text" hidden placeholder="Enter Days" class="form-control" id="rang${serviceInc}" name="service_dates[]"></div>
                                          </div>`;
                       }else{
                            var input = `<div class="row">
                                            <div class="col-md-6"><input type="number" class="form-control" required placeholder="Enter Persons" min="1" value="1" name="service_adults[]"></div>
                                            <div class="col-md-6"><input type="text" placeholder="Enter Days" id="dayrang${serviceInc}" readonly name="service_days[]"></div>
                                            <div class="col-md-12"><input type="text" placeholder="Enter Days" class="config-demo form-control" id="rang${serviceInc}" name="service_dates[]"></div>
                                          </div>`;
                       }
                   }
                   
             
                 
                 $('#'+idAppend+'').html(input)
                console.log('this is checked'+idAppend+'yr');
            }else{
                $('#'+idAppend+'').html('')
                console.log('this is not checked');
            }
            
            updateConfig();
    // }
   
    serviceInc++;
}
</script>
<!--<script type="text/javascript" src="{{ asset('public/plugins/jquery/jquery.js') }}"></script>-->
<script type="text/javascript" src="{{ asset('public/plugins/plugins.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/plugins/goodlayers-core/plugins/combine/script.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/plugins/goodlayers-core/include/js/page-builder.js') }}"></script>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>-->
         
   
         
             <script>
    let mainNavLinks = document.querySelectorAll(".hotel-nav ul li a");
let mainSections = document.querySelectorAll("main section");

let lastId;
let cur = [];


window.addEventListener("scroll", event => {
  let fromTop = window.scrollY;

  mainNavLinks.forEach(link => {
    let section = document.querySelector(link.hash);

    if (
      section.offsetTop <= fromTop &&
      section.offsetTop + section.offsetHeight > fromTop
    ) {
      link.classList.add("current");
    } else {
      link.classList.remove("current");
    }
  });
});
    </script>
 <script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("hotel-nav");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>
<!-- LIBRARY JS-->
@endsection