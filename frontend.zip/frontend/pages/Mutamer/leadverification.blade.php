@extends('template/frontend/includes/master')
<!-- PRELOADER -->
        <div class="preloader"></div>
        <!-- END / PRELOADER -->

@section('content')
 <!--Start CSS links for slider-->
    <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/revslider/public/assets/css/settings.css') }}">
     <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/plugins/combine/traveltour-style-custom.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/plugins/combine/style.css') }}">
       <link rel="stylesheet" type="text/css" href="{{ asset('public/plugins/goodlayers-core/include/css/page-builder.css') }}">
   
       
          <!--End CSS links for slider-->
<style>


.cs-bar_list {
  margin: 0;
  padding: 0;
  list-style: none;
  position: relative;
}

.cs-bar_list::before {
  content: '';
  height: 75%;
  width: 2px;
  position: absolute;
  left: 4px;
  top: 50%;
  -webkit-transform: translateY(-50%);
          transform: translateY(-50%);
  background-color: #eaeaea;
}

.cs-bar_list li {
  position: relative;
  padding-left: 25px;
}

.cs-bar_list li:before {
  content: '';
  height: 10px;
  width: 10px;
  border-radius: 50%;
  background-color: #eaeaea;
  position: absolute;
  left: 0;
  top: 6px;
}

.cs-bar_list li:not(:last-child) {
  margin-bottom: 10px;
}

.cs-table.cs-style1.cs-type1 {
  padding: 10px 30px;
}

.cs-table.cs-style1.cs-type1 tr:first-child td {
  border-top: none;
}

.cs-table.cs-style1.cs-type1 tr td:first-child {
  padding-left: 0;
}

.cs-table.cs-style1.cs-type1 tr td:last-child {
  padding-right: 0;
}

.cs-table.cs-style1.cs-type2 > * {
  padding: 0 10px;
}

.cs-table.cs-style1.cs-type2 .cs-table_title {
  padding: 20px 0 0 15px;
  margin-bottom: -5px;
}

.cs-table.cs-style2 td {
  border: none;
}

.cs-table.cs-style2 td,
.cs-table.cs-style2 th {
  padding: 12px 15px;
  line-height: 1.55em;
}

.cs-table.cs-style2 tr:not(:first-child) {
  border-top: 1px dashed #eaeaea;
}

.cs-list.cs-style1 {
  list-style: none;
  padding: 0;
  margin: 0;
}

.cs-list.cs-style1 li {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}

.cs-list.cs-style1 li:not(:last-child) {
  border-bottom: 1px dashed #eaeaea;
}

.cs-list.cs-style1 li > * {
  -webkit-box-flex: 0;
      -ms-flex: none;
          flex: none;
  width: 50%;
  padding: 7px 0px;
}

.cs-list.cs-style2 {
  list-style: none;
  margin: 0 0 30px 0;
  padding: 12px 0;
  border: 1px solid #eaeaea;
  border-radius: 5px;
}

.cs-list.cs-style2 li {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}

.cs-list.cs-style2 li > * {
  -webkit-box-flex: 1;
      -ms-flex: 1;
          flex: 1;
  padding: 5px 25px;
}
.cs-bar_list li:before{
    background-color: #e52828;
}
     .gdlr-core-ilightbox  img{
   
   height: 240px;
   width: 100%;

}
.hotel-images-section{
        padding-top: 150px;
} 

.gdlr-core-image-overlay {
    background-color: #000000;
    background-color: rgba(0, 0, 0, 0.6);
}
.hotel-nav {
  white-space: nowrap;
  background: #37474F;
  z-index:99;
}
.hotel-nav ul {
  list-style: none;
  margin: 0;
  padding: 0;
}
/* Only stick if you can fit */

.hotel-nav ul li a {
  display: block;
  padding: 0.5rem 1rem;
  color: white;
  text-decoration: none;
}
.hotel-nav ul li a.current {
  background: black;
}

.sticky {
  position: fixed;
  top: 0;
  width: 100%;
}

.sticky + .content {
  padding-top: 102px;
}



/*page css*/
.tc{
     color: #d39d00 !important;
}
section{
    padding-top:60px;
}
.product-title h2{
        color: #000000;
    font-size: 26px;
    font-weight: 600;
}
.product-detail__info .trips .item h6{
    font-size: 18px
}
.font-26{
    font-size: 24px
}
.accordion .ui-accordion-header:before{
      content: "";
    position: absolute;
    border-radius: 50%;
    pointer-events: none;
    z-index: 1;
    -webkit-transition: all 1.2s cubic-bezier(.23,1,.32,1);
    -o-transition: all 1.2s cubic-bezier(.23,1,.32,1);
    transition: all 1.2s cubic-bezier(.23,1,.32,1);
    width: 16px;
    height: 16px;
    background-color: #fff;
   left: -10px;
    top: 0px;
    border: 2px solid #767676;
}
.accordion .ui-accordion-header:after{
    content: "";
    position: absolute;
    border-radius: 50%;
    pointer-events: none;
    z-index: 1;
    -webkit-transition: all 1.2s cubic-bezier(.23,1,.32,1);
    -o-transition: all 1.2s cubic-bezier(.23,1,.32,1);
    transition: all 1.2s cubic-bezier(.23,1,.32,1);
    width: 8px;
    height: 8px;
    background-color: #e60032;
    left: -6px;
    top: 4px;
    -webkit-transform: scale(0);
    -ms-transform: scale(0);
    transform: scale(0);
}
.accordion .ui-accordion-header {
   
    margin-bottom: 15px;
   
    line-height: 30px;
}
.accordion .ui-accordion-header-active:after{
     -webkit-transform: scale(1); */
    -ms-transform: scale(1);
     transform: scale(1);
    }
.accordion .ui-state-hover:before
{
    border: 2px solid #e02044;
}
.trip-schedule-accordion.accordion{
    border-left: 3px dotted #666;
}
.item-from img, .item-to img{
    margin:0 auto;
}
.ui-accordion .ui-accordion-content {
    padding: 0 2.2em;
}
.ui-accordion .ui-accordion-content h6{
        margin-bottom: 4px;
}
.detail-sidebar {
    margin-top: 100px;
}
.select-package-top{
    font-size:18px;
    font-size: 18px;
    background: #37474f;
    color: #fff;
    padding: 5px 18px;
}
.ticket-price th, .ticket-price td{
        text-align: center;
}
.initiative-table tbody tr .item-body{
    padding:0;
}
.initiative-table tbody tr .item-body .item-time .fa{
        color: #06a803;
        font-size: 50px;
}

h5, .h5 {
    font-size: 16px;
}



:disabled {
    cursor: default;
    background-color: #e3e3e3 !important;
    border-color: #ababab !important;
}
</style>
     <!-- BREADCRUMB -->
    
        
        
        <section class="awe-parallax category-heading-section-demo" style="background-position: 50% 0px;">
        <div class="awe-overlay"></div>
            <div class="container">
                <div class="category-heading-content category-heading-content__2 text-uppercase">
                 
                   <div class="find">
                        <h2 class="text-center">LEAD PASSENGER VERIFICATION!</h2>
                        
                             <form action="{{ url('verifying_lead_and_add') }}" method="post" enctype="multipart/form-data">
        @csrf
        <div class="row">
            <div class="col-md-12 mb-4">
                @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" style="background-color:#d4edda;" role="alert">
                    {{ session('success') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif

                @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show" style="background-color:#f5cfcf;" role="alert">
                    {{ session('error') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif
            </div>
            <div class="col-md-12">
            
                <!-- Main Tab Contant Start -->
                <div class="tab-content">
                    <!-- General Tab Start -->
                  
                        <div class="row">
                            <div class="col-md-4 mt-2">
                        
                                <label for="">Your Name</label>
                                <input id="leadname" type="text" class="form-control @error('leadname') is-invalid @enderror" name="leadname" value="{{ old('leadname') }}" autofocus >
                                <input  type="hidden" class="form-control" name="invoice_no" value="{{$invoice_no}}"  >

                                @error('leadname')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="col-md-4 mt-2">
                                
                                <label for="">Your E-mail</label>
                                <input id="leadmail" type="text" class="form-control @error('leadmail') is-invalid @enderror" name="leadmail" value="{{ $email }}" autofocus readonly>

                                @error('leadmail')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="col-md-4 mt-2">
                                <label for="">Enter Password</label>
                                <input id="leadpassword" type="text" class="form-control @error('leadpassword') is-invalid @enderror enteredpass" onchange="myFunction()" name="leadpassword" value="{{ old('leadpassword') }}" placeholder="Enter Password" autofocus required>

                                @error('leadpassword')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div> 
                            <div class="col-md-4 mt-2">
                                <label for="">Re-Enter Password</label>
                                <input name="leadrepeatpassword" type="text" class="form-control @error('leadrepeatpassword') is-invalid @enderror re_entredpass" onchange="myFunction()" value="{{ old('leadrepeatpassword') }}"  autocomplete="companyemail" placeholder="Re-Enter Password" autofocus required>

                                @error('leadrepeatpassword')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="col-md-4 mt-2">
                               <a href="javascript:void(0);" class="mailotp">OTP On Mail</a>
                               <div class="mailinput">
                                <!--<input id="leadmail" type="text" class="form-control @error('leadmail') is-invalid @enderror" name="leadmailotp" placeholder="Enter E-Mail"  autofocus >-->
                                </div>
                            </div>
                            <div class="col-md-4 mt-2">
                                <a href="javascript:void(0);" class="phoneotp"> OTP On Phone</a>
                                <div class="phoneinput">
                                <!--<input id="leadmail" type="text" class="form-control @error('leadmail') is-invalid @enderror" name="leadmailotp" placeholder="Enter Phone" autofocus >-->
                                </div>
                            </div>
                            <div class="col-md-4 mt-4">
                               <button type="submit" class="btn btn-primary submit_btn">Submit</button>
                            </div>
                          
                         
                          
                           
                          

                    
                        </div>
                    </div>
                  
                    
                  
                  
                 
                </div>
                <!-- Main Tab Contant End -->
            </div>
            
        </div>

      
    </form>
                        
                        
                      
                    </div>
                </div>
            </div>
        </section>
        <!--End Slider-->





<!-- ================================
       START FOOTER AREA
================================= -->
@endsection
@section('scripts')
<script>
    $( document ).ready(function() {
   
   
    $('.mailinput').hide();
    $('.phoneinput').hide();
    $('.submit_btn').hide();
   
   
   
   
    });
    function myFunction() {
        //  alert("dfdfd");
        var pass = $('.enteredpass').val();
        var re_pass = $('.re_entredpass').val();
        console.log(pass);
        console.log(re_pass);
        if(pass == re_pass){
            alert("Password Matched!");
            $('.submit_btn').show();
        }
    }
    
</script>
@endsection