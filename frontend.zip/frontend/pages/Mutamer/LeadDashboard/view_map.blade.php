<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Dashboard | Super Admin Dashboard</title>
<meta name="viewport" content="initial-scale=1,maximum-scale=1,user-scalable=no">
 <!-- App favicon -->
        <link rel="shortcut icon" href="{{asset('public/admin_package/assets/images/favicon.ico')}}">
<link href="https://api.mapbox.com/mapbox-gl-js/v2.12.0/mapbox-gl.css" rel="stylesheet">
<link rel="stylesheet" href="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-directions/v4.1.0/mapbox-gl-directions.css" type="text/css">
<script src="https://api.mapbox.com/mapbox-gl-js/v2.12.0/mapbox-gl.js"></script>
<script src="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-directions/v4.1.0/mapbox-gl-directions.js"></script>
<style>
body { margin: 0; padding: 0; }
#map { position: absolute; top: 0; bottom: 0; width: 100%; }
</style>
</head>
<body>
<div id="map"></div>
<script>
	// TO MAKE THE MAP APPEAR YOU MUST
	// ADD YOUR ACCESS TOKEN FROM
	// https://account.mapbox.com
	 mapboxgl.accessToken = 'pk.eyJ1IjoiYXdhYWIiLCJhIjoiY2w3cTI0azIyMDE5aDNucGw2OTl2dTV2MyJ9.JjhRRvHq8JtA0xDZWxjKgQ';
  const map = new mapboxgl.Map({
attributionControl: false,
container: 'map',
style: 'mapbox://styles/mapbox/streets-v12',

center: [<?php echo ($data[0]->longitude) ?>, <?php echo ($data[0]->latitude) ?>],
zoom: 12
});
map.addControl(new mapboxgl.NavigationControl());
map.addControl(
new mapboxgl.GeolocateControl({
positionOption:{
enableHighAccuracy:true
},
trackUserLocation:true
}));
map.addControl(
new MapboxDirections({
accessToken: mapboxgl.accessToken
}),
'top-left'
);
<?php
 $stop = 0;
//  dd($data);
foreach ($data as $key => $value){ 
   
       if ($value != "") {
           $stop++;
           
             //google map api url
        $url = "https://maps.google.com/maps/api/geocode/json?latlng=$value->latitude,$value->longitude&key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY&sensor=false&libraries=places";

        // send http request
        $geocode = file_get_contents($url);
        $json = json_decode($geocode);
        $address = $json->results[0]->formatted_address;
        // dd($address);
           
           
           ?>
          
   
   
    
    
 
   
 
         
            show_marker(<?php echo json_encode($value->longitude) ?>,<?php echo json_encode($value->latitude) ?>,<?php echo json_encode($leadName) ?>,<?php echo json_encode($value->dateNtime) ?>,<?php echo json_encode($stop) ?>,<?php echo json_encode($address) ?>);
            
        <?php } 
       
      
}  
?> 



function show_marker(Lng,Lat,LeadName,dateNtime,stop,placeName)
{
   
 
 

 
                
                
                
                const marker = new mapboxgl.Marker({ "color": "#b40219" })
 
                const minPopup = new mapboxgl.Popup({closeButton: true, closeOnClick: true})
                 minPopup.setHTML("<strong><b>Hello "+LeadName+" Your Location No: "+stop+"</b><br>"+dateNtime+"<br>"+placeName+"<br>longitude: "+Lng+"<br>latitude: "+Lat+"</strong>")
                 marker.setPopup(minPopup)
                 console.log(placeName);
                 marker.setLngLat([Lng,Lat])
                 // marker.setRotation(45);
                 marker.addTo(map)
                 
                //  marker.togglePopup();
                 
                 
                 
              
          


 
 
 

 
 
 

 
}



</script>
</body>
</html>