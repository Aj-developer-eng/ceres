 @include('template/frontend/pages/Mutamer/LeadDashboard/includes/header')
	
	  @yield('content')
		
 @include('template/frontend/pages/Mutamer/LeadDashboard/includes/footer')