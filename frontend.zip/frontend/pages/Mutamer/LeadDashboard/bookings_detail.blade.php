@extends('template/frontend/pages/Mutamer/LeadDashboard/layout/default')
@section('content')
<div class="dashboard-content">
    
    
   
    <div class="container-fluid">
                    
                    <div class="table-responsive">
                        <div class="row">
                            @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show" style="background-color:#f5cfcf;" role="alert">
                    {{ session('error') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif
                @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" style="background-color:#d4edda;" role="alert">
                    {{ session('success') }}
                    <button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                @endif
                
                
                
                
                
                
                
                
                
                
                
                            <table class="table table-centered w-100 dt-responsive nowrap" id="example1">
                                <thead class="table-light">
                                    <tr>
                                        <th style="text-align: center;">Invoice No.</th>
                                        <th style="text-align: center;">Start Date</th>
                                        <th style="text-align: center;">End Date</th>
                                        <th style="text-align: center;">Sponsord By</th>
                                       
                                       
                                        <th style="width: 85px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody style="text-align: center;">
                                   
                                    <tr>
                                    <td>16666</td>
                                    <td>1-1-1001</td>
                                    <td>1-1-1001</td>
                                    <td>Sponsord By</td>
                                   
                                    <td>
                                        <a href="{{URL::to('editsupplier')}}/" class="mb-2"><span class="badge bg-success " style="font-size: 15px">Edit</span></a> <br>
                                        
                                    </tr>
                                   
                                </tbody>
                            </table>
                        </div>
                    </div> 
                    
                </div>
   
   
</div>


@endsection
@section('scripts')

@stop



