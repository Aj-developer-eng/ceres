<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contact_us;
use App\Http\Controllers\MailController;


class contactUs extends Controller
{
    //
    public function save_contact_us(Request $request)
    {  
        
        $validated = $request->validate([
            'first_name'=>'required',
            'last_name'=>'required',
            'email'=>'required',
            'phone'=>'required',
            'comments'=>'required',
            
        ]);

        $contact =  new Contact_us;
        $contact->first_name = $request->first_name;
        $contact->last_name = $request->last_name;
        $contact->email = $request->email;
        $contact->phone = $request->phone;
        $contact->message = $request->comments;

      

        $result = $contact->save();
        // $result = false;
        if($result){
            $mail_send = MailController::index($request->email);
            if($mail_send){
                return redirect()->back()->with('success','Your Message Sent Successfuly');
            }else{
                return redirect()->back()->with('error','Message is recevied but sorry email is Sent');
            }
            
        }else{
            
            return redirect()->back()->with('error','Somthing Went Wrong Try Again');
        }
        
        # code...
    }
}
