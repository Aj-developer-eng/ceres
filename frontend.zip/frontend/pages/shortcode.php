@extends('template/frontend/includes/master')

@section('content')

        <!-- HEADING PAGE -->
        <section class="awe-parallax page-heading-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class="blog-heading-content text-uppercase">
                    <h2>Shortcode</h2>
                </div>
            </div>
        </section>
        <!-- END / HEADING PAGE -->

        <section class="pt-80 pb-80 bg-border">
            <div class="container">

                <div class="row">

                    <div class="col-xs-12">
                        <h1>H1 Heading 1</h1>
                        <p>Donec pharetra ipsum sed lacinia malesuada. Integer tristique sapien et ligula porttitor egestas. Nam nec mauris volutpat, euismod massa ac, fermentum eros. Sed in lorem sed metus dapibus malesuada sit amet eget justo. In sollicitudin aliquam diam eget maximus. Sed auctor ultrices mi quis mattis. Nam porta iaculis eros, eu suscipit arcu rutrum sed. Curabitur at urna efficitur, malesuada mi non, auctor dui.</p>
                        <h2>H2 Heading 2</h2>
                        <p>Donec pharetra ipsum sed lacinia malesuada. Integer tristique sapien et ligula porttitor egestas. Nam nec mauris volutpat, euismod massa ac, fermentum eros. Sed in lorem sed metus dapibus malesuada sit amet eget justo. In sollicitudin aliquam diam eget maximus. Sed auctor ultrices mi quis mattis. Nam porta iaculis eros, eu suscipit arcu rutrum sed. Curabitur at urna efficitur, malesuada mi non, auctor dui.</p>
                        <h3>H3 Heading 3</h3>
                        <p>Donec pharetra ipsum sed lacinia malesuada. Integer tristique sapien et ligula porttitor egestas. Nam nec mauris volutpat, euismod massa ac, fermentum eros. Sed in lorem sed metus dapibus malesuada sit amet eget justo. In sollicitudin aliquam diam eget maximus. Sed auctor ultrices mi quis mattis. Nam porta iaculis eros, eu suscipit arcu rutrum sed. Curabitur at urna efficitur, malesuada mi non, auctor dui.</p>
                        <h4>H4 Heading 4</h4>
                        <p>Donec pharetra ipsum sed lacinia malesuada. Integer tristique sapien et ligula porttitor egestas. Nam nec mauris volutpat, euismod massa ac, fermentum eros. Sed in lorem sed metus dapibus malesuada sit amet eget justo. In sollicitudin aliquam diam eget maximus. Sed auctor ultrices mi quis mattis. Nam porta iaculis eros, eu suscipit arcu rutrum sed. Curabitur at urna efficitur, malesuada mi non, auctor dui.</p>
                        <h5>H5 Heading 5</h5>
                        <p>Donec pharetra ipsum sed lacinia malesuada. Integer tristique sapien et ligula porttitor egestas. Nam nec mauris volutpat, euismod massa ac, fermentum eros. Sed in lorem sed metus dapibus malesuada sit amet eget justo. In sollicitudin aliquam diam eget maximus. Sed auctor ultrices mi quis mattis. Nam porta iaculis eros, eu suscipit arcu rutrum sed. Curabitur at urna efficitur, malesuada mi non, auctor dui.</p>
                        <h6>H6 Heading 6</h6>
                        <p>Donec pharetra ipsum sed lacinia malesuada. Integer tristique sapien et ligula porttitor egestas. Nam nec mauris volutpat, euismod massa ac, fermentum eros. Sed in lorem sed metus dapibus malesuada sit amet eget justo. In sollicitudin aliquam diam eget maximus. Sed auctor ultrices mi quis mattis. Nam porta iaculis eros, eu suscipit arcu rutrum sed. Curabitur at urna efficitur, malesuada mi non, auctor dui.</p>
                    </div>

                </div>
            </div>
        </section>

        <section class="pt-80 pb-80 bg-border">
            <div class="container">

                <div class="row">

                    <div class="col-xs-12">
                        <p>Fusce congue <del>convallis malesuada</del>. Etiam ut rutrum augue. <mark>Duis consequat nibh vitae</mark> odio dapibus blandit. <a href="#">Phasellus elementum nibh</a> sit amet pharetra tincidunt. Morbi dapibus vehicula diam a accumsan. Vestibulum consectetur est aliquet, <ins>rutrum diam et, luctus leo.</ins> Quisque semper volutpat pellentesque. Cras pretium nisl a sem convallis, id fringilla nisl lobortis. Proin eu sapien augue. Sed congue nunc non massa dignissim, vel ullamcorper dui fermentum. Suspendisse in gravida augue. <abbr>Sed congue nunc non massa dignissim, vel ullamcorper dui fermentum.</abbr> Suspendisse in gravida augue. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus non efficitur ex. Aliquam ultricies tincidunt eleifend. pre, <dfn>porttitor iaculis felis</dfn>. Cras sed felis vel purus interdum semper.</p>
                    </div>

                </div>
            </div>
        </section>

        <section class="pt-80 pb-80 bg-border">
            <div class="container">

                <div class="row">

                    <div class="col-xs-12">
                        <h5 class="text-uppercase">Blockquote</h5>
                        <blockquote>
                            <p>Donec pharetra ipsum sed lacinia malesuada. Integer tristique sapien et ligula porttitor egestas. Nam nec mauris volutpat, euismod massa ac, fermentum eros. Sed in lorem sed metus dapibus malesuada sit amet eget justo. In sollicitudin aliquam diam eget maximus. Sed auctor ultrices mi quis mattis. Nam porta iaculis eros, eu suscipit arcu rutrum sed. Curabitur at urna efficitur, malesuada mi non, auctor dui.</p>
                            <footer>Awethemes</footer>
                        </blockquote>
                    </div>

                </div>
            </div>
        </section>


        <section class="pt-80 pb-80 bg-border">
            <div class="container">

                <div class="row">

                    <div class="col-xs-12">
                        <h5 class="text-uppercase">Preformated Text</h5>
                        <pre>Nunc nec blandit turpis. Nulla pharetra sit amet mauris ac facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla ac vestibulum magna. Praesent sed neque ac tellus ullamcorper malesuada non a diam. Nulla metus lectus, imperdiet at quam ac</pre>
                    </div>

                </div>
            </div>
        </section>

        <section class="pt-80 pb-80 bg-border">
            <div class="container">

                <div class="row">

                    <div class="col-xs-12">
                        <h5 class="text-uppercase">Dropcap</h5>
                        <p><span class="dropcap">N</span>unc nec blandit turpis. Nulla pharetra sit amet mauris ac facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla ac vestibulum magna. Praesent sed neque ac tellus ullamcorper malesuada non a diam. Nulla metus lectus, imperdiet at quam ac, fringilla pharetra enim. Donec faucibus sollicitudin mi. Phasellus tempus diam a dolor lacinia, vitae ultricies sem eleifend. Mauris mollis dolor vel metus aliquam, lobortis congue leo rhoncus. Ut vel ligula pulvinar, tempor tortor at, tempus diam. Fusce in leo sed enim dictum pellentesque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed metus ex, semper eu magna at, pharetra lacinia odio.</p>
                    </div>

                </div>
            </div>
        </section>


        <section class="pt-80 pb-80 bg-border">
            <div class="container">

                <div class="row">

                    <div class="col-md-6">
                        <h5 class="text-uppercase">Ordered Lists</h5>
                        <ol class="list">
                            <li>Nulla pharetra sit amet mauris ac facilisis. Lorem ipsum dolor.</li>
                            <li>Nulla pharetra sit amet mauris ac facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                            <li>Nulla pharetra sit amet mauris ac facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                            <li>Nulla pharetra sit amet mauris ac facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                        </ol>
                    </div>

                    <div class="col-md-6">
                        <h5 class="text-uppercase">Unordered Lists</h5>
                        <ul class="list">
                            <li>Nulla pharetra sit amet mauris ac facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                            <li>Nulla pharetra sit amet mauris ac facilisis. Lorem ipsum dolor.</li>
                            <li>Nulla pharetra sit amet mauris ac facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                            <li>Nulla pharetra sit amet mauris ac facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                        </ul>
                    </div>

                </div>
            </div>
        </section>


        <section class="pt-80 pb-80 bg-border">
            <div class="container">

                <div class="row">

                    <div class="col-md-6">
                        <h5 class="text-uppercase">Tabs</h5>
                        <div class="tabs">
                            <ul>
                                <li>
                                    <a href="#tabs-1">Tabs 1</a>
                                </li>
                                <li>
                                    <a href="#tabs-2">Tabs 2</a>
                                </li>
                                <li>
                                    <a href="#tabs-3">Tabs 3</a>
                                </li>
                            </ul>
                            <div class="tabs-content">
                                <div id="tabs-1">
                                    <p>Donec auctor sem eros, feugiat consectetur diam varius sit amet. Ut dapibus ante vel consectetur aliquam. Etiam lacus dolor, porta non tortor ac, elementum pretium nisl. Donec pharetra purus bibendum arcu dictum rutrum. Donec consectetur tortor at ligula luctus imperdiet. Phasellus vel nisi ligula. Duis accumsan, quam id rutrum aliquam, lorem eros consequat lectus, non fringilla risus mauris vel ex. Aliquam sollicitudin ipsum ex, sit amet eleifend arcu consectetur eu. Ut nec pulvinar quam, non cursus justo. Nunc at facilisis turpis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Integer quis eros ultrices magna porttitor faucibus at eu dolor.</p>
                                </div>
                                <div id="tabs-2">
                                    <p>Donec auctor sem eros, feugiat consectetur diam varius sit amet. Ut dapibus ante vel consectetur aliquam. Etiam lacus dolor, porta non tortor ac, elementum pretium nisl. Donec pharetra purus bibendum arcu dictum rutrum. Donec consectetur tortor at ligula luctus imperdiet. Phasellus vel nisi ligula. Duis accumsan, quam id rutrum aliquam, lorem eros consequat lectus, non fringilla risus mauris vel ex. Aliquam sollicitudin ipsum ex, sit amet eleifend arcu consectetur eu. Ut nec pulvinar quam, non cursus justo. Nunc at facilisis turpis.</p>
                                </div>
                                <div id="tabs-3">
                                    <p>Donec auctor sem eros, feugiat consectetur diam varius sit amet. Ut dapibus ante vel consectetur aliquam. Etiam lacus dolor, porta non tortor ac, elementum pretium nisl. Donec pharetra purus bibendum arcu dictum rutrum. Donec consectetur tortor at ligula luctus imperdiet. Phasellus vel nisi ligula. Duis accumsan, quam id rutrum aliquam, lorem eros consequat lectus, non fringilla risus mauris vel ex. Aliquam sollicitudin ipsum ex, sit amet eleifend arcu consectetur eu. Ut nec pulvinar quam, non cursus justo. Nunc at facilisis turpis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Integer quis eros ultrices magna porttitor faucibus at eu dolor.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <h5 class="text-uppercase">Accordion</h5>
                        <div class="accordion">
                            <h3>Day 1 : Downtown Tour</h3>
                            <div>
                                <p>Get on and go places! If you want to hit the most-visited spots in New York City, this is the one: CitySights NY’s Downtown Tour. You’ll get easy access to the most popular sites in town: the Statue of Liberty, the Empire State Building and “Ground Zero,” where the World Trade Center once stood and where a stunning new skyscraper soars today.</p>
                            </div>
                            <h3>Day 2 : Uptown Treasures &amp; Harlem Tour</h3>
                            <div>
                                <p>
                                Sed non urna. Donec et ante. Phasellus eu ligula. Vestibulum sit amet
                                purus. Vivamus hendrerit, dolor at aliquet laoreet, mauris turpis porttitor
                                velit, faucibus interdum tellus libero ac justo. Vivamus non quam. In
                                suscipit faucibus urna.
                                </p>
                            </div>
                            <h3>Day 3 : Chinatown</h3>
                            <div>
                                <p>
                                Nam enim risus, molestie et, porta ac, aliquam ac, risus. Quisque lobortis.
                                Phasellus pellentesque purus in massa. Aenean in pede. Phasellus ac libero
                                ac tellus pellentesque semper. Sed ac felis. Sed commodo, magna quis
                                lacinia ornare, quam ante aliquam nisi, eu iaculis leo purus venenatis dui.
                                </p>
                                <ul>
                                    <li>List item one</li>
                                    <li>List item two</li>
                                    <li>List item three</li>
                                </ul>
                            </div>
                            <h3>Day 4 : Parks &amp; Bridges</h3>
                            <div>
                                <p>
                                Cras dictum. Pellentesque habitant morbi tristique senectus et netus
                                et malesuada fames ac turpis egestas. Vestibulum ante ipsum primis in
                                faucibus orci luctus et ultrices posuere cubilia Curae; Aenean lacinia
                                mauris vel est.
                                </p>
                                <p>
                                Suspendisse eu nisl. Nullam ut libero. Integer dignissim consequat lectus.
                                Class aptent taciti sociosqu ad litora torquent per conubia nostra, per
                                inceptos himenaeos.
                                </p>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </section>

        <section class="pt-80 pb-80 bg-border">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h5 class="text-uppercase">Map</h5>
                        <div class="map-demo">
                            <div data-latlong="21.036697, 105.834871"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h5 class="text-uppercase">Contact Form</h5>
                        <form class="contact-form" action="http://tk-themes.net/html-gofar/processContact.php" method="post">
                            <div class="form-item">
                                <input type="text" value="Your Name *" name="name">
                            </div>
                            <div class="form-item">
                                <input type="email" value="Your Email *" name="email">
                            </div>
                            <div class="form-textarea-wrapper">
                                <textarea name="message">Company name</textarea>
                            </div>
                            <div class="form-actions">
                                <input type="submit" value="Send" class="submit-contact">
                            </div>
                            <div id="contact-content"></div>
                        </form>
                    </div>
                </div>
            </div>
        </section>


        <!-- MASONRY -->
        <section class="masonry-section-demo">
            <div class="container">
                <div class="destination-grid-content">
                    <div class="section-title">
                        <h5 class="text-uppercase">Gallery</h5>
                    </div>
                    <div class="row">
                        <div class="awe-masonry">
                            <!-- GALLERY ITEM -->
                            <div class="awe-masonry__item">
                                <a href="#">
                                    <div class="image-wrap image-cover">
                                        <img src="images/img/1.jpg" alt="">
                                    </div>
                                </a>
                                <div class="item-title">
                                    <h2><a href="#">Florenze</a></h2>
                                    <div class="item-cat">
                                        <ul>
                                            <li><a href="#">Italy</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item-available">
                                    <span class="count">845</span>
                                    available hotel
                                </div>
                            </div>
                            <!-- END / GALLERY ITEM -->
                            <!-- GALLERY ITEM -->
                            <div class="awe-masonry__item">
                                <a href="#">
                                    <div class="image-wrap image-cover">
                                        <img src="images/img/2.jpg" alt="">
                                    </div>
                                </a>
                                <div class="item-title">
                                    <h2><a href="#">Toluca</a></h2>
                                    <div class="item-cat">
                                        <ul>
                                            <li><a href="#">USA</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item-available">
                                    <span class="count">132</span>
                                    available hotel
                                </div>
                            </div>
                            <!-- END / GALLERY ITEM -->
                            <!-- GALLERY ITEM -->
                            <div class="awe-masonry__item">
                                <a href="#">
                                    <div class="image-wrap image-cover">
                                        <img src="images/img/3.jpg" alt="">
                                    </div>
                                </a>
                                <div class="item-title">
                                    <h2><a href="#">Venice</a></h2>
                                    <div class="item-cat">
                                        <ul>
                                            <li><a href="#">Italy</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item-available">
                                    <span class="count">2341</span>
                                    available hotel
                                </div>
                            </div>
                            <!-- END / GALLERY ITEM -->
                            <!-- GALLERY ITEM -->
                            <div class="awe-masonry__item">
                                <a href="#">
                                    <div class="image-wrap image-cover">
                                        <img src="images/img/4.jpg" alt="">
                                    </div>
                                </a>
                                <div class="item-title">
                                    <h2><a href="#">Ohio</a></h2>
                                    <div class="item-cat">
                                        <ul>
                                            <li><a href="#">USA</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item-available">
                                    <span class="count">2531</span>
                                    available hotel
                                </div>
                            </div>
                            <!-- END / GALLERY ITEM -->
                            <!-- GALLERY ITEM -->
                            <div class="awe-masonry__item">
                                <a href="#">
                                    <div class="image-wrap image-cover">
                                        <img src="images/img/5.jpg" alt="">
                                    </div>
                                </a>
                                <div class="item-title">
                                    <h2><a href="#">Venice</a></h2>
                                    <div class="item-cat">
                                        <ul>
                                            <li><a href="#">Italy</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item-available">
                                    <span class="count">2531</span>
                                    available hotel
                                </div>
                            </div>
                            <!-- END / GALLERY ITEM -->
                            <!-- GALLERY ITEM -->
                            <div class="awe-masonry__item">
                                <a href="#">
                                    <div class="image-wrap image-cover">
                                        <img src="images/img/6.jpg" alt="">
                                    </div>
                                </a>
                                <div class="item-title">
                                    <h2><a href="#">Mandives</a></h2>
                                    <div class="item-cat">
                                        <ul>
                                            <li><a href="#">Mandives</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item-available">
                                    <span class="count">2531</span>
                                    available hotel
                                </div>
                            </div>
                            <!-- END / GALLERY ITEM -->
                            <!-- GALLERY ITEM -->
                            <div class="awe-masonry__item">
                                <a href="#">
                                    <div class="image-wrap image-cover">
                                        <img src="images/img/7.jpg" alt="">
                                    </div>
                                </a>
                                <div class="item-title">
                                    <h2><a href="#">Istanbul</a></h2>
                                    <div class="item-cat">
                                        <ul>
                                            <li><a href="#">Turkey</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item-available">
                                    <span class="count">2531</span>
                                    available hotel
                                </div>
                            </div>
                            <!-- END / GALLERY ITEM -->
                            <!-- GALLERY ITEM -->
                            <div class="awe-masonry__item">
                                <a href="#">
                                    <div class="image-wrap image-cover">
                                        <img src="images/img/8.jpg" alt="">
                                    </div>
                                </a>
                                <div class="item-title">
                                    <h2><a href="#">Bali</a></h2>
                                    <div class="item-cat">
                                        <ul>
                                            <li><a href="#">Thailand</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item-available">
                                    <span class="count">2531</span>
                                    available hotel
                                </div>
                            </div>
                            <!-- END / GALLERY ITEM -->
                            <!-- GALLERY ITEM -->
                            <div class="awe-masonry__item">
                                <a href="#">
                                    <div class="image-wrap image-cover">
                                        <img src="images/img/9.jpg" alt="">
                                    </div>
                                </a>
                                <div class="item-title">
                                    <h2><a href="#">Phu Quoc</a></h2>
                                    <div class="item-cat">
                                        <ul>
                                            <li><a href="#">Vietnam</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item-available">
                                    <span class="count">2531</span>
                                    available hotel
                                </div>
                            </div>
                            <!-- END / GALLERY ITEM -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END / MASONRY -->


@endsection