
@extends('template/frontend/includes/master')

@section('content')

<style>
    .tour-img{
        width:100%;
        height:145px;
    }
    .departure-date{
            font-size: 16px;
            color: #477fe7;
    }
    
    .tour-description{
        
    }
    .price-div{
        display:flex;
    }
    .tour_length{
        font-size:16px;
        font-weight:bold;
    }
    .time_length{
        width:100%;
        font-size: 13px;
        text-align: center;
    }
    
    .price{
        text-align:center;
    }
    
    .parent_row{
            box-shadow: 9px 12px 15px -4px #808080bd;
    padding: .5rem 0px;
    border: 1px solid #80808038;
    border-radius: 7px;
    }
    
    .noUi-base, .noUi-connects {
    width: 97%;
    height: 100%;
    position: relative;
    z-index: 1;
    }

</style>
<!-- ================================
    START HERO-WRAPPER AREA
================================= -->
<section class="awe-parallax category-heading-section-demo">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class="category-heading-content category-heading-content__2 text-uppercase">
               
                    <div class="find">
                          
                        <h2 class="text-center">Find Your Activity</h2>
                        <form action="{{ URL::to('search_activities') }}" method="post" class="row align-items-center">
                        @csrf
                        
                            <div class="form-group">
                                
                                <div class="form-elements">
                                    
                                     <label>Where To Go?</label>
                                      <input type="text" name="city"  id="pakages_city" value="Country, city, airport..."  >
                                </div>
                                <div class="form-elements">
                                     <label>Departure Date</label>
                                        <div class="form-item">
                                            <i class="awe-icon awe-icon-calendar"></i>
                                            <input type="text" name="start" class="awe-calendar" value="Check In">
                                        </div>
                                </div>
                               
                               
                                <div class="form-actions">
                                    <input type="submit" value="Find My Trip">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
                                                    @php 
                                            if(isset($request_data['booking_person'])){
                                            @endphp
                                            <input type="text" name="booking_person" hidden readonly value="admin">
                                            
                                            @php
                                            }
                                            @endphp
        <!-- END / HEADING PAGE -->


        
        <section class="filter-page">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-top">
                            <select class="awe-select">
                                <option>Best Match</option>
                                <option>Best Rate</option>
                            </select>
                        </div>
                        <h3 class="title font-size-24" id="tours_result">{{ count($activities) }} Result found</h3>
                      
                        <?php 
                            // $from_date ='01-01-2013';
                            // $to_date ='05-01-2013';
                            
                            // $from_date = new DateTime($from_date);
                            // $to_date = new DateTime($to_date);
                            
                            // for ($date = $from_date; $date <= $to_date; $date->modify('+1 day')) {
                            //   echo $date->format('l') . "\n";
                            // }
                        ?>
                    </div>
                    <div class="col-md-3 col-md-pull-9">
                        <div class="page-sidebar">
                            <div class="sidebar-title">
                                <h2>Trip</h2>
                                <div class="clear-filter">
                                    <a href="#">Clear all</a>
                                </div>
                            </div>
                            <!-- WIDGET -->
                        
                            <!-- END / WIDGET -->

                            <!-- WIDGET -->
                            <div class="widget widget_price_filter">
                                <h3>Price Level</h3>
                                <div class="mb-0">
                                    <label class="form-label">Price Level</label>
                                    <div id="kt_slider_basic"></div>
                                
                                    <div class="pt-5">
                                        <div class="fw-bold mb-2">Min: <span id="kt_slider_basic_min"></span></div>
                                        <div class="fw-bold mb-2">Max: <span id="kt_slider_basic_max"></span></div>
                                    </div>
                                </div>
                                
                                <input type="text" id="city" hidden value="{{ $id ?? '' }}">
                                <input type="text" id="start" hidden value="{{ $request_data['start'] ?? '' }}">
                            </div>
                            <!-- END / WIDGET -->

                            <!-- WIDGET -->
                          <div class="widget widget_has_radio_checkbox">
                                <h3>Star Rating</h3>
                                <ul>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="5">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="4">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="3">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="2">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="rating_starts" value="1">
                                            <i class="awe-icon awe-icon-check"></i>
                                            <span class="rating">
                                                <i class="fa fa-star"></i>
                                            </span>
                                        </label>
                                    </li>
                                   
                                </ul>
                            </div>
                            <!-- END / WIDGET -->

                         
                            <!-- WIDGET -->
                            <div class="widget widget_has_radio_checkbox">
                                <h3>Service Include</h3>
                                <ul>
                                    @if(isset($all_attributes))
                                      @foreach($all_attributes as $att_res)
                                    <li>
                                        <label>
                                            <input type="checkbox" name="attributes" value="{{ $att_res->id }}">
                                            <i class="awe-icon awe-icon-check"></i>
                                            {{ $att_res->title }}
                                        </label>
                                    </li>
                                      @endforeach
                                     @endif
                                   
                                </ul>
                            </div>
                            <!-- END / WIDGET -->
                            <button class="btn" style="background-color:#d2b254; color:white;" onclick="getFilterResult()">Filter</button>

                            <!-- WIDGET -->
                            <div class="widget widget_product_tag_cloud">
                                <h3>Tags</h3>
                                <div class="tagcloud">
                                    <a href="#">Hotel</a>
                                    <a href="#">Motel</a>
                                    <a href="#">Hostel</a>
                                    <a href="#">Homestay</a>
                                </div>
                            </div>
                            <!-- END / WIDGET -->

                        </div>
                    </div>
                    <div class="col-md-9 col-md-push-3">
                        <div class="filter-page__content">
                            <div class="filter-item-wrapper" id="tours_filter">
                                <!-- ITEM -->
                                @foreach($activities as $toure_res)
                                <?php 
                                    $tour_availiblity = json_decode($toure_res->Availibilty);
                                    // echo "<pre>";
                                    // print_r($tour_availiblity);
                                    // echo "</pre>";
                                ?>
                                
                                 <div class="col-md-12 mb-4">
                                        <div class="row parent_row">
                                            <div class="col-md-3">
                                                <div class="">
                                                    <img class="tour-img" src="{{ config('img_url') }}/public/images/activites/{{  $toure_res->featured_image }}" alt="">
                                                    <div>
                                                        <img src="{{ config('img_url') }}/public/uploads/package_imgs/city_map.gif" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <h5 class="card-title">
                                                    <a href="{{ URL::to('view_detail/'.$toure_res->id.'') }}" style="text-decoration:none;">{{ $toure_res->title }}</a>
                                                </h5>
                                                <h6 class="departure-date"><i class="fa-solid fa-plane-departure"></i>   
                                                <?php
                                                                 
                                                              $dateValue = strtotime(date("d-m-Y", strtotime($toure_res->start_date ?? '' )));
                                                     
                                                                $year = date('Y',$dateValue);
                                                                $monthName = date('F',$dateValue);
                                                                $monthNo = date('d',$dateValue);
                                                                $day = date('l', $dateValue);
                                                                echo ' '.$monthNo . ',' . $monthName . ',' . $year;
                                                                // printf("%s, %d, %s ,%l\n", $monthName, $monthNo, $year ,$day);
                                                              ?>
                                                </h6>
                                                <p>{{ $toure_res->starts_rating }}.0 
                                                
                                                <?php
                                                      if($toure_res->starts_rating == 1){
                                                               echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                       }
                                                        if($toure_res->starts_rating == 2){
                                                               echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                               echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                         }
                                            
                                              
                                                        if($toure_res->starts_rating == 3){
                                                                echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                                echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                          }
                                            
                                              
                                                       if($toure_res->starts_rating == 4){
                                                         echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                         echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                           
                                                       }
                                            
                                              
                                                         if($toure_res->starts_rating == 5){
                                                                 echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                                 echo '<i class="fa fa-star" style="color:#ffd762;"></i>';
                                                          }
                                  ?>
                                                     
                                                <p>
                                                <p class="tour-description">{!! Str::limit($toure_res->activity_content, 175, ' ...') !!}</p>
                                                <hr>
                                                <div class="row">
                                                     <div class="col-md-5">
                                                        
                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="fa-solid fa-plane-departure"></i> Location  </p>
                                                
                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="fa-solid fa-plane-arrival"></i> Available Days  </p>
                                                     </div>
                                                     <div class="col-md-7">
                                                            <p style="margin-bottom: 0;"> {{ Str::limit($toure_res->location , 30, ' ...') }} </p>

                                                        <p style="margin-bottom: 0;"> <?php
                                                           
                                                $start_time = '';
                                                $end_time = '';
                                                  foreach($tour_availiblity as $id => $av_res){
                                                                            if(isset($av_res->enable)){
                                                                                ?>
                                                                              
                                                                                        <?php
                                                                                        $day = '';
                                                                                          if($id == '1'){
                                                                                                $day = "Monday";
                                                                                                
                                                                                          }
                                                                                          
                                                                                           if($id == '2'){
                                                                                                $day = "Tuesday";
                                                                                               
                                                                                          }
                                                                                          
                                                                                           if($id == '3'){
                                                                                                $day = "Wednesday";
                                                                                               
                                                                                          }
                                                                                          
                                                                                           if($id == '4'){
                                                                                                $day = "Thursday";
                                                                                                
                                                                                          }
                                                                                          
                                                                                           if($id == '5'){
                                                                                                $day = "Friday";
                                                                                                
                                                                                          }
                                                                                          
                                                                                           if($id == '6'){
                                                                                                $day = "Saturday";
                                                                                               
                                                                                          }
                                                                                          
                                                                                           if($id == '7'){
                                                                                                $day = "Sunday";
                                                                                              
                                                                                          }
                                                                                          
                                                                                            ?>
                                                                                            
                                                                                   {{ $day }},   
                                                                            
                                                                                <?php
                                                                                $start_time = $av_res->from;
                                                                                $end_time = $av_res->to;
                                                                                
                                                                            }
                                                                        }
                                                                        ?>
                                                        </p>
                                                     </div>
                                                    
                                                </div>
                                              
                                            </div>
                                            <div class="col-md-3 pt-2">
                                                    <div class="price">
                                                        <h6 style="font-size:25px; color:#d2b254;">
                                                                {{ $toure_res->currency_symbol }}
                                                                <super>
                                                                  {{ $toure_res->sale_price }}
                                                                </super>
                                                                 <sub>PP</sub>
                                                                
                                                              
                                                        </h6>
                                                        
                                                </div>
                                                <div class="time_length"><i class="fa fa-moon-o" aria-hidden="true"></i>Activity Hours <span class="tour_length">{{ $toure_res->duration }}</span></div>
                                                <h6 style="text-align:center;color:#477fe7;"><a href="{{ URL::to('activity_details/'.$toure_res->id.'') }}" style="text-decoration:none; font-size:15px;">View Details</a></h6>
                                                 <a href="{{ URL::to('activity_details/'.$toure_res->id.'') }}" style="text-decoration:none;" class="btn btn-primary form-control">Book Now</a>
                                            </div>
                                        </div>
                                    </div>

                                @endforeach 
                          
                             
                                <!-- END / ITEM -->
                            </div>
                           


                            <!-- PAGINATION -->
                            <!-- <div class="page__pagination">
                                <span class="pagination-prev"><i class="fa fa-caret-left"></i></span>
                                <span class="current">1</span>
                                <a href="#">2</a>
                                <a href="#">3</a>
                                <a href="#">4</a>
                                <a href="#" class="pagination-next"><i class="fa fa-caret-right"></i></a>
                            </div> -->
                            <!-- END / PAGINATION -->
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>

<!-- start back-to-top -->
@endsection

@section('scripts')
<script src="https://maps.googleapis.com/maps/api/js?libraries=places&callback=initAutocomplete&language=nl&output=json&key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY" async defer></script>

<script>
   
  function initAutocomplete() {
        var departure_city = document.getElementById('departure_city');
        var autocomplete = new google.maps.places.Autocomplete(departure_city);
      }
      

    function getFilterResult(){
        console.log('Button is Click now');
        var values = slider.noUiSlider.get();
        var city = $('#city').val();
        var start = $('#start').val();
           var attributes = [];
            $.each($("input[name='attributes']:checked"), function(){
                attributes.push($(this).val());
            });
            
            var rating_starts = [];
             $.each($("input[name='rating_starts']:checked"), function(){
                rating_starts.push($(this).val());
            });
            
            console.log('The city is '+city)
            $.ajax({
                    url: '{{ URL::to("filter_activities") }}',
                    method: "post",
                    data: {
                        _token: '{{ csrf_token() }}', 
                        city: city,
                        start:start,
                        min:values[0],
                        max:values[1],
                        attr:attributes,
                        starts:rating_starts,
                        request_page:'country_activity'
                    },
                    success: function (response) {
                        console.log(response);
                        var tourData = JSON.parse(response);
                        console.log(tourData);
                        
                         var data_html = '';
                        
                        var toursFound = tourData[0].length;
                        $('#tours_result').html(toursFound+' Result found')
                        
                        for(var i=0; i<tourData[0].length; i++){
                            console.log('value of i '+tourData[0][i]['featured_image']);
                            var tourId = tourData[0][i]['id'];
                            var desc = tourData[0][i]['activity_content'];
                            var Avalilbilty =  JSON.parse(tourData[0][i]['Availibilty']);
                            console.log(Avalilbilty);
                            const keys = Object.keys(Avalilbilty);

                            // print all keys
                            
                            console.log(keys);
                            
                            // [ 'java', 'javascript', 'nodejs', 'php' ]
                            
                            // iterate over object
                            var avaibaleDays = '';
                            keys.forEach((key, index) => {
                                console.log(Avalilbilty[key]);
                                if(Avalilbilty[key].hasOwnProperty('enable')){
                                    if(key == 1){
                                        avaibaleDays += 'Monday,';
                                    }
                                    
                                    if(key == 2){
                                        avaibaleDays += 'Tuesday,';
                                    }
                                    
                                    if(key == 3){
                                        avaibaleDays += 'Wednesday,';
                                    }
                                    
                                    if(key == 4){
                                        avaibaleDays += 'Thursday,';
                                    }
                                    
                                    if(key == 5){
                                        avaibaleDays += 'Friday,';
                                    }
                                    
                                    if(key == 6){
                                        avaibaleDays += 'Saturday,';
                                    }
                                    
                                    if(key == 7){
                                        avaibaleDays += 'Sunday,';
                                    }
                                }
                            });
                            if(desc.length > 125){
                                desc = desc.substring(0,125);
                                desc +='..'
                            } 
                            
                                                        
                            var startDate = new Date(tourData[0][i]['start_date']); 
                            var StartMonth = startDate.toLocaleString('default', { month: 'long' });
                            
                            var dateObj = new Date(tourData[0][i]['start_date']);
                            var month = dateObj.getUTCMonth() + 1; //months from 1-12
                            var day = dateObj.getUTCDate();
                            var year = dateObj.getUTCFullYear();
                            
                            startDate = day + "," + StartMonth + "," + year;
                            
                            
                            
                        data_html += ` <div class="col-md-12 mb-4">
                                        <div class="row parent_row">
                                            <div class="col-md-3">
                                                <div class="">
                                                    <img class="tour-img" src="{{ config('img_url') }}/public/images/activites/${tourData[0][i]['featured_image']}" alt="">
                                                    <div>
                                                        <img src="{{ config('img_url') }}/public/uploads/package_imgs/city_map.gif" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <h5 class="card-title">
                                                    <a href="{{ URL::to('activity_details/${tourId}') }}" style="text-decoration:none;">${tourData[0][i]['title']}</a>
                                                </h5>
                                                <h6 class="departure-date"><i class="fa-solid fa-plane-departure"></i>   
                                                
                                                              ${startDate}
                                                </h6>
                                                     <p>${tourData[0][i]['starts_rating']}.0 `;
                                                
                                                     if(tourData[0][i]['starts_rating'] == 1){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        if(tourData[0][i]['starts_rating'] == 2){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        
                                                          
                                                        if(tourData[0][i]['starts_rating'] == 3){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        
                                                          
                                                        if(tourData[0][i]['starts_rating'] == 4){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        
                                                          
                                                        if(tourData[0][i]['starts_rating'] == 5){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        
                                                        if(tourData[0][i]['location']){
                                                            if(tourData[0][i]['location'].length > 30){
                                                              var  location = tourData[0][i]['location'].substring(0,30);
                                                                  location +='..';
                                                            } 
                                                        }else{
                                                            var location = '';
                                                        }
                                                           
                                                     
                                   data_html += `</p>
                                                <p class="tour-description">${desc}</p>
                                                <hr>
                                                <div class="row">
                                                     <div class="col-md-5">
                                                        
                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="fa-solid fa-plane-departure"></i> Location  </p>
                                                
                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="fa-solid fa-plane-arrival"></i> Available Days  </p>
                                                     </div>
                                                     <div class="col-md-7">
                                                            <p style="margin-bottom: 0;"> ${location} </p>

                                                        <p style="margin-bottom: 0;"> ${avaibaleDays}
                                                        </p>
                                                     </div>
                                                    
                                                </div>
                                              
                                            </div>
                                            <div class="col-md-3 pt-2">
                                                    <div class="price">
                                                        <h6 style="font-size:25px; color:#d2b254;">
                                                                ${tourData[0][i]['currency_symbol']}
                                                                <super>
                                                                  ${tourData[0][i]['sale_price']}
                                                                </super>
                                                                 <sub>PP</sub>
                                                                
                                                              
                                                        </h6>
                                                        
                                                </div>
                                                <div class="time_length"><i class="fa fa-moon-o" aria-hidden="true"></i>Activity Hours <span class="tour_length"> ${tourData[0][i]['duration']}</span></div>
                                                <h6 style="text-align:center;color:#477fe7;"><a href="{{ URL::to('activity_details/${tourId}') }}" style="text-decoration:none; font-size:15px;">View Details</a></h6>
                                                 <a href="{{ URL::to('activity_details/${tourId}') }}" style="text-decoration:none;" class="btn btn-primary form-control">Book Now</a>
                                            </div>
                                        </div>
                                    </div>`;
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                                            
                                            
                                            
                                    }
                                    $('#tours_filter').html(data_html);
                                    console.log(data_html)
                                    
                             var toursFound = tourData[1].length;
                             $('#related_activities').html(toursFound+' Related Result')

                         var data_html = '';
                         console.log(tourData[1]);
                        for(var i=0; i<tourData[1].length; i++){
                            var tourId = tourData[1][i]['id'];
                            
                              var desc = tourData[1][i]['activity_content'];
                            var Avalilbilty =  JSON.parse(tourData[1][i]['Availibilty']);
                            console.log(Avalilbilty);
                            const keys = Object.keys(Avalilbilty);

                            // print all keys
                            
                            console.log(keys);
                            
                            // [ 'java', 'javascript', 'nodejs', 'php' ]
                            
                            // iterate over object
                            var avaibaleDays = '';
                            keys.forEach((key, index) => {
                                console.log(Avalilbilty[key]);
                                if(Avalilbilty[key].hasOwnProperty('enable')){
                                    if(key == 1){
                                        avaibaleDays += 'Monday,';
                                    }
                                    
                                    if(key == 2){
                                        avaibaleDays += 'Tuesday,';
                                    }
                                    
                                    if(key == 3){
                                        avaibaleDays += 'Wednesday,';
                                    }
                                    
                                    if(key == 4){
                                        avaibaleDays += 'Thursday,';
                                    }
                                    
                                    if(key == 5){
                                        avaibaleDays += 'Friday,';
                                    }
                                    
                                    if(key == 6){
                                        avaibaleDays += 'Saturday,';
                                    }
                                    
                                    if(key == 7){
                                        avaibaleDays += 'Sunday,';
                                    }
                                }
                            });
                            if(desc.length > 125){
                                desc = desc.substring(0,125);
                                desc +='..'
                            } 
                            
                                                       
                            var startDate = new Date(tourData[1][i]['start_date']); 
                            var StartMonth = startDate.toLocaleString('default', { month: 'long' });
                            
                            var dateObj = new Date(tourData[1][i]['start_date']);
                            var month = dateObj.getUTCMonth() + 1; //months from 1-12
                            var day = dateObj.getUTCDate();
                            var year = dateObj.getUTCFullYear();
                            
                            startDate = day + "," + StartMonth + "," + year;
                            
                            
                             data_html += ` <div class="col-md-12 mb-4">
                                        <div class="row parent_row">
                                            <div class="col-md-3">
                                                <div class="">
                                                    <img class="tour-img" src="{{ config('img_url') }}/public/images/activites/${tourData[1][i]['featured_image']}" alt="">
                                                    <div>
                                                        <img src="{{ config('img_url') }}/public/uploads/package_imgs/city_map.gif" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <h5 class="card-title">
                                                    <a href="{{ URL::to('activity_details/${tourId}') }}" style="text-decoration:none;">${tourData[1][i]['title']}</a>
                                                </h5>
                                                <h6 class="departure-date"><i class="fa-solid fa-plane-departure"></i>   
                                                
                                                              ${startDate}
                                                </h6>
                                                     <p>${tourData[1][i]['starts_rating']}.0 `;
                                                
                                                     if(tourData[1][i]['starts_rating'] == 1){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        if(tourData[1][i]['starts_rating'] == 2){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        
                                                          
                                                        if(tourData[1][i]['starts_rating'] == 3){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        
                                                          
                                                        if(tourData[1][i]['starts_rating'] == 4){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        
                                                          
                                                        if(tourData[1][i]['starts_rating'] == 5){
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                             data_html +='<i class="fa fa-star" style="color:#d2b254;"></i>';
                                                        }
                                                        
                                                        if(tourData[1][i]['location']){
                                                            if(tourData[1][i]['location'].length > 30){
                                                              var  location = tourData[1][i]['location'].substring(0,30);
                                                                  location +='..';
                                                            } 
                                                        }else{
                                                            var location = '';
                                                        }
                                                           
                                                     
                                   data_html += `</p>
                                                <p class="tour-description">${desc}</p>
                                                <hr>
                                                <div class="row">
                                                     <div class="col-md-5">
                                                        
                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="fa-solid fa-plane-departure"></i> Location  </p>
                                                
                                                        <p style="font-weight:bold; margin-bottom: 0;"><i class="fa-solid fa-plane-arrival"></i> Available Days  </p>
                                                     </div>
                                                     <div class="col-md-7">
                                                            <p style="margin-bottom: 0;"> ${location} </p>

                                                        <p style="margin-bottom: 0;"> ${avaibaleDays}
                                                        </p>
                                                     </div>
                                                    
                                                </div>
                                              
                                            </div>
                                            <div class="col-md-3 pt-2">
                                                    <div class="price">
                                                        <h6 style="font-size:25px; color:#d2b254;">
                                                                ${tourData[1][i]['currency_symbol']}
                                                                <super>
                                                                  ${tourData[1][i]['sale_price']}
                                                                </super>
                                                                 <sub>PP</sub>
                                                                
                                                              
                                                        </h6>
                                                        
                                                </div>
                                                <div class="time_length"><i class="fa fa-moon-o" aria-hidden="true"></i>Activity Hours <span class="tour_length"> ${tourData[1][i]['duration']}</span></div>
                                                <h6 style="text-align:center;color:#477fe7;"><a href="{{ URL::to('activity_details/${tourId}') }}" style="text-decoration:none; font-size:15px;">View Details</a></h6>
                                                 <a href="{{ URL::to('activity_details/${tourId}') }}" style="text-decoration:none;" class="btn btn-primary form-control">Book Now</a>
                                            </div>
                                        </div>
                                    </div>`;
                            
                            
                            
                             
                                            
                                            
                                    }
                                    $('#tours_filter_realeted').html(data_html);
                                    console.log(data_html)
                    }
                       
                    
            });
            
                
        
        console.log(rating_starts);
    }



    
    
    var slider = document.querySelector("#kt_slider_basic");
var valueMin = document.querySelector("#kt_slider_basic_min");
var valueMax = document.querySelector("#kt_slider_basic_max");

noUiSlider.create(slider, {
    start: [1, 10000],
    connect: true,
    range: {
        "min": 0,
        "max": 10000
    }
});

slider.noUiSlider.on("update", function (values, handle) {
    console.log(values)
    if (handle) {
        valueMax.innerHTML = values[handle];
    } else {
        valueMin.innerHTML = values[handle];
    }
    
});
</script>

          <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js" ></script>
    <script>

        var path = "{{ url('cites_suggestions') }}";
        
        $('#pakages_city').typeahead({
        
            source: function(query, process){
        
                return $.get(path, {query:query}, function(data){
                    console.log(data);
                    return process(data);
        
                });
        
            }
        
        });
        
        </script>

@endsection
