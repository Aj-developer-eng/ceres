<style>
   input[type=number]::-webkit-inner-spin-button, 
   input[type=number]::-webkit-outer-spin-button {
   opacity: 1;
   }
   .number-wrapper {
   position: relative;
   }
   .number-wrapper:before {
   content: "\25BC";
   margin-bottom: 13px;
   bottom: -0.5em;
   }
   .number-wrapper:after {
   content: "\25B2";
   margin-top: 1px;
   }
   .number-wrapper:after, .number-wrapper:before {
   position: absolute;
   color: #e9c070;
   right: 5px;
   width: 1.6em;
   height: 0.9em;
   font-size: 10px;
   /*pointer-events: none;*/
   background: #fff;
   }
   .pac-container:after {
   content: none !important;
   }
   .center{
   width: 150px;
   margin: 40px auto;
   }
   .travel-search-content .travl-search-advanced .search-item a{
   padding: 8px 16px;
   border-radius: 0px;
   font-weight: 600;
   font-size: 15px;
   /* color:white; */
   }
   input.searchformfieldselect.CH.snChildrenTransfers.form-control.p-0.h-100.text-center.border-r-0.get_focus
   {
   padding: 0;
   padding-bottom: 10px;
   padding-right: 4px;
   }
   input.searchformfieldselect.CH.snChildrenTransfers.form-control.p-0.h-100.text-center.border-r-0.get_focus:focus
   {
   }
   .travel-search-content .travl-search-advanced .search-item {
   height: 37px;
   }
   #content #ground_modal_home label{
   color:#1b1c1d !important;
   }
   #content #transfer_modal_home label{
   color:#1b1c1d !important;
   }
   .floating-group-buttons__v2
   {
   position: absolute;
   right: 5px;
   top: -2px;
   border-radius: 6px;
   overflow: hidden;
   }
   .floating-label_v3 {
   position: absolute;
   top: 8px;
   right: 27px;
   }
   .more-option-btn {
   display: flex;
   align-items: center;
   justify-content: center;
   z-index: 1;
   }
   .floating-group-buttons__v2 > .btn {
   height: 16px;
   background: #e19d18;
   display: flex;
   align-items: center;
   color: #fff;
   padding: 3px;
   font-weight: 600;
   border-radius: 0;
   margin-bottom: 2px;
   }
   .dec-button {
   color: #000;
   /* padding: 8px; */
   /* display: flex; */
   /* height: 100%; */
   padding: 0px 10px;
   font-weight: 900;
   cursor: pointer;
   position: absolute;
   }
   .inc-button {
   position: absolute;
   color: #1d3456;
   top: 0;
   right: 9px;
   /* padding: 8px; */
   /* display: flex; */
   /* height: 100%; */
   /* padding: 0px 10px; */
   font-weight: 900;
   cursor: pointer;
   }
   .btn-group-inc {
   position: relative;
   border-radius: 10px;
   overflow: hidden;
   border: 1px solid #1d3456;
   height: 30px;
   background: #1d3456;
   }
   .formpopupTransfers .spnAddRoomTransfers {
   background: #0e3367;
   padding: 10px;
   /* margin-top: 8px; */
   color: #fff;
   }
   .formpopupTransfers .closeToggleTransfers {
   background: #0e3367;
   padding: 10px;
   /* margin-top: 8px; */
   color: #fff;
   }
   .label-nights
   {
   position: absolute;
   background: #868686;
   z-index: 999990;
   /* left: 0px; */
   top: 12px;
   right: 10px;
   height: 20px;
   /* width: 20px; */
   display: none;
   justify-content: center;
   align-items: center;
   border-radius: 10px;
   padding-left: 10px;
   padding-right: 10px;
   color: #fff;
   }
   .btn-group .bootstrap-select .countrypicker .f16
   {
   width: 267px;
   }
   .formpopupTransfers {
   background-color: #fff;
   position: relative;
   z-index: 11;
   -webkit-box-shadow: 0 0 3px 0 rgb(0 0 0 / 40%);
   -moz-box-shadow: 0 0 3px 0 rgba(0,0,0,.4);
   box-shadow: 0 0 3px 0 rgb(0 0 0 / 40%);
   border-radius: 5px;
   margin-top: 10px;
   position: absolute;
   width: 100%;
   overflow: scroll;
   max-height: 285px;
   overflow-x: hidden;
   min-height: 200px;
   right: 0;
   }
   .ArrowSelectionUp2 {
   width: 0;
   height: 0;
   position: absolute;
   right: 17px;
   top: -12px;
   }
   .formpopupcontent {
   padding: 15px 15px;
   margin-bottom: 10px;
   border-radius: 912px 10px 10px 10px;
   background: #fff;
   }
   .border-bottom-1 {
   border-bottom: 2px solid #e19d18 !important;
   }
   .bg-grey {
   background: #ddd;
   }
   .formpopupTransfers .closeToggleTransfers, .formpopupTransfers .spnAddRoomTransfers {
   background: #e19d18;
   padding: 6px;
   margin-top: 10px;
   color: #fff !important;
   font-size: 12px;
   border-radius: 10px;
   }
   .searchformfieldselect {
   padding-left:5px  !important;
   }
</style>
<style>
   .form-group.room-selector{
   margin-bottom:0px;
   }
   #Umrah1_txtPaxRooms{
   height: 58px;
   border: 0px;
   width: 100%;
   border-bottom: 2px solid #eaeaea;
   }
   /*SEarch css26-08-22*/
   #page-wrap{
   position:relative;
   }
</style>
<section class="search-section  search-section-home section-absolute">
   <div class="container" style="z-index:100">
      <div class="awe-search-tabs tabs">
         <div class="awe-search-tab-head">
            <div class="tab-btn-right">
               <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModalpayment">Make Payment</button>
               @if(session('view_booking'))
               <a href="{{ URL::to('customer_booking') }}" class="btn btn-info">View Booking</a>
               @elseif(session()->has('customer_login'))
               <a href="{{ URL::to('customer_dashboard') }}" class="btn btn-info">View Booking</a>
               @else
               <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#view_booking">View Booking</button>
               @endif
               <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#view_track_id_booking">Track ID</button>
            </div>
            <ul>
               <li>
                  <a href="#awe-search-tabs-1">
                  <i class="flaticon-suitcase"></i><span>Tours</span>
                  </a>
               </li>
               <li>
                  <a href="#awe-search-tabs-2">
                  <i class="flaticon-hotel"></i><span>Hotels</span>
                  </a>
               </li>
               <li>
                  <a style="display:none;" href="#awe-search-tabs-3">
                  <i class="flaticon-air-freight"></i>
                  </a>
               </li>
               <li>
                  <a href="#awe-search-tabs-5">
                  <i class="awe-icon awe-icon-car"></i><span>Transfers</span>
                  </a>
               </li>
               <li>
                  <a href="#awe-search-tabs-6">
                  <i class="flaticon-air-balloon"></i><span>Activities</span>
                  </a>
               </li>
            </ul>
         </div>
         <div class="awe-search-tabs__content tabs__content">
            <div id="awe-search-tabs-1" class="search-hotel">
               @if (session('error'))
               <div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <strong> {{ session('error') }}</strong>
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
               </div>
               @endif
               <form action="{{ URL::to('search_tour') }}" method="post">
                  @csrf
                  <div class="row">
                     <div class="form-group">
                        <div class="form-elements">
                           <label>Select Category</label>
                           <div class="form-item" style="postion:relative">
                              <select name="category">
                                 @if(isset($all_categories) && !empty($all_categories))
                                 @foreach($all_categories as $cat_res)
                                 <option value="{{ $cat_res->id }}">{{ $cat_res->title }}</option>
                                 @endforeach
                                 @endif
                              </select>
                           </div>
                        </div>
                     </div>
                     <div class="form-group">
                        <div class="form-elements">
                           <label>Departure From</label>
                           <div class="form-item">
                              <i class="awe-icon awe-icon-marker-1"></i>
                              <input type="text" name="city" id="departure_city_tour" placeholder="Search Departure" value="">
                           </div>
                        </div>
                        <div class="form-elements">
                           <label>Departure Date</label>
                           <div class="form-item">
                              <i class="awe-icon awe-icon-calendar"></i>
                              <input type="text" name="start" class="awe-calendar" value="Date">
                           </div>
                        </div>
                     </div>
                     <div class="form-group">
                        <div class="form-actions">
                           <button class="btn btn-primary" type="submit" name="submit">Search</button>
                        </div>
                     </div>
                  </div>
               </form>
            </div>
            <div id="awe-search-tabs-2" class="search-flight-hotel">
               <form action="{{URL::to('')}}/hotels" method="post">
                  @csrf
                   <input type="hidden" name="currency_slc" id="currency_slc" value="" />
                   <input type="hidden" name="currency_slc_iso" id="currency_slc_iso" value="" />
                  <div class="row">
                     <div class="col-sm-3">
                        <div class="form-elements">
                           <label>Destinations</label>
                           <div class="form-item">
                              <i class="awe-icon awe-icon-marker-1"></i>
                              <!--<input type="text" name="city" readonly value="Makkah">-->
                              <!--<input type="text" name="city" placeholder="Search City" id="searchTextField">-->
                              <input name="" id="departure_airport_code" class="form-control" autocomplete="off" placeholder="Enter Destination">
                              <div class="col-xl-1" style="margin-top: 25px;text-align: center; display:none">
                                 <label for=""></label>
                                 <span id="Change_Location" class='bi bi-arrow-left-right' style="font-size: 23px;"></span>
                              </div>
                              <input type="hidden" name="country" placeholder="Search City" id="country">
                              <input type="hidden" name="lat" placeholder="Search City" id="lat">
                              <input type="hidden" name="long" placeholder="Search City" id="long">
                              <input type="hidden" name="pin" placeholder="Search City" id="pin">
                              <input type="hidden" name="cityd" placeholder="Search City" id="city">
                              <input type="hidden" name="country_code" placeholder="Search City" id="country_code">
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-3">
                        <div class="form-elements">
                           <label>Hotel Stay</label>
                           <div class="form-item">
                              <i class="awe-icon awe-icon-calendar"></i>
                              <input class="form-control" type="text" name="daterange" id="demo2" placeholder="Check In ~ Check Out">
                           </div>
                        </div>
                     </div>
                     <!--changes by jamshaid cheena-->
                     {{-- changes 2022-08-03 --}}
                     <div class="col-md-1">
                        <div class="form-elements">
                           <label>Adults</label>
                           <div class="form-item number-wrapper">
                              <input type="number" style="padding: 0 10px;" class=" pl-20px border-r-0" name="adult" id="adultsTransfers" value="2" readonly>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-1">
                        <div class="form-elements">
                           <label>Children</label>
                           <div class="form-item">
                              <input type="number" style="padding: 0 10px;" class=" pl-20px border-r-0" name="child"  id="children_total" value="0" readonly>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-elements">
                           <label>Rooms</label>
                           <div class="form-item">
                              <div class="row h-40px">
                                 <div class="position-relative p-0 h-100 on-hover show">
                                    <input style="padding: 0 10px;" type="number" class=" pl-20px border-r-0" id="rooms_only_transfer" name="room" value="1" min="1" readonly>
                                    <div class="floating-group-buttons__v2" style="margin-top: 3px">
                                       <div class="btn btn-input" target-id="#rooms_only_transfer" mode="increment">+</div>
                                       <div class="btn btn-input" target-id="#rooms_only_transfer" mode="decrement">--</div>
                                    </div>
                                 </div>
                                 <!--                                            <div class="col-xs-2 col-md-2 more-option-btn p-0 h-100" style="margin-top: -33px;margin-left: 127px;">-->
                                 <!--                                               <a style="color:#;color: #e19d18 !important;-->
                                 <!--font-size: 20px;" id="Umrah1_txtPaxRoomsTransfers" class="border-none text-white"><i class="fa-solid fa-bed"></i></a>-->
                                 <!--                                            </div>-->
                              </div>
                              <div class="text-right position-absolute right-15 more-room-top" style="font-size: 11px;">
                                 <a style="color: #000 !important; cursor:pointer;" id="Umrah1_txtPaxRoomsTransfers" class="border-none text-white">More Room Options   <i class="fa-solid fa-bed"></i></a>
                              </div>
                              <!--<input name="Umrah1$txtPaxRooms" type="text" value="1 Rooms : 1Adult(s), 0 Children" id="Umrah1_txtPaxRoomsTransfers" class="searchformfield" onkeydown="return false;" onkeypress="return false;" AutoComplete="off" readonly="readonly" />-->
                              <div class="formpopupTransfers  formpopup" style="z-index: 1000; width: 350px; display: none;">
                                 <div class="ArrowSelectionUp2">
                                    <span>▲</span>
                                 </div>
                                 <div id="HotelRoomInfoDivTransfers">
                                    <div class="formpopupcontent">
                                       <div class="addroomboxTransfers" id="HoteladdroomboxTransfers1">
                                          <div class="border-bottom-1 text-center mb-2 w-100 pt-2 color-dow pb-2"><span><i class="fa-solid fa-bed"></i> Room 1</span></div>
                                          <div id="HotelmainRoomDivTransfers">
                                             <div class="row" style="margin-bottom: 10px;">
                                                <div class="col-sm-8">
                                                   <div class="textgray13" style="margin-top: 10px;">
                                                      <span class="textblack13med">Adult </span> 12 + Years
                                                   </div>
                                                </div>
                                                <div class="col-sm-4">
                                                   <div class="btn-group-inc d-flex">
                                                      <div class="dec-button h-100" data-input-sync="syncAdultsTransfers">-</div>
                                                      <input type="number" name="snAdults[]" class="searchformfieldselect snAdultsTransfers form-control p-0 h-100 text-center border-r-0 " value="2" readonly/>
                                                      <div  class="inc-button h-100" data-input-sync="syncAdultsTransfers">+</div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="row" style="margin-bottom: 10px;">
                                                <div class="col-sm-8">
                                                   <div class="textgray13" style="margin-top: 10px;">
                                                      <span class="textblack13med">Children</span> 2-12 Years
                                                   </div>
                                                </div>
                                                <div class="col-sm-4">
                                                   <select name="snChildren[]" class="searchformfieldselect CH snChildrenTransfers  form-control p-0 h-100 border-r-0 text-center" onchange="HotelCheckAgesDivTransfers(this);">
                                                      <option value="0" selected>0</option>
                                                      <option value="1">1</option>
                                                      <option value="2">2</option>
                                                      <option value="3">3</option>
                                                      <option value="4">4</option>
                                                   </select>
                                                </div>
                                             </div>
                                             <div class="AgesDivTransfers" style="display: none;">
                                                <div class="textblack13med" style="margin-bottom: 10px;">
                                                   Age(s) of Children
                                                </div>
                                                <div class="row" style="margin-bottom: 20px;">
                                                   <div class="col-xs-3 AgeDivTransfers1 padding5px" style="display: none">
                                                      <div class="form-group">
                                                         <select name="snAges1[]" class="searchformfieldselect CHAge padding5px" type="">
                                                            <option>2</option>
                                                            <option>3</option>
                                                            <option>4</option>
                                                            <option>5</option>
                                                            <option>6</option>
                                                            <option>7</option>
                                                            <option>8</option>
                                                            <option>9</option>
                                                            <option>10</option>
                                                            <option>11</option>
                                                            <option>12</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="col-xs-3 AgeDivTransfers2 padding5px" style="display: none">
                                                      <div class="form-group">
                                                         <select name="snAges2[]" class="searchformfieldselect CHAge padding5px" type="">
                                                            <option>2</option>
                                                            <option>3</option>
                                                            <option>4</option>
                                                            <option>5</option>
                                                            <option>6</option>
                                                            <option>7</option>
                                                            <option>8</option>
                                                            <option>9</option>
                                                            <option>10</option>
                                                            <option>11</option>
                                                            <option>12</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="col-xs-3 AgeDivTransfers3 padding5px" style="display: none">
                                                      <div class="form-group">
                                                         <select name="snAges3[]" class="searchformfieldselect CHAge padding5px" type="">
                                                            <option>2</option>
                                                            <option>3</option>
                                                            <option>4</option>
                                                            <option>5</option>
                                                            <option>6</option>
                                                            <option>7</option>
                                                            <option>8</option>
                                                            <option>9</option>
                                                            <option>10</option>
                                                            <option>11</option>
                                                            <option>12</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="col-xs-3 AgeDivTransfers4 padding5px" style="display: none">
                                                      <div class="form-group">
                                                         <select name="snAges4[]" class="searchformfieldselect CHAge padding5px" type="">
                                                            <option>2</option>
                                                            <option>3</option>
                                                            <option>4</option>
                                                            <option>5</option>
                                                            <option>6</option>
                                                            <option>7</option>
                                                            <option>8</option>
                                                            <option>9</option>
                                                            <option>10</option>
                                                            <option>11</option>
                                                            <option>12</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div id="HotelRoomsDivTransfers">
                                       </div>
                                       <div class="room-selector-footer">
                                          <a href="javascript:void(0)" class="spnAddRoomTransfers color-dow fade_out" onclick="HotelAddRoomsInDivTransfers();"> <i class="fa fa-plus-circle" aria-hidden="true"></i> &nbsp;Add More Room</a>
                                          <a href="#" class="closeToggleTransfers">X&nbsp;Close</a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div id="HotelMainRoomDesineDivTransfers" style="display:none;">
                                 <input type="hidden" class="form-control" value="" id="room_noTransfers" name="room_no[]">
                                 <div class="row" style="margin-bottom: 10px;">
                                    <div class="col-sm-8">
                                       <div class="textgray13" style="margin-top: 10px;">
                                          <span class="textblack13med">Adult</span> 12+ Years
                                       </div>
                                    </div>
                                    <div class="col-sm-4">
                                       <div class="btn-group-inc d-flex">
                                          <div class="dec-button h-100"  data-input-sync="syncAdultsTransfers">-</div>
                                          <input type="number" name="snAdults[]" class="searchformfieldselect snAdultsTransfers form-control p-0 h-100 text-center border-r-0" value="2" readonly/>
                                          <div  class="inc-button h-100"  data-input-sync="syncAdultsTransfers">+</div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row" style="margin-bottom: 10px;">
                                    <div class="col-sm-8">
                                       <div class="textgray13" style="margin-top: 10px;">
                                          <span class="textblack13med">Children</span> 2-12 Years
                                       </div>
                                    </div>
                                    <div class="col-sm-4">
                                       <select name="snChildren[]" class="searchformfieldselect CH snChildrenTransfers  form-control p-0 h-100 border-r-0 text-center" onchange="HotelCheckAgesDivTransfers(this);">
                                          <option value="0" selected>0</option>
                                          <option value="1">1</option>
                                          <option value="2">2</option>
                                          <option value="3">3</option>
                                          <option value="4">4</option>
                                       </select>
                                    </div>
                                 </div>
                                 <div class="AgesDivTransfers" style="display: none;">
                                    <div class="textblack13med" style="margin-bottom: 10px;">
                                       Age(s) of Children
                                    </div>
                                    <div class="row" style="margin-bottom: 20px;">
                                       <div class="col-xs-3 AgeDivTransfers1 padding5px" style="display: none">
                                          <div class="form-group">
                                             <select name="snAges1[]" class="searchformfieldselect CHAge padding5px" type="">
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                                <option>6</option>
                                                <option>7</option>
                                                <option>8</option>
                                                <option>9</option>
                                                <option>10</option>
                                                <option>11</option>
                                                <option>12</option>
                                             </select>
                                          </div>
                                       </div>
                                       <div class="col-xs-3 AgeDivTransfers2 padding5px" style="display: none">
                                          <div class="form-group">
                                             <select name="snAges2[]" class="searchformfieldselect CHAge padding5px" type="">
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                                <option>6</option>
                                                <option>7</option>
                                                <option>8</option>
                                                <option>9</option>
                                                <option>10</option>
                                                <option>11</option>
                                                <option>12</option>
                                             </select>
                                          </div>
                                       </div>
                                       <div class="col-xs-3 AgeDivTransfers3 padding5px" style="display: none">
                                          <div class="form-group">
                                             <select name="snAges3[]" class="searchformfieldselect CHAge padding5px" type="">
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                                <option>6</option>
                                                <option>7</option>
                                                <option>8</option>
                                                <option>9</option>
                                                <option>10</option>
                                                <option>11</option>
                                                <option>12</option>
                                             </select>
                                          </div>
                                       </div>
                                       <div class="col-xs-3 AgeDivTransfers4 padding5px" style="display: none">
                                          <div class="form-group">
                                             <select name="snAges4[]" class="searchformfieldselect CHAge padding5px" type="">
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                                <option>6</option>
                                                <option>7</option>
                                                <option>8</option>
                                                <option>9</option>
                                                <option>10</option>
                                                <option>11</option>
                                                <option>12</option>
                                             </select>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-1">
                        <div class="form-actions">
                           <button class="btn btn-primary" type="submit" name="submit">Search</button>
                        </div>
                     </div>
                     {{-- end changes --}}
                     <div class="row">
                        <div class="form-group">
                           <div class="form-elements">
                              <label>Nationality</label>
                              <div class="form-item" style="postion:relative">
                                 <select name="slc_nationality" required>
                                    <option value="">Select Nationality</option>
                                    @foreach($countries as $countries)
                                    <option value="{{$countries->iso2}}">{{$countries->name}}</option>
                                    @endforeach
                                 </select>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!--end changes by jamshaid cheena-->
               </form>
               </div>
            </div>
            <div id="awe-search-tabs-3" class="search-flight">
               <h2>Search Flight</h2>
               <form>
                  <div class="form-group">
                     <div class="form-elements">
                        <label>From</label>
                        <div class="form-item">
                           <i class="awe-icon awe-icon-marker-1"></i>
                           <input type="text" value="Ho Chi Minh, Hanoi, Vietnam">
                        </div>
                     </div>
                     <div class="form-elements">
                        <label>To</label>
                        <div class="form-item">
                           <i class="awe-icon awe-icon-marker-1"></i>
                           <input type="text" value="Ankara, Turkey">
                        </div>
                     </div>
                  </div>
                  <div class="form-group">
                     <div class="form-elements">
                        <label>Depart on</label>
                        <div class="form-item">
                           <i class="awe-icon awe-icon-calendar"></i>
                           <input type="text" class="awe-calendar" value="Check in">
                        </div>
                     </div>
                     <div class="form-elements">
                        <label>Return on</label>
                        <div class="form-item">
                           <i class="awe-icon awe-icon-calendar"></i>
                           <input type="text" class="awe-calendar" value="Check out">
                        </div>
                     </div>
                     <div class="form-elements">
                        <label>Adult</label>
                        <div class="form-item">
                           <select class="awe-select">
                              <option>0</option>
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                           </select>
                        </div>
                        <span>12 yo and above</span>
                     </div>
                     <div class="form-elements">
                        <label>Kids</label>
                        <div class="form-item">
                           <select class="awe-select">
                              <option>0</option>
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                           </select>
                        </div>
                        <span>0-11 yo</span>
                     </div>
                  </div>
                  <div class="form-group">
                     <div class="form-elements">
                        <label>Budget</label>
                        <div class="form-item">
                           <select class="awe-select">
                              <option>All types</option>
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                           </select>
                        </div>
                     </div>
                  </div>
                  <div class="form-actions">
                     <input type="submit" value="Find My Flight">
                  </div>
               </form>
            </div>
            <div id="awe-search-tabs-5" class="search-car">
               <form>
                  <div class="row">
                     <div class="col-sm-3">
                        <div class="form-elements">
                           <label>Picking up</label>
                           <div class="form-item">
                              <i class="awe-icon awe-icon-marker-1"></i>
                              <input type="text" value="City, airport...">
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-3">
                        <div class="form-elements">
                           <label>Droping off</label>
                           <div class="form-item">
                              <i class="awe-icon awe-icon-marker-1"></i>
                              <input type="text" value="City, airport...">
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-2">
                        <div class="form-elements">
                           <label>Picking Date</label>
                           <div class="form-item">
                              <i class="awe-icon awe-icon-calendar"></i>
                              <input type="text" class="awe-calendar" value="Date">
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-2">
                        <div class="form-elements">
                           <label>Droping Date</label>
                           <div class="form-item">
                              <i class="awe-icon awe-icon-calendar"></i>
                              <input type="text" class="awe-calendar" value="Date">
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-2">
                        <div class="form-actions">
                           <input type="submit" value="Find My Car">
                        </div>
                     </div>
                  </div>
               </form>
            </div>
            <div id="awe-search-tabs-6" class="search-car">
               <form action="{{ URL::to('search_activities') }}" method="post">
                  @csrf
                  <div class="row">
                     <div class="form-group">
                        <div class="form-elements">
                           <label>Where To Go?</label>
                           <div class="form-item" style="postion:relative">
                              <i class="awe-icon awe-icon-marker-1"></i>
                              <input type="text" name="city"  id="cites" value="Country, city, airport..."  >
                              <div style="postion:absolute">
                                 <ul class="list-group" id="cites_result"></ul>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="form-group">
                        <div class="form-elements">
                           <label>Date</label>
                           <div class="form-item">
                              <i class="awe-icon awe-icon-calendar"></i>
                              <input type="text" name="start" class="awe-calendar" value="Check In">
                           </div>
                        </div>
                        <div class="form-elements">
                           <label></label>
                           <div class="form-item">
                              <button class="btn btn-primary" type="submit" style="margin-top:2rem;" name="submit">Search</button>
                           </div>
                        </div>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- Button trigger modal -->
<!-- Modal -->
<script src="https://code.jquery.com/jquery-3.6.0.slim.js" integrity="sha256-HwWONEZrpuoh951cQD1ov2HUK5zA5DwJ1DNUXaM6FsY=" crossorigin="anonymous"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmwlQFQKwxZ4D8nRbsWVRTBFUHMO-lUOY&sensor=false&libraries=places"></script>
<script>
   let departure_city_tour,places,places1,return_places,return_places1,places_T,places1_T,return_places_T,return_places1_T ,input, address, city;
   google.maps.event.addDomListener(window, "load", function () {
       var places = new google.maps.places.Autocomplete(
           document.getElementById("departure_airport_code")
       );
       
       var departure_city_tour = new google.maps.places.Autocomplete(
           document.getElementById("departure_city_tour")
       );
       
   google.maps.event.addListener(places, "place_changed", function () {
           var place = places.getPlace();
          console.log(place);
          
          
          
          
          
          
                      
            if(place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['locality', 'political']))[0])
            {
             const city1 = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['locality', 'political']))[0].short_name;
              console.log('city1='+city1);
            }
            else
            {
              const city1 = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['administrative_area_level_2', 'political']))[0].short_name;
              console.log('city1='+city1);  
            }
            
            
            
            
            // if(place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['administrative_area_level_1', 'political']))[0])
            // {
            //  const state1 = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['administrative_area_level_1', 'political']))[0].short_name; 
            //   console.log('state1='+state1);
            // }
            
            if(place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['locality', 'political']))[0])
            {
              const displayCity1 = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['locality', 'political']))[0].long_name;
              console.log('displayCity1='+displayCity1);
              $('#city').val(displayCity1);
            }
            else
            {
              const displayCity1 = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['administrative_area_level_2', 'political']))[0].long_name;
              console.log('displayCity1='+displayCity1); 
              $('#city').val(displayCity1);
            }
            
            
            
            
            // if(place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['administrative_area_level_1', 'political']))[0])
            // {
            //  const displayState1 = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['administrative_area_level_1', 'political']))[0].long_name;
            //  console.log('displayState1='+displayState1);
            // }
            
            
            if(place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['country', 'political']))[0])
            {
             const country_code = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['country', 'political']))[0].short_name;
             console.log('country_code='+country_code);
             $('#country_code').val(country_code);
            }
            if(place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['country', 'political']))[0])
            {
             const country = place.address_components.filter(f => JSON.stringify(f.types) === JSON.stringify(['country', 'political']))[0].long_name;
             console.log('country='+country);
             $('#country').val(country);
            }
          
          
          
          
           var address = place.formatted_address;
           var latitude = place.geometry.location.lat();
           var longitude = place.geometry.location.lng();
           var latlng = new google.maps.LatLng(latitude, longitude);
           var geocoder = (geocoder = new google.maps.Geocoder());
           geocoder.geocode({ latLng: latlng }, function (results, status) {
               if (status == google.maps.GeocoderStatus.OK) {
                   if (results[0]) {
                       var address = results[0].formatted_address;
                       var pin =
                       results[0].address_components[
                   results[0].address_components.length - 1
                 ].short_name;
                  console.log('pin'+pin);
                       var country =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].long_name;
                       var state =
                         results[0].address_components[
                           results[0].address_components.length - 3
                         ].long_name;
                         console.log('state'+state);
                       var city =
                         results[0].address_components[
                           results[0].address_components.length - 4
                         ].long_name;
                       var country_code =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].short_name;
                    //   $('#country').val(country);
                       $('#lat').val(latitude);
                       $('#long').val(longitude);
                       $('#pin').val(pin);
                    //   $('#city').val(city);
                    //   $('#country_code').val(country_code);
                   }
               }
           });
       });
       
        google.maps.event.addListener(departure_city_tour, "place_changed", function () {
           var place = places.getPlace();
           // console.log(place);
           var address = place.formatted_address;
           var latitude = place.geometry.location.lat();
           var longitude = place.geometry.location.lng();
           var latlng = new google.maps.LatLng(latitude, longitude);
           var geocoder = (geocoder = new google.maps.Geocoder());
           geocoder.geocode({ latLng: latlng }, function (results, status) {
               if (status == google.maps.GeocoderStatus.OK) {
                   if (results[0]) {
                       var address = results[0].formatted_address;
                       var pin =
                       results[0].address_components[
                   results[0].address_components.length - 1
                 ].long_name;
                       var country =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].long_name;
                       var state =
                         results[0].address_components[
                           results[0].address_components.length - 3
                         ].long_name;
                       var city =
                         results[0].address_components[
                           results[0].address_components.length - 4
                         ].long_name;
                       var country_code =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].short_name;
                       $('#country').val(country);
                       $('#lat').val(latitude);
                       $('#long').val(longitude);
                       $('#pin').val(pin);
                       $('#city').val(city);
                       $('#country_code').val(country_code);
                   }
               }
           });
       });
   });
   
    google.maps.event.addDomListener(window, "load", function () {
       var places = new google.maps.places.Autocomplete(
           document.getElementById("get_nationality")
       );
   google.maps.event.addListener(places, "place_changed", function () {
           var place = places.getPlace();
           // console.log(place);
           var address = place.formatted_address;
           var latitude = place.geometry.location.lat();
           var longitude = place.geometry.location.lng();
           var latlng = new google.maps.LatLng(latitude, longitude);
           var geocoder = (geocoder = new google.maps.Geocoder());
           geocoder.geocode({ latLng: latlng }, function (results, status) {
               if (status == google.maps.GeocoderStatus.OK) {
                   if (results[0]) {
                       var address = results[0].formatted_address;
                       var pin =
                       results[0].address_components[
                   results[0].address_components.length - 1
                 ].long_name;
                       var country =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].long_name;
                       var state =
                         results[0].address_components[
                           results[0].address_components.length - 3
                         ].long_name;
                       var city =
                         results[0].address_components[
                           results[0].address_components.length - 4
                         ].long_name;
                       var country_code =
                         results[0].address_components[
                           results[0].address_components.length - 2
                         ].short_name;
                       $('#country_n').val(country);
                       $('#lat_n').val(latitude);
                       $('#long_n').val(longitude);
                       $('#pin_n').val(pin);
                       $('#city_n').val(city);
                       $('#country_code_n').val(country_code);
                   }
               }
           });
       });
   });
   
</script>
<script>
   $(".js-example-placeholder-multiple").select2({
   placeholder: "Select a state"
   });
</script>
<script>
   $("input[type='text']").bind("blur", function (e) {
    var s = $(this).val();
    //$(this).val("");
    var test = "";
    for (i = 0; i < s.length; i++) {
        if (s.charCodeAt(i) <= 128) {
            test += s.charAt(i);
        }
        $(this).val(test);
    }
   });
   
   $('#Umrah1_txtPaxRooms').click(function () {
        $('.formpopup').toggle("slow");
        
    });
    $('#Umrah1_txtPaxRoomsTransfers,#children_total,#adultsTransfers').click(function () {
        $('.formpopupTransfers').toggle("slow");
        
    });
    $('#Umrah1_txtPaxRoomsMadina').click(function(){
      $('.formpopupMadina').toggle("slow");
    });
    $('.closeToggle').click(function () {
        $('.formpopup').toggle("slow");
    });
   $('#HotelRoomInfoDiv').on('change', '.snAdults,.snChildren', function () {
        SetHotelGroupPax();
   });  
   
   
   
   
   
   function syncAdults(input) {
   
       
       
    var adults = $('#adults').val();
     var adult_count = parseInt($('#HotelmainRoomDiv').find('.snAdults').val());
      
     
   
     $('#HotelRoomsDiv').find('.addroombox').each(function(){
       adult_count =  parseInt($(this).find('.snAdults').val()) + adult_count; 
    });
   
   
   
   
   $('#adults').val(adult_count);
   
   
   
   }
   
   
   
   
   
   
   
   $('#HotelRoomInfoDiv').on('change', '.snAdults,.snChildren', function () {
    SetHotelGroupPax();
   });  
   function HotelAddRoomsInDiv() {
    var current_room = parseInt($('#rooms_only_hotel').val());
    current_room = current_room + 1;
    $('#rooms_only_hotel').val(current_room);
    SetRoomGroupPax();
   
   }
   $('#HotelRoomsDiv').on('click', '.spnRemoveRoom', function () {
   
    var current_room = parseInt($('#rooms_only_hotel').val());
    current_room = current_room - 1;
   
    $('#rooms_only_hotel').val(current_room);
    SetRoomGroupPax();
   
   });
   function HotelCheckAgesDiv(obj) {
   var parentIDs = $(obj).parents(".addroombox").attr("id");
   var ChildCount = $(obj).val();
   
   $('#' + parentIDs + ' .AgesDiv').find('select').parent().parent().css("display", "none");
   
   if (ChildCount != 0) {
    $('#' + parentIDs + ' .AgesDiv').css("display", "block");
    for (var i = 0; i < parseInt(ChildCount) ; i++) {
        $('#' + parentIDs + ' .AgeDiv' + (i + 1)).css("display", "block");
    }
   }
   else {
    $('#' + parentIDs + ' .AgesDiv').css("display", "none");
    for (var i = 0; i < 4; i++) {
        $('#' + parentIDs + ' .AgeDiv' + (i + 1)).css("display", "block");
    }
   }
   }
   function SetHotelGroupPax() {
   var RoomCount = 0, AdultCount = 0, ChildCount = 0;
   $('#HotelRoomInfoDiv').find('.addroombox').each(function () {
    var Adult = parseInt($(this).find('.snAdults').val().trim());
    var Child = parseInt($(this).find('.snChildren').val().trim());
   
    RoomCount++;
    AdultCount += Adult;
    ChildCount += Child;
   
   });
   
   var StrPax = RoomCount + "Rooms : " + AdultCount + " Adult(s), " + ChildCount + " Children";
   $('#Umrah1_txtPaxRooms').val(StrPax);  
   console.log($('#Umrah1_txtPaxRooms').val());
   }
   //   $('.snAdults').on('change', function(){
   //       var adult = $(this).val();
   
   
   //      var adults = $('#adults').val();
   
   //     adults = parseInt(adults) - parseInt(adult);
   //     $('#adults').val(adults);
   
   //   });
   $('#adults').change(function(){
   if($('#adults').val() < 0){
    $('#adults').val(1);
   }
   var value =  $('#adults').val();
   var rooms = $('#rooms_only_hotel').val();
   var total_adults = 6 * rooms;
   var total_adults_1 = value * rooms;
   if(value > 0){
   
   
   if(value > total_adults){
     value = value - 1;
       $('#adults').val(value);
       
   }else{
       $('.snAdults').each(function(){
         $(this).val(total_adults_1);
         $(this).attr('value', total_adults_1);
        
       });
   
   }
   
   }
   
   
   });
   
   function SetRoomGroupPax(){
     
     
     
     // $('#HotelRoomsDiv').empty();
   
    var i = $('#HotelRoomsDiv .addroombox').length;
    var total_rooms = $('#rooms_only_hotel').val();
   
     if(total_rooms ==  i){
       
         var last = $('#HotelRoomsDiv .addroombox').last();
         console.log(last);
         $(last).remove();
     }else{
          var i = $('#HotelRoomsDiv .addroombox').length;
         i = i + 1;
          var InnerHtmlContent = $('#HotelMainRoomDesineDiv').html();
          console.log(InnerHtmlContent);
         var addroomboxDivCount = i + 1;
       
         if (addroomboxDivCount < 101) {
             $('#room_no').val(addroomboxDivCount);
             var MainDivContent = '<div class="addroombox" id=Hoteladdroombox' + addroomboxDivCount + '>';
             var RoomCountDivContent = "<div class='bg-grey border-dow text-center mb-2 w-100 pt-2 color-blue pb-2 bc-gray'><span><svg xmlns='https://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 512 512'><path d='M496,344h-8V280a32.042,32.042,0,0,0-32-32V112a32.042,32.042,0,0,0-32-32H88a32.042,32.042,0,0,0-32,32V248a32.042,32.042,0,0,0-32,32v64H16a8,8,0,0,0-8,8v32a8,8,0,0,0,8,8h8v32a8,8,0,0,0,8,8H56a7.99,7.99,0,0,0,7.84-6.43L70.56,392H441.44l6.72,33.57A7.99,7.99,0,0,0,456,432h24a8,8,0,0,0,8-8V392h8a8,8,0,0,0,8-8V352A8,8,0,0,0,496,344ZM72,112A16.021,16.021,0,0,1,88,96H424a16.021,16.021,0,0,1,16,16V248H424V216a32.042,32.042,0,0,0-32-32H296a32.042,32.042,0,0,0-32,32v32H248V216a32.042,32.042,0,0,0-32-32H120a32.042,32.042,0,0,0-32,32v32H72ZM408,216v32H280V216a16.021,16.021,0,0,1,16-16h96A16.021,16.021,0,0,1,408,216Zm-176,0v32H104V216a16.021,16.021,0,0,1,16-16h96A16.021,16.021,0,0,1,232,216ZM40,280a16.021,16.021,0,0,1,16-16H456a16.021,16.021,0,0,1,16,16v64H40Zm9.44,136H40V392H54.24ZM472,416h-9.44l-4.8-24H472Zm16-40H24V360H488Z'/></svg>&nbsp;Room " + addroomboxDivCount + "</span><a href='javascript:void(0)' class='spnRemoveRoom' style='position: absolute;right: 25px;font-weight:900;font-size: 12px;'><svg height='20' viewBox='0 0 128 128' width='20' xmlns='https://www.w3.org/2000/svg'><g><g><circle cx='64' cy='64' fill='#ea3883' r='45'/><path d='m69.657 64 14.274-14.273a4 4 0 0 0 -5.657-5.658l-14.274 14.274-14.274-14.274a4 4 0 1 0 -5.657 5.658l14.274 14.273-14.274 14.273a4 4 0 0 0 5.657 5.658l14.274-14.274 14.274 14.274a4 4 0 1 0 5.657-5.658z' fill='#fffcee'/></g><g fill='#01014c'><path d='m64 17.25a46.75 46.75 0 1 0 31.911 80.916 1.75 1.75 0 0 0 -2.389-2.558 43.121 43.121 0 1 1 10.72-15.728 1.75 1.75 0 0 0 3.256 1.285 46.778 46.778 0 0 0 -43.498-63.915z'/><path d='m102.7 87.031a1.751 1.751 0 0 0 -2.421.517l-.329.5a1.75 1.75 0 1 0 2.91 1.952c.122-.182.243-.363.361-.545a1.752 1.752 0 0 0 -.521-2.424z'/></g></g><path d='m86.853 46.9a5.75 5.75 0 0 0 -9.816-4.066l-13.037 13.035-13.037-13.037a5.75 5.75 0 1 0 -8.131 8.132l13.036 13.036-13.036 13.036a5.75 5.75 0 1 0 8.131 8.132l13.037-13.037 13.037 13.037a5.75 5.75 0 1 0 8.131-8.132l-13.036-13.036 13.036-13.036a5.713 5.713 0 0 0 1.685-4.064zm-4.16 1.591-14.273 14.272a1.748 1.748 0 0 0 0 2.474l14.273 14.274a2.248 2.248 0 0 1 0 3.183 2.3 2.3 0 0 1 -3.18 0l-14.276-14.275a1.75 1.75 0 0 0 -2.474 0l-14.276 14.275a2.3 2.3 0 0 1 -3.18 0 2.248 2.248 0 0 1 0-3.182l14.273-14.275a1.748 1.748 0 0 0 0-2.474l-14.273-14.274a2.248 2.248 0 0 1 0-3.183 2.3 2.3 0 0 1 3.18 0l14.276 14.275a1.75 1.75 0 0 0 2.474 0l14.276-14.275a2.3 2.3 0 0 1 3.18 0 2.248 2.248 0 0 1 0 3.182z' fill='#01014c'/></svg></a></div>";
             var MainEndDiv = '</div>';
             var AppendContent = MainDivContent + RoomCountDivContent + InnerHtmlContent + MainEndDiv;
             $('#HotelRoomsDiv').append(AppendContent);
             $('#Umrah1_HdnRoomCount').val(addroomboxDivCount);
             SetHotelGroupPax();
             if (addroomboxDivCount == 100) {
                 $('#Hotelbtnadd').hide();
             }
         
             
         }
         else {
             $('#Hotelbtnadd').hide();
             
         }
         
     }
    
   
   
     
   
     
    
     
     
      var adult = $('#Hoteladdroombox1').val();
     var adults = $('#adults').val();
      var adult_count = parseInt($('.addroombox').find('.snAdults').val());
    
   
      $('#HotelRoomsDiv').find('.addroombox').each(function(){
        adult_count =  parseInt($(this).find('.snAdults').val()) + adult_count; 
     });
     
    $('#adults').val(adult_count);
    if(total_rooms > 1){
        $('#adults').attr('readonly', true);
       }else{
        $('#adults').attr('readonly', false);
       }
    
   }
   //////////////////////////////////////////////////////////////////////
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
    function syncAdultsTransfers(input) {
   
       
       
        var adults = $('#adultsTransfers').val();
         var adult_count = parseInt($('.addroomboxTransfers').find('.snAdultsTransfers').val());
          
         
         $('#HotelRoomInfoDivTransfers').find('.addroombox').each(function(){
           adult_count =  parseInt($(this).find('.snAdultsTransfers').val()) + adult_count; 
        });
       
       $('#adultsTransfers').val(adult_count);
    
     
   }
   
    
    // const count_adults = (value, id) => {
    //         if(id == 'adults'){
    //             $( ".addroombox" ).each(function( index ) {
                  
    //               var val_adults = $( this ).children('.adults_row').children('.snAdults');
                 
    //               console.log(val_adults);
    //             });
    //             $( "#HotelmainRoomDiv" ).each(function( index ) {
    //                  var val_adults = $( this ).children('.adults_row').children('.snAdults');
    //                  console.log(val_adults);
    //             });
    //         }
    // }
   
   //Transfers + Hotels Search //////////////////////////////////////////////////////////////
   
   
   
   $('.closeToggleTransfers').click(function () {
    $('.formpopupTransfers').toggle("slow");
   });
   $('#HotelRoomInfoDivTransfers').on('change', '.snAdultsTransfers,.snChildrenTransfers', function () {
       SetHotelGroupPaxTransfers();
   }); 
   
   
   
   function HotelAddRoomsInDivTransfers() {
       var current_room = parseInt($('#rooms_only_transfer').val());
   
       
       current_room = current_room + 1;
   // alert(current_room);
      //  if (current_room == '7')
      //   {
   
      //     $('.fade_out').fadeOut();
   
      //  }
   var adultsTransfers_count=$('#adultsTransfers').val();
   // var count_ad=$('#adults_count').val();
   //  var sum_ad=parseInt(count_ad) + parseInt(adultsTransfers_count); 
   $('#adults_count').val(adultsTransfers_count);
   
       $('#rooms_only_transfer').val(current_room);
       SetRoomGroupPaxTransfer();
   
   }
   $('#HotelRoomsDivTransfers').on('click', '.spnRemoveRoomTransfers', function () {
      
       var current_room = parseInt($('#rooms_only_transfer').val());
       current_room = current_room - 1;
       $('#rooms_only_transfer').val(current_room);
       SetRoomGroupPaxTransfer();
      
   });
   function HotelCheckAgesDivTransfers(obj) {
   var parentIDs = $(obj).parents(".addroomboxTransfers").attr("id");
   var parentIDs_1 = $(obj).parents(".addroomboxTransfers_1").attr("id");
   var ChildCount = $(obj).val();
   
   $('#' + parentIDs + ' .AgesDivTransfers').find('select').parent().parent().css("display", "none");
   
   
   if (ChildCount != 0) {
       $('#' + parentIDs + ' .AgesDivTransfers').css("display", "block");
       for (var i = 0; i < parseInt(ChildCount) ; i++) {
           $('#' + parentIDs + ' .AgeDivTransfers' + (i + 1)).css("display", "block");
       }
   }
   else {
       $('#' + parentIDs + ' .AgesDivTransfers').css("display", "none");
       for (var i = 0; i < 4; i++) {
           $('#' + parentIDs + ' .AgeDivTransfers' + (i + 1)).css("display", "block");
       }
   }
   
   }
   
   function SetHotelGroupPaxTransfers() {
   var RoomCount = 0, AdultCount = 0, ChildCount = 0;
   $('#HotelRoomInfoDivTransfers').find('.addroomboxTransfers').each(function () {
       var Adult = parseInt($(this).find('.snAdultsTransfers').val().trim());
       var Child = parseInt($(this).find('.snChildrenTransfers').val().trim());
     
       RoomCount++;
       AdultCount += Adult;
       ChildCount += Child;
       
   });
   // alert(ChildCount);
   
   $('#children_total').val(ChildCount);
   var StrPax = RoomCount + "Rooms : " + AdultCount + " Adult(s), " + ChildCount + " Children";
   // alert(StrPax);
   $('#Umrah1_txtPaxRoomsTransfers').val(StrPax);  
   // console.log($('#Umrah1_txtPaxRoomsTransfers').val(StrPax));
   }
   
   $('#adultsTransfers').change(function(){
    if($('#adultsTransfers').val() < 0){
    $('#adultsTransfers').val(1);
   }
      var value =  $('#adultsTransfers').val();
      var rooms = $('#rooms_only_transfer').val();
      var total_adults = 6 * rooms;
      var total_adults_1 = value * rooms;
      if(parseInt(value) > parseInt(total_adults)){
        value = total_adults;
       $('#adultsTransfers').val(value);
   
      }else{
          $('.snAdultsTransfers').each(function(){
            
            // alert($(this).val());
            $(this).val(total_adults_1);
            $(this).attr('value', total_adults_1);
           
          });
   
      }
      
   
   });
    function SetRoomGroupPaxTransfer(){
        
    
        
        // $('#HotelRoomsDivTransfers').empty();
   
       var i = $('#HotelRoomsDivTransfers .addroombox').length;
       var total_rooms = $('#rooms_only_transfer').val();
      
        if(total_rooms ==  i){
            // alert(total_rooms);
            // alert(i);
            var last = $('#HotelRoomsDivTransfers .addroombox').last();
            console.log(last);
            $(last).remove();
        }else{
             var i = $('#HotelRoomsDivTransfers .addroombox').length;
            i = i + 1;
             var InnerHtmlContent = $('#HotelMainRoomDesineDivTransfers').html();
             console.log(InnerHtmlContent);
            var addroomboxDivCount = i + 1;
          
            if (addroomboxDivCount < 101) {
              
                $('#room_noTransfers').val(addroomboxDivCount);
                var MainDivContent = '<div class="addroombox" id=HoteladdroomboxTransfers' + addroomboxDivCount + '><div class="addroomboxTransfers" id=HoteladdroomboxTransfers' + addroomboxDivCount + '>';
                var RoomCountDivContent = "<div class='border-bottom-1 text-center mb-2 w-100 pt-2 color-blue pb-2 '><span><i class='fa-solid fa-bed'></i>&nbsp;Room " + addroomboxDivCount + "</span><a href='javascript:void(0)' class='spnRemoveRoomTransfers' style='position: absolute;right: 25px;font-weight:900;font-size: 12px;'><i style='color: #1d3456 !important;' class='fa-solid fa-trash'></i></a></div>";
                var MainEndDiv = '</div></div>';
                var AppendContent = MainDivContent + RoomCountDivContent + InnerHtmlContent + MainEndDiv;
                $('#HotelRoomsDivTransfers').append(AppendContent);
                $('#Umrah1_HdnRoomCountTransfers').val(addroomboxDivCount);
                SetHotelGroupPax();
                if (addroomboxDivCount == 100) {
                    $('#Hotelbtnadd').hide();
                }
            
                
            }
            else {
                $('#Hotelbtnadd').hide();
                
            }
            
        }
       
     
     
        
   
        
       
        
        
         var adult = $('#HoteladdroomboxTransfers1').val();
        var adults = $('#adultsTransfers').val();
   
   
         var adult_count = parseInt($('.addroomboxTransfers').find('.snAdultsTransfers').val());
       
     
         $('#HotelRoomsDivTransfers').find('.addroombox').each(function(){
           adult_count =  parseInt($(this).find('.snAdultsTransfers').val()) + adult_count; 
   
   
   
        });
        
       $('#adultsTransfers').val(adult_count);
       
   
   
   
        
   
       if(total_rooms > 1){
        $('#adultsTransfers').attr('readonly', true);
       }else{
        $('#adultsTransfers').attr('readonly', false);
       }
       
   }
   //////////////////////////////////////////////////////////////////////
   $('.formpopup').on('click', '.inc-button', function() {
   var value = parseInt($(this).parent().find('.form-control').val());
   var input_target = $(this).attr('data-input-sync');
   var input = $(this).parent().find('.form-control');
   
   if(value < 6 ){
   value = value + 1;
   $(this).parent().find('.form-control').val(value);
   if(!!input_target){
   
    if(input_target == 'syncAdultsTransfers'){
     
      syncAdultsTransfers(input);
    }else if(input_target == 'syncAdults'){
   
      syncAdults(input);
   
    }
   }
   }
   });
   $('.formpopup').on('click', '.dec-button', function() {
   var value = parseInt($(this).parent().find('.form-control').val());
   var input_target = $(this).attr('data-input-sync');
   var input = $(this).parent().find('.form-control');
   
   if(value <= 6 && value >= 2 ){
    value = value - 1;
    $(this).parent().find('.form-control').val(value);
    if(!!input_target){
   
      if(input_target == 'syncAdultsTransfers'){
        
        syncAdultsTransfers(input);
      }else if(input_target == 'syncAdults'){
   
        syncAdults(input);
   
      }
   }
   }
   });
   $('.btn-input').click(function(){
   var target_input = $(this).attr('target-id');
   var mode = $(this).attr('mode');
   if(mode == 'increment'){
    var room = $(target_input).val();
    
    room = parseInt(room) + 1;
    $(target_input).val(room);
      if(target_input == '#rooms_only_hotel'){
        SetRoomGroupPax();
      }else if(target_input == '#rooms_only_transfer'){
        SetRoomGroupPaxTransfer();
      }
    }else if(mode == 'decrement'){
   
   
      
      var room = $(target_input).val();
       room = parseInt(room) - 1;
   
      if(room >= 1){
        $(target_input).val(room);
        if(target_input == '#rooms_only_hotel'){
          SetRoomGroupPax();
        }else if(target_input == '#rooms_only_transfer'){
          SetRoomGroupPaxTransfer();
        }
      }
   
   
   
       
    }
   
   })
      
</script>
<script>
   $(window).on('load', function () {
         var checkin = $('#check_in_1').val();
         var checkout = $('#check_out_1').val();
     
       $('#demo_modify').daterangepicker({
          	"autoApply": true,
          	"startDate": checkin,
          	"endDate": checkout,
       
          });
          
          
          
       var today = new Date();
       var end =  new Date(today);
        end.setDate(end.getDate() + 5);
    
   
   $('#demo').daterangepicker({
       "autoApply": true,
       "startDate": today,
       "endDate": end,
       "minDate": today
   });
   $('#demo').val('');
   $('#demo').attr("placeholder","Check In ~ Check Out");
   
   var end_m   = new Date(end);
   end_m.setDate(end_m.getDate() + 5);
   
   $('#demo1').daterangepicker({
       "autoApply": true,
       "startDate": today,
       "endDate": end,
       "minDate": today
   });
   $('#demo1').val('');
   $('#demo1').attr("placeholder","Check In ~ Check Out ~ Madina");
   
   
      $('#demo1').on('apply.daterangepicker', function(ev, picker) {
   
   
   ev.stopPropagation();
   
   var start_date_makkah = $('.start-date-makkah').attr('start-date-makkah');
   var end_date_makkah = $('.end-date-makkah').attr('end-date-makkah');
   
   if(!!start_date_makkah && !!end_date_makkah){
   
   
   
   var flag = true;
   
   var startDate = picker.startDate.format('MM/DD/YYYY');
   var endDate = picker.endDate.format('MM/DD/YYYY');
   var startDate = new Date(startDate);
   var endDate = new Date(endDate);
   
   checkIfDateSameMadina(startDate, endDate);
   
   
   var startDateMakkah = $('#demo').data('daterangepicker').startDate;
   
   var endDateMakkah = $('#demo').data('daterangepicker').endDate;
   
   
   var startDateMakkah = new Date(startDateMakkah);
   var endDateMakkah = new Date(endDateMakkah);
   
   
   check_madina_dates_with_makkah(startDate, endDate, startDateMakkah, endDateMakkah);
   
   
   var diffTime = Math.abs(startDate - endDate);
   var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));   
   
   
   
   var diffTimeMakkah = Math.abs(startDateMakkah - endDateMakkah);
   var diffDaysMakkah = Math.ceil(diffTimeMakkah / (1000 * 60 * 60 * 24));   
   diffDays = diffDays;
   diffDaysMakkah = diffDaysMakkah - 1;
   
   var iterateDate = startDate;
   iterateDate = new Date(iterateDate);
   for(var i=0; i<diffDays; i++){
   var iterateDateMakkah = '';
   var iterateDateMakkah = startDateMakkah;
   iterateDateMakkah = new Date(iterateDateMakkah);
   
   // newDate = startDate.setDate(startDate.getDate() + 1);
   if(i == 0){
   var startMadina = iterateDate.setDate(iterateDate.getDate() + i);
   
   }else{
   var startMadina = iterateDate.setDate(iterateDate.getDate() + 1);
   
   }
   for(var j =0 ; j<diffDaysMakkah; j++){
   
   if(j == 0){
   var startMakkah = iterateDateMakkah.setDate(iterateDateMakkah.getDate() + j);
   
   }else{
   var startMakkah = iterateDateMakkah.setDate(iterateDateMakkah.getDate() + 1);
   
   }
   
   //console.log('madina date=>' + new Date(startMadina));
   console.log('madina date=>' + new Date(startMadina));
   console.log('makkah date=>' + new Date(startMakkah));
   console.log('madina date=>' + new Date(startMadina).getTime());
   console.log('makkah date=>' + new Date(startMakkah).getTime());
   if(new Date(startMadina).getTime() == new Date(startMakkah).getTime()){
   flag = false;
   }
   
   }
   
   
   
   
   }
   
   
   
   if(flag == false){
   
   
   
   
   getMadinaDates(startDateMakkah, endDateMakkah, flag)
   
   
   
   
   
   // e.stopPropagation();
   }else{
   
   getMadinaDates(startDate, endDate, flag)
   $('.madina-error').remove();
   }
   
   }else{
   
   
   
   var startDate = picker.startDate.format('MM/DD/YYYY');
   var endDate = picker.endDate.format('MM/DD/YYYY');
   startDate = new Date(startDate);
   endDate = new Date(endDate);
   
   
   
   var startDate1  = startDate;
   startDate1 = ((startDate1.getMonth() > 8) ? (startDate1.getMonth() + 1) : ('0' + (startDate1.getMonth() + 1))) + '/' + ((startDate1.getDate() > 9) ? startDate1.getDate() : ('0' + startDate1.getDate())) + '/' + startDate1.getFullYear();
   var endDate1 = endDate;
   endDate1 = ((endDate1.getMonth() > 8) ? (endDate1.getMonth() + 1) : ('0' + (endDate1.getMonth() + 1))) + '/' + ((endDate1.getDate() > 9) ? endDate1.getDate() : ('0' + endDate1.getDate())) + '/' + endDate1.getFullYear();
   var startDate = new Date(endDate);
   
   startDate.setDate(startDate.getDate() + 1);
   endDateMadina = endDate;
   var endDateMadina = new Date(endDate);
   endDateMadina.setDate(endDateMadina.getDate() + 5);
   
   checkIfDateSameMadina(startDate, endDate);
   
   $('.calendar-madina').empty();
   var result = '<div class="calendar-madina d-flex w-100"><div class="ml-3"><b>Madina</b></div><div class="ml-3"><b class="start-date-madina" start-date-madina=' + startDate1 +'>' + startDate1 + '</b> - <b class="end-date-madina" end-date-madina=' + endDate1 +'>' + endDate1 + '</b></div></div>';
   $('.date-selector').append(result);
   }
   
   
   });
   
   const getMadinaDates = (startDateMakkah, endDateMakkah, flag) => {
   if(flag == false){
   var startDate1 = $('#demo').data('daterangepicker').startDate;
   var endDate1 = $('#demo').data('daterangepicker').endDate;
   // startDate1.setDate(startDate1.getDate() + 3);
   $('#demo1').data('daterangepicker').setStartDate(endDate1);
   endDate1 = new Date(endDate1);
   endDate1.setDate(endDate1.getDate() + 1);
   
   
   $('#demo1').data('daterangepicker').setEndDate(endDate1);
   
   
   startDate1  = startDateMakkah;
   endDate1  = endDateMakkah;
   startDate1 = ((startDate1.getMonth() > 8) ? (startDate1.getMonth() + 1) : ('0' + (startDate1.getMonth() + 1))) + '/' + ((startDate1.getDate() > 9) ? startDate1.getDate() : ('0' + startDate1.getDate())) + '/' + startDate1.getFullYear();
   endDate1 = endDate1;
   endDate1 = ((endDate1.getMonth() > 8) ? (endDate1.getMonth() + 1) : ('0' + (endDate1.getMonth() + 1))) + '/' + ((endDate1.getDate() > 9) ? endDate1.getDate() : ('0' + endDate1.getDate())) + '/' + endDate1.getFullYear();
   
   // alert(startDate1);
   // alert(endDate1);
   
   $('.calendar-madina').empty();
   var result = '<div class="calendar-madina d-flex w-100"><div class="ml-3"><b>Madina</b></div><div class="ml-3"><b class="start-date-madina" start-date-madina=' + startDate1 +'>' + startDate1 + '</b> - <b class="end-date-madina" end-date-madina=' + endDate1 +'>' + endDate1 + '</b></div></div>';
   $('.date-selector').append(result);
   $('.madina-error').empty();
   alert('Please Select Different Dates For Madina');
   var result = '<div class="d-flex w-100 madina-error"><small class="ml-3">Please Select Different Dates For Madina</small></div>';
   $('.date-selector').append(result);
   }else{
   var startDate1 = startDateMakkah;
   var endDate1 = endDateMakkah;
   startDate1  = startDate1;
   startDate1 = ((startDate1.getMonth() > 8) ? (startDate1.getMonth() + 1) : ('0' + (startDate1.getMonth() + 1))) + '/' + ((startDate1.getDate() > 9) ? startDate1.getDate() : ('0' + startDate1.getDate())) + '/' + startDate1.getFullYear();
   endDate1 = endDate1;
   endDate1 = ((endDate1.getMonth() > 8) ? (endDate1.getMonth() + 1) : ('0' + (endDate1.getMonth() + 1))) + '/' + ((endDate1.getDate() > 9) ? endDate1.getDate() : ('0' + endDate1.getDate())) + '/' + endDate1.getFullYear();
   $('.calendar-madina').empty();
   var result = '<div class="calendar-madina d-flex w-100"><div class="ml-3"><b>Madina</b></div><div class="ml-3"><b class="start-date-madina" start-date-madina=' + startDate1 +'>' + startDate1 + '</b> - <b class="end-date-madina" end-date-madina=' + endDate1 +'>' + endDate1 + '</b></div></div>';
   $('.date-selector').append(result);
   
   }
   }
   
   
   const checkIfDateSameMadina = (startDate, endDate) => {
   if(new Date(startDate).getTime() == new Date(endDate).getTime()){
   endDate = new Date(endDate);
   
   endDate = endDate.setDate(endDate.getDate() + 1);
   endDate = new Date(endDate);
   
   $('#demo1').data('daterangepicker').setEndDate(endDate);
   }
   }
   
   const check_madina_dates_with_makkah = (startDate, endDate, startDateMakkah, endDateMakkah) =>{
   if(new Date(startDateMakkah).getDate() !== new Date(endDate).getDate()){
   if(new Date(endDateMakkah).getDate() !== new Date(startDate).getDate()){
   checkIfDateSameMadina(endDateMakkah,endDateMakkah);
   endDate = new Date(endDateMakkah);
   $('#demo1').data('daterangepicker').setStartDate(endDateMakkah);
   alert('Check In or Check Out Date must match with Check In or Check Out Date Of Makkah');
   $('.madina-error').remove();
   var result = '<div class="d-flex w-100 madina-error"><small class="ml-3">heck In or Check Out Date must match with Check In or Check Out Date Of Makkah</small></div>';
   $('.date-selector').append(result);
   }
   }
   }
   
   
   
   
   $('#demo2').daterangepicker({
       "autoApply": true,
       "startDate": today,
       "endDate": end,
       "minDate": today
   });
   $('#demo2').val('');
   $('#demo2').attr("placeholder","Check In ~ Check Out");
   
   
   
   $('#demo2').on('apply.daterangepicker', function(ev, picker) {
   
   ev.stopPropagation();
   
   
   
   var start_date_madina = $('.start-date-madina_hotel').attr('start-date-madina');
   var end_date_madina = $('.end-date-madina_hotel').attr('end-date-madina');
   
   if(!!start_date_madina && !!end_date_madina){
   
   
   
   var flag = true;
   
   var startDate = picker.startDate.format('MM/DD/YYYY');
   var endDate = picker.endDate.format('MM/DD/YYYY');
   var startDate = new Date(startDate);
   var endDate = new Date(endDate);
   checkIfDateSameMakkah_hotel(startDate, endDate);
   var startDatemadina = $('#demo3').data('daterangepicker').startDate;
   
   var endDatemadina = $('#demo3').data('daterangepicker').endDate;
   
   
   var startDatemadina = new Date(startDatemadina);
   var endDatemadina = new Date(endDatemadina);
   
   
   check_makkah_dates_with_madina_hotel(startDate, endDate, startDatemadina, endDatemadina);
   
   var diffTime = Math.abs(startDate - endDate);
   var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));   
   
   
   
   var diffTimemadina = Math.abs(startDatemadina - endDatemadina);
   var diffDaysmadina = Math.ceil(diffTimemadina / (1000 * 60 * 60 * 24));   
   diffDays = diffDays;
   diffDaysmadina = diffDaysmadina - 1;
   
   var iterateDate = startDate;
   iterateDate = new Date(iterateDate);
   for(var i=0; i<diffDays; i++){
   var iterateDatemadina = '';
   var iterateDatemadina = startDatemadina;
   iterateDatemadina = new Date(iterateDatemadina);
   
   // newDate = startDate.setDate(startDate.getDate() + 1);
   if(i == 0){
   var startMadina = iterateDate.setDate(iterateDate.getDate() + i);
   
   }else{
   var startMadina = iterateDate.setDate(iterateDate.getDate() + 1);
   
   }
   for(var j =0 ; j<diffDaysmadina; j++){
   
   if(j == 0){
   var startmadina = iterateDatemadina.setDate(iterateDatemadina.getDate() + j);
   
   }else{
   var startmadina = iterateDatemadina.setDate(iterateDatemadina.getDate() + 1);
   
   }
   
   //console.log('madina date=>' + new Date(startMadina));
   console.log('madina date=>' + new Date(startMadina));
   console.log('madina date=>' + new Date(startmadina));
   console.log('madina date=>' + new Date(startMadina).getTime());
   console.log('madina date=>' + new Date(startmadina).getTime());
   if(new Date(startMadina).getTime() == new Date(startmadina).getTime()){
   flag = false;
   }
   
   }
   
   
   
   
   
   }
   
   
   if(flag == false){
   
   getMakkahDates_hotel(startDatemadina, endDatemadina, flag);
   // $(this).fadeIn();
   // e.stopPropagation();
   }else{
   getMakkahDates_hotel(startDate, endDate, flag);
   $('.madina-error').remove();
   }
   
   }else{
   
   
   
   var startDate = picker.startDate.format('MM/DD/YYYY');
   var endDate = picker.endDate.format('MM/DD/YYYY');
   startDate = new Date(startDate);
   endDate = new Date(endDate);
   var  end_of_madina = picker.endDate.format('MM/DD/YYYY');
   end_of_madina = new Date(end_of_madina);
   $('#demo3').data('daterangepicker').setStartDate(endDate);
   end_of_madina.setDate(end_of_madina.getDate() + 1);
   
   $('#demo3').data('daterangepicker').setEndDate(end_of_madina);
   
   
   checkIfDateSameMakkah_hotel(startDate, endDate);
   
   
   var startDate1  = startDate;
   startDate1 = ((startDate1.getMonth() > 8) ? (startDate1.getMonth() + 1) : ('0' + (startDate1.getMonth() + 1))) + '/' + ((startDate1.getDate() > 9) ? startDate1.getDate() : ('0' + startDate1.getDate())) + '/' + startDate1.getFullYear();
   var endDate1 = endDate;
   endDate1 = ((endDate1.getMonth() > 8) ? (endDate1.getMonth() + 1) : ('0' + (endDate1.getMonth() + 1))) + '/' + ((endDate1.getDate() > 9) ? endDate1.getDate() : ('0' + endDate1.getDate())) + '/' + endDate1.getFullYear();
   var startDate = new Date(endDate);
   
   startDate.setDate(startDate.getDate() + 1);
   endDateMadina = endDate;
   var endDateMadina = new Date(endDate);
   endDateMadina.setDate(endDateMadina.getDate() + 5);
   $('.calendar-makkah').empty();
   var result = '<div class="calendar-makkah d-flex w-100"><div class="ml-3"><b>Makkah</b></div><div class="ml-3"><b class="start-date-makkah_hotel" start-date-makkah=' + startDate1 +'>' + startDate1 + '</b> - <b class="end-date-makkah_hotel" end-date-makkah=' + endDate1 +'>' + endDate1 + '</b></div></div>';
   $('.date-selector').append(result);
   // $('#demo3').daterangepicker({
   // "autoApply": true,
   // "startDate": startDate,
   // "endDate": endDateMadina,
   // "minDate": today
   // });
   
   }
   
   
   });
   
   
   const getMakkahDates_hotel = (startDatemadina, endDatemadina, flag) => {
   if(flag == false){
   var startDate1 = $('#demo3').data('daterangepicker').startDate;
   var endDate1 = $('#demo3').data('daterangepicker').endDate;
   // startDate1.setDate(startDate1.getDate() + 3);
   $('#demo2').data('daterangepicker').setStartDate(endDate1);
   endDate1 = new Date(endDate1);
   endDate1.setDate(endDate1.getDate() + 1);
   
   
   $('#demo2').data('daterangepicker').setEndDate(endDate1);
   
   
   startDate1  = startDatemadina;
   endDate1  = endDatemadina;
   startDate1 = ((startDate1.getMonth() > 8) ? (startDate1.getMonth() + 1) : ('0' + (startDate1.getMonth() + 1))) + '/' + ((startDate1.getDate() > 9) ? startDate1.getDate() : ('0' + startDate1.getDate())) + '/' + startDate1.getFullYear();
   endDate1 = endDate1;
   endDate1 = ((endDate1.getMonth() > 8) ? (endDate1.getMonth() + 1) : ('0' + (endDate1.getMonth() + 1))) + '/' + ((endDate1.getDate() > 9) ? endDate1.getDate() : ('0' + endDate1.getDate())) + '/' + endDate1.getFullYear();
   
   // alert(startDate1);
   // alert(endDate1);
   
   $('.calendar-makkah').empty();
   var result = '<div class="calendar-makkah d-flex w-100"><div class="ml-3"><b>Makkah</b></div><div class="ml-3"><b class="start-date-makkah_hotel" start-date-makkah=' + startDate1 +'>' + startDate1 + '</b> - <b class="end-date-makkah_hotel" end-date-makkah=' + endDate1 +'>' + endDate1 + '</b></div></div>';
   $('.date-selector').append(result);
   
   $('.madina-error').empty();
   alert('Please Select Different Dates For Makkah');
   var result = '<div class="d-flex w-100 madina-error"><small class="ml-3">Please Select Different Dates For Makkah</small></div>';
   $('.date-selector').append(result);
   }else{
   var startDate1 = startDatemadina;
   var endDate1 = endDatemadina;
   startDate1  = startDate1;
   startDate1 = ((startDate1.getMonth() > 8) ? (startDate1.getMonth() + 1) : ('0' + (startDate1.getMonth() + 1))) + '/' + ((startDate1.getDate() > 9) ? startDate1.getDate() : ('0' + startDate1.getDate())) + '/' + startDate1.getFullYear();
   endDate1 = endDate1;
   endDate1 = ((endDate1.getMonth() > 8) ? (endDate1.getMonth() + 1) : ('0' + (endDate1.getMonth() + 1))) + '/' + ((endDate1.getDate() > 9) ? endDate1.getDate() : ('0' + endDate1.getDate())) + '/' + endDate1.getFullYear();
   $('.calendar-makkah').empty();
   var result = '<div class="calendar-makkah d-flex w-100"><div class="ml-3"><b>Makkah</b></div><div class="ml-3"><b class="start-date-makkah_hotel" start-date-makkah=' + startDate1 +'>' + startDate1 + '</b> - <b class="end-date-makkah_hotel" end-date-makkah=' + endDate1 +'>' + endDate1 + '</b></div></div>';
   $('.date-selector').append(result);
   
   }
   }
   
   const checkIfDateSameMakkah_hotel = (startDate, endDate) => {
   if(new Date(startDate).getTime() == new Date(endDate).getTime()){
   endDate = new Date(endDate);
   
   endDate = endDate.setDate(endDate.getDate() + 1);
   endDate = new Date(endDate);
   
   $('#demo2').data('daterangepicker').setEndDate(endDate);
   }
   }
   
   
   const check_makkah_dates_with_madina_hotel = (startDate, endDate, startDatemadina, endDatemadina) =>{
   if(new Date(startDatemadina).getDate() !== new Date(endDate).getDate()){
   if(new Date(endDatemadina).getDate() !== new Date(startDate).getDate()){
   checkIfDateSameMakkah_hotel(endDatemadina,endDatemadina);
   endDate = new Date(endDatemadina);
   $('#demo2').data('daterangepicker').setStartDate(endDatemadina);
   alert('Check In or Check Out Date must match with Check In or Check Out Date Of Madina');
   $('.madina-error').remove();
   var result = '<div class="d-flex w-100 madina-error"><small class="ml-3">heck In or Check Out Date must match with Check In or Check Out Date Of Madina</small></div>';
   $('.date-selector').append(result);
   }
   }
   }
   
   
   
   $('#demo3').daterangepicker({
       "autoApply": true,
       "startDate": today,
       "endDate": end,
       "minDate": today
   });
   $('#demo3').val('');
   $('#demo3').attr("placeholder","Check In ~ Check Out ~ Madina");
   
     $('#demo3').on('apply.daterangepicker', function(ev, picker) {
   
   
       ev.stopPropagation();
   
       var start_date_makkah = $('.start-date-makkah_hotel').attr('start-date-makkah');
       var end_date_makkah = $('.end-date-makkah_hotel').attr('end-date-makkah');
    
       if(!!start_date_makkah && !!end_date_makkah){
           
       
   
       var flag = true;
   
       var startDate = picker.startDate.format('MM/DD/YYYY');
       var endDate = picker.endDate.format('MM/DD/YYYY');
       var startDate = new Date(startDate);
       var endDate = new Date(endDate);
   
       checkIfDateSameMadina_hotel(startDate, endDate);
   
   
       var startDateMakkah = $('#demo2').data('daterangepicker').startDate;
      
       var endDateMakkah = $('#demo2').data('daterangepicker').endDate;
   
    
       var startDateMakkah = new Date(startDateMakkah);
       var endDateMakkah = new Date(endDateMakkah);
         
      
         check_madina_dates_with_makkah_hotel(startDate, endDate, startDateMakkah, endDateMakkah);
       
   
       var diffTime = Math.abs(startDate - endDate);
       var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));   
   
   
        
       var diffTimeMakkah = Math.abs(startDateMakkah - endDateMakkah);
       var diffDaysMakkah = Math.ceil(diffTimeMakkah / (1000 * 60 * 60 * 24));   
       diffDays = diffDays;
       diffDaysMakkah = diffDaysMakkah - 1;
   
      var iterateDate = startDate;
      iterateDate = new Date(iterateDate);
       for(var i=0; i<diffDays; i++){
         var iterateDateMakkah = '';
         var iterateDateMakkah = startDateMakkah;
         iterateDateMakkah = new Date(iterateDateMakkah);
        
         // newDate = startDate.setDate(startDate.getDate() + 1);
         if(i == 0){
           var startMadina = iterateDate.setDate(iterateDate.getDate() + i);
           
         }else{
           var startMadina = iterateDate.setDate(iterateDate.getDate() + 1);
          
         }
         for(var j =0 ; j<diffDaysMakkah; j++){
           
           if(j == 0){
             var startMakkah = iterateDateMakkah.setDate(iterateDateMakkah.getDate() + j);
           
           }else{
             var startMakkah = iterateDateMakkah.setDate(iterateDateMakkah.getDate() + 1);
           
           }
   
           //console.log('madina date=>' + new Date(startMadina));
           console.log('madina date=>' + new Date(startMadina));
           console.log('makkah date=>' + new Date(startMakkah));
           console.log('madina date=>' + new Date(startMadina).getTime());
           console.log('makkah date=>' + new Date(startMakkah).getTime());
           if(new Date(startMadina).getTime() == new Date(startMakkah).getTime()){
             flag = false;
           }
   
         }
   
   
   
    
       }
   
   
   
       if(flag == false){
         
   
   
   
           getMadinaDates_hotel(startDateMakkah, endDateMakkah, flag)
         
       
   
         
        
         // e.stopPropagation();
       }else{
   
           getMadinaDates_hotel(startDate, endDate, flag)
         $('.madina-error').remove();
       }
   
       }else{
         
   
         
         var startDate = picker.startDate.format('MM/DD/YYYY');
             var endDate = picker.endDate.format('MM/DD/YYYY');
            startDate = new Date(startDate);
             endDate = new Date(endDate);
   
            
   
            var startDate1  = startDate;
            startDate1 = ((startDate1.getMonth() > 8) ? (startDate1.getMonth() + 1) : ('0' + (startDate1.getMonth() + 1))) + '/' + ((startDate1.getDate() > 9) ? startDate1.getDate() : ('0' + startDate1.getDate())) + '/' + startDate1.getFullYear();
            var endDate1 = endDate;
            endDate1 = ((endDate1.getMonth() > 8) ? (endDate1.getMonth() + 1) : ('0' + (endDate1.getMonth() + 1))) + '/' + ((endDate1.getDate() > 9) ? endDate1.getDate() : ('0' + endDate1.getDate())) + '/' + endDate1.getFullYear();
            var startDate = new Date(endDate);
           
            startDate.setDate(startDate.getDate() + 1);
            endDateMadina = endDate;
            var endDateMadina = new Date(endDate);
            endDateMadina.setDate(endDateMadina.getDate() + 5);
   
            checkIfDateSameMadina_hotel(startDate, endDate);
   
            $('.calendar-madina').empty();
            var result = '<div class="calendar-madina d-flex w-100"><div class="ml-3"><b>Madina</b></div><div class="ml-3"><b class="start-date-madina_hotel" start-date-madina=' + startDate1 +'>' + startDate1 + '</b> - <b class="end-date-madina_hotel" end-date-madina=' + endDate1 +'>' + endDate1 + '</b></div></div>';
            $('.date-selector').append(result);
       }
   
   
     });
   
   
   
   
   
   
     const getMadinaDates_hotel = (startDateMakkah, endDateMakkah, flag) => {
      if(flag == false){
         var startDate1 = $('#demo2').data('daterangepicker').startDate;
         var endDate1 = $('#demo2').data('daterangepicker').endDate;
         // startDate1.setDate(startDate1.getDate() + 3);
         $('#demo3').data('daterangepicker').setStartDate(endDate1);
         endDate1 = new Date(endDate1);
         endDate1.setDate(endDate1.getDate() + 1);
           
        
           $('#demo3').data('daterangepicker').setEndDate(endDate1);
   
          
           startDate1  = startDateMakkah;
           endDate1  = endDateMakkah;
             startDate1 = ((startDate1.getMonth() > 8) ? (startDate1.getMonth() + 1) : ('0' + (startDate1.getMonth() + 1))) + '/' + ((startDate1.getDate() > 9) ? startDate1.getDate() : ('0' + startDate1.getDate())) + '/' + startDate1.getFullYear();
               endDate1 = endDate1;
             endDate1 = ((endDate1.getMonth() > 8) ? (endDate1.getMonth() + 1) : ('0' + (endDate1.getMonth() + 1))) + '/' + ((endDate1.getDate() > 9) ? endDate1.getDate() : ('0' + endDate1.getDate())) + '/' + endDate1.getFullYear();
             
             // alert(startDate1);
             // alert(endDate1);
   
             $('.calendar-madina').empty();
             var result = '<div class="calendar-madina d-flex w-100"><div class="ml-3"><b>Madina</b></div><div class="ml-3"><b class="start-date-madina_hotel" start-date-madina=' + startDate1 +'>' + startDate1 + '</b> - <b class="end-date-madina_hotel" end-date-madina=' + endDate1 +'>' + endDate1 + '</b></div></div>';
             $('.date-selector').append(result);
             $('.madina-error').empty();
           alert('Please Select Different Dates For Madina');
           var result = '<div class="d-flex w-100 madina-error"><small class="ml-3">Please Select Different Dates For Madina</small></div>';
             $('.date-selector').append(result);
      }else{
         var startDate1 = startDateMakkah;
         var endDate1 = endDateMakkah;
         startDate1  = startDate1;
             startDate1 = ((startDate1.getMonth() > 8) ? (startDate1.getMonth() + 1) : ('0' + (startDate1.getMonth() + 1))) + '/' + ((startDate1.getDate() > 9) ? startDate1.getDate() : ('0' + startDate1.getDate())) + '/' + startDate1.getFullYear();
               endDate1 = endDate1;
             endDate1 = ((endDate1.getMonth() > 8) ? (endDate1.getMonth() + 1) : ('0' + (endDate1.getMonth() + 1))) + '/' + ((endDate1.getDate() > 9) ? endDate1.getDate() : ('0' + endDate1.getDate())) + '/' + endDate1.getFullYear();
             $('.calendar-madina').empty();
             var result = '<div class="calendar-madina d-flex w-100"><div class="ml-3"><b>Madina</b></div><div class="ml-3"><b class="start-date-madina_hotel" start-date-madina=' + startDate1 +'>' + startDate1 + '</b> - <b class="end-date-madina_hotel" end-date-madina=' + endDate1 +'>' + endDate1 + '</b></div></div>';
             $('.date-selector').append(result);
   
      }
    }
   
   
    const checkIfDateSameMadina_hotel = (startDate, endDate) => {
             if(new Date(startDate).getTime() == new Date(endDate).getTime()){
             endDate = new Date(endDate);
     
             endDate = endDate.setDate(endDate.getDate() + 1);
             endDate = new Date(endDate);
            
             $('#demo3').data('daterangepicker').setEndDate(endDate);
            }
    }
   
    const check_madina_dates_with_makkah_hotel = (startDate, endDate, startDateMakkah, endDateMakkah) =>{
       if(new Date(startDateMakkah).getDate() !== new Date(endDate).getDate()){
         if(new Date(endDateMakkah).getDate() !== new Date(startDate).getDate()){
           checkIfDateSameMadina_hotel(endDateMakkah,endDateMakkah);
           endDate = new Date(endDateMakkah);
           $('#demo3').data('daterangepicker').setStartDate(endDateMakkah);
           alert('Check In or Check Out Date must match with Check In or Check Out Date Of Makkah');
           $('.madina-error').remove();
           var result = '<div class="d-flex w-100 madina-error"><small class="ml-3">Check In or Check Out Date must match with Check In or Check Out Date Of Makkah</small></div>';
           $('.date-selector').append(result);
         }
       }
    }
   
   
    $(document).ready(function(){
     $('.daterangepicker').append('<div class="date-selector"></div>');  
   });
   
   
       $('html, body').animate({
           scrollTop: $("#mySearch").offset().top
       }, 2000);
       
       flatpickr(".single-picker", {
           dateFormat: "m-d-Y",
       });
       // initialization of HSMegaMenu component
       $('.js-mega-menu').HSMegaMenu({
           event: 'hover',
           pageContainer: $('.container'),
           breakpoint: 1199.98,
           hideTimeOut: 0
       });
   
       // Page preloader
       setTimeout(function() {
         $('#jsPreloader').fadeOut(500)
       }, 800);
   });
   
   $(document).on('ready', function () {
       // initialization of header
       $.HSCore.components.HSHeader.init($('#header'));
   
       // initialization of google map
       function initMap() {
           $.HSCore.components.HSGMap.init('.js-g-map');
       }
   
       // initialization of unfold component
       $.HSCore.components.HSUnfold.init($('[data-unfold-target]'));
   
       // initialization of autonomous popups
       $.HSCore.components.HSModalWindow.init('[data-modal-target]', '.js-modal-window', {
           autonomous: true
       });
   
       // initialization of show animations
       $.HSCore.components.HSShowAnimation.init('.js-animation-link');
   
       // initialization of datepicker
       $.HSCore.components.HSRangeDatepicker.init('.js-range-datepicker');
   
       // initialization of forms
       $.HSCore.components.HSRangeSlider.init('.js-range-slider');
   
       // initialization of select
       $.HSCore.components.HSSelectPicker.init('.js-select');
   
       // initialization of malihu scrollbar
       $.HSCore.components.HSMalihuScrollBar.init($('.js-scrollbar'));
   
       // initialization of quantity counter
       $.HSCore.components.HSQantityCounter.init('.js-quantity');
   
       // initialization of slick carousel
       $.HSCore.components.HSSlickCarousel.init('.js-slick-carousel');
   
       // initialization of go to
       $.HSCore.components.HSGoTo.init('.js-go-to');
       
       $.HSCore.components.HSFancyBox.init('.js-fancybox');
   });
      
</script>